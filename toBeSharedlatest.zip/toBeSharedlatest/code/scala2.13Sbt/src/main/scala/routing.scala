package routing  
import akka.actor._
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import scala.concurrent.duration._
import akka.routing._
import akka.util._
import scala.util._

object Helper {
    val routingActorSystem = "RoutingSystem"
    val routingApp = "routingApp.conf"
    

    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        killThisSystemSeq(system, Seq(actor), killtime, sleeptime)
    }
    def killThisSystemSeq(system:ActorSystem, actors:Seq[ActorRef], killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actors.foreach{ actor => actor ! PoisonPill }
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}


 
case class Work(str:String)       
case class Result(str:String)       

class Master extends Actor with ActorLogging{
  var router = {
    val routees = Vector.fill(5) {
      val r = context.actorOf(Props(new Worker))
      context watch r
      ActorRefRoutee(r)   //create the routees as ordinary child actors wrapped in ActorRefRoutee
    }
    Router(RoundRobinRoutingLogic(), routees)
  }
 
  def receive = {
    case w: Work =>
      router.route(w, sender())  //Sending messages via the router is done with the route method
    case Terminated(a) =>
      router = router.removeRoutee(a)
      val r = context.actorOf(Props(new Worker))
      context watch r
      router = router.addRoutee(r)
  }
}

class Worker extends Actor with ActorLogging{
   
    def receive = {
        case Work(str) => 
            sender() ! Result(str.reverse) 
        case _ => 
    }

}

object RoutingDemo extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)

  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val firstRef = system.actorOf(Props(new Master), "master")


  for (_ <- 0 to 5){
      firstRef.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, firstRef, 1.minutes, 1*60*1000)
}

object RoutingDemoRRP extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrp: ActorRef = context.actorOf(FromConfig.props(Props(new Worker)), "router_rrp")
    
    override def receive: Receive = {
      case x =>
        router_rrp.forward(x)
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, parent, 1.minutes, 1*60*1000)
}

object RoutingDemoRRG extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val workers: ActorRef = system.actorOf(Props(new Actor {
    val seqw = (1 to 4).toList.map( i => context.actorOf(Props(new Worker), name = s"w$i") )

    override def receive: Receive = {
      case x =>
       println(s"In Workers !!! $x")
    }
  }), "workers")
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrg: ActorRef = context.actorOf(FromConfig.props(), "router_rrg")
    
    override def receive: Receive = {
      case x =>
        router_rrg.forward(x)
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystemSeq(system, Seq(parent, workers), 1.minutes, 1*60*1000)
}