package clustering 

import akka.cluster._
import akka.cluster.ClusterEvent._
import akka.actor._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory
import akka.cluster.ClusterEvent._ 
import scala.util._ 
import akka.util._ 
import java.util.concurrent.atomic.AtomicInteger

trait CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "ClusterSystem"
    val clusterMainApp = "clusterMainApp.conf"
    
    //val clusterTrx = "clusterTrx.conf"
    
    val sleeptime = 10*60*1000
    val killtime = 10.minutes 
    
    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=killtime, sleeptime:Int=sleeptime):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actor ! PoisonPill
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}




class SimpleClusterListener extends Actor with ActorLogging {

  val cluster = Cluster(context.system)

  // subscribe to cluster changes, re-subscribe when restart
  //def subscribe(subscriber: ActorRef, initialStateMode: SubscriptionInitialStateMode, to: Class[_]*): Unit
  // InitialStateAsEvents :When using this subscription mode the events corresponding to the current state will be sent to the subscriber to mimic what you would have seen if you were listening to the events when they occurred in the past.
  //https://doc.akka.io/api/akka/2.6.13/akka/cluster/ClusterEvent$.html
  override def preStart(): Unit = {
    cluster.subscribe(self, initialStateMode = InitialStateAsEvents,
      classOf[MemberEvent], classOf[UnreachableMember])
  }
  override def postStop(): Unit = cluster.unsubscribe(self)

  def receive = {
    //https://doc.akka.io/api/akka/2.6.13/akka/cluster/ClusterEvent$.html
    case MemberUp(member) =>
      log.info("Member is Up: {}", member.address)
    case UnreachableMember(member) =>
      log.info("Member detected as unreachable: {}", member)
    case MemberRemoved(member, previousStatus) =>
      log.info(
        "Member is Removed: {} after {}",
        member.address, previousStatus)
    case _: MemberEvent => // ignore
  }
}
//app 
object SimpleClusterApp {
  def main(args: Array[String]): Unit = {
    startup(args)
  }

  def startup(ports: Seq[String]): Unit = {
    import Helper._ 
    
    ports foreach { port =>
      // Override the configuration of the port
      val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """).withFallback(ConfigFactory .load(clusterMainApp))

      // Create an Akka system , ClusterSystem must be as per seedNode 
      val system = ActorSystem(clusterActorSystem, config)
      // Create an actor that handles cluster domain events
      val lis = system.actorOf(Props(new SimpleClusterListener), name = "clusterListener")
      
      killThisSystem(system, lis)
    }
  }

}

//Worker 
final case class TransformationJob(text: String) extends CborSerializable
final case class TransformationResult(text: String) extends CborSerializable
final case class JobFailed(reason: String, job: TransformationJob) extends CborSerializable

//Only use case class 
final case class BackendRegistration() extends CborSerializable
//case object BackendRegistration


//frontend 
class TransformationFrontend extends Actor {

  var backends = IndexedSeq.empty[ActorRef]
  var jobCounter = 0

  def receive = {
    case job: TransformationJob if backends.isEmpty =>
      sender() ! JobFailed("Service unavailable, try again later", job)

    case job: TransformationJob =>
      jobCounter += 1
      backends(jobCounter % backends.size) forward job

    //Backend Sends this 
    case _ : BackendRegistration if !backends.contains(sender()) =>
      context watch sender()
      backends = backends :+ sender()

    case Terminated(a) =>
      backends = backends.filterNot(_ == a)
  }
}

object TransformationFrontend {
  def main(args: Array[String]): Unit = {
    import Helper._ 
    
    // Override the configuration of the port when specified as program argument
    val port = if (args.isEmpty) "0" else args(0)
    val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
      .withFallback(ConfigFactory.parseString("akka.cluster.roles = [frontend]"))
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem(clusterActorSystem, config)
    val frontend = system.actorOf(Props(new TransformationFrontend), name = "frontend")

    
    import system.dispatcher
    val input = Seq("IAMCLUSTER", "HELLO WORLD")
    val counter = new AtomicInteger
    system.scheduler.scheduleAtFixedRate(1.seconds, 1.seconds){ () => 
      implicit val timeout = Timeout(5.seconds)
      import akka.pattern._
      

      val text = input(counter.incrementAndGet() % input.size)
      
      (frontend ? TransformationJob(text)).onComplete {
        case Success(TransformationResult(result)) => println(s"Result: $result")
        case Failure(ex)  => println(s"Result exception: $ex")
        case x => println(s"Result ???: $x")
      }
    }
    
          
    killThisSystem(system, frontend)

  }
}

//Backend 
class TransformationBackend extends Actor with ActorLogging{

  val cluster = Cluster(context.system)

  // subscribe to cluster changes, MemberUp
  // re-subscribe when restart
  override def preStart(): Unit = cluster.subscribe(self, classOf[MemberUp])
  override def postStop(): Unit = cluster.unsubscribe(self)

  def receive = {
    case TransformationJob(text) => sender() ! TransformationResult(text.reverse)
    case state: CurrentClusterState =>
      state.members.filter(_.status == MemberStatus.Up) foreach register
    case MemberUp(m) => register(m)
  }

  def register(member: Member): Unit = {
    if (member.hasRole("frontend")){
      log.info(s"member=$member ${member.address}")
      context.actorSelection(RootActorPath(member.address) / "user" / "frontend") ! BackendRegistration()
      }
   }
}

object TransformationBackend {
  def main(args: Array[String]): Unit = {
    import Helper._ 
    
    // Override the configuration of the port when specified as program argument
    val port = if (args.isEmpty) "0" else args(0)
    val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
      .withFallback(ConfigFactory.parseString("akka.cluster.roles = [backend]"))
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem(clusterActorSystem, config)
    val backend = system.actorOf(Props(new TransformationBackend), name = "backend")
    
    killThisSystem(system, backend)
  }
}
