package persistance  
import akka.actor._
import akka.persistence._

import com.typesafe.config.ConfigFactory
import scala.concurrent._
import scala.concurrent.duration._
import akka.routing._
import akka.util._
import scala.util._



object Helper {
    val actorSystemName = "TestSystem"  //must match with 
    val configFile = "persistance.conf"
    

    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        killThisSystemSeq(system, Seq(actor), killtime, sleeptime)
    }
    def killThisSystemSeq(system:ActorSystem, actors:Seq[ActorRef], killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actors.foreach{ actor => actor ! PoisonPill }
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}

case class Cmd(data: String)
case class Evt(data: String)

case class ExampleState(events: List[String] = Nil) {
  def updated(evt: Evt): ExampleState = copy(evt.data :: events)
  def size: Int = events.length
  override def toString: String = events.reverse.toString
}

class ExamplePersistentActor extends PersistentActor {
  override def persistenceId = "sample-id-1"

  //Some state, which would be mutated and captures Actor state 
  var state = ExampleState()

  def updateState(event: Evt): Unit =  
    state = state.updated(event)

  def numEvents =  state.size
  
  //Note, same TYPE in recieveRecover's case evt:TYPE and persist(TYPE)(handler(TYPE):Unit)
  //handler(TYPE) updates STATE , here examplestate 

  val receiveRecover: Receive = {
    case SnapshotOffer(metadata, snapshot: ExampleState) => state = snapshot  
    //if snapshot is saved, we get this first
    //get the same type as 1st arg of persist , goal is to mutate state variable 
    case evt: Evt                                 => updateState(evt)  
    //then we get each event persisted earlier, one by one 
  }

  //Command handler main job is to convert Command to Event 
  //and persist the event by persist[A](event: A)(handler: (A) => Unit): Unit
  //    OR  persistAll[A](events: Seq[A])(handler: (A) => Unit): Unit
  val receiveCommand: Receive = {
    case Cmd(data) =>
      //note handler gets the same type as 1st arg of persist , goal is to mutate state variable
      persist(Evt(s"${data}-${numEvents}"))(updateState)  //updatestate takes same Event, 1st arg of persist
      persist(Evt(s"${data}-${numEvents + 1}")) { event =>
        updateState(event)
        context.system.eventStream.publish(event)
      }
    case "snap"  => saveSnapshot(state)  
    //explicit save snapshot handling , required to minimize performance hit 
    //Persistent actors can save snapshots of internal state by calling the saveSnapshot method. 
    //If saving of a snapshot succeeds, the persistent actor receives a SaveSnapshotSuccess message, 
    //otherwise a SaveSnapshotFailure message
    
    //where metadata is of type SnapshotMetadata and contains:
    //persistenceId
    //sequenceNr
    //timestamp

    case "print" => println(state)
    case SaveSnapshotSuccess(metadata)         => // ...
    case SaveSnapshotFailure(metadata, reason) => // ...
    //To experiment with Failure 
    case "boom"  => throw new Exception("boom")
  }

}

object PersistentActorExample extends App {
  import Helper._ 
  
  val system = ActorSystem(actorSystemName, ConfigFactory.load(configFile))
  
  val persistentActor = system.actorOf(Props(new ExamplePersistentActor), "persistentActor-4-scala")

  persistentActor ! Cmd("foo")
  persistentActor ! Cmd("baz")
  persistentActor ! Cmd("bar")
  persistentActor ! "snap"
  persistentActor ! Cmd("buzz")
  persistentActor ! "print"
  
  persistentActor ! "boom" // restart and recovery
  persistentActor ! "print"
  persistentActor ! Cmd("foo")
  persistentActor ! Cmd("baz")
  persistentActor ! Cmd("bar")
  persistentActor ! "print"
  
  killThisSystem(system, persistentActor, 1.minutes, 1*60*1000)
}
