package typedpubsub

import akka.actor.typed.scaladsl._
import akka.cluster.ClusterEvent._
import akka.cluster.typed._
import akka.actor.typed._
import akka.actor.typed.pubsub.Topic

import scala.concurrent.duration._ 
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import akka.util._
import akka._
import akka.actor.typed.receptionist._
import scala.util._ 

import typedclustering.CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "TypedClusterSystem"
    val clusterMainApp = "typedclusterMainApp.conf"      
    val sleeptime = 10*60*1000
    
    def killThisSystem[X](system:ActorSystem[X], sleeptime:Int=sleeptime):Unit = {    
        Thread.sleep(sleeptime)
        system.terminate()
    }

}

object ClusterPubSubExample {
  
  
  object RootBehavior {
    sealed trait Event extends CborSerializable
    final case class Message(msg:String) extends Event 
    case object Stop extends Event 
    case object Tock extends Event
    
    def apply(): Behavior[Event] = Behaviors.setup[Event] { ctx =>
      Behaviors.withTimers { timers =>
          val cluster = Cluster(ctx.system)     
          val topic = ctx.spawn(Topic[Message]("my-topic"), "MyTopic")
          topic ! Topic.Subscribe(ctx.self)
          timers.startTimerWithFixedDelay(Tock, Tock, 5.seconds)
          timers.startSingleTimer(Stop, Stop, 1.minutes)
        
          if (cluster.selfMember.hasRole("backend")) {     
            ctx.log.info("Sending@ {}", cluster.selfMember.roles )            
            topic ! Topic.Publish(Message("Hello from backend"))
          }
          if (cluster.selfMember.hasRole("frontend")) {            
            ctx.log.info("Sending@ {}", cluster.selfMember.roles )
            topic ! Topic.Publish(Message("Hello from frontend"))
          }          
          Behaviors.receiveMessage{
            case sx @ Message(_) => 
                ctx.log.info2("Got Message@{}: {}", cluster.selfMember.roles, sx )
                Behaviors.same     
            case Stop =>
                topic ! Topic.Unsubscribe(ctx.self)
                Behaviors.stopped
            case Tock =>
                topic ! Topic.Publish(Message("Hello in general"))
                Behaviors.same    
          }          
        }
    }
  }

  def main(args: Array[String]): Unit = {
    require(args.size == 1, "Usage: role port")
    startup(args(0), args(1).toInt)
  }

  def startup(role: String, port: Int): Unit = {
    // Override the configuration of the port and role
    import Helper._ 
    val config = ConfigFactory.parseString(s"""
        akka.remote.artery.canonical.port=$port
        akka.cluster.roles = [$role]
        """)
      .withFallback(ConfigFactory.load(clusterMainApp)) 

    val system = ActorSystem[RootBehavior.Event](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }
}