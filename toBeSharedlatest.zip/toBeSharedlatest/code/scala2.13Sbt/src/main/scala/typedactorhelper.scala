import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory

object TypedActorHelper{

    def process[T,X]( system: ActorSystem[X], props:Behavior[T], actorName: String = "name", stopMessage:Seq[T]=Seq.empty[T])
            (sendfn: (ActorSystem[X], ActorRef[T]) => Any):Function0[Unit]  = {
        processSeq[T,X](system, Seq( (actorName, props) ), stopMessage){
            (system, seq) => sendfn(system, seq.head)
        }
    }
    def testGuardianSystem[T]( guardian:Behavior[T], name: String = "guardiansystem_under_test")
            (sendfn: ActorSystem[T]=> Any):Function0[Unit]  = {
        val system = ActorSystem(guardian, name)
        val x= sendfn(system)
        ( () => {
              println(s"Stopping, body returned $x")
              system.terminate()
           }
        )
    }
    def testGuardianSystemWithConfig[T](guardian:Behavior[T], configFilename: String, name: String = "guardiansystem_under_test")
            (sendfn: ActorSystem[T]=> Any):Function0[Unit]  = {
        val system = ActorSystem(guardian, name, ConfigFactory.load(configFilename))
        val x= sendfn(system)
        ( () => {
              println(s"Stopping, body returned $x")
              system.terminate()
           }
        )
    } 
    def testActor[T](props:Behavior[T], actorName: String = "name", stopMessage:Seq[T]=Seq.empty[T])
            (sendfn: (ActorSystem[Any], ActorRef[T]) => Any):Function0[Unit]  = {
            
        val system = ActorSystem(Behaviors.empty[Any], "testsystem_TypedActorHelper")
        val close = processSeq[T,Any](system, Seq( (actorName, props) ), stopMessage){
            (system, seq) => sendfn(system, seq.head)
        }
        ( () => {
            close()
            system.terminate()
          }
        )
    }
    def processSeq[T,X]( system: ActorSystem[X], propNames:Seq[(String, Behavior[T])], stopMessage:Seq[T]=Seq.empty[T] )
            (sendfn: (ActorSystem[X], Seq[ActorRef[T]]) => Any ):Function0[Unit]  = {
        process(system){system => 
            propNames.map{case (n,p) => system.systemActorOf(p, n)}
          }{ (system, seq) =>
            if (seq.nonEmpty)
                seq.zip(stopMessage).foreach{ case(a, m) => a ! m} 
                else 
                    ()
          }{(system, seq) => 
            sendfn(system, seq)
        }
    } 
    def process[T, X](system: ActorSystem[X])(createActors: ActorSystem[X]=>Seq[ActorRef[T]]) 
            (stopActors:((ActorSystem[X], Seq[ActorRef[T]])=>Unit)  )
            (body: (ActorSystem[X], Seq[ActorRef[T]]) => Any ):Function0[Unit]  = {
        val actors = createActors(system)
        println(s"Created: ${actors.map(_.toString).mkString("(",",",")")}")
        val x = body(system, actors)
        ( () => {
              println(s"Stopping, body returned $x")
              stopActors(system,actors)
           }
        )
    }   

   
    def ask[T,U:scala.reflect.ClassTag,X, R](system:ActorSystem[X], target: RecipientRef[T], reciever:Option[ActorRef[R]]=None)(createRequest:ActorRef[U]=>T):Unit=
        system.systemActorOf(TestProb.askM[T,U,R](target, createRequest, reciever), "asrx")


    object TestProb {
        case object ECHOSTOP
        def echo[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
            context.log.info(s"New msg received: $msg")  
            msg match{
                case ECHOSTOP => 
                    println(s"${context.self} stopping")
                    Behaviors.stopped  
                case _ => Behaviors.same    
            }
        }
        def echoOnce[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
            context.log.info(s"New msg received: $msg")  
            Behaviors.stopped 
        }
        //(ActorRef[PingService.Ping], ActorRef[PingService.Pong.type] => PingService.Ping) => Behavior[PingService.Pong.type]
        //echoOnceAfterSendOnce[PingService.Ping, PingService.Pong.type](ps, PingService.Ping(_))
        def echoOnceAfterSendOnce[T, U:scala.reflect.ClassTag](target: RecipientRef[T], reqFn:ActorRef[U]=>T):Behavior[U] = Behaviors.setup { context =>
            val receiver = context.spawnAnonymous( echoOnce[U]())
            askM[T,U,U](target, reqFn, Option(receiver))
        }     
        //Many 
        sealed trait Command 
        case class Request(msg:Any, replyTo: ActorRef[Any]) extends Command 
        case object Stop extends Command 
        
        def sendRec(): Behavior[Command] = Behaviors.receive { (context, msg) =>
            context.log.info(s"${context.self} - New msg received: $msg")  
            msg match {
                case Stop => Behaviors.stopped
                case Request(msg, replyTo) =>
                    replyTo ! msg
                    Behaviors.same 
            }                
        } 
        
        //ask 
        def askM[T, U:scala.reflect.ClassTag,R](target: RecipientRef[T], reqFn:(ActorRef[U]=>T), rx:Option[ActorRef[R]]=None): Behavior[R] = Behaviors.setup{ context =>
            import scala.concurrent.duration._
            implicit val timeout = akka.util.Timeout(5.seconds)
            import  scala.util._
            context.ask(target, reqFn ){  //target would get T and return Res 
                case Success(res) => res.asInstanceOf[R]  //res:U, res goes to receiveMessage.msg 
                case Failure(ex)  =>  s"ex".asInstanceOf[R]
            }
            var echoCreated = false         
            val echo = rx.getOrElse{
                    echoCreated = true 
                    context.spawnAnonymous(TestProb.echo[R]())
                }
            
            Behaviors.receiveMessage {  msg:R =>
                echo ! msg 
                if(echoCreated){                
                    //children are autoclosed, so not needed 
                    Behaviors.stopped( () => context.stop(echo) )
                } else 
                 Behaviors.stopped               
            }
        }
    }
}
