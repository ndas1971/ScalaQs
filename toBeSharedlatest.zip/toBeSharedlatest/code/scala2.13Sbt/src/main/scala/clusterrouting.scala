package clusterrouting  
import akka.actor._
import akka.cluster._
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import scala.concurrent.duration._
import akka.routing._
import akka.util._
import scala.util._
import akka.cluster.ClusterEvent._
import java.util.concurrent.ThreadLocalRandom
import akka.routing.ConsistentHashingRouter.ConsistentHashableEnvelope

object Helper {
    val routingActorSystem = "ClusterRoutingSystem"  //must match with seedNodes 
    val routingConf = "clusterrouting.conf"
    

    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        killThisSystemSeq(system, Seq(actor), killtime, sleeptime)
    }
    def killThisSystemSeq(system:ActorSystem, actors:Seq[ActorRef], killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actors.foreach{ actor => actor ! PoisonPill }
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}
trait CborSerializable
final case class StatsJob(text: String) extends CborSerializable
final case class StatsResult(meanWordLength: Double) extends CborSerializable
final case class JobFailed(reason: String) extends CborSerializable

class StatsWorker extends Actor {
  var cache = Map.empty[String, Int]
  def receive = {
    case word: String =>
      val length = cache.get(word) match {
        case Some(x) => x
        case None =>
          val x = word.length
          cache += (word -> x)
          x
      }

      sender() ! length
  }
}

// ConsistentHashableEnvelope(message: Any, hashKey: Any) 
//If you don't define the hashMapping when constructing the akka.routing.ConsistentHashingRouter 
//and messages can't implement akka.routing.ConsistentHashingRouter.ConsistentHashable themselves 
//they can we wrapped by this envelope instead. 
//The router will only send the wrapped message to the destination, i.e. the envelope will be stripped off. 


class StatsService(name:String) extends Actor {
  // This router is used both with lookup and deploy of routees. If you
  // have a router with only lookup of routees you can use Props.empty
  // instead of Props[StatsWorker.class].
  val workerRouter = context.actorOf(FromConfig.props(Props(new StatsWorker)),  name = name)

  def receive = {
    case StatsJob(text) if text != "" =>
      val words = text.split(" ")
      val replyTo = sender() // important to not close over sender()
      // create actor that collects replies from workers
      val aggregator = context.actorOf(Props( new StatsAggregator( words.size, replyTo)))
      words foreach { word =>
        workerRouter.tell(
          ConsistentHashableEnvelope(word, word), aggregator) //aggregator would get reply 
      }
  }
}

class StatsAggregator(expectedResults: Int, replyTo: ActorRef) extends Actor {
  var results = IndexedSeq.empty[Int]
  context.setReceiveTimeout(3.seconds)

  def receive = {
    case wordCount: Int =>
      results = results :+ wordCount
      if (results.size == expectedResults) {
        val meanWordLength = results.sum.toDouble / results.size
        replyTo ! StatsResult(meanWordLength)
        context.stop(self)
      }
    case ReceiveTimeout =>
      replyTo ! JobFailed("Service unavailable, try again later")
      context.stop(self)
  }
}

//Group 
object ClusterGroupRouter {
  def main(args: Array[String]): Unit = {
    startup(args)
  }

  def startup(ports: Seq[String]): Unit = {
    import Helper._ 
    ports foreach { port =>
      // Override the configuration of the port when specified as program argument
      val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
        .withFallback(
          ConfigFactory.parseString("akka.cluster.roles = [compute]")).
          withFallback(ConfigFactory.load(routingConf))

      val system = ActorSystem(routingActorSystem, config)

      system.actorOf(Props(new StatsWorker), name = "statsWorkerGROUP")
      system.actorOf(Props(new StatsService("workerRouterGROUP")), name = "statsServiceGROUP")
    }
  }
}

object ClusterGroupRouterClient {
  import Helper._ 
  def main(args: Array[String]): Unit = {
    // note that client is not a compute node, role not defined
    val system = ActorSystem(routingActorSystem , ConfigFactory.load(routingConf))
    system.actorOf(Props(new StatsClient("/user/statsServiceGROUP")), "client")
  }
}

class StatsClient(servicePath: String) extends Actor {
  val cluster = Cluster(context.system)
  
  val servicePathElements = servicePath match {
    case RelativeActorPath(elements) => elements
    case _ => throw new IllegalArgumentException(
      "servicePath [%s] is not a valid relative actor path" format servicePath)
  }
  
  import context.dispatcher
  val tickTask = context.system.scheduler.scheduleAtFixedRate(2.seconds, 2.seconds, self, "tick")

  var nodes = Set.empty[Address]

  override def preStart(): Unit = {
    cluster.subscribe(self, classOf[MemberEvent], classOf[ReachabilityEvent])
  }
  override def postStop(): Unit = {
    cluster.unsubscribe(self)
    tickTask.cancel()
  }

  def receive = {
    case "tick" if nodes.nonEmpty =>
      // just pick any one
      val address = nodes.toIndexedSeq( ThreadLocalRandom.current.nextInt(nodes.size) )
      val service = context.actorSelection(RootActorPath(address) / servicePathElements)
      service ! StatsJob("this is the text that will be analyzed")
      
    case result: StatsResult =>
      println(result)
      
    case failed: JobFailed =>
      println(failed)
      
    case state: CurrentClusterState =>
      nodes = state.members.collect {
        case m if m.hasRole("compute") && m.status == MemberStatus.Up => m.address
      }
      
    case MemberUp(m) if m.hasRole("compute")        => nodes += m.address
    case other: MemberEvent                         => nodes -= other.member.address
    case UnreachableMember(m)                       => nodes -= m.address
    case ReachableMember(m) if m.hasRole("compute") => nodes += m.address
  }

}
//Pool 
import akka.cluster.singleton._


object ClusterPoolRouter {
  def main(args: Array[String]): Unit = {
      startup(args)
  }

  def startup(ports: Seq[String]): Unit = {
    import Helper._ 
    
    ports foreach { port =>
      // Override the configuration of the port when specified as program argument
      val config =
        ConfigFactory.parseString(s"""
          # akka.remote.netty.tcp.port=$port
          akka.remote.artery.canonical.port=$port
          """).withFallback(
          ConfigFactory.parseString("akka.cluster.roles = [compute]")).
          withFallback(ConfigFactory.load(routingConf))

      val system = ActorSystem(routingActorSystem, config)

      system.actorOf(ClusterSingletonManager.props(
        singletonProps = Props(new StatsService("workerRouterPOOL")),
        terminationMessage = PoisonPill,
        settings = ClusterSingletonManagerSettings(system).withRole("compute")),
        name = "statsServicePool")

      system.actorOf(ClusterSingletonProxy.props(singletonManagerPath = "/user/statsServicePool",
        settings = ClusterSingletonProxySettings(system).withRole("compute")),
        name = "statsServiceProxy")
    }
  }
}

object ClusterPoolRouterClient {
  import Helper._ 
  def main(args: Array[String]): Unit = {
    // note that client is not a compute node, role not defined
    val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingConf))
    system.actorOf(Props(new StatsClient("/user/statsServiceProxy")), "client")
  }
}