Day Four
//9. Familiarizing Yourself with Basic Monads
//    Familiarizing Yourself with Basic Monads
//    Introduction to monads
//    Id Monad
//    State monad
//    Reader monad
//    Writer monad
10. A Look at Monad Transformers and Free Monad
    A Look at Monad Transformers and Free Monad
    Combining monads
    Monad transformers
    Monad transformers stacks
    Free monads
#11. An Introduction to the Akka and Actor Models
#    An Introduction to the Akka and Actor Models
#    Introduction to the actor model
#    Akka basics
#    Advanced topics
#    Testing actors
#    Running the application
-------------------------------------------

////--------------------A Look at Monad Transformers and Free Monad---------------------------------------------------------------------------------------
10.   A Look at Monad Transformers and Free Monad
·       A Look at Monad Transformers and Free Monad
·       Combining monads
·       Monad transformers
·       Monad transformers stacks
·       Free monads

///Combining monads
we talked about standard effects such as Option,Try, Either, and Future. 

case class Bait(name: String) extends AnyVal
case class Line(length: Int) extends AnyVal
case class Fish(name: String) extends AnyVal


For an instance, this is the way we defined the process of fishing in terms of Option 

val   buyBait: String => Option[Bait] = str => Option(Bait(str))
val   makeBait: String => Option[Bait] = str => Option(Bait(str))
val   castLine: Bait => Option[Line] = bait => Option(Line(0))
val   hookFish: Line => Option[Fish] = line => Option(Fish("noname"))

def goFishing(bestBaitForFish: Option[String]): Option[Fish] =
  for {
    baitName <- bestBaitForFish
    bait <- buyBait(baitName).orElse(makeBait(baitName))
    line <- castLine(bait)
    fish <- hookFish(line)
  } yield fish

With our new obtained knowledge about monads, we could make this implementation effect-agnostic (ie instead of Option, other F[_]):

trait Monad[F[_]]{
  def flatMap[A, B](a: F[A])(f: A => F[B]): F[B]
  def pure[A](a: A): F[A]
  def map[A, B](a: F[A])(f: A => B): F[B] = flatMap(a)(a => pure(f(a)))
  def ap[A, B](a: F[A])(ff: F[A => B]): F[B] = flatMap(ff)(f => map(a)(f))
}
object Monad {
  def apply[F[_] : Monad]: Monad[F] = implicitly[Monad[F]]
}
//extension method on F[A]
object lowPriorityImplicits {
    implicit class MonadF[A, F[_] : Monad](val value: F[A]) {
      private val M = implicitly[Monad[F]]
      def pure(a: A) = M.pure(a)
      def flatMap[B](fab: A => F[B]): F[B] = M.flatMap(value)(fab)
      def map[B](fab: A => B): F[B] = M.map(value)(fab)
      def ap[B](ff: F[A => B]): F[B] = M.ap(value)(ff)
    }
}

//Use cats 
import cats._ 
import cats.implicits._
  
def goFishing[M[_]](bestBaitForFish: M[String])(implicit M: Monad[M]): M[Fish] = {

   val   buyBait: String => M[Bait] = str => M.pure(Bait(str))
   //val   makeBait: String => M[Bait] = str => M.pure(Bait(str))
   val   castLine: Bait => M[Line] = bait => M.pure(Line(0))
   val   hookFish: Line => M[Fish] = line => M.pure(Fish("noname"))
   
   //import lowPriorityImplicits._

   for {
     baitName <- bestBaitForFish
     bait <- buyBait(baitName)  //no generaic .orElse
     line <- castLine(bait)
     fish <- hookFish(line)
   } yield fish
}

goFishing(Option("Crankbait"))
//Option[Fish] = Some(Fish(noname))

Another simplification we are making here is pretending that all our actions can be
described by the same effect. In reality, return could be N 

//Compilation Error  
def goFishing[M[_]: Monad, N[_]: Monad](bestBaitForFish: M[String]):N[Fish] = {

  val buyBait: String => N[Bait] = ???
  val castLine: Bait => M[Line] = ???
  val hookFish: Line => N[Fish] = ???
  
  //import lowPriorityImplicits._
   for {
     baitName <- bestBaitForFish  // Here M[_]
     bait <- buyBait(baitName)    //here N[_], must be M , as it is flatMap(F[A])(A=>B):F[B]
     line <- castLine(bait)
     fish <- hookFish(line)
   } yield fish
}

//Compilation Error 
import scala.concurrent.ExecutionContext.Implicits.global
goFishing[Option, Future](Option("Crankbait"))

Because of Compilation Error , it looks like we have two possibilities to combine desired effects:
    Put them in separate for-comprehensions
    Lift different effects to some kind of common denominator type

We can compare both approaches using our fishing example as the playground. The
variation of separate for-comprehensions would look like the following:


def goFishing[M[_]: Monad, N[_]: Monad](bestBaitForFish: M[String]) = {

  val buyBait: String => N[Bait] = ???
  val castLine: Bait => M[Line] = ???
  val hookFish: Line => N[Fish] = ???
  
  //import lowPriorityImplicits._
   for {
      baitName <- bestBaitForFish
    } yield for {
      bait <- buyBait(baitName)
    } yield for {
      line <- castLine(bait)
    } yield for {
      fish <- hookFish(line)
    } yield fish
}

The type of the result has changed from N[Fish] to the M[N[M[N[Fish]]]]. 
In the specific cases of Future and Option, it would be Option[Future[Option[Future[Fish]]]] 


Another option would be to abandon the generosity of our implementation and make it
nonpolymorphic as follows:

import scala.concurrent._ 
import scala.concurrent.ExecutionContext.Implicits.global

val   buyBait: String => Future[Bait] = str => Future(Bait(str))
val   castLine: Bait => Option[Line] = bait => Option(Line(0))
val   hookFish: Line => Future[Fish] = line => Future(Fish("noname"))

def goFishing(bestBaitForFish: Option[String]): Future[Fish] =
  bestBaitForFish match {
    case None => (Future.failed(new NoSuchElementException))
    case Some(name) => buyBait(name).flatMap { bait: Bait =>
      castLine(bait) match {
        case None => Future.failed(new IllegalStateException)
        case Some(line) => hookFish(line)
      }
    }
  }

However, 2nd approach 'Lift different effects to some kind of common denominator type'
might bear more fruit than the first one.

First, we need to decide how we want to compose the two effects we currently have. There
are two choices: Future[Option[_]] and Option[Future[_]]. 

Lets take Future[Option[_]]
This type of composition of Monads is called Monad Transformer.

//Using cats 
import cats._ 
import cats.implicits._ 
import cats.data._ 

By convention, in Cats a monad Foo will have a transformer class called FooT.
    ·   case class cats.data.OptionT[F[_], A](value: F[Option[A]]) for Option;
    ·   case class cats.data.EitherT[F[_], A, B](value: F[Either[A, B]]) for Either;
    ·   case class cats.data.Kleisli[F[_], -A, B](run: A => F[B])
        type ReaderT[F[_], -A, B] = Kleisli[F, A, B] for Reader;
    ·   case class cats.data.WriterT[F[_], L, V](run: F[(L, V)]) for Writer;
    ·   class cats.data.IndexedStateT[F[_], SA, SB, A](val runF: F[SA => F[(SB, A)]]) for State;
        type StateT[F[_], S, A] = IndexedStateT[F, S, S, A]
    ·   case class cats.data.IdT[F[_], A](value: F[A]) for the Id monad.
    
Many monads in Cats are defined using the corresponding transformer and the Id/Eval monad. 
type Reader[E, A] = ReaderT[Id, E, A] // = Kleisli[Id, E, A]
type Writer[W, A] = WriterT[Id, W, A]
type State[S, A]   = StateT[Eval, S, A]


All of these monad transformers follow the same convention. The transformer
itself represents the inner monad in a stack, while the first type parameter
specifies the outer monad (INSIDE OUT). The remaining type parameters are the types we have
used to form the corresponding monads.

type ListOption[A] = OptionT[List, A]  //List of Option [A]

For example, suppose we want to wrap Either around Option. 

// Alias Either to a type constructor with one parameter:
type ErrorOr[A] = Either[String, A]
// Build our final monad stack using OptionT:
type ErrorOrOption[A] = OptionT[ErrorOr, A]  

ErrorOrOption is a monad, just like ListOption. We can use pure, map, and
flatMap as usual to create and transform instances:

val a = 10.pure[ErrorOrOption]
// a: ErrorOrOption[Int] = OptionT(Right(Some(10)))
val b = 32.pure[ErrorOrOption]
// b: ErrorOrOption[Int] = OptionT(Right(Some(32)))

//OR 
val a = OptionT[ErrorOr, Int](Right(Some(10)))


val c = a.flatMap( (x:Int) => b.map((y:Int) => x + y))
// c: OptionT[ErrorOr, Int] = OptionT(Right(Some(42)))
//OR Cuts accross all layers 
val c = for {
 x <- a 
 y <- b
 } yield x+y //OptionT[ErrorOr, Int]
 
// Extracting the untransformed monad stack:
c.value 
// res4: ErrorOr[Option[Int]] = Right(Some(42))

// Mapping over the Either in the stack:
c.value.map(_.getOrElse(-1))
// res5: Either[String, Int] =  Right(42)

 
//Earlier example 
case class Bait(name: String) extends AnyVal
case class Line(length: Int) extends AnyVal
case class Fish(name: String) extends AnyVal

import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global
//We need Future[Option[_]] so, Use OptionT[Future, *] - INSIDE OUT 

type OptionFuture[A] = OptionT[Future, A]
//Future(Option(x)) 

val buyBaitFO: String => OptionT[Future, Bait] = str => Bait(str).pure[OptionFuture] //OptionT(Future(Success(Some(Bait(str)))))
val castLineFO: Bait => OptionT[Future, Line] = bat => Line(0).pure[OptionFuture]   //pure only takes F[_], so create a typelambda or type alias 
val hookFishFO: Line => OptionT[Future, Fish] = line => Fish("noname").pure[OptionT[Future, *]]


def goFishing(bestBaitForFish: OptionT[Future, String]): OptionT[Future, Fish] = {
    for {      
      name <- bestBaitForFish
      bait <- buyBaitFO(name)
      line <- castLineFO(bait)
      fish <- hookFishFO(line)
    } yield fish
}

goFishing( "haha".pure[OptionFuture])
//OptionT[scala.concurrent.Future,Fish]
val fish = goFishing( "haha".pure[OptionFuture]).flatMap( (f:Fish) => f.pure[OptionFuture])
//cats.data.OptionT[scala.concurrent.Future,Fish] = OptionT(Future(Success(Some(Fish(noname)))))

//It's a Future 
import scala.concurrent.duration._
Await.result(fish.value, Duration.Inf)
//Option[Fish] = Some(Fish(noname))

//Another example 
For example, lets create a Future of an Either of Option. Once again we
build this from the inside out with an OptionT of an EitherT of Future. 

import scala.concurrent._

type FutureEither[A] = EitherT[Future, String, A]
type FutureEitherOption[A] = OptionT[FutureEither, A]


import scala.concurrent.Await
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._

val futureEitherOr: FutureEitherOption[Int] =
 for {
  a <- 10.pure[FutureEitherOption]
  b <- 32.pure[FutureEitherOption]
} yield a + b  //OptionT(EitherT(Future(..)))

//Kind Projector compiler plugin 
123.pure[OptionT[EitherT[Future, String, *], *]]
// OptionT(EitherT(Future(Success(Right(Some(123))))))        )

//unpacking - keep on calling value 
futureEitherOr.value //EitherT(Future(Success(Right(Some(42))))
futureEitherOr.value.value //Future(Success(Right(Some(42)))
val res = Await.result(futureEitherOr.value.value, Duration.Inf) //Right(Some(42))
res.map(_.getOrElse(-1)) //Right(42)

The "super stack" approach starts to fail in larger, more heterogeneous code
bases where different stacks make sense in different contexts. 

Another design pattern that makes more sense in these contexts uses monad transformers
as local "glue code". 

We expose untransformed stacks at module boundaries,
transform them to operate on them locally, and untransform them before pass
ing them on. This allows each module of code to make its own decisions about
which transformers to use:

type Logged[A] = Writer[List[String], A]

import scala.util._ 

// Methods generally return untransformed stacks:
def parseNumber(str: String): Logged[Option[Int]] =
 Try(str.toInt).toOption match {
     case Some(num) => Writer(List(s"Read $str"), Some(num))
     case None     => Writer(List(s"Failed on $str"), None)
 }

// Consumers use monad transformers locally to simplify composition:
def addAll(a: String, b: String, c: String): Logged[Option[Int]] = {
 import cats.data._
 val result = for {
     a <- OptionT(parseNumber(a))  //OptionT[Logged,Int] => Logged[Option[Int]] as inside out , so matches with parseNumber returns type 
     b <- OptionT(parseNumber(b))
     c <- OptionT(parseNumber(c))
 } yield a + b + c
 result.value
}


// This approach doesnot force OptionT on other users' code:
val result1 = addAll("1", "2", "3")
// result1: Logged[Option[Int]] = WriterT(
//       (List("Read 1", "Read 2", "Read 3"), Some(6))
// )
val result2 = addAll("1", "a", "3")
// result2: Logged[Option[Int]] = WriterT(
//       (List("Read 1", "Failed on a"), None)
// )

val (logs, res) = result1.run

///Monad Transformer Stack 
//More Combined Stack - State of Reader of Writer of String 

StateT[Id, state, computation]
    Here 
    state = List[String]
    val step = State[state, computation] { oldstate =>
         val newstate = someTransformation(oldstate)
         val result    = someCalculation
         (newstate, result)
     }
    val (state, result) = step.run(initialStep).value


ReaderT[Id, config, ReaderFnreturns]
    Here 
    config = Map[String,String]
    val rs: Reader[config, ReaderFnreturns] =
       Reader{ config => ReaderFnreturns}


WriterT[F[_], Log, V]
    Here 
    Log = Vector[String]

//State of Reader of Writer of String 
//so inside out 
//Alwyas has to be type constructor in first arg, as given as F[_]
//so multiple type declaration is needed 

type StateList[A] = State[List[String],A]  //T 
type ReaderState[A] = ReaderT[StateList,  Map[String,String], A]   //RT
type WriterReaderState[A] = WriterT[ReaderState, Vector[String], A]  
type WriterReaderStateString = WriterReaderState[String]  //WRT
//State[List[String],Reader[ Map[String,String], Writer[Vector[String], String]]]

//pure takes only F[_] type param 
10.pure[StateList]
10.pure[ReaderState] 
10.pure[WriterReaderState]


//Quick revision - State 
10.pure[StateList] //StateList[Int]

val step1 = State[List[String],Int]{ lstString =>    //oldstate
     val ans = "STEP1" :: lstString
     (ans, 10)   //(newState, value)
}

val step2 = State[List[String],Int]{ lstString =>
     val ans = "STEP2" :: lstString
     (ans, 20)
}

val both = for {
     a <- step1 // Get result 
     b <- step2
} yield (a, b)

//Give initial state = List[String]
val (state, result) = both.run(Nil).value
//val state: List[String] = List(STEP2, STEP1)
//val result: (Int, Int) = (10,20)

val steps = List( step1, step2)
val alsteps = steps.foldLeft(10.pure[StateList]){ (state,e) =>
        println(s"1) state=$state e=$e")
        state.flatMap{ va /*value*/=> 
            print(s"2) va=$va")
            e.map{ sv /*value*/ => 
                  println(s" sv=$sv ret=${va+sv}")
                  va + sv
                }
        }
    }
1) r=cats.data.IndexedStateT@3dc19f23 e=cats.data.IndexedStateT@770d46f
1) r=cats.data.IndexedStateT@4953bf2 e=cats.data.IndexedStateT@8540fd0
val alsteps: T[Int] = cats.data.IndexedStateT@632a547d

//Inner prints are not printed 
scala> val (state, result) = alsteps.run(Nil).value
2) va=10 sv=10 ret=20
2) va=20 sv=20 ret=40
val state: List[String] = List(STEP2, STEP1)
val result: Int = 40


//Quick Reader 
ReaderT[F[_], -Confg, Ftype](run: Confg => F[Ftype])
WriterT[F[_], Log, V](run: F[(Log, V)])
StateT[F[_], StateStructure, Result]( run: StateStructure => (StateStructure, Result))


//type StateList[A] = State[List[String],A]
//type ReaderState[A] = ReaderT[StateList,  Map[String,String], A] 

10.pure[ReaderState] //ReaderState[Int]

//ReaderT returns State 
val rs =  ReaderT[StateList, Map[String,String], Int]{ mapSS /*conf*/ =>
        State[List[String],Int]{ lstString /*state*/=> 
             val ans = "STEP1" :: lstString
             (ans, 10)
            }
       }       
    
val value = for {
    value1 <- rs     // Int
    value2 <- rs
} yield s"${value1 * value2}"  //in ReaderT[T, Map[String,String], Int]
//Reader[StateList,Map[String,String],String]

val res8 = value(Map("OK"->"OKVALUE")) //State[List[String],String]
//val res8: StateList[String] = cats.data.IndexedStateT@5739c440

val (state, result) = res8.run(Nil).value 
//val state: List[String] = List(STEP1, STEP1)
//val result: String = 100


//Quick Writer 
ReaderT[F[_], -Confg, Ftype](run: Confg => F[Ftype])
WriterT[F[_], Log, V](run: F[(Log, V)])
StateT[F[_], StateStructure, Result]( run: StateStructure => (StateStructure, Result))

WriterT
    liftF[F[_], L, V](fv: F[V])(implicit monoidL: Monoid[L], F: Applicative[F]): WriterT[F, L, V]
    liftK[F[_], L](implicit monoidL: Monoid[L], F: Applicative[F]): F ~> WriterT[F, L, *]

WriterT[F[_], L, V](run: F[(L, V)])
    mapBoth[M, U](f: (L, V) => (M, U))(implicit functorF: Functor[F]): WriterT[F, M, U] 
    bimap[M, U](f: L => M, g: V => U)(implicit functorF: Functor[F]): WriterT[F, M, U] 
    mapWritten[M](f: L => M)(implicit functorF: Functor[F]): WriterT[F, M, V]
    swap(implicit functorF: Functor[F]): WriterT[F, V, L] 
    reset(implicit monoidL: Monoid[L], functorF: Functor[F]): WriterT[F, L, V] 
    foldLeft[C](c: C)(f: (C, V) => C)(implicit F: Foldable[F]): C
    traverse[G[_], V1](f: V => G[V1])(implicit F: Traverse[F], G: Applicative[G]): G[WriterT[F, L, V1]]
//syntax 
extension (a: A) 
  def tell: Writer[A, Unit] = Writer(a, ())
  def writer[W](w: W): Writer[W, A] = Writer(w, a)  
    
//type StateList[A] = State[List[String],A]
//type ReaderState[A] = ReaderT[StateList,  Map[String,String], A]  
//type WriterReaderState[A] = WriterT[ReaderState, Vector[String], A]
//F[A] of Writer is Reader[Map[String,String], State[List[String],A]]
//Writer is F[(L,V)] so Reader[Map[String,String], State[List[String],(Log, Int)]]


10.pure[WriterReaderState]
// WriterReaderState[Int]

val innerrs =  ReaderT[StateList, Map[String,String], Int]{ mapSS =>
        State[List[String],Int]{ lstString => 
             val ans = "STEP1" :: lstString
             (ans, 10)
            }
       }
       
val ws = WriterT.liftF[ReaderState, Vector[String], Int](innerrs)
//WriterT[ReaderState,Vector[String],Int]

ws.tell(Vector("x", "y", "z"))
//WriterT[ReaderState,Vector[String],Int]

val writer1 = for {
   a <- 10.pure[WriterReaderState]      //a=10
   b <- ws.tell(Vector("x", "y", "z"))  //b=10
 } yield a + b
//cats.data.WriterT[RT,Vector[String],Int]

val wr = writer1.run 
//ReaderState[(Vector[String], Int)]

val rres = wr(Map("OK"->"OKVALUE")) //StateList[(Vector[String], Int)]
val (state, result) = rres.run(Nil).value 
//val state: List[String] = List(STEP1)
//val result: (Vector[String], Int) = (Vector(x, y, z),20)




///Free monads
We represented sequenced computations with monads. 
The flatMap method of the monad describes how the computation steps should
be joined and the function given to it as an argument--the computation step itself. The free
monad elevates the concept of sequenced computations to the next level.

Sometimes, the general outline of a monad may be useful, but no simple pattern recommends 
one monad or another.

This is where a free monad comes in; 
as a free object, https://en.wikipedia.org/wiki/Free_object in the category of monads, 

For example, by working entirely through the Some and None markers, 
the Option monad is in fact a free monad. The List monad, on the other hand, is not a free monad 
since it brings extra, specific facts about lists (like append) into its definition

Other examples from cats are Chain, AndThen, TailRec etc 

Free monads are characterized by ADT  ie sealed trait as CoProduct and case class as Product 
and flatMap and pure implemented entirely with those Products 

sealed trait Option[+A]{
    def get: A
    def isEmpty: Boolean = this eq None
    def pure[A](a: A): Option[A] = Option(a)
    
    def flatMap[B](f: A => Option[B]): Option[B] = if (isEmpty) None else f(this.get)
    def map[B](f: A => B): Option[B] =  if (isEmpty) None else Some(f(this.get))
    def ap[A, B](a: F[A])(ff: F[A => B]): F[B] = flatMap(ff)(f => map(a)(f))
}
object Option {
    def apply[A](x: A): Option[A] = if (x == null) None else Some(x)
}

final case class Some[+A](value: A) extends Option[A] {
  def get: A = value
}
case object None extends Option[Nothing] {
  def get: Nothing = throw new NoSuchElementException("None.get")
}

//Example of Free Monad - Console 
We can build a data structure to describe a console program with just three instructions:

sealed trait Console[+A]
final case class Return[A](value: () => A) extends Console[A]
final case class PrintLine[A](line: String, rest: Console[A]) extends Console[A]
final case class ReadLine[A](rest: String => Console[A]) extends Console[A]

In this model, Console[A] is an immutable, type-safe value, which represents a console program 
that returns a value of type A.

The Console data structure is an ordered tree, and at the very "end" of the program, 
you will find a Return instruction that stores a value of type A, 
which is the return value of the Console[A] program.

val example1: Console[Unit] = 
  PrintLine("Hello, what is your name?",
    ReadLine(name =>
      PrintLine(s"Good to meet you, ${name}", Return(() => ())))
)
//Nested Structure of Console

//OR Using 
def succeed[A](a: => A): Console[A] = Return(() => a)
def printLine(line: String): Console[Unit] =
  PrintLine(line, succeed(()))
val readLine: Console[String] =
  ReadLine(line => succeed(line))
  

implicit class ConsoleSyntax[+A](self: Console[A]) {
  def map[B](f: A => B): Console[B] =
    flatMap(a => succeed(f(a)))

  def flatMap[B](f: A => Console[B]): Console[B] =
    self match {
      case Return(value) => f(value())
      case PrintLine(line, next) =>
        PrintLine(line, next.flatMap(f))
      case ReadLine(next) =>
        ReadLine(line => next(line).flatMap(f))
    }
}
//Then Note that this is a nested structure 
val example2: Console[String] =
  for {
    _    <- printLine("Whats your name?")
    name <- readLine
    _    <- printLine(s"Hello, ${name}, good to meet you!")
  } yield name
//val example2: Console[String] = PrintLine(Whats your name?,ReadLine(lambda,PrintLine(Hello, ${name}, good to meet you!)))

//When we wish to execute this program

def run[A](program: Console[A]): A = program match {
  case Return(value) => 
    value()
  case PrintLine(line, next) => 
    println(line)
    interpret(next)
  case ReadLine(next) =>
    interpret(next(scala.io.StdIn.readLine()))
}

run(example2)


///Free monad with cats 
Use below 
libraryDependencies += "org.typelevel" %% "cats-free" % "2.4.2"

//ref 
class Free[S[_], A] 
    Binding is done using the heap instead of the stack, allowing tail-call elimination.
    S[_] is sealed trait of ADT 
     
    final def map[B](f: A => B): Free[S, B] 
    final def mapK[T[_]](f: S ~> T): Free[T, A] 
    final def flatMap[B](f: A => Free[S, B]): Free[S, B] 
    final def fold[B](r: A => B, s: S[Free[S, A]] => B)(implicit S: Functor[S]): B 
    final def run(implicit S: Comonad[S]): A 
        Run to completion, using the given comonad to extract the resumption.
        Comonad[F[_]] has below    
          def extract[A](x: F[A]): A  
          def coflatMap[A, B](fa: F[A])(f: F[A] => B): F[B]   // from CoflatMap
          def coflatten[A](fa: F[A]): F[F[A]] =  coflatMap(fa)(fa => fa) //from CoflatMap
    def runM[M[_]](f: S[Free[S, A]] => M[Free[S, A]])(implicit S: Functor[S], M: Monad[M]): M[A]  
    def runTailRec(implicit S: Monad[S]): S[A]  
    def foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
    def compile[T[_]](f: FunctionK[S, T]): Free[T, A] = mapK(f)
    def inject[G[_]](implicit ev: InjectK[S, G]): Free[G, A]
        Lift into G (typically a EitherK) given InjectK.

object Free
  def pure[S[_], A](a: A): Free[S, A] = Pure(a)
  def liftF[F[_], A](value: F[A]): Free[F, A] = Suspend(value)
  def liftK[F[_]]: F ~> Free[F, *] =
  def liftId[F[_]]: Id ~> Free[F, *] =
  def roll[F[_], A](value: F[Free[F, A]]): Free[F, A] =
    Absorb a step into the free monad
  def suspend[F[_], A](value: => Free[F, A]): Free[F, A] =
    Suspend the creation of a `Free[F, A]` value.
  def defer[F[_], A](value: => Free[F, A]): Free[F, A] =    pure(()).flatMap(_ => value)
    Defer the creation of a `Free[F, A]` value.
  def mapK[F[_], G[_]](fk: FunctionK[F, G]): FunctionK[Free[F, *], Free[G, *]] =
  def compile[F[_], G[_]](fk: FunctionK[F, G]): FunctionK[Free[F, *], Free[G, *]] =
  def foldMap[F[_], M[_]: Monad](fk: FunctionK[F, M]): FunctionK[Free[F, *], M] =
  def inject[F[_], G[_]]: FreeInjectKPartiallyApplied[F, G]
        One to one function from F[_] to G[_] eg apply(F[A]):Free[G,A] exists 
        class FreeInjectKPartiallyApplied[F[_], G[_]](private val dummy: Boolean = true) extends AnyVal 
            def apply[A](fa: F[A])(implicit I: InjectK[F, G]): Free[G, A] =  Free.liftF(I.inj(fa))


The free monad has advantages
    Gluing the computations together as classes happens in a heap and saves stack  memory.
    
    It is possible to pass the computation over to different parts of the code and the
    side-effects will be deferred until it is explicitly run.    
   
    represent stateful computations as data, and run them

    build an embedded DSL (domain-specific language)
    
    retarget a computation to another interpreter using natural transformations
    (In Cats, the type representing a free monad is abbreviated as Free[_])
    
The disadvantages lie in the same plane as they do for monads. These include additional
initial implementation effort, runtime overhead for the garbage collector, and processing
additional instructions and mental overhead for developers new to the concept.


//Practicalities 
Represent your domain,S:Functor in ADT and the Use Free[S[_], A] to convert those into monadic form. 
  
In terms of implementation(cats), to build a monad from a functor , below types are used 

sealed abstract class Free[F[_], A]
case class Pure[F[_], A](a: A) extends Free[F, A]
case class Suspend[F[_], A](a: F[Free[F, A]]) extends Free[F, A]

In this representation:
    Pure builds a Free instance from an A value (it corresponds to the Monad.pure function)
    Suspend builds a new Free by applying F to a previous Free (it corresponds to the flatMap function)

resulting Free into a  recursive structure
Suspend(F(Suspend(F(Suspend(F(....(Pure(a))))))))

//Steps 
Represent problem into  ADT where S[_] is sealed trait 
and case class Step(inputs...)/object extends S[Output] are Steps 

Use  
Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
to convert S[_] to Known M:Monad eg State/Id/Reader/List/Option etc by using below steps 

    1. Define Free container type eg 'type Type[A] = Free[S,A]' where S[_] is sealed trait 
    2. Define helper for each case class to convert to Free[S,Output]
        Use Free.liftF[S[_], A](value: S[A]): Free[S, A]
    3. Free[S,A] has flatMap, Use 
        Free[S[_], A].flatMap[B](f: A => Free[S, B]): Free[S, B] 
       OR for-comprehension , to define program using Step2 helpers 
       This creates a Nested structure using Pure and Suspend 
    4. Write FunctionK[S, M] /S ~> M with 'def apply(S[A]): M[A]' using respective M[_] methods 
       eg for Id, it is simple type, for State, it is State[state,A] helpers 
       This is required to use with foldMap 
       This step is called interpretor and Many such with different M[_] can be written 
    5. foldMap returns M[A], run this to get A 
        Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
       eg for Id, output is direct simple type,
       for State, use M[A].run(InitialState).value 
    
If there are two ADTs, then we need to compose them using
    type etype[A] = EitherK[FirstADT[_], SecondADT[_], A]
    For FirstADT and SecondADT , write helpers , 
    Then write programs with Free[etype,A] with those helpers 
    and write FirstADT ~> M and SecondADT ~> M 
    Then use below to get etype ~> M 
        FunctionK[FirstADT[_], M[_]].or[SecondADT[_]](h: FunctionK[SecondADT, M]) FunctionK[EitherK[FirstADT, SecondADT, *], M] 
    Use above in Free[etype,A].foldMap 
    
    Note if  implicits of InjectK[FirstADT, F[_]] and 
    InjectK[SecondADT,F[_]] are avilable , then Use 
        Free.inject[FirstADT/SecondADT, F[_]].apply( FirstADT/SecondADT[A]) to get Free[F,A]
    For F[A] = EitherK[FirstADT[_], SecondADT[_], A], implicits of InjectK[FirstADT,*]
    and InjectK[SecondADT,*] are available , So, use implicit arguments and use Free.inject
    to get Free[etype,A] in helpers 
    
    
To compose Free with other M:Monad , Use FreeT[S[_], M[_], A] instead of Free 
    Above steps are same, with below change  
    1. Define FreeT container type eg 'type Type[A] = FreeT[S,M, A]' where S[_] is sealed trait 
       and M[_]: any Monad eg Id, State etc 
    2. Use below to create helpers 
        liftF to lift ADT and liftT to lift Monad 
        FreeT.liftF[S[_], M[_], A](value: S[A])(implicit M: Applicative[M]): FreeT[S, M, A] 
        FreeT.liftT[S[_], M[_], A](value: M[A])(implicit M: Functor[M]): FreeT[S, M, A] 
        FreeT.pure[S[_], M[_], A](value: A)(implicit M: Applicative[M]): FreeT[S, M, A]
    
    Other steps remain same , Only Note foldMap signature is 
        FreeT[S[_], M[_], A].foldMap(f: FunctionK[S, M])(implicit M: Monad[M]): M[A]
    ie M[_] of FreeT[S[_], M[_], *] is used when writing S ~> M 
    means, FreeT can be converted to those M[_] with which FreeT was created     
    
    Note, to convert M[_] to another Monad N[_]
    use program_written_in_M.hoisted by writing M ~> N 
    FreeT[S[_], M[_], A].hoist[N[_]](mn: FunctionK[M, N]): FreeT[S, N, A]
    Now We need to write interpretors from N[_]
    

//Example 
Let imagine that we want to create a DSL for a key-value store. 
    put a value into the store, associated with its key.
    get a value from the store given its key.
    delete a value from the store given its key.

For example:

put("toto", 3)
get("toto") // returns 3
delete("toto")

//STEP1-Create an ADT representing your grammar

sealed trait KVStore[A]

//Note output of any action is part of 'extends KVStore[OUTPUT]'

//Put a value associated with a key into the store
case class Put[T](key: String, value: T) extends KVStore[Unit]

//Get a value associated with a key out of the store
case class Get[T](key: String) extends KVStore[Option[T]]

//Delete a value associated with a key from the store
case class Delete(key: String) extends KVStore[Unit]

//STEP2-Free your ADT - There are five basic steps to 'freeing' the ADT:
    
//STEP2.1. Create a Free type based on your ADT
import cats._ 
import cats.implicits._ 
import cats.data._ 
import cats.free._ 
import cats.free.Free._

//Free[S[_], A]
type KVStoreMonad[A] = Free[KVStore, A]

Use 
    Free.pure[S[_], A](a: A): Free[S, A] 
    Free.liftF[F[_], A](value: F[A]): Free[F, A] 
    Free.foldMap[F[_], M[_]: Monad](fk: FunctionK[F, M]): FunctionK[Free[F, *], M] 
    def inject[F[_], G[_]]: FreeInjectKPartiallyApplied[F, G]
        One to one function from F[_] to G[_] eg apply(F[A]):Free[G,A] exists 
Free[S[_], A] 
    def map[B](f: A => B): Free[S, B] 
    def mapK[T[_]](f: S ~> T): Free[T, A] 
    def flatMap[B](f: A => Free[S, B]): Free[S, B]     
    def runM[M[_]](f: S[Free[S, A]] => M[Free[S, A]])(implicit S: Functor[S], M: Monad[M]): M[A]  
    def runTailRec(implicit S: Monad[S]): S[A]  
    def foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 


//STEP2.2.Create smart constructors using liftF for convenience

// Put returns nothing (i.e. Unit).
def put[T](key: String, value: T): KVStoreMonad[Unit] =
  liftF[KVStore, Unit](Put[T](key, value))

// Get returns a T value.
def get[T](key: String): KVStoreMonad[Option[T]] =
  liftF[KVStore, Option[T]](Get[T](key))

// Delete returns nothing (i.e. Unit).
def delete(key: String): KVStoreMonad[Unit] =
  liftF(Delete(key))

// Derived, helper Update composes get and set, and returns nothing.
def update[T](key: String, f: T => T): KVStoreMonad[Unit] =
  for {
    vMaybe <- get[T](key) //unwrap KVStoreMonad and get Option[T]
    _ <- vMaybe.map(v => put[T](key, f(v))).getOrElse(Free.pure(()))
  } yield ()

//STEP2.3.Build a application out of key-value DSL operations.

def program: KVStoreMonad[Option[Int]] =
  for {
    _ <- put("wild-cats", 2)
    _ <- update[Int]("wild-cats", (_ + 12))
    _ <- put("tame-cats", 5)
    n <- get[Int]("wild-cats")
    _ <- delete("tame-cats")
  } yield n

//STEP2.4. Write a compiler for your program, ie transformation from S ie KVStoreMonad[_]  to M[_]
//or FunctionK[KVStoreMonad,M] or KVStoreMonad ~ M , Note M should be Monad, eg Id, State etc 

//Implementation-1:  Use M[_] as Id which is simple type 
we could easily use other type containers for different behavior, such as:
    Future[_] for asynchronous computation
    List[_] for gathering multiple results
    Option[_] to support optional results
    Either[E, *] to support failure
    
//we will use a simple mutable map to represent our key value store:

import cats.arrow.FunctionK
import cats.{Id, ~>}
import scala.collection.mutable

// the program will crash if a key is not found,
// or if a type is incorrectly specified.
def impureCompiler: KVStore ~> Id  =
  new (KVStore ~> Id) {  // KVStore[A] => Id[A]
    val kvs = mutable.Map.empty[String, Any]
    def apply[A](fa: KVStore[A]): Id[A] =
      fa match {
        case Put(key, value) =>
          println(s"put($key, $value)")
          kvs(key) = value
          ()
        case Get(key) =>
          println(s"get($key)")
          kvs.get(key).map(_.asInstanceOf[A])
        case Delete(key) =>
          println(s"delete($key)")
          kvs.remove(key)
          ()
      }
  }

//STEP2.5. Run your program
//Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
//In our case M = Id and S=KVStore

val result: Option[Int] = program.foldMap(impureCompiler)
// put(wild-cats, 2)
// get(wild-cats)
// put(wild-cats, 14)
// put(tame-cats, 5)
// get(wild-cats)
// delete(tame-cats)
// result: Option[Int] = Some(14)


//STEP2.6. Use a pure compiler (Using another compiler eg State whch is also Monad) 
class State[S,A] (val runEval: Eval[S => Eval[(S, A)]])
  def run(initial: S): Eval[(S, A)] 
  def flatMap[B](fas: A => State[S,B]): State[S,B] 
  def map[B](f: A => B): State[S, B] 
  def transform[B](f: (S, A) => (S, B)): State[S,B] =
  def transformS[R](f: R => S, g: (R, S) => R): State[R, A] =
  def modify[C](f: S => C): State[C,A] =
     Modify the state (`S`) component.
  def inspect[B](f: S => B): State[S, B] =
    Inspect a value from the input state, without modifying the state.
  def get: State[S,S] =
    Get the input state, without modifying the state.
object State 
  def apply[S, A](f: S => (S, A)): State[S, A] 
  def pure[S, A](a: A): State[S, A] 
  def empty[S, A](implicit A: Monoid[A]): State[S, A] 
  def modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
    Modify the input state and return Unit.
  def inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
    Inspect a value from the input state, without modifying the state.
  def get[S]: State[S, S] = inspect(identity)
    Return the input state without modifying it.
  def set[S](s: S): State[S, Unit] = State(_ => (s, ()))
    Set the state to `s` and return Unit.
    
    
type KVStoreState[A] = State[Map[String, Any], A]

val pureCompiler: KVStore ~> KVStoreState = new (KVStore ~> KVStoreState) {
  def apply[A](fa: KVStore[A]): KVStoreState[A] =
    fa match {
      case Put(key, value) => State.modify(map => map.updated(key, value))  //Use Map Method 
      case Get(key) => State.inspect(map => map.get(key).map(_.asInstanceOf[A]))
      case Delete(key) => State.modify(map => map - key)
    }
}
//run to run the State 
val result: (Map[String, Any], Option[Int]) = program.foldMap(pureCompiler).run(Map.empty).value
// result: (Map[String, Any], Option[Int]) = (Map("wild-cats" -> 14), Some(14))



////-----------------An Introduction to the Akka and Actor Models------------------------------------------------------------------------------------------
11.   An Introduction to the Akka and Actor Models
·       An Introduction to the Akka and Actor Models
·       Introduction to the actor model
·       Akka basics
·       Advanced topics
·       Testing actors
·       Running the application

//sbt info 
val AkkaVersion = "2.6.13"
libraryDependencies ++= Seq(
  "com.typesafe.akka" %% "akka-actor" % AkkaVersion,
  "com.typesafe.akka" %% "akka-testkit" % AkkaVersion % Test
  "com.typesafe.akka" %% "akka-slf4j" %  AkkaVersion
  "org.slf4j" % "slf4j-simple" % "1.7.30"
  "log4j" % "log4j" % "1.2.14"
)

///Actor Props - for passing Actor constructor argument 
import akka.actor.Props

import akka.actor._

class MyActor(magicNumber: Int) extends Actor with ActorLogging {
  import MyActor._
  //def receive: PartialFunction[Any, Unit]
  //Accept Any 
  //In Typed Actor, accept type is a Particular Type, so it can not accept any other type 
  def receive = {
    case Greeting(greeter) => 
            log.info(s"$magicNumber: I was greeted by $greeter.")
            sender() ! "Greeted"
    case Goodbye           => 
            log.info(s"$magicNumber: Someone said goodbye to me.")
            context.stop(self)
  }
}
//RECOMENDED Practice, put props in companion object with below pattern , can be used inside or outside Actor
object MyActor {
   def props(magicNumber: Int): Props = Props(new MyActor(magicNumber))
   case class Greeting(from: String)
   case object Goodbye
}

//when no constructor arg 
val props1 = Props[MyActor]()  //ERROR???
val props7 = Props(new MyActor) //NOT RECOMMENDED within another actor
//OR 
val props3 = Props(classOf[ActorWithArgs], "arg", "arg2") // RECO , but not for value class arguments( class extends AnyVal)
val props2 = Props(new ActorWithArgs("arg")) //for all type ctor args , but NOT RECOMMENDED within another actor

Props Methods 
    def withActorTags(tags: Set[String]): Props
        Scala API: Returns a new Props with the specified set of tags.
    def withDeploy(d: Deploy): Props
        Returns a new Props with the specified deployment configuration.
    def withDispatcher(d: String): Props
        Returns a new Props with the specified dispatcher set.
    def withMailbox(m: String): Props
        Returns a new Props with the specified mailbox set.
    def withRouter(r: RouterConfig): Props
        Returns a new Props with the specified router config set.

///Actor creation 
//both context(inside actor) and system(ActorSystem) have below methods 
def actorOf(props: Props, name: String): ActorRef
    Create new actor as child of this context with the given name, 
    which must not be null, empty or start with '$'.
def actorOf(props: Props): ActorRef
    Create new actor as child of this context and give it an automatically  generated name 
    (currently similar to base64-encoded integer count, reversed and with $ prepended, may change in the future).

//Example of creation 
import akka.actor.{ActorSystem, Props}

// ActorSystem is a heavy object: create only one per application
val system = ActorSystem("Dummy") //akka://Dummy
val resOne = system.actorOf(MyActor.props(42), "name") //name should unique 
//Actor[akka://Dummy/user/name#115048092]

//OR 
val resTwo =system.actorOf(MyActor.props(42))
//val res2: akka.actor.ActorRef = Actor[akka://Dummy/user/$a#2024249730]

//via context inside an Actor 
context.actorOf(MyActor.props(42), "name")
context.actorOf(MyActor.props(42))

//These are the rules for message sends by default 
//to change check Persistence
at-most-once delivery, i.e. no guaranteed delivery, 
    that message is delivered zero or one time
    For a given pair of actors, messages sent directly from the first to the second 
    will not be received out-of-order.


//Message sending 
! , tell
    send a message, 
    Note any message can be sent, eg, Int, String, any user defined Class/object(must be immutable and Serializable)
?,ask 
    Sends a message and wait for result in future
    
resOne ! MyActor.Greeting("Das")  //Response goes to Deadletter 
resTwo ! MyActor.Greeting("Das")
    
//Stopping 
resOne ! PoisonPill
resTwo ! PoisonPill

import system.dispatcher //brings ExecutionContext
system.terminate().foreach( _ => "Terminated")

///Testing 
https://doc.akka.io/docs/akka/current/testing.html

The TestKit contains an actor named testActor which is the entry point for messages 
to be examined with the various expectMsg... assertions . 
When mixing in the trait ImplicitSender this test actor is implicitly used 
as sender reference when dispatching messages from the test procedure. 


import akka.actor._
import akka.testkit._
import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers
import org.scalatest.wordspec.AnyWordSpecLike

class MySpec()
    extends TestKit(ActorSystem("Dummy"))
    with ImplicitSender //TestKit.testActor is sender 
    with AnyWordSpecLike //BDD like template 
    with Matchers
    with BeforeAndAfterAll //must be last trait
    {
  
  var actor:ActorRef =   _
  var probe: TestProbe = _

  override def beforeAll() : Unit = {
    actor = system.actorOf(MyActor.props(42)) 
    probe = TestProbe()    
    probe.watch(actor)
  }
  
  override def afterAll(): Unit = {
    TestKit.shutdownActorSystem(system)
  }

  "My First Actor" must {

    "send back Greeted" in {
      actor ! MyActor.Greeting("Das")
      expectMsg("Greeted")
    }
    
    "stop" in {
      import scala.concurrent.duration._
      actor ! MyActor.Goodbye
      probe.expectTerminated(actor)
    }
  }
}
scala> org.scalatest.run(new MySpec())
//In sbt , this must be in src/test/scala folder 
$ sbt test 
//https://www.scalatest.org/user_guide/using_scalatest_with_sbt


///Important testkit method   
import scala.concurrent.duration._

val hello: String = expectMsg("hello")
val any: String = expectMsgAnyOf("hello", "world")
val all: immutable.Seq[String] = expectMsgAllOf("hello", "world")
val i: Int = expectMsgType[Int]
expectNoMessage(200.millis)
val two: immutable.Seq[AnyRef] = receiveN(2)
expectMsg(500.millis, "hello")

///Important attributes of Actor 
1.The Actor own akka.actor.ActorRef is available as self, 
2.the current message sender as sender() 
3.the akka.actor.ActorContext as context. 
4.abstract method ,receive returns the initial behavior of the actor as a partial function 
 (behavior can be changed using context.become and context.unbecome).

The Akka Actor receive message loop is exhaustive Otherwise an 
akka.actor.UnhandledMessage(message, sender, recipient) 
will be published to the ActorSystem EventStream.

///An actor has a well-defined (non-cyclic) life-cycle.
1.RUNNING (created and started actor) - can receive messages
2.SHUTDOWN (when 'stop' is invoked) - canot do anything

///Helper Functions 
import akka.actor._
import scala.util._

object ActorHelper{
    import scala.concurrent._
    import scala.concurrent.duration._
    
    def process(system: ActorSystem)(createActors: ActorSystem=>Seq[ActorRef])
            (stopActors:(ActorSystem, Seq[ActorRef])=>Unit)
            (body: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        val actors = createActors(system)
        println(s"Created: ${actors.map(_.toString).mkString("(",",",")")}")
      
        import system.dispatcher //brings ExecutionContext 
        body(system, actors).andThen{
            case x => 
                println(s"Stopping, body returned $x")
                stopActors(system,actors)
                x
          }
    }   
    def processSeq( system: ActorSystem, propNames:Seq[(String, Props)], stopMessage:Iterator[Any] =Iterator.continually(PoisonPill) )(sendfn: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        process(system){system => 
            propNames.map{case (n,p) => system.actorOf(p, n)}
          }{ (system, seq) =>
            seq.zip(stopMessage).foreach{ case(a, m) => a ! m} 
          }{(system, seq) => 
            sendfn(system, seq)
        }
    }    
    
    def processOne( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system)
               (system => Seq(system.actorOf(props, "name")))
               ( (system, seq) =>seq.head ! stopMessage ){
            (system, seq) => sendfn(system, seq.head)
        }
    }    
    def processWithTestProb(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef, ActorRef) => Future[Any] ):Future[Any]  = {
      processSeq(system, Seq(("name", props)/*actor*/, ("testprob", Props(new TestProb))/*sender*/), 
        Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor, sender) = seqs 
            sendfn(system, actor, sender)/*Future*/.transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                    sender ! PoisonPill
                })
            }
        }
    }
    def processWithoutStop(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        processSeq(system, Seq(("name", props)), Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor) = seqs 
            sendfn(system, actor).transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                })
            }
        }
    }
    
    def processName( system: ActorSystem, props:Props, actorName: String, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system)(system => Seq(system.actorOf(props, actorName)))( (system, seq) =>seq.head ! stopMessage ){
            (system, seq) => sendfn(system, seq.head)
        }
    }

    
    def findActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds):Future[ActorRef] =     
        system.actorSelection(prefix+name).resolveOne(duration)
        
    def stopActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds, stopMessage:Any=PoisonPill)={
        import system.dispatcher //brings ExecutionContext 
        findActor(system, name, prefix, duration).onComplete{
            case util.Success(ref) => 
                println(s"$ref")
                ref ! stopMessage
            case _ =>
        }
    }
    
    trait ActorStop { thisActor : Actor =>
        import ActorStop._ 
        
        def receiveSTOP: Actor.Receive = {    
           case STOP =>
              context.children.foreach { ch =>
                ch ! PoisonPill
              }
              self ! PoisonPill 
              
           case IMMSTOP =>
                 context.children.foreach { ch =>
                    context.stop(ch)
                }
              context.stop(self)
           case FAKESTOP =>
                 
        }
    }
    object ActorStop{
        sealed trait STOPMARKER
        case object STOP extends STOPMARKER
        case object IMMSTOP extends STOPMARKER
        case object FAKESTOP extends STOPMARKER
    }
    
    class TestProb extends Actor with ActorLogging {
        def receive: Receive = {    
               case msg => log.info(s"${self.path.name} - New msg received: $msg")      
            }
    }
    object TestProb{
        def props:Props = Props(new TestProb)
    }
}



///ActorRef and  sender()
//ActorRefs can be freely shared among actors by message passing. 
//Message passing conversely is their only purpose

//example 
import akka.actor._

class ExampleActor extends Actor with ActorLogging with ActorHelper.ActorStop {
  val other = context.actorOf(MyActor.props(32), "childName") // will be destroyed and re-created upon restart by default
  log.info(s"$self created $other")
  
  import ExampleActor._    
  
  def receiveAll:Actor.Receive = {
    case Request1(msg) => other ! MyActor.Greeting1(msg)                // uses this actor as sender reference, reply comes here 
    case Request2(msg) => other.tell(MyActor.Greeting2(msg), sender())  // forward sender reference, in other sender() would be this actor sender()
    case Request3(msg) =>
      import akka.pattern.{ask, pipe}
      import scala.concurrent.duration._
      val fut = other.ask(MyActor.Greeting3(msg))(5.seconds)
      import context.dispatcher
      pipe(fut) to sender()
      // the ask call will get a future from other's reply
      // when the future is complete, send its value to the original sender      
  }
  override def receive:Actor.Receive = receiveAll.orElse(receiveSTOP)
}
object ExampleActor {
   def props: Props = Props(new ExampleActor)
   case class Request1(msg: String)
   case class Request2(msg: String)
   case class Request3(msg: String)
}

class MyActor(magicNumber: Int) extends Actor with ActorLogging {
  import MyActor._
  def receive = {
    case Greeting1(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.1")
        sender() !  ExampleActor.Request2(greeter)
    case Greeting2(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.2")
        //Here sender() is not ExampleActor, but MyActor because of other.tell(..)
        sender() !  MyActor.Goodbye
    case Greeting3(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.3")
        sender() !  "Completed"
    case Goodbye  => log.info(s"$magicNumber: Someone said goodbye to me.")
  }
}
object MyActor {
   def props(magicNumber: Int): Props = Props(new MyActor(magicNumber))
   case class Greeting1(from: String)
   case class Greeting2(from: String)
   case class Greeting3(from: String)
   case object Goodbye
}
//Using REPL 
val system = ActorSystem("Dummy") //akka://Dummy
val resOne = system.actorOf(ExampleActor.props, "name") //name should unique 
resOne ! ExampleActor.Request1("Das") 
32: I was greeted by Das.1
32: I was greeted by Das.2
32: Someone said goodbye to me.

import scala.concurrent.duration._
import akka.pattern.ask
val future = resOne.ask(ExampleActor.Request3("Das"))(5.seconds).mapTo[String] //Future[String]

import system.dispatcher //brings ExecutionContext
future.foreach(println) //Completed
resOne ! PoisonPill
system.terminate().foreach( _ => "Terminated")


//Using ActorHelper 
val system = ActorSystem("Dummy")
import system.dispatcher
ActorHelper.processOne(system, ExampleActor.props, ActorHelper.ActorStop.STOP){ (system, actor) =>
    import akka.pattern._ 
    import scala.concurrent.duration._
    import system.dispatcher //brings ExecutionContext  
    actor ! ExampleActor.Request1("Das")     
    val future = actor.ask(ExampleActor.Request3("Das"))(5.seconds).mapTo[String] //Future[String]
    future
}.foreach(println)
//output 
Created: Actor[akka://Dummy/user/name#-2078609943]
Actor[akka://Dummy/user/name#-2078609943] created Actor[akka://Dummy/user/name/childName#-145826343]
32: I was greeted by Das.1
32: I was greeted by Das.3
32: I was greeted by Das.2
32: Someone said goodbye to me.
Completed

system.terminate().foreach( _ => "Terminated")


///Dispatchers (ExecutionContext)
Dispatchers are the machinery that makes actors work. They are responsible for assigning
CPU to the actors, managing actor mailboxes, and passing over messages from the
mailbox to an actor. There are four commonly used types of dispatchers:

    Default dispatcher: This dispatcher creates one mailbox per actor and may be
    shared by any number of actors. 
    It uses java.util.concurrent.ExecutorService for this process. It is designed to
    be used in combination with actors having a nonblocking code. The dispatcher
    selects an idle thread and assigns it to an actor of its choice. The actor then
    processes a certain number of messages before releasing the thread.

    Balanced dispatcher: This dispatcher creates a single mailbox that can be shared
    by multiple actors of the same kind. Messages from the mailbox are distributed
    among actors sharing the dispatcher.

    Pinned dispatcher: This dispatcher uses a thread pool with a single thread. This
    thread is assigned to a single actor. Thus, each actor has its own thread and
    mailbox, and can perform blocking or long-running activities without starving
    other actors.

    CallingThread dispatcher: This dispatcher assigns one thread per actor. This is
    mainly used for testing.

In our case, the BlockActor has a blocking call in its implementation. So update 
//src/main/resources/application.conf
blockactor-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}
//code 
import akka.actor._ 
object BlockActor {
  final case class Request(x: Int, y: Int)
  def props: Props = Props(new BlockActor).withDispatcher("blockactor-dispatcher")
}

class BlockActor extends Actor with ActorLogging{
  override def receive: Receive = {
    case BlockActor.Request(x,y) =>
      Thread.sleep(3000)
      sender() ! "Done"
      log.info("Done")
  }
}

//Usage 
val system = ActorSystem("Dummy")
import system.dispatcher

//process( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, BlockActor.props){ (system, actor) =>
    import akka.pattern._ 
    import scala.concurrent.duration._
    import system.dispatcher //brings ExecutionContext       
    actor.ask(BlockActor.Request(2,2))(50.seconds) 
}.foreach(println)

system.terminate()

//Details 
All MessageDispatcher implementations are also an ExecutionContext, 
which means that they can be used to execute arbitrary code, for instance Futures.

By default this is a "fork-join-executor", 
Other type of dispatchers - https://doc.akka.io/docs/akka/current/dispatchers.html?language=scala

Dispatchers implement the ExecutionContext interface and can thus be used to run Future invocations etc
for use with Futures, Scheduler, etc.

import system.dispatcher // The ExecutionContext that will be used
//or a particular dispatcher 
implicit val executionContext = system.dispatchers.lookup("my-thread-pool-dispatcher")

//example that uses the "thread-pool-executor"
//application.conf 
my-thread-pool-dispatcher {
  # Dispatcher is the name of the event-based dispatcher
  type = Dispatcher
  # What kind of ExecutionService to use
  executor = "thread-pool-executor"
  # Configuration for the thread pool
  thread-pool-executor {
    # minimum number of threads to cap factor-based core number to
    core-pool-size-min = 2
    # No of core threads ... ceil(available processors * factor)
    core-pool-size-factor = 2.0
    # maximum number of threads to cap factor-based number to
    core-pool-size-max = 10
  }
  # Throughput defines the maximum number of messages to be
  # processed per actor before the thread jumps to the next actor.
  # Set to 1 for as fair as possible.
  throughput = 100
}

//Use it as in , for name "myactor" as given in Props
//application.conf
akka.actor.deployment {
  /myactor {
    dispatcher = my-thread-pool-dispatcher
  }
}

//OR An alternative to the deployment configuration is to define the dispatcher in code. 
import akka.actor.Props
val myActor = context.actorOf(Props[MyActor].withDispatcher("my-thread-pool-dispatcher"), "myactor")




///Actor - supervisorStrategy and LifeCycle 
case class  AllForOneStrategy(maxNrOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf, loggingEnabled: Boolean = true)(decider: Decider) extends SupervisorStrategy with Product with Serializable  
    Applies the fault handling Directive (Resume, Restart, Stop) specified in the Decider 
    to all children when one fails, as opposed to akka.actor.OneForOneStrategy 
    that applies it only to the child actor that failed. 
    maxNrOfRetries
        the number of times a child actor is allowed to be restarted, negative value means no limit, if the limit is exceeded the child actor is stopped
    withinTimeRange
        duration of the time window for maxNrOfRetries, Duration.Inf means no window
    loggingEnabled
        the strategy logs the failure if this is enabled (true), by default it is enabled
    decider
        mapping from Throwable to akka.actor.SupervisorStrategy.Directive, 
        you can also use a scala.collection.immutable.Seq of Throwables 
        which maps the given Throwables to restarts, otherwise escalates.


case class  OneForOneStrategy(maxNrOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf, loggingEnabled: Boolean = true)(decider: Decider) extends SupervisorStrategy with Product with Serializable  
    Applies the fault handling Directive (Resume, Restart, Stop) specified 
    in the Decider to the child actor that failed, 
    as opposed to akka.actor.AllForOneStrategy that applies it to all children. 
    maxNrOfRetries
        the number of times a child actor is allowed to be restarted, negative value means no limit, if the limit is exceeded the child actor is stopped
    withinTimeRange
        duration of the time window for maxNrOfRetries, Duration.Inf means no window
    loggingEnabled
        the strategy logs the failure if this is enabled (true), by default it is enabled
    decider
        mapping from Throwable to akka.actor.SupervisorStrategy.Directive, 
        you can also use a scala.collection.immutable.Seq of Throwables 
        which maps the given Throwables to restarts, otherwise escalates.

class  ClusterMetricsStrategy extends OneForOneStrategy  
    Default ClusterMetricsSupervisor strategy: 
    A configurable akka.actor.OneForOneStrategy with restart-on-throwable decider. 

Directives 
    Resume the subordinate, keeping its accumulated internal state
    Restart the subordinate, clearing out its accumulated internal state
    Stop the subordinate permanently
    Escalate the failure, thereby failing itself
    
    It is important to always view an actor as part of a supervision hierarchy, 
    which explains the existence of the fourth choice 
    (as a supervisor also is subordinate to another supervisor higher up) 
    and has implications on the first three: 
        resuming an actor resumes all its subordinates, 
        restarting an actor entails restarting all its subordinates 
        terminating an actor will also terminate all its subordinates. 
    It should be noted that the default behavior of the preRestart hook of the Actor class 
    is to terminate all its children before restarting, 
    but this hook can be overridden; 
    the recursive restart applies to all children left after this hook has been executed.

  
//one-for-one strategy, meaning that each child is treated separately 
//all-for-one strategy works very similarly, the only difference is that any decision 
//is applied to all children of the supervisor, not only the failing one

//There are limits set on the restart frequency, namely maximum 10 restarts per minute; 
//The child actor is stopped if the limit is exceeded.

//The match statement is of type Decider, which is a PartialFunction[Throwable, Directive]

//Escalate is used if the defined strategy doesn't cover the exception that was thrown.
//the following exceptions are handled by default:
ActorInitializationException    will stop the failing child actor
ActorKilledException            will stop the failing child actor
Exception                       will restart the failing child actor
Other types of Throwable        will be escalated to parent actor

//If the exception escalate all the way up to the root guardian 
//it will handle it in the same way as the default strategy defined above.

//You can combine your own strategy with the default strategy:
import akka.actor.OneForOneStrategy
import akka.actor.SupervisorStrategy._
import scala.concurrent.duration._
 
override val supervisorStrategy =  OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 1.minute) {
    case _: ArithmeticException => Resume
    case t =>
      super.supervisorStrategy.decider.applyOrElse(t, (_: Any) => Escalate)
  }

//You can mute the default logging of a SupervisorStrategy 
//by setting loggingEnabled to false when instantiating it. 

class ExampleActor(ns:Int) extends Actor with ActorHelper.ActorStop{
  import akka.actor.SupervisorStrategy._

  override val supervisorStrategy = OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 30.seconds) {
    case _: ArithmeticException      => Resume
    case _: NullPointerException     => Restart
    case _: IllegalArgumentException => Stop
    case _: Exception                => Escalate
  }
  
  val refs = (0 until ns).toList.foreach{ i =>
    context.actorOf(BadActor.props(i)) //Nothing Bad about it, only it raises exception 
  }
  
  def receive = receiveSTOP
}

//Each timer has a key and can be replaced or cancelled. 
//It’s guaranteed that a message from the previous incarnation of the timer with the same key is not received, 

class TimerScheduler extends AnyRef        
    def cancel(key: Any): Unit
        Cancel a timer with a given key.
    def cancelAll(): Unit
        Cancel all timers.
    def isTimerActive(key: Any): Boolean
        Check if a timer with a given key is active.
        
//The timers are bound to the lifecycle of the actor that owns it, 
//and thus are cancelled automatically when it is restarted or stopped. 
//Note that the TimerScheduler is not thread-safe, 
//i.e. it must only be used within the actor that owns it.  

object BadActor {
  private case object TickKey
  private case object FirstTick
  private case object Tick
  def props(id:Int):Props = Props(new BadActor(id))
}

class BadActor(val id:Int) extends Actor with Timers with ActorLogging{
    import BadActor._
    import scala.util.Random 
    import scala.util.chaining._

    val r = new Random
    val name = s"MyActor($id)"
    println(s"$name: entered the constructor")
      
    val excol = Seq(new ArithmeticException(s"$name"), new NullPointerException(s"$name"), 
        new IllegalArgumentException(s"$name"), new Exception(s"$name"))
  
    timers.startSingleTimer(TickKey, FirstTick, 1.seconds)

    def receive = {
        case FirstTick =>
          // initalization of timer is done here 
          timers.startTimerWithFixedDelay(TickKey, Tick, 10.seconds) //first arg is Timer Key for cancellation 
        case Tick =>
            if (r.nextInt(10) > 5) 
                log.info(s"$name: Pass")
            else {
                r.shuffle(excol).head.tap{s =>
                log.info(s"$name: $s ")}.pipe(s => throw s)
            }
    }

 
    override def preStart()= { 
       //Called right after the actor is started. 
       //During restarts it is called by the default implementation of postRestart. 
       println(s"$name: preStart")  
    }
    
    override def postStop()= { 
       //Called after an actor is stopped, 
       //it can be used to perform any needed cleanup work. 
       println(s"$name: postStop") 
       
    }
    override def preRestart(reason: Throwable, message: Option[Any])={
      //when an actor is restarted, the old actor is informed with this 
      println(s"$name: preRestart reason=${reason.getMessage} message=$message")
      super.preRestart(reason, message)
    }
    override def postRestart(reason: Throwable) ={
      //The postRestart method of the new actor is invoked with the exception 
      // that caused the restart. 
      println(s"$name: postRestart reason=${reason.getMessage}")
      super.postRestart(reason)
    }
}
//Usage 
val system = ActorSystem("testSystem")
import system.dispatcher

//process( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, Props(new ExampleActor(1)), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext       
    Future.successful("Completed")
}.foreach(println)
//Kill actor by ActorHelper 
system.actorSelection("/user/name").resolveOne(5.seconds).onComplete{
    case util.Success(ref) => 
        println(s"$ref")
        ref ! PoisonPill
    case _ => ActorHelper.ActorStop.STOP
}

system.terminate 


///Understanding the Methods in the Akka Actor Lifecycle
//Method                Description
constructor           
    An actor constructor is called just like any other Scala class constructor, 
    when an instance of the class is first created.         
preStart              
    Called right after the actor is started. 
    During restarts it is called by the default implementation of postRestart.
postStop              
    Called after an actor is stopped, it can be used to perform any needed cleanup work. 
preRestart(reason: Throwable, message: Option[Any])            
    when an actor is restarted, the old actor is informed of the process 
    when preRestart is called with the exception that caused the restart, 
    and the message that triggered the exception. 
    The message may be None if the restart was not caused by processing a message.
postRestart(reason: Throwable)           
    The postRestart method of the new actor is invoked with the exception 
    that caused the restart. 
    In the default implementation, the preStart method is called.

    
    
//The postStop hook is invoked after an actor is fully stopped. 
//This enables cleaning up of resources
override def postStop() {
  // clean up some resources ...
}

//Initialization via preStart
//The method preStart() of an actor is only called once directly during the initialization of the first instance
//In the case of restarts, preStart() is called from postRestart()

//One useful usage of this pattern is to disable creation of new ActorRefs 
//for children during restarts.
override def preStart(): Unit = {
  // Initialize children here
}
//and then  Overriding postRestart to disable the call to preStart() after restarts
override def postRestart(reason: Throwable): Unit = ()
 
 
// The default implementation of preRestart() stops all the children of the actor. 
//To opt-out from stopping the children
override def preRestart(reason: Throwable, message: Option[Any]): Unit = {
  // Keep the call to postStop(), but no stopping of children
  postStop()
}



///Actor - Scheduler - Schedule a code 

//The scheduler will throw an exception if attempts are made to schedule too far into the future 
//(which by default is around 8 months (Int.MaxValue seconds)

def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and frequency.
def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    Schedules a Runnable to be run repeatedly with an initial delay and a frequency.
def scheduleOnce(delay: FiniteDuration)(f: => Unit)(implicit executor: ExecutionContext): Cancellable
    Schedules a function to be run once with a delay, i.e.
def scheduleOnce(delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent once with a delay, i.e.
def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and a fixed delay between messages.
def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    Schedules a Runnable to be run repeatedly with an initial delay and a fixed delay between subsequent executions.
    

//trait Cancellable
def cancel(): Boolean
    Cancels this Cancellable and returns true if that was successful.
def isCancelled: Boolean
    Returns true if and only if this Cancellable has been successfully cancelled

//code 
import akka.actor._
import scala.concurrent.duration._

implicit val system = ....

class TestActor extends Actor {

}

testActor = system.actorOf(Props[TestActor])

//Schedule to send the “foo”-message to the testActor after 50ms:
//Use the system's dispatcher as ExecutionContext
import system.dispatcher

//Schedules to send the "foo"-message to the testActor after 50ms
system.scheduler.scheduleOnce(50 milliseconds, testActor, "foo")

//Schedules a function to be executed (send a message to the testActor) after 50ms
system.scheduler.scheduleOnce(50 milliseconds) {
  testActor ! System.currentTimeMillis
}

//Schedule to send the “Tick”-message to the tickActor after 0ms repeating every 50ms:

val Tick = "tick"
class TickActor extends Actor {
  def receive = {
    case Tick => //Do something
  }
}
val tickActor = system.actorOf(Props(classOf[TickActor], this))


//This will schedule to send the Tick-message
//to the tickActor after 0ms repeating every 50ms
val cancellable = system.scheduler.schedule(
    0 milliseconds,
    50 milliseconds,
    tickActor,
    Tick)

//This cancels further Ticks to be sent
cancellable.cancel()

//Usage 
import akka.actor._

val system = ActorSystem("testSystem")
import system.dispatcher

val fut = ActorHelper.processOne(system, Props(new ActorHelper.TestProb), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    
    val run:Runnable = () => actor ! "5TICK"
    val id1 = system.scheduler.scheduleAtFixedRate(1.seconds, 5.seconds)(run)
    //OR 
    val id2 = system.scheduler.scheduleWithFixedDelay(1.seconds, 2.seconds, actor,"2TICK")
    Future.successful(() => { 
        id1.cancel()
        id2.cancel()
        })
}
fut.foreach{ lambda => lambda.asInstanceOf[Function0[Any]]()}

//Check 
ActorHelper.stopActor(system, "name")





///Actor - Switching Between Different States with become
//context.become and context.unbecome
def  become(behavior: Receive, discardOld: Boolean): Unit 
    Changes the Actor behavior to become the new 'Receive' (PartialFunction[Any, Unit]) 
    handler. This method acts upon the behavior stack as follows:
        if discardOld = true it will replace the top element (i.e.default), 
            no need for unbecome(), This is default 
        if discardOld = false it will keep the current behavior and push the given one atop, 
            must issue unbecome()
def unbecome(): Unit
    Reverts the Actor behavior to the previous one on the behavior stack.


//Example 
import akka.actor._
object OneActor{
    case object GoToSecondState
    case object TryToFindSolution
    case object GoToOneState
    def props = Props(new OneActor)
}
class OneActor extends Actor with ActorLogging{
  import context._
  import OneActor._ 
  
	def oneState: Receive = {
	  case GoToSecondState =>
		   println("Moving to two State")
		   become(twoState)
	}

	def twoState: Receive = {
	  case TryToFindSolution =>
		   println("remaining in two State")
	  case GoToOneState =>
		   println("Moving to one state")
		   become(oneState)
	}

	def receive = {
	  case GoToOneState => become(oneState)
	  case GoToSecondState => become(twoState)
	}
}



val system = ActorSystem("testSystem")
import system.dispatcher

ActorHelper.processOne(system, OneActor.props){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    import OneActor._ 
    
    actor ! GoToOneState // init to normalState
    actor ! GoToSecondState
    actor ! TryToFindSolution
    Thread.sleep(1000)
    actor ! GoToOneState
    Future.successful("OK")
}.foreach(println)

//Check 
ActorHelper.findActor(system, "name")

system.terminate()


///If an exception is thrown while a message is being processed 
//(i.e. taken out of its mailbox and handed over to the current behavior), 
//then this message will be lost

//If an exception is thrown while a message is being processed, nothing happens to the mailbox. 
//If the actor is restarted, the same mailbox will be there. 
//So all messages on that mailbox will be there as well.

//If code within an actor throws an exception, 
//that actor is suspended and the supervision process is started 
//Depending on the supervisor’s decision the actor is resumed (as if nothing happened), 
//restarted (wiping out its internal state and starting from scratch) or terminated.



///Where configuration is read from
//default is to parse all application.conf, application.json and application.properties found at class path
//The actor system then merges in all reference.conf resources found at class path to form the fallback configuration,
 
//For Akka application, keep configuration in application.conf at class path(for sbt, src/main/resources)
//For Akka-based library, keep its configuration in reference.conf at the root of the JAR file.
 
//Check details from 
//http://doc.akka.io/docs/akka/2.5/general/configuration.html






///Akka-Cluster (Preferred over Remoting) 
Akka Cluster provides a fault-tolerant decentralized peer-to-peer based cluster membership service 
with no single point of failure or single point of bottleneck. 
It does this using gossip protocols and an automatic failure detector.

//Steps 
In conf, put provider cluster and seed-nodes containing atleast one node 
Start that seed nodes 
All nodes should have same ActorSystem names 
Nodes would talk to each other and converge to cluster 
All Nodes can be remote 


//Terminologies 
node
    A logical member of a cluster. There could be multiple nodes on a physical machine. 
    Defined by a hostname:port:uid tuple.
cluster
    A set of nodes joined together through the membership service.
    Cluster membership is communicated using a Gossip Protocol, 
    where the current state of the cluster is gossiped randomly through the cluster, 
    with preference to members that have not seen the latest version.
leader
    A single node in the cluster that acts as the leader. 
    Managing cluster convergence and membership state transitions.
    
    
//Joining configured seed nodes
Use https://developer.lightbend.com/docs/akka-management/current/bootstrap.html
if to be used with Kubernetes, AWS, Google Cloud, Azure, Mesos or others which maintain DNS 
or other ways of discovering nodes,

You may decide if joining to the cluster should be done manually or automatically 
to configured initial contact points, so-called seed nodes. 

You can join to any node in the cluster. It does not have to be configured as a seed node
An actor system can only join a cluster once


//Automatic joining - application.conf 
akka.cluster.seed-nodes = [
  "akka.tcp://ClusterSystem@host1:2552",
  "akka.tcp://ClusterSystem@host2:2552"]
  
//OR 
-Dakka.cluster.seed-nodes.0=akka.tcp://ClusterSystem@host1:2552
-Dakka.cluster.seed-nodes.1=akka.tcp://ClusterSystem@host2:2552

//OR Manual joining 
import akka.actor.Address
import akka.cluster.Cluster

val cluster = Cluster(system)
val list: List[Address] = AddressFromURIString("akka.tcp://ClusterSystem@host2:2552")
cluster.joinSeedNodes(list)


///Example -Worker Dial-in Example 
//workers, here named backend, can detect and register to new master nodes, here named frontend.

//The example application provides a service to transform text. 
//When some text is sent to one of the frontend services, 
//it will be delegated to one of the backend workers, which performs the reverse, 
//and sends the result back to the original client. 

//New backend nodes, as well as new frontend nodes, can be added or removed to the cluster dynamically.

//five window 
$ sbt "runMain clustering.TransformationFrontend 25251"
$ sbt "runMain clustering.TransformationFrontend 25252"
$ sbt "runMain clustering.TransformationBackend 0"
$ sbt "runMain clustering.TransformationBackend 0"
$ sbt "runMain clustering.TransformationFrontend 0"


//code 
package clustering 

import akka.cluster._
import akka.cluster.ClusterEvent._
import akka.actor._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory
import akka.cluster.ClusterEvent._ 
import scala.util._ 
import akka.util._ 
import java.util.concurrent.atomic.AtomicInteger

trait CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "ClusterSystem"
    val clusterMainApp = "clusterMainApp.conf"
    
    //val clusterTrx = "clusterTrx.conf"
    
    val sleeptime = 10*60*1000
    val killtime = 10.minutes 
    
    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=killtime, sleeptime:Int=sleeptime):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actor ! PoisonPill
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}

//Worker 
final case class TransformationJob(text: String) extends CborSerializable
final case class TransformationResult(text: String) extends CborSerializable
final case class JobFailed(reason: String, job: TransformationJob) extends CborSerializable

//Only use case class 
final case class BackendRegistration() extends CborSerializable
//case object BackendRegistration


//frontend 
class TransformationFrontend extends Actor {

  var backends = IndexedSeq.empty[ActorRef]
  var jobCounter = 0

  def receive = {
    case job: TransformationJob if backends.isEmpty =>
      sender() ! JobFailed("Service unavailable, try again later", job)

    case job: TransformationJob =>
      jobCounter += 1
      backends(jobCounter % backends.size) forward job

    //Backend Sends this 
    case _ : BackendRegistration if !backends.contains(sender()) =>
      context watch sender()
      backends = backends :+ sender()

    case Terminated(a) =>
      backends = backends.filterNot(_ == a)
  }
}

object TransformationFrontend {
  def main(args: Array[String]): Unit = {
    import Helper._ 
    
    // Override the configuration of the port when specified as program argument
    val port = if (args.isEmpty) "0" else args(0)
    val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
      .withFallback(ConfigFactory.parseString("akka.cluster.roles = [frontend]"))
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem(clusterActorSystem, config)
    val frontend = system.actorOf(Props(new TransformationFrontend), name = "frontend")

    
    import system.dispatcher
    val input = Seq("IAMCLUSTER", "HELLO WORLD")
    val counter = new AtomicInteger
    system.scheduler.scheduleAtFixedRate(1.seconds, 1.seconds){ () => 
      implicit val timeout = Timeout(5.seconds)
      import akka.pattern._
      
      val text = input(counter.incrementAndGet() % input.size)
      
      (frontend ? TransformationJob(text)).onComplete {
        case Success(TransformationResult(result)) => println(s"Result: $result")
        case Failure(ex)  => println(s"Result exception: $ex")
        case x => println(s"Result ???: $x")
      }
    }
    
          
    killThisSystem(system, frontend)

  }
}

//Backend 
class TransformationBackend extends Actor with ActorLogging{

  val cluster = Cluster(context.system)

  // subscribe to cluster changes, MemberUp
  // re-subscribe when restart
  override def preStart(): Unit = cluster.subscribe(self, classOf[MemberUp])
  override def postStop(): Unit = cluster.unsubscribe(self)

  def receive = {
    case TransformationJob(text) => sender() ! TransformationResult(text.reverse)
    case state: CurrentClusterState =>
      state.members.filter(_.status == MemberStatus.Up) foreach register
    case MemberUp(m) => register(m)
  }

  def register(member: Member): Unit = {
    if (member.hasRole("frontend")){
      log.info(s"member=$member ${member.address}")
      context.actorSelection(RootActorPath(member.address) / "user" / "frontend") ! BackendRegistration()
      }
   }
}

object TransformationBackend {
  def main(args: Array[String]): Unit = {
    import Helper._ 
    
    // Override the configuration of the port when specified as program argument
    val port = if (args.isEmpty) "0" else args(0)
    val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
      .withFallback(ConfigFactory.parseString("akka.cluster.roles = [backend]"))
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem(clusterActorSystem, config)
    val backend = system.actorOf(Props(new TransformationBackend), name = "backend")
    
    killThisSystem(system, backend)
  }
}




///Routers  
//router - which routes messages 
//routee - actors which recieve message (ie Worker)

//Messages can be sent via a router to efficiently route them to destination actors, known as its routees. 
//A Router can be used inside or outside of an actor, 

final case class Router(logic: RoutingLogic, routees: IndexedSeq[Routee] = Vector.empty)
    For each message that is sent through the router via the #route method 
    the RoutingLogic decides to which Routee to send the message.
    
//The routing logic shipped with Akka are(akka.routing.) 
final class BroadcastRoutingLogic
    Broadcasts a message to all its routees.
final case class ConsistentHashingRoutingLogic(system: ActorSystem, virtualNodesFactor: Int = 0, hashMapping: ConsistentHashMapping = ...)
    Uses consistent hashing to select a routee based on the sent message.
final class RandomRoutingLogic
    Randomly selects one of the target routees to send a message to
final class RoundRobinRoutingLogic
    Uses round-robin to select a routee.
final case class ScatterGatherFirstCompletedRoutingLogic(within: FiniteDuration)
    Broadcasts the message to all routees, and replies with the first response.
final case class TailChoppingRoutingLogic(scheduler: Scheduler, within: FiniteDuration, interval: FiniteDuration, context: ExecutionContext)
    As each message is sent to the router, the routees are randomly ordered.
class SmallestMailboxRoutingLogic
    Tries to send to the non-suspended routee with fewest messages in mailbox.

//Types 
Pool
    to create a round-robin router 
    that forwards messages to five Worker routees

Group 
    rather than having the router actor create its routees, 
    it is desirable to create routees separately and provide them to the router for its use. 
    Messages will be sent with ActorSelection to these paths.


//routingApp.conf
akka.actor.deployment {
  /parent/router_rrp {   #"router_rrp" is used in code 
    router = round-robin-pool
    nr-of-instances = 5
  }
}

akka.actor.deployment {
  /parent/router_rrg {
    router = round-robin-group
    routees.paths = ["/user/workers/w1", "/user/workers/w2", "/user/workers/w3"]
  }
}

//code 
package routing  
import akka.actor._
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import scala.concurrent.duration._
import akka.routing._
import akka.util._
import scala.util._

object Helper {
    val routingActorSystem = "RoutingSystem"
    val routingApp = "routingApp.conf"
    

    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        killThisSystemSeq(system, Seq(actor), killtime, sleeptime)
    }
    def killThisSystemSeq(system:ActorSystem, actors:Seq[ActorRef], killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actors.foreach{ actor => actor ! PoisonPill }
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}


 
case class Work(str:String)       
case class Result(str:String)       

class Master extends Actor with ActorLogging{
  var router = {
    val routees = Vector.fill(5) {
      val r = context.actorOf(Props(new Worker))
      context watch r
      ActorRefRoutee(r)   //create the routees as ordinary child actors wrapped in ActorRefRoutee
    }
    Router(RoundRobinRoutingLogic(), routees)
  }
 
  def receive = {
    case w: Work =>
      router.route(w, sender())  //Sending messages via the router is done with the route method
    case Terminated(a) =>
      router = router.removeRoutee(a)
      val r = context.actorOf(Props(new Worker))
      context watch r
      router = router.addRoutee(r)
  }
}

class Worker extends Actor with ActorLogging{
   
    def receive = {
        case Work(str) => 
            sender() ! Result(str.reverse) 
        case _ => 
    }

}

object RoutingDemo extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)

  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val firstRef = system.actorOf(Props(new Master), "master")


  for (_ <- 0 to 5){
      firstRef.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, firstRef, 1.minutes, 1*60*1000)
}
//Pool 
object RoutingDemoRRP extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrp: ActorRef = context.actorOf(FromConfig.props(Props(new Worker)), "router_rrp")
    
    override def receive: Receive = {
      case x =>
        router_rrp.forward(x)
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, parent, 1.minutes, 1*60*1000)
}
//Group 
object RoutingDemoRRG extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val workers: ActorRef = system.actorOf(Props(new Actor {
    val seqw = (1 to 4).toList.map( i => context.actorOf(Props(new Worker), name = s"w$i") )

    override def receive: Receive = {
      case x =>
       println(s"In Workers !!! $x")
    }
  }), "workers")
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrg: ActorRef = context.actorOf(FromConfig.props(), "router_rrg")
    
    override def receive: Receive = {
      case x =>
        router_rrg.forward(x)
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystemSeq(system, Seq(parent, workers), 1.minutes, 1*60*1000)
}




///BalancingPool 
//A Router that will try to redistribute work from busy routees to idle routees. 
//All routees share the same mailbox.
//Do not use Broadcast Messages when you use BalancingPool for routers
//conf 
akka.actor.deployment {
  /parent/router_bp {
    router = balancing-pool
    nr-of-instances = 5
    pool-dispatcher {
      attempt-teamwork = off
    }
  }
}
//Same Code as RoutingDemoRRP , only router_rrp line changed to below 
val router_bp: ActorRef =  context.actorOf(FromConfig.props(Props[Worker]), "router_bp")
//OR 
val router_bp: ActorRef =
      context.actorOf(BalancingPool(5).props(Props[Worker]), "router_bp")

//By default the fork-join-dispatcher is used 
//OR 
akka.actor.deployment {
  /parent/router_bptpe {
    router = balancing-pool
    nr-of-instances = 5
    pool-dispatcher {
      executor = "thread-pool-executor"

      # allocate exactly 5 threads for this pool
      thread-pool-executor {
        core-pool-size-min = 5
        core-pool-size-max = 5
      }
    }
  }
}



///Routers : Specially Handled Messages 

//Broadcast Messages
A Broadcast message can be used to send a message to all of a router routees. 

Do not use Broadcast Messages when you use BalancingPool for routers.

When a router receives a Broadcast message, 
it will broadcast that message payload to all routees, 

//Example 
import akka.routing.Broadcast
router ! Broadcast("Watch out for Davy Jones' locker") //router extracts its payload and send only payload to Worker



//Specially Handled Messages - PoisonPill Messages(same treatment for Kill Messages)
//here router (only router) is getting PoisionPill or Kill 
//and when the router stops it also stops its children(routees)
import akka.actor.PoisonPill
router ! PoisonPill

//If you wish to stop a router and its routees explicitely 
import akka.actor.PoisonPill
import akka.routing.Broadcast
router ! Broadcast(PoisonPill)
//or for Kill 
import akka.actor.Kill
import akka.routing.Broadcast
router ! Broadcast(Kill)

