Day Four
9.       Familiarizing Yourself with Basic Monads
·       Familiarizing Yourself with Basic Monads
·       Introduction to monads
·       Id Monad
·       State monad
·       Reader monad
·       Writer monad
10. A Look at Monad Transformers and Free Monad
    A Look at Monad Transformers and Free Monad
    Combining monads
    Monad transformers
    Monad transformers stacks
    Free monads
11. An Introduction to the Akka and Actor Models
    An Introduction to the Akka and Actor Models
    Introduction to the actor model
    Akka basics
    Advanced topics
    Testing actors
    Running the application
-------------------------------------------
///Introducing Monad 
The abstraction name is Monad, and it is defined by two methods, flatMap, and pure:
More powerful than Applicative and Functor because ap, map can be implemented by flatMap 

import scala.language.higherKinds
trait Monad[F[_]] {
  def pure[A](a: A): F[A]
  def flatMap[A, B](a: F[A])(f: A => F[B]): F[B]
  
  def map[A, B](a: F[A])(f: A => B): F[B] =
    flatMap(a)(a => pure(f(a)))

  def flatten[A](a: F[F[A]]): F[A] = flatMap(a)(fa => fa)
    
  // def flatMap[A, B](a: F[A])(f: A => F[B]): F[B] //Note a is F[sometype] and f is sometype to someother Fn ie f's arg and a type is same 
  //def map[A, B](a: F[A])(f: A => B): F[B]
  def ap[A, B](ff: F[A => B])(fa: F[A]): F[B] =
    flatMap(f) { fab: (A => B) => map(a)(fab)}
    //fab is arg name with type A=>B  , body 

  override def product[A, B](fa: F[A], fb: F[B]): F[(A, B)] =
    flatMap(fa)(a => map(fb)(b => (a, b)))

  override def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] =
    flatMap(fa)(a => flatMap(fb)(b => map(ff)(_(a, b))))

  override def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z] =
    flatMap(fa)(a => map(fb)(b => f(a, b)))

  override def productR[A, B](fa: F[A])(fb: F[B]): F[B] =
    flatMap(fa)(_ => fb)

  override def productL[A, B](fa: F[A])(fb: F[B]): F[A] =
    map2(fa, fb)((a, _) => a)

}

This possibility to flatten F[F[A]] into F[A] is the reason why monads are often expressed
with a different set of methods; that is, map and flatten:

trait   Monad[F[_]] {
  def   pure[A](a: => A): F[A]
  def   map[A, B](a: F[A])(f: A => B): F[B]
  def   flatten[A](fa: F[F[A]]): F[A]
}

///Monad-Some implementations
implicit def eitherMonad[L] = new Monad[Either[L, *]] {
 override def pure[A](a:  A): Either[L, A] = Right(a)

 override def flatMap[A, B](a: Either[L, A])(f: A => Either[L, B]):  Either[L, B] = a match {
   case Right(r) => f(r)
   case Left(l) => Left(l)
 }
}

implicit val listMonad = new Monad[List] {
  def unit[A](a: => A) = List(a)

  def flatMapNonTailRec[A,B](as: List[A])(f: A => List[B]): List[B] = as match {
    case Nil => Nil
    case a :: as => f(a) ::: flatMap(as)(f)
  }

  def flatMapOkButSlow[A,B](as: List[A])(f: A => List[B]): List[B] = {
    @tailrec
    def fMap(as: List[A], acc: List[B])(f: A => List[B]): List[B] = as match {
      case Nil => acc
      case a :: aas => fMap(aas, acc ::: f(a))(f)
    }
    fMap(as, Nil)(f)
  }

  override def flatMap[A,B](as: List[A])(f: A => List[B]): List[B] = as.flatMap(f)
}

///Monad Laws
pure and flatMap must obey a set of laws that allow us to sequence
operations freely without unintended glitches and sideeffects:

    Left identity: calling pure and transforming the result with func is the
    same as calling func:
    pure(a).flatMap(func) == func(a)

    Right identity: passing pure to flatMap is the same as doing nothing:
    m.flatMap(pure) == m

    Associativity: flatMapping over two functions f and g is the same as
    flatMapping over f and then flatMapping over g:
    m.flatMap(f).flatMap(g) == m.flatMap(x => f(x).flatMap(g))

//In Props 
import org.scalacheck._
import Prop._


def associativity[A, B, C, M[_]](implicit M: Monad[M],
                                 arbMA: Arbitrary[M[A]],
                                 arbMB: Arbitrary[M[B]],
                                 arbMC: Arbitrary[M[C]],
                                 arbB: Arbitrary[B],
                                 arbC: Arbitrary[C],
                                 cogenA: Cogen[A],
                                 cogenB: Cogen[B]): Prop = {
  forAll((as: M[A], f: A => M[B], g: B => M[C]) => {
    val leftSide = M.flatMap(M.flatMap(as)(f))(g)
    val rightSide = M.flatMap(as)(a => M.flatMap(f(a))(g))
    leftSide == rightSide
  })
}

def id[A, B, M[_]](implicit M: Monad[M],
                   arbFA: Arbitrary[M[A]],
                   arbFB: Arbitrary[M[B]],
                   arbA: Arbitrary[A],
                   cogenA: Cogen[A]): Prop = {
  val leftIdentity = forAll { as: M[A] =>
    M.flatMap(as)(M.pure(_)) == as
  }
  val rightIdentity = forAll { (a: A, f: A => M[B]) =>
    M.flatMap(M.pure(a))(f) == f(a)
  }
  leftIdentity && rightIdentity
}

def monad[A, B, C, M[_]](implicit M: Monad[M],
                         arbMA: Arbitrary[M[A]],
                         arbMB: Arbitrary[M[B]],
                         arbMC: Arbitrary[M[C]],
                         arbA: Arbitrary[A],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],
                         cogenB: Cogen[B]): Prop = {
  id[A, B, M] && associativity[A, B, C, M]
}

//Monad[List] and String => Int, Int => Boolean
monad[String, Int, Boolean, List].check 

///Monad -Props check with  cats-law 
import cats.laws.discipline.MonadTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 //monad[A: Arbitrary: Eq, B: Arbitrary: Eq, C: Arbitrary: Eq]
  checkAll("List.MonadLaws", MonadTests[List].monad[Int, Int, String])
  checkAll("List.StackUnsafeMonadLaws", MonadTests[List].stackUnsafeMonad[Int, Int, String])
  
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
- List.MonadLaws.monad.ap consistent with product + map
- List.MonadLaws.monad.applicative homomorphism
- List.MonadLaws.monad.applicative identity
- List.MonadLaws.monad.applicative interchange
- List.MonadLaws.monad.applicative map
- List.MonadLaws.monad.applicative unit
- List.MonadLaws.monad.apply composition
- List.MonadLaws.monad.covariant composition
- List.MonadLaws.monad.covariant identity
- List.MonadLaws.monad.flatMap associativity
- List.MonadLaws.monad.flatMap consistent apply
- List.MonadLaws.monad.flatMap from tailRecM consistency
- List.MonadLaws.monad.invariant composition
- List.MonadLaws.monad.invariant identity
- List.MonadLaws.monad.map flatMap coherence
- List.MonadLaws.monad.map2/map2Eval consistency
- List.MonadLaws.monad.map2/product-map consistency
- List.MonadLaws.monad.monad left identity
- List.MonadLaws.monad.monad right identity
- List.MonadLaws.monad.monoidal left identity
- List.MonadLaws.monad.monoidal right identity
- List.MonadLaws.monad.mproduct consistent flatMap
- List.MonadLaws.monad.productL consistent map2
- List.MonadLaws.monad.productR consistent map2
- List.MonadLaws.monad.semigroupal associativity
- List.MonadLaws.monad.tailRecM consistent flatMap
- List.MonadLaws.monad.tailRecM stack safety

- List.StackUnsafeMonadLaws.monad (stack-unsafe).ap consistent with product +map
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative homomorphism
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative interchange
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative map
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative unit
- List.StackUnsafeMonadLaws.monad (stack-unsafe).apply composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).covariant composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).covariant identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap associativity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap consistent apply
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap from tailRecM consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).invariant composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).invariant identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map flatMap coherence
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map2/map2Eval consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map2/product-map consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monad left identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monad right identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monoidal left identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monoidal right identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).mproduct consistent flatMap
- List.StackUnsafeMonadLaws.monad (stack-unsafe).productL consistent map2
- List.StackUnsafeMonadLaws.monad (stack-unsafe).productR consistent map2
- List.StackUnsafeMonadLaws.monad (stack-unsafe).semigroupal associativity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).tailRecM consistent flatMap

///Id Monad
It wraps a value but does nothing with it. 
Because Monad requires type constructor, simple type can not be used, so use Id type 

type Id[A] = A

This type definition will dictate the details of the monad implementation:
implicit val idMonad = new Monad[Id] {
  override def unit[A](a: => A): Id[A] = a
  override def flatMap[A, B](a: Id[A])(f: A => Id[B]): Id[B] = f(a)
}

///Example from cats 
import cats._
import cats.implicits._ 
 
def sumSquare[F[_]: Monad](a: F[Int], b: F[Int]): F[Int] =
     for {
      x <- a
      y <- b
     } yield x*x + y*y


This method works well on Options and Lists 
sumSquare(Some(2):Option[Int], Some(3):Option[Int])

but we canot call it passing in plain values:
sumSquare(3, 4)

//There comes Id monad 
sumSquare(3 : Id[Int], 4 : Id[Int])






///State monad
The state monad is build around a function that takes state as an argument 
and returns a result and modified state 

The signature of such a function looks like this: 

type StatefulFunction[S, A] = S => (S, A).
//OR in case class 
case class State[S, A](runF: S => (S, A))

To compose this computation with the next one 
ie we now have State[S, A] and we need to transform to  State[S, B].
This type of monadic composition is called Kleisli composition / Kleisli arrow, 
It is frequently named >>= (basically it is flatMap)

final case class State[S, A](runF: S => (S, A)) {
  def compose[B](f: A => State[S, B]): State[S, B] = {
    val composedRuns = (s: S) => {
      val (nextState, a) = runF(s)
      f(a).runF(nextState)  //(S,B)
    }
    State(composedRuns)
  }
}

object State {
  def apply[S, A](a: S => (S,A) ): State[S, A] = State(a)
  def get[S]: State[S, S] = State(s => (s, s))  //A becomes S 
  def set[S](s: => S): State[S, Unit] = State(_ => (s, ())) 
}

And then 
implicit def stateMonad[S] = new Monad[State[S, *]] {
  override def pure[A](a: => A): State[S, A] = State(s => (s, a))
  override def flatMap[A, B](a: State[S, A])(f: A => State[S, B]): State[S,B] = a.compose(f)
}

///More Examples from Cats 
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/IndexedStateT.scala

IndexedStateT[F, SA, SB, A] is a stateful computation in a context `F` yielding
a value of type `A`. The state transitions from a value of type `SA` to a value
of type `SB`.
Note IndexedStateT[F, S, S, A] is StateT[F, S, A] monad and StateT[Eval, S, A]  is  State[S,A]

//Few implementations 
object IndexedStateT 
  def apply[F[_], SA, SB, A](f: SA => F[(SB, A)])(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, A] =
    new IndexedStateT(F.pure(f))
    
  def applyF[F[_], SA, SB, A](runF: F[SA => F[(SB, A)]]): IndexedStateT[F, SA, SB, A] =
    new IndexedStateT(runF)
    
  def modify[F[_], SA, SB](f: SA => SB)(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =
  def modifyF[F[_], SA, SB](f: SA => F[SB])(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =
  def set[F[_], SA, SB](sb: SB)(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =
  def setF[F[_], SA, SB](fsb: F[SB])(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =

//Note Actually the fn is not S => (S,A) but 
//SA => F[(SB, A)] and stores inside context F 
class IndexedStateT[F[_], SA, SB, A](val runF: F[SA => F[(SB, A)]])

 def run(initial: SA)(implicit F: FlatMap[F]): F[(SB, A)] =
    F.flatMap(runF)(f /*SA => F[(SB, A)]*/ => f(initial) /*F[(SB, A)]*/)

  def run(initial: SA)(implicit F: FlatMap[F]): F[(SB, A)] =
    Run with the provided initial state value
  def runS(s: SA)(implicit F: FlatMap[F]): F[SB] = F.map(run(s))(_._1)
    Run with the provided initial state value and return the final state
    (discarding the final value).
  def runA(s: SA)(implicit F: FlatMap[F]): F[A] = F.map(run(s))(_._2)
    Run with the provided initial state value and return the final value
    (discarding the final state).
  def runEmpty(implicit S: Monoid[SA], F: FlatMap[F]): F[(SB, A)] = run(S.empty)
    Run with `S` empty monoid value as the initial state.
  def runEmptyS(implicit S: Monoid[SA], F: FlatMap[F]): F[SB] = runS(S.empty)
    Run with `S` empty monoid value as the initial state and return the final
    state (discarding the final value).
  def runEmptyA(implicit S: Monoid[SA], F: FlatMap[F]): F[A] = runA(S.empty)
    Run with `S` empty monoid value as the initial state and return the final
    value (discarding the final state).
 /*
  object AndThen
    apply[A, B](f: A => B): AndThen[A, B]
  class AndThen[-T, +R] extends (T => R) 
    Stack safe T => R 
      def andThen[A](g: R => A): AndThen[T, A]
      def compose[A](g: A => T): AndThen[A, R]
  //Example 
  val seed = AndThen((x: Int) => x + 1)
  val f = (0 until 10000).foldLeft(seed)((acc, _) => acc.andThen(_ + 1))
 // This should not trigger stack overflow 
 f(0)
 */
 def flatMap[B, SC](fas: A => IndexedStateT[F, SB, SC, B])(implicit F: FlatMap[F]): IndexedStateT[F, SA, SC, B] =
    //applyF[F[_], SA, SB, A](arg: F[SA => F[(SB, A)]])
    //val runF: F[SA => F[(SB, A)]]
    IndexedStateT.applyF(F.map(runF) { safsba /*SA => F[(SB, A)]*/ =>
      //1st run       //2nd run 
      AndThen(safsba).andThen { fsba /*F[(SB, A)]*/=>
        F.flatMap(fsba) { /*(SB, A)*/case (sb, a) =>
          fas(a).run(sb) /*F[(SB, A)]*/
        }
      }
    })
    
  def flatMapF[B](faf: A => F[B])(implicit F: FlatMap[F]): IndexedStateT[F, SA, SB, B] =
  def mapK[G[_]](f: F ~> G)(implicit F: Functor[F]): IndexedStateT[G, SA, SB, A] =
  def contramap[S0](f: S0 => SA)(implicit F: Functor[F]): IndexedStateT[F, S0, SB, A] =
  def bimap[SC, B](f: SB => SC, g: A => B)(implicit F: Functor[F]): IndexedStateT[F, SA, SC, B] =
  def dimap[S0, S1](f: S0 => SA)(g: SB => S1)(implicit F: Functor[F]): IndexedStateT[F, S0, S1, A] =

 def map[B](f: A => B)(implicit F: Functor[F]): IndexedStateT[F, SA, SB, B] =
    transform { case (s, a) => (s, f(a)) }
    
 def transform[B, SC](f: (SB, A) => (SC, B))(implicit F: Functor[F]): IndexedStateT[F, SA, SC, B] =
    IndexedStateT.applyF(F.map(runF) { sfsa =>
      AndThen(sfsa).andThen { fsa =>
        F.map(fsa) { case (s, a) => f(s, a) }
      }
    })
    
  def transformF[G[_], B, SC]( f: F[(SB, A)] => G[(SC, B)])(implicit F: FlatMap[F], G: Applicative[G]): IndexedStateT[G, SA, SC, B] =
    IndexedStateT(s => f(run(s)))
    //Exmaple 
    import cats.implicits._
    type ErrorOr[A] = Either[String, A]
    val xError: IndexedStateT[ErrorOr, Int, Int, Int] = IndexedStateT.get
    val xOpt: IndexedStateT[Option, Int, Int, Int] = xError.transformF(_.toOption)
    val input = 5
    xError.run(input)
    //res0: ErrorOr[(Int, Int)] = Right((5,5))
    xOpt.run(5)
    //res1: Option[(Int, Int)] = Some((5,5))
  
  def transformS[R](f: R => SA, g: (R, SB) => R)(implicit F: Functor[F]): IndexedStateT[F, R, R, A] =
    StateT.applyF(F.map(runF) { sfsa => (r: R) =>
      val sa = f(r)
      val fsba = sfsa(sa)
      F.map(fsba) { case (sb, a) => (g(r, sb), a) }
    })  
    //Example 
    This is useful when you are working with many focused `StateT`s and want to pass in a
    global state containing the various states needed for each individual `StateT`.

    import cats.implicits._ // needed for StateT.apply
    type GlobalEnv = (Int, String)
    val x: StateT[Option, Int, Double] = StateT((x: Int) => Option((x + 1, x.toDouble)))
    val xt: StateT[Option, GlobalEnv, Double] = x.transformS[GlobalEnv](_._1, (t, i) => (i, t._2))
    val input = 5
    x.run(input)
    //res0: Option[(Int, Double)] = Some((6,5.0))
    xt.run((input, "hello"))
    //res1: Option[(GlobalEnv, Double)] = Some(((6,hello),5.0))
    
  def modify[SC](f: SB => SC)(implicit F: Functor[F]): IndexedStateT[F, SA, SC, A] =
     Modify the state (`S`) component.
  def inspect[B](f: SB => B)(implicit F: Functor[F]): IndexedStateT[F, SA, SB, B] =
    Inspect a value from the input state, without modifying the state.
  def get(implicit F: Functor[F]): IndexedStateT[F, SA, SB, SB] =
    Get the input state, without modifying the state.
 
 
 
type State[S,A] = IndexedStateT[Eval, S,S,A]

object State 
  def apply[S, A](f: S => (S, A)): State[S, A] = IndexedStateT.applyF(Now((s: S) => Now(f(s))))
    So State is IndexedStateT[Eval[S => Eval[(S, A)]], S,S,A]
  def pure[S, A](a: A): State[S, A] = State(s => (s, a))
    Return `a` and maintain the input state.
  def empty[S, A](implicit A: Monoid[A]): State[S, A] = pure(A.empty)
    Return `A` empty monoid value and maintain the input state.
  def modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
    Modify the input state and return Unit.
  def inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
    Inspect a value from the input state, without modifying the state.
  def get[S]: State[S, S] = inspect(identity)
    Return the input state without modifying it.
  def set[S](s: S): State[S, Unit] = State(_ => (s, ()))
    Set the state to `s` and return Unit.
//Exmaple 
import cats._ 
import cats.implicits._ 
import cats.data._

//Simple case 
val s = State[Double,Int] { (state:Double) =>
    println("Executed")
    //must return (Double, Int)
    (state+1, state.toInt)
    }
//must return new v:Int , map does not have access currentState 
val new_s = s.map { (v:Int)/*initiaState.toInt*/ => v * 10 }
new_s.run(10.0)/*Eval*/.value 
//Executed 
//(Double, Int) = (11.0,100)

//must return S[Double,Int], flatMap has access to currentState 
val newss = new_s.flatMap{ (v:Int)/*100*/ =>  State[Double,Int] { (state:Double)/*11*/ =>
    println("Again Executed")
    //must return (Double, Int)
    (state+1, state.toInt+v)
    //11+1 , 11+100
    } 
}
newss.run(10.0)/*Eval*/.value 
//Executed
//Again Executed
//val res20: (Double, Int) = (12.0,111)


//Using shortcut methods of object State 
//Note method[S], S is for State and method[S,A] where first type is for State 
val getDemo = State.get[Int]
// getDemo: State[Int, Int] = cats.data.IndexedStateT@796af713
getDemo.runF
//cats.Eval[Int => cats.Eval[(Int, Int)]]
getDemo.run(10).value    //run return Eval[(Int, Int)], hence .value 
// res1: (Int, Int) = (10, 10)


val setDemo = State.set[Int](30)
// setDemo: State[Int, Unit] = cats.data.IndexedStateT@f9e66fa
//run(initial: SA)(implicit F: FlatMap[F]): F[(SB, A)]
setDemo.run(10).value
// res2: (Int, Unit) = (30, ())


val pureDemo = State.pure[Int, String]("Result")
// pureDemo: State[Int, String] = cats.data.IndexedStateT@439e3ee4
pureDemo.run(10).value
// res3: (Int, String) = (10, "Result")

//inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
val inspectDemo = State.inspect[Int, String](x => s"${x}!")
// inspectDemo: State[Int, String] = cats.data.IndexedStateT@77263be4
inspectDemo.run(10).value
// res4: (Int, String) = (10, "10!")

//modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
val modifyDemo = State.modify[Int](_ + 1)
// modifyDemo: State[Int, Unit] = cats.data.IndexedStateT@44ddcbfc
modifyDemo.run(10).value
// res5: (Int, Unit) = (11, ())

//OR With for comprehension 

import cats.data.State
import State._

//Note method[S] is for State and method[S,A] where first type is for State 

// return_value_A_of_[S,A] <- State.method 
//as [S,A].flatMap fn takes A 
val program: State[Int, (Int, Int, Int)] = for {
    a <- State.get[Int]               //A=S, Returns initialState 
    _ <- State.set[Int](a + 1)        //Returns  ()
    b <- State.get[Int]               //Returns above state , ie a+1
    _ <- State.modify[Int](_ + 1)     //Return (), modify State to _ + 1
    c <- State.inspect[Int, Int](_ * 1000) //gets value after value = state * 3000 
} yield (a, b, c)
// program: State[Int, (Int, Int, Int)] = cats.data.IndexedStateT@42c9d44a

//OR - flatMap gets value and must return State (which gets state as well) , map gets only value 
State.get[Int].flatMap{ (a:Int)/*state*/ => State[Int,Int]{ state => (state, a) }}
State.get[Int].flatMap{ (a:Int) /*state*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/*()*/ => State[Int,Unit]{ state => (state, ()) }}
}
State.get[Int].flatMap{ (a:Int) /*state*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/*()*/ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => State[Int,Int]{ state => (state, a) }}
    }
}
State.get[Int].flatMap{ (a:Int)/*state*/ => 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/* () */ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => 
            State.modify[Int](_ + 1)/*State[S,()], state=state+1*/.flatMap{ (v2:Unit) /*()*/ =>   State[Int,Unit]{ state => (state, ()) }}
        }
    }
}

val program = State.get[Int].flatMap{ (a:Int) /*state*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/* () */ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => 
            State.modify[Int](_ + 1)/*State[S,()], state=state+1*/.flatMap{ (v2:Unit) /*()*/ =>  
                State.inspect[Int, Int](_ * 1000)/*State[Int, Int], v=state*1000*/.map { (c:Int)/*v*/ => 
                    (a,b,c) 
               }
            }
        }
    }
}

val (state, result) = program.run(1).value
// state: Int = 3
// result: (Int, Int, Int) = (1, 2, 3000)
 
///example  State from cats - postorder calculation 
https://github.com/typelevel/cats/blob/master/core/src/main/scala/cats/data/IndexedStateT.scala

import cats._ 
import cats.implicits._ 
import cats.data._

//State[S,A] = S => (S,A) , where state=S, computation is A 
type CalcState[A] = State[List[Int], A] //S is List[A]
//Monad can take only one type, fix one if you have two types


  
/* All operations should be 
State[List[Int], Int] { oldState =>
     val newState = someTransformation(oldState)
     val result    = someCalculation
     (newState, result)
 }
*/
 
//Simply push the operands 
//apply[S, A](f: S => (S, A)): State[S, A] 
def operand(num: Int): CalcState[Int] =
    State[List[Int], Int] { stack => //state , List[Int]
        println(s"operand, state=$stack")
        (num :: stack, num)
}
    
def operator(func: (Int, Int) => Int): CalcState[Int] =
   State[List[Int], Int] { //state , List[Int]
       case b :: a :: tail =>
         println(s"operator, state=${b :: a :: tail}")
         val ans = func(a, b)
         (ans :: tail, ans)
       case _ =>
         sys.error("Fail!")
}  

def evalOne(sym: String): CalcState[Int] =
  sym match {
      case "+" => operator(_ + _)
      case "-" => operator(_ - _)
      case "*" => operator(_ * _)
      case "/" => operator(_ / _)
      case num => operand(num.toInt)
  }
  
//0.pure[CalcState] ie CalcState[Int].pure(0) = State[List[Int], 0)
def evalAll(input: List[String]): CalcState[Int] =
   input.foldLeft(0.pure[CalcState]) { (state, ele) => //a : State[List[Int], Int] , b:String 
       state.flatMap(_ => evalOne(ele)) 
       // _ is value, Int , evalOne returns CalcState 
       //a.flatMap() return CalcState which becomes input in next iteration 
   }
   
val program = evalAll(List("1", "2", "+", "3", "*"))
//program.runF
//cats.Eval[List[Int] => cats.Eval[(List[Int], Int)]]

//Takes initial State , List[Int]
//Run return Eval, so .value 
program.run(Nil).value 
/*
operand, state=List()
operand, state=List(1)
operator, state=List(2, 1)
operand, state=List(3)
operator, state=List(3, 3)
val res11: (List[Int], Int) = (List(9),9)
*/


// Get the state, ignore the result:
val justTheState = program.runS(Nil).value

// Get the result, ignore the state:
val justTheResult = program.runA(Nil).value

//OR 
val program = for {
    _    <- evalOne("1")
    _    <- evalOne("2")
    ans <- evalOne("+")
} yield ans

val (state, result) = program.run(Nil).value
//val state: List[Int] = List(3)
//val result: Int = 3
/*
class State:
     def __init__(self, runF): # lambda S : (S, A)
        self.runF = runF 
     def __str__(self):
        return f"State({self.runF})"
     def run(self, state):
        return self.runF(state)
     def flatMap(self, fnAToState): # lambda A : State 
         def inner(state):
            new_state, a = self.runF(state)
            return fnAToState(a).runF(new_state) #(S, B)
         return State(inner)
     def map(self, fnA):  # lambda A : B
        def fn(a):
            return State( lambda s: (s, fnA(a)))
        return self.flatMap(fn)


def ns(state):
    print("Executed")
    return (state+1, int(state))

s = State(ns)
new_s = s.map(lambda a : a*10)
new_s.run(10.0)
#Executed
#(11.0, 100)

def nss(state, a):
    print("Again Executed")
    return (state+1, int(state)+a)

newss = new_s.flatMap(lambda a: State(lambda s, a=a: nss(s,a=a)))
newss.run(10.0)
#Executed
#Again Executed
#(12.0, 111)
newss1 = newss.flatMap(lambda a: State(lambda s, a=a: nss(s,a=a)))
newss1.run(10.0)
#Executed
#Again Executed
#Again Executed
#(13.0, 123)

#Complex example 
def operand(num): #State[ (), int]
    def inner_operand(stack):
        print(f"operand, state={stack}")
        return ( (num,) + stack , num)
    return State(inner_operand) 

def operator(func):     # (Int, Int) => Int
    def inner_operator(stack):
        b,a,*tail = stack 
        print(f"operator, state={stack}")
        ans = func(a,b)
        return ( (ans,)+ tuple(tail), ans)
    return State(inner_operator)

def evalOne(sym, convertFn=int): #str
    ops = { '+' : lambda : operator(lambda a,b: a+b),
            '-' : lambda : operator(lambda a,b: a-b),
            '*' : lambda : operator(lambda a,b: a*b),
            '/' : lambda : operator(lambda a,b: a/b), }
    default = lambda e=sym: operand(convertFn(e))
    return ops.get(sym, default)()    

from functools import reduce 

def evalAll(input, convertFn=int, defaultV=0): # tuple[String]
    def inner_evalall(state, ele):
        return state.flatMap( lambda _ : evalOne(ele, convertFn))
    return reduce(inner_evalall, input, State(lambda s: (s, defaultV)))

program = evalAll(("1", "2", "+", "3", "*"))
program.run( () )
#operand, state=()
#operand, state=(1,)
#operator, state=(2, 1)
#operand, state=(3,)
#operator, state=(3, 3)
#((9,), 9)
*/

///Reader monad
The Reader will have access to read-only system properties. 
Because of this, the reader monad is often known as a mechanism for dependency injection
because it takes some outside configuration and makes it available for the function it wraps.

final case class Reader[R, A](runF: R => A) {
  def compose[B](f: A => Reader[R, B]): Reader[R, B] =
    Reader { r: R =>
      f(runF(r)/*A*/).runF(r) //B
    }
}

object Reader {
  def apply[R, A](f: R => A): Reader[R, A] = Reader(f)
}


implicit def readerMonad[R] = new Monad[Reader[R, *]] {
  override def pure[A](a: A): Reader[R, A] = Reader(_ => a)
  override def flatMap[A, B](a: Reader[R, A])(f: A => Reader[R, B]):  Reader[R, B] = a.compose(f)
}
///Reader monad from cats 
type Reader[A,B] = Kleisli[Id, A,B]

case class Kleisli[F[_], -A, B](run: A => F[B])
  def ap[C, D, AA <: A](f: Kleisli[F, AA, C])(implicit F: Apply[F], ev: B As (C => D)): Kleisli[F, AA, D] 
  def dimap[C, D](f: C => A)(g: B => D)(implicit F: Functor[F]): Kleisli[F, C, D] 
  def map[C](f: B => C)(implicit F: Functor[F]): Kleisli[F, A, C] 
  def mapF[N[_], C](f: F[B] => N[C]): Kleisli[N, A, C] 
  def mapK[G[_]](f: F ~> G): Kleisli[G, A, B] 
  def flatMap[C, AA <: A](f: B => Kleisli[F, AA, C])(implicit F: FlatMap[F]): Kleisli[F, AA, C] 
  def flatMapF[C](f: B => F[C])(implicit F: FlatMap[F]): Kleisli[F, A, C] 
  def andThen[C](f: B => F[C])(implicit F: FlatMap[F]): Kleisli[F, A, C] 
  def andThen[C](k: Kleisli[F, B, C])(implicit F: FlatMap[F]): Kleisli[F, A, C] 
  def compose[Z, AA <: A](f: Z => F[AA])(implicit F: FlatMap[F]): Kleisli[F, Z, B] 
  def compose[Z, AA <: A](k: Kleisli[F, Z, AA])(implicit F: FlatMap[F]): Kleisli[F, Z, B]
  def traverse[G[_], AA <: A](f: G[AA])(implicit F: Applicative[F], G: Traverse[G]): F[G[B]] 
  def lift[G[_]](implicit G: Applicative[G]): Kleisli[λ[α => G[F[α]]], A, B] 
  def local[AA](f: AA => A): Kleisli[F, AA, B]
  def lower(implicit F: Applicative[F]): Kleisli[F, A, F[B]] 
  def first[C](implicit F: Functor[F]): Kleisli[F, (A, C), (B, C)] 
  def second[C](implicit F: Functor[F]): Kleisli[F, (C, A), (C, B)] 
  def tap[AA <: A](implicit F: Functor[F]): Kleisli[F, AA, AA] 
  def tapWith[C, AA <: A](f: (AA, B) => C)(implicit F: Functor[F]): Kleisli[F, AA, C]
  def tapWithF[C, AA <: A](f: (AA, B) => F[C])(implicit F: FlatMap[F]): Kleisli[F, AA, C] 
  def toReader: Reader[A, F[B]] 
  def apply(a: A): F[B] 
  
object Kleisli    
  def applyK[F[_], A](a: A): Kleisli[F, A, *] ~> F 
  def liftF[F[_], A, B](x: F[B]): Kleisli[F, A, B] 
  def liftK[F[_], A]: F ~> Kleisli[F, A, *] 
  def pure[F[_], A, B](x: B)(implicit F: Applicative[F]): Kleisli[F, A, B]
  def ask[F[_], A](implicit F: Applicative[F]): Kleisli[F, A, A] 
  def local[M[_], A, R](f: R => R)(fa: Kleisli[M, R, A]): Kleisli[M, R, A]
  def fromFunction[M[_], R]: KleisliFromFunctionPartiallyApplied[M, R] 
  def liftFunctionK[F[_], G[_], A](f: F ~> G): Kleisli[F, A, *] ~> Kleisli[G, A, *] 


import cats._ 
import cats.implicits._ 
import cats.data._

Note flatMap and map, Fn both gets A , flatMap Fn must return Reader[R,B] eg via Reader { R => B }
wherease map Fn returns B such that map and flatMap both returns Reader[R,B]

//Simple case 
case class Configuration(v:String)

val s = Reader[Configuration,String] { (conf:Configuration) =>
    println("Executed")
    //must return String
    "first"
    }
//must return new v:String , map does not have access Configuration 
val new_s = s.map { (v:String)/*first*/ => s"map_$v" }
scala> new_s.run(Configuration("conf"))/*Id*/
//Executed
//cats.Id[String] = mapFirst

//flatMap has access to Configuration 
val newss = new_s.flatMap{ (v:String)/*map_first*/ =>  Reader[Configuration,String] { 
(conf:Configuration) =>
    println("Again Executed")
    //must return String
    s"${v}_flatMap_${conf.v}"    
  } 
}
newss.run(Configuration("conf"))/*Id*/
//OR 
newss(Configuration("conf")) //apply 
//Executed
//Again Executed
//val res36: cats.Id[String] = map_first_flatMap_conf

//Complex Usagecase 
The classic use of Readers is to build programs that accept a configuration
as a parameter. 
Our configuration will consist of two databases: a list of valid users
and a list of their passwords


final case class Db(
     usernames: Map[Int, String],
     passwords: Map[String, String]
)

type DbReader[A] = Reader[Db, A]  //Reader[R,A] , R ie db is configuration 

def findUsername(userId: Int): DbReader[Option[String]] =
   Reader(db => db.usernames.get(userId))
   
def checkPassword(username: String, password: String): DbReader[Boolean] =
   Reader(db => db.passwords.get(username).contains(password))
   
//Finally create a checkLogin method to check the password for a given user ID. 
//Flatmap Fn takes always A ,  A <- Reader[R,A]
def checkLogin( userId: Int, password: String): DbReader[Boolean] =
   for {
      username /*Option[String]*/  <- findUsername(userId)  //flatMap 
      passwordOk /*Boolean*/ <- username.map { username /*String*/ =>
                         checkPassword(username, password) /*DbReader[Boolean]*/
                    }/*Option[DbReader[Boolean]]*/.getOrElse {
                         false.pure[DbReader]
                    }
   } yield passwordOk

val users = Map(
     1 -> "dade",
     2 -> "kate",
     3 -> "margo"
 )

val passwords = Map(
     "dade"   -> "zerocool",
     "kate"   -> "acidburn",
     "margo" -> "secret"
 )


val db = Db(users, passwords)

//run returns Id 
checkLogin(1, "zerocool").run(db)
// res7: cats.package.Id[Boolean] = true
checkLogin(4, "davinci").run(db)
// res8: cats.package.Id[Boolean] = false



///Writer monad
Its main purpose is to provide a facility to write into some kind of log by passing 
this log between computations. 

The Writer takes two type arguments, one for the log entry, W:Monoid, 
and one for the result, A. 

final case class Writer[W: Monoid, A](runF: (W, A)) {
  def compose[B](f: A => Writer[W, B]): Writer[W, B] = Writer {
    val (w, a) = runF
    val (ww, b) = f(a).runF
    val www = implicitly[Monoid[W]].combine(w, ww)
    (www, b)
  }
}

object Writer {
    def apply[W: Monoid, A](a: => A): Writer[W, A] = Writer((implicitly[Monoid[W]].identity, a))
}

implicit def writerMonad[W : Monoid] = new Monad[Writer[W, *]] {
  override def unit[A](a: => A): Writer[W, A] = Writer(a)
  override def flatMap[A, B](a: Writer[W, A])(f: A => Writer[W, B]):  Writer[W, B] = a.compose(f)
}


///Example from cats 
type Writer[W,V] = WriterT[Id, W, V]
//syntax 
extension (a: A) 
  def tell: Writer[A, Unit] = Writer(a, ())
  def writer[W](w: W): Writer[W, A] = Writer(w, a)


case class WriterT[F[_], L, V](run: F[(L, V)]) 
  def tell(l: L)(implicit functorF: Functor[F], semigroupL: Semigroup[L]): WriterT[F, L, V] =
    mapWritten(semigroupL.combine(_, l))
      //Example:
      val writer = WriterT.liftF[Option, List[String], Int](Some(123))
      writer.tell(List("a","b","c")).tell(List("d","e","f"))
      //res0: WriterT[Option, List[String], Int] = WriterT(Some((List(a, b, c, d, e, f),123)))

  def written(implicit functorF: Functor[F]): F[L] =
    functorF.map(run)(_._1)
      //Example:
      val writer: WriterT[Option, List[String], Int] = WriterT.liftF(Some(123))
      writer.tell(List("a","b","c")).written.getOrElse(Nil)
      //res0: List[String] = List(a, b, c)

  def value(implicit functorF: Functor[F]): F[V] =
    functorF.map(run)(_._2)
       //Example:
       val writer: WriterT[Option, List[String], Int] = WriterT.liftF(Some(123))
       val wt: WriterT[Option, List[String], Int] = writer.tell(List("error"))
       //res0: WriterT[Option, List[String], Int] = WriterT(Some((List(error),123)))
       wt.value
       //res1: Option[Int] = Some(123)

  def listen(implicit F: Functor[F]): WriterT[F, L, (V, L)] =
    WriterT(F.map(run) { case (l, v) =>
      (l, (v, l))
    })
    //Example:
    val writer: WriterT[Option, String, Int] = WriterT.liftF(Some(123))
    val wt: WriterT[Option, String, Int] = writer.tell("error").tell(" log")
    //res0: WriterT[Option, String, Int] = WriterT(Some((error log,123)))
    wt.listen
    //res1: WriterT[Option, String, (Int,String)] = WriterT(Some((error log,(123,error log))))

  def ap[Z](f: WriterT[F, L, V => Z])(implicit F: Apply[F], L: Semigroup[L]): WriterT[F, L, Z] =
    WriterT(F.map2(f.run, run) { case ((l1, fvz), (l2, v)) =>
      (L.combine(l1, l2), fvz(v))
    })
    //Example:
    val writer: WriterT[Option, String, Int] = WriterT.liftF(Some(123))
    val wt: WriterT[Option, String, Int] = writer.tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(Some((error,123)))
    val func = WriterT.liftF[Option, String, Int => List[Int]](Some(i => List(i)))
    val func2 = func.tell("log")
    wt.ap(func2)
    //res1: WriterT[Option, String, List[Int]] = WriterT(Some((logerror,List(123))))
  
  def map[Z](fn: V => Z)(implicit functorF: Functor[F]): WriterT[F, L, Z] =
    WriterT {
      functorF.map(run) { z =>
        (z._1, fn(z._2))
      }
    }
    //Example:
    val wr1: WriterT[Option, String, Int] = WriterT.liftF(None)
    val wr2 = wr1.tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(None)
    scala> wr2.map(_ * 2)
    //res1: WriterT[Option, String, Int] = WriterT(None)
    val wr3: WriterT[Option, String, Int] = WriterT.liftF(Some(456))
    val wr4 = wr3.tell("error")
    wr4.map(_ * 2)
    //res2: WriterT[Option, String, Int] = WriterT(Some((error,912)))

  def imap[Z](f: V => Z)(g: Z => V)(implicit F: Invariant[F]): WriterT[F, L, Z] =
    WriterT {
      F.imap(run)(z => (z._1, f(z._2)))(z => (z._1, g(z._2)))
    }
    //Example:
    val wr1: WriterT[Option, String, Int] = WriterT.liftF(Some(123))
    val wr2 = wr1.tell("log...")
    wr2.imap(_ * 2)(_ / 2)
    //res0: WriterT[Option, String, Int] = WriterT(Some((log...,246)))

  def flatMap[U](f: V => WriterT[F, L, U])(implicit flatMapF: FlatMap[F], semigroupL: Semigroup[L]): WriterT[F, L, U] =
    WriterT {
      flatMapF.flatMap(run) { lv =>
        flatMapF.map(f(lv._2).run) { lv2 =>
          (semigroupL.combine(lv._1, lv2._1), lv2._2)
        }
      }
    }
    //Example:
    val wr1 = WriterT.liftF[Option, String, Int](Some(123)).tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(Some(error,123))
    val func = (i:Int) => WriterT.liftF[Option, String, Int](Some(i * 2)).tell(i.show)
    wr1.flatMap(func)
    //res1: WriterT[Option, String, Int] = WriterT(Some((error123,246)))

  def mapBoth[M, U](f: (L, V) => (M, U))(implicit functorF: Functor[F]): WriterT[F, M, U] =
    WriterT(functorF.map(run)(f.tupled))
    //Example:
    val wr1 = WriterT.liftF[Option, String, Int](Some(123)).tell("quack")
    //res0: WriterT[Option, String, Int] = WriterT(Some(quack,123))
    wr1.mapBoth((s,i) => (s + " " + s, i * 2))
    //res1: WriterT[Option, String, Int] = WriterT(Some((quack quack,246)))

  def bimap[M, U](f: L => M, g: V => U)(implicit functorF: Functor[F]): WriterT[F, M, U] =
    mapBoth((l, v) => (f(l), g(v)))

  def mapWritten[M](f: L => M)(implicit functorF: Functor[F]): WriterT[F, M, V] =
    mapBoth((l, v) => (f(l), v))
    //Example:
    val writer = WriterT.liftF[Option, String, Int](Some(246)).tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(Some((error,246)))
    writer.mapWritten(i => List(i))
    //res1: WriterT[Option, List[String], Int] = WriterT(Some((List(error),246)))

  def swap(implicit functorF: Functor[F]): WriterT[F, V, L] =
    mapBoth((l, v) => (v, l))

  def reset(implicit monoidL: Monoid[L], functorF: Functor[F]): WriterT[F, L, V] =
    mapWritten(_ => monoidL.empty)

  def show(implicit F: Show[F[(L, V)]]): String = F.show(run)

  def foldLeft[C](c: C)(f: (C, V) => C)(implicit F: Foldable[F]): C =
    F.foldLeft(run, c)((z, lv) => f(z, lv._2))

  def foldRight[C](lc: Eval[C])(f: (V, Eval[C]) => Eval[C])(implicit F: Foldable[F]): Eval[C] =
    F.foldRight(run, lc)((lv, z) => f(lv._2, z))
    
  def traverse[G[_], V1](f: V => G[V1])(implicit F: Traverse[F], G: Applicative[G]): G[WriterT[F, L, V1]] =
    G.map(
      F.traverse(run)(lv => G.tupleLeft(f(lv._2), lv._1))
    )(WriterT.apply)

  def compare(that: WriterT[F, L, V])(implicit Ord: Order[F[(L, V)]]): Int =
    Ord.compare(run, that.run)

object WriterT 
  def liftF[F[_], L, V](fv: F[V])(implicit monoidL: Monoid[L], F: Applicative[F]): WriterT[F, L, V] =
    WriterT(F.map(fv)(v => (monoidL.empty, v)))

  def liftK[F[_], L](implicit monoidL: Monoid[L], F: Applicative[F]): F ~> WriterT[F, L, *] =
    new (F ~> WriterT[F, L, *]) { def apply[A](a: F[A]): WriterT[F, L, A] = WriterT.liftF(a) }

  def putT[F[_], L, V](vf: F[V])(l: L)(implicit functorF: Functor[F]): WriterT[F, L, V] =
    WriterT(functorF.map(vf)(v => (l, v)))

  def put[F[_], L, V](v: V)(l: L)(implicit applicativeF: Applicative[F]): WriterT[F, L, V] =
    WriterT.putT[F, L, V](applicativeF.pure(v))(l)

  def tell[F[_], L](l: L)(implicit applicativeF: Applicative[F]): WriterT[F, L, Unit] =
    WriterT.put[F, L, Unit](())(l)

  def value[F[_], L, V](v: V)(implicit applicativeF: Applicative[F], monoidL: Monoid[L]): WriterT[F, L, V] =
    WriterT.put[F, L, V](v)(monoidL.empty)

  def valueT[F[_], L, V](vf: F[V])(implicit functorF: Functor[F], monoidL: Monoid[L]): WriterT[F, L, V] =
    WriterT.putT[F, L, V](vf)(monoidL.empty)

//Use Writer 
extension (a: A) 
  def tell: Writer[A, Unit] = Writer(a, ())
  def writer[W](w: W): Writer[W, A] = Writer(w, a)
case class Writer[L,V] 
    def written: Id[L]
    def value: Id[V]
    def run: Id[(L,V)]
    def map[Z](fn: V => Z): Writer[L, Z]
    def flatMap[U](f: V => Writer[L, U])(implicit semigroupL: Semigroup[L]): Writer[L, U]
    def mapBoth[M, U](f: (L, V) => (M, U)): Writer[M, U]
    def mapWritten[M](f: L => M): Writer[M, V] 
    def swap: Writer[V, L] 
    def reset(implicit monoidL: Monoid[L]): Writer[L, V] 
    def show: String 
    def foldLeft[C](c: C)(f: (C, V) => C): C
  
  
Note Writer[W,A], flatMap and map, Fn both gets A , flatMap Fn must return Writer[R,B] 
eg via Writer { returns (W,B) or via b.tell or b.writer(w:W) }
wherease map Fn returns B such that map and flatMap both returns Writer[R,B] 


import cats._ 
import cats.implicits._ 
import cats.data._

//If we have a log and no result we can create a Writer[Unit] using the 'tell'
Vector("msg1", "msg2", "msg3").tell
// res2: Writer[Vector[String], Unit] = WriterT( (Vector("msg1", "msg2", "msg3"), ()) )

val b = 123.writer(Vector("msg1", "msg2", "msg3"))
// b: Writer[Vector[String], Int] = WriterT((Vector("msg1", "msg2", "msg3"), 123) )

b.value  // Int = 123
b.written
// aLog: Vector[String] = Vector("msg1", "msg2", "msg3")

//We can extract both values at the same time using the run method:
val (log, result) = b.run
// log: Vector[String] = Vector("msg1", "msg2", "msg3")
// result: Int = 123

b.flatMap{ (v:Int) =>
            Writer( Vector("msg4"), v+10 )
         }.flatMap { (v:Int) =>
            (v+20).writer( Vector("msg5") )
         }.flatMap{ (v:Int) =>
            Vector("msg6").tell.map{ (v1:Unit) => v+30}
         }.run 
         
type Logged[A] = Writer[Vector[String], A] //joins via Vector.combine 

// flatMap_arg <- Writer[L,V]
val writer1 = for {
   a <- 10.pure[Logged]   //Writer((Vector(),10))//10
   _ <- Vector("a", "b", "c").tell   //Unit
   b <- 32.writer(Vector("x", "y", "z")) //32
 } yield a + b
 // writer1: cats.data.WriterT[cats.package.Id, Vector[String], Int] = WriterT((Vector("a", "b", "c", "x", "y", "z"), 42) )
//OR 
10.pure[Logged].flatMap( a => Vector("a", "b", "c").tell.flatMap( _ => 
    32.writer(Vector("x", "y", "z")).map ( b => (a+b) )))

writer1.run
// res3: (Vector[String], Int) = (Vector("a", "b", "c", "x", "y", "z")        , 42)


//Complex example 
Writers are useful for logging operations in multithreaded environments.

The factorial function below computes a factorial and prints out the inter
mediate steps as it runs. The slowly helper function ensures this takes a while
to run, even on the very small examples below:

import cats._ 
import cats.implicits._ 
import cats.data._

def slowly[A](body: => A) =
     try body finally Thread.sleep(100)


def factorial(n: Int): Int = {
     val ans = slowly(if(n == 0) 1 else n * factorial(n - 1))
     println(s"fact $n $ans")
     ans
 }

factorial(5)
// fact 0 1
// fact 1 1
// fact 2 2
// fact 3 6
// fact 4 24
// fact 5 120
// res9: Int = 120

If we start several factorials in parallel, the log messages can become inter
leaved on standard out. This makes it difficult to see which messages come
from which computation:

import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.duration._

//vector of Future => Future of Vector 
Await.result(Future.sequence(Vector(
    Future(factorial(5)),
    Future(factorial(5))
)), 5.seconds)


//Solution 

 
//In our case
type Logged[A] = Writer[Vector[String], A] //joins via Vector.combine 

def slowly[A](body: => A) =
     try body finally Thread.sleep(100)

def factorial(n: Int): Logged[Int] =
    for {
        ans <- if(n == 0) {
                1.pure[Logged]
            } else {
                slowly(factorial(n - 1).map(_ * n)) // map from Writer 
            }
        _  <- Vector(s"fact $n $ans").tell
    } yield ans


val (log, res) = factorial(5).run
 // log: Vector[String] = Vector(
 //     "fact 0 1",
 //     "fact 1 1",
 //     "fact 2 2",
 //     "fact 3 6",
 //     "fact 4 24",
 //     "fact 5 120"
 // )
 // res: Int = 120


Await.result(Future.sequence(Vector(
   Future(factorial(5)),
   Future(factorial(5))
 ))/* Future[Vector[Logged[Int]]] */
 .map(/*Vector[Logged[Int]]*/ _.map(/*Logged[Int]]*/_.written))  , 5.seconds)
// res: scala.collection.immutable.Vector[cats.Id[Vector[String]]] =
//     Vector(
//         Vector(fact 0 1, fact 1 1, fact 2 2, fact 3 6, fact 4 24, fact        5 120),
//         Vector(fact 0 1, fact 1 1, fact 2 2, fact 3 6, fact 4 24, fact        5 120)
//     )


///Monad Composition is called Monad Transformer 

Functor[F[_]].compose[G[_]: Functor]: Functor[({type f[x]=F[G[x]]})#f] =  {   
        val F = this
        val G = implicitly[Functor[G]]
        new Functor[({type f[x]=F[G[x]]})#f] {
            override def map[A, B](fga: F[G[A]])(f: A => B): F[G[B]] =
                F.map(fga)(ga => G.map(ga)(f))
        }
    }
    
Applicative[F[_]].compose[G[_]]( implicit  G: Applicative[G]): Applicative[({type f[x] = F[G[x]]})#f] = {
    val F = this

    def fab[A, B]: G[A => B] => G[A] => G[B] = (gf: G[A => B]) => (ga: G[A]) => G.ap(gf)(ga)

    def fg[B, A](f: F[G[A => B]]): F[G[A] => G[B]] = F.map(f)(gab => fab(gab) )

    new Applicative[({type f[x] = F[G[x]]})#f] {
      def pure[A](a: A) = F.pure(G.pure(a))
      override def ap[A, B](f: F[G[A => B]])(a: F[G[A]]): F[G[B]] =
        F.ap(fg(f) /*F[G[A] => G[B]]*/ )(a)
    }
  }
Unlike Functors and Applicatives, not all Monads compose. 
This means that even if M[_] and N[_] are both Monads, M[N[_]] is not guaranteed to be a Monad.

However, many common cases do. 
One way of expressing this is to provide instructions on how to compose any outer monad 
(F in the following example) with a specific inner monad (Option in the following example).

This sort of construction is called a monad transformer.

Cats has an OptionT monad transformer, which adds a lot of useful functions 
to the simple implementation below.

import cats.*
import cats.implicits._

case class OptionT[F[_], A](value: F[Option[A]])

implicit def optionTMonad[F[_]](implicit F: Monad[F]): Monad[OptionT[F, *]] = {
  new Monad[OptionT[F, *]] {
    def pure[A](a: A): OptionT[F, A] = OptionT(F.pure(Some(a)))
    def flatMap[A, B](fa: OptionT[F, A])(f: A => OptionT[F, B]): OptionT[F, B] =
      OptionT {
        F.flatMap(fa.value) { /*Option[A]*/
          case None => F.pure(None)
          case Some(a) => f(a).value
        }
      }

    def tailRecM[A, B](a: A)(f: A => OptionT[F, Either[A, B]]): OptionT[F, B] =
      OptionT {
        F.tailRecM(a)(a0 => F.map(f(a0).value) {
          case None => Either.right[A, Option[B]](None)
          case Some(b0) => b0.map(Some(_))
        })
      }
  }
}

///Monad Transformer Stack 


//Example of More Combined Stack - State of Reader of Writer of String 

StateT[Id, state, computation]
    Here 
    state = List[String]
    val step = State[state, computation] { oldstate =>
         val newstate = someTransformation(oldstate)
         val result    = someCalculation
         (newstate, result)
     }
    val (state, result) = step.run(initialStep).value


ReaderT[Id, config, ReaderFnreturns]
    Here 
    config = Map[String,String]
    val rs: Reader[config, ReaderFnreturns] =
       Reader{ config => ReaderFnreturns}


WriterT[F[_], Log, V]
    Here 
    Log = Vector[String]

//State of Reader of Writer of String 
//so inside out 
//Alwyas has to be type constructor in first arg, as given as F[_]
//so multiple type declaration is needed 

type StateList[A] = State[List[String],A]  //T 
type ReaderState[A] = ReaderT[StateList,  Map[String,String], A]   //RT
type WriterReaderState[A] = WriterT[ReaderState, Vector[String], A]  
type WriterReaderStateString = WriterReaderState[String]  //WRT
//State[List[String],Reader[ Map[String,String], Writer[Vector[String], String]]]

//pure takes only F[_] type param 
10.pure[StateList]
10.pure[ReaderState] 
10.pure[WriterReaderState]


//Quick revision - State 
10.pure[StateList] //StateList[Int]

val step1 = State[List[String],Int]{ lstString =>    //oldstate
     val ans = "STEP1" :: lstString
     (ans, 10)   //(newState, value)
}

val step2 = State[List[String],Int]{ lstString =>
     val ans = "STEP2" :: lstString
     (ans, 20)
}

val both = for {
     a <- step1 // Get result 
     b <- step2
} yield (a, b)

//Give initial state = List[String]
val (state, result) = both.run(Nil).value
//val state: List[String] = List(STEP2, STEP1)
//val result: (Int, Int) = (10,20)

val steps = List( step1, step2)
val alsteps = steps.foldLeft(10.pure[StateList]){ (state,e) =>
        println(s"1) state=$state e=$e")
        state.flatMap{ va /*value*/=> 
            print(s"2) va=$va")
            e.map{ sv /*value*/ => 
                  println(s" sv=$sv ret=${va+sv}")
                  va + sv
                }
        }
    }
1) r=cats.data.IndexedStateT@3dc19f23 e=cats.data.IndexedStateT@770d46f
1) r=cats.data.IndexedStateT@4953bf2 e=cats.data.IndexedStateT@8540fd0
val alsteps: T[Int] = cats.data.IndexedStateT@632a547d

//Inner prints are not printed 
scala> val (state, result) = alsteps.run(Nil).value
2) va=10 sv=10 ret=20
2) va=20 sv=20 ret=40
val state: List[String] = List(STEP2, STEP1)
val result: Int = 40


//Quick Reader 
ReaderT[F[_], -Confg, Ftype](run: Confg => F[Ftype])
WriterT[F[_], Log, V](run: F[(Log, V)])
StateT[F[_], StateStructure, Result]( run: StateStructure => (StateStructure, Result))


//type StateList[A] = State[List[String],A]
//type ReaderState[A] = ReaderT[StateList,  Map[String,String], A] 

10.pure[ReaderState] //ReaderState[Int]

//ReaderT returns State 
val rs =  ReaderT[StateList, Map[String,String], Int]{ mapSS /*conf*/ =>
        State[List[String],Int]{ lstString /*state*/=> 
             val ans = "STEP1" :: lstString
             (ans, 10)
            }
       }       
    
val value = for {
    value1 <- rs     // Int
    value2 <- rs
} yield s"${value1 * value2}"  //in ReaderT[T, Map[String,String], Int]
//Reader[StateList,Map[String,String],String]

val res8 = value(Map("OK"->"OKVALUE")) //State[List[String],String]
//val res8: StateList[String] = cats.data.IndexedStateT@5739c440

val (state, result) = res8.run(Nil).value 
//val state: List[String] = List(STEP1, STEP1)
//val result: String = 100


//Quick Writer 
ReaderT[F[_], -Confg, Ftype](run: Confg => F[Ftype])
WriterT[F[_], Log, V](run: F[(Log, V)])
StateT[F[_], StateStructure, Result]( run: StateStructure => (StateStructure, Result))

WriterT
    liftF[F[_], L, V](fv: F[V])(implicit monoidL: Monoid[L], F: Applicative[F]): WriterT[F, L, V]
    liftK[F[_], L](implicit monoidL: Monoid[L], F: Applicative[F]): F ~> WriterT[F, L, *]

WriterT[F[_], L, V](run: F[(L, V)])
    mapBoth[M, U](f: (L, V) => (M, U))(implicit functorF: Functor[F]): WriterT[F, M, U] 
    bimap[M, U](f: L => M, g: V => U)(implicit functorF: Functor[F]): WriterT[F, M, U] 
    mapWritten[M](f: L => M)(implicit functorF: Functor[F]): WriterT[F, M, V]
    swap(implicit functorF: Functor[F]): WriterT[F, V, L] 
    reset(implicit monoidL: Monoid[L], functorF: Functor[F]): WriterT[F, L, V] 
    foldLeft[C](c: C)(f: (C, V) => C)(implicit F: Foldable[F]): C
    traverse[G[_], V1](f: V => G[V1])(implicit F: Traverse[F], G: Applicative[G]): G[WriterT[F, L, V1]]
//syntax 
extension (a: A) 
  def tell: Writer[A, Unit] = Writer(a, ())
  def writer[W](w: W): Writer[W, A] = Writer(w, a)  
    
//type StateList[A] = State[List[String],A]
//type ReaderState[A] = ReaderT[StateList,  Map[String,String], A]  
//type WriterReaderState[A] = WriterT[ReaderState, Vector[String], A]
//F[A] of Writer is Reader[Map[String,String], State[List[String],A]]
//Writer is F[(L,V)] so Reader[Map[String,String], State[List[String],(Log, Int)]]


10.pure[WriterReaderState]
// WriterReaderState[Int]

val innerrs =  ReaderT[StateList, Map[String,String], Int]{ mapSS =>
        State[List[String],Int]{ lstString => 
             val ans = "STEP1" :: lstString
             (ans, 10)
            }
       }
       
val ws = WriterT.liftF[ReaderState, Vector[String], Int](innerrs)
//WriterT[ReaderState,Vector[String],Int]

ws.tell(Vector("x", "y", "z"))
//WriterT[ReaderState,Vector[String],Int]

val writer1 = for {
   a <- 10.pure[WriterReaderState]      //a=10
   b <- ws.tell(Vector("x", "y", "z"))  //b=10
 } yield a + b
//cats.data.WriterT[RT,Vector[String],Int]

val wr = writer1.run 
//ReaderState[(Vector[String], Int)]

val rres = wr(Map("OK"->"OKVALUE")) //StateList[(Vector[String], Int)]
val (state, result) = rres.run(Nil).value 
//val state: List[String] = List(STEP1)
//val result: (Vector[String], Int) = (Vector(x, y, z),20)




///Free monads
We represented sequenced computations with monads. 
The flatMap method of the monad describes how the computation steps should
be joined and the function given to it as an argument--the computation step itself. The free
monad elevates the concept of sequenced computations to the next level.

Sometimes, the general outline of a monad may be useful, but no simple pattern recommends 
one monad or another.

This is where a free monad comes in; 
as a free object, https://en.wikipedia.org/wiki/Free_object in the category of monads, 

For example, by working entirely through the Some and None markers, 
the Option monad is in fact a free monad. The List monad, on the other hand, is not a free monad 
since it brings extra, specific facts about lists (like append) into its definition

Other examples from cats are Chain, AndThen, TailRec etc 

Free monads are characterized by ADT  ie sealed trait as CoProduct and case class as Product 
and flatMap and pure implemented entirely with those Products 

sealed trait Option[+A]{
    def get: A
    def isEmpty: Boolean = this eq None
    def pure[A](a: A): Option[A] = Option(a)
    
    def flatMap[B](f: A => Option[B]): Option[B] = if (isEmpty) None else f(this.get)
    def map[B](f: A => B): Option[B] =  if (isEmpty) None else Some(f(this.get))
    def ap[A, B](a: F[A])(ff: F[A => B]): F[B] = flatMap(ff)(f => map(a)(f))
}
object Option {
    def apply[A](x: A): Option[A] = if (x == null) None else Some(x)
}

final case class Some[+A](value: A) extends Option[A] {
  def get: A = value
}
case object None extends Option[Nothing] {
  def get: Nothing = throw new NoSuchElementException("None.get")
}

//Example of Free Monad - Console 
We can build a data structure to describe a console program with just three instructions:

sealed trait Console[+A]
final case class Return[A](value: () => A) extends Console[A]
final case class PrintLine[A](line: String, rest: Console[A]) extends Console[A]
final case class ReadLine[A](rest: String => Console[A]) extends Console[A]

In this model, Console[A] is an immutable, type-safe value, which represents a console program 
that returns a value of type A.

The Console data structure is an ordered tree, and at the very "end" of the program, 
you will find a Return instruction that stores a value of type A, 
which is the return value of the Console[A] program.

val example1: Console[Unit] = 
  PrintLine("Hello, what is your name?",
    ReadLine(name =>
      PrintLine(s"Good to meet you, ${name}", Return(() => ())))
)
//Nested Structure of Console

//OR Using 
def succeed[A](a: => A): Console[A] = Return(() => a)
def printLine(line: String): Console[Unit] =
  PrintLine(line, succeed(()))
val readLine: Console[String] =
  ReadLine(line => succeed(line))
  

implicit class ConsoleSyntax[+A](self: Console[A]) {
  def map[B](f: A => B): Console[B] =
    flatMap(a => succeed(f(a)))

  def flatMap[B](f: A => Console[B]): Console[B] =
    self match {
      case Return(value) => f(value())
      case PrintLine(line, next) =>
        PrintLine(line, next.flatMap(f))
      case ReadLine(next) =>
        ReadLine(line => next(line).flatMap(f))
    }
}
//Then Note that this is a nested structure 
val example2: Console[String] =
  for {
    _    <- printLine("Whats your name?")
    name <- readLine
    _    <- printLine(s"Hello, ${name}, good to meet you!")
  } yield name
//val example2: Console[String] = PrintLine(Whats your name?,ReadLine(lambda,PrintLine(Hello, ${name}, good to meet you!)))

//When we wish to execute this program

def run[A](program: Console[A]): A = program match {
  case Return(value) => 
    value()
  case PrintLine(line, next) => 
    println(line)
    interpret(next)
  case ReadLine(next) =>
    interpret(next(scala.io.StdIn.readLine()))
}

run(example2)


///Free monad with cats 
Use below 
libraryDependencies += "org.typelevel" %% "cats-free" % "2.4.2"

//ref 
class Free[S[_], A] 
    Binding is done using the heap instead of the stack, allowing tail-call elimination.
    S[_] is sealed trait of ADT 
     
    final def map[B](f: A => B): Free[S, B] 
    final def mapK[T[_]](f: S ~> T): Free[T, A] 
    final def flatMap[B](f: A => Free[S, B]): Free[S, B] 
    final def fold[B](r: A => B, s: S[Free[S, A]] => B)(implicit S: Functor[S]): B 
    final def run(implicit S: Comonad[S]): A 
        Run to completion, using the given comonad to extract the resumption.
        Comonad[F[_]] has below    
          def extract[A](x: F[A]): A  
          def coflatMap[A, B](fa: F[A])(f: F[A] => B): F[B]   // from CoflatMap
          def coflatten[A](fa: F[A]): F[F[A]] =  coflatMap(fa)(fa => fa) //from CoflatMap
    def runM[M[_]](f: S[Free[S, A]] => M[Free[S, A]])(implicit S: Functor[S], M: Monad[M]): M[A]  
    def runTailRec(implicit S: Monad[S]): S[A]  
    def foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
    def compile[T[_]](f: FunctionK[S, T]): Free[T, A] = mapK(f)
    def inject[G[_]](implicit ev: InjectK[S, G]): Free[G, A]
        Lift into G (typically a EitherK) given InjectK.

object Free
  def pure[S[_], A](a: A): Free[S, A] = Pure(a)
  def liftF[F[_], A](value: F[A]): Free[F, A] = Suspend(value)
  def liftK[F[_]]: F ~> Free[F, *] =
  def liftId[F[_]]: Id ~> Free[F, *] =
  def roll[F[_], A](value: F[Free[F, A]]): Free[F, A] =
    Absorb a step into the free monad
  def suspend[F[_], A](value: => Free[F, A]): Free[F, A] =
    Suspend the creation of a `Free[F, A]` value.
  def defer[F[_], A](value: => Free[F, A]): Free[F, A] =    pure(()).flatMap(_ => value)
    Defer the creation of a `Free[F, A]` value.
  def mapK[F[_], G[_]](fk: FunctionK[F, G]): FunctionK[Free[F, *], Free[G, *]] =
  def compile[F[_], G[_]](fk: FunctionK[F, G]): FunctionK[Free[F, *], Free[G, *]] =
  def foldMap[F[_], M[_]: Monad](fk: FunctionK[F, M]): FunctionK[Free[F, *], M] =
  def inject[F[_], G[_]]: FreeInjectKPartiallyApplied[F, G]
        One to one function from F[_] to G[_] eg apply(F[A]):Free[G,A] exists 
        class FreeInjectKPartiallyApplied[F[_], G[_]](private val dummy: Boolean = true) extends AnyVal 
            def apply[A](fa: F[A])(implicit I: InjectK[F, G]): Free[G, A] =  Free.liftF(I.inj(fa))


The free monad has advantages
    Gluing the computations together as classes happens in a heap and saves stack  memory.
    
    It is possible to pass the computation over to different parts of the code and the
    side-effects will be deferred until it is explicitly run.    
   
    represent stateful computations as data, and run them

    build an embedded DSL (domain-specific language)
    
    retarget a computation to another interpreter using natural transformations
    (In Cats, the type representing a free monad is abbreviated as Free[_])
    
The disadvantages lie in the same plane as they do for monads. These include additional
initial implementation effort, runtime overhead for the garbage collector, and processing
additional instructions and mental overhead for developers new to the concept.


//Practicalities 
Represent your domain,S:Functor in ADT and the Use Free[S[_], A] to convert those into monadic form. 
  
In terms of implementation(cats), to build a monad from a functor , below types are used 

sealed abstract class Free[F[_], A]
case class Pure[F[_], A](a: A) extends Free[F, A]
case class Suspend[F[_], A](a: F[Free[F, A]]) extends Free[F, A]

In this representation:
    Pure builds a Free instance from an A value (it corresponds to the Monad.pure function)
    Suspend builds a new Free by applying F to a previous Free (it corresponds to the flatMap function)

resulting Free into a  recursive structure
Suspend(F(Suspend(F(Suspend(F(....(Pure(a))))))))

//Steps 
Represent problem into  ADT where S[_] is sealed trait 
and case class Step(inputs...)/object extends S[Output] are Steps 

Use  
Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
to convert S[_] to Known M:Monad eg State/Id/Reader/List/Option etc by using below steps 

    1. Define Free container type eg 'type Type[A] = Free[S,A]' where S[_] is sealed trait 
    2. Define helper for each case class to convert to Free[S,Output]
        Use Free.liftF[S[_], A](value: S[A]): Free[S, A]
    3. Free[S,A] has flatMap, Use 
        Free[S[_], A].flatMap[B](f: A => Free[S, B]): Free[S, B] 
       OR for-comprehension , to define program using Step2 helpers 
       This creates a Nested structure using Pure and Suspend 
    4. Write FunctionK[S, M] /S ~> M with 'def apply(S[A]): M[A]' using respective M[_] methods 
       eg for Id, it is simple type, for State, it is State[state,A] helpers 
       This is required to use with foldMap 
       This step is called interpretor and Many such with different M[_] can be written 
    5. foldMap returns M[A], run this to get A 
        Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
       eg for Id, output is direct simple type,
       for State, use M[A].run(InitialState).value 
    
If there are two ADTs, then we need to compose them using
    type etype[A] = EitherK[FirstADT[_], SecondADT[_], A]
    For FirstADT and SecondADT , write helpers , 
    Then write programs with Free[etype,A] with those helpers 
    and write FirstADT ~> M and SecondADT ~> M 
    Then use below to get etype ~> M 
        FunctionK[FirstADT[_], M[_]].or[SecondADT[_]](h: FunctionK[SecondADT, M]) FunctionK[EitherK[FirstADT, SecondADT, *], M] 
    Use above in Free[etype,A].foldMap 
    
    Note if  implicits of InjectK[FirstADT, F[_]] and 
    InjectK[SecondADT,F[_]] are avilable , then Use 
        Free.inject[FirstADT/SecondADT, F[_]].apply( FirstADT/SecondADT[A]) to get Free[F,A]
    For F[A] = EitherK[FirstADT[_], SecondADT[_], A], implicits of InjectK[FirstADT,*]
    and InjectK[SecondADT,*] are available , So, use implicit arguments and use Free.inject
    to get Free[etype,A] in helpers 
    
    
To compose Free with other M:Monad , Use FreeT[S[_], M[_], A] instead of Free 
    Above steps are same, with below change  
    1. Define FreeT container type eg 'type Type[A] = FreeT[S,M, A]' where S[_] is sealed trait 
       and M[_]: any Monad eg Id, State etc 
    2. Use below to create helpers 
        liftF to lift ADT and liftT to lift Monad 
        FreeT.liftF[S[_], M[_], A](value: S[A])(implicit M: Applicative[M]): FreeT[S, M, A] 
        FreeT.liftT[S[_], M[_], A](value: M[A])(implicit M: Functor[M]): FreeT[S, M, A] 
        FreeT.pure[S[_], M[_], A](value: A)(implicit M: Applicative[M]): FreeT[S, M, A]
    
    Other steps remain same , Only Note foldMap signature is 
        FreeT[S[_], M[_], A].foldMap(f: FunctionK[S, M])(implicit M: Monad[M]): M[A]
    ie M[_] of FreeT[S[_], M[_], *] is used when writing S ~> M 
    means, FreeT can be converted to those M[_] with which FreeT was created     
    
    Note, to convert M[_] to another Monad N[_]
    use program_written_in_M.hoisted by writing M ~> N 
    FreeT[S[_], M[_], A].hoist[N[_]](mn: FunctionK[M, N]): FreeT[S, N, A]
    Now We need to write interpretors from N[_]
    

//Example 
Let imagine that we want to create a DSL for a key-value store. 
    put a value into the store, associated with its key.
    get a value from the store given its key.
    delete a value from the store given its key.

For example:

put("toto", 3)
get("toto") // returns 3
delete("toto")

//STEP1-Create an ADT representing your grammar

sealed trait KVStore[A]

//Note output of any action is part of 'extends KVStore[OUTPUT]'

//Put a value associated with a key into the store
case class Put[T](key: String, value: T) extends KVStore[Unit]

//Get a value associated with a key out of the store
case class Get[T](key: String) extends KVStore[Option[T]]

//Delete a value associated with a key from the store
case class Delete(key: String) extends KVStore[Unit]

//STEP2-Free your ADT - There are five basic steps to 'freeing' the ADT:
    
//STEP2.1. Create a Free type based on your ADT
import cats._ 
import cats.implicits._ 
import cats.data._ 
import cats.free._ 
import cats.free.Free._

//Free[S[_], A]
type KVStoreMonad[A] = Free[KVStore, A]

Use 
    Free.pure[S[_], A](a: A): Free[S, A] 
    Free.liftF[F[_], A](value: F[A]): Free[F, A] 
    Free.foldMap[F[_], M[_]: Monad](fk: FunctionK[F, M]): FunctionK[Free[F, *], M] 
    def inject[F[_], G[_]]: FreeInjectKPartiallyApplied[F, G]
        One to one function from F[_] to G[_] eg apply(F[A]):Free[G,A] exists 
Free[S[_], A] 
    def map[B](f: A => B): Free[S, B] 
    def mapK[T[_]](f: S ~> T): Free[T, A] 
    def flatMap[B](f: A => Free[S, B]): Free[S, B]     
    def runM[M[_]](f: S[Free[S, A]] => M[Free[S, A]])(implicit S: Functor[S], M: Monad[M]): M[A]  
    def runTailRec(implicit S: Monad[S]): S[A]  
    def foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 


//STEP2.2.Create smart constructors using liftF for convenience

// Put returns nothing (i.e. Unit).
def put[T](key: String, value: T): KVStoreMonad[Unit] =
  liftF[KVStore, Unit](Put[T](key, value))

// Get returns a T value.
def get[T](key: String): KVStoreMonad[Option[T]] =
  liftF[KVStore, Option[T]](Get[T](key))

// Delete returns nothing (i.e. Unit).
def delete(key: String): KVStoreMonad[Unit] =
  liftF(Delete(key))

// Derived, helper Update composes get and set, and returns nothing.
def update[T](key: String, f: T => T): KVStoreMonad[Unit] =
  for {
    vMaybe <- get[T](key) //unwrap KVStoreMonad and get Option[T]
    _ <- vMaybe.map(v => put[T](key, f(v))).getOrElse(Free.pure(()))
  } yield ()

//STEP2.3.Build a application out of key-value DSL operations.

def program: KVStoreMonad[Option[Int]] =
  for {
    _ <- put("wild-cats", 2)
    _ <- update[Int]("wild-cats", (_ + 12))
    _ <- put("tame-cats", 5)
    n <- get[Int]("wild-cats")
    _ <- delete("tame-cats")
  } yield n

//STEP2.4. Write a compiler for your program, ie transformation from S ie KVStoreMonad[_]  to M[_]
//or FunctionK[KVStoreMonad,M] or KVStoreMonad ~ M , Note M should be Monad, eg Id, State etc 

//Implementation-1:  Use M[_] as Id which is simple type 
we could easily use other type containers for different behavior, such as:
    Future[_] for asynchronous computation
    List[_] for gathering multiple results
    Option[_] to support optional results
    Either[E, *] to support failure
    
//we will use a simple mutable map to represent our key value store:

import cats.arrow.FunctionK
import cats.{Id, ~>}
import scala.collection.mutable

// the program will crash if a key is not found,
// or if a type is incorrectly specified.
def impureCompiler: KVStore ~> Id  =
  new (KVStore ~> Id) {  // KVStore[A] => Id[A]
    val kvs = mutable.Map.empty[String, Any]
    def apply[A](fa: KVStore[A]): Id[A] =
      fa match {
        case Put(key, value) =>
          println(s"put($key, $value)")
          kvs(key) = value
          ()
        case Get(key) =>
          println(s"get($key)")
          kvs.get(key).map(_.asInstanceOf[A])
        case Delete(key) =>
          println(s"delete($key)")
          kvs.remove(key)
          ()
      }
  }

//STEP2.5. Run your program
//Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
//In our case M = Id and S=KVStore

val result: Option[Int] = program.foldMap(impureCompiler)
// put(wild-cats, 2)
// get(wild-cats)
// put(wild-cats, 14)
// put(tame-cats, 5)
// get(wild-cats)
// delete(tame-cats)
// result: Option[Int] = Some(14)


//STEP2.6. Use a pure compiler (Using another compiler eg State whch is also Monad) 
class State[S,A] (val runEval: Eval[S => Eval[(S, A)]])
  def run(initial: S): Eval[(S, A)] 
  def flatMap[B](fas: A => State[S,B]): State[S,B] 
  def map[B](f: A => B): State[S, B] 
  def transform[B](f: (S, A) => (S, B)): State[S,B] =
  def transformS[R](f: R => S, g: (R, S) => R): State[R, A] =
  def modify[C](f: S => C): State[C,A] =
     Modify the state (`S`) component.
  def inspect[B](f: S => B): State[S, B] =
    Inspect a value from the input state, without modifying the state.
  def get: State[S,S] =
    Get the input state, without modifying the state.
object State 
  def apply[S, A](f: S => (S, A)): State[S, A] 
  def pure[S, A](a: A): State[S, A] 
  def empty[S, A](implicit A: Monoid[A]): State[S, A] 
  def modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
    Modify the input state and return Unit.
  def inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
    Inspect a value from the input state, without modifying the state.
  def get[S]: State[S, S] = inspect(identity)
    Return the input state without modifying it.
  def set[S](s: S): State[S, Unit] = State(_ => (s, ()))
    Set the state to `s` and return Unit.
    
    
type KVStoreState[A] = State[Map[String, Any], A]

val pureCompiler: KVStore ~> KVStoreState = new (KVStore ~> KVStoreState) {
  def apply[A](fa: KVStore[A]): KVStoreState[A] =
    fa match {
      case Put(key, value) => State.modify(map => map.updated(key, value))  //Use Map Method 
      case Get(key) => State.inspect(map => map.get(key).map(_.asInstanceOf[A]))
      case Delete(key) => State.modify(map => map - key)
    }
}
//run to run the State 
val result: (Map[String, Any], Option[Int]) = program.foldMap(pureCompiler).run(Map.empty).value
// result: (Map[String, Any], Option[Int]) = (Map("wild-cats" -> 14), Some(14))



///Actor Props - for passing Actor constructor argument 
import akka.actor.Props

import akka.actor._

class MyActor(magicNumber: Int) extends Actor with ActorLogging {
  import MyActor._
  //def receive: PartialFunction[Any, Unit]
  //Accept Any 
  //In Typed Actor, accept type is a Particular Type, so it can not accept any other type 
  def receive = {
    case Greeting(greeter) => 
            log.info(s"$magicNumber: I was greeted by $greeter.")
            sender() ! "Greeted"
    case Goodbye           => 
            log.info(s"$magicNumber: Someone said goodbye to me.")
            context.stop(self)
  }
}
//RECOMENDED Practice, put props in companion object with below pattern , can be used inside or outside Actor
object MyActor {
   def props(magicNumber: Int): Props = Props(new MyActor(magicNumber))
   case class Greeting(from: String)
   case object Goodbye
}

//when no constructor arg 
val props1 = Props[MyActor]()  //ERROR???
val props7 = Props(new MyActor) //NOT RECOMMENDED within another actor
//OR 
val props3 = Props(classOf[ActorWithArgs], "arg", "arg2") // RECO , but not for value class arguments( class extends AnyVal)
val props2 = Props(new ActorWithArgs("arg")) //for all type ctor args , but NOT RECOMMENDED within another actor

Props Methods 
    def withActorTags(tags: Set[String]): Props
        Scala API: Returns a new Props with the specified set of tags.
    def withDeploy(d: Deploy): Props
        Returns a new Props with the specified deployment configuration.
    def withDispatcher(d: String): Props
        Returns a new Props with the specified dispatcher set.
    def withMailbox(m: String): Props
        Returns a new Props with the specified mailbox set.
    def withRouter(r: RouterConfig): Props
        Returns a new Props with the specified router config set.

///Actor creation 
//both context(inside actor) and system(ActorSystem) have below methods 
def actorOf(props: Props, name: String): ActorRef
    Create new actor as child of this context with the given name, 
    which must not be null, empty or start with '$'.
def actorOf(props: Props): ActorRef
    Create new actor as child of this context and give it an automatically  generated name 
    (currently similar to base64-encoded integer count, reversed and with $ prepended, may change in the future).

//Example of creation 
import akka.actor.{ActorSystem, Props}

// ActorSystem is a heavy object: create only one per application
val system = ActorSystem("Dummy") //akka://Dummy
val resOne = system.actorOf(MyActor.props(42), "name") //name should unique 
//Actor[akka://Dummy/user/name#115048092]

//OR 
val resTwo =system.actorOf(MyActor.props(42))
//val res2: akka.actor.ActorRef = Actor[akka://Dummy/user/$a#2024249730]

//via context inside an Actor 
context.actorOf(MyActor.props(42), "name")
context.actorOf(MyActor.props(42))

//These are the rules for message sends by default 
//to change check Persistence
at-most-once delivery, i.e. no guaranteed delivery, 
    that message is delivered zero or one time
    For a given pair of actors, messages sent directly from the first to the second 
    will not be received out-of-order.


//Message sending 
! , tell
    send a message, 
    Note any message can be sent, eg, Int, String, any user defined Class/object(must be immutable and Serializable)
?,ask 
    Sends a message and wait for result in future
    
resOne ! MyActor.Greeting("Das")  //Response goes to Deadletter 
resTwo ! MyActor.Greeting("Das")
    
//Stopping 
resOne ! PoisonPill
resTwo ! PoisonPill

import system.dispatcher //brings ExecutionContext
system.terminate().foreach( _ => "Terminated")

///Testing 
https://doc.akka.io/docs/akka/current/testing.html

The TestKit contains an actor named testActor which is the entry point for messages 
to be examined with the various expectMsg... assertions . 
When mixing in the trait ImplicitSender this test actor is implicitly used 
as sender reference when dispatching messages from the test procedure. 


import akka.actor._
import akka.testkit._
import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers
import org.scalatest.wordspec.AnyWordSpecLike

class MySpec()
    extends TestKit(ActorSystem("Dummy"))
    with ImplicitSender //TestKit.testActor is sender 
    with AnyWordSpecLike //BDD like template 
    with Matchers
    with BeforeAndAfterAll //must be last trait
    {
  
  var actor:ActorRef =   _
  var probe: TestProbe = _

  override def beforeAll() : Unit = {
    actor = system.actorOf(MyActor.props(42)) 
    probe = TestProbe()    
    probe.watch(actor)
  }
  
  override def afterAll(): Unit = {
    TestKit.shutdownActorSystem(system)
  }

  "My First Actor" must {

    "send back Greeted" in {
      actor ! MyActor.Greeting("Das")
      expectMsg("Greeted")
    }
    
    "stop" in {
      import scala.concurrent.duration._
      actor ! MyActor.Goodbye
      probe.expectTerminated(actor)
    }
  }
}
scala> org.scalatest.run(new MySpec())
//In sbt , this must be in src/test/scala folder 
$ sbt test 
//https://www.scalatest.org/user_guide/using_scalatest_with_sbt


///Important testkit method   
import scala.concurrent.duration._

val hello: String = expectMsg("hello")
val any: String = expectMsgAnyOf("hello", "world")
val all: immutable.Seq[String] = expectMsgAllOf("hello", "world")
val i: Int = expectMsgType[Int]
expectNoMessage(200.millis)
val two: immutable.Seq[AnyRef] = receiveN(2)
expectMsg(500.millis, "hello")

///Important attributes of Actor 
1.The Actor own akka.actor.ActorRef is available as self, 
2.the current message sender as sender() 
3.the akka.actor.ActorContext as context. 
4.abstract method ,receive returns the initial behavior of the actor as a partial function 
 (behavior can be changed using context.become and context.unbecome).

The Akka Actor receive message loop is exhaustive Otherwise an 
akka.actor.UnhandledMessage(message, sender, recipient) 
will be published to the ActorSystem EventStream.

///Helper Functions 
import akka.actor._
import scala.util._

object ActorHelper{
    import scala.concurrent._
    import scala.concurrent.duration._
    
    def process(system: ActorSystem)(createActors: ActorSystem=>Seq[ActorRef])
            (stopActors:(ActorSystem, Seq[ActorRef])=>Unit)
            (body: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        val actors = createActors(system)
        println(s"Created: ${actors.map(_.toString).mkString("(",",",")")}")
      
        import system.dispatcher //brings ExecutionContext 
        body(system, actors).andThen{
            case x => 
                println(s"Stopping, body returned $x")
                stopActors(system,actors)
                x
          }
    }   
    def processSeq( system: ActorSystem, propNames:Seq[(String, Props)], stopMessage:Iterator[Any] =Iterator.continually(PoisonPill) )(sendfn: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        process(system){system => 
            propNames.map{case (n,p) => system.actorOf(p, n)}
          }{ (system, seq) =>
            seq.zip(stopMessage).foreach{ case(a, m) => a ! m} 
          }{(system, seq) => 
            sendfn(system, seq)
        }
    }    
    
    def processOne( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system)
               (system => Seq(system.actorOf(props, "name")))
               ( (system, seq) =>seq.head ! stopMessage ){
            (system, seq) => sendfn(system, seq.head)
        }
    }    
    def processWithTestProb(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef, ActorRef) => Future[Any] ):Future[Any]  = {
      processSeq(system, Seq(("name", props)/*actor*/, ("testprob", Props(new TestProb))/*sender*/), 
        Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor, sender) = seqs 
            sendfn(system, actor, sender)/*Future*/.transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                    sender ! PoisonPill
                })
            }
        }
    }
    def processWithoutStop(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        processSeq(system, Seq(("name", props)), Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor) = seqs 
            sendfn(system, actor).transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                })
            }
        }
    }
    
    def processName( system: ActorSystem, props:Props, actorName: String, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system)(system => Seq(system.actorOf(props, actorName)))( (system, seq) =>seq.head ! stopMessage ){
            (system, seq) => sendfn(system, seq.head)
        }
    }

    
    def findActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds):Future[ActorRef] =     
        system.actorSelection(prefix+name).resolveOne(duration)
        
    def stopActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds, stopMessage:Any=PoisonPill)={
        import system.dispatcher //brings ExecutionContext 
        findActor(system, name, prefix, duration).onComplete{
            case util.Success(ref) => 
                println(s"$ref")
                ref ! stopMessage
            case _ =>
        }
    }
    
    trait ActorStop { thisActor : Actor =>
        import ActorStop._ 
        
        def receiveSTOP: Actor.Receive = {    
           case STOP =>
              context.children.foreach { ch =>
                ch ! PoisonPill
              }
              self ! PoisonPill 
              
           case IMMSTOP =>
                 context.children.foreach { ch =>
                    context.stop(ch)
                }
              context.stop(self)
           case FAKESTOP =>
                 
        }
    }
    object ActorStop{
        sealed trait STOPMARKER
        case object STOP extends STOPMARKER
        case object IMMSTOP extends STOPMARKER
        case object FAKESTOP extends STOPMARKER
    }
    
    class TestProb extends Actor with ActorLogging {
        def receive: Receive = {    
               case msg => log.info(s"${self.path.name} - New msg received: $msg")      
            }
    }
    object TestProb{
        def props:Props = Props(new TestProb)
    }
}



///ActorRef and  sender()
//ActorRefs can be freely shared among actors by message passing. 
//Message passing conversely is their only purpose

//example 
import akka.actor._

class ExampleActor extends Actor with ActorLogging with ActorHelper.ActorStop {
  val other = context.actorOf(MyActor.props(32), "childName") // will be destroyed and re-created upon restart by default
  log.info(s"$self created $other")
  
  import ExampleActor._    
  
  def receiveAll:Actor.Receive = {
    case Request1(msg) => other ! MyActor.Greeting1(msg)                // uses this actor as sender reference, reply comes here 
    case Request2(msg) => other.tell(MyActor.Greeting2(msg), sender())  // forward sender reference, in other sender() would be this actor sender()
    case Request3(msg) =>
      import akka.pattern.{ask, pipe}
      import scala.concurrent.duration._
      val fut = other.ask(MyActor.Greeting3(msg))(5.seconds)
      import context.dispatcher
      pipe(fut) to sender()
      // the ask call will get a future from other's reply
      // when the future is complete, send its value to the original sender      
  }
  override def receive:Actor.Receive = receiveAll.orElse(receiveSTOP)
}
object ExampleActor {
   def props: Props = Props(new ExampleActor)
   case class Request1(msg: String)
   case class Request2(msg: String)
   case class Request3(msg: String)
}

class MyActor(magicNumber: Int) extends Actor with ActorLogging {
  import MyActor._
  def receive = {
    case Greeting1(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.1")
        sender() !  ExampleActor.Request2(greeter)
    case Greeting2(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.2")
        //Here sender() is not ExampleActor, but MyActor because of other.tell(..)
        sender() !  MyActor.Goodbye
    case Greeting3(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.3")
        sender() !  "Completed"
    case Goodbye  => log.info(s"$magicNumber: Someone said goodbye to me.")
  }
}
object MyActor {
   def props(magicNumber: Int): Props = Props(new MyActor(magicNumber))
   case class Greeting1(from: String)
   case class Greeting2(from: String)
   case class Greeting3(from: String)
   case object Goodbye
}
//Using REPL 
val system = ActorSystem("Dummy") //akka://Dummy
val resOne = system.actorOf(ExampleActor.props, "name") //name should unique 
resOne ! ExampleActor.Request1("Das") 
32: I was greeted by Das.1
32: I was greeted by Das.2
32: Someone said goodbye to me.

import scala.concurrent.duration._
import akka.pattern.ask
val future = resOne.ask(ExampleActor.Request3("Das"))(5.seconds).mapTo[String] //Future[String]

import system.dispatcher //brings ExecutionContext
future.foreach(println) //Completed
resOne ! PoisonPill
system.terminate().foreach( _ => "Terminated")


//Using ActorHelper 
val system = ActorSystem("Dummy")
import system.dispatcher
ActorHelper.processOne(system, ExampleActor.props, ActorHelper.ActorStop.STOP){ (system, actor) =>
    import akka.pattern._ 
    import scala.concurrent.duration._
    import system.dispatcher //brings ExecutionContext  
    actor ! ExampleActor.Request1("Das")     
    val future = actor.ask(ExampleActor.Request3("Das"))(5.seconds).mapTo[String] //Future[String]
    future
}.foreach(println)
//output 
Created: Actor[akka://Dummy/user/name#-2078609943]
Actor[akka://Dummy/user/name#-2078609943] created Actor[akka://Dummy/user/name/childName#-145826343]
32: I was greeted by Das.1
32: I was greeted by Das.3
32: I was greeted by Das.2
32: Someone said goodbye to me.
Completed

system.terminate().foreach( _ => "Terminated")


///Actor - Scheduler - Schedule a code 

//The scheduler will throw an exception if attempts are made to schedule too far into the future 
//(which by default is around 8 months (Int.MaxValue seconds)

def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and frequency.
def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    Schedules a Runnable to be run repeatedly with an initial delay and a frequency.
def scheduleOnce(delay: FiniteDuration)(f: => Unit)(implicit executor: ExecutionContext): Cancellable
    Schedules a function to be run once with a delay, i.e.
def scheduleOnce(delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent once with a delay, i.e.
def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and a fixed delay between messages.
def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    Schedules a Runnable to be run repeatedly with an initial delay and a fixed delay between subsequent executions.
    

//trait Cancellable
def cancel(): Boolean
    Cancels this Cancellable and returns true if that was successful.
def isCancelled: Boolean
    Returns true if and only if this Cancellable has been successfully cancelled

//code 
import akka.actor._
import scala.concurrent.duration._

implicit val system = ....

class TestActor extends Actor {

}

testActor = system.actorOf(Props[TestActor])

//Schedule to send the “foo”-message to the testActor after 50ms:
//Use the system's dispatcher as ExecutionContext
import system.dispatcher

//Schedules to send the "foo"-message to the testActor after 50ms
system.scheduler.scheduleOnce(50 milliseconds, testActor, "foo")

//Schedules a function to be executed (send a message to the testActor) after 50ms
system.scheduler.scheduleOnce(50 milliseconds) {
  testActor ! System.currentTimeMillis
}

//Schedule to send the “Tick”-message to the tickActor after 0ms repeating every 50ms:

val Tick = "tick"
class TickActor extends Actor {
  def receive = {
    case Tick => //Do something
  }
}
val tickActor = system.actorOf(Props(classOf[TickActor], this))


//This will schedule to send the Tick-message
//to the tickActor after 0ms repeating every 50ms
val cancellable = system.scheduler.schedule(
    0 milliseconds,
    50 milliseconds,
    tickActor,
    Tick)

//This cancels further Ticks to be sent
cancellable.cancel()

//Usage 
import akka.actor._

val system = ActorSystem("testSystem")
import system.dispatcher

val fut = ActorHelper.processOne(system, Props(new ActorHelper.TestProb), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    
    val run:Runnable = () => actor ! "5TICK"
    val id1 = system.scheduler.scheduleAtFixedRate(1.seconds, 5.seconds)(run)
    //OR 
    val id2 = system.scheduler.scheduleWithFixedDelay(1.seconds, 2.seconds, actor,"2TICK")
    Future.successful(() => { 
        id1.cancel()
        id2.cancel()
        })
}
fut.foreach{ lambda => lambda.asInstanceOf[Function0[Any]]()}

//Check 
ActorHelper.stopActor(system, "name")





///Actor - Switching Between Different States with become
//context.become and context.unbecome
def  become(behavior: Receive, discardOld: Boolean): Unit 
    Changes the Actor behavior to become the new 'Receive' (PartialFunction[Any, Unit]) 
    handler. This method acts upon the behavior stack as follows:
        if discardOld = true it will replace the top element (i.e.default), 
            no need for unbecome(), This is default 
        if discardOld = false it will keep the current behavior and push the given one atop, 
            must issue unbecome()
def unbecome(): Unit
    Reverts the Actor behavior to the previous one on the behavior stack.


//Example 
import akka.actor._
object OneActor{
    case object GoToSecondState
    case object TryToFindSolution
    case object GoToOneState
    def props = Props(new OneActor)
}
class OneActor extends Actor with ActorLogging{
  import context._
  import OneActor._ 
  
	def oneState: Receive = {
	  case GoToSecondState =>
		   println("Moving to two State")
		   become(twoState)
	}

	def twoState: Receive = {
	  case TryToFindSolution =>
		   println("remaining in two State")
	  case GoToOneState =>
		   println("Moving to one state")
		   become(oneState)
	}

	def receive = {
	  case GoToOneState => become(oneState)
	  case GoToSecondState => become(twoState)
	}
}



val system = ActorSystem("testSystem")
import system.dispatcher

ActorHelper.processOne(system, OneActor.props){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    import OneActor._ 
    
    actor ! GoToOneState // init to normalState
    actor ! GoToSecondState
    actor ! TryToFindSolution
    Thread.sleep(1000)
    actor ! GoToOneState
    Future.successful("OK")
}.foreach(println)

//Check 
ActorHelper.findActor(system, "name")

system.terminate()


///Routers  
//router - which routes messages 
//routee - actors which recieve message (ie Worker)

//Messages can be sent via a router to efficiently route them to destination actors, known as its routees. 
//A Router can be used inside or outside of an actor, 

final case class Router(logic: RoutingLogic, routees: IndexedSeq[Routee] = Vector.empty)
    For each message that is sent through the router via the #route method 
    the RoutingLogic decides to which Routee to send the message.
    
//The routing logic shipped with Akka are(akka.routing.) 
final class BroadcastRoutingLogic
    Broadcasts a message to all its routees.
final case class ConsistentHashingRoutingLogic(system: ActorSystem, virtualNodesFactor: Int = 0, hashMapping: ConsistentHashMapping = ...)
    Uses consistent hashing to select a routee based on the sent message.
final class RandomRoutingLogic
    Randomly selects one of the target routees to send a message to
final class RoundRobinRoutingLogic
    Uses round-robin to select a routee.
final case class ScatterGatherFirstCompletedRoutingLogic(within: FiniteDuration)
    Broadcasts the message to all routees, and replies with the first response.
final case class TailChoppingRoutingLogic(scheduler: Scheduler, within: FiniteDuration, interval: FiniteDuration, context: ExecutionContext)
    As each message is sent to the router, the routees are randomly ordered.
class SmallestMailboxRoutingLogic
    Tries to send to the non-suspended routee with fewest messages in mailbox.

//Types 
Pool
    to create a round-robin router 
    that forwards messages to five Worker routees

Group 
    rather than having the router actor create its routees, 
    it is desirable to create routees separately and provide them to the router for its use. 
    Messages will be sent with ActorSelection to these paths.


//routingApp.conf
akka.actor.deployment {
  /parent/router_rrp {   #"router_rrp" is used in code 
    router = round-robin-pool
    nr-of-instances = 5
  }
}

akka.actor.deployment {
  /parent/router_rrg {
    router = round-robin-group
    routees.paths = ["/user/workers/w1", "/user/workers/w2", "/user/workers/w3"]
  }
}

//code 
package routing  
import akka.actor._
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import scala.concurrent.duration._
import akka.routing._
import akka.util._
import scala.util._

object Helper {
    val routingActorSystem = "RoutingSystem"
    val routingApp = "routingApp.conf"
    

    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        killThisSystemSeq(system, Seq(actor), killtime, sleeptime)
    }
    def killThisSystemSeq(system:ActorSystem, actors:Seq[ActorRef], killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actors.foreach{ actor => actor ! PoisonPill }
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}


 
case class Work(str:String)       
case class Result(str:String)       

class Master extends Actor with ActorLogging{
  var router = {
    val routees = Vector.fill(5) {
      val r = context.actorOf(Props(new Worker))
      context watch r
      ActorRefRoutee(r)   //create the routees as ordinary child actors wrapped in ActorRefRoutee
    }
    Router(RoundRobinRoutingLogic(), routees)
  }
 
  def receive = {
    case w: Work =>
      router.route(w, sender())  //Sending messages via the router is done with the route method
    case Terminated(a) =>
      router = router.removeRoutee(a)
      val r = context.actorOf(Props(new Worker))
      context watch r
      router = router.addRoutee(r)
  }
}

class Worker extends Actor with ActorLogging{
   
    def receive = {
        case Work(str) => 
            sender() ! Result(str.reverse) 
        case _ => 
    }

}

object RoutingDemo extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)

  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val firstRef = system.actorOf(Props(new Master), "master")


  for (_ <- 0 to 5){
      firstRef.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, firstRef, 1.minutes, 1*60*1000)
}
//Pool 
object RoutingDemoRRP extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrp: ActorRef = context.actorOf(FromConfig.props(Props(new Worker)), "router_rrp")
    
    override def receive: Receive = {
      case x =>
        router_rrp.forward(x)
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, parent, 1.minutes, 1*60*1000)
}
//Group 
object RoutingDemoRRG extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val workers: ActorRef = system.actorOf(Props(new Actor {
    val seqw = (1 to 4).toList.map( i => context.actorOf(Props(new Worker), name = s"w$i") )

    override def receive: Receive = {
      case x =>
       println(s"In Workers !!! $x")
    }
  }), "workers")
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrg: ActorRef = context.actorOf(FromConfig.props(), "router_rrg")
    
    override def receive: Receive = {
      case x =>
        router_rrg.forward(x)
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystemSeq(system, Seq(parent, workers), 1.minutes, 1*60*1000)
}




