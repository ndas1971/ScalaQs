Day One
1. An Introduction to Scala 2.13
    An Introduction to Scala 2.13
    New features of Scala 2.13
    Revision of core syntax vis-a-vis Java
    Designing with Scala class
    Object Comparison with Java
    The Scala 2.13 Collection Library
//2. Understanding Types in Scala
//    Understanding Types in Scala
//    Understanding types
//    Types – all the way down
//    Using types to define domain constraints
3. Deep Dive into Functions
    Deep Dive into Functions
    Ways to define a function
    Polymorphism and higher order functions
    Recursion and trampolining
    Object-oriented aspects of functions
------------------------------------------------
///*** Reference 
Learn Scala Programming by Slava Schmidt 
Functional Programming in Scala by Manning
Cats 
    https://typelevel.org/cats/
    
///*** Installation 

##->file:build.sbt:
lazy val root = (project in file(".")).
  settings(
    inThisBuild(List(
      organization := "com.example",
      scalaVersion := "2.13.5"
    )),
    addCompilerPlugin("org.typelevel" % "kind-projector" % "0.11.3" cross CrossVersion.full), 
    addCompilerPlugin("com.olegpy" %% "better-monadic-for" % "0.3.1"),
    //scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked"),
    name := "scalatest-example"
  )


val AkkaVersion = "2.6.15"
libraryDependencies += "com.typesafe.akka" %% "akka-cluster" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-cluster-tools" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-actor" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-persistence" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-remote" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-serialization-jackson" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-stream" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-stream-testkit" % AkkaVersion //% Test

libraryDependencies += "com.typesafe.akka" %% "akka-testkit" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-slf4j" % AkkaVersion

libraryDependencies += "com.typesafe.akka" %% "akka-cluster-typed" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-actor-typed" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-cluster-sharding-typed" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-persistence-typed" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-stream-typed" % AkkaVersion
libraryDependencies += "com.typesafe.akka" %% "akka-actor-testkit-typed" % AkkaVersion

libraryDependencies += "com.fasterxml.jackson.core" % "jackson-databind" % "2.11.4"
libraryDependencies += "com.typesafe.akka" %% "akka-stream-kafka" % "2.1.1"  // must be AkkaVersion = "2.6.15"

val alpakkaVersion = "3.0.4"
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-json-streaming" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-csv" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-simple-codecs" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-text" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-xml" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-file" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-ftp" % alpakkaVersion
libraryDependencies += "com.lightbend.akka" %% "akka-stream-alpakka-slick" % alpakkaVersion

libraryDependencies += "com.lightbend.akka" %% "akka-persistence-jdbc" % "5.0.0"

val akkaHttpVersion = "10.2.4"
libraryDependencies ++= Seq(
    "com.typesafe.akka" %% "akka-http-core" % akkaHttpVersion,
    "com.typesafe.akka" %% "akka-http" % akkaHttpVersion,
    "com.typesafe.akka" %% "akka-http-testkit" % akkaHttpVersion,
    "com.typesafe.akka" %% "akka-http-spray-json" % akkaHttpVersion,
    "com.typesafe.akka" %% "akka-http-jackson" % akkaHttpVersion,
    "com.typesafe.akka" %% "akka-http-xml" % akkaHttpVersion
)
libraryDependencies += "io.spray" %%  "spray-json" % "1.3.6"
libraryDependencies += "org.fusesource.leveldbjni" % "leveldbjni-all" % "1.8"
libraryDependencies += "org.slf4j" % "slf4j-simple" % "1.7.30"
libraryDependencies += "log4j" % "log4j" % "1.2.14"
libraryDependencies += "com.chuusai" %% "shapeless" % "2.3.3"
libraryDependencies ++= Seq(
 "com.github.julien-truffaut" %% "monocle-core"  % "3.0.0-M3",
 "com.github.julien-truffaut" %% "monocle-macro" % "3.0.0-M3", // Not required for Scala 3
)
libraryDependencies += "org.scala-lang.modules" %% "scala-parallel-collections" % "1.0.1"
libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.2"         // % Test
libraryDependencies += "org.typelevel" %% "cats-core" % "2.5.0"
libraryDependencies += "org.scalacheck" %% "scalacheck" % "1.15.3"      // % Test

//zio for IO Monad 
val zio_verson = "1.0.6"
libraryDependencies += "dev.zio" %% "zio" % zio_verson
libraryDependencies += "dev.zio" %% "zio-streams" % zio_verson
libraryDependencies += "dev.zio" %% "zio-process" % "0.3.0"
libraryDependencies += "dev.zio" %% "zio-json" % "0.1.4"
libraryDependencies += "dev.zio" %% "zio-nio" % "1.0.0-RC10"
libraryDependencies += "dev.zio" %% "zio-interop-reactivestreams" % "1.3.2"


//Uncomment below and comment Monix section
libraryDependencies += "org.typelevel" %% "cats-effect" % "3.0.1"
libraryDependencies += "org.typelevel" %% "cats-effect-testing-scalatest" % "1.0.1" // % Test
libraryDependencies += "co.fs2" %% "fs2-core" % "3.0.1"
libraryDependencies += "co.fs2" %% "fs2-io" % "3.0.1"
libraryDependencies += "co.fs2" %% "fs2-reactive-streams" % "3.0.1"

//MOnix depedends on below 
//libraryDependencies += "io.monix" %% "monix" % "3.3.0"
//val monix_catsEffect_Version = "2.4.1"
//val monix_fs2_Version = "2.4.4"
//libraryDependencies += "org.typelevel" %% "cats-effect" % monix_catsEffect_Version
//libraryDependencies += "co.fs2" %% "fs2-core" % monix_fs2_Version
//libraryDependencies += "co.fs2" %% "fs2-io" % monix_fs2_Version
//libraryDependencies += "co.fs2" %% "fs2-reactive-streams" % monix_fs2_Version



libraryDependencies += "org.typelevel" %% "cats-free" % "2.5.0"
libraryDependencies ++= Seq(
  "org.typelevel" %% "cats-laws" % "2.4.2" , //% Test,
  "com.github.alexarchambault" %% "scalacheck-shapeless_1.14" % "1.2.3" ,// % Test
  "org.typelevel" %% "discipline-scalatest" % "2.1.3" //% Test
)

libraryDependencies += "com.typesafe.play" %% "play-json" % "2.8.1"  //excludeAll(excludejackson) // add more exclusions here
//libraryDependencies += "org.micchon" %% "play-json-xml" % "0.3.0"
libraryDependencies += "com.typesafe.play" %% "play-ahc-ws-standalone" % "2.1.3"
//To add XML and JSON support using Play-JSON or Scala XML to WS, add the following:
libraryDependencies += "com.typesafe.play" %% "play-ws-standalone-xml" % "2.1.3"
libraryDependencies += "com.typesafe.play" %% "play-ws-standalone-json" % "2.1.3"
libraryDependencies ++= List(
  "com.typesafe.slick" %% "slick" % "3.3.3",
  "com.h2database" % "h2" % "1.4.197",
  "com.typesafe.slick" %% "slick-hikaricp" % "3.3.3",
  "com.softwaremill.akka-http-session" %% "core" % "0.6.1"
)




/*

ThisBuild / organization := "com.example"
ThisBuild / version := "1.0-SNAPSHOT"
ThisBuild / scalaVersion := "2.13.5"

//these should contain build.sbt etc 
lazy val sbtProject1 = RootProject(file("../AnotherProject"))

lazy val sbtProject2 = RootProject(file("../OtherProject"))

lazy val mainProject = project.in(file(".")).settings(
  scalacOptions ++= Seq("-deprecation", "-feature", "-unchecked"),
  libraryDependencies += "org.scalacheck" %% "scalacheck" % "1.14.0" withSources() withJavadoc(),
  addCompilerPlugin("org.typelevel" % "kind-projector" % "0.11.3" cross CrossVersion.full)
).dependsOn(sbtProject1, sbtProject2)

*/

//assembly

fork := true

retrieveManaged := true

assemblyJarName in assembly := "learning-assembly.jar"

assemblyOption in assembly := (assemblyOption in assembly).value.copy(includeScala = false)

assemblyMergeStrategy in assembly := {
  case PathList("javax", "servlet", xs @ _*)         => MergeStrategy.first
  case PathList(ps @ _*) if ps.last endsWith ".html" => MergeStrategy.first
  case "application.conf"                            => MergeStrategy.concat
  case "unwanted.txt"                                => MergeStrategy.discard
  case m if m.toLowerCase.endsWith("manifest.mf")    => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".rsa") 			 => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".dsa") 			 => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".sf") 			 => MergeStrategy.discard
  case _ 											 => MergeStrategy.first
}

##for scala3 
val scala2Version = "2.13.6"
val scala3Version = "3.1.0"
val catsVersion = "2.7.0"

lazy val root = project
  .in(file("."))
  .settings(
    name := "scala3Experiment",
    version := "0.1.0",

    libraryDependencies += "com.novocode" % "junit-interface" % "0.11" % "test",
    libraryDependencies ++= Seq("org.typelevel" %% "shapeless3-deriving" % "3.0.1"),    
    libraryDependencies += "org.scala-lang.modules" %% "scala-xml" % "2.0.1",
    libraryDependencies += "org.scalacheck" %% "scalacheck" % "1.15.4",
    libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.10"  , //% Test, 
    libraryDependencies += "org.typelevel" %% "cats-free" % catsVersion,
    libraryDependencies += "org.typelevel" %% "cats-core" % catsVersion ,
    libraryDependencies ++= Seq(
      "org.typelevel" %% "cats-laws" % catsVersion , //% Test,      
      "org.typelevel" %% "discipline-scalatest" % "2.1.5" //% Test
    ),    
    // To make the default compiler and REPL use Dotty
    scalaVersion := scala3Version,
    
    //scalacOptions += "-Yexplicit-nulls"
    //scalacOptions += "-Xprint:typer",

    // To cross compile with Dotty and Scala 2
    //crossScalaVersions := Seq(scala3Version, scala2Version)
  )


//assembly
//check in replaced by / 
//https://www.scala-sbt.org/1.x/docs/Migrating-from-sbt-013x.html#slash

fork := true

retrieveManaged := true

assembly / assemblyJarName := "learning-assembly.jar"

assembly / assemblyOption := (assembly / assemblyOption).value.copy(includeScala = true)

assembly / assemblyMergeStrategy  := {
  case PathList("javax", "servlet", xs @ _*)         => MergeStrategy.first
  case PathList(ps @ _*) if ps.last endsWith ".html" => MergeStrategy.first
  case "application.conf"                            => MergeStrategy.concat
  case "unwanted.txt"                                => MergeStrategy.discard
  case m if m.toLowerCase.endsWith("manifest.mf")    => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".rsa") 			 => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".dsa") 			 => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".sf") 			 => MergeStrategy.discard
  case _ 											 => MergeStrategy.first
}


##->file:project\build.properties:
sbt.version=1.4.9



##->file:project\plugins.sbt:
addSbtPlugin("com.eed3si9n" % "sbt-assembly" % "0.15.0")

////--------------An Introduction to Scala 2.13---------------------------------------------------------------------------------------------
1.       An Introduction to Scala 2.13
·       An Introduction to Scala 2.13
·       New features of Scala 2.13
·       Revision of core syntax vis-a-vis Java
·       Designing with Scala class
·       Object Comparison with Java
·       The Scala 2.13 Collection Library
///*** General 

///inference 
val a = 1
var b = 1

println(s"${a} and $b")
//or with format , f"$v%2.2f ${v2.method}%2.2f"
println(f"${a}%d and $b%03d")

///Numeric types 

//Everything is class , no primitive types and operators are actually methods 
1 + 2
//=>
1.+(2)

//Int, Boolean, Double, Float, BigInt,BigDecimal, Byte, Char, Short, Long  and their Rich*
//conversion, toInt, toFloat

//Rich type has many methods(eg abs, longValue, isValidLong etc) , these are automatically called on base type
Check Int and RichInt  -Reference (RichInt is merged with Int documentation)

1. ==, != is used for content checking
   == calls def equals(other:Any):Boolean method internally. 
  Overload this if required
  
2. eq, ne is used for object identity only for AnyRef 

//Scala Type 
scala.Any , abstract  class  Any ( != , ==, toString, ##, asInstanceOf[], isInstanceOf[], equals, hashCode)
	Nothing  (type represents nothing, no instance)
	scala.AnyRef (java.lang.Object) (overrides Any methods as final, eq , ne , notify, notifyAll, synchronized, wait)
		java.lang.String
		Array
		java.lang.Number
			java.lang.Integer
			....
		Other java classes
		scala.Seq
			...Collections
		scala.Option
		... other scala classes
		Null (with instance null )
	scala.AnyVal , only method is getClass()
		scala.Int
		scala.Double
		scala.Float
		scala.Unit
		scala.Char
		scala.Long
		scala.Byte
		scala.Boolean

//use d, f, L as suffix, default Int and double 
BigInt("111111111111")
1.0  //Double 
1    //Int
1.0f 
1L 

///Scala Class 
//val - can be 'get' only , var- can be 'get' and 'set', none - can not be 'get' or 'set'
//default - public or mention private 
// def m =... , can only be called as .m 
//but def m()=.., can be called as .m or .m(), but use .m() (in scala3 - must)


// By default , following is generated 
//val - accessor method, var- Accessor and mutator , none - nothing 
//x is instance 
//				expansion
x.f 			x.f or 'def f' under x
x.f = e 		x.f_=(e) 
x() = e 		x.update(e) 
x(i) = e 		x.update(i, e) 
x(i, j) = e 	x.update(i, j, e) 
x()				x.apply()
x(i)			x.apply(i)	
CLASS(i)        apply(i) inside object CLASS 	

//Must be in same file, in REPL use :paste 

// (1) primary constructor
class Animal ( val name: String, val age: Int) {
    Animal.howmany += 1
    // (2) auxiliary constructor
    //scala3: def this (name: String) = {
    def this (name: String) {
        this(name, 0)
    }
    def talk ="talk?"
    override def toString = s"$name is $age years old"
}
//apply() is must if not having generic type 
object Animal {     
  private var howmany = 0                         
  def apply() = new Animal("Default")
  def apply(name: String, age: Int) = new Animal(name, age)
  def how_many_created = howmany
}

val an = new Animal("ABC", 20) //scala3: new is not required only if no user defined companion object
an.name 
an.age 
an.talk 
val an = Animal()


//Test 
//https://www.scalatest.org/at_a_glance/FlatSpec
As of now no final for scala3 , check here 
https://mvnrepository.com/artifact/org.scalatest/scalatest

//scala2 
libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.2"   

import org.scalatest._
import matchers.should._
import funsuite._

class AnimalTest extends AnyFunSuite  with BeforeAndAfter with Matchers {     

  // Fixtures as reassignable variables and mutable objects
  var object1:Animal = _
  //scala3:
  // import scala.compiletime.uninitialized
  //var object1:Animal = uninitialized
  
  before {
      //modify
      object1 = Animal("ABC", 20)
  }

  test("Animal talk") { assert(object1.talk == "talk?") }
}

scala> org.scalatest.run(new AnimalTest)


///Inheritance, extends Base ( only one base class)

//Donot mention val or var for fields that are common to Base class


//val can be overridden by val, var can not be,
// def can be by def or val


// Auxiliary constructors in subclass can not call a superclass constructor.
//Auxiliary constructor can only call primary constructor or earlier defined constructor of same class

//in first line of subclass(ie class..), subclass can call any ctor of base class 
// calls the Animal one-arg constructor

//scala3, Must use 'open' in Base class 
//OR  import scala.language.adhocExtensions   here      OR Use  compiler option -language:adhocExtensions. 
class Dog (name: String, val owner:String) extends Animal (name) {
        override def toString = s"Dog: $name is $age years old"
        def this() {this("No-name", "no owner")}   //can only call own ctor 
        override def talk = {
            super.talk +  "Dog talk"
        }
}
//def by val 
class Dog (name: String) extends Animal (name) {
        override def toString = s"Dog: $name is $age years old"
        def this() {this("No-name")}   //can only call own ctor 
        override val talk = "OK"
}

val dn = new Dog()
dn.owner
dn.talk
 
///In override, return type can be changed (in scala3, returntype is from base class)

class Foo

class RichFoo(foo: Foo) extends Foo {
  def show: String = ""
}

class Parent {
  def foo: Foo = new Foo
}
//Return type is RichFoo in scala2.13, Foo in scala3
//Better to explicitly mention 
class Child extends Parent {
  override def foo = new RichFoo(super.foo) 
}

(new Child).foo.show //OK in scala2, NOK in scala3





///Case class (no 22 limits in 2.13+scala3)
//Case classes to generate copy/hashcode/equal/apply code (along with companion object)
//Case class constructor parameters are val by default
//case class does not allow to  inherit from a case class. 
//but can inherit from a non case class

//must use () 
case class A //<console>:1: error: case classes without a parameter list are not allowed;

case object A //OK

case class Animal2 ( val name: String, val age: Int) {
      def talk ="talk?"
	  override def toString = s"$name is $age years old"
}

val an = Animal2("A", 2)
an.name
an.age
val an2 = an.copy(age=20)
  



///Trait 
trait A{
    def name:String 
    def print2 = println(this.name)
}
class D extends A {
    def name = "OK"
    override def print2 = println(s"Hello ${this.name}")
}

val d2 = new D; d2.print2 ; //new implementation
val d = new A{
    def name = "OK"
}
d.print2  //default



///pre initalized field - (scala3 it is removed)
class D 

trait T1 {
    val x:Int 
    val y:Int 
}
//here RHS has to be const 
val d = new T1{
    val x = 2 
    val y =3 
}
val d2 = new D with T1 {
    val x = 2 
    val y =3 
}
//OR expr can be used 
val d2 = new  {
    val x = 2 
    val y =3 
} with T1 

class E extends {
    val x = 2 
    val y =3 
} with T1 {
    val z = 30 
}


///Abstract Class
//When to Use an Abstract Class instead of trait
1.You want to create a base class that requires constructor arguments.
2.The code will be called from Java code.

// this won't compile
trait Animal(name: String)

//Solution
abstract class Animal(name: String)


///Assigning a Field to a Block or Function and Lazy variable

class X { val x = { Thread.sleep(2000); 15 } }

class Y { lazy val y = { Thread.sleep(2000); 13 } }
new X      //waiting
new Y      //immediate
(new X).x     //immediate
(new Y).y    //waiting

///initialization
//-Xcheckinit: Add runtime check to field accessors (only for testing as code size increases)

//superclass constructor is called first with overridden val/var as null
//no need to mention 'abstract' modifier, simply leave the definition
abstract class X {
    val x: String  
    println ("x is "+ x.length)  // in primary constructor, x is still null
}

object Y extends X { val x = "Hello" }   

Y   //Exeptions 

//Solution use lazy either in X or in Y 
//or use preinitialized fields (scala3-dropped)
object Y extends X { lazy val x = "Hello" }
object Y extends { val x = "Hello" } with X

Y   //OK


///Private constructor, singleton pattern
class Brain private {
    override def toString = "This is the brain."
}

object Brain {
    private val brain = new Brain
    def getInstance = brain
}




///if 
val absValue = if (a < 0) -a else a

if (true) "S"   //Return type Any

if (true) "S" else throw new Exception("Whoops!")   // Return type is String as else return type is Nothing

//Nothing -> [Int] -> ... -> AnyVal -> Any

//If no else, then put null (only for Reference type, for any other general type, throw new Exception) , such that return type comes from if block

if (true) "S" else null

///for 
for (i <- 1 to 10) println(i)
for (i <- 1 until 10 ) println(i)
for (i <- 1 to 10 by 2 ) println(i)

for (i <- 1.0 to 10.0 by 2.0 ) println(i)
//Can use guard statement as well 

for {i <- 1 to 10  if i % 2 == 0
   x = i * i                     //no val, is deprecated
   j <- 1 to x    if j % 2 == 1
 }
{
  val y = i*i
  println(s"$y -> $j") 
 }
///while 
var a = 10;

// while loop execution
while( a < 20 ){
         println( "Value of a: " + a )
         a = a + 1
}

///Function - Parametrized function
//No explicit return is required , last line is return (in Recursion and if return type is mentioned, Must required)

def f(x:Int, y:Int):Int = {
    return x+y
 }

def f(x:Int, y:Int) = {
   x+y
 }

def f(x:Int, y:Int) =  x+y


f(2,3)
f(y=3,x=2)
f(2,y=3)

def f(x:Int, y:Int = 20) =  x+y
f(2)
f(2,3)


/// Creating Methods That Take Variable-Argument, 
//Last arg should be *
// version 1
def printAll(numbers: String*) {  //numbers becomes Seq<String>
        for (i <- numbers) println(i)
      }
      
def printAll[T](numbers: T*) {  //numbers becomes Seq<T>
        for (i <- numbers) println(i)
      }
//var args must be last and only one
def printAll(strings: String*, i: Int) //error

// these all work
printAll()
printAll("foo")
printAll("foo", "bar")
printAll("foo", "bar", "baz")


// Use : _* to adapt a sequence (Array, List, Seq, Vector, etc.)
// to unpack for sequence of strings (only allowed if corresponding arg is T* in definition)

val fruits = List("apple", "banana", "cherry")

// pass the sequence to the varargs field
printAll(fruits: _*)
//Note, do below 
printAll(("OK" +: fruits): _*)
//To add extra args, instead of below 
//printAll("OK", fruits: _*)

///Call by 
def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0) + "ns")
    result
}

// Now wrap your method calls, for example change this...
val result = 1 to 1000 sum

// ... into this, if block is not used as call by name , then block execution happens outside of time function 
val result = time { 1 to 1000 sum }

///Tuple - mixed type, immutable - 22 limits 
//For operation like Dynamic types, use Tuple or case class 
//Tuple2(x,y) or x -> y or (x,y)
//Tuple3(x,y,z) or (x,y,z) ... so on till 22 (inscala3, limit 22 is removed)

val x = (1,2)
val x = 1 -> 2
x._1
x._2

//pattern matching 
val Tuple2(x,y) = (1,2)
//or
val (x,y) = (1,2)

///Defining a Method That Returns Multiple Items ( use Tuples)

def getStockInfo = ("NFLX", 100.00)

val (symbol, currentPrice) = getStockInfo  //de-structuring of tupple happens only at 'val/var' definition not at 'var' reassignment

val result = getStockInfo
result._1
result._2




///Char and String and  interpolation
// Scala has Char type (java Character), eg 'A'

//Strings - " "  or multiline """ """
// raw string as raw"  "

//size, union, stripLineEnd, isEmpty, reduceRightOption,  
//contains, split, replace
//To get character str(index), length, size, > , < , 
//count(func), find(func), foreach, flatMap, map
// and all sequence operators
//conversion to other type  - toInt, toArray etc

var name = null.asInstanceOf[String]  //null String
val name:String = null

//accessing
"OK"(0)   //res19: Char = O
val a = "OK"  //a: String = OK
a(0) = 1  //<console>:10: error: value update is not a member of String
          
"    A   ".trim 
"OK".size 
"abc".capitalize
"abc".indexOf("b")


//splitting various ways- split takes regex
"""OK 
   OK
   OK""".split("\\n")   //res8: Array[String] = Array(OK, OK, OK)


///HANDSON - Given a string 
val s = "Hello World Hello"
//can you print each word and it's frequency 
val wds = s.split(raw"\s+")

for (c <- wds) {
 var count = 0
 for (c1 <- wds){
	if (c == c1) {
		count = count + 1
	}	
 }
  println(s"${c} counts ${count}")
}

//in scala way  
s.toArray.map(e => (e, s.count(x => x ==e))).toMap

s.toArray.map(e => (e, s.count(_ == e))).toMap

s.toArray.map(e => (e, s.count(_ == e))).filter( _ != ' ').toMap
//dont do below, not works 
s toArray map {e => (e, s count _==e ) } 

///Java vs Scala - Then Display 
1. Display 1.coreDocs/Java-Scala.docx



///*** Scala2.13 
///New features of Scala 2.13
Optional parsing for string literals, 
Adding names-reporting functions to case classes, 
Methods for chaining operations, 
Automatic resource-management.


///Optional parsing for string literals in StringOps

"10".toIntOption        //res3: Option[Int] = Some(10)
"TrUe".toBooleanOption  //res4: Option[Boolean] = Some(true)
val bool = "Not True"   
bool.toBooleanOption    //res5: Option[Boolean] = None

///Products can report the names of their element by productElementName(idx)

case class User(name: String, surname: String, email: String)

def naiveToJsonString(p: Product): String =
 (for { i <- 0 until p.productArity } yield
   s""""${p.productElementName(i)}": "${p.productElement(i)}"""")
   .mkString("{ ", ", ", " }")

val user = User("John", "Doe", "jd@mail.me")
//user: User = User(John,Doe,jd@mail.me)
naiveToJsonString(user)
//res1: String = { "name": "John", "surname": "Doe", "email": "jd@mail.me" }

Unfortunately, the method taking an index of the element throws an exception in the case
that the index is invalid:
scala> user.productElementName(3)
java.lang.IndexOutOfBoundsException: 3
at User.productElementName(<console>:1)
... 38 elided

///Added methods for chaining operations - tap an pipe methods to any instance 
ChainingOps[A] extends AnyVal
    def pipe[B](f: (A) => B): B
        Converts the value by applying the function f.
    def tap[U](f: (A) => U): A
        Applies f to the value for its side effects, and returns the original value.


//Example 
import scala.util.chaining._

def pipe[B](f: (A) => B): B
    Converts the value by applying the function f.
def tap[U](f: (A) => U): A
    Applies f to the value for its side effects, and returns the original value.
    
"Hello".tap( x => println(x)).pipe( x => x.size).tap( i => println(i)).pipe(2 + _)

//Example 
object UserDb {
 case class User(name:String) 
 def getById(id: Long): User = User("ABC")
 def update(u: User): User = User("ABC")
 def save(u: User): Boolean = true
}


import UserDb._
val userId = 1L

save(update(getById(userId)))
//pipe allows us to represent this in a more readable format:
getById(userId).pipe(update).pipe(save)
//OR using tap 
getById(userId).tap( user => println(user)).pipe(update).pipe(save)

//OR 
val doEverything = (getById _).andThen(update).andThen(save)
doEverything(userId)

//Example 
import scala.util.chaining._
val lastTick = new java.util.concurrent.atomic.AtomicLong(0)


def measure[A](a: A): Unit = {
    val now = System.currentTimeMillis()
    val before = lastTick.getAndSet(now)
    println(s"$a: ${now-before} ms elapsed")
}

def start(): Unit = lastTick.set(System.currentTimeMillis())

start()
val result = scala.io.StdIn.readLine().pipe(_.toIntOption).tap(measure)

None: 291 ms elapsed

val anotherResult = scala.io.StdIn.readLine().pipe(_.toIntOption).tap(measure)

Some(3456): 11356 ms elapsed
anotherResult: Option[Int] = Some(3456)



///Automatic Resource Management using scala.util.Using
'Using' is a class that takes some resources as a by-name parameter. The resource can be
anything that has a type class instance for scala.util.Resource available. Such an
instance for java.lang.AutoCloseable is provided in the standard library. 

//Example 
import scala.util.{Try, Using}
final case class Resource(name: String) extends AutoCloseable {
    override def close(): Unit = println(s"Closing $name")
    def lines = List(s"$name line 1", s"$name line 2")
}

val List(r1, r2, r3) = List("first", "2", "3").map(Resource(_))  

//Note in scala, spreading only works with var args 
//resources[R1, R2, R3, A](resource1: R1, resource2: => R2, resource3: => R3)(body: (R1, R2, R3) => A)(implicit arg0: Releasable[R1], arg1: Releasable[R2], arg2: Releasable[R3]): A
val lines:List[String] = Using.resources(r1,r2,r3)( (u1,u2,u3) => (u1.lines ++ u2.lines ++ u3.lines))

Closing 3
Closing 2
Closing first
lines: scala.util.Try[Seq[String]] = Success(List(first line 1, first line 2, 2 line 1, 2 line 2, 3 line 1, 3 line 2))

//or 
val lines: Try[Seq[String]] = Using.Manager { use =>
    val List(r1, r2, r3) = List("first", "2", "3").map(Resource(_)).map(use(_))
    r1.lines ++ r2.lines ++ r3.lines
}    

//OR 
import java.io.{BufferedReader, FileReader}
import scala.util.{Try, Using}

val lines: Try[Seq[String]] =
  Using(new BufferedReader(new FileReader("file.txt"))) { reader =>
    Iterator.continually(reader.readLine()).takeWhile(_ != null).toSeq
  }  //success or failure 
  
//OR 
val lines: Seq[String] =
  Using.resource(new BufferedReader(new FileReader("file.txt"))) { reader =>
    Iterator.continually(reader.readLine()).takeWhile(_ != null).toSeq
}//without success and failure, but raises exception 
  
//Multiple files 
import java.io.{BufferedReader, FileReader}
import scala.util.{Try, Using}

val lines: Try[Seq[String]] = Using.Manager { use =>
  val r1 = use(new BufferedReader(new FileReader("file1.txt")))
  val r2 = use(new BufferedReader(new FileReader("file2.txt")))
  val r3 = use(new BufferedReader(new FileReader("file3.txt")))
  val r4 = use(new BufferedReader(new FileReader("file4.txt")))

  // use your resources here
  def lines(reader: BufferedReader): Iterator[String] =
    Iterator.continually(reader.readLine()).takeWhile(_ != null)

  (lines(r1) ++ lines(r2) ++ lines(r3) ++ lines(r4)).toList
}

///The Scala 2.13 Collection Library
IterableOnce[+A]
    Iterable[+A]    //Mutable and Immutable 
        Map[K, +V]  //Mutable and Immutable 
        Set[A]      //Mutable and Immutable 
        Seq[+A]     //Mutable and Immutable 

These traits cover only the structural characteristics. The operations defined for the specific type are placed in the
helper traits carrying the Ops suffix in the name. ie 

IterableOnceOps[+A, +CC[_], +C]
    IterableOps[+A, +CC[_], +C]    
        MapOps[K, +V, +CC[_,_] <: IterableOps[_, AnyConstr, _], +C]  
        SetOps[A, +CC[X], +C < SetOps[A, CC, C]]      
        SeqOps[+A, +CC[_], +C] 
        
//Performance checking 
https://www.lihaoyi.com/post/BenchmarkingScalaCollections.html#vectors-are-ok
        
//Details 
IterableOnce[+A]
    Iterable[+A] 
      abstract def iterator: Iterator[A]
        Set 
            ListSet 
            HashSet
                LinkedHashSet
            SortedSet 
                TreeSet 
                BitSet 
                
        Map 
            SortedMap 
                TreeMap 
            HashMap 
            SeqMap 
                ListMap 
                VectorMap 
                LinkedHashMap
            MultiMap 
            
        Seq 
            IndexedSeq
                Range 
                Vector 
                WrappedString 
                ArraySeq 
                    ofRef 
                    ofChar
                    ofByte 
                    ofBoolean 
                    ofUnit
            LinearSeq
                List 
                LazyList 
                Queue 
            Buffer  
                ListBuffer 
                        
            Buffer + IndexSeq             
                IndexBuffer 
                ArrayBuffer 
                ArrayDeque
                    Queue 
                    Stack 
        

trait Iterator[+A] 
    abstract def hasNext: Boolean
        Check if there is a next element available.
    abstract def next(): A
        Return the next element and advance the iterator.
            
///Scala Collection Contrib library
https://github.com/scala/scala-collection-contrib 

The Scala Collection Contrib module is Scala
way of having both a stable standard library and some extra features. 

Currently, there are four collection types available in the module, each both mutable and
immutable:
  MultiDict
  SortedMultiDict
  MultiSet
  SortedMultiSet
  
  
///Using collection 
where S is Array, List, Seq, Set,....
Note 'object' can not take T, hence if required, mention T as part of method 
ex :  val m = collection.mutable.ListBuffer.fill(256)( null :Any); m(0) = "OK" ..

Note Type parameter is must sometimes eg 
val a = List.empty[Int]

S.empty[T] 						The empty sequence
S(x, y, z) 						A sequence consisting of elements x, y, and z - variable args 
S.concat(xs, ys, zs) 			The sequence obtained by concatenating the elements of xs, ys, and zs - variable args 
S.fill[T](n)(e) 				A sequence of length n where each element is computed by expression e
S.fill[T](m, n)(e) 				A sequence of sequences of dimension m x n where each element is computed by expression e (exists also in higher dimensions)
S.tabulate(n)(f) 				A sequence of length n where the element at each index i is computed by f(i)
S.tabulate(m, n)(f) 			A sequence of sequences of dimension m x n	where the element at each index (i, j) is computed  by f(i, j) (exists also in higher dimensions)
S.range[T](start, end) 			The sequence of integers start : : : end 
S.range[T](start, end, step) 	The sequence of integers starting with start and progressing by step increments up to, and excluding, the end value
S.iterate(x, n)(f) 				The sequence of length n with elements x, f(x), f(f(x)),...

//Example 
List.empty[Int]
List.fill(2)(3)
List.tabulate[Int](2)((i)=>3)


/// Array  - java core Array 
//fixed size, mutable, All collection methods can be used via ArrayOps implicits 
//runtime keeps Type , hence no type erasure 
//Array can be implicitly converted to Seq 

reflect.runtime.universe.typeOf[Array[Int]].members.toSet
reflect.runtime.universe.typeOf[collection.mutable.ArrayOps[Int]].members.toSet


//Usage - ++, :+, +: etc 
//genally single operation like + for one element 
//for multiple operations like ++, for another Collection 
// :+ where LHS is array , +: where RHS is array 

// Can use Array.empty, Array.fill etc 
val a = Array(1,2,3,4)
println(a.min)
a(0)  //res6: Int = 1
a(0) = 2
a contains 2  //res9: Boolean = true
Array.empty[Int]
Array.empty[Int] ++ Array.empty[Int]
Array.empty[Int] :+ 2
for(i <- a)println(i)


///Array Buffers - can grow in size by appending , but fast like Array
//operationWith suffix = for updating 
val buf = scala.collection.mutable.ArrayBuffer.empty[Int]
buf += 1
buf += 10
buf ++= Array(2,10)
buf.toArray

///HandsOn
package examples

object DayN {
  //Json 
  // val str = "[1,2,3,4]"
  // Array(1,2,3,4)
  def parseArray(str:String):Array[Int] = {
  
    //import scala.collection.mutable.ArrayBuffer
    import scala.collection.mutable._  // instead of * as in Java    
    
    val res = ArrayBuffer.empty[Int]
    val inA = str.stripPrefix("[").stripSuffix("]").split(',').toArray
    for ( i <- inA ){
        res += i.toInt
    }
    res.toArray
  }
  
}
			  

///List - List and collection.mutable.ListBuffer
//Insertion ordered, Indexing with (Int),
reflect.runtime.universe.typeOf[List[Int]].members.toSet

//Main Methods, slice(start,until) ,contains, 
// isEmpty,  List[Int](),   ++, +:, :+, ::, ++:
//Mutable methods  +=, ++=, -=, --=
//Conversion  toList, toMap, toSet, toArray

//genally single operation like + for one element 
//for multiple operations like ++, for another Collection 
// :+ where LHS is List , +: where RHS is List  


//shift -  stripFront
//unshift(prepend) - +:
//pop - stripEnd
//push - append or :+


val L = List(1,2,3)
val L = 1 :: 2 :: Nil
val L2 = 1 +: L :+ List(55,66)
L ++ List(2,3)
val L2 = 1 +: L :+ 55

val L = scala.collection.mutable.ListBuffer[Int]()
L += 2
L(0)
L(0) = 3
L contains 3

val l = 1 :: Nil
l(0)
l.head
l.tail
List(1,2,3,4).slice(1,3)  //no step 

//Append 
val L = scala.collection.mutable.ListBuffer[Int]()
L += 2
L ++= List(2)
L.append(2)

//Iterating 
val a = List((1,2,5),(2,3,4))
for( (i,j,k) <- a) println(s"$i,$j,$k")



///Hands ON - square each element 
val a = List(1,2,3,4)
val res = collection.mutable.ListBuffer.empty[Int]
for(i <- a) {
     val z = i*i
     res += z
    }

///Map   - Map or mutable.Map 

//Main Methods - mutable +=, ++=, -=, --=  
//or immutable ++, contains, ++:, ++, 

//genally single operation like + for one element 
//for multiple operations like ++, for another Collection 
// :+ where LHS is Map , +: where RHS is Map  

//For Map - call keys(), values() to get keys and values
//toList gives tupleSet

val m = Map('o'-> 1, 'b' -> 2)
m ++ Map('c'-> 3)
m +('c'-> 3)

//Mutable 
val m = collection.mutable.Map[String,Int]()
m("OK") = 2
m += ("NOK" -> 3)
m contains "OK"
m contains "OKK"
for( (k,v) <- m) println(""+k+v)
m.keys   //res30: Iterable[Char] = Set(o, b)
m.values  //res31: Iterable[Int] = MapLike(1, 2)
m.toList  //res34: List[(Char, Int)] = List((o,1), (b,2))

//With default
val m = Map[String, Int]().withDefaultValue(0)
m("OK")  //res0: Int = 0

//mutable.HashSet and mutable.HashMap 
//- No order for iteration, but fast lookup
val map = scala.collection.mutable.HashMap.empty[Int,String]
map += (1 -> "make a web site")
map += (3 -> "profit!")
map(1)  //res44: String = make a web site
map contains 2  //res46: Boolean = false


///Concurrent Map - All operations are atomic, hence can be accessed by multiple threads
//mutable 
val s = scala.collection.concurrent.TrieMap[Int,Int]()
s(0) = 2 
s(0)
s contains 0 
//All Map operations are possible(but atomic) and  below new methods
m.putIfAbsent(k, v) 	
    Adds key/value binding k -> v unless k is already defined in m 
m.remove (k, v) 		
    Removes entry for k if it is currently mapped to v. 
m.replace (k, old, new) 
    Replaces value associated with key k to new, if it was previously bound to old. 
m.replace (k, v) 		
    Replaces value associated with key k to v, if it was previously bound to some value. 

//Note below operations of Map are atomic
def  getOrElse(key: K, default: => V): V 
    Returns the value associated with a key, or a default value 
    if the key is not contained in the map. 
def  getOrElseUpdate(key: K, op: => V): V 
    If given key is already in this map, returns associated value.
    Otherwise, computes value from given expression op, 
    stores with key in map and returns that value.


  
//OR USE java.util.concurrent.ConcurrentHashMap
val d =  new java.util.concurrent.ConcurrentHashMap[Int,String]()

d.put(1, "OK")
d.get(1)
Option(d.get(1))
Option(d.get(0))
d containsKey 1
d containsKey 0

//Note there is no concurrent List or Set , Don't use collection.mutable.Synchronized* trait as not realiable 
//Use below from Java 
java.util.concurrent.ConcurrentLinkedQueue   instead of  SynchronizedBuffer
java.util.concurrent.ConcurrentHashMap(better TrieMap) instead of SynchronizedMap
java.util.concurrent.ConcurrentSkipListSet instead of SynchronizedPriorityQueue
java.util.concurrent.ConcurrentLinkedQueue instead of SynchronizedQueue
java.util.concurrent.ConcurrentHashMap instead of SynchronizedSet
java.util.concurrent.LinkedBlockingDequeue instead of SynchronizedStack

///stack 
scala> val stack = new scala.collection.mutable.Stack[Int]           
stack: scala.collection.mutable.Stack[Int] = Stack()
scala> stack.push(1)
res0: stack.type = Stack(1)
scala> stack
res1: scala.collection.mutable.Stack[Int] = Stack(1)
scala> stack.push(2)
res0: stack.type = Stack(1, 2)
scala> stack
res3: scala.collection.mutable.Stack[Int] = Stack(1, 2)
scala> stack.top
res8: Int = 2
scala> stack
res9: scala.collection.mutable.Stack[Int] = Stack(1, 2)
scala> stack.pop    
res10: Int = 2
scala> stack    
res11: scala.collection.mutable.Stack[Int] = Stack(1)
///Queue 
scala> val queue = new scala.collection.mutable.Queue[String]
queue: scala.collection.mutable.Queue[String] = Queue()
scala> queue += "a"
res10: queue.type = Queue(a)
scala> queue ++= List("b", "c")
res11: queue.type = Queue(a, b, c)
scala> queue
res12: scala.collection.mutable.Queue[String] = Queue(a, b, c)
scala> queue.dequeue
res13: String = a
scala> queue
res14: scala.collection.mutable.Queue[String] = Queue(b, c)
///bitset 
scala> val bits = scala.collection.mutable.BitSet.empty
bits: scala.collection.mutable.BitSet = BitSet()
scala> bits += 1
res49: bits.type = BitSet(1)
scala> bits += 3
res50: bits.type = BitSet(1, 3)
scala> bits
res51: scala.collection.mutable.BitSet = BitSet(1, 3)

///With java collections 
def nums = {
              var list = new java.util.ArrayList[Int]()
              list.add(1)
              list.add(2)
              list  
          }
//Below is removed 
//import scala.collection.JavaConversions._
//nums.toSet

//import collection.JavaConverters._
import scala.jdk.CollectionConverters._
nums.asScala.toSet.asJava

///Serialization 
// create a serializable Stock class
@SerialVersionUID(123L)
class Stock(var symbol: String, var price: BigDecimal) extends Serializable {
    override def toString = f"$symbol%s is ${price.toDouble}%.2f"
}


object SerializationDemo extends App {

    // (1) create a Stock instance
    val nflx = new Stock("NFLX", BigDecimal(85.00))

    // (2) write the instance out to a file
    val oos = new ObjectOutputStream(new FileOutputStream("/tmp/nflx"))
    oos.writeObject(nflx)
    oos.close

    // (3) read the object back in
    val ois = new ObjectInputStream(new FileInputStream("/tmp/nflx"))
    val stock = ois.readObject.asInstanceOf[Stock]
    ois.close

    // (4) print the object that was read back in
    println(stock)

}

///Pattern Matching 
object Twice {                              
  def apply(x: Int): Int = x * 2
  //unapply is first priority and then unapplySeq, 
  //so both existing on object do not work
  def unapply(z: Int): Option[Int] = Some(z/2)   //Must return Option type, scala would remove Option when giving result 
}

val x = Twice(21)   // x = 42  //apply
val Twice(y) = 22   //y is 11  //unapply 
var Twice(y1) = 22   // y1 is 11 //unapply 

object M {
  def apply(a: String*) = a.mkString(":") // makes a M from an As.
  def unapplySeq(m: String): Option[Seq[String]] = Some(m.split(":") )// retrieve the As from the M
}
val m = M("Ok", "nok")  //m: String = Ok:nok
val M(s,a) = "ok:nok"  //s: String = ok a: String = nok

x match { case Twice(n) => Console.println(n) }   //unapply 
m match { case M(a1, a2) => true }  //unapply 
m match { case obj @ M(a, aes @ _*) => s"$obj $a $aes" } 


case class Person(first:String, sec:String)
case object Request 

def extract(o:Any) = o match {
    case 0 | 1 | 2 => s"alternate"
    case Request => s"Request"
    case Twice(x) => s"Twice $x"  //unapply z/2
    case List(1,_,_) => s"List three"
    case a @ List(x,y @ _*) => s"$a $x $y"
    case Person("X", s ) => s"Person $s"
    case (x,y) if x == y => s"tuple same"
    case (x,y)  => "tuple"
    case x:String => "string"
    case x: Array[String] => "array string"
    case l : Seq[_]  => "seq"
    case ((x,y),(z,a),b)  => s"nested"
    case _ => "none"
}

//Scala2.13 
val y = "ram@jho"
y match {
        case s"$a@$b" => println(a+b)
     }
//ramjho

//Equivalent not there for f"" eg "$a%02d$f%2.3f$s%10s"

////------------Deep Dive into Functions-----------------------------------------------------------------------------------------------
3.      Deep Dive into Functions
·       Deep Dive into Functions
·       Ways to define a function
·       Polymorphism and higher order functions
·       Recursion and trampolining
·       Object-oriented aspects of functions

///Understanding function 
def add(x:Int, y:Int) = x + y

val add1 = (x:Int, y:Int) => x+y 

val add2 = add _ 

type AddType = (Int,Int) => Int 

val add1 = (x:Int) => (y:Int) => x+y 
add1(2)(3)

scala> add _
res21: (Int, Int) => Int = <function2>

///partial application 
scala> add(2, _:Int)                   
res19: Int => Int = <function1>

//placeholder 
scala> val hashPlaceholder =    (_: Int) * 31^4 + (_: Int) * 31^3 + (_: Int) * 31^2 + (_: Int) * 31

scala> :type hashPlaceholder
(Int, Int, Int, Int) => Int

def four(one: String, two: Int, three: Boolean, four: Long) = ()
val applyTwo = four("one", _: Int, true, _: Long)

///Function literals
scala> :type Functions.applyTwo
(Int, Long) => Unit

Here is an example of the full definition for a function of four arguments:

val hash: (Int, Boolean, String, Long) => Int = (a, b, c, d) => {
      val ab = 31 * a.hashCode() + b.hashCode()
      val abc = 31 * ab + c.hashCode
      31 * abc + d.hashCode()
}

//OR when type is not mentioned 
val hashInferred = (a: Int, b: Boolean, c: String, d: Long) =>
  // ... same implementation as before


//Function2 to Function22 have few extra goodies 
//For example args converted to tupled 

scala> (add _).tupled
res22: ((Int, Int)) => Int = <function1>

scala> (add _).tupled( (2,3) )
res23: Int = 5

(add _).curried(2)(3)


//Some Trick
scala> val t = (1,2)
t: (Int, Int) = (1,2)

scala> case class Two(x:Int, y:Int)
defined class Two

scala> Two(t._1, t._2)
res26: Two = Two(1,2)

scala> (Two.apply _).tupled(t)
res27: Two = Two(1,2)


//Function1 has also few goodies 
val dou = (x:Int) => x*x 
val ai = (x:Int) => x+5

(dou andThen ai )(5)
(dou compose ai)(5)  //reverse 

///Object Function also has few goodies 
Function.chain( Seq(dou,ai) )(5)  //dou andThen ai 
Function.chain( Seq(dou,ai).reverse )(5)  //reverse
val const = Function.const(20) _
const(30) //20

Function.tupled( add _ ) ( (2,3) )  //upto 5 args 

val add1 = (x:Int) => (y:Int) => x+y 
Function.uncurried( add1)(2,3)  //upto 5 args 

val add2 = ( t:Tuple2[Int,Int] ) => t._1 + t._2  
Function.untupled( add2)(2,3) 

///HOF 
def twistedadd( f: (Int, Int) => Int, x:Int, y:Int) = f(x,y)

twistedadd( (x:Int, y:Int) => x+y, 2,3)

///Many ways to declare add 
def add(x:Int, y:Int) = x+y

val add1: (Int,Int) => Int = (x,y) => x+y

val add3 = (x:Int,y:Int) => x+y

val add4 = (_:Int) + (_:Int)

def add5(x:Int)(y:Int) = x+y

def add6(x:Int) = {
        def _ad(y:Int) = x + y
       _ad _
 }

val add7 = (x:Int) => (y:Int) => x+y

val add8: Int =>Int => Int = x => y => x+y

///Overloading 
//Overloading is exactly like Java except it has problem if overloading defines default args 
//Only one overload can define default Args 

def f(x:Int, y:Int=0) = ???
def f(x:Int, y:String="") = ??? //Error 
def f(x:Int, y:String) = ??? //OK 



///Default in curry form   
def defaultValues(a: String = "default")(b: Int = 0, c: String = a)(implicit d: Long = b, e: String = a) = ???

///Inference is also good in curry form 
def f[A,B](x:A, fn: A=>B):B = fn(x)
f(2, _.toDouble) //Error
 
def f[A,B](x:A)(fn: A=>B):B = fn(x)
f(2)( _.toDouble)


///Disadv of curry form: Scala2 error but scala3:Changes in Overload Resolution 
Scala3: it takes all argument lists into account instead of just the first argument list(scala2)

def f(x: Int)(y: String): Int = 0
def f(x: Int)(y: Int): Int = 0

f(3)("")     // in scala2, error , scala3-OK 

def g(x: Int)(y: Int)(z: Int): Int = 0
def g(x: Int)(y: Int)(z: String): Int = 0

g(2)(3)(4)     // ok , in scala2, error 
g(2)(3)("")    // ok , in scala2, error 

The handling of function values with missing parameter types has been improved. 

def f(x: Int, f2: Int => Int) = f2(x)
def f(x: String, f2: String => String) = f2(x)

f("a", _.toUpperCase) // scala3:ok , in scala2, error 
f(2, _ * 2)           // scala3:ok , in scala2, error 

///Local functions
def average(in: Int*): Int = {
 def sum(in: Int*): Int = in.sum
 def count(in: Int*): Int = in.size
 sum(in:_*)/count(in:_*)
}

val items = Seq(1,2,3,4,5)
val avg = average(items:_*)

We could rewrite both code blocks as follows:

val items = Seq(1,2,3,4,5)
val avg = {
    def sum(in: Int*): Int = in.sum
    def count(in: Int*): Int = in.size
    sum(items:_*)/count(items:_*)
}

//OR 
def averageNoPassing(in: Int*): Int = {
  def sum: Int = in.sum
  def count: Int = in.size
  sum /count
}

///Closures
In our function definitions, we have referred to two different types of variables: the ones that
are provided as parameters (bound variables) and others, which were defined in the
enclosing block (free variables)

def outerA = {
  val free = 5
  def innerA = {
    val free = 20
    def closure(in: Int) = free + in
        closure(10)
    }
  innerA + free
}
scala> outerA
res3: Int = 35

The res3 is calculated as outerA.free (5) + innerA.free (20) + closure.in(10).

///PartialFunction
val pf:PartialFunction[Int,Int] = {case x:Int if x!=0 => 42/x}


scala> pf(0)
scala.MatchError: 0 (of class java.lang.Integer)
  at scala.PartialFunction$$anon$1.apply(PartialFunction.scala:253)
  at scala.PartialFunction$$anon$1.apply(PartialFunction.scala:251)
  at $anonfun$1.applyOrElse(<console>:12)
  at $anonfun$1.applyOrElse(<console>:12)
  at scala.runtime.AbstractPartialFunction$mcII$sp.apply$mcII$sp(AbstractPartialFunction.s
cala:36)
  ... 40 elided

scala> pf(1)
res29: Int = 42

scala> pf.isDefinedAt(0)
res30: Boolean = false

scala> pf.isDefinedAt(1)
res31: Boolean = true

val pf1:PartialFunction[Int,Int] = {case x:Int if x == 0 => 0}

scala> (pf orElse pf1)(0)
res33: Int = 0

scala> val f:Function[Int,Int] = pf orElse pf1
f: Function[Int,Int] = <function1>



///SAM with  >SCala 2.12 has SAM conversion, which preceeds implicits 

trait MySam { def i(): Int }
implicit def convert(fun: () => Int): MySam = new MySam { def i() = 1 }

val sam1: MySam = () => 2 // Uses SAM conversion, not the implicit
sam1.i()                  // Returns 2


//Note that SAM conversion only applies to lambda expressions, 
//not to arbitrary expressions with Scala FunctionN types:

val fun = () => 2     // Type Function0[Int]
val sam2: MySam = fun // Uses implicit conversion
sam2.i()              // Returns 1


//Note that SAM conversion in overloading resolution is always considered
//below code works ok in 2.11, but ambiguous in 2.12
object T {
    def m(f: () => Unit, o: Object) = 0
    def m(r: Runnable, s: String) = 1  //Runnable is SAM with Unit => Unit
}


T.m(() => (), "")
//<console>:13: error: ambiguous reference to overloaded definition



///Polymorphic methods (function is only possible in scala3)
sealed trait Glass[+Contents] //Contents produced , note Glass[Nothing] <: Glass[Water] as Nothing <: Water

case class Full[Contents](c: Contents) extends Glass[Contents]
case object EmptyGlass extends Glass[Nothing]

case class Water(purity: Int)

def drink(glass: Glass[Water]): Unit = ???

scala> :type drink _
Glass[Water] => Unit

The drink method is monomorphic and thus can only be applied to the argument of the type Glass[Water], 
Glass[Nothing] <: Glass[Water] as Nothing <: Water So can be used for EmptyGlass because of Covariant type param

drink(Full(Water(10)))  //OK 
drink(EmptyGlass)

OR we implement our functions in a polymorphic way:

def drinkAndRefill[C](glass: Glass[C]): Glass[C] = glass


scala> :type drinkAndRefill _
Glass[Nothing] => Glass[Nothing]

scala> :type drinkAndRefill[Water] _
Glass[Water] => Glass[Water]

//OR with constraint 
def drinkAndRefillWater[B >: Water, C >: B](glass: Glass[B]): Glass[C] = glass

scala> :type drinkAndRefillWater[Water, Water] _
Glass[Water] => Glass[Water]

we define a polymorphic function using a function literal:

scala> def drinkFun[B] = (glass: Glass[B]) => glass
//def drinkFun[B]: Glass[B] => Glass[B]


///FP with Function 
Only take foreach, map, filter, reduce, sortBy , Then example of File IO

val ls = List(1,2,3)
val map = Map("OK"->1, "Nok" -> 2) 


//foreach 
val p = (x:Int) => println(x) 

ls.foreach(p) 
ls.foreach(  println(_) )

println _ 
ls.foreach(println _ ) 
ls.foreach(println)
//this conversion is not valid for overloaded method case 
ls foreach println

map foreach println 
map foreach ( (x,y) => println(x)) //Nok 
map.foreach{case(x,y) => println(x)}

scala> map.foreach{t:Tuple2[String,Int] => println(t._1)}


//in terms of for loop 
for{
    i <- ls
    j = i*i 
    k <- i to j if j %2 == 0
}
{
    println(s"$i $j $k")
}


//Map 
ls.map(x => x*x) 
map.map{case (x,y) => x+y}

//in terms of for loop 
val out = for{
        i <- ls    
    } yield {
        i*i
    }
    

//flatMap 
scala> ls.flatMap(x => List(x,x*x))
res47: List[Int] = List(1, 1, 2, 4, 3, 9)


scala> map.flatMap{case (x,y) => Map(x->y*y)}
res48: List[(String, Int)] = List((OK,1), (Nok,4))

scala> map.flatMap{case (x,y) => Map(x->y*y)}.toMap
res49: scala.collection.immutable.Map[String,Int] = Map(OK -> 1, Nok -> 4)

//with for loops 
val first = List(1, 2)
val next = List(8, 9)
val last = List("ab", "cde", "fghi")

for {
  i <- first  if i %2 ==0   //flatmap with filter 
  j <- next      //flatmap
  k <- last      //map 
} yield {
    val len = k.size 
    i * j * len 
}

//Equivalent to Monadic form
first withFilter (t => t%2 == 0) flatMap {
  i => next flatMap {
    j => last map {
      k => 
        val len = k.size 
        i * j * len 
      
    }
  }
}


//filter 
ls.filter(x => x % 2 == 0)
map.filter{case (x,y) => y%2 == 0}


//collect 
ls.collect{ case x:Int if x%2==0 => x*x }
map.collect{case (x,y) if y%2 == 0  => (x,y*y)}



//reduce 
ls.reduce{ (r,t) => r+t }
map.reduce{(r,t) => (r._1+t._1, r._2+t._2) }

//foldLeft
ls.foldLeft(16){ (r,t) => r+t }
map.foldLeft( ("pre",10) ){(r,t) => (r._1+t._1, r._2+t._2) }

map.foldLeft( Map[String,Int]() ){ (r,t) => r ++ Map(t._1 -> t._2*t._2)}

//sortBy 
ls.sorted 
map.sorted 

ls.sortBy(x => -x) 
map.toList.sortBy{case(x,y) => y}

//def sortWith(lt: (A, A) ⇒ Boolean): List[A] 
ls.sortWith{ (a,b) => a > b }

map.toList.sortWith{(x,y) => x._2 > y._2}
map.toList.sortWith{case ((k1,v1),(k2,v2)) => v1 > v2}




//maxBy 
ls.maxBy(identity) 
map.toList.maxBy{case(x,y) => y}



//groupBy 
ls.groupBy( x => x % 2 )
map.groupBy{case (x,y) => x.size}



//Zip - shortest 
ls.zip( List("a", "b", "c")) //List((1,a), (2,b), (3,c))
map.zip( List("a", "b", "c")) //List(((OK,1),a), ((Nok,2),b))

ls.zip( List("a", "b", "c")).unzip //(List(1, 2, 3),List(a, b, c))

//to make equal 
//def zipAll[B](that: collection.Iterable[B], thisElem: A, thatElem: B): List[(A, B)] 

//ZipWithIndex 
ls.zipWithIndex //List((1,0), (2,1), (3,2))
map.zipWithIndex //List(((OK,1),0), ((Nok,2),1))

//any - def exists(p: (A) => Boolean): Boolean 
ls.exists( _ % 2 ==0 )
map.exists{case (k,v) => v % 2 ==0 }


//def indexWhere(p: (A) => Boolean): Int 
ls.indexWhere( _ % 2 == 0 )
map.indexWhere{case (k,v) => v % 2 ==0 }

//def partition(p: (A) => Boolean): (List[A], List[A]) 
ls.partition( _ % 2 ==0 )
map.partition{case (k,v) => v % 2 ==0 }


// forall(p: (A) => Boolean): Boolean 
ls.forall( _ % 2 ==0 )
map.forall{case (k,v) => v % 2 ==0 }

// dropWhile(p: (A) => Boolean): List[A] 
ls.dropWhile( _ % 2 == 1 )
map.dropWhile{case (k,v) => v % 2 ==1 }

// final def takeWhile(p: (A) ⇒ Boolean): List[A]  
ls.takeWhile( _ % 2 == 1 )
map.takeWhile{case (k,v) => v % 2 ==1 }



///Iterator 
//Note Iterator object also has following methods (hence prefix with Iterator)
//empty Iterator
val empty: Iterator[Nothing] 
//Creates an iterator which produces a single element.
//  '''Note:''' Equivalent, but more efficient than Iterator(elem)
def single[A](elem: A): Iterator[A] 
//Creates iterator that produces the results of some element computation a number of times.
 def fill[A](len: Int)(elem: => A): Iterator[A] 
 //Creates an iterator producing the values of a given function over a range of integer values starting from 0.
//An iterator that produces the values `f(0), ..., f(n -1)`.
def tabulate[A](end: Int)(f: Int => A): Iterator[A] 
//the iterator producing values `start, start + 1, ..., end - 1`
def range(start: Int, end: Int): Iterator[Int] = range(start, end, 1)
//the iterator producing values `start, start + step, ...` up to, but excluding `end`
def range(start: Int, end: Int, step: Int): Iterator[Int] 
//the iterator producing the infinite sequence of values `start, f(start), f(f(start)), ...`
def iterate[T](start: T)(f: T => T): Iterator[T] 
//the iterator producing the infinite sequence of values `start, start + 1, start + 2, ...`
def from(start: Int): Iterator[Int] = from(start, 1)
//the iterator producing the infinite sequence of values `start, start + 1 * step, start + 2 * step, ...`
 def from(start: Int, step: Int): Iterator[Int] 
//Creates an infinite-length iterator returning the results of evaluating an expression.
//The expression is recomputed for every element.
def continually[A](elem: => A): Iterator[A] 

//Examples 
val b = Range(1,1000).iterator
b.filter( _ % 2 == 0)
b.filter( _ % 2 == 0).take(10)
b.filter( _ % 2 == 0).take(10).toList 


///Iterator Examples 
//Files - MQ - breadth first , Stack - depth first 

//Many warnings so check 
:warnings 
:settings "-deprecation"

import scala.collection.mutable.{Queue => MQ, Stack =>MS}
import scala.util._
import java.io._ 

trait Q[CC[_]]{  
    def isEmpty:Boolean 
    def getOne:Option[File]
    def addMany(files: File*):CC[File]
    def clear():Unit 
}

def QMQ:Q[MQ]  = new Q[MQ]{ //not required 
    private val queue = MQ[File]()
    def isEmpty:Boolean = queue.isEmpty
    def getOne:Option[File] = Try(queue.dequeue()).toOption
    def addMany(files: File*):MQ[File] = {
        queue ++= files
        queue
    }
    def clear():Unit = queue.dequeueAll(x => true)
}
def QMS:Q[MS]  = new Q[MS]{
    private val stack = MS[File]()
    def isEmpty:Boolean = stack.isEmpty
    def getOne:Option[File] = Try(stack.pop()).toOption
    def addMany(files: File*):MS[File] = {
        files.foreach( stack.push )
        stack
    }
    def clear():Unit = stack.popAll()
}

//Note because below are singleton, only one instance , 
//so multiple usage is not possible unless  exhausted and then use again 
implicit val singletone_QMQ:Q[MQ] = QMQ
implicit val  singletone_QMS:Q[MS] = QMS


case class GetFiles[CC[_]](path:String)( implicit queue: Q[CC])  extends Iterator[File]{
    val q = {
        queue.clear()
        queue.addMany( (new File(path)).listFiles.toIndexedSeq : _* ) 
    }
    //println(q)
    def hasNext = ! queue.isEmpty
    def next():File = queue.getOne match {
            case Some(f) => 
                if (f.isFile) f else {
                    queue.addMany( f.listFiles.toIndexedSeq : _*)
                    next()
                }
            case None    => new File("")
        }
}

val path = raw"D:\tool"
//Check 
val aa = GetFiles[MQ](path)
aa.take(10).toList 
val bb = GetFiles[MS](path)
bb.take(10).toList 

//OR for seperate instance of Stack 
val aaq = GetFiles[MQ](path)(QMQ)
aaq.take(10).toList 

///LazyList 
//for fusing steps 
val aa = List.from(0 to 10)
aa.filter((x:Int) => { println(s"filtering $x");x % 2 == 0}
    ).map((x:Int) => {println(s"mapping $x");x+1}).foldLeft(0)((x:Int, y:Int) => { println(s"summing $x $y");x+y} )

filtering 0
filtering 1
filtering 2
filtering 3
filtering 4
filtering 5
filtering 6
filtering 7
filtering 8
filtering 9
filtering 10
mapping 0
mapping 2
mapping 4
mapping 6
mapping 8
mapping 10
summing 0 1
summing 1 3
summing 4 5
summing 9 7
summing 16 9
summing 25 11
val res6: Int = 36

//Compare this 
val aa = LazyList.from(0 to 10)
aa.filter((x:Int) => { println(s"filtering $x");x % 2 == 0}
    ).map((x:Int) => {println(s"mapping $x");x+1}).foldLeft(0)((x:Int, y:Int) => { println(s"summing $x $y");x+y} )
    
filtering 0
mapping 0
summing 0 1
filtering 1
filtering 2
mapping 2
summing 1 3
filtering 3
filtering 4
mapping 4
summing 4 5
filtering 5
filtering 6
mapping 6
summing 9 7
filtering 7
filtering 8
mapping 8
summing 16 9
filtering 9
filtering 10
mapping 10
summing 25 11
val res4: Int = 36

//Methods 
object LazyList extends SeqFactory[LazyList]
    def apply[A](elems: A*): LazyList[A]
        Creates a lazy list with the specified elements.
    def concat[A](xss: collection.Iterable[A]*): LazyList[A]
        Concatenates all argument collections into a single lazy list.
    def continually[A](elem: => A): LazyList[A]
        Create an infinite LazyList containing the given element expression (which is computed for each occurrence).
    def empty[A]: LazyList[A]
        An empty collection
    def fill[A](n: Int)(elem: => A): LazyList[A]
        Produces a lazy list containing the results of some element computation a number of times.
    def fill[A](n1: Int, n2: Int, n3: Int, n4: Int, n5: Int)(elem: => A): LazyList[LazyList[LazyList[LazyList[LazyList[A]]]]]
        Produces a five-dimensional lazy list containing the results of some element computation a number of times.
        Similar methods exist for below 5 dimension
    def from(start: Int): LazyList[Int]
        Create an infinite LazyList starting at start and incrementing by 1.
    def from(start: Int, step: Int): LazyList[Int]
        Create an infinite LazyList starting at start and incrementing by step step.
    def from[A](coll: IterableOnce[A]): LazyList[A]
        Creates a target lazy list from an existing source collection

    def iterate[A](start: => A)(f: (A) => A): LazyList[A]
        An infinite LazyList that repeatedly applies a given function to a start value.
    def iterate[A](start: A, len: Int)(f: (A) => A): LazyList[A]
        Produces a lazy list containing repeated applications of a function to a start value.

    def range[A](start: A, end: A, step: A)(implicit arg0: Integral[A]): LazyList[A]
        Produces a lazy list containing equally spaced values in some integer interval.
    def range[A](start: A, end: A)(implicit arg0: Integral[A]): LazyList[A]
        Produces a lazy list containing a sequence of increasing of integers.
    def tabulate[A](n: Int)(f: (Int) => A): LazyList[A]
        Produces a lazy list containing values of a given function over a range of integer values starting from 0.
    def tabulate[A](n1: Int, n2: Int, n3: Int, n4: Int, n5: Int)(f: (Int, Int, Int, Int, Int) => A): LazyList[LazyList[LazyList[LazyList[LazyList[A]]]]]
        Produces a five-dimensional lazy list containing values of a given function over ranges of integer values starting from 0.
        Similar methods exist for below 5 dimension

    def unfold[A, S](init: S)(f: (S) => Option[(A, S)]): LazyList[A]
        Produces a lazy list that uses a function f to produce elements of type A and update an internal state of type S.
        
    object #::
    object cons
        An alternative way of building and matching lazy lists using LazyList.cons(hd, tl).


///Fibs using Iterator and Using Lazylist 
import scala.math.BigInt

val fibs: LazyList[BigInt] = BigInt(0) #:: BigInt(1) #:: fibs.zip(fibs.tail).map{ n => n._1 + n._2 }
fibs.take(5).foreach(println)

def fib_lazy(n:Int) = fibs.take(n).last

def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0) + "ns")
    result
}

time(fib_lazy(100))
//next time would be much faster , Note this is not Iterator hence 100 would give same value 
time(fib_lazy(100))
//Or Iterator 
class Fib extends Iterator[BigInt]{
    var (a,b) = (0:BigInt, 1:BigInt)
    def hasNext = true 
    def next = {
        val tmp = a; a=b;b=tmp+b;
        b
    }

}
(new Fib).take(10).toList 

val res33=Iterator.iterate( (0,1) ){case (x,y) =>(y,x+y)}
res33.take(10).map{case (x,y) => x}.toList



///Par 
//In 2.13, use 
libraryDependencies += "org.scala-lang.modules" %% "scala-parallel-collections" % "1.0.1"

import scala.collection.parallel.CollectionConverters._ 
//Put it in method if using with REPL, else hangs (in code, works)

def foo = (0 to 10).par.foreach(println)
def foo2 = (0 to 10).par.map(_*2).seq.foreach(println)




///Recursion 
def mysum(x:List[Int]):Int = if (x.isEmpty) 0 else x(0)+mysum(x.tail)

def mysum2(x:List[Int]): Int = x match {
        case h :: t => h + mysum2(t)
        case Nil => 0
}
//for TCO, function must be final or private such that subclass can not override that 
object Tail{
    @annotation.tailrec
    final def mysum3(x:List[Int], acc:Int=0):Int = x match {
        case h::t => mysum3(t, h+acc)
        case Nil => acc 
    }
}

def mysum4(x:List[Int]) = {
    @annotation.tailrec
    def _sum(y:List[Int], acc:Int):Int = y match {
        case h::t => _sum(t, h+acc)
        case Nil => acc 
    }
    _sum(x,0)
}

//- Given Path, find file with MaxName 
import java.io.File 

def getMaxFile(dir:File) = {
    def getFiles(dirs:Array[File], acc:Array[File]=Array.empty[File]):Array[File] = {
        val files = dirs.flatMap{ f => f.listFiles.filter(_.isFile)}
        val subs = dirs.flatMap{ f => f.listFiles.filter(_.isDirectory)}
        if(subs.isEmpty) acc ++ files else getFiles(subs, acc ++ files)
    }
    val allFiles = getFiles(Array(dir))
    val map = allFiles.map{f => (f, f.length)}.toMap 
    val smap = map.toList.sortBy{case(x,y) => y}
    smap.last
}

getMaxFile(new File(dir))

///HandsOn: Finding max for an list 
def max(ints: List[Int]): Int = { 
    @annotation.tailrec
    def maxAccum(ints: List[Int], theMax: Int): Int = {
      ints match {
        case Nil => theMax
        case x :: tail => maxAccum(tail, if (x > theMax) x else theMax)
      }
    }
    maxAccum(ints, ints.head)
  }
  
///trampoline 
In essence, trampolining is replacing recursive function calls 
with objects representing these calls.(so moving from stack to heap)

Let take a look at them by re implementing our Ackerman function:

val A: (Long, Long) => Long = (m, n) =>
  if (m == 0) n + 1
  else if (n == 0) A(m - 1, 1)
  else A(m - 1, A(m, n - 1))
  
//Using below of TailRec 
TailRec[A]
final def flatMap[B](f: (A) => TailRec[B]): TailRec[B]
    Continue the computation with f and merge the trampolining of this computation with that of f.
final def map[B](f: (A) => B): TailRec[B]
    Continue the computation with f.
        
//Example 
import util.control.TailCalls._

def tailA(m: BigInt, n: BigInt): TailRec[BigInt] = {
  if (m == 0) done(n + 1)
  else if (n == 0) tailcall(tailA(m - 1, 1))
  else tailcall(tailA(m, n - 1)).flatMap(tailA(m - 1, _))
}
def A(m: Int, n: Int): BigInt = tailA(m, n).result

//Another  Example 
def F(n:Int): Int = if (n == 0) 1 else n - M(F(n-1))
def M(n:Int): Int = if (n == 0) 0 else n - F(M(n-1))


import util.control.TailCalls._

def FA(n: Int): TailRec[Int] = {
  if (n == 0) done(1) else tailcall(FA(n-1)).flatMap(MA(_)).map( n - _)
}
def MA(n: Int): TailRec[Int] = {
  if (n == 0) done(0) else tailcall(MA(n-1)).flatMap(FA(_)).map( n - _)
}

def start(n: Int): Int = FA(n).result


//Another  Example 
import util.control.TailCalls._

def fib(n: Int): TailRec[Int] =
  if (n < 2) done(n) else for {
    x <- tailcall(fib(n - 1))
    y <- tailcall(fib(n - 2))
  } yield (x + y)

fib(40).result
//OR 
import util.control.TailCalls._

def mysum4(x:List[Int]) = {
    def _sum(x:List[Int]):TailRec[Int] = if (x.isEmpty) done(0) else tailcall(_sum(x.tail)).map( _ + x.head)
    _sum(x).result
}

//Memoization with Map 
//Or non TCO ways - very slow as func calls are 2**n
def fib(n:Int):BigInt = {
  if (n == 0 ) BigInt(0) else if (n == 1) BigInt(1) else  fib(n-1) + fib(n-2)
}

import scala.collection.mutable.Map
val m:Map[BigInt,BigInt] = Map[BigInt,BigInt]().withDefault { n => 
    m.getOrElseUpdate(n, if (n<2) n else m(n-1) + m(n-2)) 
}
m(100)

def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0) + "ns")
    result
}
time(m(100))
time(fib(100)) //woud hangs 


  
//OR TCO way, 
def fibtco(n:Int, a:BigInt=0, b:BigInt=1):BigInt = n match {
   case 0 => a
   case 1 => b
   case _ => fibtco(n-1, b, a+b)
}
time(fibtco(100))


///File Handling - scala.io.Source
//http://www.scala-lang.org/api/2.11.12/#scala.io.Source$
//fromFile, fromURL, fromChars, fromString, fromInputStream
libraryDependencies += "org.xerial" % "sqlite-jdbc" % "3.21.0.1"


package examples 

case class Row(SepalLength:Double, SepalWidth:Double, PetalLength:Double, PetalWidth:Double, Name:String){
    override def toString = s"""( $SepalLength,$SepalWidth,$PetalLength,$PetalWidth,"$Name")"""
    def toSql = s"insert into iris values ${this.toString}"
}

object Day4 {
    Class.forName("org.sqlite.JDBC")
    import java.sql.{Array => JArray, _ }
    
    def process[B](path:String)(f:Array[String] =>B):List[B] = {
        val lines = scala.io.Source.fromFile(path).getLines.toList
        val lines2 = lines.drop(1). map(_.split(",")).map(f)
        lines2
    }
    
    def query[T](stmt:Statement)(sql:String)(f: ResultSet => T ) = {
        val rs = stmt.executeQuery(sql)
        new Iterator[T]{
            def hasNext = rs.next()
            def next() = f(rs)
        }   
    }
    
    //examples.Day4.demo_sql
    def demo_sql = {
        val path = raw"D:\handson\demo\iris.csv"
        val rows = process(path){ arr =>
            val ( Array(a,b,c,d),e) = (arr.slice(0,4).map(_.toDouble), arr.last)
            Row(a,b,c,d,e)        
        }
        //println(rows)     
        val un = rows.map(_.Name).distinct  //or .toSet 
        //val un: List[String] = List(Iris-setosa, Iris-versicolor, Iris-virginica)
        //Aggregation 
        //get max of SepalLength of each Name 
        rows.groupBy(_.Name).map{case(n,lst) => (n -> lst.map(_.SepalLength).max) }
        rows.groupBy(_.Name).map{case(n,lst) => (n -> Map("sl"->lst.map(_.SepalLength).max, "sw" -> lst.map(_.SepalWidth).max)) }

        println(agg)     
        val con = DriverManager.getConnection("jdbc:sqlite:iris.db")
        val stmt = con.createStatement()
        stmt.executeUpdate("drop table if exists iris")
        stmt.executeUpdate("""create table iris (
            SepalLength double, SepalWidth double,PetalLength double,PetalWidth double,Name string)""" )
        val how_many_rows = rows.map(_.toSql).map(stmt.executeUpdate).sum
        println(s"Inserted $how_many_rows rows")  
        val sql1 = "select count(*) from iris"
        val it = query(stmt)(sql1){ r =>
                r.getInt(1)
            }.toList 
        println(s"$sql1=$it")
        val sql2 = "select Name, max(SepalLength) from iris group by Name"
        val it1 = query(stmt)(sql2){ r =>
                (r.getString(1), r.getDouble(2))
            }.toList 
        println(s"$sql2=$it1")
        con.close
    }
}



