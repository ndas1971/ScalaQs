Day One
1. An Introduction to Scala 2.13
    An Introduction to Scala 2.13
    New features of Scala 2.13
    Revision of core syntax vis-a-vis Java
    Designing with Scala class
    Object Comparison with Java
    The Scala 2.13 Collection Library
2. Deep Dive into Functions
    Deep Dive into Functions
    Ways to define a function
    Polymorphism and higher order functions
    Recursion and trampolining
    Object-oriented aspects of functions
------------------------------------------------
/// Quick installation and Using SBT 
0.Install JDK8 and set JAVA_HOME, then check 
$ java -version    //Make sure you have version 1.8.
1.Download https://github.com/sbt/sbt/releases/download/v1.1.1/sbt-1.1.1.zip
  Unzip and put into some dir and update PATH to include THAT_DIR\bin;
2.cd to an empty folder.
$ cd firstProject 
3.Run the following command

//List of templates: https://github.com/foundweekends/giter8/wiki/giter8-templates
$ sbt new scala/scalatest-example.g8   //or scala/hello-world.g8

//scala3
$ sbt new scala/scala3.g8
//Or cross compiles with Scala 2:
$ sbt new scala/scala3-cross.g8

4.Enter 'first' when prompted 
5. Project structure 
- first
    - project (sbt uses this to install manage plugins and dependencies)
        - build.properties
    - src
        - main
            - scala (All of your scala code goes here)
                -Main.scala (Entry point of program) <-- this is all we need for now
    build.sbt (sbt build definition file)

6.Note sbt can compile src/main/scala, src/main/java and src/test/scala and src/test/java 
7.IntelliJ IDE already supports sbt projects. 
    a. download from https://www.jetbrains.com/idea/download/#section=windows
    How to download scala plugin, check https://www.jetbrains.com/help/idea/managing-plugins.html

8.Quick IntellJ:  
    a.Open up IntelliJ and click File => New => Project
      To install a Scala SDK. To the right of the Scala SDK field, click the Create button.(select 2.12.8 and download)
      With SBT, On the left panel, select Scala and on the right panel, select SBT
    OR
    a.open up IntelliJ, select Import Project and open the build.sbt file for your project
    b.Make sure the JDK Version is 1.8 and the SBT Version is at least 0.13.13
    c.Select Use auto-import so dependencies are automatically downloaded when available
        For import options:
        Enable use auto-import.
        For Download options, enable Sources and disable Javadocs and Sources for SBT and plugins.
        For Project SDK, verify the version (JDK 1.8).
        Leave Project format: at the default, .idea (directory based). 
    d.Select Finish
    //Writing Scala code
    1.On the Project panel on the left, expand SBTExampleProject => src => main 
    2.Right-click scala and select New => Package
    3.Name the package examples and click OK.
    4.Right-click the package examples and select New => Scala class.
    5.Name the class Main and change the Kind to object.
    6.Change the code in the class to the following:
    (Window -> Editor Tabs -> Editor configuration ->Font)
    //scala2 , in scala3: No App 
    package examples 
    object Main extends App {
      //val ages = Seq(42, 75, 29, 64)
      //println(s"The oldest person is ${ages.max}")
      val a = 1
      var b = 1
      println(s"${a} and $b")
      
      def cube(x:Double) = x*x*x
    }    
    //scala3 - check below 
    
    //Creating a test
    1.On the project pane on the left, expand src => test.
    2.Right-click on scala and select New => Scala class.
    3.Name the class CubeCalculatorTest and click OK.
    4.Replace the code with the following:
    //scala 2, scala3 check below 
    package examples 
    import org.scalatest.FunSuite

    class CubeTest extends FunSuite {
      test("cube of a double") {
        assert(Main.cube(3) === 27)
      }
    }
    //Running the test 
    1.In the source code, right-click CubeCalculatorTest and select Run ‘CubeCalculatorTest’.
    //Running the project
    1.From the Run menu, select Edit configurations
    2.Click the + button and select SBT Task.
    3.Name it 'Run the program'.
    4.In the Tasks field, type ~run. for runMain, use "runMain examples.Main"
      The ~ causes SBT to rebuild and rerun the project when you save changes to a file in the project.
    5.Click OK.
    6.On the Run menu. Click Run 'Run the program'.
    7. OR find out where sbt-launch.jar is installed by Idea and execute 
    $ "C:\Program Files\Java\jdk1.8.0_65\bin\java.exe"  -jar C:\Users\das\.IdeaIC2019.2\config\plugins\Scala\launcher\sbt-launch.jar run
    OR Create Package, Same proceedure as above and In the Tasks field, type package 
    It is created in project_dir/target/scala-2.12/project_name.jar 
    execute by 
    (Note path details are in project_dir\.idea\libraries\sbt__org_scala_lang_scala_library_2_12_13_jar.xml)
    C:/Users/das/AppData/Local/Coursier/cache/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.12.13/scala-library-2.12.13.jar
    Better copy all these jars to a dir and then put that in classpath 
    $ java -cp target/scala-2.12/demo1_2.12-0.1.jar;C:/Users/das/AppData/Local/Coursier/cache/v1/https/repo1.maven.org/maven2/org/scala-lang/scala-library/2.12.13/scala-library-2.12.13.jar  examples.Main

    OR in sbt 
    sbt run 
    sbt "runMain examples.Main"
    or 
    sbt package 
    $ java -cp target\scala-2.12\demo1_2.12-0.1.jar;C:\Users\das\.m2\repository\org\scala-lang\scala-library\2.12.8\scala-library-2.12.8.jar   examples.Main
    
//compile 
$ sbt compile
$ sbt testCompile 
$ sbt test          // check the reports under target/test-reports/TEST-Test1.xml
$ sbt "run arg1 arg2"    //for running main class (only one)
$ sbt package   //packaging jar
$ sbt console   //scala REPL
$ sbt "runMain Main" 
$ sbt "runMain examples.hello i am ok" //i am ok === arg1 arg2 arg3
$ sbt tasks   //for task 

//dont do for all those jars as assembly would be very big 
$ sbt assembly 

///*** Scala language concepts 

//Inference and mutability and immutability 
val a = 1
var b = 1

//string interpolation 
println(s"${a} and $b")
//or with format , f"$v%2.2f ${v2.method}%2.2f"
println(f"${a}%d and $b%03d")

//Numeric types 

//Everything is class , no primitive types and operators are actually methods 
1 + 2
//=>
1.+(2)

//Int, Boolean, Double, Float, BigInt,BigDecimal, Byte, Char, Short, Long  and their Rich*
//conversion, toInt, toFloat

//Rich type has many methods(eg abs, longValue, isValidLong etc) , these are automatically called on base type
Check Int and RichInt  -Reference (RichInt is merged with Int documentation)

1. ==, != is used for content checking
   == calls def equals(other:Any):Boolean method internally. 
  Overload this if required
  
2. eq, ne is used for object identity only for AnyRef 

//Scala Type 
scala.Any , abstract  class  Any ( != , ==, toString, ##, asInstanceOf[], isInstanceOf[], equals, hashCode)
	Nothing  (type represents nothing, no instance)
	scala.AnyRef (java.lang.Object) (overrides Any methods as final, eq , ne , notify, notifyAll, synchronized, wait)
		java.lang.String
		Array
		java.lang.Number
			java.lang.Integer
			....
		Other java classes
		scala.Seq
			...Collections
		scala.Option
		... other scala classes
		Null (with instance null )
	scala.AnyVal , only method is getClass()
		scala.Int
		scala.Double
		scala.Float
		scala.Unit
		scala.Char
		scala.Long
		scala.Byte
		scala.Boolean

//use d, f, L as suffix, default Int and double 
BigInt("111111111111")
1.0  //Double 
1    //Int
1.0f 
1L 

///Scala class examples
//class and object must be in same file, in REPL use :paste 

// (1) primary constructor
class Animal ( val name: String, val age: Int) {
    Animal.howmany += 1
    // (2) auxiliary constructor
    //scala3: def this (name: String) = {
    def this (name: String) {
        this(name, 0)
    }
    def talk ="talk?"
    override def toString = s"$name is $age years old"
}

object Animal {     
  private var howmany = 0                         
  def apply() = new Animal("Default")
  def apply(name: String, age: Int) = new Animal(name, age)
  def how_many_created = howmany
}

val an = new Animal("ABC", 20) //scala3: new is not required only if no user defined companion object
an.name 
an.age 
an.talk 
val an = Animal()


//Test 
//https://www.scalatest.org/at_a_glance/FlatSpec
As of now no final API for scala3 , check here 
https://mvnrepository.com/artifact/org.scalatest/scalatest

//scala2 
libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.2"   

import org.scalatest._
import matchers.should._
import funsuite._

class AnimalTest extends AnyFunSuite  with BeforeAndAfter with Matchers {     

  // Fixtures as reassignable variables and mutable objects
  var object1:Animal = _
  //scala3:
  // import scala.compiletime.uninitialized
  //var object1:Animal = uninitialized
  
  before {
      //modify
      object1 = Animal("ABC", 20)
  }

  test("Animal talk") { assert(object1.talk == "talk?") }
}

scala> org.scalatest.run(new AnimalTest)


///Inheritance, extends Base ( only one base class)
Donot mention val or var for fields that are common to Base class

val can be overridden by val, var can not be,
def can be by def or val

Auxiliary constructors in subclass can not call a superclass constructor.
Auxiliary constructor can only call primary constructor or earlier defined constructor of same class

//in first line of subclass(ie class..), subclass can call any ctor of base class 
// calls the Animal one-arg constructor

//scala3, Must use 'open' in Base class 
//OR  import scala.language.adhocExtensions   OR Use  compiler option -language:adhocExtensions. 
class Dog (name: String, val owner:String) extends Animal (name) {
        override def toString = s"Dog: $name is $age years old"
        def this() {this("No-name", "no owner")}   //can only call own ctor 
        override def talk = {
            super.talk +  "Dog talk"
        }
}
//OR def by val 
class Dog (name: String) extends Animal (name) {
        override def toString = s"Dog: $name is $age years old"
        def this() {this("No-name")}   //can only call own ctor 
        override val talk = "OK"
}

val dn = new Dog()
dn.owner
dn.talk
 
///Case class (no 22 limits in 2.13+scala3)
Case classes to generate copy/hashcode/equal/apply code (along with companion object)
Case class constructor parameters are val by default
case class does not allow to  inherit from a case class. 
but can inherit from a non case class

//must use () 
case class A //<console>:1: error: case classes without a parameter list are not allowed;

case object A //OK

case class Animal2 ( val name: String, val age: Int) {
      def talk ="talk?"
	  override def toString = s"$name is $age years old"
}

val an = Animal2("A", 2)
an.name
an.age
val an2 = an.copy(age=20)
  



///Understanding Trait (similar to interface in Java)
trait A{
    def name:String 
    def print2 = println(this.name)
}
class D extends A {
    def name = "OK"
    override def print2 = println(s"Hello ${this.name}")
}

val d2 = new D; d2.print2 ; //new implementation

val d = new A{  //annon instance 
    def name = "OK"
}
d.print2  //default



///Abstract Class
//When to Use an Abstract Class instead of trait
1.You want to create a base class that requires constructor arguments.
2.The code will be called from Java code.

// this won't compile - scala3-OK
trait Animal(name: String)

//Solution
abstract class Animal(name: String)


///Assigning a Field to a Block or Function and Lazy variable

class X { val x = { Thread.sleep(2000); 15 } }

class Y { lazy val y = { Thread.sleep(2000); 13 } }
new X      //waiting
new Y      //immediate
(new X).x     //immediate
(new Y).y    //waiting

///Scala basic syntax -- if 
val absValue = if (a < 0) -a else a

if (true) "S"   //Return type Any

if (true) "S" else throw new Exception("Whoops!")   // Return type is String as else return type is Nothing

//Nothing -> [Int] -> ... -> AnyVal -> Any

//If no else, then put null (only for Reference type, for any other general type, throw new Exception) , such that return type comes from if block

if (true) "S" else null

///Scala basic syntax --for 
for (i <- 1 to 10) println(i)
for (i <- 1 until 10 ) println(i)
for (i <- 1 to 10 by 2 ) println(i)

for (i <- 1.0 to 10.0 by 2.0 ) println(i)
//Can use guard statement as well 

for {i <- 1 to 10  if i % 2 == 0
   x = i * i                     //no val, is deprecated
   j <- 1 to x    if j % 2 == 1
 }
{
  val y = i*i
  println(s"$y -> $j") 
 }
 
///while - no break and continue 
var a = 10;

// while loop 
while( a < 20 ){
    println( "Value of a: " + a )
    a = a + 1
}

///HandsOn 
3*3 + 4*4 = 5*5 - how many such triplets under 100 ?

///Understanding Methods  
No explicit return is required , last line is return 
(in Recursion and if return type is mentioned, Must required)

def f(x:Int, y:Int):Int = {
    return x+y
 }

def f(x:Int, y:Int) = {
   x+y
 }

def f(x:Int, y:Int) =  x+y


f(2,3)
f(y=3,x=2)
f(2,y=3)

def f(x:Int, y:Int = 20) =  x+y
f(2)
f(2,3)


/// Creating Methods That Take Variable-Argument, 
//Last arg should be *
// version 1
def printAll(numbers: String*) {  //numbers becomes Seq<String>
        for (i <- numbers) println(i)
      }
      
def printAll[T](numbers: T*) {  //numbers becomes Seq<T>
        for (i <- numbers) println(i)
      }
//var args must be last and only one
def printAll(strings: String*, i: Int) //error

// these all work
printAll()
printAll("foo")
printAll("foo", "bar")
printAll("foo", "bar", "baz")

// Use : _* to adapt a sequence (Array, List, Seq, Vector, etc.)
// to unpack for sequence of strings (only allowed if corresponding arg is T* in definition)

val fruits = List("apple", "banana", "cherry")

// pass the sequence to the varargs field
printAll(fruits: _*)
//Note, do below 
printAll(("OK" +: fruits): _*)
//To add extra args, instead of below 
//printAll("OK", fruits: _*)

///Call by and parameterized Function 
def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0) + "ns")
    result
}

// Now wrap your method calls, for example change this...
val result = 1 to 1000 sum

// ... into this, if block is not used as call by name , then block execution happens outside of time function 
val result = time { 1 to 1000 sum }

///Tuple - mixed type, immutable - 22 limits 
//For operation like Dynamic types, use Tuple or case class 
//Tuple2(x,y) or x -> y or (x,y)
//Tuple3(x,y,z) or (x,y,z) ... so on till 22 (in scala3, limit 22 is removed)

val x = (1,2)
val x = 1 -> 2
x._1
x._2

//pattern matching 
val Tuple2(x,y) = (1,2)
//or
val (x,y) = (1,2)

///Char and String
Scala has Char type (java Character), eg 'A'

Strings - " "  or multiline """ """
raw string as raw"  "

//Main methods 
size, union, stripLineEnd, isEmpty, reduceRightOption,  
contains, split, replace
To get character str(index), length, size, > , < , 
count(func), find(func), foreach, flatMap, map and all sequence operators
conversion to other type  - toInt, toArray etc

//Example 
var name = null.asInstanceOf[String]  //null String
val name:String = null

//accessing
"OK"(0)   //res19: Char = O
val a = "OK"  //a: String = OK
a(0) = 1  //<console>:10: error: value update is not a member of String
          
"    A   ".trim 
"OK".size 
"abc".capitalize
"abc".indexOf("b")


//splitting various ways- split takes regex
"""OK 
   OK
   OK""".split("\\n")   //res8: Array[String] = Array(OK, OK, OK)


///HANDSON 
Given a string 
val s = "Hello World Hello"
can you print each word and its frequency 

///Methods for chaining operations - tap an pipe methods to any instance 
//Example 
import scala.util.chaining._

def pipe[B](f: (A) => B): B
    Converts the value by applying the function f.
def tap[U](f: (A) => U): A
    Applies f to the value for its side effects, and returns the original value.
    
"Hello".tap( x => println(x)).pipe( x => x.size).tap( i => println(i)).pipe(2 + _)

///The Scala 2.13 Collection Library
IterableOnce[+A]
    Iterable[+A]    //Mutable and Immutable 
        Map[K, +V]  //Mutable and Immutable 
        Set[A]      //Mutable and Immutable 
        Seq[+A]     //Mutable and Immutable 

These traits cover only the structural characteristics. 
The operations defined for the specific type are placed in the
helper traits carrying the Ops suffix in the name. ie 

IterableOnceOps[+A, +CC[_], +C]
    IterableOps[+A, +CC[_], +C]    
        MapOps[K, +V, +CC[_,_] <: IterableOps[_, AnyConstr, _], +C]  
        SetOps[A, +CC[X], +C < SetOps[A, CC, C]]      
        SeqOps[+A, +CC[_], +C] 
        
        
//Details 
IterableOnce[+A]
    Iterable[+A] 
        abstract def iterator: Iterator[A]
        Set 
            ListSet 
            HashSet
                LinkedHashSet
            SortedSet 
                TreeSet 
                BitSet 
                
        Map 
            SortedMap 
                TreeMap 
            HashMap 
            SeqMap 
                ListMap 
                VectorMap 
                LinkedHashMap
            MultiMap 
            
        Seq 
            IndexedSeq
                Range 
                Vector 
                WrappedString 
                ArraySeq 
                    ofRef 
                    ofChar
                    ofByte 
                    ofBoolean 
                    ofUnit
            LinearSeq
                List 
                LazyList 
                Queue 
            Buffer  
                ListBuffer 
                        
            Buffer + IndexSeq             
                IndexBuffer 
                ArrayBuffer 
                ArrayDeque
                    Queue 
                    Stack 
        

trait Iterator[+A] 
    abstract def hasNext: Boolean
        Check if there is a next element available.
    abstract def next(): A
        Return the next element and advance the iterator.
            
///Using collection 
where S is Array, List, Seq, Set,....
Note 'object' can not take T, hence if required, mention T as part of method 
ex :  val m = collection.mutable.ListBuffer.fill(256)( null :Any); m(0) = "OK" ..

Note Type parameter is must sometimes eg 
val a = List.empty[Int]

S.empty[T] 						The empty sequence
S(x, y, z) 						A sequence consisting of elements x, y, and z - variable args 
S.concat(xs, ys, zs) 			The sequence obtained by concatenating the elements of xs, ys, and zs - variable args 
S.fill[T](n)(e) 				A sequence of length n where each element is computed by expression e
S.fill[T](m, n)(e) 				A sequence of sequences of dimension m x n where each element is computed by expression e (exists also in higher dimensions)
S.tabulate(n)(f) 				A sequence of length n where the element at each index i is computed by f(i)
S.tabulate(m, n)(f) 			A sequence of sequences of dimension m x n	where the element at each index (i, j) is computed  by f(i, j) (exists also in higher dimensions)
S.range[T](start, end) 			The sequence of integers start : : : end 
S.range[T](start, end, step) 	The sequence of integers starting with start and progressing by step increments up to, and excluding, the end value
S.iterate(x, n)(f) 				The sequence of length n with elements x, f(x), f(f(x)),...

//Example 
List.empty[Int]
List.fill(2)(3)
List.tabulate[Int](2)((i)=>3)


/// Array  - java core Array 
//fixed size, mutable, All collection methods can be used via ArrayOps implicits 
//runtime keeps Type , hence no type erasure 
//Array can be implicitly converted to Seq 

reflect.runtime.universe.typeOf[Array[Int]].members.toSet
reflect.runtime.universe.typeOf[collection.mutable.ArrayOps[Int]].members.toSet


//Usage - ++, :+, +: etc 
//genally single operation like + for one element 
//for multiple operations like ++, for another Collection 
// :+ where LHS is array , +: where RHS is array 

// Can use Array.empty, Array.fill etc 
val a = Array(1,2,3,4)
println(a.min)
a(0)  //res6: Int = 1
a(0) = 2
a contains 2  //res9: Boolean = true
Array.empty[Int]
Array.empty[Int] ++ Array.empty[Int]
Array.empty[Int] :+ 2
for(i <- a)println(i)


///Array Buffers - can grow in size by appending , but fast like Array
//operationWith suffix = for updating 
val buf = scala.collection.mutable.ArrayBuffer.empty[Int]
buf += 1
buf += 10
buf ++= Array(2,10)
buf.toArray

///HANDSON 
Json Parsing 
val str = "[1,2,3,4]"
Convert to  Array(1,2,3,4)

///List - List and collection.mutable.ListBuffer
//Insertion ordered, Indexing with (Int),
reflect.runtime.universe.typeOf[List[Int]].members.toSet

//Main Methods - Immutable  
slice(start,until) ,contains, 
isEmpty,  List[Int](),   ++, +:, :+, ::, ++:
//Main methods for Mutable   +=, ++=, -=, --=
//Conversion  toList, toMap, toSet, toArray

//genally single operation like + for one element 
//for multiple operations like ++, for another Collection 
// :+ where LHS is List , +: where RHS is List  


//shift -  stripFront
//unshift(prepend) - +:
//pop - stripEnd
//push - append or :+


val L = List(1,2,3)
val L = 1 :: 2 :: Nil
val L2 = 1 +: L :+ List(55,66)
L ++ List(2,3)
val L2 = 1 +: L :+ 55

val L = scala.collection.mutable.ListBuffer[Int]()
L += 2
L(0)
L(0) = 3
L contains 3

val l = 1 :: Nil
l(0)
l.head
l.tail
List(1,2,3,4).slice(1,3)  //no step 

//Append 
val L = scala.collection.mutable.ListBuffer[Int]()
L += 2
L ++= List(2)
L.append(2)

//Iterating 
val a = List((1,2,5),(2,3,4))
for( (i,j,k) <- a) println(s"$i,$j,$k")



///Hands ON 
square each element of below 
val a = List(1,2,3,4)

///Map   - Map or mutable.Map 

//Main Methods - mutable +=, ++=, -=, --=  
//or immutable ++, contains, ++:, ++, 

//genally single operation like + for one element 
//for multiple operations like ++, for another Collection 
// :+ where LHS is Map , +: where RHS is Map  

//For Map - call keys(), values() to get keys and values
//toList gives tupleSet

val m = Map('o'-> 1, 'b' -> 2)
m ++ Map('c'-> 3)
m +('c'-> 3)

//Mutable 
val m = collection.mutable.Map[String,Int]()
m("OK") = 2
m += ("NOK" -> 3)
m contains "OK"
m contains "OKK"
for( (k,v) <- m) println(""+k+v)
m.keys   //res30: Iterable[Char] = Set(o, b)
m.values  //res31: Iterable[Int] = MapLike(1, 2)
m.toList  //res34: List[(Char, Int)] = List((o,1), (b,2))

//With default
val m = Map[String, Int]().withDefaultValue(0)
m("OK")  //res0: Int = 0

//mutable.HashSet and mutable.HashMap 
//- No order for iteration, but fast lookup
val map = scala.collection.mutable.HashMap.empty[Int,String]
map += (1 -> "make a web site")
map += (3 -> "profit!")
map(1)  //res44: String = make a web site
map contains 2  //res46: Boolean = false


///With java collections 
def nums = {
              var list = new java.util.ArrayList[Int]()
              list.add(1)
              list.add(2)
              list  
          }
//Below is removed 
//import scala.collection.JavaConversions._
//nums.toSet

//import collection.JavaConverters._
import scala.jdk.CollectionConverters._
nums.asScala.toSet.asJava

///Pattern Matching 
case class Person(first:String, sec:String)
case object Request 

def extract(o:Any) = o match {
    case 0 | 1 | 2 => s"alternate"
    case Request => s"Request"
    case Twice(x) => s"Twice $x"  //unapply z/2
    case List(1,_,_) => s"List three"
    case a @ List(x,y @ _*) => s"$a $x $y"
    case Person("X", s ) => s"Person $s"
    case (x,y) if x == y => s"tuple same"
    case (x,y)  => "tuple"
    case x:String => "string"
    case x: Array[String] => "array string"
    case l : Seq[_]  => "seq"
    case ((x,y),(z,a),b)  => s"nested"
    case _ => "none"
}

//Scala2.13 
val y = "ram@jho"
y match {
        case s"$a@$b" => println(a+b)
     }
//ramjho

//Equivalent not there for f"" eg "$a%02d$f%2.3f$s%10s"

///Understanding function 
def add(x:Int, y:Int) = x + y

val add1 = (x:Int, y:Int) => x+y 

val add2 = add _ 

type AddType = (Int,Int) => Int 

val add1 = (x:Int) => (y:Int) => x+y 
add1(2)(3)

add _
//(Int, Int) => Int = <function2>

//partial application 
add(2, _:Int)                   
//Int => Int = <function1>

///Function2 to Function22 have few extra goodies 
//For example args converted to tupled 

(add _).tupled
//((Int, Int)) => Int = <function1>

(add _).tupled( (2,3) )
//Int = 5

(add _).curried(2)(3)

//Function1 has also few goodies 
val dou = (x:Int) => x*x 
val ai = (x:Int) => x+5

(dou andThen ai )(5)
(dou compose ai)(5)  //reverse 

///HOF 
def twistedadd( f: (Int, Int) => Int, x:Int, y:Int) = f(x,y)

twistedadd( (x:Int, y:Int) => x+y, 2,3)

///Many ways to declare add 
def add(x:Int, y:Int) = x+y

val add1: (Int,Int) => Int = (x,y) => x+y

val add3 = (x:Int,y:Int) => x+y

val add4 = (_:Int) + (_:Int)

def add5(x:Int)(y:Int) = x+y

def add6(x:Int) = {
        def _ad(y:Int) = x + y
       _ad _
 }

val add7 = (x:Int) => (y:Int) => x+y

val add8: Int =>Int => Int = x => y => x+y

///Overloading 
//Overloading is exactly like Java except it has problem if overloading defines default args 
//Only one overload can define default Args 

def f(x:Int, y:Int=0) = ???
def f(x:Int, y:String="") = ??? //Error 
def f(x:Int, y:String) = ??? //OK 


///Advantages of curry form 
//Default in curry form   
def defaultValues(a: String = "default")(b: Int = 0, c: String = a) = ???

//Inference is also good in curry form 
def f[A,B](x:A, fn: A=>B):B = fn(x)
f(2, _.toDouble) //Error
 
def f[A,B](x:A)(fn: A=>B):B = fn(x)
f(2)( _.toDouble)


///Disadv of curry form: Scala2 error but scala3:Changes in Overload Resolution 
Scala3: it takes all argument lists into account instead of just the first argument list(scala2)

def f(x: Int)(y: String): Int = 0
def f(x: Int)(y: Int): Int = 0

f(3)("")     // in scala2, error , scala3-OK 

def g(x: Int)(y: Int)(z: Int): Int = 0
def g(x: Int)(y: Int)(z: String): Int = 0

g(2)(3)(4)     // ok scala3, in scala2, error 
g(2)(3)("")    // ok scala3, in scala2, error 

The handling of function values with missing parameter types has been improved in scala3 

def f(x: Int, f2: Int => Int) = f2(x)
def f(x: String, f2: String => String) = f2(x)

f("a", _.toUpperCase) // scala3:ok , in scala2, error 
f(2, _ * 2)           // scala3:ok , in scala2, error 

///PartialFunction
val pf:PartialFunction[Int,Int] = {case x:Int if x!=0 => 42/x}


scala> pf(0)
scala.MatchError: 0 (of class java.lang.Integer)
  at scala.PartialFunction$$anon$1.apply(PartialFunction.scala:253)
  at scala.PartialFunction$$anon$1.apply(PartialFunction.scala:251)
  at $anonfun$1.applyOrElse(<console>:12)
  at $anonfun$1.applyOrElse(<console>:12)
  at scala.runtime.AbstractPartialFunction$mcII$sp.apply$mcII$sp(AbstractPartialFunction.s
cala:36)
  ... 40 elided

scala> pf(1)
res29: Int = 42

scala> pf.isDefinedAt(0)
res30: Boolean = false

scala> pf.isDefinedAt(1)
res31: Boolean = true

val pf1:PartialFunction[Int,Int] = {case x:Int if x == 0 => 0}

scala> (pf orElse pf1)(0)
res33: Int = 0

scala> val f:Function[Int,Int] = pf orElse pf1
f: Function[Int,Int] = <function1>



///FP with Function 
Check reference and try to understand reference 

val ls = List(1,2,3)
val map = Map("OK"->1, "Nok" -> 2) 


//foreach 
val p = (x:Int) => println(x) 

ls.foreach(p) 
ls.foreach(  println(_) )

println _ 
ls.foreach(println _ ) 
ls.foreach(println)
//this conversion is not valid for overloaded method case 
ls foreach println

map foreach println 
map foreach ( (x,y) => println(x)) //Nok 
map.foreach{case(x,y) => println(x)}

scala> map.foreach{t:Tuple2[String,Int] => println(t._1)}


//in terms of for loop 
for{
    i <- ls
    j = i*i 
    k <- i to j if j %2 == 0
}
{
    println(s"$i $j $k")
}


//Map 
ls.map(x => x*x) 
map.map{case (x,y) => x+y}

//in terms of for loop 
val out = for{
        i <- ls    
    } yield {
        i*i
    }
    

//flatMap 
scala> ls.flatMap(x => List(x,x*x))
res47: List[Int] = List(1, 1, 2, 4, 3, 9)


scala> map.flatMap{case (x,y) => Map(x->y*y)}
res48: List[(String, Int)] = List((OK,1), (Nok,4))

scala> map.flatMap{case (x,y) => Map(x->y*y)}.toMap
res49: scala.collection.immutable.Map[String,Int] = Map(OK -> 1, Nok -> 4)

//with for loops 
val first = List(1, 2)
val next = List(8, 9)
val last = List("ab", "cde", "fghi")

for {
  i <- first  if i %2 ==0   //flatmap with filter 
  j <- next      //flatmap
  k <- last      //map 
} yield {
    val len = k.size 
    i * j * len 
}

//Equivalent to Monadic form
first withFilter (t => t%2 == 0) flatMap {
  i => next flatMap {
    j => last map {
      k => 
        val len = k.size 
        i * j * len 
      
    }
  }
}


//filter 
ls.filter(x => x % 2 == 0)
map.filter{case (x,y) => y%2 == 0}


//collect 
ls.collect{ case x:Int if x%2==0 => x*x }
map.collect{case (x,y) if y%2 == 0  => (x,y*y)}



//reduce 
ls.reduce{ (r,t) => r+t }
map.reduce{(r,t) => (r._1+t._1, r._2+t._2) }

//foldLeft
ls.foldLeft(16){ (r,t) => r+t }
map.foldLeft( ("pre",10) ){(r,t) => (r._1+t._1, r._2+t._2) }

map.foldLeft( Map[String,Int]() ){ (r,t) => r ++ Map(t._1 -> t._2*t._2)}

//sortBy 
ls.sorted 
map.sorted 

ls.sortBy(x => -x) 
map.toList.sortBy{case(x,y) => y}

//def sortWith(lt: (A, A) ⇒ Boolean): List[A] 
ls.sortWith{ (a,b) => a > b }

map.toList.sortWith{(x,y) => x._2 > y._2}
map.toList.sortWith{case ((k1,v1),(k2,v2)) => v1 > v2}




//maxBy 
ls.maxBy(identity) 
map.toList.maxBy{case(x,y) => y}



//groupBy 
ls.groupBy( x => x % 2 )
map.groupBy{case (x,y) => x.size}



//Zip - shortest 
ls.zip( List("a", "b", "c")) //List((1,a), (2,b), (3,c))
map.zip( List("a", "b", "c")) //List(((OK,1),a), ((Nok,2),b))

ls.zip( List("a", "b", "c")).unzip //(List(1, 2, 3),List(a, b, c))

//to make equal 
//def zipAll[B](that: collection.Iterable[B], thisElem: A, thatElem: B): List[(A, B)] 

//ZipWithIndex 
ls.zipWithIndex //List((1,0), (2,1), (3,2))
map.zipWithIndex //List(((OK,1),0), ((Nok,2),1))

//any - def exists(p: (A) => Boolean): Boolean 
ls.exists( _ % 2 ==0 )
map.exists{case (k,v) => v % 2 ==0 }


//def indexWhere(p: (A) => Boolean): Int 
ls.indexWhere( _ % 2 == 0 )
map.indexWhere{case (k,v) => v % 2 ==0 }

//def partition(p: (A) => Boolean): (List[A], List[A]) 
ls.partition( _ % 2 ==0 )
map.partition{case (k,v) => v % 2 ==0 }


// forall(p: (A) => Boolean): Boolean 
ls.forall( _ % 2 ==0 )
map.forall{case (k,v) => v % 2 ==0 }

// dropWhile(p: (A) => Boolean): List[A] 
ls.dropWhile( _ % 2 == 1 )
map.dropWhile{case (k,v) => v % 2 ==1 }

// final def takeWhile(p: (A) ⇒ Boolean): List[A]  
ls.takeWhile( _ % 2 == 1 )
map.takeWhile{case (k,v) => v % 2 ==1 }



///Par 
//In 2.13, use 
libraryDependencies += "org.scala-lang.modules" %% "scala-parallel-collections" % "1.0.1"

import scala.collection.parallel.CollectionConverters._ 
//Put it in method if using with REPL, else hangs (in code, works)

def foo = (0 to 10).par.foreach(println)
def foo2 = (0 to 10).par.map(_*2).seq.foreach(println)




///Recursion 
def mysum(x:List[Int]):Int = if (x.isEmpty) 0 else x(0)+mysum(x.tail)

def mysum2(x:List[Int]): Int = x match {
        case h :: t => h + mysum2(t)
        case Nil => 0
}
//for TCO, function must be final or private such that subclass can not override that 
object Tail{
    @annotation.tailrec
    final def mysum3(x:List[Int], acc:Int=0):Int = x match {
        case h::t => mysum3(t, h+acc)
        case Nil => acc 
    }
}

def mysum4(x:List[Int]) = {
    @annotation.tailrec
    def _sum(y:List[Int], acc:Int):Int = y match {
        case h::t => _sum(t, h+acc)
        case Nil => acc 
    }
    _sum(x,0)
}

///HandsOn: 
Find max for an list 

///trampoline - Advanced recursion via heap 
In essence, trampolining is replacing recursive function calls 
with objects representing these calls.(so moving from stack to heap)

//Using below of TailRec 
object TailCalls 
    def done[A](result: A): TailRec[A]
        Used to return final result from tailcalling computation
    def tailcall[A](rest: => TailRec[A]): TailRec[A]
        Performs a tailcall
TailRec[A]
    final def flatMap[B](f: (A) => TailRec[B]): TailRec[B]
        Continue the computation with f and merge the trampolining of this computation with that of f.
    final def map[B](f: (A) => B): TailRec[B]
        Continue the computation with f.

//Example 
import util.control.TailCalls._

def fib(n: Int): TailRec[Int] =
  if (n < 2) done(n) else for {
    x <- tailcall(fib(n - 1))
    y <- tailcall(fib(n - 2))
  } yield (x + y)

fib(40).result
//OR 
import util.control.TailCalls._

def mysum4(x:List[Int]) = {
    def _sum(x:List[Int]):TailRec[Int] = if (x.isEmpty) done(0) else tailcall(_sum(x.tail)).map( _ + x.head)
    _sum(x).result
}

///HandsOn - Deepely nested function - Ackerman function:

val A: (Long, Long) => Long = (m, n) =>
  if (m == 0) n + 1
  else if (n == 0) A(m - 1, 1)
  else A(m - 1, A(m, n - 1))
  
        
