Day Two
#2. Understanding Types in Scala
#    Understanding Types in Scala
#    Understanding types
#    Types – all the way down
#    Using types to define domain constraints
4. Getting to Know Implicits and Type Classes
    Getting to Know Implicits and Type Classes
    Types of implicits
    View and context bounds
    Type classes
    Implicit scope resolution
5. Property-Based Testing in Scala
    Property-Based Testing in Scala
    Introduction to property-based testing
    Properties and Generators
//6. Exploring Built-In Effects
//    Exploring Built-In Effects
//    Introduction to effects
//    Option
//    Either
//    Try
//    Future    
    
------------------------

////-----------------Understanding Types in Scala------------------------------------------------------------------------------------------
2.      Understanding Types in Scala
·       Understanding Types in Scala
·       Understanding types
·       Types – all the way down
·       Using types to define domain constraints

///Understanding Types in Scala
There are four ways to define a type in Scala:
    By using a literal to define a singleton type
    By using the type keyword to define an alias for an abstract or concrete type
    By defining a class, object, or trait to create a concrete type
    By defining a method that creates a method type

//Example 
class SomeClass       //value is new SomeClass , whose type is SomeClass, many values can be created 
object SomeObject    // SomeObject is value(only one-singleton) whose type is SomeObject.type 

:type SomeObject //SomeObject.type
:type new SomeClass //SomeClass

trait SomeTrait {
    def usage(a: SomeClass, b: SomeObject.type): SomeTrait
}

class ClassWithSomeTrait extends SomeTrait{
    def usage(a: SomeClass, b: SomeObject.type): SomeTrait = this 
}
:type (new ClassWithSomeTrait).usage(new  SomeClass, SomeObject) //SomeTrait

A method type does not denote a value, nor does it appear directly in the program. 
It is an internal representation of a method definition. 
As we defined in the usage method, the compiler internally created a method type called 
(a: SomeClass, b:SomeObject.type) SomeTrait.

///Type - this.type  - returns concrete class type polymorphic
trait TA { def f:this } // NOK               

trait TA { def f:this.type  }  //OK

class A extends TA { def f = this} //but returns A , override can change return type

class B extends TA { def f = this} //but Returns B 

:type (new A()).f   // Return A object
:type (new B()).f   // returns B object


///Method Chaining by using this.type
class A {def method1: A = this }
class B extends A {def method2: B = this }

val b = new B()

b.method2.method1

b.method1.method2   //NOK as method2 belongs to B

//Use with this.type
class A {def method1: this.type = this }
class B extends A {def method2: this.type = this }

val b = new B()

b.method2.method1   //b.type = B@4a3a0004

b.method1.method2  //res45: b.type = B@4a3a0004

///Literal types
It is available for all types for which literal syntax is available 
(for example, Boolean, Char, String, and Symbol). I
t is impossible to define a literal type for Unit (by specification) 
and for Byte and Short (because there is no syntax to define literals of such types). 

These literal types are probably not very interesting for day-to-day programming, but are
very useful for type-level library development.

def bool2String(b: true) = "ja"
//bool2String: (b: true)String

bool2String(true)
//res7: String = ja

bool2String(false)
//error: type mismatch;

There are two ways to define a variable of a literal type. 

//OPTION-1: explicit type ascription
val a1: true = true
//a1: true = true

bool2String(a1)
//res10: String = ja

//OPTION2- not possible in scala3
final val a2 = true
//a2: Boolean(true) = true

bool2String(a2)
//res11: String = ja

Note below is not Literal 
val a3 = true
//a3: Boolean = true

bool2String(a3)
//error: type mismatch;

A literal type is erased to the normal type during compilation, 
and so it is not possible to overload methods using literal types:

object scope {
    def bool2String(b: true) = "ja"
    def bool2String(b: false) = "nein"
}
// error: double definition:

val t:42 = 42
//val t: 42 = 42

t + 2
//val res6: Int = 44

final val t2 = t + 2
//val t2: Int(44) = 44

In Scala 2.13, there is a new marker trait Singleton 
that can be applied as an upper bound on a type parameter, then singleton type would be passed in arg 

def singleIn[T <: Singleton](t: T): T = t

final val t = singleIn(42) //t: 42 = 42 //final is must to see singletone type 

//OR use .type to get singleton type , here normal type enters 
def singleOut[T](t: T): t.type = t

final val t = singleOut(42)
//t: 42 = 42

Since Scala 2.13, there is a type class called scala.ValueOf[T] and an operator
called scala.Predef.valueOf[T] that can be used to yield values for singleton types.

def valueOf[T](implicit vt: ValueOf[T]): T = vt.value

final val a = valueOf[42]
//a: 42 = 42

The pattern matching against literal types also works 

def int2str(i: Int) = i match {
    case t: 42 => "forty-two"
    case ii => ii.toString
}

int2str(42)
//res24: String = forhty-two

int2str(43)
//res25: String = 43



///Compound (intersection) types (scala3 has good support)
If just a refinement is given, the compound type is equivalent to extending AnyRef
eg def method[T <: { def ok:String }] 
This way of defining a type is known as a structural type. 

A single type is extended by using the corresponding extends keyword
Two or more types are combined by interleaving them with the with keyword

In the case of a name clash , the rightmost type or refinement has the highest priority.

//Example 
trait A { override def toString = "A" }
trait B { override def toString = super.toString + "B" }
trait C { override def toString = super.toString + "C" }


//Starts with E, C,B,A 
class E extends A with B with C {
    override def toString: String = super.toString + "D"
}

new E().toString
//res28: String = ABCD

scala.reflect.runtime.universe.typeOf[E].baseClasses //E,C,B,A 

///Type inference 
By finding the least upper bound(closest type common to all), check below function return types 

case class C(); class D(); case class E()

def iOrB(i: Int, s: Boolean)(b: Boolean) = if (b) i else s
//AnyVal

def iOrS(i: Int, s: String)(b: Boolean) = if (b) i else s
//Any

def sOrC(c: C, s: String)(b: Boolean) = if (b) c else   s
//java.io.Serializable 

def cOrD(c: C, d: D)(b: Boolean) = if (b) c else d
//AnyRef 

def cOrE(c: C, e: E)(b: Boolean)= if (b) c else   e
// Product with Serializable

trait Foo { def foo: Int }

case class F() extends Foo {def foo: Int = 0}
case class G() extends Foo {def foo: Int = 0}

def fOrG(f: F, g: G)(b: Boolean) = if (b) f else g
//Product with Serializable with Foo


///Trait: Runtime mixing 
class E 
trait A{
    def name:String 
    def print2 = println(this.name)
}

val e = new E 
val e1 = new E with A {
    def name = "OK"
}

class E1{
    def name = "NOK"
}

trait A2 extends A {
    override def print2 = println(s"Hello ${this.name}")
}
val e2 = new E1 with A 
val e3 = new E1 with A2
//Multiple 
trait T2 
val e4 = new E1 with A2 with T2 



///Stackable trait 
trait T1{
  def m(x:Int):Unit
}

class ET1 extends T1{
    def m(x:Int) = {println("ET1"); println(x) }
}

(new ET1).m(10) //10

//abstract override only allowed for trait 
trait T2 extends T1{
    abstract override def m(x:Int) = { println("T2"); super.m(x*x)}
}

(new ET1 with T2).m(10) //100 //Anon,T2,ET1,T1


trait T3 extends T1{
    abstract override def m(x:Int) = {println("T3"); super.m(x-2) }
}

(new ET1 with T2 with T3).m(10) //64 //Anon, T3,T2,ET1
(new ET1 with T3 with T2).m(10) //98 //Anon,T2,T3,ET1
(new ET1 with T2).m(10) //100 //Anon,T2,ET1
(new ET1).m(10) //10 //Anon,ET1

//No class can extend from abstract override Trait , used for only runtime mixing 
class AB extends T3{
    override def m(x:Int) = {println("AB"); println(x) }
}
//ERROR 







///Path-dependent types
A path can have one of the following forms:
    An empty path, denoted with . It cannot be written directly, but implicitly
    precedes any other path.

    C.this, where C is a reference class. This is the path that is constructed if this is
    used inside of a class.

    C.super.x. or C.super[P]. refers to the member x of the superclass or
    designated parent class, P of C. It plays the same role as this for the class, but
    refers to the classes that are upper in the hierarchy.

    p.x, where p is a path and x is a stable member of p. The stable member is an
    object definition or a value definition for which it is possible for the compiler to
    tell that it will always be accessible (as opposed to the volatile type where it is not
    possible, for example, there is an abstract type definition that can be overridden
    by a subclass).

Types within the path can be referred to by two operators, # (hash) and . (dot). The former
is known as type projection, and T#m refers to the type member m of the type T. 

We can demonstrate the difference between these operators by building a type-safe lock:

case class Lock() {
 final case class Key()
 def open(key: Key): Lock = this
 def close(key: Key): Lock = this
 def openWithMaster(key: Lock#Key): Lock = this
 def makeKey: Key = new Key  //Key shortcut for this.Key
 def makeMasterKey: Lock#Key = new Key //type projection, Lock#Key
}

The key can be referenced using its path, Lock.Key, or by using a projection, Lock#Key. 
The former denotes a type tied to a specific instance, and the latter denotes a type that is not. 

Because the path-dependent type refers to the concrete instance, the compiler will only allow the use of the
appropriate type to call the open and close methods:

val   blue: Lock = Lock()
val   red: Lock = Lock()
val   blueKey: blue.Key = blue.makeKey
val   anotherBlueKey: blue.Key = blue.makeKey
val   redKey: red.Key = red.makeKey

blue.open(blueKey) //takes only blue.Key 
blue.open(anotherBlueKey)
blue.open(redKey) // compile error
red.open(blueKey) // compile error

The masterKey is not path-dependent, and so can be used to call methods on any instance in a typical way:

val masterKey: Lock#Key = red.makeMasterKey

blue.openWithMaster(masterKey)
red.openWithMaster(masterKey)


///Scala self type - creating dependencies 

trait   A   {   def a: String }
trait   B   {   def b: String }

//C must be mixed with A
trait   C   {   this: A => // override `this`, now this is A  
  def   c   =   this.a
}

//D must be mixed with A and B 
trait   D { self: A with B => // any alias is allowed, but generally this or self is used 
  def   d = self.a + this.b //can access like self or this 
}

abstract class DD extends D  //Error 
abstract class DD extends D with A with B 


///Renaming this or Outer.this  - self type  
class A {
  outer =>
  private val a:Int = 0
  private class B {					// if this is private, A can access it's public member, but outside world can not
     inner =>
	  private val b:Int = 0        //since it is private, outerclass can not access (unlike Java)
	  def m = outer.a + inner.b    // outer === A.this and inner == this. Note inner class can access Outer's private 
	  }
  def m2 = { val i = new B ; i.m }  
 }
	
new A#B()  // note A#B is only a type, can not be used as constructor
val a:A#B = { val m = new A; new m.B } //a: A#B = A$B@57b59fa2  // if B is private , new m.B fails

///Trait: Same name methods 
trait A{
    def m = "from A"
}

class B extends A {
    override def m = "from B"
}

class C extends B with A {
    def a = super.m 
    def b = super[A].m 
}

scala.reflect.runtime.universe.typeOf[C].baseClasses 

/// type Bounds 
"""

                                 Name                     Description
A <: B                           Upper bound              A must be a subtype of B. , java- A extends B
A >: B                           Lower bound              A must be a supertype of B. , java- none
A >: Lower  <: Upper             Both Bound               Lower must come first, Java - none
A <% B                           View bound 		      A can be converted to B via implicit method or class                                
A : M                            Context Bound            A can be converted to M[A] via implicit class/object. Applicable for parametric/container type M
A >: Lower  <: Upper : M         Both Bound + context     context bound comes last

Eg:
def f[T >: Int <: AnyVal  : Numeric](x:List[T]) = x :+ Nil

Note traits cannot have type parameters with context bounds nor view bounds 

Note object can not have Type parameter

Multiple Bounds
A <: B with C with D     - B,C,D are traits or class, order does not matter(unlike java -class must be first)

Structural type
A <: AnyRef with B {def method }
OR
A <: A1{def method: Unit}     means Derived from A1 with a new method 'method'

"""

//Example 
class A[T <:AnyVal]
new A[Int]

class A[T >: AnyVal]
new A[Any]

class A[T >:AnyVal <: Any]
new A[AnyVal]

///Type parameters
The scope resolution rules apply to the type parameters the same way as they do 
to the normal parameters, as shown by the unwrap method definition.

case class Wrapper[A](content: A) {
  def unwrap: A = content
}

def createWrapper[A](a: A):Wrapper[A] = Wrapper(a)

type ConcreteWrapper[A] = Wrapper[A]

val   wInt: Wrapper[Int] = createWrapper[Int](10)

val   wLong: ConcreteWrapper[Long] = createWrapper(10L) //inference 
val   int: Int = wInt.unwrap
val   long: Long = wLong.unwrap

//This type inference is in fact quite powerful. 

case class Abc[A](a: A, b: A, c: A)
val intA: Abc[Int] = Abc(10, 20, 30)
val longA: Abc[Long] = Abc(10L, 20L, 30L)
val whatA: Abc[AnyVal] = Abc(10, 20, true)
val whatB: Abc[io.Serializable] = Abc("10", "20", Wrapper(10))
val whatC: Abc[Any] = Abc(10, "20", Wrapper(10))

It is possible to restrict possible definitions of the type parameter by using type constraints,
as shown in the following example:

trait Constraints[A <: AnyVal, B >: Null <: AnyRef] {
  def a: A
  def b: B
}

// compile error - type parameter bounds
// case class AB(a: String, b: Int) extends Constraints[String, Int]

case class AB(a: Int, b: String) extends Constraints[Int, String]




///Type members or abstract type 
Type constraints are rules associated with a type. 
using the symbols >: (lower, unhappy bound, greaterthan) and <: (upper, happy bound, lessthan)
( S >: L <: U : ContextBound)

object Constraints{
    trait A 
    trait B extends A
    trait C extends B
}
trait bounds {
    type LOWER  >: Constraints.B    //Supertype of B , so B is lower 
    type UPPER  <: Constraints.B    //Subtype of B , so B is upper
}

The type constraints are inclusive, which is why type B represents both the upper and
lower bounds. Besides B in our type hierarchy, only A obeys the LOWER type constraint and
only C obeys the UPPER constraint.

trait boundsA extends bounds {
    override type LOWER = Constraints.A 
    override type UPPER = Constraints.A //compiler error 
}
trait boundsA extends bounds {
    override type LOWER = Constraints.B 
    override type UPPER = Constraints.B 
}
trait boundsC extends bounds {
    override type LOWER = Constraints.C   //compiler error 
    override type UPPER = Constraints.C 
}


//MOre examples (INTERNAL)
trait HolderA {
  type A  //type members 
  def a: A
}
class A extends HolderA {
  override type A = Int
  override def a = 10
}

//multiple type members
trait HolderBC {
 type B
 type C <: B
 def b: B
 def c: C
}

Type inference is not applied in this case, so the following code will not compile because
the type definition is missing:

class BC extends HolderBC {
 override def b = "String"
 override def c = true
}

//complex one 
trait HolderDEF {
    type D >: Null <: AnyRef
    type E <: AnyVal
    type F = this.type
    def d: D
    def e: E
    def f: F
}

class DEF extends HolderDEF {
    override type D = String
    override type E = Boolean

    // incompatible type String
    // override type E = String
    // override def e = true

    override def d = ""
    override def e = true

    // incompatible type DEF
    // override def f: DEF = this

    override def f: this.type = this
}

It is also possible to combine type members and type parameters and use them later to
further constrain possible definitions of the former:

abstract class HolderGH[G,H] {
  type I <: G
  type J >: H
  def apply(j: J): I
}

class GH extends HolderGH[String, Null] {
  override type I = Nothing
  override type J = String
  override def apply(j: J): I = throw new Exception
}

///Infix types
In the same way that Scala has infix operators, it has infix types.

trait Dummy[A,B]

type   Or[A, B]  = Dummy[A,B]
type   And[A, B] = Dummy[A,B]

type   +=[A, B] = Or[A, B]
type   =:[A, B] = And[A, B]

type CC[A,B,C] = Or[And[A, B], C]
type DA[A,B,C] = A =: B =: C
type DB[A,B,C] = A And B And C

// type E = A += B =: C // wrong associativity
type F[A,B,C] = (A += B) =: C

If used properly, infix types can greatly improve the readability of the code:
type |[A, B] = Or[A, B]
type &[A, B] = And[A, B]
type G[A,B,C] = A  &  B | C


///When to use Type parameters and Type members 
Type parameters are used to define input types and type members to define the output  type 

trait Generic[A] {
    type Repr
    def to(value: A): Repr
    def from(value: Repr): A
}

Suppose we implement a method getRepr as follows.What type will we get back?

import shapeless._
def getRepr[A](value: A)(implicit gen: Generic[A]) =  gen.to(value)

The answer is it depends on the instance we get for gen

case class Vec(x: Int, y: Int)
case class Rect(origin: Vec, size: Vec)


getRepr(Vec(1, 2))
// res1: Int :: Int :: shapeless.HNil = 1 :: 2 :: HNil


getRepr(Rect(Vec(0, 0), Vec(5, 5)))
// res2: Vec :: Vec :: shapeless.HNil = Vec(0,0) :: Vec(5,5) :: HNil

What were seeing here is called dependent typing: the result type of getRepr
depends on its value parameters via their type members. 

Suppose we had specified Repr as type parameter on Generic instead of a type member:

trait Generic2[A, Repr]
def getRepr2[A, R](value: A)(implicit generic: Generic2[A, R]): R =   ???

We would have had to pass the desired value of Repr to getRepr as a type
parameter, effectively making getRepr useless. 

Conclusion: type parameters are useful as "inputs" and type members are useful as "outputs".

///Generalized type constraints 
There is also another way(than bounds) to specify boundaries for type parameters and type members in
Scala, Generalized type constraints.

A <:< B is same as A <: B, but is used as implicits , 
hence resolution is deferred via searching implicit scope whereas A <: B is checkded during compiler checking 



abstract class Wrapper[A] {
  val a: A
  //eg, flatten Wrapper[A] when A is of Wrapper[X] 
  // A in flatten would shadow A in the Wrapper if written below way 
  // def flatten[B, A <: Wrapper[B]]: Wrapper[B] = a
  def flatten[B](implicit ev: A <:< Wrapper[B]): Wrapper[B] = a
}

val aa = new Wrapper[Wrapper[Int]]{ val a = new Wrapper[Int]{ val a = 2} }
aa.flatten //Wrapper[Int]

Using implicit ev will be available in scope if the compiler can prove that the subtype relation holds.

def flatten[B, A <: Wrapper[B]]: Wrapper[B] = a
On line 5: error: type mismatch
        found   : A
        required: Wrapper[B]
        

Similarly A=:= B is same as A = B but used as implicits such that it is deferred 

case class Foo[A](a:A) { // 'A' can be substituted with any type
    // getStringLength can only be used if this is a Foo[String]
    def getStringLength(implicit evidence: A =:= String) = a.length
}

Foo("blah").getStringLength
 
//Another example 
Suppose you want to define a homogeneous Pair

class Pair[T](val first: T, val second: T)

Now you want to add a method smaller, like this:

def smaller = if (first < second) first else second

That only works if T is ordered. You could restrict the entire class:

class Pair[T <: Ordered[T]](val first: T, val second: T)

But now T has to be ordered and Pair can not be used for any other T 
To solve that, defer T <: Ordered[T]

class Pair[T](val first: T, val second: T) {
    def smaller(implicit ev: T <:< Ordered[T]) = if (first < second) first else second
}

//Another example 
On Either[+A, +B], you have (so B1 or A1 must be Either

 def joinRight[A1 >: A, B1 >: B, C](implicit ev: B1 <:< Either[A1, C]): Either[A1, C] = this match {
   case Left(a)  => Left(a)
   case Right(b) => b
 }

 def joinLeft[A1 >: A, B1 >: B, C](implicit ev: A1 <:< Either[C, B1]): Either[C, B1] = this match {
   case Left(a)  => a
   case Right(b) => Right(b)
 }

On Option, you have:

def orNull[A1 >: A](implicit ev: Null <:< A1): A1 = this getOrElse null





///Variance 
//In JAVA - PECS ie Producer-Extend,  Consumer-Super 
C[+T]  co-varient means , T is produced, or in function-return or can be read/get from C 
       means C[T'] is subtype of C[T] if T' <: T
       Whenever C[T] is required, one can pass C[T'] and usage can operate on C[T'] to get/read T
C[+T]  contravarient means , T is consumed, or in function-arg or can be put/write in C 
       means C[T] is subtype of C[T'] if T' <: T 
       Whenever C[T'] is required, one can pass C[T] and usage can operate on C[T] to put/write of T   //'
   

//Variances  is for the case 
//how C[T] and C[T'] are related if T is related to T' 
// T , only same type can be used, mutable
// +T, derived type can be used , immutable , this class produces T (ie returns)
// -T , super type can be used , immutable, this class consumes T (ie arg)

//if generic type only acts as parameter: using contravariance. 
//if generic type only acts as retrun value: using covariance. 
//as in Function1[-T,+R]
"""
Note  If C[T] and  C'[T] are always related if C' <: C or vice versa
(ie List[Int] is subtype of Seq[Int] as List <: Seq) 

Variance is only applicable of container/parametric class/trait (C[T]) 
and defines rules for C[T] relational with C[T'] 
ie what can be passed in method taking C[T] or any assignments of C[T] by C[T']


Array[T]        Invariant   Used when elements in the container are mutable.
                            Example: Can only pass Array[String] to a method expecting  only Array[String].

Seq[+A]         Covariant   Used when elements in the container are immutable. 
                            if B <: A, then C[B] <: C[A] and C[B] can be passed to any method expecting  C[A]
                            Example: Can pass a Seq[String] to a method expected Seq[Any].
							We can pass Seq[Any] as well as  List[String], List[Any] as List <:Seq

Foo[-A]     Contra variant Contra-variance is opposite of covariance 
                           if B >: A, then C[B] <: C[A] and C[B] can be passed to any method expecting  C[A]
                           Example: Can pass a Foo[Any] to a method expected Foo[String].

1. because of List[+T] , List is immutable, ie only val and inside List, T can be not used as arg of methods directly
   -T can not be used as var or val 
   Note val means get*() returns T and var means both set*(T) and get*:T
   


Given Function1[-T,+R], 
    ie arg is contravariant and return is covariant 
val name:T , creates   def name:T  ie returns T
    means T has to be covariant or Invariant
var name:T, creates def name:T and def name_=(x:T), ie both arg and return type
    means T can be only Invariant

1. one side effect of +T is that, T can only be used as val (not var) inside class(hence immutable)
(not practical because val with generics can not be initialized)
and in return type of function(not argument type) as arguments of functions are contra-variant ,
hence use like below to have a arguments of T when T is covariant
def meth[U >: T](x:U):T
(Note U <: T is not possible for +T)

2. one side effect of -T is that, T can not used as return type of method(but can be used as argument type)
as return type of method is covariant . 
Hence can not be used for val, var declaration(as get method returns T)
class A[-T]( val x:T) //Not OK as get method
class A[-T]( x:T) //OK, no get method
To use as return type , use 
def meth[U <: T](x:T):U
(Note U >: T is not possible for -T)
"""

//here 
//Examples 
val l:Array[AnyVal] = Array[Int](1,2,3,4) //NOK 
val l2 :List[AnyVal] = List[Int](1,2,3)

class A[T]
val la:A[AnyVal] = new A[Int] //Error 

class A[+T]
val la:A[AnyVal] = new A[Int] //OK

class A[-T]
val la:A[Int] = new A[AnyVal] //OK


///covariant type T occurs in contra-variant position - Error
class A[+T]{
    def m(x:T) = println(x)
}
class A[+T](x:T){
    def m:T = x 
}
class A[+T]{
    def m[B>:T](x:B):T = ???
}

///Variance - why needed 
sealed trait Glass[Contents]
case class Full[Contents](contents: Contents) extends Glass[Contents]
case object Empty extends Glass[Nothing]

case class Water(purity: Int)

def drinkAndRefill(glass: Glass[Water]): Unit = ???
drinkAndRefill(Full(Water(100))) //OK 
drinkAndRefill(Empty) // compile error, wrong type of contents

//To Solve , change method as Nothing <: Water 
def drinkAndRefill[B <: Water](glass: Glass[B]): Unit = ???

//OR ,  Glass[Nothing] <: Glass[Water] as Nothing <: Water 
sealed trait Glass[+Contents]  //covariant 
case class Full[Contents](contents: Contents) extends Glass[Contents]
case object Empty extends Glass[Nothing]

def drinkAndRefill(glass: Glass[Water]): Unit = ???

drinkAndRefill(Full(Water(100)))
drinkAndRefill(Empty) // compiles fine

Now, let imagine that our glass is supposed to interact with a drinker. 

class Drinker[T] { def drink(contents: T): Unit = ??? }

sealed trait Glass[Contents] {
  def contents: Contents
  def knockBack(drinker: Drinker[Contents]): Unit = drinker.drink(contents)
}
case class Full[C](contents: C) extends Glass[C]

Now, let inspect what happens if we have two different kinds of Water:

class Water(purity: Int)

class PureWater(purity: Int) extends Water(purity) {
  def shine: Unit = ???
}

val glass = Full(new PureWater(100))
glass.knockBack(new Drinker[PureWater]) //OK 

Obviously, if somebody can drink just water, they should be able to drink pure water as well:

glass.knockBack(new Drinker[Water]) // compile error

To fix this, we need to use contravariance, which is denoted by the - (minus sign) before the
type parameter. 

class Drinker[-T] { def drink(contents: T): Unit = ??? }
glass.knockBack(new Drinker[Water]) // compiles

It is important to notice that co- and contravariance do not define the type itself, but only
the type parameters . 


///Existential types
Existential types come into play if we stop caring about the specifics of type parameters.
(Existential types used in function arguments whereas Higher kinded is used in type parameters/members)

A[_] means any A 

def p(x:Array[_]) = x.size 
//not same as 
def p1(x:Array[Any]) = x.size 

p1(Array("OK"))  //1
p1(Array[String]("OK")) //error 
p(Array[String]("OK"))

//above means 
def p3[T](x:Array[T]) = x.size 

//Existential type with bound
def f(x:List[_]) = x.length            //OK
def f(x:List[_ <: AnyVal]) = x.length  //OK
def f(x:List[_ : Numeric]) = x.length   //ERROR as _ does not take context bound

This syntax is just a shorter version of the more powerful syntax T forSome { Q }, where
Q is a sequence of type declarations, (scala3 -removed)

we can write Array[_] to mean Array[T] forSome { type T}.
(Note but higher kinded _ has different meaning ,only used in type definition eg class/trait 
or type parameter of methods whereas Existential is used in arguments)

import scala.language.existentials

Array[T] forSome { type T; }
Array[T forSome { type T; }]

They look almost identical, but they re in fact very different.
The first is the type of all arrays, whatever their type parameter(=existential). 
The second is Array[Any]

We have a Map. We want it to map any Class to Strings. 
What type do we use?

Map[Class[T forSome { type T}], String]  //Map[Class[Any], String]
Map[Class[T] forSome { type T}, String]  //Not same as Map[Class[_], String] !!!- This we want 
Map[Class[T], String] forSome { type T}  //some T, and Class[T] is for that T 

The correct answer is "Map[Class[T] forSome { type T}, String]", (middle one)

The third one is the supertype of all map types such that there is some T such that 
they are a Map[Class[T], String]. we have got some fixed class type for keys in the map

So what happens if we try to use this in the above and write Map[Class[_], String]? 
It turns out, we get "Map[Class[T], String] forSome { type T}". 
The wildcards always bind to the outermost level of the type expression. 




///Higher kinded types
sealed trait Contents
case class Water(purity: Int) extends Contents
case class Whiskey(label: String) extends Contents

sealed trait Container[C <: Contents] { def contents: C }
case class Glass[C<: Contents](contents: C) extends Container[C]
case class Jar[C <: Contents](contents: C) extends Container[C]

//The glass and the jar can both be filled with any contents. 
def fillGlass[C <: Contents](c: C): Glass[C] = Glass(c)
def fillJar[C <: Contents](c: C): Jar[C] = Jar(c)

Looks duplicated , so rewriting above  via trait 

sealed trait Filler[CC[_ <: Contents]] {  //higher kinded as _ is in type definitation 
  def fill[C](c: C): CC[C]
}
Filler[G] is a higher order(2nd order) type that uses G[_]  , another higher kinded (1st order)
Higher kinded types are also called type constructor as it created other type 
Zero ordered types are types of values eg Int 
Higher-kinded types are type constructors such as List or Map (which takes Zero ordered type),

object GlassFiller extends Filler[Glass] {
  override def fill[C <: Contents](c: C): Glass[C] = Glass(c)
}
object JarFiller extends Filler[Jar] {
  override def fill[C <: Contents](c: C): Jar[C] = Jar(c)
}

//Now using G[_] type constructor 
def fill[C <: Contents, G[_ <: Contents]](c: C)(F: Filler[G]): G[C] = F.fill(c)

val fullGlass = fill(Water(100))(GlassFiller)
val fullJar = fill(Water(100))(JarFiller)


Higer kinded are similar to HOF 

//first order function
scala> val f =  (x:Int,y:Int) => x+y
f: (Int, Int) => Int = <function2>

scala> :type f
(Int, Int) => Int

//Type Constructor 
:kind -v List
//List's kind is F[+A]
//* -(+)-> *
//This is a type constructor: a 1st-order-kinded type.

:kind -v Filler
//Filler's kind is X[CC[_ <: iw$Contents]]
//(*(iw$Contents) -> *) -> *
//This is a type constructor that takes type constructor(s): a higher-kinded type.



class C[T,U[X]]
class D[T,U[_],X[_,_[_]]]  //same as D[T,U[Z],X[Z,X1[Z]]] as inside []'s type does not matter

scala> :kind -v D
//D's kind is Y[A1,F1[A2],X[A3,F2[A4]]]
//* -> (* -> *) -> (* -> (* -> *) -> *) -> *
//This is a type constructor that takes type constructor(s): a higher-kinded type.


///One example of HigherKinded type Usage 

def size[T, C[X] <: Seq[X] ](x:C[T]) = x.size
//OR 
def size[T, C[_] <: Seq[_] ](x:C[T]) = x.size


//example: To remove complicated casting 
trait Optional[+T]
case class Sm[T](x:T) extends Optional[T]
case object Nn extends Optional[Nothing]


val map: Map[Optional[Any], List[Any]] = Map(
   Sm("foo") -> List("f", "O"),
   Sm(42) -> List(2,3,4),
   Sm(true) -> List(true, false, false))

//ugly cast
val xs: List[String] = map(Sm("foo")).asInstanceOf[List[String]]
val ys: List[Int] = map(Sm(42)).asInstanceOf[List[Int]]


//:Paste
class HOMap[ K[_], V[_]]( val map : Map[ K[Any], V[Any] ]) {
 def apply[A](key: K[A]) : V[A] =  map(key.asInstanceOf[K[Any]]).asInstanceOf[V[A]]
}
object HOMap {
    type Pair[K[_], V[_]] = (K[Any], V[Any]) 
    def apply[K[_], V[_]](tuples: Pair[K,V]*) = new HOMap[K, V]( Map(tuples: _*) )
}


val map_b: HOMap[Optional, List] = HOMap[Optional, List](
  Sm("foo") -> List("foo", "bar", "baz"),
  Sm(42) -> List(1, 1, 2, 3, 5, 8),
  Sm(true) -> List(true, false, true, false)
)

val xs_b: List[String] = map_b(Sm("foo"))
val ys_b: List[Int] = map_b(Sm(42))
println(xs_b)
println(ys_b)




///Type Lambdas 
Type Lambda are used where container type(higher kinded type) is required 

def fn[A, F[_]](x : F[A]) = x 

For List, Set, above can be used as those take single type parameters 

val x = List(1,2,3)
fn[Int, List](x)  
//OR 
fn(x)
//OR 
fn[Int, ({type L[A] = List[A]})#L ](x)  //scala 2 

But if we have Map[X,Y], then how to use it ? We need to fix one of X,Y 

// partially-applied type named "MapA"
type MapA[A] = Map[Int, A]

//USage 
val m = Map(1 -> "OK", 2->"NOK")
fn(m) //OK 

scala> fn[Int, Map](m)
-- Error:
1 |fn[Int, Map](m)
  |             ^
  |             Found:    (m : Map[Int, String])
  |             Required: Map[Int]

//SOlution is type lambda 
fn[String, ({type L[A] = Map[Int, A]})#L](m) 
//OR 
fn[String, MapAA](m)

//Another example 
trait Functor[A, +M[_]]{   //M[_] is produced 
  def map[B] (f: A => B): M[B]
}
 
//for Seq
case class SeqFunctor[A](seq: Seq[A]) extends Functor[A, Seq]{ 
  def map[B](f: A => B): Seq[B] = seq.map(f)
}
 
val lst = List(1,2,3)
SeqFunctor(lst).map(_ * 10)  // prints List(10, 20, 30)
 
//But for Map, as Map take two Types, need to fix either K or V 
//lets maps V so we need to fix K in M[_]

case class MapFunctor[K,V](mapKV: Map[K,V]) extends  Functor[V, ({type L[X] = Map[K,X]})#L ]{  // K is fixed  Xie value is variable 
   def map[V2](f: V => V2): Map[K, V2] =  mapKV.map{ case (k,v) => (k, f(v))  }
}
 
MapFunctor(Map(1->1, 2->2, 3->3)).map(_ * 10)// Result: Map(1 -> 10, 2 -> 20, 3 -> 30)
 
//Another way to implement, use ` ` to define variable name
case class ReadableMapFunctor[K,V](mapKV: Map[K,V]){
  type `Map[K]`[V2] = Map[K, V2]
  def mapFunctor[V2] = new Functor[V, `Map[K]`] {
        def map[V2](f: V => V2): `Map[K]`[V2] = mapKV.map{ case (k,v) => (k, f(v))  }    
  }
} 

ReadableMapFunctor(Map(1->1, 2->2, 3->3)).mapFunctor.map(_*10)
//Map(1 -> 10, 2 -> 20, 3 -> 30)



///Package objects 
Scala provides package objects as a convenient container shared across an entire package.

They are frequently used to hold package-wide type aliases and implicit conversions. 
Package objects can even inherit Scala classes and traits.

Each package is allowed to have one package object. 
Any definitions placed in a package object are considered members of the package itself.

Assume first a class Fruit and three Fruit objects in a package gardening.fruits:

// in file gardening/fruits/Fruit.scala
package gardening.fruits

case class Fruit(name: String, color: String)
object Apple extends Fruit("Apple", "green")
object Plum extends Fruit("Plum", "blue")
object Banana extends Fruit("Banana", "yellow")
//Apple.color 

Now assume you want to place a variable planted and a method showFruit directly 
into package gardening.fruits. 

// in file gardening/fruits/package.scala
package gardening   //parent package 
package object fruits {
  val planted = List(Apple, Plum, Banana)
  def showFruit(fruit: Fruit): Unit = {
    println(s"${fruit.name}s are ${fruit.color}")
  }
}

The following object PrintPlanted imports planted and showFruit in exactly 
the same way it imports class Fruit, using a wildcard import on package gardening.fruits:

// in file PrintPlanted.scala
import gardening.fruits._
object PrintPlanted {
  def main(args: Array[String]): Unit = {
    for (fruit <- planted) {
      showFruit(fruit)
    }
  }
}

Package objects are like other objects, which means you can use inheritance for building them. 
For example, one might mix in a couple of traits:

package object fruits extends FruitAliases with FruitHelpers {
  // helpers and variables follows here
}

///Type Recursion or f bound polymorphic

//Suppose , want to double atinumeric type
trait Doubler[T] {
  def double: T         //note double returns T which is Doubler's contained type
}

//below is OK
case class Square(base: Double) extends Doubler[Square] {
  def double: Square = Square(base * 2)
}

//Below is illogical, but OK, as Doubler can take any Type
case class Person(firstname: String)
case class Square(base: Double) extends Doubler[Person] {
  override def double: Person = Person("some")
}

//How to put a constraint such that above is not possible
//ie Double must contain type which is related

//Make T <: Double[T] called f bound polymorphic or self recursive 
//means: T must be subtype of Doubler[T]
//Not possible to extends Doubler with a type which doesn’t extend Doubler in turn
 
//in Java, Enum<E extends Enum<E>>

trait Doubler[T <: Doubler[T]] {
  def double: T
}
//below is OK
case class Square(base: Double) extends Doubler[Square] {
  def double: Square = Square(base * 2)
}
//But
case class Person(firstname: String)
case class Square(base: Double) extends Doubler[Person] {} //Error as Person is not subtype of Doubler

//But below is still OK as Square is subtype of Doubler[T]
//but illogical

case class BadDoubler(kind: String) extends Doubler[Square] {
  override def double: Square = Square(5)
}

//to put a constraint, such that above is wrong , use self type such that self must be T
 
trait Doubler[T <: Doubler[T]] { self: T =>
  def double: T
}


// Another example - Using Ordered[_]

trait Container extends Ordered[Container]

class MyContainer extends Container {
  def compare(that: MyContainer): Int  = 0   //fails as it requires def compare(that: Container): Int from Ordered[Container]
}

//Solution use self recursive 
trait Container[A <: Container[A]] extends Ordered[A]

class MyContainer extends Container[MyContainer] { 
  def compare(that: MyContainer) = 0 
}

List(new MyContainer, new MyContainer, new MyContainer)
       

//Another example - How to enforce comparison with same type
 
// naive impl, any derived class of Fruit can be used for comparison

trait Fruit {
  final def compareTo(other: Fruit): Boolean = true 
}

class Apple  extends Fruit
class Orange extends Fruit

val apple = new Apple()
val orange = new Orange()

apple compareTo orange // compiles, but we want to make this NOT compile!

//Solution
// Create atinew Type for each T, hence comparison fails

trait Fruit[T <: Fruit[T]] {
  final def compareTo(other: Fruit[T]): Boolean = true 
}

class Apple  extends Fruit[Apple]
class Orange extends Fruit[Orange]

val apple = new Apple
val orange = new Orange

orange compareTo apple  //NOK
orange compareTo orange  //res1: Boolean = true


//Another Example 
We will now extend Lock with an open method, which should return the same type
of Lock and let our implementations serve as type parameters:

sealed trait Secret[E]

sealed trait Lock[E] { 
    def open(key: Secret[E]): E = ??? 
}

case class PadLock() extends Lock[PadLock]
case class CombinationLock() extends Lock[CombinationLock]

Now, with this implementation, there is an issue that we can use it with something that is
not a Lock at all:

case class IntLock() extends Lock[Int]
lazy val unlocked: Int = IntLock().open(new Secret[Int] {})

Naturally, we do not want to allow this! We want to constrain our type parameter so that it
is a subtype of Lock:

sealed trait Lock[E <: Lock]

But unfortunately, this wonot compile because the Lock takes a type parameter that is
absent in the preceding definition. We need to provide that type parameter. 

sealed trait Lock[E <: Lock[E]] {
  def open(key: Secret[E]): E = ???
}

case class IntLock() extends Lock[Int]
//Error 

case class PadLock() extends Lock[PadLock]
//defined class PadLock

But unfortunately, we can still mess things up by defining the wrong subtype as a type
parameter:

scala> case class CombinationLock() extends Lock[PadLock]
defined class CombinationLock

Therefore, we need to define another constraint that will say that the type parameter should
refer to the type itself, not just any Lock. We already know that there is a self-type that can
be used for that:

sealed trait Lock[E <: Lock[E]] { self: E          =>
  def open(key: Secret[E]): E = self
}

case class CombinationLock() extends Lock[PadLock]
//Error 

PadLock().open(new Secret[PadLock]{})
CombinationLock().open(new Secret[CombinationLock]{})


///Phantom types (marker trait which does not have Runtime representation)
The phantom type in Scala is a type that is never instantiated at runtime. Because of this, it is
only useful at compile time to express domain constraints 

sealed trait Lock
class PadLock extends Lock
class CombinationLock extends Lock

We would like to encode in the type system that only the following state transitions are
allowed for any locks:

open -> closed
closed -> open
closed -> broken
open -> broken

we will use the phantom types Open, Closed, and Broken to model the states 

sealed   trait   LockState
sealed   trait   Open extends LockState
sealed   trait   Closed extends LockState
sealed   trait   Broken extends LockState


case class Lock[State <: LockState]() {
    //And define our state transitioning methods using type constraints:
    def break: Lock[Broken] = Lock()                //Any State can break it 
    def open[_ >: State <: Closed](): Lock[Open] = Lock()  //when Closed, -> Open 
    def close[_ >: State <: Open](): Lock[Closed] = Lock() //When Open, -> Closed
}

val openLock = Lock[Open]
//openLock: Lock[Open] = Lock()

val closedLock = openLock.close()
//closedLock: Lock[Closed] = Lock()

val broken = closedLock.break
//broken: Lock[Broken] = Lock()

closedLock.close()
//Error: inferred type arguments [Closed] do not conform to method close

openLock.open()
//error: inferred type arguments [Open] do not conform to method open type


We can also provide an alternative implementation by using generalized type constraints:

def open(implicit ev: State =:= Closed): Lock[Open] = Lock()
def close(implicit ev: State =:= Open): Lock[Closed] = Lock()

It is arguable that the generalized syntax conveys the intention much better as it almost
reads as State should be equal to Closed in the first case or State should be
equal to Open in the second case.




////-----------------Getting to Know Implicits and Type Classes------------------------------------------------------------------------------------------
4.       Getting to Know Implicits and Type Classes
·       Getting to Know Implicits and Type Classes
·       Types of implicits
·       View and context bounds
·       Type classes
·       Implicit scope resolution

///Various usages of Implicits

//1.implicit conversion - Scala3-Conversion or extension 
class Conv(x:String) {
    def toIntx(rx:Int) = Integer.valueOf(x,rx)
}

(new Conv("AB")).toIntx(16)
implicit def xyz(x:String) = new Conv(x)
"AB".toIntx(16)

//or 
implicit class Conv(x:String) {
    def toIntx(rx:Int) = Integer.valueOf(x,rx)
}
"AB".toIntx(16)

//2. Implicits as Context Parameter 
class A[T](val init:T)

implicit val x = new A[Int](20)

def m(y:Int)(implicit ev:A[Int]) =  "OK"+ev.init.toString

m(2)(new A[Int](30))
m(2)

//3. Usage in typeClass -  scala3: Context parameter-using and given 

trait Add[T]{
    def plus(x:T, y:T) :T
}

def add[T](x:T, y:T)(implicit ev:Add[T]) = ev.plus(x,y) 

add(2,3)//NOK 


implicit object xyws1 extends Add[Int]{
    def plus(x:Int, y:Int) = x+y 
}
//OR 
implicit val xyzw = new Add[Double]{def plus(x:Double, y:Double) = x-y}

add(2,3)//OK 


Check implicits in scope Scala2 REPL 
:implicits -v

//Many typeclass is available in scala 
List[A].sorted[B >: A](implicit ord: Ordering[B]): List[A]

case class Animal(name:String, age:Int)

implicit val ao = new Ordering[Animal]{
     def compare(x: Animal, y: Animal): Int = x.age.compare(y.age)
}

(10 to 20).toList.map(Animal("ABC", _)).sorted  

//OR could have done 
case class Animal2(name:String, age:Int) extends Ordered[Animal2]{
    def compare(that: Animal2) =  this.age.compare(that.age)
}
(10 to 20).toList.map(Animal2("ABC", _)).sorted  
// sorted[B >: A](implicit ord: Ordering[B]): List[A]
//for reverse sorting
(10 to 20).toList.map(Animal2("ABC", _)).sorted(Ordering.by[Animal2, Int](_.age).reversed)
//Or Many FUn -Ordering 
def by[T, S](f: (T) => S)(implicit ord: Ordering[S]): Ordering[T]
def fromLessThan[T](cmp: (T, T) => Boolean): Ordering[T]

case class Animal3(name:String, age:Int)
(10 to 20).toList.map(Animal3("ABC", _)).sorted(Ordering.by[Animal3,Int](_.age))

//Similarly for Numeric 
def mean[T](xs: Seq[T]):Double = xs.sum / xs.size//Error 

def mean[T](xs: Seq[T])(implicit ev: Numeric[T]) :Double = {
    import ev._
    xs.sum.toDouble / xs.size
}
def mean[T:Numeric](xs: Seq[T]) :Double = {
    val ev = implicitly[Numeric[T]]
    import ev._
    xs.sum.toDouble / xs.size
}
//scala3 
def mean[T:Numeric](xs: Seq[T]) :Double = 
    val ev = summon[Numeric[T]]
    import ev.*
    xs.sum.toDouble / xs.size


//Best Practice 
//Put all implicits declaration in companion objects
trait Add[T]{
    def plus(x:T, y:T) :T
}
case class Point(x:Int, y:Int)
object Point {
    implicit object ghft extends Add[Point]{
        def plus(x:Point, y:Point) = Point(x.x+y.x, x.y+y.y)
    }
    
    implicit object porde extends Ordering[Point]{
        def compare(x:Point, y:Point) = x.x.compare(y.x)
    }
    
    def generate(n:Int) = 
        (0 to n).toList.map(e => Point(e, e+1)) //List[Point]
}

Point.generate(5).sorted

//Excersize 
import scala.collection.mutable.{Queue => MQ, Stack =>MS}
import scala.util._
import java.io._ 


trait Q[CC[_]]{  
    def isEmpty:Boolean 
    def getOne:Option[File]
    def addMany(files: File*):CC[File]
    def clear():Unit 
}

def QMQ:Q[MQ]  = new Q[MQ]{
    private val queue = MQ[File]()
    def isEmpty:Boolean = queue.isEmpty
    def getOne:Option[File] = Try(queue.dequeue()).toOption
    def addMany(files: File*):MQ[File] = {
        queue ++= files
        queue
    }
    def clear():Unit = queue.dequeueAll(x => true)
}
def QMS:Q[MS]  = new Q[MS]{
    private val stack = MS[File]()
    def isEmpty:Boolean = stack.isEmpty
    def getOne:Option[File] = Try(stack.pop()).toOption
    def addMany(files: File*):MS[File] = {
        files.foreach( stack.push )
        stack
    }
    def clear():Unit = stack.popAll()
}

implicit val singletone_QMQ:Q[MQ] = QMQ
implicit val  singletone_QMS:Q[MS] = QMS


case class GetFiles[CC[_]](path:String)( implicit queue: Q[CC])  extends Iterator[File]{
    val q = {
        queue.clear()
        queue.addMany( (new File(path)).listFiles.toIndexedSeq : _* ) 
    }
    //println(q)
    def hasNext = ! queue.isEmpty
    def next():File = queue.getOne match {
            case Some(f) => 
                if (f.isFile) f else {
                    queue.addMany( f.listFiles.toIndexedSeq : _*)
                    next()
                }
            case None    => new File("")
        }
}

val path = raw"D:\tool"
//Check 
val aa = GetFiles[MQ](path)
aa.take(10).toList 
val bb = GetFiles[MS](path)
bb.take(10).toList 

//OR for seperate instance of Stack 
val aaq = GetFiles[MQ](path)(using QMQ)
aaq.take(10).toList 

///HandsOn  - all generic on lst:List[T] 
Mean(lst) =         Sum of lst/length of lst 
Median(lst) =       sort and midddle value or average of two middle  if length is even
sd(lst) =           sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
Mode(lst) =         sort with frequency, highest frequency
Put these methods in List 




def mean[T:Numeric, C[T] <: Seq[T]](l: C[T])={    
    import Numeric.Implicits._
    if (l.isEmpty ) 0.0 else l.sum.toDouble/ l.size.toDouble
    }
    
def mean[T: Numeric](xs: Seq[T]):Double =
  implicitly[Numeric[T]].toDouble(xs.sum) / xs.size

def mean[T: Numeric](xs: Seq[T]):Double = {
   val num = implicitly[Numeric[T]]
   import num._
   xs.sum.toDouble / xs.size
  }
  
def sd[T: Numeric](xs: Seq[T]):Double = {
    val num = implicitly[Numeric[T]]
    import scala.math._
    import num._
    val  m = xs.sum.toDouble / xs.size
    if (xs.isEmpty) 0.0 else  sqrt( xs.map { x:T  => (x.toDouble-m) * (x.toDouble-m) }.sum ) / xs.size.toDouble
 }
    

def mode[T](lst: Seq[T]):T ={  					//throw clause is needed to have if's return type as T
     if (lst.isEmpty) throw new Exception("Oh") else lst.sortBy{ e => lst.count{ l => l == e} }.last       
    }
mode(List(1,2,3,4,1,3,3,4,3,4)) 

	

def median[T:Numeric](lst:Seq[T])={
    val num = implicitly[Numeric[T]]
    import num._
    val list = lst.sorted   
    val m = list.size / 2
    if (list.size % 2 == 1)   list(m).toDouble else  (list(m).toDouble + list(m+1).toDouble)/2
   }
median(List(1,2,3,4,1,3,3,4,3,4))

	
//for one or more same frequencies
def mode_multi[T:Numeric](list: Seq[T])= {
      val fr =  list.groupBy{ e => list.count{ l => l == e} } 
      val m = fr.toList.sortBy { e => e._1 }     
      mean(m.last._2.toSet.toList) 
    }
	
val l = List(1,2,3,2,1,2)
mode_multi(l)


//Put sd, mean, median, mode to List


//Way-1

class MyList[T:Numeric](xs: Seq[T]) {
    import java.lang.Math._
    def mean:Double =  implicitly[Numeric[T]].toDouble(xs.sum) / xs.size
	def mode:T = xs.sortBy{ e => xs.count{ l => l == e} }.last 
}
implicit def listToMyList[T:Numeric](l: Seq[T]) = new MyList(l)

val l = List(1, 2, 3, 2, 1, 2, 1)

l.mean //res38: Double = 1.7142857142857142

//Way-2
implicit class MyList[T:Numeric](xs: Seq[T]) {
    import java.lang.Math._
    def mean:Double =  implicitly[Numeric[T]].toDouble(xs.sum) / xs.size
	def mode:T = xs.sortBy{ e => xs.count{ l => l == e} }.last 
}



///View bounds
view bounds have been deprecated since Scala 2.11, Use context bound as in type class 
The view bound is a syntactic sugar for the implicit conversion from one type to another 

case class CanEqual(hash: Int)

def equal[CA, CB](a: CA, b: CB)(implicit ca: CA => CanEqual, cb: CB =>CanEqual): Boolean = ca(a).hash == cb(a).hash

//OR 
def equalsWithBounds[CA <% CanEqual, CB <% CanEqual](a: CA, b: CB): Boolean   = {
 val hashA = implicitly[CA => CanEqual].apply(a).hash
 val hashB = implicitly[CB => CanEqual].apply(b).hash
 hashA == hashB
}
//OR 
def equalsWithPassing[CA <% CanEqual, CB <% CanEqual](a: CA, b: CB): Boolean = equal(a, b)



///Implicit Scope 
The implicit scope available under number 1 below has precedence over the ones under number 2. 

Other than that, if there are several eligible arguments which match the implicit parameter’s type, 
a most specific one will be chosen using the rules of static overloading resolution 
(see Scala Specification §6.26.3). 

1.First look in Lexical scope
    •Implicits defined in current scope explicitly
    •Explicit imports eg import com.xyz
    •wildcard imports eg import integral._
    •Same scope in other files(ie package objects of users or package object where type is defined)
2.Now look in other implicits scope 
    •Companion objects of a type ie for C[T],  in object C 
    •Implicit scope of an argument type if used inside a function 
    •Implicit scope of type arguments  ie for C[T] ,in object T 
    •Outer objects for nested types including parent class 

///Static overloading rules
The definition of static overloading rules is quite long and complicated (it can be found in
the official documentation at https://www.scala-lang.org/files/archive/spec/2.13/06-expressions.html#overloading-resolution). 

It specifies a number of rules that the compiler uses to decide which alternative implicit is chosen. 

This decision is based on the relative weight of the alternatives. 
The higher weight means that the alternative A is more specific than B, and A wins.

The relative weight of A over B is calculated as a sum of two numbers:
    If A is defined in a class or object which is derived from the class or object
    defining B (simplified, A is derived from B if A is a subclass or companion object
    of a subclass of B, or B is a companion object of a superclass of A)

    If A is as specific as B (simplified, this means that if A is a method, it can be called
    with the same arguments as B; for polymorphic methods, this also means more
    specific type constraints)

These two rules allow you to calculate relative weights for two implicit conversions or
parameters between 0 and 2 and to select the more suitable alternative in the case of the
weights being different. If the weights are equal, the compiler will report ambiguous
implicit values.

///Implicit scope - example 
For our purposes, we can package type class instances in roughly four ways:
    1. by placing them in an object such as JsonWriterInstances;
    2. by placing them in a trait;
    3. by placing them in the companion object of the type class;
    4. by placing them in the companion object of the parameter type.
    (in this case JsonWriter or Person)
    
We can actually define instances in two ways:
     1. by defining concrete instances as implicit vals of the required  type;
     2. by defining implicit methods to construct instances from other type class instances.
     
     
sealed trait Json
final case class JsObject(get: Map[String, Json]) extends Json
final case class JsString(get: String) extends Json
final case class JsNumber(get: Double) extends Json
final case object JsNull extends Json


// The "serialize to JSON" behaviour is encoded in this trait
trait JsonWriter[A] {
    def write(value: A): Json
}


//FOr 
case class Person(name: String, email: String)

object JsonWriterInstances {
    implicit val stringWriter: JsonWriter[String] =
       new JsonWriter[String] {
           def write(value: String): Json =
            JsString(value)
       }

    implicit val personWriter: JsonWriter[Person] =
       new JsonWriter[Person] {
           def write(value: Person): Json =
            JsObject(Map(
               "name" -> JsString(value.name),
               "email" -> JsString(value.email)
             ))
       }
}
//Interface 
object JsonH {
    def toJson[A](value: A)(implicit w: JsonWriter[A]): Json =
      w.write(value)
}

import JsonWriterInstances._
//import JsonWriterInstances.given 

JsonH.toJson(Person("Dave", "dave@example.com"))

We can alternatively use extension methods to extend existing types with interface methods. 

object JsonSyntax {
    implicit class JsonWriterOps[A](value: A) {
        def toJson(implicit w: JsonWriter[A]): Json =
          w.write(value)
    }
}

import JsonWriterInstances._
import JsonSyntax._
Person("Dave", "dave@example.com").toJson

implicitly[JsonWriter[String]]
 // res5: JsonWriter[String] = repl.Session$App0$JsonWriterInstances$$anon$1@6fccdc48
 //summon[JsonWriter[String]]


///Conditional Implicits 
Consider defining a JsonWriter for Option. 
We would need a JsonWriter[Option[A]] for every A we care about in our application. 

implicit val optionIntWriter: JsonWriter[Option[Int]] =???
implicit val optionPersonWriter: JsonWriter[Option[Person]] =  ???
// and so on...

OR Use implicit def:

implicit def optionWriter[A](implicit writer: JsonWriter[A]): JsonWriter[Option[A]] =
  new JsonWriter[Option[A]] {
      def write(option: Option[A]): Json =
        option match {
            case Some(aValue) => writer.write(aValue)
            case None        => JsNull
        }
  }

When the compiler sees an expression like this:
JsonH.toJson(Option("A string"))

it searches for an implicit JsonWriter[Option[String]]. It finds the 
implicit method for JsonWriter[Option[A]]:

JsonH.toJson(Option("A string"))(optionWriter[String])
//JsonH.toJson(Option("A string"))(using optionWriter[String])

and recursively searches for a JsonWriter[String] to use as the parameterto optionWriter:
JsonH.toJson(Option("A string"))(optionWriter(stringWriter)) 
    
When working with type classes we must consider two issues that control instance selection:
    · What is the relationship between an instance defined on a type and its   subtypes?
        For example, if we define a JsonWriter[Option[Int]], will the ex
        pression Json.toJson(Some(1)) select this instance? (Remember
        that Some is a subtype of Option).

     · How do we choose between type class instances when there are many
       available?
        What if we define two JsonWriters , one for Option and other for Some 
        which one would it prefer when we do Json.toJson(Some(1))?
    

It turns out we cant have both at once. 
The three choices give us behaviour as follows:(ie for invariant, matching should be exact)

Type Class Variance               Invariant       Covariant      Contravariant

Supertype instance used?          No              No             Yes
More specific type preferred?     No              Yes            No


For Option[+A], it is Covariant , hence if Option and Some is present, Some is choosen 
But if Some is not present and Option is present , then Error , 

We can solve this problem with a type annotation like Some(1) : Option[Int] 
or by using "smart constructors" like the Option.apply, Option.empty, some, and none methods 
which returns option[T] instead of Some or None 

///type Sclass smart constructor using cats Functor (containing map)
trait Functor[F[_]]{
     def map[A, B](fa: F[A])(f: (A) => B): F[B] 
}
Companion object contains main implementation 
//Example 
sealed trait Tree[+A]
final case class Branch[A](left: Tree[A], right: Tree[A])  extends Tree[A]
final case class Leaf[A](value: A) extends Tree[A]

//Since it is covariant , create smart constructor because for Branch, we would want to select Tree 
object Tree {
     def branch[A](left: Tree[A], right: Tree[A]): Tree[A] =
      Branch(left, right)

     def leaf[A](value: A): Tree[A] =
      Leaf(value)
 }

 
 
//usage 
import cats._ 
import cats.implicits._ 


implicit val treeFunctor: Functor[Tree] =
 new Functor[Tree] {
   def map[A, B](tree: Tree[A])(func: A => B): Tree[B] =
    tree match {
         case Branch(left, right) =>
          Tree.branch(map(left)(func), map(right)(func))
         case Leaf(value) =>
          Tree.leaf(func(value))
     }
}

Branch(Leaf(10), Leaf(20)).map(_ * 2)
// error: value map is not a member of repl.Session.App0.Branch[Int]


Tree.leaf(100).map(_ * 2)
// res9: Tree[Int] = Leaf(200)


Tree.branch(Tree.leaf(10), Tree.leaf(20)).map(_ * 2)
// res10: Tree[Int] = Branch(Leaf(20), Leaf(40))


///Example of Idiomatic typeclass 

trait CsvEncoder[A] {
 def encode(value: A): List[String]
}
//1. create an apply method which summons implicits 
//2. Create constructor method which would be called for typeclass creation 
//3. Create basic instances and then create conditional instances based on basic instance 
object CsvEncoder {    
    def apply[A](implicit enc: CsvEncoder[A]): CsvEncoder[A] =  enc

    // "Constructor" method
    def instance[A](func: A => List[String]): CsvEncoder[A] =
     new CsvEncoder[A] {
         def encode(value: A): List[String] =
           func(value)
     }

    //Now generally any encoder can be written by calling above 
    implicit val booleanEncoder: CsvEncoder[Boolean] =
        instance(b => if(b) List("yes") else List("no"))
        
    implicit val stringEncoder: CsvEncoder[String] =
      instance(str => List(str))
    
    
    implicit val intEncoder: CsvEncoder[Int] =
      instance(num => List(num.toString))
      
    implicit def pairEncoder[A, B](  implicit   aEncoder: CsvEncoder[A], bEncoder: CsvEncoder[B]): CsvEncoder[(A, B)] =
         instance{ pair: (A, B)  =>
                  val (a, b) = pair
                 aEncoder.encode(a) ++ bEncoder.encode(b)
             }


}

// Custom data type:
case class Employee(name: String, number: Int, manager: Boolean)
object Employee {
  import CsvEncoder._
 // CsvEncoder instance for the custom data type:
 implicit val employeeEncoder: CsvEncoder[Employee] =
     instance{ e =>
             List(
                 e.name,
                 e.number.toString,
                 if(e.manager) "yes" else "no"
             )
     }
}

//The apply method, known as a "summoner" or "materializer", does the 
//same job as scala.Predef.implicitly

CsvEncoder[Employee]
// res9: CsvEncoder[Employee] = $anon$1@5940ac6a
//OR 
implicitly[CsvEncoder[Employee]]
// res10: CsvEncoder[Employee] = $anon$1@5940ac6a

def writeCsv[A](values: List[A])(implicit enc: CsvEncoder[A]): String  =
     values.map(value => enc.encode(value).mkString(",")).mkString("\n")


val employees: List[Employee] = List(
     Employee("Bill", 1, true),
     Employee("Peter", 2, false),
     Employee("Milton", 3, false)
)

writeCsv(employees)
 
//We can use writeCsv with any data type we like, provided we have a corresponding implicit CsvEncoder in scope:

case class IceCream(name: String, numCherries: Int, inCone: Boolean)
object IceCream {
  import CsvEncoder._
  
    implicit val iceCreamEncoder: CsvEncoder[IceCream] =
     instance{i =>
          List(
              i.name,
              i.numCherries.toString,
              if(i.inCone) "yes" else "no"
          )
     }
}

val iceCreams: List[IceCream] = List(
 IceCream("Sundae", 1, false),
 IceCream("Cornetto", 0, true),
 IceCream("Banana Split", 0, false)
)


writeCsv(iceCreams)

//Then using pair 
writeCsv(employees zip iceCreams)


///Type class - Example from Cats - Show 
Show is an alternative to the Java toString method. 
It is defined by a single function show:

def show(a: A): String

The difference is that toString is defined on Any(Java’s Object) 
and can therefore be called on anything, not just case classes. 

Most often, this is unwanted behaviour, as the standard implementation of 
toString on non case classes is mostly gibberish. 

(new {}).toString
// res0: String = "repl.MdocSession$App$$anon$1@31418a9b"


//Example 
import cats._ 
import cats.implicits._ 

//It has below 
trait Show[A] {
    def show(value: A): String
}
object Show {
    /** creates an instance of Show using the provided function */
    def show[A](f: A => String): Show[A]

    /** creates an instance of Show using object toString */
    def fromToString[A]: Show[A]
}
//USage 
import cats.Show

case class Person(name: String, age: Int)

implicit val showPerson: Show[Person] = Show.show(person => person.name)

case class Department(id: Int, name: String)

implicit val showDep: Show[Department] = Show.fromToString //case class has good ToString
// showDep: Show[Department] = cats.Show$$anon$3@184af520


import cats.implicits._

val john = Person("John", 31)
john.show
// res1: String = "John"

val engineering = Department(2, "Engineering")
show"$john works at $engineering"
// res2: String = "John works at Department(2,Engineering)"


//Custom 
import java.util.Date


implicit val dateShow: Show[Date] =
 new Show[Date] {
     def show(date: Date): String =
       s"${date.getTime}ms since the epoch."
 }


new Date().show
// res1: String = "1594650192117ms since the epoch."


//OR

implicit val dateShow: Show[Date] =
     Show.show(date => s"${date.getTime}ms since the epoch.")


//Our definition of Cat remains the same:
final case class Cat(name: String, age: Int, color: String)

implicit val catShow: Show[Cat] = Show.show[Cat] { cat =>
 val name   = cat.name.show
 val age    = cat.age.show
 val color = cat.color.show
 s"$name is a $age year-old $color cat."
}

println(Cat("Garfield", 38, "ginger and black").show)
// Garfield is a 38 year-old ginger and black cat.
 
 
///Type class - Example from Cats - Eq
Eq is designed to support typesafe equality and address annoyances using Scalas builtin == operator.
(which would always succeeds and return false if dissimilar types )
(we want dissimilar types to fail during compilation )

List(1, 2, 3).map(Option(_)).filter(item => item == 1)
// warning: Option[Int] and Int are unrelated: they will most likely never compare equal
// res: List[Option[Int]] = List()

The predicate in the filter clause always returns false be cause it is comparing an Int to an Option[Int].


//cats has below 
trait Eq[A] {
    def eqv(a: A, b: A): Boolean
    // other concrete methods based on eqv...
}

· === compares two objects for equality;
· =!= compares two objects for inequality.


import cats._ 
import cats.implicits._ 


val eqInt = Eq[Int]

eqInt.eqv(123, 123)
// res1: Boolean = true
eqInt.eqv(123, 234)
// res2: Boolean = false


eqInt.eqv(123, "234")
// error: type mismatch;
//     found   : String("234")
//     required: Int

123 === 123
// res4: Boolean = true
123 =!= 234
// res5: Boolean = true

123 === "123"
// error: type mismatch;
//     found   : String("123")
//     required: Int
// 123 === "123"
//             ^^^^^


Some(1) === None
// error: value === is not a member of Some[Int]
// Some(1) === None
// ^^^^^^^^^^^

We have received an error here because the types donot quite match up. We
have Eq instances in scope for Int and Option[Int] but the values we are
comparing are of type Some[Int] and Option is covariant, so either Some must have implementation or use smart constror 


(Some(1) : Option[Int]) === (None : Option[Int])
// res8: Boolean = false

//OR 
Option(1) === Option.empty[Int]
// res9: Boolean = false

or using special syntax from cats.syntax.option:
1.some === none[Int]
// res10: Boolean = false
1.some =!= none[Int]
// res11: Boolean = true

//Comparing Custom Types
import java.util.Date


implicit val dateEq: Eq[Date] = Eq.instance[Date] { (date1, date2) =>
    date1.getTime === date2.getTime
}


val x = new Date() // now
val y = new Date() // a bit later than now


x === x
// res12: Boolean = true
x === y
// res13: Boolean = false


final case class Cat(name: String, age: Int, color: String)

val cat1 = Cat("Garfield",      38, "orange and black")
val cat2 = Cat("Heathcliff", 33, "orange and black")

val optionCat1 = Option(cat1)
val optionCat2 = Option.empty[Cat]


implicit val catEqual: Eq[Cat] =
    Eq.instance[Cat] { (cat1, cat2) =>
       (cat1.name   === cat2.name ) &&
       (cat1.age    === cat2.age   ) &&
       (cat1.color === cat2.color)
    }



val cat1 = Cat("Garfield",        38, "orange and black")
// cat1: Cat = Cat("Garfield", 38, "orange and black")
val cat2 = Cat("Heathcliff", 32, "orange and black")
// cat2: Cat = Cat("Heathcliff", 32, "orange and black")

cat1 === cat2
// res15: Boolean = false
cat1 =!= cat2
// res16: Boolean = true


optionCat1 === optionCat2
// res17: Boolean = false
optionCat1 =!= optionCat2
// res18: Boolean = true






////-------------Property-Based Testing in Scala----------------------------------------------------------------------------------------------
5.       Property-Based Testing in Scala
·       Property-Based Testing in Scala
·       Introduction to property-based testing
·       Properties and Generators

///Property-Based Testing
Property based testing relies on properties(different than Unit test/ AT/ST)
It checks that a function, program or whatever system under test abides by a property. 
Only applicable if program can be represented by a property 

A property is just something like:
    for all (x, y, ...)
    such as precondition(x, y, ...) holds
    property(x, y, ...) is true

//Example 
for all (a, b, c) strings
the concatenation of a, b and c always contains b

///ScalaCheck
ScalaCheck (http://www.scalacheck.org) is a framework for automated PBT in Scala. 

libraryDependencies += "org.scalacheck" %% "scalacheck" % "1.15.3"      // % Test

//others 
libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.2"         // % Test
libraryDependencies += "org.typelevel" %% "cats-core" % "2.1.0"

Now, we can define and verify our first property:

https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Prop.html
//Methods - forall takes a function which returns Boolean 
//and  there is an implicit conversion Boolean => Property 
//and test data is generated by  Gen[String], in our case, random strings.
def forAll[T1, T2, P](g1: Gen[T1], g2: Gen[T2])(f: (T1, T2) => P)(implicit p: (P) => Prop, s1: Shrink[T1], pp1: (T1) => Pretty, s2: Shrink[T2], pp2: (T2) => Pretty): Prop
def forAll[T1, P](g1: Gen[T1])(f: (T1) => P)(implicit p: (P) => Prop, s1: Shrink[T1], pp1: (T1) => Pretty): Prop

import org.scalacheck._
import org.scalacheck.Prop._

val stringLengthProp = forAll { (_: String).length >= 0 }
//stringLength: org.scalacheck.Prop = Prop

stringLengthProp.check
//+ OK, passed 100 tests.


///Properties Classification- Universally quantified properties - forAll 
By default, ScalaCheck has instances for common types like Int, String, List, etc, 
but it is also possible to define own Arbitrary instances

val propReverseList = forAll { l: List[String] => l.reverse.reverse == l }

val propConcatString = forAll { (s1: String, s2: String) =>
  (s1 + s2).endsWith(s2)
}

propReverseList.check
propConcatString.check

///Properties Classification- Conditional Properties using ==>:
Now ScalaCheck will only care for the cases when n is not negative. 
We also filter out large numbers, since we donot want to generate huge lists.

val propMakeList = forAll { n: Int =>
  (n >= 0 && n < 10000) ==> (List.fill(n)("").length == n)
}
propMakeList.check


///Types of properties-Commutativity
If order operands do not matter, we say that the operation is commutative. 

scala> forAll((a: Int, b: Int) => a + b == b + a).check
+ OK, passed 100 tests.

scala> forAll((a: Int, b: Int) => a * b == b * a).check
+ OK, passed 100 tests.

For strings, the addition is defined as a concatenation but is not commutative in general:
    
scala> forAll((a: String, b: String) => a + b == b + a).check
! Falsified after 1 passed tests.
> ARG_0: "\u0001"
> ARG_0_ORIGINAL
> ARG_1: "\u0000"
> ARG_1_ORIGINAL:

If at least one of the strings is empty, the property becomes commutative 

scala> forAll((a: String) => a + "" == "" + a).check
+ OK, passed 100 tests.

///Types of properties-Associativity
scala> forAll((a: Int, b: Int, c: Int) => (a + b) + c == a + (b + c)).check
+ OK, passed 100 tests.

scala> forAll((a: Int, b: Int, c: Int) => (a * b) * c == a * (b * c)).check
+ OK, passed 100 tests.

scala> forAll((a: String, b: String, c: String) =>
   (a + b) + c == a + (b + c)).check
+ OK, passed 100 tests.

///Types of properties-Identity
scala> forAll((a: Int) => a + 0 == a && 0 + a == a).check
+ OK, passed 100 tests.

scala> forAll((a: Int) => a * 1 == a && 1 * a == a).check
+ OK, passed 100 tests.

scala> forAll((a: String) => a + "" == a && "" + a == a).check
+ OK, passed 100 tests.


///Types of properties-Invariants
Invariant properties are those which should never change in the context of the operation

scala> forAll((a: String) => a.sorted.length == a.length).check
+ OK, passed 100 tests.

scala> forAll((a: String) => a.toUpperCase().length == a.length).check
! Falsified after 50 passed tests.
> ARG_0:
> ARG_0_ORIGINAL:

Or well, for toUpperCase at least it should work if the locale matches the contents of the
string or the string only contains ASCII symbols:

import org.scalacheck.Gen 

scala> forAll(Gen.asciiStr)((a: String) => a.toUpperCase().length ==  a.length).check
+ OK, passed 100 tests.

Gen.asciiStr to generate strings which only contain ASCII chars. Check other Gen
https://javadoc.io/static/org.scalacheck/scalacheck_2.13/1.15.3/org/scalacheck/Gen$.html


///Checking property
The check() method accepts Test.Parameters, which allow for the configuration of a
few aspects of how the check is executed. 

val prop = forAll { a: String => a.nonEmpty ==> (a.reverse.reverse  == a) }

//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Prop$.html
scala> val timed = within(10000)(prop) //within 10 sec , operation should finish 
timed: org.scalacheck.Prop = Prop

//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Test$$Parameters.html
scala> Test.check(timed) {  _.withMinSuccessfulTests(100000).withWorkers(4).withMaxDiscardRatio(3) }
res47: org.scalacheck.Test.Result = Result(Failed(List(),Set(Timeout)),0,0,Map(),10011)
//final case class Result(status: Status, succeeded: Int, discarded: Int, freqMap: FreqMap[Set[Any]], time: Long = 0)
//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Test$.html

We can see that our test has failed because of the timeout.

Besides within, there are other wrapper methods defined on Prop.
//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Prop$.html

scala> forAll { a: String =>
        //def classify(c: => Boolean, ifTrue: Any, ifFalse: Any)(prop: Prop): Prop
        classify(a.isEmpty, "empty string", "non-empty string") { //collect data for test report 
          a.sorted.length ?= a.length
        }
      }.check()
+ OK, passed 100 tests.
> Collected test data:
96% non-empty string
4% empty string

Note 
the == compares two values and returns a Boolean, which is then implicitly 
converted to the Prop; 
the ?= creates a Prop directly and sometimes it can be useful in the situations 
where properties are combined

A property can also be labelled, which makes it easier to spot in the results:
Here we also used the protect method to convert the exception into the test failure.

scala> val prop2 = "Division by zero" |: protect(forAll((a: Int) => a / a  == 1))
prop2: org.scalacheck.Prop = Prop

scala> prop2.check()
! Exception raised on property evaluation.
> Labels of failing property:
Division by zero
> ARG_0: 0
> Exception: java.lang.ArithmeticException: / by zero
$line74.$read$$iw$$iw$$iw$$iw$$iw$$iw$$iw$$iw$.$anonfun$prop2$2(<console>:2  3)
...

///Grouping properties 
Often you want to specify several related properties, eg all methods in a class. 
Extend Properties(name: String) 

Properties is a subtype of Prop, so you can use it just as if it was a single property. 
That single property holds if and only if all of the contained properties hold.


import org.scalacheck._

object StringSpecification extends Properties("String") {
  import Prop.forAll

  //single property 
  //property(name: String)
  property("startsWith") = forAll { (a: String, b: String) =>
    (a+b).startsWith(a)
  }

  property("endsWith") = forAll { (a: String, b: String) =>
    (a+b).endsWith(b)
  }

  property("substring") = forAll { (a: String, b: String) =>
    (a+b).substring(a.length) == b
  }

  property("substring") = forAll { (a: String, b: String, c: String) =>
    (a+b+c).substring(a.length, a.length+b.length) == b
  }
}
scala > StringSpecification.check()

OR compile and run it 
$ scalac -cp scalacheck.jar StringSpecification.scala

$ scala -cp scalacheck.jar:. StringSpecification
+ String.startsWith: OK, passed 100 tests.
+ String.endsWith: OK, passed 100 tests.
+ String.substring: OK, passed 100 tests.
+ String.substring: OK, passed 100 tests.

OR use Include to include another property 
    def include(ps: Properties): Unit
    def include(ps: Properties, prefix: String): Unit
        Adds all properties from another property collection to this one 
        with a prefix this is prepended to each included property name.

object MyAppSpecification extends Properties("MyApp") {
  include(StringSpecification)
  include(...)
  include(...)
}

///Collecting Generated Test Data 
It is possible to collect statistics about what kind of test data 
that has been generated during property evaluation. 

def Prop.classify(c: => Boolean, ifTrue: Any, ifFalse: Any)(prop: Prop): Prop
def Prop.classify(c: => Boolean, ifTrue: Any)(prop: Prop): Prop
    Use Prop.classify to collect interesting information on the generated data. 
def Prop.collect[T](t: T)(prop: Prop): Prop
    Collect data for presentation in test report


import org.scalacheck.Prop._

def ordered(l: List[Int]) = l == l.sorted

val myProp = forAll { l: List[Int] =>
  classify(ordered(l), "ordered") {
    classify(l.length > 5, "large", "small") {
      l.reverse.reverse == l
    }
  }
}

scala> myProp.check
+ OK, passed 100 tests.
> Collected test data:
78% large
16% small, ordered
6% small

Here ScalaCheck tells us that the property has not been tested with any large and ordered list 
 
Maybe we need to use a special generator that generates also large ordered lists, 
if that is important for testing our method thoroughly. 

We can also collect data directly, using the Prop.collect method. 

val dummyProp = forAll(Gen.choose(1,10)) { n =>
  collect(n) {
    n == n
  }
}

scala> dummyProp.check
+ OK, passed 100 tests.
> Collected test data:
13% 7
13% 5
12% 1
12% 6
11% 2
9% 9
9% 3
8% 10
7% 8
6% 4

As we can see, the frequency for each number is around 10%, which seems reasonable.

///Generators - where the input data for these properties comes from
To make falsifiable properties more trustworthy, existing ScalaCheck generators for Byte,
Short, Int, and Long place additional weight on zero, +1, -1, and both minValue and
maxValue for the type.

//Existing generators
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen$.html

All subtypes of AnyVal, Unit, Function0, chars and strings with different contents
(alphaChar, alphaLowerChar, alphaNumChar, alphaStr, alphaUpperChar, numChar,
numStr), containers, lists and maps (containerOf, containerOf1, containerOfN,
nonEmptyContainerOf, listOf, listOf1, listOfN, nonEmptyListOf, mapOf, mapOfN,
nonEmptyMap), numbers (chooseNum, negNum, posNum), duration, Calendar, BitSet, and
even Test.Parameters

forAll(Gen.asciiStr)((a: String) => a.toUpperCase().length ==  a.length).check

If there is no generator suitable for the testing purposes available, 
it is possible to create a custom generator by implementing a Gen class:

sealed abstract class Gen[+T] extends Serializable { self =>
  ...
  def apply(p: Gen.Parameters, seed: Seed): Option[T]
  def sample: Option[T]
  ...
}

As an exercise, let implement a generator for literal types:

def literalGen[T <: Singleton](t: T): Gen[T] = Gen.const(t)
implicit val myGen: Arbitrary[42] = Arbitrary(literalGen(42))

val literalProp = forAll((_: 42) == 42).check

///Gen vs Arbitrary
forAll takes Gen[T], Gen[T] generates random T 

Arbitrary[T] makes it easy to find implicits Gen[T] in the scope 
and defined as 
sealed abstract class Arbitrary[T] {
  val arbitrary: Gen[T]
}

Note, Arbitrary is not needed if we create Gen and pass it to forAll 

val myGen1: Gen[T] = ...
val mygen2: Gen[T] = ...

val prop1 = forAll(myGen1) { (t:T) => Boolean }
val prop2 = forAll(myGen2) { (t:T) => Boolean }

arbitrary[Int] works just like forAll { (n: Int) => Boolean }, 
it just looks up the implicit Arbitrary[Int] instance and uses its generator. 
which is implemented as 

def arbitrary[T](implicit a: Arbitrary[T]): Gen[T] = a.arbitrary


///Combining generators
Gen offers a couple of methods that are very useful for combining 
The classic example is to use the map and flatMap methods 
to create a generator for a case class.

sealed trait Rank

case class SymRank(s: Char) extends Rank {
 override def toString: String = s.toString
}

case class NumRank(n: Int) extends Rank {
 override def toString: String = n.toString
}

case class Card(suit: Char, rank: Rank) {
 override def toString: String = s"$suit $rank"
}

First, we need some generators for suits and ranks which we can create 
by reusing existing oneOf and choose constructors:
"""
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen$.html

def choose[T](min: T, max: T)(implicit c: Choose[T]): Gen[T]
    A generator that generates a random value in the given (inclusive) range.
def oneOf[T](g0: Gen[T], g1: Gen[T], gn: Gen[T]*): Gen[T]
    Picks a random generator from a list
def frequency[T](gs: (Int, Gen[T])*): Gen[T]
    Chooses one of the given generators with a weighted random distribution
def listOfN[T](n: Int, g: Gen[T]): Gen[List[T]]
    Generates a list with at most the given number of elements.
def containerOfN[C[_], T](n: Int, g: Gen[T])(implicit evb: Buildable[T, C[T]], evt: (C[T]) => Traversable[T]): Gen[C[T]]
    A convenience method for calling buildableOfN[C[T],T](n,g).
"""

val suits = Gen.oneOf('H', 'S', 'D', 'C')
val numbers = Gen.choose(2, 10).map(NumRank)
val symbols = Gen.oneOf('A', 'K', 'Q', 'J').map(SymRank)

Now, we can combine our generators into the card generator using for comprehension:

val full: Gen[Card] = for {
 suit <- suits
 rank <- Gen.frequency((9, numbers), (4, symbols))
} yield Card(suit, rank)

full.sample.get 

//All check 
//forAll[T1, P](g1: Gen[T1])(f: (T1) => P)
forAll(full) { card =>
      Prop.collect(card)(true)  //collect for  test data collection 
}.check

//Or use implicit Arbitrary, then we dont have to pass Gen[Card] argument 
implicit lazy val arbBool: Arbitrary[Card] = Arbitrary(full)

forAll { (card:Card) =>
      Prop.collect(card)(true)
}.check

//More Custom Generators (INTERNAL)
It is easy to change this generator to only make cards for a pique pack by using the
suchThat combinator:( https://en.wikipedia.org/wiki/Piquet)

Piquet is played with a 32-card pack, normally referred to as a piquet pack 
or piquet deck. 
The pack comprises the 7s through to 10s, the face cards, and the aces in each suit, 
and can be created by removing all 2–6 values from a 52-card poker pack

//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen.html
//def suchThat(f: (T) => Boolean): Gen[T]
//Create a new generator that uses this generator to produce a value that fulfills the given condition.

val piquet: Gen[Card] = full.suchThat {
 case Card(_, _: SymRank) => true
 case Card(_, NumRank(n)) => n > 6
}

//def collect[T](t: T)(prop: Prop): Prop
//Collect data for presentation in test report

forAll(piquet) { card =>
      Prop.collect(card)(true)
}.check
+ OK, passed 100 tests.
> Collected test data:
8%  J
6%  7
6%  10
... (couple of lines more)

Of course, it is also possible to generate a handfull of cards from the deck 
using one of the container generator methods:

val handOfCards: Gen[List[Card]] = Gen.listOfN(6, piquet)

forAll(handOfCards) { hand: Seq[Card] =>
      Prop.collect(hand.mkString(","))(true)
}.check
! Gave up after only 58 passed tests. 501 tests were discarded.
> Collected test data:
2%  8, 10, 8, 7, Q, 8

Oh, we have duplicate cards in our hand. 
It turns out that we need to use a more general form of the container generator, 
which takes both the type of the container and the type of the element as type parameters:

val handOfCards = Gen.containerOfN[Set, Card](6, piquet)

scala> forAll(handOfCards) { hand =>
      Prop.collect(hand.mkString(","))(true)
      }.check
! Gave up after only 75 passed tests. 501 tests were discarded.
> Collected test data:
1%  A, J, K, 6, K, A
1%  9, A, 8, 9

Moreover, another issue is obvious(as it is only 2%)--a lot of tests are discarded. 
This happens because our piquet generator is defined in terms of filtering
the output of the more general full generator. ScalaCheck notices that there are too
many tests which do not qualify as a valid input and gives up earlier.

So implement as below 
val piquetNumbers = Gen.choose(7, 10).map(NumRank)

val piquet: Gen[Card] = for {
  suit <- suits
  rank <- Gen.frequency((5, piquetNumbers), (4, symbols))
} yield Card(suit, rank)

To fix the issue, we will repeatedly generate the set of cards 
until it has an expected size using retryUntil combinator:

val handOfCards = Gen.containerOfN[Set, Card](6, piquet).retryUntil(_.size == 6)

scala> forAll(handOfCards) { hand =>
      Prop.collect(hand.mkString(","))(true)
      }.check
+ OK, passed 100 tests.
> Collected test data:
1%  9, 9, 9, Q, J, 10
...

Now, our hands are generated as expected.

///Sized Generators 
When ScalaCheck uses a generator to generate a value, it feeds it with size value, 

If you want to use the size parameter in your own generator, 
you can use the Gen.sized method:

def matrix[T](g: Gen[T]): Gen[Seq[Seq[T]]] = Gen.sized { size =>
  val side = scala.math.sqrt(size).asInstanceOf[Int]
  Gen.listOfN(side, Gen.listOfN(side, g))
}

///The arbitrary Generator 
There is a special generator, org.scalacheck.Arbitrary.arbitrary, 
which generates arbitrary values of any supported type.

abstract class Arbitrary[T] {
    def arbitrary: Gen[T]
}
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Arbitrary$.html
Has many default implicits 
eg arbInt, arbBigDecimal, arbString etc 

val evenInteger = Arbitrary.arbitrary[Int] suchThat (_ % 2 == 0)

val squares = for {
  xs <- Arbitrary.arbitrary[List[Int]]
} yield xs.map(x => x*x)

You can use arbitrary for any type that has an implicit Arbitrary instance. 

implicit lazy val arbBool: Arbitrary[Boolean] = Arbitrary(oneOf(true, false))

To get support for your own type T you need to define an 
implicit def or val of type Arbitrary[T]. 

Use the factory method 
Arbitrary.apply[T](g: => Gen[T]): Arbitrary[T] 
to create the Arbitrary instance. 

//Example 
abstract sealed class Tree[T] {
  def merge(t: Tree[T]) = Internal(List(this, t))

  def size: Int = this match {
    case Leaf(_) => 1
    case Internal(children) => (children :\ 0) (_.size + _)  //:\ is foldLeft 
  }
}
case class Internal[T](children: Seq[Tree[T]]) extends Tree[T]
case class Leaf[T](elem: T) extends Tree[T]

implicit def arbTree[T](implicit a: Arbitrary[T]): Arbitrary[Tree[T]] =Arbitrary {
  val genLeaf = for(e <- Arbitrary.arbitrary[T]) yield Leaf(e)

  def genInternal(sz: Int): Gen[Tree[T]] = for {
    n <- Gen.choose(sz/3, sz/2)
    c <- Gen.listOfN(n, sizedTree(sz/2))
  } yield Internal(c)

  def sizedTree(sz: Int) =
    if(sz <= 0) genLeaf
    else Gen.frequency((1, genLeaf), (3, genInternal(sz)))

  Gen.sized(sz => sizedTree(sz))
}

As long as the implicit arbTree function is in scope, 
you can now write properties like this:

val propMergeTree = forAll( (t1: Tree[Int], t2: Tree[Int]) =>
  t1.size + t2.size == t1.merge(t2).size

