Day Two
1.  Understanding Types in Scala
    Understanding Types in Scala
    Understanding types
    Types – all the way down
    Using types to define domain constraints
2. Getting to Know Implicits and Type Classes
    Getting to Know Implicits and Type Classes
    Types of implicits
    View and context bounds
    Type classes
    Implicit scope resolution
3. Property-Based Testing in Scala
    Property-Based Testing in Scala
    Introduction to property-based testing
    Properties and Generators 
    
------------------------
///File Handling and FP - scala.io.Source

case class Row(SepalLength:Double, SepalWidth:Double, PetalLength:Double, PetalWidth:Double, Name:String){
    override def toString = s"""( $SepalLength,$SepalWidth,$PetalLength,$PetalWidth,"$Name")"""
    def toSql = s"insert into iris values ${this.toString}"
}

object Examples  {
    
    def process[B](path:String)(f:Array[String] =>B):List[B] = {
        val lines = scala.io.Source.fromFile(path).getLines.toList
        val lines2 = lines.drop(1). map(_.split(",")).map(f)
        lines2
    }    
        
    def demo_sql = {
        val path = raw"D:\handson\demo\iris.csv"
        val rows = process(path){ arr =>
            val ( Array(a,b,c,d),e) = (arr.slice(0,4).map(_.toDouble), arr.last)
            Row(a,b,c,d,e)        
        }
        //println(rows)     
        val un = rows.map(_.Name).distinct  //or .toSet 
        //val un: List[String] = List(Iris-setosa, Iris-versicolor, Iris-virginica)
        //Aggregation 
        //get max of SepalLength of each Name 
        rows.groupBy(_.Name).map{case(n,lst) => (n -> lst.map(_.SepalLength).max) }
        rows.groupBy(_.Name).map{case(n,lst) => (n -> Map("sl"->lst.map(_.SepalLength).max, "sw" -> lst.map(_.SepalWidth).max)) }

        
    }
}

///Type - this.type  - returns concrete class type polymorphic
trait TA { def f:this } // NOK               

trait TA { def f:this.type  }  //OK

class A extends TA { def f = this} //but returns A , override can change return type

class B extends TA { def f = this} //but Returns B 

:type (new A()).f   // Return A object
:type (new B()).f   // returns B object


///Method Chaining by using this.type
class A {def method1: A = this }
class B extends A {def method2: B = this }

val b = new B()

b.method2.method1

b.method1.method2   //NOK as method2 belongs to B

//Use with this.type
class A {def method1: this.type = this }
class B extends A {def method2: this.type = this }

val b = new B()

b.method2.method1   //b.type = B@4a3a0004

b.method1.method2  //res45: b.type = B@4a3a0004

///Trait: Runtime mixing 
class E 
trait A{
    def name:String 
    def print2 = println(this.name)
}

val e = new E 
val e1 = new E with A {
    def name = "OK"
}

class E1{
    def name = "NOK"
}

trait A2 extends A {
    override def print2 = println(s"Hello ${this.name}")
}
val e2 = new E1 with A 
val e3 = new E1 with A2
//Multiple 
trait T2 
val e4 = new E1 with A2 with T2 



///Stackable trait 
trait T1{
  def m(x:Int):Unit
}

class ET1 extends T1{
    def m(x:Int) = {println("ET1"); println(x) }
}

(new ET1).m(10) //10

//abstract override only allowed for trait 
trait T2 extends T1{
    abstract override def m(x:Int) = { println("T2"); super.m(x*x)}
}

(new ET1 with T2).m(10) //100 //Anon,T2,ET1,T1


trait T3 extends T1{
    abstract override def m(x:Int) = {println("T3"); super.m(x-2) }
}

(new ET1 with T2 with T3).m(10) //64 //Anon, T3,T2,ET1
(new ET1 with T3 with T2).m(10) //98 //Anon,T2,T3,ET1
(new ET1 with T2).m(10) //100 //Anon,T2,ET1
(new ET1).m(10) //10 //Anon,ET1

//No class can extend from abstract override Trait , used for only runtime mixing 
class AB extends T3{
    override def m(x:Int) = {println("AB"); println(x) }
}
//ERROR 







///Scala self type - creating dependencies 

trait   A   {   def a: String }
trait   B   {   def b: String }

//C must be mixed with A
trait   C   {   this: A => // override `this`, now this is A  
  def   c   =   this.a
}

//D must be mixed with A and B 
trait   D { self: A with B => // any alias is allowed, but generally this or self is used 
  def   d = self.a + this.b //can access like self or this 
}

abstract class DD extends D  //Error 
abstract class DD extends D with A with B 


///Example of Type Bounds 
class A[T <:AnyVal]
new A[Int]

class A[T >: AnyVal]
new A[Any]

class A[T >:AnyVal <: Any]
new A[AnyVal]

///Variance 
//In JAVA - PECS ie Producer-Extend,  Consumer-Super 
C[+T]  co-varient means , T is produced, or in function-return or can be read/get from C 
       means C[T'] is subtype of C[T] if T' <: T
       Whenever C[T] is required, one can pass C[T'] and usage can operate on C[T'] to get/read T
C[+T]  contravarient means , T is consumed, or in function-arg or can be put/write in C 
       means C[T] is subtype of C[T'] if T' <: T 
       Whenever C[T'] is required, one can pass C[T] and usage can operate on C[T] to put/write of T   //'
   

//Variances  is for the case 
//how C[T] and C[T'] are related if T is related to T' 
// T , only same type can be used, mutable
// +T, derived type can be used , immutable , this class produces T (ie returns)
// -T , super type can be used , immutable, this class consumes T (ie arg)

//if generic type only acts as parameter: using contravariance. 
//if generic type only acts as retrun value: using covariance. 
//as in Function1[-T,+R]
"""
Note  If C[T] and  C'[T] are always related if C' <: C or vice versa
(ie List[Int] is subtype of Seq[Int] as List <: Seq) 

Variance is only applicable of container/parametric class/trait (C[T]) 
and defines rules for C[T] relational with C[T'] 
ie what can be passed in method taking C[T] or any assignments of C[T] by C[T']


Array[T]        Invariant   Used when elements in the container are mutable.
                            Example: Can only pass Array[String] to a method expecting  only Array[String].

Seq[+A]         Covariant   Used when elements in the container are immutable. 
                            if B <: A, then C[B] <: C[A] and C[B] can be passed to any method expecting  C[A]
                            Example: Can pass a Seq[String] to a method expected Seq[Any].
							We can pass Seq[Any] as well as  List[String], List[Any] as List <:Seq

Foo[-A]     Contra variant Contra-variance is opposite of covariance 
                           if B >: A, then C[B] <: C[A] and C[B] can be passed to any method expecting  C[A]
                           Example: Can pass a Foo[Any] to a method expected Foo[String].

1. because of List[+T] , List is immutable, ie only val and inside List, T can be not used as arg of methods directly
   -T can not be used as var or val 
   Note val means get*() returns T and var means both set*(T) and get*:T
   


Given Function1[-T,+R], 
    ie arg is contravariant and return is covariant 
val name:T , creates   def name:T  ie returns T
    means T has to be covariant or Invariant
var name:T, creates def name:T and def name_=(x:T), ie both arg and return type
    means T can be only Invariant

1. one side effect of +T is that, T can only be used as val (not var) inside class(hence immutable)
(not practical because val with generics can not be initialized)
and in return type of function(not argument type) as arguments of functions are contra-variant ,
hence use like below to have a arguments of T when T is covariant
def meth[U >: T](x:U):T
(Note U <: T is not possible for +T)

2. one side effect of -T is that, T can not used as return type of method(but can be used as argument type)
as return type of method is covariant . 
Hence can not be used for val, var declaration(as get method returns T)
class A[-T]( val x:T) //Not OK as get method
class A[-T]( x:T) //OK, no get method
To use as return type , use 
def meth[U <: T](x:T):U
(Note U >: T is not possible for -T)
"""

///Examples of Variance 
val l:Array[AnyVal] = Array[Int](1,2,3,4) //NOK 
val l2 :List[AnyVal] = List[Int](1,2,3)

class A[T]
val la:A[AnyVal] = new A[Int] //Error 

class A[+T]
val la:A[AnyVal] = new A[Int] //OK

class A[-T]
val la:A[Int] = new A[AnyVal] //OK


///Type Lambdas  
Type Lambda are used where container type(higher kinded type) is required 

def fn[A, F[_]](x : F[A]) = x 

For List, Set, above can be used as those take single type parameters 

val x = List(1,2,3)
fn[Int, List](x)  
//OR 
fn(x)
//OR 
fn[Int, ({type L[A] = List[A]})#L ](x)  //scala 2 

But if we have Map[X,Y], then how to use it ? We need to fix one of X,Y 

// partially-applied type named "MapA"
type MapA[A] = Map[Int, A]

//USage 
val m = Map(1 -> "OK", 2->"NOK")
fn(m) //OK 

scala> fn[Int, Map](m)
-- Error:
1 |fn[Int, Map](m)
  |             ^
  |             Found:    (m : Map[Int, String])
  |             Required: Map[Int]

//SOlution is type lambda 
fn[String, ({type L[A] = Map[Int, A]})#L](m) 
//OR 
fn[String, MapAA](m)

//Another example 
trait Functor[A, +M[_]]{   //M[_] is produced 
  def map[B] (f: A => B): M[B]
}
 
//for Seq
case class SeqFunctor[A](seq: Seq[A]) extends Functor[A, Seq]{ 
  def map[B](f: A => B): Seq[B] = seq.map(f)
}
 
val lst = List(1,2,3)
SeqFunctor(lst).map(_ * 10)  // prints List(10, 20, 30)
 
//But for Map, as Map take two Types, need to fix either K or V 
//lets maps V so we need to fix K in M[_]

case class MapFunctor[K,V](mapKV: Map[K,V]) extends  Functor[V, ({type L[X] = Map[K,X]})#L ]{  // K is fixed  Xie value is variable 
   def map[V2](f: V => V2): Map[K, V2] =  mapKV.map{ case (k,v) => (k, f(v))  }
}
 
MapFunctor(Map(1->1, 2->2, 3->3)).map(_ * 10)// Result: Map(1 -> 10, 2 -> 20, 3 -> 30)
 
//Another way to implement, use ` ` to define variable name
case class ReadableMapFunctor[K,V](mapKV: Map[K,V]){
  type `Map[K]`[V2] = Map[K, V2]
  def mapFunctor[V2] = new Functor[V, `Map[K]`] {
        def map[V2](f: V => V2): `Map[K]`[V2] = mapKV.map{ case (k,v) => (k, f(v))  }    
  }
} 

ReadableMapFunctor(Map(1->1, 2->2, 3->3)).mapFunctor.map(_*10)
//Map(1 -> 10, 2 -> 20, 3 -> 30)



///Various usages of Implicits

//1.implicit conversion - Scala3-Conversion or extension 
class Conv(x:String) {
    def toIntx(rx:Int) = Integer.valueOf(x,rx)
}

(new Conv("AB")).toIntx(16)
implicit def xyz(x:String) = new Conv(x)
"AB".toIntx(16)

//or 
implicit class Conv(x:String) {
    def toIntx(rx:Int) = Integer.valueOf(x,rx)
}
"AB".toIntx(16)

//2. Implicits as Context Parameter 
class A[T](val init:T)

implicit val x = new A[Int](20)

def m(y:Int)(implicit ev:A[Int]) =  "OK"+ev.init.toString

m(2)(new A[Int](30))
m(2)

//3. Usage in typeClass -  scala3: Context parameter-using and given 

trait Add[T]{
    def plus(x:T, y:T) :T
}

def add[T](x:T, y:T)(implicit ev:Add[T]) = ev.plus(x,y) 

add(2,3)//NOK 


implicit object xyws1 extends Add[Int]{
    def plus(x:Int, y:Int) = x+y 
}
//OR 
implicit val xyzw = new Add[Double]{def plus(x:Double, y:Double) = x-y}

add(2,3)//OK 


Check implicits in scope Scala2 REPL 
:implicits -v

//Many typeclass is available in scala 
List[A].sorted[B >: A](implicit ord: Ordering[B]): List[A]

case class Animal(name:String, age:Int)

implicit val ao = new Ordering[Animal]{
     def compare(x: Animal, y: Animal): Int = x.age.compare(y.age)
}

(10 to 20).toList.map(Animal("ABC", _)).sorted  

//OR could have done 
case class Animal2(name:String, age:Int) extends Ordered[Animal2]{
    def compare(that: Animal2) =  this.age.compare(that.age)
}
(10 to 20).toList.map(Animal2("ABC", _)).sorted  
// sorted[B >: A](implicit ord: Ordering[B]): List[A]
//for reverse sorting
(10 to 20).toList.map(Animal2("ABC", _)).sorted(Ordering.by[Animal2, Int](_.age).reversed)
//Or Many FUn -Ordering 
def by[T, S](f: (T) => S)(implicit ord: Ordering[S]): Ordering[T]
def fromLessThan[T](cmp: (T, T) => Boolean): Ordering[T]

case class Animal3(name:String, age:Int)
(10 to 20).toList.map(Animal3("ABC", _)).sorted(Ordering.by[Animal3,Int](_.age))

//Similarly for Numeric 
def mean[T](xs: Seq[T]):Double = xs.sum / xs.size//Error 

def mean[T](xs: Seq[T])(implicit ev: Numeric[T]) :Double = {
    import ev._
    xs.sum.toDouble / xs.size
}
def mean[T:Numeric](xs: Seq[T]) :Double = {
    val ev = implicitly[Numeric[T]]
    import ev._
    xs.sum.toDouble / xs.size
}
//scala3 
def mean[T:Numeric](xs: Seq[T]) :Double = 
    val ev = summon[Numeric[T]]
    import ev.*
    xs.sum.toDouble / xs.size


//Best Practice 
//Put all implicits declaration in companion objects
trait Add[T]{
    def plus(x:T, y:T) :T
}
case class Point(x:Int, y:Int)
object Point {
    implicit object ghft extends Add[Point]{
        def plus(x:Point, y:Point) = Point(x.x+y.x, x.y+y.y)
    }
    
    implicit object porde extends Ordering[Point]{
        def compare(x:Point, y:Point) = x.x.compare(y.x)
    }
    
    def generate(n:Int) = 
        (0 to n).toList.map(e => Point(e, e+1)) //List[Point]
}

Point.generate(5).sorted

//Excersize 
import scala.collection.mutable.{Queue => MQ, Stack =>MS}
import scala.util._
import java.io._ 


trait Q[CC[_]]{  
    def isEmpty:Boolean 
    def getOne:Option[File]
    def addMany(files: File*):CC[File]
    def clear():Unit 
}

def QMQ:Q[MQ]  = new Q[MQ]{
    private val queue = MQ[File]()
    def isEmpty:Boolean = queue.isEmpty
    def getOne:Option[File] = Try(queue.dequeue()).toOption
    def addMany(files: File*):MQ[File] = {
        queue ++= files
        queue
    }
    def clear():Unit = queue.dequeueAll(x => true)
}
def QMS:Q[MS]  = new Q[MS]{
    private val stack = MS[File]()
    def isEmpty:Boolean = stack.isEmpty
    def getOne:Option[File] = Try(stack.pop()).toOption
    def addMany(files: File*):MS[File] = {
        files.foreach( stack.push )
        stack
    }
    def clear():Unit = stack.popAll()
}

implicit val singletone_QMQ:Q[MQ] = QMQ
implicit val  singletone_QMS:Q[MS] = QMS


case class GetFiles[CC[_]](path:String)( implicit queue: Q[CC])  extends Iterator[File]{
    val q = {
        queue.clear()
        queue.addMany( (new File(path)).listFiles.toIndexedSeq : _* ) 
    }
    //println(q)
    def hasNext = ! queue.isEmpty
    def next():File = queue.getOne match {
            case Some(f) => 
                if (f.isFile) f else {
                    queue.addMany( f.listFiles.toIndexedSeq : _*)
                    next()
                }
            case None    => new File("")
        }
}

val path = raw"D:\tool"
//Check 
val aa = GetFiles[MQ](path)
aa.take(10).toList 
val bb = GetFiles[MS](path)
bb.take(10).toList 

//OR for seperate instance of Stack 
val aaq = GetFiles[MQ](path)(using QMQ)
aaq.take(10).toList 

///HandsOn  - all generic on lst:List[T] 
Mean(lst) =         Sum of lst/length of lst 
Median(lst) =       sort and midddle value or average of two middle  if length is even
sd(lst) =           sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
Mode(lst) =         sort with frequency, highest frequency
Put these methods in List 



///Implicit Scope 
The implicit scope available under number 1 below has precedence over the ones under number 2. 

Other than that, if there are several eligible arguments which match the implicit parameter’s type, 
a most specific one will be chosen using the rules of static overloading resolution 
(see Scala Specification §6.26.3). 

1.First look in Lexical scope
    •Implicits defined in current scope explicitly
    •Explicit imports eg import com.xyz
    •wildcard imports eg import integral._
    •Same scope in other files(ie package objects of users or package object where type is defined)
2.Now look in other implicits scope 
    •Companion objects of a type ie for C[T],  in object C 
    •Implicit scope of an argument type if used inside a function 
    •Implicit scope of type arguments  ie for C[T] ,in object T 
    •Outer objects for nested types including parent class 

///One example of type class 
sealed trait Json
final case class JsObject(get: Map[String, Json]) extends Json
final case class JsString(get: String) extends Json
final case class JsNumber(get: Double) extends Json
final case object JsNull extends Json


// The "serialize to JSON" behaviour is encoded in this trait
trait JsonWriter[A] {
    def write(value: A): Json
}


//FOr 
case class Person(name: String, email: String)

object JsonWriterInstances {
    implicit val stringWriter: JsonWriter[String] =
       new JsonWriter[String] {
           def write(value: String): Json =
            JsString(value)
       }

    implicit val personWriter: JsonWriter[Person] =
       new JsonWriter[Person] {
           def write(value: Person): Json =
            JsObject(Map(
               "name" -> JsString(value.name),
               "email" -> JsString(value.email)
             ))
       }
}
//Interface 
object JsonH {
    def toJson[A](value: A)(implicit w: JsonWriter[A]): Json =
      w.write(value)
}

import JsonWriterInstances._
//import JsonWriterInstances.given 

JsonH.toJson(Person("Dave", "dave@example.com"))

We can alternatively use extension methods to extend existing types with interface methods. 

object JsonSyntax {
    implicit class JsonWriterOps[A](value: A) {
        def toJson(implicit w: JsonWriter[A]): Json =
          w.write(value)
    }
}

import JsonWriterInstances._
import JsonSyntax._
Person("Dave", "dave@example.com").toJson

implicitly[JsonWriter[String]]
 // res5: JsonWriter[String] = repl.Session$App0$JsonWriterInstances$$anon$1@6fccdc48
 //summon[JsonWriter[String]]


///Conditional Implicits 
Consider defining a JsonWriter for Option. 
We would need a JsonWriter[Option[A]] for every A we care about in our application. 

implicit val optionIntWriter: JsonWriter[Option[Int]] =???
implicit val optionPersonWriter: JsonWriter[Option[Person]] =  ???
// and so on...

OR Use implicit def:

implicit def optionWriter[A](implicit writer: JsonWriter[A]): JsonWriter[Option[A]] =
  new JsonWriter[Option[A]] {
      def write(option: Option[A]): Json =
        option match {
            case Some(aValue) => writer.write(aValue)
            case None        => JsNull
        }
  }

When the compiler sees an expression like this:
JsonH.toJson(Option("A string"))

it searches for an implicit JsonWriter[Option[String]]. It finds the 
implicit method for JsonWriter[Option[A]]:

JsonH.toJson(Option("A string"))(optionWriter[String])
//JsonH.toJson(Option("A string"))(using optionWriter[String])

and recursively searches for a JsonWriter[String] to use as the parameterto optionWriter:
JsonH.toJson(Option("A string"))(optionWriter(stringWriter)) 
    
When working with type classes we must consider two issues that control instance selection:
    · What is the relationship between an instance defined on a type and its   subtypes?
        For example, if we define a JsonWriter[Option[Int]], will the ex
        pression Json.toJson(Some(1)) select this instance? (Remember
        that Some is a subtype of Option).

     · How do we choose between type class instances when there are many
       available?
        What if we define two JsonWriters , one for Option and other for Some 
        which one would it prefer when we do Json.toJson(Some(1))?
    

It turns out we cant have both at once. 
The three choices give us behaviour as follows:(ie for invariant, matching should be exact)

Type Class Variance               Invariant       Covariant      Contravariant

Supertype instance used?          No              No             Yes
More specific type preferred?     No              Yes            No


For Option[+A], it is Covariant , hence if Option and Some is present, Some is choosen 
But if Some is not present and Option is present , then Error , 

We can solve this problem with a type annotation like Some(1) : Option[Int] 
or by using "smart constructors" like the Option.apply, Option.empty, some, and none methods 
which returns option[T] instead of Some or None 

///Type class - Example from Cats - Show 
Show is an alternative to the Java toString method. 
It is defined by a single function show:

def show(a: A): String

The difference is that toString is defined on Any(Java’s Object) 
and can therefore be called on anything, not just case classes. 

Most often, this is unwanted behaviour, as the standard implementation of 
toString on non case classes is mostly gibberish. 

(new {}).toString
// res0: String = "repl.MdocSession$App$$anon$1@31418a9b"


//Example 
import cats._ 
import cats.implicits._ 

//It has below 
trait Show[A] {
    def show(value: A): String
}
object Show {
    /** creates an instance of Show using the provided function */
    def show[A](f: A => String): Show[A]

    /** creates an instance of Show using object toString */
    def fromToString[A]: Show[A]
}
//USage 
import cats.Show

case class Person(name: String, age: Int)

implicit val showPerson: Show[Person] = Show.show(person => person.name)

case class Department(id: Int, name: String)

implicit val showDep: Show[Department] = Show.fromToString //case class has good ToString
// showDep: Show[Department] = cats.Show$$anon$3@184af520


import cats.implicits._

val john = Person("John", 31)
john.show
// res1: String = "John"

val engineering = Department(2, "Engineering")
show"$john works at $engineering"
// res2: String = "John works at Department(2,Engineering)"


//Custom 
import java.util.Date


implicit val dateShow: Show[Date] =
 new Show[Date] {
     def show(date: Date): String =
       s"${date.getTime}ms since the epoch."
 }


new Date().show
// res1: String = "1594650192117ms since the epoch."


//OR

implicit val dateShow: Show[Date] =
     Show.show(date => s"${date.getTime}ms since the epoch.")


//Our definition of Cat remains the same:
final case class Cat(name: String, age: Int, color: String)

implicit val catShow: Show[Cat] = Show.show[Cat] { cat =>
 val name   = cat.name.show
 val age    = cat.age.show
 val color = cat.color.show
 s"$name is a $age year-old $color cat."
}

println(Cat("Garfield", 38, "ginger and black").show)
// Garfield is a 38 year-old ginger and black cat.
 
 
///Type class - Example from Cats - Eq
Eq is designed to support typesafe equality and address annoyances using Scalas builtin == operator.
(which would always succeeds and return false if dissimilar types )
(we want dissimilar types to fail during compilation )

List(1, 2, 3).map(Option(_)).filter(item => item == 1)
// warning: Option[Int] and Int are unrelated: they will most likely never compare equal
// res: List[Option[Int]] = List()

The predicate in the filter clause always returns false be cause it is comparing an Int to an Option[Int].


//cats has below 
trait Eq[A] {
    def eqv(a: A, b: A): Boolean
    // other concrete methods based on eqv...
}

· === compares two objects for equality;
· =!= compares two objects for inequality.


import cats._ 
import cats.implicits._ 


val eqInt = Eq[Int]

eqInt.eqv(123, 123)
// res1: Boolean = true
eqInt.eqv(123, 234)
// res2: Boolean = false


eqInt.eqv(123, "234")
// error: type mismatch;
//     found   : String("234")
//     required: Int

123 === 123
// res4: Boolean = true
123 =!= 234
// res5: Boolean = true

123 === "123"
// error: type mismatch;
//     found   : String("123")
//     required: Int
// 123 === "123"
//             ^^^^^


Some(1) === None
// error: value === is not a member of Some[Int]
// Some(1) === None
// ^^^^^^^^^^^

We have received an error here because the types donot quite match up. We
have Eq instances in scope for Int and Option[Int] but the values we are
comparing are of type Some[Int] and Option is covariant, so either Some must have implementation or use smart constror 


(Some(1) : Option[Int]) === (None : Option[Int])
// res8: Boolean = false

//OR 
Option(1) === Option.empty[Int]
// res9: Boolean = false

or using special syntax from cats.syntax.option:
1.some === none[Int]
// res10: Boolean = false
1.some =!= none[Int]
// res11: Boolean = true

//Comparing Custom Types
import java.util.Date


implicit val dateEq: Eq[Date] = Eq.instance[Date] { (date1, date2) =>
    date1.getTime === date2.getTime
}


val x = new Date() // now
val y = new Date() // a bit later than now


x === x
// res12: Boolean = true
x === y
// res13: Boolean = false


final case class Cat(name: String, age: Int, color: String)

val cat1 = Cat("Garfield",      38, "orange and black")
val cat2 = Cat("Heathcliff", 33, "orange and black")

val optionCat1 = Option(cat1)
val optionCat2 = Option.empty[Cat]


implicit val catEqual: Eq[Cat] =
    Eq.instance[Cat] { (cat1, cat2) =>
       (cat1.name   === cat2.name ) &&
       (cat1.age    === cat2.age   ) &&
       (cat1.color === cat2.color)
    }



val cat1 = Cat("Garfield",        38, "orange and black")
// cat1: Cat = Cat("Garfield", 38, "orange and black")
val cat2 = Cat("Heathcliff", 32, "orange and black")
// cat2: Cat = Cat("Heathcliff", 32, "orange and black")

cat1 === cat2
// res15: Boolean = false
cat1 =!= cat2
// res16: Boolean = true


optionCat1 === optionCat2
// res17: Boolean = false
optionCat1 =!= optionCat2
// res18: Boolean = true






///Property-Based Testing
Property based testing relies on properties(different than Unit test/ AT/ST)
It checks that a function, program or whatever system under test abides by a property. 
Only applicable if program can be represented by a property 

A property is just something like:
    for all (x, y, ...)
    such as precondition(x, y, ...) holds
    property(x, y, ...) is true

//Example 
for all (a, b) strings
the concatenation of a, b always ends with b 

///PropertyBased testing by ScalaCheck
ScalaCheck (http://www.scalacheck.org) is a framework for automated PBT in Scala. 

libraryDependencies += "org.scalacheck" %% "scalacheck" % "1.15.3"      // % Test

//others 
libraryDependencies += "org.scalatest" %% "scalatest" % "3.2.2"         // % Test
libraryDependencies += "org.typelevel" %% "cats-core" % "2.1.0"

Now, we can define and verify our first property:

https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Prop.html
//Methods - forall takes a function which returns Boolean 
//and  there is an implicit conversion Boolean => Property 
//and test data is generated by  Gen[String], in our case, random strings.
def forAll[T1, T2, P](g1: Gen[T1], g2: Gen[T2])(f: (T1, T2) => P)(implicit p: (P) => Prop, s1: Shrink[T1], pp1: (T1) => Pretty, s2: Shrink[T2], pp2: (T2) => Pretty): Prop
def forAll[T1, P](g1: Gen[T1])(f: (T1) => P)(implicit p: (P) => Prop, s1: Shrink[T1], pp1: (T1) => Pretty): Prop

//Example 
import org.scalacheck._
import org.scalacheck.Prop._

val stringLengthProp = forAll { (_: String).length >= 0 }
//stringLength: org.scalacheck.Prop = Prop

stringLengthProp.check
//+ OK, passed 100 tests.


//more test 
val propReverseList = forAll { l: List[String] => l.reverse.reverse == l }

val propConcatString = forAll { (s1: String, s2: String) =>
  (s1 + s2).endsWith(s2)
}

propReverseList.check
propConcatString.check

///Properties Classification- Conditional Properties using ==>:
Now ScalaCheck will only care for the cases when n is not negative. 
We also filter out large numbers, since we donot want to generate huge lists.

val propMakeList = forAll { n: Int =>
  (n >= 0 && n < 10000) ==> (List.fill(n)("").length == n)
}
propMakeList.check


///Types of properties-Commutativity
If order operands do not matter, we say that the operation is commutative. 

scala> forAll((a: Int, b: Int) => a + b == b + a).check
+ OK, passed 100 tests.

scala> forAll((a: Int, b: Int) => a * b == b * a).check
+ OK, passed 100 tests.

For strings, the addition is defined as a concatenation but is not commutative in general:
    
scala> forAll((a: String, b: String) => a + b == b + a).check
! Falsified after 1 passed tests.
> ARG_0: "\u0001"
> ARG_0_ORIGINAL
> ARG_1: "\u0000"
> ARG_1_ORIGINAL:

If at least one of the strings is empty, the property becomes commutative 

scala> forAll((a: String) => a + "" == "" + a).check
+ OK, passed 100 tests.

///HandsON 
Check Associativity of three integers 
What about Strings?

///Types of properties-Identity 
scala> forAll((a: Int) => a + 0 == a && 0 + a == a).check
+ OK, passed 100 tests.

scala> forAll((a: Int) => a * 1 == a && 1 * a == a).check
+ OK, passed 100 tests.

scala> forAll((a: String) => a + "" == a && "" + a == a).check
+ OK, passed 100 tests.


///Combining properties 
Note 
the == compares two values and returns a Boolean, which is then implicitly 
converted to the Prop(needs implicit conversion); 
the ?= or ?= is a method from Prop which compares two props, Use this method always 
when possible (difference between ?= and ?= are reporting , check reference. Prop$)

A property can also be labelled(eg "Commutativity"), which makes it easier to spot in the results
Note |: from Prop class and | should be towards string 

Check all the methods 
//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Prop$.html

//Check how it fails , by making != 
forAll { (a: Int, b: Int, c: Int, d: String) =>
  val multiplicationLaws = all(
    "Commutativity" |: (a * b ?= b * a),
    "Associativity" |: ((a * b) * c == a * (b * c)),
    "Identity" |: all(a * 1 == a, 1 * a == a)
  ) :| "Multiplication laws"

   val stringProps = atLeastOne(d.isEmpty, d.nonEmpty)
   all(multiplicationLaws, stringProps)
 }.check()

    + OK, passed 100 tests.

//Details 
val p1 = forAll(...)

val p2 = forAll(...)

val p3 = p1 && p2

val p4 = p1 || p2

val p5 = p1 == p2

val p6 = all(p1, p2) // same as p1 && p2

val p7 = atLeastOne(p1, p2) // same as p1 || p2

Here, p3 will hold if and only if both p1 and p2 hold, 
p4 will hold if either p1 or p2 holds, and p5 will hold if p1 holds exactly when p2 holds and vice versa.

///Grouping properties 
import org.scalacheck._

object StringSpecification extends Properties("String") {
  import Prop.forAll

  //single property 
  //property(name: String)
  property("startsWith") = forAll { (a: String, b: String) =>
    (a+b).startsWith(a)
  }

  property("endsWith") = forAll { (a: String, b: String) =>
    (a+b).endsWith(b)
  }

  property("substring") = forAll { (a: String, b: String) =>
    (a+b).substring(a.length) == b
  }

  property("substring") = forAll { (a: String, b: String, c: String) =>
    (a+b+c).substring(a.length, a.length+b.length) == b
  }
}
scala > StringSpecification.check()

///Gen vs Arbitrary
Note there are two version of forAll , note P boolean can be implicitely converted to Prop 
Prop.forAll[T1, P](g1: Gen[T1])(f: (T1) => P)(implicit p: (P) => Prop,..):Prop 
Prop.forAll[A1, P](f: (A1) => P)(implicit p: (P) => Prop, a1: Arbitrary[A1],...):Prop

first version , forAll takes Gen[T], Gen[T] produces values/testdata  for Props
For each type (builtin or customized), Gen[T] must be available and be passed to forAll 
However, 2nd version of forAll takes implicit Arbitrary which has .arbitrary member to give Gen[T]

sealed abstract class Arbitrary[T] {
  val arbitrary: Gen[T]
}

There are many implicit Arbitrary available (eg Int, String...)
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Arbitrary$.html

//Existing generators
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen$.html
Check detail in above link 

All subtypes of AnyVal, Unit, Function0, chars and strings with different contents
(alphaChar, alphaLowerChar, alphaNumChar, alphaStr, alphaUpperChar, numChar,
numStr), containers, lists and maps (containerOf, containerOf1, containerOfN,
nonEmptyContainerOf, listOf, listOf1, listOfN, nonEmptyListOf, mapOf, mapOfN,
nonEmptyMap), numbers (chooseNum, negNum, posNum), duration, Calendar, BitSet, and
even Test.Parameters

For custom class, one can write Gen[T] and then create Arbitrary instance 

import org.scalacheck._
import org.scalacheck.Prop._

case class Person(firstName:String, lastName:String, age:Int)

val genPerson = for {
  firstName <- Gen.oneOf("Alan", "Ada", "Alonzo")
  lastName <- Gen.oneOf("Lovelace", "Turing", "Church")
  age <- Gen.choose(0,100) if (age >= 18)
} yield Person(firstName, lastName, age)

implicit val arbMyClass: Arbitrary[Person] = Arbitrary(genPerson)

val myProp = Prop.forAll { (myClass: Person) =>
  println(myClass)
  List("Alan", "Ada", "Alonzo").contains(myClass.firstName) //Boolean can be implicitly converted to Prop 
}
myProp.check()

//one value 
genPerson.sample.get
//Person = Person(Alan,Lovelace,73)


//builtin Gen 
val genBool: Gen[Boolean] = Gen.oneOf(true,false)

//OR The same boolean generator is defined in Arbitrary as an implicit declaration 
val genBool: Gen[Boolean] = Arbitrary.arbitrary[Boolean]

//his is a boolean generator, but one that always produces true:
val genBool = Gen.const(true)

//This is a generator of booleans that is true at a 2-to-1 ratio:
val genBool = Gen.frequency(2 -> true, 1 -> false)

//This is a boolean generator that will produce true 75% of the time:
val genBool = Gen.prob(0.75)

//This is an example of a custom generator for integers:
val genSmallInt: Gen[Int] = Gen.choose(-100,100)

val genListOfInts: Gen[List[Int]] = Gen.listOf(genSmallInt)

val genSeqOfInts: Gen[Seq[Int]] = Gen.someOf(-100 to 100)

val genVectorOfInts: Gen[Vector[Int]] = Gen.containerOf[Vector,Int](genSmallInt)

val genMap: Gen[Map[Int,Boolean]] = Gen.mapOf(Gen.zip(genSmallInt, genBool))

val genOptionalInt: Gen[Option[Int]] = Gen.option(genSmallInt)

//Or collections of one or more small integers:
val genListOfInts: Gen[List[Int]] = Gen.nonEmptyListOf(genSmallInt)

val genSeqOfInts: Gen[Seq[Int]] = Gen.atLeastOne(-100 to 100)

val genVectorOfInts: Gen[Vector[Int]] = Gen.nonEmptyContainerOf[Vector,Int](genSmallInt)

val genMap: Gen[Map[Int,Boolean]] = Gen.nonEmptyMap(Gen.zip(genSmallInt, genBool))

val genOptionalInt: Gen[Option[Int]] = Gen.some(genSmallInt)


///Builtin implicits arbitrary Generator 
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Arbitrary$.html
Has many default implicits 
eg arbInt, arbBigDecimal, arbString etc 

import org.scalacheck._
import org.scalacheck.Prop._

val evenInteger:Gen[Int] = Arbitrary.arbitrary[Int] suchThat (_ % 2 == 0)

val squares = for {
  xs <- Arbitrary.arbitrary[List[Int]]
} yield xs.map(x => x*x)


//Example 
abstract sealed class Tree[T] {
  def merge(t: Tree[T]) = Internal(List(this, t))

  def size: Int = this match {
    case Leaf(_) => 1
    case Internal(children) => (children :\ 0) (_.size + _)  //:\ is foldLeft 
  }
}
case class Internal[T](children: Seq[Tree[T]]) extends Tree[T]
case class Leaf[T](elem: T) extends Tree[T]

implicit def arbTree[T](implicit a: Arbitrary[T]): Arbitrary[Tree[T]] =Arbitrary {
  val genLeaf = for(e <- Arbitrary.arbitrary[T]) yield Leaf(e)

  def genInternal(sz: Int): Gen[Tree[T]] = for {
    n <- Gen.choose(sz/3, sz/2)
    c <- Gen.listOfN(n, sizedTree(sz/2))
  } yield Internal(c)

  def sizedTree(sz: Int) =
    if(sz <= 0) genLeaf
    else Gen.frequency((1, genLeaf), (3, genInternal(sz)))

  Gen.sized(sz => sizedTree(sz))
}

As long as the implicit arbTree function is in scope, 
you can now write properties like this:

val propMergeTree = forAll( (t1: Tree[Int], t2: Tree[Int]) =>
  t1.size + t2.size == t1.merge(t2).size

///Shrinkers 
One interesting feature of ScalaCheck is that if it finds an argument that falsifies a property, 
it tries to minimise that argument before it is reported. 

This is done automatically when you use the Prop.property and Prop.forAll methods to create properties, 
but not if you use Prop.forAllNoShrink. 

In PBT, the test data comes from generators and it is kind of random. Given this fact, we
could expect that it might be hard to find out why a test is failing. Consider the following
example:

But below failed after first test 

scala> forAllNoShrink { (num: Int) =>
      num < 42
      }.check()
! Falsified after 0 passed tests.
> ARG_0: 2008612603

Here, we can see that our property was falsified by the number 2008612603 which is not < 42 

Compare this with Shrink 

forAll { (num: Int) =>
    num < 42
    }.check()
! Falsified after 0 passed tests.
> ARG_0: 67
> ARG_0_ORIGINAL: 1128316729


It is more or less obvious for an Int, but consider a case with a
list of many elements and a property formulated for these elements:

// def listOfN[T](n: Int, g: Gen[T]): Gen[List[T]], where List[T].size == n 
//Use Gen.alphaStr if we want to get alphanumeric str 
scala> forAllNoShrink(Gen.listOfN(1000, Gen.asciiStr)) {
            _.forall(_.length < 10)
     }.check()
! Falsified after 10 passed tests.
> ARG_0: List

... // a lot of similar lines

Obviously, it is near to impossible to find out which of 1,000 strings 
had a wrong length in this test.

Use  Shrink. 
The job of the shrinker is to find a minimal test data with which the property does not hold. 
//
scala> forAll(Gen.listOfN(1000, Gen.asciiStr)) {
            _.forall(_.length < 10)
      }.check()
! Falsified after 10 passed tests.
> ARG_0: List("")
> ARG_0_ORIGINAL: // a long list as before

Here, we can see that the minimal list, which falsifies our property, is the list with one
empty string. The original failing input is shown as ARG_0_ORIGINAL and it is of a similar
length and complexity as we have seen before.

The Shrink instances are passed as implicit parameters, so we can summon one to see how
they work. we will do this with our failing value for Int property:

forAllNoShrink { (num: Int) =>
      num < 42
      }.check()
! Falsified after 0 passed tests.
> ARG_0: 534044208

val intShrink: Shrink[Int] = implicitly[Shrink[Int]]

scala> intShrink.shrink(534044208).toList
val res16: List[Int] = List(267022104, -267022104, 133511052, -133511052, 6675
5526, -66755526, 33377763, -33377763, 16688881, -16688881, 8344440, -8344440,
4172220, -4172220, 2086110, -2086110, 1043055, -1043055, 521527, -521527, 2607
63, -260763, 130381, -130381, 65190, -65190, 32595, -32595, 16297, -16297, 814
8, -8148, 4074, -4074, 2037, -2037, 1018, -1018, 509, -509, 254, -254, 127, -1
27, 63, -63, 31, -31, 15, -15, 7, -7, 3, -3, 1, -1, 0)

The shrink method generates a stream of values --the values produced by the Shrink lie symmetrically 
to the central value of 0 (zero), starting from the initial failing value, and then are each time
divided by two until they converge to the zero. 

It is easy to see that numbers produced by the Shrink will depend on the initial failing
argument, in ourcase 2008612603. 
This is why for the first property the returned value will differ each time:

scala> forAll { (_: Int) < 42 }.check()
! Falsified after 1 passed tests.
> ARG_0: 83
> ARG_0_ORIGINAL: 1394573331

scala> intShrink.shrink(1394573331).toList //which contains 83 
val res17: List[Int] = List(697286665, -697286665, 348643332, -348643332, 1743
21666, -174321666, 87160833, -87160833, 43580416, -43580416, 21790208, -217902
08, 10895104, -10895104, 5447552, -5447552, 2723776, -2723776, 1361888, -13618
88, 680944, -680944, 340472, -340472, 170236, -170236, 85118, -85118, 42559, -
42559, 21279, -21279, 10639, -10639, 5319, -5319, 2659, -2659, 1329, -1329, 66
4, -664, 332, -332, 166, -166, 83, -83, 41, -41, 20, -20, 10, -10, 5, -5, 2, -
2, 1, -1, 0)

scala> forAll { (_: Int) < 42 }.check()
! Falsified after 0 passed tests.
> ARG_0: 54
> ARG_0_ORIGINAL: 908148321

scala> forAll { (_: Int) < 42 }.check
! Falsified after 2 passed tests.
> ARG_0: 57
> ARG_0_ORIGINAL: 969910515

scala> forAll { (_: Int) < 42 }.check
! Falsified after 6 passed tests.
> ARG_0: 44
> ARG_0_ORIGINAL: 745869268


