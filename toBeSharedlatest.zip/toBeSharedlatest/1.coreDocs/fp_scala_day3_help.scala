Day Three
#6. Exploring Built-In Effects
#    Exploring Built-In Effects
#    Introduction to effects
#    Option
#    Either
#    Try
#    Future  
7. Understanding Algebraic Structures
    Understanding Algebraic Structures
    Introduction to abstract algebraic structures
    Semigroup
    Monoid
    Foldable
    Group
8. Dealing with Effects
    Dealing with Effects
    Functor
    Applicative
    Traversable
#9. Familiarizing Yourself with Basic Monads
#    Familiarizing Yourself with Basic Monads
#    Introduction to monads
#    Id Monad
#    State monad
#    Reader monad
#    Writer monad
----------------------

////------------ Exploring Built-In Effects-----------------------------------------------------------------------------------------------
6.       Exploring Built-In Effects
·       Exploring Built-In Effects
·       Introduction to effects
·       Option
·       Either
·       Try
·       Future
·       Summary
·       Technical requirements

///Option[T] 
//Option ADT 
sealed abstract class Option[+A]
case object None extends Option[Nothing]
final case class Some[+A](value: A) extends Option[A]

class Request {
    import scala.util.Random 
    val r = new Random 
    def nget = {
        if (r.nextInt(10) < 5) "Hello" else null
    }
    def get = Option(nget)
}

val ls = (0 to 10).toList.map{i => (new Request).get }
//map 
ls.map { o => o.map{_.size} }
//collapse
ls.flatMap { o => o.map{_.size} }
//OR collect take PF
ls.collect{ case Some(x) => x }
//OR map takes Function 
ls.map { 
    case Some(x) => x 
    case None  => "" 
    }

// monadic 
val one = (new Request).get 
one.map(_.trim).filter(_.size > 1).map(_.toUpperCase)
one.getOrElse("NOT FOUND")
Option(null).get

//OR  
one match {
    case Some(x) => println(x)
}

//Goodies from object Function 
Function.unlift[T, R](f: (T) => Option[R]): PartialFunction[T, R]
Turns a function A => Option[B] into a PartialFunction[A, B], A is arg, B is return 

//COnverse function is in PF 
//PartialFunction[A, B] is a function defined for some subset of the domain A (as specified by the isDefinedAt method). 
//You can "lift" a PartialFunction[A, B] into a Function[A, Option[B]]. 
//That is, a function defined over the whole of A but whose values are of type Option[B]

val pf: PartialFunction[Int, Boolean] = { case i if i > 0 => i % 2 == 0}

scala> res1 = pf.lift
res1: Int => Option[Boolean] = <function1>

scala> res1(-1)
res2: Option[Boolean] = None

scala> res1(1)
res3: Option[Boolean] = Some(false)

//Note any collection that extends PartialFunction[Int, A] 
// may be lifted; thus for instance
Seq(1,2,3).lift
Int => Option[Int] = <function1> //into a total function where values not defined in the collection are mapped onto None,

Seq(1,2,3).lift(2)
Option[Int] = Some(3)

Seq(1,2,3).lift(22)
Option[Int] = None

Seq(1,2,3).lift(2).getOrElse(-1)
Int = 3

Seq(1,2,3).lift(22).getOrElse(-1)
Int = -1


//List for method: "lift" a method invocation into a function. This is called eta-expansion 
scala> def times2(i: Int) = i * 2
times2: (i: Int)Int

scala> val f = times2 _
f: Int => Int = <function1>

scala> f(4)
res0: Int = 8

///a lift function takes a function A => B, 
//the lifted function F[A] => F[B] can be applied to a functor or monad F[A].

def double(x: Int): Int = 2 * x, 
val xs = Seq(1, 2, 3). 

//We cannot double(xs) due to incompatible types. 
//but 
val doubleSeq = liftToSeq(double)(xs) // Seq(2, 4, 6).
def liftToSeq[A, B](f: A => B): (Seq[A] => Seq[B]) = (seq: Seq[A]) => seq.map(f)



///Try[T] 
//Trye ADT 
sealed abstract class Try[+T]
final case class Success[+T](value: T) extends Try[T]
final case class Failure[+T](exception: Throwable) extends Try[T]

//Example 
import scala.util._ 
class Request {
    import scala.util.Random 
    val r = new Random 
    def eget = {
        val den = if (r.nextInt(10) < 5) 42 else 0
        42/den
    }
    def get = Try(eget)
}
val ls = (0 to 10).toList.map{i => (new Request).get }
//map 
ls.map { o => o.map{x=>x*x} }

//following not there as Try does not implement flatten 
ls.flatMap{ o => o.map{x=>x*x} }
//but 
ls.collect{ case Success(x) => x}

// monadic 
val one = (new Request).get 
one.map(_.toString).map(_.trim).filter(_.size >= 1).map(_.toUpperCase)
one.toOption
one.toOption.get



///Future 

import scala.concurrent._ 
import scala.concurrent.duration._ 
import scala.concurrent.ExecutionContext.Implicits.global 

val fut = Future {
    Thread.sleep(10)
    "Hello"
}
//monadic 
scala> fut.map{ x => x.toUpperCase}.filter(e => e.size != 0).map{_.size}
res54: scala.concurrent.Future[Int] = Future(<not completed>)

scala> val re = Await.result(res54, Duration.Inf)

//or 
res54.foreach(println) 

//or 
res54.onSuccess{ case x:Int => println(x)}

//or 
res54.onComplete{
    case Success(x) => println(x)
    case Failure(ex) => println(ex)
}

//For - Note these are not in parallel, but in sequence 
def delta(startTime:Long) = System.currentTimeMillis - startTime
def time = System.currentTimeMillis
def sleep(time: Long): Unit = Thread.sleep(time)

val startTime = time
val fut = for {
    a <- Future { sleep(1000); 2*2 }
    b <- Future{ sleep(1000); "Hello" }.mapTo[String]
    c <- Future{ sleep(1000); a- 1} if a > 0
} yield {
    a*b.size*c 
}
println(Await.result(fut, Duration.Inf))
println(delta(startTime)) // ~3000 sec 

//To make it parallel , create them seperately as val 
val startTime = time
val a = Future { sleep(1000); 2*2 }
val b = Future{ sleep(1000); "Hello" }.mapTo[String]

val fut = for {
    a1 <- a
    b1 <- b
    c1 <- Future{ sleep(1000); a1 - 1} if a1 > 0
} yield {
    a1*b1.size*c1 
}
println(Await.result(fut, Duration.Inf))
println(delta(startTime))  //~2000 sec 

//download 
import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global //must for execution context
import scala.util._  //Success,Failure 
import scala.concurrent.duration._

//Dowload and sum of the bytes 

def get(url: String) = scala.io.Source.fromURL(url).getLines.toList.mkString
def create_urls(n:Int) =
       (0 to n).toList.map( e=> "https://www.google.co.in")

val htmls = create_urls(5).map {
        url => Future {   
            println(Thread.currentThread.getName)
            blocking { get(url) } 
        }.map(_.size)            
    } //List of Future
    
//Use sequence(simpler version of traverse)
//def sequence[A, M[X] <: TraversableOnce[X]](in: M[Future[A]])(implicit cbf: CanBuildFrom[M[Future[A]], A, M[A]], executor: ExecutionContext): Future[M[A]] 
// to convert imagesFuts from List[Future[...]] to a Future[List[...]].
//But one exception would result into full failure , hence only wait for this 
//but iterate original htmls 
val html2 = Future.sequence(htmls)   // Future of List 

//Or durectly using traverse
//def traverse[A, B, M[X] <: TraversableOnce[X]](in: M[A])(fn: (A) => Future[B])(implicit cbf: CanBuildFrom[M[A], B, M[B]], executor: ExecutionContext): Future[M[B]] 
//But one exception would result into full failure , hence only wait for this  

val html3 = Future.traverse(create_urls(5)){ url => 
    Future {   
            println(Thread.currentThread.getName)
            blocking { get(url) } 
        }.map(_.size)
} // Future of List 

Await.result(html2, Duration.Inf).sum 
Await.result(html3, Duration.Inf).sum 

If 'one exception would result into full failure' is not wanted , can use below types 
Future.firstCompletedOf[T](futures: IterableOnce[Future[T]])(implicit executor: ExecutionContext): Future[T]
Future.foldLeft[T, R](futures: collection.immutable.Iterable[Future[T]])(zero: R)(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R]
//example 
f_fut = Future.foldLeft(htmls)(0)( (r,t) => r+t)
Await.result(html3, Duration.Inf)



//Duration 
import scala.concurrent.duration._
import java.util.concurrent.TimeUnit._

// instantiation
val d1 = Duration(100, MILLISECONDS) // from Long and TimeUnit
val d2 = Duration(100, "millis") // from Long and String
val d3 = 100 millis // implicitly from Long, Int or Double
val d4 = Duration("1.2 µs") // from String

// pattern matching
val Duration(length, unit) = 5 millis

///Execution Context 
We need execution context to run Future 
given ec: ExecutionContext = ExecutionContext.fromExecutor(
  new java.util.concurrent.ForkJoinPool(4) //initialParallelism: Int
)
val nonec2 = ExecutionContext.fromExecutor(java.util.concurrent.Executors.newFixedThreadPool(4)) //limit: Int


OR use builtin 
import scala.concurrent.ExecutionContext.Implicits.global 

OR 
implicit val ec = ExecutionContext.global
//scala3 
given ExecutionContext = ExecutionContext.global

By default the ExecutionContext.global sets the parallelism level 
of its underlying fork-join pool to the number of available processors (Runtime.availableProcessors). 
This configuration can be overridden by setting one (or more) of the following VM attributes:
    scala.concurrent.context.minThreads - defaults to Runtime.availableProcessors
    scala.concurrent.context.numThreads - can be a number or a multiplier (N) in the form ‘xN’ ; defaults to Runtime.availableProcessors
    scala.concurrent.context.maxThreads - defaults to Runtime.availableProcessors

The parallelism level will be set to numThreads as long as it remains within [minThreads; maxThreads]


//blocking construct
//Used to designate a piece of code which potentially blocks, 
//allowing the current BlockContext to adjust the runtime's behavior. 
//Properly marking blocking code may improve performance or avoid deadlocks.

//Usage - download
import scala.concurrent.blocking

def get(url: String) = scala.io.Source.fromURL(url).getLines.toList.mkString

Future {
    blocking { get("http://www.example.com") }
} onComplete {
    case Success(html) => println("Result: " + html.length)
    case Failure(ex) => println(ex)
}

If you need to wrap long lasting blocking operations 
we recommend using a dedicated ExecutionContext instead of default threadpool in above blocking construct 

Future {
    blocking {
      Thread.sleep(999999)
    }
  }(explicitly_created_executionContext)


//Recovering failed one , Result is Future
//'recover' - recover's PartiatialFunction returns simple value
// 'recoverWith'  - recoverWith's PartiatialFunction returns another Future
//'fallbackTo'  - fallbackTo simply takes another future 

val f = Future { 1/0 } recover { case e:Exception => 25 }

val f = Future { 1/0 } recoverWith { case e:Exception => Future { 200} }

val f = Future { 1/0 }.fallbackTo(Future { 200} )



//def  andThen[U](pf: PartialFunction[Try[T], U]): Future[T] 
//Applies Partial function(with Success or Failure) to the result of this future
//and returns a new future with final result 
 
val allposts = collection.mutable.Set[String]()

Future {
  List("Hello", "world")  
} andThen {
  case Success(posts) => allposts ++= posts
} andThen {
  case Success(posts) =>  for (post <- allposts) println(post)
}


//Future is a monad, 
//can call map, filter , these result into another future
//note these function ignores Failure and only works with Success
//can call collect as well

val f = Future { -5 }
val g = f collect {
  case x if x < 0 => -x
}
val h = f collect {
  case x if x > 0 => x * 2
}
Await.result(g, Duration.Zero) // evaluates to 5
Await.result(h, Duration.Zero) // throw a NoSuchElementException

//Projections
//def  failed: Future[Throwable] 
//Returns a failed projection of this future. ie if only Future is failed, returns throwable

val f = Future {
  2 / 0
}
for (exc <- f.failed) println(exc)


//The following example does not print anything to the screen:
val f = Future {
  4 / 2
}
for (exc <- f.failed) println(exc)

//Refefence
object Future 
    final def delegate[T](body: => Future[T])(implicit executor: ExecutionContext): Future[T]
        Starts an asynchronous computation and returns a Future instance 
        with the result of that computation once it completes.
    final def failed[T](exception: Throwable): Future[T]
        Creates an already completed Future with the specified exception.
    final def find[T](futures: collection.immutable.Iterable[Future[T]])(p: (T) => Boolean)(implicit executor: ExecutionContext): Future[Option[T]]
        Asynchronously and non-blockingly returns a Future that will hold the optional result 
        of the first Future with a result that matches the predicate, failed Futures will be ignored.
    final def firstCompletedOf[T](futures: IterableOnce[Future[T]])(implicit executor: ExecutionContext): Future[T]
        Asynchronously and non-blockingly returns a new Future to the result of the 
        first future in the list that is completed.
    final def foldLeft[T, R](futures: collection.immutable.Iterable[Future[T]])(zero: R)(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R]
        A non-blocking, asynchronous left fold over the specified futures, 
        with the start value of the given zero. op is called on zero 
        and as and when future completed value T
    final def fromTry[T](result: Try[T]): Future[T]
        Creates an already completed Future with the specified result or exception.
    final def reduceLeft[T, R >: T](futures: collection.immutable.Iterable[Future[T]])(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R]
        Initiates a non-blocking, asynchronous, left reduction over the supplied futures 
        where the zero is the result value of the first Future.
    final def sequence[A, CC[X] <: IterableOnce[X], To](in: CC[Future[A]])(implicit bf: BuildFrom[CC[Future[A]], A, To], executor: ExecutionContext): Future[To]
        Simple version of Future.traverse.
    final def successful[T](result: T): Future[T]
        Creates an already completed Future with the specified result.
    final def traverse[A, B, M[X] <: IterableOnce[X]](in: M[A])(fn: (A) => Future[B])(implicit bf: BuildFrom[M[A], B, M[B]], executor: ExecutionContext): Future[M[B]]
        Asynchronously and non-blockingly transforms a IterableOnce[A] into a
        Future[IterableOnce[B]] using the provided function A => Future[B].
    final val unit: Future[Unit]
        A Future which is completed with the Unit value.
    object never extends Future[Nothing]
        A Future which is never completed.

//Promises - single time set 
import scala.concurrent.{ Future, Promise }
import scala.concurrent.ExecutionContext.Implicits.global

val p = Promise[Int]()
val f = p.future

def produceSomething() = 22
def continueDoingSomethingUnrelated() = ()
def startDoingSomething() = ()
def doSomethingWithResult(r:Int) = ()

val producer = Future {
  val r = produceSomething()
  p success r
  continueDoingSomethingUnrelated()
}

val consumer = Future {
  startDoingSomething()
  f foreach { r =>
    doSomethingWithResult(r)
  }
}

To fail 
val p = Promise[T]()
val f = p.future

val producer = Future {
  val r = someComputation
  if (isInvalid(r))
    p failure (new IllegalStateException)
  else {
    val q = doSomeMoreComputation(r)
    p success q
  }
}

Or with another future 
val f = Future { 1 }
val p = Promise[Int]()

p completeWith f

p.future foreach { x =>
  println(x)
}

Or with trysuccess 
def first[T](f: Future[T], g: Future[T]): Future[T] = {
  val p = Promise[T]

  f foreach { x =>
    p.trySuccess(x)
  }

  g foreach { x =>
    p.trySuccess(x)
  }

  p.future
}

///Either
Either represents the possibility of a function having one of two alternative results which
can not be represented by a single type.
//adt 
sealed abstract class Either[+A, +B]
final case class Left[+A, +B](value: A) extends Either[A, B]
final case class Right[+A, +B](value: B) extends Either[A, B]

//Example 
import scala.util._ 

class Request {
    import scala.util.Random 
    val r = new Random 
    def eget = if (r.nextInt(10) < 5) 42 else -42

    //def cond[A, B](test: Boolean, right_when_true: => B, left_when_false: => A): Either[A, B]
    def get = {
        val x = eget
        Either.cond(eget > 0, x, "negative_value")
     }
}
val ls = (0 to 10).toList.map{i => (new Request).get }
//map 
ls.map { case Right(x) => x*x 
         case Left(str) => str.size}

Either is right-biased, which means that Right is assumed to be the default case to operate on. 
If it is Left, operations like map and flatMap return the Left value unchanged:

def doubled(i: Int) = i * 2
Right(42).map(doubled) // Right(84)
Left(42).map(doubled)  // Left(42)

Right(12).foreach(println) // prints "12"
Left(12).foreach(println)  // doesn't print

Right(12).getOrElse(17) // 12
Left(12).getOrElse(17)  // 17

Right(12).toOption // Some(12)
Left(12).toOption  // None

val left: Either[String, Int]  = Left("left")
val right: Either[Int, String] = left.swap // Result: Right("left")

val right = Right(2)
val left  = Left(3)
for {
  r1 <- right
  r2 <- left.swap
} yield r1 * r2 // Right(6)

Since Either defines the methods map and flatMap, it can also be used in for comprehensions:

val right1 = Right(1)   : Right[Double, Int]
val right2 = Right(2)
val right3 = Right(3)
val left23 = Left(23.0) : Left[Double, Int]
val left42 = Left(42.0)

for {
  x <- right1
  y <- right2
  z <- right3
} yield x + y + z 
//scala.util.Either[Double,Int] = Right(6)

right1.flatMap( x => right2.flatMap ( y => right3.map( z => x + y + z)))
//scala.util.Either[Double,Int] = Right(6)
Note right1 determines what Left type is 
right3.map ( z => z+1)  //Either[Nothing,Int]


for {
  x <- right1
  y <- right2
  z <- left23
} yield x + y + z // Left(23.0)
right1.flatMap( x => right2.flatMap ( y => left23.map( z => x + y + z)))
//scala.util.Either[Double,Int] = Left(23.0)
//Note map on Left remains Left unchanged 
left23.map( z => z + 1)  //Either[Double,Int] = Left(23.0)
right2.flatMap ( y => left23.map( z => z + y)) //Either[Double,Int] = Left(23.0)

for {
  x <- right1
  y <- left23
  z <- right2
} yield x + y + z // Left(23.0)

// Guard expressions are not supported:
for {
  i <- right1
  if i > 0
} yield i
// error: value withFilter is not a member of Right[Double,Int]

Because of right-biasing, 
Left values may require an explicit type argument for type parameter B, the right value. 
Otherwise, it might be inferred as Nothing.

Either[+A, +B].map[B1](f: (B) => B1): Either[A, B1]
Either[+A, +B].flatMap[A1 >: A, B1](f: (B) => Either[A1, B1]): Either[A1, B1]

right3.map ( z => z+1)  //Either[Nothing,Int]
for (x <- right2 ; y <- left23) yield x + y  // Left(23.0)
for (x <- right2 ; y <- left42) yield x + y  // error

for {
  x <- right1
  y <- left42  // type at this position: Either[Double, Nothing]
  z <- left23
} yield x + y + z
// Left(42.0), but unexpectedly a `Either[Double,String]`

Special ops on Either 

Either[+A, +B].joinLeft[A1 >: A, B1 >: B, C](implicit ev: <:<[A1, Either[C, B1]]): Either[C, B1]
    Joins an Either through Left.
    This method requires that the left side of this Either is itself an Either type. 
    That is, this must be some type like:Either[Either[C, B], B]

    If this instance is a Left[Either[C, B]] then the contained Either[C, B] will be returned, 
    otherwise this value will be returned unmodified.
    //Example 
    Left[Either[Int, String], String](Right("flower")).joinLeft // Result: Right("flower")
    Left[Either[Int, String], String](Left(12)).joinLeft // Result: Left(12)
    Right[Either[Int, String], String]("daisy").joinLeft // Result: Right("daisy")

Either[+A, +B].joinRight[A1 >: A, B1 >: B, C](implicit ev: <:<[B1, Either[A1, C]]): Either[A1, C]
    Joins an Either through Right.
    This method requires that the right side of this Either is itself an Either type. 
    That is, this must be some type like: Either[A, Either[A, C]]
    If this instance is a Right[Either[A, C]] then the contained Either[A, C] will be returned, 
    otherwise this value will be returned unmodified.
    //Example:
    Right[String, Either[String, Int]](Right(12)).joinRight // Result: Right(12)
    Right[String, Either[String, Int]](Left("flower")).joinRight // Result: Left("flower")
    Left[String, Either[String, Int]]("flower").joinRight // Result: Left("flower")

///Option, Try and Either fold 
The Either.fold method is unbiased as it treats the left and right sides of Either equally.

Either[+A, +B]
    def fold[C](fa: (A) => C, fb: (B) => C): C
        Applies fa if this is a Left or fb if this is a Right.
    //Example 
    val result = util.Try("42".toInt).toEither
    result.fold(
      e => s"Operation failed with $e",
      v => s"Operation produced value: $v"
    )    
   
Option[+A]   
    def fold[B](ifEmpty: => B)(f: (A) => B): B
        This is equivalent to:
        option match {
          case Some(x) => f(x)
          case None    => ifEmpty
        }

Try[+T]
    def fold[U](fa: (Throwable) => U, fb: (T) => U): U
        Applies fa if this is a Failure or fb if this is a Success.
        //Example 
        val result: Try[Int] = Try { string.toInt }
        println(result.fold(
          ex => "Operation failed with " + ex,
          v => "Operation produced value: " + v
        ))
        
Future[+T]     
    def transform[S](f: (Try[T]) => Try[S])(implicit executor: ExecutionContext): Future[S]
        Creates a new Future by applying the specified function to the result of this Future.
    def transformWith[S](f: (Try[T]) => Future[S])(implicit executor: ExecutionContext): Future[S]
        Creates a new Future by applying the specified function, which produces a Future, 
        to the result of this Future.
    //
    val fut = Future( 100 ).transform { case Success(n) => Success(n-10)
                              case Failure(ex) => Failure(ex) }
    Await.result(fut, Duration.Inf)
        

////--------------Understanding Algebraic Structures---------------------------------------------------------------------------------------------
7.       Understanding Algebraic Structures
·       Understanding Algebraic Structures
·       Introduction to abstract algebraic structures
·       Semigroup
·       Monoid
·       Foldable
·       Group


///Algebraic Data Types (ADT)
Algebraic data types (ADTs) are way of representing data using "ands" and "ors".
  a shape is a rectangle or a circle - 'or' represented via sealed trait , a Coproduct or Sum 
  a rectangle has a width and a height - 'and' represnted by case class , a Product 
  a circle has a radius
  
When sealed trait takes type parameter, it is GADT (Generalized ADT)
//eg below is GADT 

sealed trait Optional[+T] {                         //a Coproduct or Sum
   //Pattern matching is the way to handle ADT 
   def isDefined: Boolean = this match
      case Nn => false
      case _    => true
}
case class Sm[T](x:T) extends Optional[T]           //a Product 
case object Nn extends Optional[Nothing]

object Optional{
   def apply[T >: Null](x: T): Optional[T] =
      if x == null then Nn else Sm(x)
   //smart constructors 
   def sm[T](x:T):Optional[T] = Some(x)
   def nn:Optional[Nothing]  = Nn
}

List(Optional.sm(2), Optional.sm(3), Optional.nn)


///Algebraic data types(ADT) using Shapeless 
libraryDependencies += "com.chuusai" %% "shapeless" % "2.3.3"

Doc 
https://underscore.io/books/shapeless-guide/

//Example 
sealed trait Shape
final case class Rectangle(width: Double, height: Double) extends Shape
final case class Circle(radius: Double) extends Shape

val rect: Shape = Rectangle(3.0, 4.0)
val circ: Shape = Circle(1.0)

The advantages of ADTs is that they are completely type safe. 
The compiler has complete knowledge of the algebras we define

def area(shape: Shape): Double =
  shape match {
    case Rectangle(w, h) => w * h
    case Circle(r)       => math.Pi * r * r
  }

area(rect)
// res1: Double = 12.0

area(circ)
// res2: Double = 3.141592653589793

//Alternative encodings
type Rectangle2 = (Double, Double)
type Circle2    = Double
type Shape2     = Either[Rectangle2, Circle2]

val rect2: Shape2 = Left((3.0, 4.0))
val circ2: Shape2 = Right(1.0)

def area2(shape: Shape2): Double =
  shape match {
    case Left((w, h)) => w * h
    case Right(r)     => math.Pi * r * r
  }

area2(rect2)
// res4: Double = 12.0

area2(circ2)
// res5: Double = 3.141592653589793

///Shapeless Generic 

//Generic Product encodings using shapeless.HList - tuple with more than 22 
An HList is either the empty list HNil, or a pair ::[H, T] where H is an arbitrary type 
and T is another HList. 

import shapeless._

val product: String :: Int :: Boolean :: HNil =  "Sunday" :: 1 :: false :: HNil

//Many List methods are applicable 
val first = product.head
// first: String = Sunday

val second = product.tail.head
// second: Int = 1

val rest = product.tail.tail
// rest: Boolean :: shapeless.HNil = false :: HNil

The compiler knows the exact length of each HList, so it becomes a compilation error 
to take the head or tail of an empty list:

product.tail.tail.tail.head
// <console>:15: error: could not find implicit value for parameter c: shapeless.ops.hlist.IsHCons[shapeless.HNil]
//        product.tail.tail.tail.head
//                               ^


///Shapeless Product - Generic 
Shapeless provides a type class called Generic that allows us to switch back 
and forth between a concrete ADT and its generic representation, using HList 
This way Product can be generically manipulated 


import shapeless._

case class IceCream(name: String, numCherries: Int, inCone: Boolean)

val iceCreamGen = Generic[IceCream]
// iceCreamGen: shapeless.Generic[IceCream]{type Repr = String :: Int :: Boolean :: shapeless.HNil} = anon$macro$4$1@6b9323fe


val iceCream = IceCream("Sundae", 1, false)
// iceCream: IceCream = IceCream(Sundae,1,false)

val repr = iceCreamGen.to(iceCream)
// repr: iceCreamGen.Repr = Sundae :: 1 :: false :: HNil

val iceCream2 = iceCreamGen.from(repr)
// iceCream2: IceCream = IceCream(Sundae,1,false)

If two ADTs have the same Repr, we can convert back and forth between them 
using their Generics:

case class Employee(name: String, number: Int, manager: Boolean)

// Create an employee from an ice cream:
val employee = Generic[Employee].from(Generic[IceCream].to(iceCream))
// employee: Employee = Employee(Sundae,1,false)

//Scala tuples are actually case classes, 

val tupleGen = Generic[(String, Int, Boolean)]

tupleGen.to(("Hello", 123, true))
// res4: tupleGen.Repr = Hello :: 123 :: true :: HNil

tupleGen.from("Hello" :: 123 :: true :: HNil)
// res5: (String, Int, Boolean) = (Hello,123,true)

It also works with case classes of more than 22 fields:

case class BigData(
  a:Int,b:Int,c:Int,d:Int,e:Int,f:Int,g:Int,h:Int,i:Int,j:Int,
  k:Int,l:Int,m:Int,n:Int,o:Int,p:Int,q:Int,r:Int,s:Int,t:Int,
  u:Int,v:Int,w:Int)

Generic[BigData].from(Generic[BigData].to(BigData(
  1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23)))
// res6: BigData = BigData(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23)

Shapeless provide implicits for tuples, so that you can use HList methods on tuples.

import shapeless.syntax.std.tuple._
(1, "foo", 12.3).tail // returns (foo,12.3)

///Algebric Type class -  Semigroup
Many Datatypes can be abstracted by algebric structure 
which helps us in finding the commonality of them and write generic code for them 
Few examples are - List is monoid , Map is monoid and then can be operated 
with same syntax/functionality of Monoid 

Semigroup is fully defined by two qualities:
    It is defined for some (possibly infinite) set of elements
    It has a binary operation defined for any pairs of elements in this set
    
Example of Semigroups are Int, Double where op can be + 

trait Semigroup[S] {
  def combine(l: S, r: S): S
}
//Example using cats 
Cats use |+| for combine , has many implicits 
//https://github.com/typelevel/cats/blob/main/kernel/src/main/scala/cats/kernel/Semigroup.scala
eg Int, List Maps are examples of Semigroups 

import cats.implicits._

1 |+| 2
// res4: Int = 3

val map1 = Map("hello" -> 1, "world" -> 1)
val map2 = Map("hello" -> 2, "cats"  -> 3)

map1 |+| map2
// res6: Map[String, Int] = Map("hello" -> 3, "cats" -> 3, "world" -> 1)

//Complex combine 
def optionCombine[A: Semigroup](a: A, opt: Option[A]): A =
  opt.map(a |+| _).getOrElse(a)

def mergeMap[K, V: Semigroup](lhs: Map[K, V], rhs: Map[K, V]): Map[K, V] =
  lhs.foldLeft(rhs) {
    case (acc, (k, v)) => acc.updated(k, optionCombine(v, acc.get(k)))
  }

val xm1 = Map('a' -> 1, 'b' -> 2)
// xm1: Map[Char, Int] = Map('a' -> 1, 'b' -> 2)
val xm2 = Map('b' -> 3, 'c' -> 4)
// xm2: Map[Char, Int] = Map('b' -> 3, 'c' -> 4)

val x = mergeMap(xm1, xm2)
// x: Map[Char, Int] = Map('b' -> 5, 'c' -> 4, 'a' -> 1)

val ym1 = Map(1 -> List("hello"))
// ym1: Map[Int, List[String]] = Map(1 -> List("hello"))
val ym2 = Map(2 -> List("cats"), 1 -> List("world"))
// ym2: Map[Int, List[String]] = Map(2 -> List("cats"), 1 -> List("world"))

val y = mergeMap(ym1, ym2)
// y: Map[Int, List[String]] = Map(
//   2 -> List("cats"),
//   1 -> List("hello", "world")
// )

///SemiGroup - property 
It also has the following two properties:
    The operation is closed, which means that the result of the operation belongs to
    the same set as its operands

    The operation is associative, meaning that multiple operations should produce
    the same result, regardless of the order in which they are applied

///SemiGroup Example - from scratch 
final case class Fish(volume: Int, weight: Int, teeth: Int, poisonousness: Int) {
  def eat(f: Fish): Fish = Fish(volume + f.volume, weight + f.weight, teeth + f.teeth, poisonousness + f.poisonousness)
}

trait Semigroup[S] {
  def combine(l: S, r: S): S
}

object Semigroup {
  //SAM 
  implicit val volumeSemigroup: Semigroup[Fish] = (l: Fish, r: Fish) =>
    if (l.volume > r.volume) l.eat(r) else r.eat(l)

  implicit val weightSemigroup: Semigroup[Fish] = (l: Fish, r: Fish) =>
    if (l.weight > r.weight) l.eat(r) else r.eat(l)

  implicit val poisonSemigroup: Semigroup[Fish] = (l: Fish, r: Fish) =>
    if (l.poisonousness > r.poisonousness) l else r

  implicit val teethSemigroup: Semigroup[Fish] = (l: Fish, r: Fish) =>
    if (l.teeth > r.teeth) l else r  
}

//Check Properties 
import org.scalacheck._
import org.scalacheck.Prop._

object SemigroupSpecification extends Properties("Semigroup") {

  def associativity[S : Semigroup : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Semigroup[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })

  val fishGen: Gen[Fish] = for {
    weight <- Gen.posNum[Int]
    volume <- Gen.posNum[Int]
    poisonousness <- Gen.posNum[Int]
    teeth <- Gen.posNum[Int]
  } yield Fish(volume, weight, teeth, poisonousness)

  implicit val arbFish: Arbitrary[Fish] = Arbitrary(fishGen)

  property("associativity for fish semigroup under 'big eats little'") = {
    import Semigroup.volumeSemigroup
    associativity[Fish]
  }

  property("associativity for fish semigroup under 'heavy eats light'") = {
    import Semigroup.weightSemigroup
    associativity[Fish]
  }

  property("associativity for fish semigroup under 'poisonous drives away others'") = {
    import Semigroup.poisonSemigroup
    associativity[Fish]
  }
  property("associativity for fish semigroup under 'teeth FTW'") = {
    import Semigroup.teethSemigroup
    associativity[Fish]
  }
}
SemigroupSpecification.check()

///SemiGroup With Cats - Testing properties of Custom class 
Semigroup[A]
    combineN(a: A, n: Int): A 
        Return `a` combined with itself `n` times.
    combineAllOption(as: IterableOnce[A]): Option[A]
        Given a sequence of `as`, combine them and return the total.
    reverse: Semigroup[A]    
        return a semigroup that reverses the order
        so combine(a, b) == reverse.combine(b, a)
    intercalate(middle: A): Semigroup[A]
        Between each pair of elements insert middle
        ie def combine(a: A, b: A): A = self.combine(a, self.combine(middle, b))
        
object Semigroup
    def combine[A](x: A, y: A)(implicit ev: S[A]): A 
    def maybeCombine[A](ox: Option[A], y: A)(implicit ev: S[A]): A =
    def maybeCombine[A](x: A, oy: Option[A])(implicit ev: S[A]): A =
    def isCommutative[A](implicit ev: S[A]): Boolean 
    def isIdempotent[A](implicit ev: S[A]): Boolean 
    def combineN[A](a: A, n: Int)(implicit ev: S[A]): A 
    def combineAllOption[A](as: IterableOnce[A])(implicit ev: S[A]): Option[A] 

    def apply[A](implicit ev: Semigroup[A]): Semigroup[A] 
    def instance[A](cmb: (A, A) => A): Semigroup[A] 
    
    def first[A]: Semigroup[A]
        Create a `Semigroup` instance that always returns the lefthand side.
        ie def combine(x: A, y: A): A = x
    def last[A]: Semigroup[A] 


//Example  
import cats._ 
import cats.implicits._ 

final case class Fish(volume: Int, weight: Int, teeth: Int, poisonousness: Int) {
  def eat(f: Fish): Fish = Fish(volume + f.volume, weight + f.weight, teeth + f.teeth, poisonousness + f.poisonousness)
}

//instance[A](cmb: (A, A) => A): Semigroup[A] 
implicit val volumeSemigroup:Semigroup[Fish] = Semigroup.instance{ (l,r) =>
    if (l.weight > r.weight) l.eat(r) else r.eat(l)
}

import org.scalacheck._
import org.scalacheck.Prop._

def associativity[S : Semigroup : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Semigroup[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })

val fishGen: Gen[Fish] = for {
    weight <- Gen.posNum[Int]
    volume <- Gen.posNum[Int]
    poisonousness <- Gen.posNum[Int]
    teeth <- Gen.posNum[Int]
} yield Fish(volume, weight, teeth, poisonousness)

implicit val arbFish: Arbitrary[Fish] = Arbitrary(fishGen)

associativity[Fish].check 

type Bucket[S] = List[S]
val bucketOfFishGen: Gen[List[Fish]] = Gen.listOf(fishGen)
val manyFishes = bucketOfFishGen.sample.get 
Semigroup.combineAllOption(manyFishes) //OK as Semigroup[Fish] available


///Algebric Type class  - Monoid
A monoid is a semigroup with an identity element. 
Formally, the identity element z is an element for which an equation, 
z + x = x + z = x, holds for any x. 

trait Monoid[S] extends Semigroup[S] {
 def empty: S  //Identity 
}

//Example usage: Collapsing a list - not possible with SemiGroup as Identity is missing 
def combineAll[A: Semigroup](as: List[A]): A =
  as.foldLeft(/* ?? what goes here ?? */)(_ |+| _)

//With Monoid 
def combineAll[A: Monoid](as: List[A]): A =
  as.foldLeft(Monoid[A].empty)(Monoid[A].combine)
  
This function is provided in Cats as Monoid.combineAll.
https://github.com/typelevel/cats/blob/main/kernel/src/main/scala/cats/kernel/Monoid.scala


Has many default implicits (whereever Zero is possible)

import cats.Monoid
import cats.implicits._

Monoid.combineAll(List(1, 2, 3))
// res3: Int = 6

Monoid.combineAll(List("hello", " ", "world"))
// res4: String = "hello world"

Monoid.combineAll(List(Map('a' -> 1), Map('a' -> 2, 'b' -> 3), Map('b' -> 4, 'c' -> 5)))
// res5: Map[Char, Int] = Map('b' -> 7, 'c' -> 5, 'a' -> 3)

Monoid.combineAll(List(Set(1, 2), Set(2, 3, 4, 5)))
// res6: Set[Int] = Set(5, 1, 2, 3, 4)

///Semigroup but not Monoid 
There are some types that can form a Semigroup but not a Monoid. 

For example, the following NonEmptyList type forms a semigroup through ++, 
but has no corresponding identity element to form a monoid.

import cats.Semigroup

final case class NonEmptyList[A](head: A, tail: List[A]) {
  def ++(other: NonEmptyList[A]): NonEmptyList[A] = NonEmptyList(head, tail ++ other.toList)
  def toList: List[A] = head :: tail
}

object NonEmptyList {
  implicit def nonEmptyListSemigroup[A]: Semigroup[NonEmptyList[A]] =
    new Semigroup[NonEmptyList[A]] {
      def combine(x: NonEmptyList[A], y: NonEmptyList[A]): NonEmptyList[A] = x ++ y
    }
}

How then can we collapse a List[NonEmptyList[A]] ? 
For such types that only have a Semigroup we can lift into Option to get a Monoid.

import cats.implicits._

implicit def optionMonoid[A: Semigroup]: Monoid[Option[A]] = new Monoid[Option[A]] {
  def empty: Option[A] = None

  def combine(x: Option[A], y: Option[A]): Option[A] =
    x match {
      case None => y
      case Some(xv) =>
        y match {
          case None => x
          case Some(yv) => Some(xv |+| yv)
        }
    }
}
//Then usage 
import cats.Monoid
import cats.data.NonEmptyList //cats already has NonEmptyList
import cats.implicits._

val list = List(NonEmptyList(1, List(2, 3)), NonEmptyList(4, List(5, 6)))
val lifted = list.map(nel => Option(nel))

Monoid.combineAll(lifted)
// res8: Option[NonEmptyList[Int]] = Some(NonEmptyList(1, List(2, 3, 4, 5, 6)))


///Monoid - Properties 
def associativity[S : Monoid : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Monoid[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
    
def identity[S : Monoid : Arbitrary]: Prop =
 forAll((a: S) => {
    val m = implicitly[Monoid[S]]
     m.combine(a, m.empty) == a && m.combine(m.empty, a) == a
  })

def monoidProp[S : Monoid : Arbitrary]: Prop = associativity[S] &&  identity[S]

///Monoid - Properties from Cats 
trait Monoid[A] extends Any with Semigroup[A] 
  def empty: A
  
  def isEmpty(a: A)(implicit ev: Eq[A]): Boolean 
  def combineN(a: A, n: Int): A 
  def combineAll(as: IterableOnce[A]): A 
  def combineAllOption(as: IterableOnce[A]): Option[A] 
  def reverse: Monoid[A] 


object Monoid 
  def empty[A](implicit ev: M[A]): A =
  def isEmpty[A](a: A)(implicit m: M[A], ev: Eq[A]): Boolean 
  def combineAll[A](as: IterableOnce[A])(implicit ev: M[A]): A 
  
  final def apply[A](implicit ev: Monoid[A]): Monoid[A] 
  def instance[A](emptyValue: A, cmb: (A, A) => A): Monoid[A] 


  
//Usage 
import cats._ 
import cats.implicits._ 

final case class Fish(volume: Int, weight: Int, teeth: Int, poisonousness: Int) {
  def eat(f: Fish): Fish = Fish(volume + f.volume, weight + f.weight, teeth + f.teeth, poisonousness + f.poisonousness)
}
type Bucket[S] = List[S]

import org.scalacheck._
import org.scalacheck.Prop._

//Create Generators 
val fishGen: Gen[Fish] = for {
    weight <- Gen.posNum[Int]
    volume <- Gen.posNum[Int]
    poisonousness <- Gen.posNum[Int]
    teeth <- Gen.posNum[Int]
} yield Fish(volume, weight, teeth, poisonousness)

val bucketOfFishGen: Gen[List[Fish]] = Gen.listOf(fishGen)
implicit val arbFish: Arbitrary[Fish] = Arbitrary(fishGen)
implicit val arbBucketOfFish: Arbitrary[Bucket[Fish]] = Arbitrary(bucketOfFishGen)


//Test props 
def associativity[S : Monoid : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Monoid[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
def identity[S : Monoid : Arbitrary]: Prop =
  forAll((a: S) => {
    val m = implicitly[Monoid[S]]
    m.combine(a, m.empty) == a && m.combine(m.empty, a) == a
  })

def monoidProp[S : Monoid : Arbitrary]: Prop = associativity[S] &&  identity[S]

//Create implicits 
val ZeroFish = Fish(0,0,0,0)


implicit val volumeMonoid: Monoid[Fish] = Monoid.instance(ZeroFish, (l,r) =>
    if (l.weight > r.weight) l.eat(r) else r.eat(l)
)
implicit def surviveInTheBucket(implicit m: Monoid[Fish]): Monoid[Bucket[Fish]] = 
    Monoid.instance(List.fill(100)(ZeroFish), 
    (l,r) => { //(l: Bucket[Fish], r: Bucket[Fish])
        val operation = (m.combine _).tupled
        l zip r map operation
    }
  )

 
monoidProp[Bucket[Fish]].check 

val manyFishes = bucketOfFishGen.sample.get 
Monoid.combineAllOption(manyFishes)

//OR using Syntax 
def addAll[A:Monoid](values: List[A]): A =
    values.foldLeft(Monoid[A].empty)(_ |+| _)
    
//OR 
def addAll[A](values: List[A])(implicit monoid: Monoid[A]): A =
    values.foldLeft(monoid.empty)(_ |+| _)

addAll(manyFishes)

//scala3 
import cats.*
import cats.given

final case class Fish(volume: Int, weight: Int, teeth: Int, poisonousness: Int) {
  def eat(f: Fish): Fish = Fish(volume + f.volume, weight + f.weight, teeth + f.teeth, poisonousness + f.poisonousness)
}
type Bucket[S] = List[S]

import org.scalacheck.*
import org.scalacheck.Prop.*

//Create Generators 
val fishGen: Gen[Fish] = for {
    weight <- Gen.posNum[Int]
    volume <- Gen.posNum[Int]
    poisonousness <- Gen.posNum[Int]
    teeth <- Gen.posNum[Int]
} yield Fish(volume, weight, teeth, poisonousness)

val bucketOfFishGen: Gen[List[Fish]] = Gen.listOf(fishGen)
given arbFish: Arbitrary[Fish] = Arbitrary(fishGen)
given arbBucketOfFish: Arbitrary[Bucket[Fish]] = Arbitrary(bucketOfFishGen)


//Test props 
def associativity[S : Monoid : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = summon[Monoid[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
def identity[S : Monoid : Arbitrary]: Prop =
  forAll((a: S) => {
    val m = summon[Monoid[S]]
    m.combine(a, m.empty) == a && m.combine(m.empty, a) == a
  })

def monoidProp[S : Monoid : Arbitrary]: Prop = associativity[S] &&  identity[S]

//Create implicits 
val ZeroFish = Fish(0,0,0,0)


given volumeMonoid: Monoid[Fish] = Monoid.instance(ZeroFish, (l,r) =>
    if (l.weight > r.weight) l.eat(r) else r.eat(l)
)
given surviveInTheBucket(using m: Monoid[Fish]): Monoid[Bucket[Fish]] = 
    Monoid.instance(List.fill(100)(ZeroFish), 
    (l,r) => { //(l: Bucket[Fish], r: Bucket[Fish])
        val operation = (m.combine _).tupled
        l zip r map operation
    }
  )

//scala3, give ()
monoidProp[Bucket[Fish]].check() 

val manyFishes = bucketOfFishGen.sample.get 
Monoid.combineAllOption(manyFishes)

//OR using Syntax 
import cats.syntax.all.*
def addAll[A:Monoid](values: List[A]): A =
    values.foldLeft(Monoid[A].empty)(_ |+| _)
    
//OR 
def addAll[A](values: List[A])(using monoid: Monoid[A]): A =
    values.foldLeft(monoid.empty)(_ |+| _)

addAll(manyFishes)


///Quick Eval from Cats 
Eval is a data type for controlling synchronous evaluation. 

//Eval.now - eager evaluation 
import cats.Eval
import cats.implicits._


val eager = Eval.now {
  println("Running expensive calculation...")
  1 + 2 * 3
}
// Running expensive calculation...
// eager: Eval[Int] = Now(7)

//Then get the value 
eager.value
// res0: Int = 7

//Eval.later- lazy evaluation, with memoization, like lazy val 
val lazyEval = Eval.later {
  println("Running expensive calculation...")
  1 + 2 * 3
}
// lazyEval: Eval[Int] = cats.Later@22ea4e3

lazyEval.value
// Running expensive calculation...
// res1: Int = 7

lazyEval.value
// res2: Int = 7

//Eval.always - lazy evaluation without memoization eg like Function0
val always = Eval.always {
  println("Running expensive calculation...")
  1 + 2 * 3
}
// always: Eval[Int] = cats.Always@29e3bb1b

always.value
// Running expensive calculation...
// res3: Int = 7

always.value
// Running expensive calculation...
// res4: Int = 7


///Algebric Type class - Foldable
Foldable type class instances can be defined for data structures 
that can be folded to a summary value.

Similar concept for Monoid(with Monoid.empty) is Reducible 
trait Reducible[A] {
    def reduceLeft(op: (A, A) => A): A
    def reduceRight(op: (A, A) => A): A
}

Foldable approach allows us to use any structure, not only monoids, for folding. 

trait Foldable[F[_]] {
 def foldLeft[A,B](as: F[A])(z: B)(f: (B, A) => B): B
 def foldRight[A,B](as: F[A])(z: B)(f: (A, B) => B): B

  //Derived  - map and then fold   
  def foldMap[A,B : Monoid](as: F[A])(f: A => B): B = {
      val m = implicitly[Monoid[B]]
      foldLeft(as)(m.empty)((b, a) => m.combine(f(a), b))
  }
  
}


///Foldable from cats 
Note that, in order to support laziness(right could be big), the signature of Foldable’s foldRight uses Eval[B]

trait Foldable[F[_]] {
    def foldLeft[A, B](fa: F[A], b: B)(f: (B, A) => B): B
    def foldRight[A, B](fa: F[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B]
    
    //many concrete implementation 
    //https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/Foldable.scala
    def fold[A](fa: F[A])(implicit A: Monoid[A]): A =  A.combineAll(toIterable(fa))
}

//Example 
import cats._
import cats.implicits._ 

//def fold[A](fa: F[A])(implicit A: Monoid[A]): A 
Foldable[List].fold(List("a", "b", "c"))
// res0: String = "abc"

//def foldMap[A, B](fa: F[A])(f: A => B)(implicit B: Monoid[B]): B =
Foldable[List].foldMap(List(1, 2, 4))(_.toString)
// res1: String = "124"

Foldable[List].find(List(1,2,3))(_ > 2)
// res7: Option[Int] = Some(3)
Foldable[List].exists(List(1,2,3))(_ > 2)
// res8: Boolean = true
Foldable[List].forall(List(1,2,3))(_ > 2)
// res9: Boolean = false
Foldable[List].forall(List(1,2,3))(_ < 4)
// res10: Boolean = true

Foldable[List].isEmpty(List(1,2))
// res12: Boolean = false
Foldable[Option].isEmpty(None)
// res13: Boolean = true
Foldable[List].nonEmpty(List(1,2))
// res14: Boolean = true

val allFalse = Stream.continually(false)
// allFalse: Stream[Boolean] = Stream(
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
// ...

which is an infinite stream of false values, 
and if you wanted to reduce this to a single false value using the logical and (&&).
 
You intuitively know that the result of this operation should be false. 
It is not necessary to consider the entire stream in order to determine this result, 
you only need to consider the first value. 

Using foldRight from the standard library will try to consider the entire stream, 
and thus will eventually cause a stack overflow:

try {
  allFalse.foldRight(true)(_ && _)
} catch {
  case e:StackOverflowError => println(e)
}
// java.lang.StackOverflowError
// res29: AnyVal = ()

With the lazy foldRight on Foldable, the calculation terminates 
after looking at only one value:

//def foldRight[A, B](fa: F[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B]
Foldable[Stream].foldRight(allFalse, Eval.True)((a,b) => if (a) b else Eval.False).value
// res30: Boolean = false


///Group: Monoid with Inverse
Abstract algebraic structures do not end with monoids. 
In fact, there are a lot of more advanced definitions out there like the
group, abelian group(commutative group), and ring(with two ops)
  
//Ie Group contains all below 
trait Group[A] {
  def empty: A // identity
  def inverse(a: A): A
  def combine(a: A, b: A): A
}

///Group - Checking Props 
trait Semigroup[A] {
  def combine(l: A, r: A): A
}
trait Monoid[A] extends Semigroup[A] {
 def empty: A  //Identity 
}

trait Group[A] extends Monoid[A]{
  def inverse(a: A): A
}

import org.scalacheck._
import org.scalacheck.Prop._

def associativity[S : Semigroup : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Semigroup[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
    
def identity[S : Monoid : Arbitrary]: Prop =
 forAll((a: S) => {
    val m = implicitly[Monoid[S]]
     m.combine(a, m.empty) == a && m.combine(m.empty, a) == a
  })

def monoidProp[S : Monoid : Arbitrary]: Prop = associativity[S] &&  identity[S]


def invertibility[S : Group : Arbitrary]: Prop =
  forAll((a: S) => {
    val m = implicitly[Group[S]]
     m.combine(a, m.inverse(a)) == m.empty && m.combine(m.inverse(a), a) ==   m.empty
  })
  
def groupProp[S : Group: Arbitrary]: Prop = monoidProp[S] && invertibility[S]

//For abelian group 
def commutativity[S : Group : Arbitrary]: Prop =
  forAll((a: S, b: S) => {
    val m = implicitly[Group[S]]
     m.combine(a, b) == m.combine(b, a)
  })

def abelianGroupProp[S : Group: Arbitrary]: Prop =    groupProp[S] && commutativity[S]


One example of the abelian group is integer under addition. 

implicit val intAddition: Group[Int] = new Group[Int] {
 override def empty: Int = 0
 override def combine(l: Int, r: Int): Int = l + r
 override def inverse(a: Int): Int = empty - a
}

//Usage 
abelianGroupProp[Int].check 


///Group from cats 
trait Group[A] extends Any with Monoid[A] 
  def inverse(a: A): A

  def remove(a: A, b: A): A 
  override def combineN(a: A, n: Int): A 
 
object Group 
    def inverse[@sp(Int, Long, Float, Double) A](a: A)(implicit ev: G[A]): A 
    def remove[@sp(Int, Long, Float, Double) A](x: A, y: A)(implicit ev: G[A]): A 
    
    def apply[A](implicit ev: Group[A]): Group[A] = ev
    
//from cats 
import cats._
import cats.implicits._ 

Cats provides instances out of the box for various numerical types. 
(Int, Long, Float, Double)
//https://github.com/typelevel/cats/blob/main/kernel/src/main/scala/cats/kernel/Group.scala

Group[Int].inverse(1)
//res0: Int = -1

Group[Int].remove(10, 1)
//res1: Int = 9

10 |-| 1
//res2: Int = 9

3 |+| 2 |-| 2
//res3: Int = 3



////--------------Dealing with Effects---------------------------------------------------------------------------------------------
8.       Dealing with Effects
·       Dealing with Effects
·       Functor
·       Applicative
·       Traversable

///Functor 
Understand that in Functor/Applicative/Monad(LHS is subclass of RHS)  , 
inside function,f  we get a, ie F[_] is peeled off 

Functor[F[_]].map[A,B](in: F[A])(f: A => B): F[B]
Applicative[F[_]].ap[A,B](f: F[A => B])(in: F[A]): F[B]
Monad[F[_]].flatMap[A,B](in: F[A])(f: A => F[B]): F[B]

import cats._
import cats.implicits._

Functor[Option].map(Option(2))( (x:Int) => x + 1)
Applicative[Option].ap( Option( (x:Int) => x + 1))(Option(2))
Monad[Option].flatMap(Option(2))( (x:Int) => Option(x + 1))


Informally, a functor is anything with a map method. 
Map is to get To transform the inner value 
Functor, Applicative, Traversable can be composed - Most powerfull 

List(1, 2, 3).map(n => n + 1)
// res0: List[Int] = List(2, 3, 4)

//For Example 
List[A]                 A => B              List[B]
Option[A]               A => B              Option[B]
Either[E, A]            A => B              Either[E, B]
Future[A]               A => B              Future[B]

//Definition 
F[_] is a type constructor for the container. 

import scala.language.higherKinds
trait Functor[F[_]] {
  def map[A,B](in: F[A])(f: A => B): F[B]
}

We could also define the map slightly differently, in a curried form, mapC

trait Functor[F[_]] {
  def map[A,B](in: F[A])(f: A => B): F[B]
  def mapC[A,B](f: A => B): F[A] => F[B] = fa => map(fa)(f)
}

//Functor Laws
Functors guarantee the same semantics whether we sequence many small operations 
one by one, or combine them into a larger function before mapping. 

To ensure this is the case the following laws must hold:
    Identity
    calling map with the identity function is the same as doing nothing:
      fa.map(a => a) == fa

    Composition/associativity
    mapping with two functions f and g is the same as mapping with f 
    and then mapping with g:
      fa.map(g(f(_))) == fa.map(f).map(g)


In Scalacheck Props 

import org.scalacheck._
import org.scalacheck.Prop._

def identity[A](x: A): A = x

def id[A, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]]): Prop =
    forAll { as: F[A] => F.map(as)(identity) == as }

//(CoGen is required for argument of Function )
def associativity[A, B, C, F[_]](implicit F: Functor[F],
                                  arbFA: Arbitrary[F[A]],
                                  arbB: Arbitrary[B],
                                  arbC: Arbitrary[C],
                                  cogenA: Cogen[A], //for f:A =>B
                                  cogenB: Cogen[B]): Prop = { //for g:B => C
  forAll((as: F[A], f: A => B, g: B => C) => {
     F.map(F.map(as)(f))(g) == F.map(as)(f andThen g)
  })
}

def functor[A, B, C, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],
                         cogenB: Cogen[B]): Prop =
    id[A, F] && associativity[A, B, C, F]

///Functor - Some of the implementations
import scala.util._ 
 
//for option 
implicit val optionFunctor: Functor[Option] = new Functor[Option] {
    override def map[A, B](in: Option[A])(f: A => B): Option[B] = in.map(f)
    override def mapC[A, B](f: A => B): Option[A] => Option[B] = (_: Option[A]).map(f)
}
//OR 
implicit val functorForOption: Functor[Option] = new Functor[Option] {
  def map[A, B](fa: Option[A])(f: A => B): Option[B] = fa match {
    case None    => None
    case Some(a) => Some(f(a))
  }
}
//Other 
implicit val listFunctor: Functor[List] = new Functor[List] {
    override def map[A, B](in: List[A])(f: A => B): List[B] = in.map(f)
    override def mapC[A, B](f: A => B): List[A] => List[B] = (_: List[A]).map(f)
}
//Left is fixed, Right is var - type lambda 
implicit def eitherFunctor[L] = new Functor[({ type T[A] = Either[L, A] })#T] {
    override def map[A, B](in: Either[L, A])(f: A => B): Either[L, B] = in.map(f)
    override def mapC[A, B](f: A => B): Either[L, A] => Either[L, B] = (_: Either[L, A]).map(f)
}

implicit val tryFunctor: Functor[Try] = new Functor[Try] {
    override def map[A, B](in: Try[A])(f: A => B): Try[B] = in.map(f)
    override def mapC[A, B](f: A => B): Try[A] => Try[B] = (_: Try[A]).map(f)
}

eg To test 
property("Functor[Option] and Int => String, String => Long") = {
    functor[Int, String, Long, Option]
}
  
functor[Int, String, Long, Option].check 

//Functor[Option] and String => Int, Int => Boolean"
functor[String, Int, Boolean, Option].check 

type UnitEither[R] = Either[Unit, R]

//Functor[Either] and Int => String, String => Long
functor[Int, String, Long, UnitEither].check 
//Functor[Either] and String => Int, Int => Boolean"
functor[String, Int, Boolean, UnitEither].check 
//Functor[Try] and Int => String, String => Long
functor[Int, String, Long, Try].check 
//"Functor[Try] and String => Int, Int => Boolean
functor[String, Int, Boolean, Try].check 



///Functor - Prop check With Cats 
import cats._ 
import cats.implicits._ 

//Functor[Option] and Int => String, String => Long
functor[Int, String, Long, Option].check 

type UnitEither[R] = Either[Unit, R]
//Functor[Either] and Int => String, String => Long
functor[Int, String, Long, UnitEither].check 


///Props check with  cats-law 
import cats.laws.discipline.FunctorTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
  checkAll("List.FunctorLaws", FunctorTests[List].functor[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests())
TreeLawTests:
- Tree.FunctorLaws.functor.covariant composition
- Tree.FunctorLaws.functor.covariant identity
- Tree.FunctorLaws.functor.invariant composition
- Tree.FunctorLaws.functor.invariant identity



///Functor - Usage from cats 
In Cats, Functors mapC is called lift 

trait Functor[F[_]] {
  def map[A, B](fa: F[A])(f: A => B): F[B]

  def lift[A, B](f: A => B): F[A] => F[B] =
    fa => map(fa)(f)
}
It has few derived functions eg
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/Functor.scala
//Other helpers from cats Functor
//Alias for map, since map can't be injected as syntax if
//the implementing type already had a built-in `.map` method.
final def fmap[A, B](fa: F[A])(f: A => B): F[B] = map(fa)(f)
    //Example 
    val m: Map[Int, String] = Map(1 -> "hi", 2 -> "there", 3 -> "you")
     m.fmap(_ ++ "!")
    // res0: Map[Int,String] = Map(1 -> hi!, 2 -> there!, 3 -> you!)

def widen[A, B >: A](fa: F[A]): F[B] = fa.asInstanceOf[F[B]]
    //Example 
    val s = Some(42)
    Functor[Option].widen(s)
    //res0: Option[Int] = Some(42)

//Lift a function f to operate on Functors
def lift[A, B](f: A => B): F[A] => F[B] = map(_)(f)
    //Example 
    val o = Option(42)
    Functor[Option].lift((x: Int) => x + 10)(o)
    //res0: Option[Int] = Some(52)
    
//Empty the fa of the values, preserving the structure
def void[A](fa: F[A]): F[Unit] = as(fa, ())
    //Example 
    Functor[List].void(List(1,2,3))
    //res0: List[Unit] = List((), (), ())

//Tuple the values in fa with the result of applying a function with the value
def fproduct[A, B](fa: F[A])(f: A => B): F[(A, B)] = map(fa)(a => a -> f(a))
    //Example 
    Functor[Option].fproduct(Option(42))(_.toString)
    //res0: Option[(Int, String)] = Some((42,42))

//Pair the result of function application with `A`.
def fproductLeft[A, B](fa: F[A])(f: A => B): F[(B, A)] = map(fa)(a => f(a) -> a)
    //Example 
    Functor[Option].fproductLeft(Option(42))(_.toString)
    // res0: Option[(String, Int)] = Some((42,42))

//Replaces the `A` value in `F[A]` with the supplied value.
def as[A, B](fa: F[A], b: B): F[B] = map(fa)(_ => b)
    //Example 
    Functor[List].as(List(1,2,3), "hello")
    //res0: List[String] = List(hello, hello, hello)

//Tuples the `A` value in `F[A]` with the supplied `B` value, with the `B` value on the left.
def tupleLeft[A, B](fa: F[A], b: B): F[(B, A)] = map(fa)(a => (b, a))
    //Example 
    Functor[Queue].tupleLeft(Queue("hello", "world"), 42)
    //res0: scala.collection.immutable.Queue[(Int, String)] = Queue((42,hello), (42,world))

//Tuples the `A` value in `F[A]` with the supplied `B` value, with the `B` value on the right.
def tupleRight[A, B](fa: F[A], b: B): F[(A, B)] = map(fa)(a => (a, b))
    //Example 
    Functor[Queue].tupleRight(Queue("hello", "world"), 42)
    //res0: scala.collection.immutable.Queue[(String, Int)] = Queue((hello,42), (world,42))

//Un-zips an `F[(A, B)]` consisting of element pairs or Tuple2 into two separate F's tupled.
def unzip[A, B](fab: F[(A, B)]): (F[A], F[B]) = (map(fab)(_._1), map(fab)(_._2))
    //Example 
    Functor[List].unzip(List((1,2), (3, 4)))
    //(List[Int], List[Int]) = (List(1, 3),List(2, 4))

//Lifts `if` to Functor
def ifF[A](fb: F[Boolean])(ifTrue: => A, ifFalse: => A): F[A] = map(fb)(x => if (x) ifTrue else ifFalse)
    //Example 
    Functor[List].ifF(List(true, false, false))(1, 0)
    //res0: List[Int] = List(1, 0, 0)

Many types have Functor implementions 
check in https://github.com/typelevel/cats/tree/main/core/src/main/scala/cats/instances


//Example 
import cats._ 
import cats.implicits._ 

//check 
implicitly[Functor[List]]

//function compose using Functor 
val func1 = (a: Int) => a + 1
val func2 = (a: Int) => a * 2
val func3 = (a: Int) => s"${a}!"
val func4 = func1.map(func2).map(func3) //nothing but compose 

func4(123)
// res3: String = "248!"

def doMath[F[_]](start: F[Int])(implicit functor: Functor[F]): F[Int] =
 start.map(n => n + 1 * 2)

doMath(Option(20))
// res4: Option[Int] = Some(22)
doMath(List(1, 2, 3))
// res5: List[Int] = List(3, 4, 5)

//Compose 
If you have Option[List[A]] or List[Either[String, Future[A]]] 
and tried to map over it, we do  _.map(_.map(_.map(f))). 
As it turns out, Functors compose, ie if F and G have Functor instances, 
then so does F[G[_]] ie Functor[F].compose[G].map(v)(f)

trait Functor[F[_]] {
    def map[A,B](fa: F[A])(f: A => B): F[B]

    def compose[G[_]: Functor]: Functor[({type f[x]=F[G[x]]})#f] =  {   
        val F = this
        val G = implicitly[Functor[G]]
        new Functor[({type f[x]=F[G[x]]})#f] {
            override def map[A, B](fga: F[G[A]])(f: A => B): F[G[B]] =
                F.map(fga)(ga => G.map(ga)(f))
        }
    }
}

//example 
val optL = Option(List(1,2,3))

optL.map(_.map(_+2))
//OR
Functor[Option].compose[List].map(optL)(_ + 2)
 
val listOption = List(Some(1), None, Some(2))
Functor[List].compose[Option].map(listOption)(_ + 1)
//OR with Nested 
import cats.data.Nested

val nested: Nested[List, Option, Int] = Nested(listOption)
nested.map(_ + 1) // Nested(List(Some(2), None, Some(3)))
nested.map(_ + 1).value

Nested is extremly valuable if we need to pass composed Functor to function 

def needsFunctor[F[_]: Functor, A](fa: F[A]): F[Unit] = Functor[F].map(fa)(_ => ())

def foo: List[Option[Unit]] = {
  val listOptionFunctor = Functor[List].compose[Option]
  type ListOption[A] = List[Option[A]]
  needsFunctor[ListOption, Int](listOption)(listOptionFunctor) 
  //listOptionFunctor is implicit Functor value 
}
//OR 
needsFunctor[({ type T[A] = Nested[List, Option, A] })#T, Int](nested)



//Custom Type 
import cats._ 

sealed trait Tree[+A]

case class Node[A](p: A, left: Tree[A], right: Tree[A]) extends Tree[A]
final case class Leaf[A](value: A) extends Tree[A]
 
object Tree {
    def node[A](p:A, left: Tree[A], right: Tree[A]): Tree[A] =
     Node(p, left, right)
    def leaf[A](value: A): Tree[A] =
     Leaf(value)
     
    implicit val treeFunctor: Functor[Tree] =
      new Functor[Tree] {
          def map[A, B](tree: Tree[A])(func: A => B): Tree[B] =
           tree match {
                case Node(p, left, right) =>
                 node(func(p), map(left)(func), map(right)(func))
                case Leaf(value) =>
                 leaf(func(value))
            }
      }
}

import cats.implicits._
Node(10, Leaf(10), Leaf(20)).map(_ * 2)
// error: value map is not a member of repl.Session.App0.Branch[Int]

Because of Covariant, as Covariant implicit resolution is with specific subtype 
or use smart constructor as we have implicit for base class 

//Use smart-constructor 
Tree.leaf(100).map(_ * 2)
// res9: Tree[Int] = Leaf(200)


Tree.node(10, Tree.leaf(10), Tree.leaf(20)).map(_ * 2)
// res10: Tree[Int] = Branch(Leaf(20), Leaf(40))


///Functor - Custom type testing using cats-law 
import cats.laws.discipline.FunctorTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[Tree[A]] =
    Arbitrary(Gen.oneOf(    
    (for {
      l <- Arbitrary.arbitrary[A]
    } yield Leaf(l)), 
    (for {
      e <- Arbitrary.arbitrary[A]
      l1 <- Arbitrary.arbitrary[A]
      l2 <- Arbitrary.arbitrary[A]
    } yield Node(e, Leaf(l1), Leaf(l2)))
    )
  )
}

class TreeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._ 
 implicit def eqTree[A: Eq]: Eq[Tree[A]] = Eq.fromUniversalEquals
  
  checkAll("Tree.FunctorLaws", FunctorTests[Tree].functor[Int, Int, String])
}

scala> org.scalatest.run(new TreeLawTests())
TreeLawTests:
- Tree.FunctorLaws.functor.covariant composition
- Tree.FunctorLaws.functor.covariant identity
- Tree.FunctorLaws.functor.invariant composition
- Tree.FunctorLaws.functor.invariant identity

Where 
//https://github.com/typelevel/cats/tree/main/laws/src/main/scala/cats/laws/discipline

FunctorTests[F[_]].functor[A: Arbitrary, B: Arbitrary, C: Arbitrary](implicit
    ArbFA: Arbitrary[F[A]],
    CogenA: Cogen[A],
    CogenB: Cogen[B],
    CogenC: Cogen[C],
    EqFA: Eq[F[A]],
    EqFC: Eq[F[C]]
  ): RuleSet 



///Applicative
With functor, we now have a convenient way to apply functions 
to the contents of an effect,regardless of the type of the effect itself.

Applicative extends the original functor with two more methods:
(Applicative is more powerful because Functor can be implemented by that)

    The unit/pure method allows us to wrap a plain value, a, into the effect ie F[A] 
    This is often called lifting, as it "lifts" the original value 
    into the context of the effect, F.

    The apply method takes an effect, a, and a function, f, defined 
    in the context of the same effect F and applies f to a, 
    thus returning the result that wrapped in the very same effect, F

//definition 
trait Applicative[F[_]] extends Functor[F] {
  def apply[A, B](ff: F[A => B])(fa: F[A]): F[B] //ie in cats called ap[A,B]
  def pure[A](a: A): F[A]  //ie unit[A] 
  //from Functor but overridden 
  override def map[A,B](f: A => B)(fa: F[A]): F[B] =  
    apply(pure(f))(fa)
}


There are a few laws:
    1. Identity law states that an application of an identity function 
       should return the  argument unchanged, 
       the same way the identity function does. This is similar to
       the identity law for the functor, but this time defined for 
       the apply function.
       
    2. Homomorphism law states that applying a function to a value 
       and then lifting the result is the same as first lifting this function 
       and value and then applying them in the context of the applicative.
       
    3. Interchange law states that changing the order of the parameters 
       for the apply method should not change the result.
       
    4. Composition law states that function composition should be preserved.
    
//in scalacheck and cats (exit and import below - getting Functor etc from cats )
import cats._ 
import cats.implicits._ 

import org.scalacheck.Prop._
import org.scalacheck._

//Functors 
def identity[A](x: A): A = x

def id[A, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]]): Prop =
    forAll { as: F[A] => F.map(as)(identity) == as }

//(CoGen is required for argument of Function )
def associativity[A, B, C, F[_]](implicit F: Functor[F],
                                  arbFA: Arbitrary[F[A]],
                                  arbB: Arbitrary[B],
                                  arbC: Arbitrary[C],
                                  cogenA: Cogen[A],
                                  cogenB: Cogen[B]): Prop = {
  forAll((as: F[A], f: A => B, g: B => C) => {
     F.map(F.map(as)(f))(g) == F.map(as)(f andThen g)
  })
}

def functor[A, B, C, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],
                         cogenB: Cogen[B]): Prop =
    id[A, F] && associativity[A, B, C, F]
    
//Applicatves 
def identityProp[A, F[_]](implicit A: Applicative[F],
                          arbFA: Arbitrary[F[A]]): Prop =
  forAll { as: F[A] =>
    A.ap(A.pure((a: A) => a))(as) == as
  }

def homomorphism[A, B, F[_]](implicit A: Applicative[F],
                             arbA: Arbitrary[A],
                             arbB: Arbitrary[B],
                             cogenA: Cogen[A]): Prop = {
  forAll((f: A => B, a: A) => {
    A.ap(A.pure(f))(A.pure(a)) == A.pure(f(a))
  })
}

def interchange[A, B, F[_]](implicit A: Applicative[F],
                            arbFA: Arbitrary[F[A]],
                            arbA: Arbitrary[A],
                            arbB: Arbitrary[B],
                            cogenA: Cogen[A]): Prop = {
  forAll((f: A => B, a: A) => {
    val leftSide = A.ap(A.pure(f))(A.pure(a))
    val func = (ff: A => B) => ff(a)
    val rightSide = A.ap(A.pure(func))(A.pure(f))
    leftSide == rightSide
  })
}

def composeF[A, B, C]: (B => C) => (A => B) => (A => C) = _.compose

def composition[A, B, C, F[_]](implicit A: Applicative[F],
                               arbFA: Arbitrary[F[A]],
                               arbB: Arbitrary[B],
                               arbC: Arbitrary[C],
                               cogenA: Cogen[A],
                               cogenB: Cogen[B]): Prop = {
  forAll((as: F[A], f: A => B, g: B => C) => {
    val af: F[A => B] = A.pure(f)
    val ag: F[B => C] = A.pure(g)
    val ac: F[(B => C) => (A => B) => (A => C)] = A.pure(composeF)
    val leftSide = A.ap(A.ap(A.ap(ac)(ag))(af))(as)
    val rightSide = A.ap(ag)(A.ap(af)(as))

    leftSide == rightSide
  })
}

def applicative[A, B, C, F[_]](implicit fu: Applicative[F],
                               arbFA: Arbitrary[F[A]],
                               arbA: Arbitrary[A],
                               arbB: Arbitrary[B],
                               arbC: Arbitrary[C],
                               cogenA: Cogen[A],
                               cogenB: Cogen[B]): Prop = {
  identityProp[A, F] && homomorphism[A, B, F] &&
    interchange[A, B, F] && composition[A, B, C, F] &&
    functor[A, B, C, F] //old testing 
}
//Testing 
//Applicative[Option] and Int => String, String => Long
applicative[Int, String, Long, Option].check 

//Applicative[Option] and String => Int, Int => Boolean
applicative[String, Int, Boolean, Option].check 

//Applicative[Try] and Int => String, String => Long
applicative[Int, String, Long, Try].check 
//Applicative[Try] and String => Int, Int => Boolean
applicative[String, Int, Boolean, Try].check 

type UnitEither[R] = Either[Unit, R]
//Applicative[Either] and Int => String, String => Long
applicative[Int, String, Long, UnitEither].check 
//Applicative[Either] and String => Int, Int => Boolean
applicative[String, Int, Boolean, UnitEither].check 
//Applicative[List] and Int => String, String => Long
applicative[Int, String, Long, List].check 
//Applicative[List] and String => Int, Int => Boolean
applicative[String, Int, Boolean, List].check 


///Any Implementation can not be Applicative  - it must obey Applicative law 

import cats._ 
import cats.implicits._ 

Note, List applicatives creates N1 * N2 result 

val xs: List[Int] = List(1, 2, 3)
val fs: List[Int => Int] = List(_ + 2, _ + 2, _ +1)
val ys: List[Int] = Applicative[List].ap(fs)(xs) 
//List(3, 4, 5, 3, 4, 5, 2, 3, 4)
//ap is also called  <*>[A, B](ff: F[A => B])(fa: F[A]): F[B]
fs <*> xs

Requirement is to Implement such that 
ys expected to be List(f1(1), f2(2), f3(3)) = List(3,4,4)

Define 
case class ZipList[A](val list: List[A])

implicit val zipListApplicative = new Applicative[ZipList] {

  def pure[A](a: A): ZipList[A] = ZipList(List(a))

  def ap[A, B](zf : ZipList[A => B])(za: ZipList[A]): ZipList[B] = {
    val bs = (za.list zip zf.list) map {case (a, f) => f(a)}
    ZipList(bs)
  }
  //Defined as below in Applicative 
  //def map[A,B](f: A => B)(fa: F[A]): F[B] =   ap(pure(f))(fa)
  
}


//Usage 
val xs: List[Int] = List(1, 2, 3)
val fs: List[Int => Int] = List(_ + 2, _ + 2, _ +1)

def <*>[F[_]:Applicative, A, B](ff: F[A => B])(fa: F[A]): F[B] = Applicative[F].ap(ff)(fa)
ZipList(fs) <*> ZipList(xs)
//ZipList[Int] = ZipList(List(3, 4, 4))

But is ZipList a Applicative or Functor?

//Test Data 
import org.scalacheck.Prop._
import org.scalacheck._

implicit def arbZipList[T](implicit ev: Arbitrary[T]): Arbitrary[ZipList[T]] =Arbitrary {
  for {
    lst <-  Gen.listOf[T](ev.arbitrary)  //Arbitrary[T].arbitrary : Gen[T]
    } yield ZipList(lst)
}
//Check 
arbZipList[Int].arbitrary.sample 

//Check for Functor - remove all instances of Applicative 
//else implicits comes from applicatives, so restart scala prompt 
implicit val zipListFunctor = new Functor[ZipList] {
  def map[A, B](fa: ZipList[A])(f: A => B): ZipList[B] = ZipList(fa.list.map(f))
}

def identity[A](x: A): A = x

def id[A, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]]): Prop =
    forAll { as: F[A] => F.map(as)(identity) == as }
    
id[Int,ZipList].check //OK when zipListFunctor is in scope 

id[Int,ZipList].check //Failed when zipListApplicative is in scope 
//! Falsified after 2 passed tests.
//> ARG_0: ZipList(List(-1483655021, 499003824))
Because 
ZipList(List(-1483655021, 499003824)).map(identity) = ZipList(List(-1483655021))
gives first value only because identity is applied in firstvalue 
because of below implementation
map[A,B](f: A => B)(fa: F[A]): F[B] =   ap(pure(f))(fa)
and ap is implemented  as a zip of function and ZipList and in zip , shortest length wins 
So it should have two functions  
ZipList(List(identity[Int](_), identity[Int](_))) <*> ZipList(List(-1483655021, 499003824))
//ZipList(List(-1483655021, 499003824))

//With cats-law 
import cats.laws.discipline.ApplicativeTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[ZipList[A]] = Eq.fromUniversalEquals //because case class
 checkAll("ZipList.ApplicativeLaws", ApplicativeTests[ZipList].applicative[Int, Int, String])
}
org.scalatest.run(new SomeLawTests()) //Failed 





///Applicative - Props check with  cats-law 
https://github.com/typelevel/cats/tree/main/laws/src/main/scala/cats/laws
https://github.com/typelevel/cats/blob/main/laws/src/main/scala/cats/laws/discipline/AlternativeTests.scala

import cats.laws.discipline.ApplicativeTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 // ApplicativeTests[F[_].applicative[A: Arbitrary, B: Arbitrary, C: Arbitrary]
  checkAll("List.ApplicativeLaws", ApplicativeTests[List].applicative[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
- List.ApplicativeLaws.applicative.ap consistent with product + map
- List.ApplicativeLaws.applicative.applicative homomorphism
- List.ApplicativeLaws.applicative.applicative identity
- List.ApplicativeLaws.applicative.applicative interchange
- List.ApplicativeLaws.applicative.applicative map
- List.ApplicativeLaws.applicative.applicative unit
- List.ApplicativeLaws.applicative.apply composition
- List.ApplicativeLaws.applicative.covariant composition
- List.ApplicativeLaws.applicative.covariant identity
- List.ApplicativeLaws.applicative.invariant composition
- List.ApplicativeLaws.applicative.invariant identity
- List.ApplicativeLaws.applicative.map2/map2Eval consistency
- List.ApplicativeLaws.applicative.map2/product-map consistency
- List.ApplicativeLaws.applicative.monoidal left identity
- List.ApplicativeLaws.applicative.monoidal right identity
- List.ApplicativeLaws.applicative.productL consistent map2
- List.ApplicativeLaws.applicative.productR consistent map2
- List.ApplicativeLaws.applicative.semigroupal associativity


    
///Example from  cats (apply called as ap)
import cats._
import cats.implicits._

def applyFunc[A, B, F[_]](as: F[A])(f: F[A => B])(implicit app: Applicative[F]): F[B] = app.ap(f)(as)

//for list, all functions are applied on all inputs 
//so 3 inputs, 3 functions would make 9 outputs 
applyFunc(List(1,2,3))(List( (_:Int) * 2, (_:Int) * 3, (e:Int) => e*e ))
//List(2, 4, 6, 3, 6, 9, 1, 4, 9) 

//Applicatives compose
import cats.data.Nested
import cats.implicits._
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

val x: Future[Option[Int]] = Future.successful(Some(5))
val y: Future[Option[Char]] = Future.successful(Some('a'))

//def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z]
val composed = Applicative[Future].compose[Option].map2(x, y)(_ + _)
// composed: Future[Option[Int]] = Future(Success(Some(102)))

//with kind projector 
val nested = Applicative[Nested[Future, Option, *]].map2(Nested(x), Nested(y))(_ + _)
// nested: Nested[Future, Option, Int] = Nested(Future(Success(Some(102))))
//OR 
val nested = Applicative[({type n[x]=Nested[Future, Option, x]})#n].map2(Nested(x), Nested(y))(_ + _)





///Why we need to Traverse in Applicative 
The straightforward way to use product and map (or just ap) 
is to compose n independent effects,  where n is a fixed number. 

In fact there are convenience methods named apN, mapN
(replacing N with a number 2 - 22)  to make it even easier.

def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] 
def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z] 

Imagine we have one Option representing a username, 
one representing a password, and another representing  a URL 
for logging into a database.

import java.sql.Connection
import cats._
import cats.implicits._

val username: Option[String] = Some("username")
val password: Option[String] = Some("password")
val url: Option[String] = Some("some.login.url.here")

// Stub for demonstration purposes
def attemptConnect(username: String, password: String, url: String): Option[Connection] = None

//we have 3 Options, so we can use map3 specifically.
Applicative[Option].map3(username, password, url)(attemptConnect)
// res2: Option[Option[Connection]] = Some(None)

//OR using cats.syntax 
import cats.implicits._

(username, password, url).mapN(attemptConnect)
// res7: Option[Option[Connection]] = Some(None)

Sometimes we don’t know how many effects will be in play 
This implies the need for a function:

def sequenceOption[A](fa: List[Option[A]]): Option[List[A]] = ???

// Alternatively..
def traverseOption[A, B](as: List[A])(f: A => Option[B]): Option[List[B]] = ???

For example , implement as 

def traverseOption[A, B](as: List[A])(f: A => Option[B]): Option[List[B]] =
  as.foldRight(Some(List.empty[B]): Option[List[B]]) { 
  (a: A, acc: Option[List[B]]) =>
    val optB: Option[B] = f(a)
    // optB and acc are independent effects so we can use Applicative to compose
    Applicative[Option].map2(optB, acc)(_ :: _)
  }

traverseOption(List(1, 2, 3))(i => Some(i): Option[Int])

Or to implement for Either 

import cats.implicits._

def traverseEither[E, A, B](as: List[A])(f: A => Either[E, B]): Either[E, List[B]] =
  as.foldRight(Right(List.empty[B]): Either[E, List[B]]) { (a: A, acc: Either[E, List[B]]) =>
    val eitherB: Either[E, B] = f(a)
    Applicative[Either[E, *]].map2(eitherB, acc)(_ :: _)
  }

traverseEither(List(1, 2, 3))(i => if (i % 2 != 0) Left(s"${i} is not even") else Right(i / 2))
// res4: Either[String, List[Int]] = Left("1 is not even")


So the generic implementation is 

def traverse[F[_]: Applicative, A, B](as: List[A])(f: A => F[B]): F[List[B]] =
  as.foldRight(Applicative[F].pure(List.empty[B])) { (a: A, acc: F[List[B]]) =>
    val fb: F[B] = f(a)
    Applicative[F].map2(fb, acc)(_ :: _)
  }
  
This function is provided by Cats via the Traverse[List] instance 

import cats.implicits._

List(1, 2, 3).traverse(i => Some(i): Option[Int])
// res5: Option[List[Int]] = Some(List(1, 2, 3))


The Traversable is defined as
Traversable is independent  of Applicative concept , 
but traverse requires Applicative to traverse one container 

Traversable is powerful than Functor (as map can be implemented by traverse)
and more powerful than Foldable as (foldLeft/Right can be implemented by traverse) 

Functor, Applicative, Traversable can be composed 


import scala.{ Traversable => _ }

trait Traverse[F[_]] extends Functor[F]{ 
  
  //main two methods 
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]
  def sequence[G[_]: Applicative, A](fga: F[G[A]]): G[F[A]] =
    traverse(fga)(ga => ga)
    
  //compose 
  implicit def compose[H[_]](implicit H: Traversable[H]): Traversable[({type f[x] = F[H[x]]})#f] = {
    val F = this
    new Traversable[({type f[x] = F[H[x]]})#f] {
      override def traverse[G[_]: Applicative, A, B](fa: F[H[A]])(f: A => G[B]) =
        F.traverse(fa)((ga: H[A]) => H.traverse(ga)(f))

      override def map[A, B](in: F[H[A]])(f: A => B): F[H[B]] =
        F.map(in)((ga: H[A]) => H.map(ga)(f))
    }
  }
    
  //other concrete methods from Cats 
  //F.flatten should exists which comes from FlatMap[F]
  def flatTraverse[G[_], A, B](fa: F[A])(f: A => G[F[B]])(implicit G: Applicative[G], F: FlatMap[F]): G[F[B]] =
    G.map(traverse(fa)(f))(F.flatten)

  def flatSequence[G[_], A](fgfa: F[G[F[A]]])(implicit G: Applicative[G], F: FlatMap[F]): G[F[A]] =
    G.map(sequence(fgfa))(F.flatten)

  def mapWithIndex[A, B](fa: F[A])(f: (A, Int) => B): F[B] = ...
  def traverseWithIndexM[G[_], A, B](fa: F[A])(f: (A, Int) => G[B])(implicit G: Monad[G]): G[F[B]] =
  def zipWithIndex[A](fa: F[A]): F[(A, Int)] =
    mapWithIndex(fa)((a, i) => (a, i))

}


///Traverse: Props check with  cats-law 
https://github.com/typelevel/cats/tree/main/laws/src/main/scala/cats/laws
https://github.com/typelevel/cats/blob/main/laws/src/main/scala/cats/laws/discipline/AlternativeTests.scala

import cats.laws.discipline.TraverseTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

//CommutativeApplicative
//Further than an Applicative, which just allows composition of independent effectful functions,
//in a Commutative Applicative those functions can be composed in any order, which guarantees
//that their effects do not interfere.

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 // ApplicativeTests[F[_].traverse[A: Arbitrary, B: Arbitrary, C: Arbitrary, M: Arbitrary, X[_]: CommutativeApplicative, Y[_]: CommutativeApplicative]
  checkAll("List.TraversalLaws", TraverseTests[List].traverse[Int, Int, Int, Int, Option, Option])
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
SomeLawTests:
- List.TraversalLaws.traverse.collectFirst reference
- List.TraversalLaws.traverse.collectFirstSome reference
- List.TraversalLaws.traverse.covariant composition
- List.TraversalLaws.traverse.covariant identity
- List.TraversalLaws.traverse.dropWhile_ reference
- List.TraversalLaws.traverse.exists consistent with find
- List.TraversalLaws.traverse.exists is lazy
- List.TraversalLaws.traverse.filter_ reference
- List.TraversalLaws.traverse.fold reference
- List.TraversalLaws.traverse.foldLeft consistent with foldMap
- List.TraversalLaws.traverse.foldM identity
- List.TraversalLaws.traverse.foldRight consistent with foldMap
- List.TraversalLaws.traverse.foldRight is lazy
- List.TraversalLaws.traverse.foldRightDefer consistency
- List.TraversalLaws.traverse.forall consistent with exists
- List.TraversalLaws.traverse.forall is lazy
- List.TraversalLaws.traverse.forall true if empty
- List.TraversalLaws.traverse.get reference
- List.TraversalLaws.traverse.invariant composition
- List.TraversalLaws.traverse.invariant identity
- List.TraversalLaws.traverse.nonEmpty reference
- List.TraversalLaws.traverse.ordered consistency
- List.TraversalLaws.traverse.reduceLeftOption consistent with reduceLeftToOption
- List.TraversalLaws.traverse.reduceRightOption consistent with reduceRightToOption
- List.TraversalLaws.traverse.takeWhile_ reference
- List.TraversalLaws.traverse.toList reference
- List.TraversalLaws.traverse.traverse derive foldMap
- List.TraversalLaws.traverse.traverse identity
- List.TraversalLaws.traverse.traverse order consistency
- List.TraversalLaws.traverse.traverse parallel composition
- List.TraversalLaws.traverse.traverse ref mapWithIndex
- List.TraversalLaws.traverse.traverse ref traverseWithIndexM
- List.TraversalLaws.traverse.traverse ref zipWithIndex
- List.TraversalLaws.traverse.traverse sequential composition
- List.TraversalLaws.traverse.traverse traverseTap
- List.TraversalLaws.traverse.unordered traverse consistent with sequence
- List.TraversalLaws.traverse.unordered traverse parallel composition
- List.TraversalLaws.traverse.unordered traverse sequential composition
- List.TraversalLaws.traverse.unorderedFold consistent with unorderedFoldMap



///Example from cats 
import cats 
import cats.implicits._

//One element None, means result None 
val list = List(Some(1), Some(2), None)
// list: List[Option[Int]] = List(Some(1), Some(2), None)
val traversed = list.traverse(identity)
// traversed: Option[List[Int]] = None
//Or 
val sequenced = list.sequence
// sequenced: Option[List[Int]] = None


def parseInt(s: String): Option[Int] = Either.catchOnly[NumberFormatException](s.toInt).toOption
List("1", "2", "3").traverse(parseInt)
//Option[List[Int]] = Some(List(1, 2, 3))
List("1", "two", "3").traverse(parseInt)
//Option[List[Int]] = None

def parseInt(s: String): Option[Int] = Either.catchOnly[NumberFormatException](s.toInt).toOption
val x = Option(List("1", "two", "3"))
x.flatTraverse(_.map(parseInt))
//List[Option[Int]] = List(Some(1), None, Some(3))

val x: List[Option[Int]] = List(Some(1), Some(2))
val y: List[Option[Int]] = List(None, Some(2))
x.sequence
//Option[List[Int]] = Some(List(1, 2))
y.sequence
//Option[List[Int]] = None

val x: List[Option[List[Int]]] = List(Some(List(1, 2)), Some(List(3)))
val y: List[Option[List[Int]]] = List(None, Some(List(3)))
x.flatSequence
//Option[List[Int]] = Some(List(1, 2, 3))
y.flatSequence
//Option[List[Int]] = None



///Some examples of Functor but not Applicative etc 

// tagged value ("tag", v) is functor but not applicative 
Functor but not an Applicative is a tagged value, 
where you have a value that is  associated with some arbitrary "tag". 
This is a functor - given a function f and a tagged value ("tag1", v), 
you can map over it to get the result ("tag1", f(v)). 

But it is not an applicative: for one, there is no "default" tag, so it is not Pured, 
but also given ("tag1", f) ie f in applicative context and ("tag2", v), 
the result(ap) should have a value of ("someTag", f(v)), but what would that "sometag" be? 
There is no automatic way to generate a tag from two existing tags.


import cats._ 
import cats.implicits._ 

case class TaggedValue[A](val value: (String, A) ){
    val tag = value._1
    val v = value._2
}


implicit val taggedValueFunctor = new Functor[TaggedValue] {
  def map[A, B](fa: TaggedValue[A])(f: A => B): TaggedValue[B] = TaggedValue( (fa.tag, f(fa.v) ) )
}
//Prop check 
import cats.laws.discipline.FunctorTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._


object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[TaggedValue[A]] = Arbitrary{
    for {
        tag <- Arbitrary.arbString.arbitrary
        v <- Arbitrary.arbitrary[A]
        }  yield TaggedValue((tag, v))
  }
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[TaggedValue[A]] = Eq.fromUniversalEquals //because case class
 checkAll("TaggedValue.FunctorLaws", FunctorTests[TaggedValue].functor[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests()) //OK 


The Writer monad is almost identical to the tagged value -
its conceptually a value paired with a "logging value". 
The difference is that the logging value is not arbitrary - 
it's required to be a monoid. This gives us a default value, 
so it's Pured, and a way to combine logging values, 
so ("log1", f) and ("log2", v) can be combined into ("log1log2", f(v)). 
So Writer is Applicative, and in fact a full Monad.

case class TaggedValueM[A](val value: (String, A) ){
    val tag = value._1
    val v = value._2
}

implicit val taggedValueMApplicative = new Applicative[TaggedValueM] {

  def pure[A](a: A): TaggedValueM[A] = TaggedValueM( (Monoid[String].empty,  a) )

  def ap[A, B](zf : TaggedValueM[A => B])(za: TaggedValueM[A]): TaggedValueM[B] = {
    val tag = Monoid[String].combine(za.tag, zf.tag)
    val v = zf.v(za.v)
    TaggedValueM( (tag, v) )
  }
  //Defined as below in Applicative 
  //def map[A,B](f: A => B)(fa: F[A]): F[B] =   ap(pure(f))(fa)
  
}
//prop check 
import cats.laws.discipline.ApplicativeTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._


object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[TaggedValueM[A]] = Arbitrary{
    for {
        tag <- Arbitrary.arbString.arbitrary
        v <- Arbitrary.arbitrary[A]
        }  yield TaggedValueM((tag, v))
  }
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[TaggedValueM[A]] = Eq.fromUniversalEquals //because case class
 checkAll("TaggedValueM.ApplicativeLaws", ApplicativeTests[TaggedValueM].applicative[Int, Int, String])
}

scala > org.scalatest.run(new SomeLawTests()) //OK 

//check for Monad 
import cats.laws.discipline.MonadTests


implicit val taggedValueMMonad = new Monad[TaggedValueM] {

  def pure[A](a: A): TaggedValueM[A] = TaggedValueM( (Monoid[String].empty,  a) )

  def flatMap[A, B](fa: TaggedValueM[A])(f: A => TaggedValueM[B]): TaggedValueM[B] = {
    val mappedV = f(fa.v)
    val tag = Monoid[String].combine(fa.tag, mappedV.tag)
    TaggedValueM( (tag, mappedV.v) )
  }
  //Not Stack safe - but required
  def tailRecM[A, B](a: A)(f: A => TaggedValueM[Either[A,B]]): TaggedValueM[B] = 
   flatMap(f(a) /*TaggedValueM[Either[A,B]]*/) { /* Either[A,B] */
      case Right(b) => pure(b)
      case Left(nextA) => tailRecM(nextA)(f)
    }
  //Defined as 
  //def flatten[A](ffa: F[F[A]]): F[A] =  flatMap(ffa)(fa => fa)
  //def ap[A, B](ff: F[A => B])(fa: F[A]): F[B] =    flatMap(ff)(f => map(fa)(f))
  //def map[A, B](fa: F[A])(f: A => B): F[B] =  flatMap(fa)(a => pure(f(a)))  
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[TaggedValueM[A]] = Eq.fromUniversalEquals //because case class
 //stackUnsafeMonad because tailRecM is not implemented 
 checkAll("TaggedValueM.MonadLaws", MonadTests[TaggedValueM].stackUnsafeMonad[Int, Int, String])
}
scala > org.scalatest.run(new SomeLawTests()) //OK 


//ZipList is Functor, but not Applicative 
An intuitive example of something that's an Functor (a Traversable, really) 
but not a Monad is a ZipList. Given [f1, f2] and [v1, v2, v3], you'll end up with [f1(v1), f2(v2)], so it's Applicative. 
But implementing join is impossible in general - given [[a1, a2], [b1], [c1, c2, c3]], 
the obvious way to collapse it into a single ziplist is to take the Nth element of the Nth list.
But there's no b2 element! Fixed-length or infinite-length ziplists are Monads, though. 
(Why can't you just stop at the first one that fails, returning [a1]? 
It violates the monad laws! Usually associativity, depending on exactly what you implement.)

An intuitive example of something that's an Applicative but not a Traversable is IO. 
An IO is an Applicative - you can join an IO and an IO into an IO that 
just performs the side-effects of both source IOs in order. 
But the essential characteristic of a Traversable is that you can build an identical 
version of one just by looking at its internal values. 
A list is a Traversable - once you pull its values out, you can just put them in a new list 
in the same order, and the old and new are functionally indistinguishable. 
But the same isn't true of an IO - the internal value is the result of some operation 
which has side effects, and those side-effects aren't extractable or reproducible. 
If you try and make a new IO from an existing one, all that happens is you end up 
executing the side-effects once, and then the new one is a sterile IO 
with no side-effects at all.

Another example of Applicative-but-not-Traversable is Function, for similar reasons - 
the value "inside" of a Function is its return value. 
Its Applicative instance just holds onto the two source Functions; 
when you go to extract the value (by giving it an input argument), 
it feeds it to each of the source Functions, producing a function and a value, 
then calls the former on the latter and returns the result. 
But the code that transforms the input into the output is hidden internal state, 
which is not extractable, so you cant "rebuild" a function by extracting its return value; 
at best you can produce a constant function that just returns the same thing 
as the Function does for a single particular value.



////--------------Familiarizing Yourself with Basic Monads---------------------------------------------------------------------------------------------
9.       Familiarizing Yourself with Basic Monads
·       Familiarizing Yourself with Basic Monads
·       Introduction to monads
·       Id Monad
·       State monad
·       Reader monad
·       Writer monad

///Introducing Monad 
The abstraction name is Monad, and it is defined by two methods, flatMap, and pure:
More powerful than Applicative and Functor because ap, map can be implemented by flatMap 

import scala.language.higherKinds
trait Monad[F[_]] {
  def pure[A](a: A): F[A]
  def flatMap[A, B](a: F[A])(f: A => F[B]): F[B]
  
  def map[A, B](a: F[A])(f: A => B): F[B] =
    flatMap(a)(a => pure(f(a)))

  def flatten[A](a: F[F[A]]): F[A] = flatMap(a)(fa => fa)
    
  // def flatMap[A, B](a: F[A])(f: A => F[B]): F[B] //Note a is F[sometype] and f is sometype to someother Fn ie f's arg and a type is same 
  //def map[A, B](a: F[A])(f: A => B): F[B]
  def ap[A, B](ff: F[A => B])(fa: F[A]): F[B] =
    flatMap(f) { fab: (A => B) => map(a)(fab)}
    //fab is arg name with type A=>B  , body 

  override def product[A, B](fa: F[A], fb: F[B]): F[(A, B)] =
    flatMap(fa)(a => map(fb)(b => (a, b)))

  override def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] =
    flatMap(fa)(a => flatMap(fb)(b => map(ff)(_(a, b))))

  override def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z] =
    flatMap(fa)(a => map(fb)(b => f(a, b)))

  override def productR[A, B](fa: F[A])(fb: F[B]): F[B] =
    flatMap(fa)(_ => fb)

  override def productL[A, B](fa: F[A])(fb: F[B]): F[A] =
    map2(fa, fb)((a, _) => a)

}

This possibility to flatten F[F[A]] into F[A] is the reason why monads are often expressed
with a different set of methods; that is, map and flatten:

trait   Monad[F[_]] {
  def   pure[A](a: => A): F[A]
  def   map[A, B](a: F[A])(f: A => B): F[B]
  def   flatten[A](fa: F[F[A]]): F[A]
}

///Monad-Some implementations
implicit def eitherMonad[L] = new Monad[Either[L, *]] {
 override def pure[A](a:  A): Either[L, A] = Right(a)

 override def flatMap[A, B](a: Either[L, A])(f: A => Either[L, B]):  Either[L, B] = a match {
   case Right(r) => f(r)
   case Left(l) => Left(l)
 }
}

implicit val listMonad = new Monad[List] {
  def unit[A](a: => A) = List(a)

  def flatMapNonTailRec[A,B](as: List[A])(f: A => List[B]): List[B] = as match {
    case Nil => Nil
    case a :: as => f(a) ::: flatMap(as)(f)
  }

  def flatMapOkButSlow[A,B](as: List[A])(f: A => List[B]): List[B] = {
    @tailrec
    def fMap(as: List[A], acc: List[B])(f: A => List[B]): List[B] = as match {
      case Nil => acc
      case a :: aas => fMap(aas, acc ::: f(a))(f)
    }
    fMap(as, Nil)(f)
  }

  override def flatMap[A,B](as: List[A])(f: A => List[B]): List[B] = as.flatMap(f)
}

///Monad Laws
pure and flatMap must obey a set of laws that allow us to sequence
operations freely without unintended glitches and sideeffects:

    Left identity: calling pure and transforming the result with func is the
    same as calling func:
    pure(a).flatMap(func) == func(a)

    Right identity: passing pure to flatMap is the same as doing nothing:
    m.flatMap(pure) == m

    Associativity: flatMapping over two functions f and g is the same as
    flatMapping over f and then flatMapping over g:
    m.flatMap(f).flatMap(g) == m.flatMap(x => f(x).flatMap(g))

//In Props 
import org.scalacheck._
import Prop._


def associativity[A, B, C, M[_]](implicit M: Monad[M],
                                 arbMA: Arbitrary[M[A]],
                                 arbMB: Arbitrary[M[B]],
                                 arbMC: Arbitrary[M[C]],
                                 arbB: Arbitrary[B],
                                 arbC: Arbitrary[C],
                                 cogenA: Cogen[A],
                                 cogenB: Cogen[B]): Prop = {
  forAll((as: M[A], f: A => M[B], g: B => M[C]) => {
    val leftSide = M.flatMap(M.flatMap(as)(f))(g)
    val rightSide = M.flatMap(as)(a => M.flatMap(f(a))(g))
    leftSide == rightSide
  })
}

def id[A, B, M[_]](implicit M: Monad[M],
                   arbFA: Arbitrary[M[A]],
                   arbFB: Arbitrary[M[B]],
                   arbA: Arbitrary[A],
                   cogenA: Cogen[A]): Prop = {
  val leftIdentity = forAll { as: M[A] =>
    M.flatMap(as)(M.pure(_)) == as
  }
  val rightIdentity = forAll { (a: A, f: A => M[B]) =>
    M.flatMap(M.pure(a))(f) == f(a)
  }
  leftIdentity && rightIdentity
}

def monad[A, B, C, M[_]](implicit M: Monad[M],
                         arbMA: Arbitrary[M[A]],
                         arbMB: Arbitrary[M[B]],
                         arbMC: Arbitrary[M[C]],
                         arbA: Arbitrary[A],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],
                         cogenB: Cogen[B]): Prop = {
  id[A, B, M] && associativity[A, B, C, M]
}

//Monad[List] and String => Int, Int => Boolean
monad[String, Int, Boolean, List].check 

///Monad -Props check with  cats-law 
import cats.laws.discipline.MonadTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 //monad[A: Arbitrary: Eq, B: Arbitrary: Eq, C: Arbitrary: Eq]
  checkAll("List.MonadLaws", MonadTests[List].monad[Int, Int, String])
  checkAll("List.StackUnsafeMonadLaws", MonadTests[List].stackUnsafeMonad[Int, Int, String])
  
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
- List.MonadLaws.monad.ap consistent with product + map
- List.MonadLaws.monad.applicative homomorphism
- List.MonadLaws.monad.applicative identity
- List.MonadLaws.monad.applicative interchange
- List.MonadLaws.monad.applicative map
- List.MonadLaws.monad.applicative unit
- List.MonadLaws.monad.apply composition
- List.MonadLaws.monad.covariant composition
- List.MonadLaws.monad.covariant identity
- List.MonadLaws.monad.flatMap associativity
- List.MonadLaws.monad.flatMap consistent apply
- List.MonadLaws.monad.flatMap from tailRecM consistency
- List.MonadLaws.monad.invariant composition
- List.MonadLaws.monad.invariant identity
- List.MonadLaws.monad.map flatMap coherence
- List.MonadLaws.monad.map2/map2Eval consistency
- List.MonadLaws.monad.map2/product-map consistency
- List.MonadLaws.monad.monad left identity
- List.MonadLaws.monad.monad right identity
- List.MonadLaws.monad.monoidal left identity
- List.MonadLaws.monad.monoidal right identity
- List.MonadLaws.monad.mproduct consistent flatMap
- List.MonadLaws.monad.productL consistent map2
- List.MonadLaws.monad.productR consistent map2
- List.MonadLaws.monad.semigroupal associativity
- List.MonadLaws.monad.tailRecM consistent flatMap
- List.MonadLaws.monad.tailRecM stack safety

- List.StackUnsafeMonadLaws.monad (stack-unsafe).ap consistent with product +map
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative homomorphism
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative interchange
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative map
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative unit
- List.StackUnsafeMonadLaws.monad (stack-unsafe).apply composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).covariant composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).covariant identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap associativity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap consistent apply
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap from tailRecM consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).invariant composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).invariant identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map flatMap coherence
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map2/map2Eval consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map2/product-map consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monad left identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monad right identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monoidal left identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monoidal right identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).mproduct consistent flatMap
- List.StackUnsafeMonadLaws.monad (stack-unsafe).productL consistent map2
- List.StackUnsafeMonadLaws.monad (stack-unsafe).productR consistent map2
- List.StackUnsafeMonadLaws.monad (stack-unsafe).semigroupal associativity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).tailRecM consistent flatMap

///Monad-cats definition 
trait FlatMap[F[_]] extends Apply[F] {
  def flatMap[A, B](fa: F[A])(f: A => F[B]): F[B]
  def flatten[A](ffa: F[F[A]]): F[A] =  flatMap(ffa)(fa => fa)
  
  override def ap[A, B](ff: F[A => B])(fa: F[A]): F[B] =
    flatMap(ff)(f => map(fa)(f))

  override def product[A, B](fa: F[A], fb: F[B]): F[(A, B)] =
    flatMap(fa)(a => map(fb)(b => (a, b)))

  override def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] =
    flatMap(fa)(a => flatMap(fb)(b => map(ff)(_(a, b))))

  override def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z] =
    flatMap(fa)(a => map(fb)(b => f(a, b)))

  override def productR[A, B](fa: F[A])(fb: F[B]): F[B] =
    flatMap(fa)(_ => fb)

  override def productL[A, B](fa: F[A])(fb: F[B]): F[A] =
    map2(fa, fb)((a, _) => a)
}
  
trait Monad[F[_]] extends FlatMap[F] with Applicative[F] {
  override def map[A, B](fa: F[A])(f: A => B): F[B] =  flatMap(fa)(a => pure(f(a)))
  //Only flatMap and pure as Abstract 
  def flatMap[A, B](fa: F[A])(f: A => F[B]): F[B]
  //from Others 
  //from FlatMap 
  def flatten[A](ffa: F[F[A]]): F[A] =  flatMap(ffa)(fa => fa)
  //from Applicative
  def pure[A](x: A): F[A]
  def unit: F[Unit] = pure(())
  
  def point[A](a: A): F[A] = imap(unit)(_ => a)(_ => ())
  
  //From flatMap 
  override def ap[A, B](ff: F[A => B])(fa: F[A]): F[B] =
    flatMap(ff)(f => map(fa)(f))

  override def product[A, B](fa: F[A], fb: F[B]): F[(A, B)] =
    flatMap(fa)(a => map(fb)(b => (a, b)))

  override def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] =
    flatMap(fa)(a => flatMap(fb)(b => map(ff)(_(a, b))))

  override def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z] =
    flatMap(fa)(a => map(fb)(b => f(a, b)))

  override def productR[A, B](fa: F[A])(fb: F[B]): F[B] =
    flatMap(fa)(_ => fb)

  override def productL[A, B](fa: F[A])(fb: F[B]): F[A] =
    map2(fa, fb)((a, _) => a)
}

//With Cats 
import cats.implicits._
import cats._

def mapFunc[A, B, F[_]](as: F[A])(f: A => B)(implicit monad: Monad[F]): F[B] = monad.map(as)(f)
def applyFunc[A, B, F[_]](as: F[A])(f: F[A => B])(implicit monad: Monad[F]): F[B] = monad.ap(f)(as)

mapFunc(List(1,2,3))(_ * 2)
//List(2, 4, 6)
applyFunc(List(1,2,3))(List( (_:Int) * 2, (_:Int) * 3, (e:Int) => e*e ))
//List(2, 4, 6, 3, 6, 9, 1, 4, 9)

//Valid for functions as well 
val func1: Int => Double =
(x: Int) => x.toDouble


val func2: Double => Double =
(y: Double) => y * 2


(func1 map func2)(1)        // composition using map
// res3: Double = 2.0        // composition using map
(func1 andThen func2)(1) // composition using andThen
// res4: Double = 2.0 // composition using andThen
func2(func1(1))             // composition written out by hand
// res5: Double = 2.0


val func =
((x: Int) => x.toDouble).
  map(x => x + 1).
  map(x => x * 2).
  map(x => s"${x}!")


func(123)
// res6: String = "248.0!"

///Extend Monad with FlatAppply 


trait Functor[F[_]] {
  def map[A,B](in: F[A])(f: A => B): F[B]
  def mapC[A,B](f: A => B): F[A] => F[B] = fa => map(fa)(f)
}

trait Applicative[F[_]] extends Functor[F] {
  def apply[A,B](a: F[A])(f: F[A => B]): F[B]
  def unit[A](a: => A): F[A]
}

trait Monad[F[_]] extends Applicative[F] {
  def flatMap[A, B](a: F[A])(f: A => F[B]): F[B]
  def unit[A](a: => A): F[A]
  
  def flatten[A](a: F[F[A]]): F[A] = flatMap(a)(fa => fa)

  override def map[A, B](a: F[A])(f: A => B): F[B] = flatMap(a)(a => unit(f(a)))

  override def apply[A, B](a: F[A])(f: F[A => B]): F[B] =
    flatMap(f) { fab: (A => B) => map(a)(fab)}
    
  def flatApply[A, B](a: F[A])(f: F[A => F[B]]): F[B] =
    flatMap(f) { fab: (A => F[B]) => flatMap(a) { a: A => fab(a) }}
  }

implicit val listMonad = new Monad[List] {
    def unit[A](a: => A) = List(a)
    override def flatMap[A,B](as: List[A])(f: A => List[B]): List[B] = as.flatMap(f)
}
def flatApplyFunc[A, B, F[_]](as: F[A])(f: F[A => F[B]])(implicit monad: Monad[F]): F[B] = monad.flatApply(as)(f)

flatApplyFunc(List(1,2,3))(List( (e:Int) => List(e*e, e*e*e), (e:Int) => List(2*e,3*e) ))
// List(1, 1, 4, 8, 9, 27, 2, 3, 4, 6, 6, 9) //each Fn  all elements


///Partial Unification
For the above examples to work, in versions of Scala before 2.13, we
need to add the following compiler option to build.sbt:

scalacOptions += "-Ypartial-unification"

otherwise we will get a compiler error:

val func1: Int => Double =
(x: Int) => x.toDouble


val func2: Double => Double =
(y: Double) => y * 2

func1.map(func2)
// <console>: error: value map is not a member of Int => Double
//         func1.map(func2)
                    ^
Function1 has two type parameters (the function argument and the result type):
trait Function1[-A, +B] {
 def apply(arg: A): B
}

However, Functor accepts a type constructor with one parameter:
trait Functor[F[_]] {
 def map[A, B](fa: F[A])(func: A => B): F[B]
}

The compiler has to fix one of the two parameters of Function1 to create a
type constructor of the correct kind to pass to Functor. It has two options to
choose from when Int => Double 
type F[A] = Int => A
type F[A] = A => Double

We know that the former of these is the correct choice. However the compiler
doesnot understand what the code means. Instead it relies on a simple rule,
implementing what is called "partial unification".

The partial unification in the Scala compiler works by fixing type parameters
from left to right. In the above example, the compiler fixes the Int in 
Int => Double and looks for a Functor for functions of type Int => ?:

type F[A] = Int => A
val functor = Functor[F]

This lefttoright elimination works for a wide variety of common scenarios,
including Functors for types such as Function1 and Either:

val either: Either[String, Int] = Right(123)
// either: Either[String, Int] = Right(123)


either.map(_ + 1)
// res0: Either[String, Int] = Right(124)

//Limitations of Partial Unification
There are situations where lefttoright elimination is not the correct choice.
One example is the Or type in Scalactic, which is a conventionally leftbiased
equivalent of Either:

type PossibleResult = ActualResult Or Error

Another example is the Contravariant functor for Function1.

While the covariant Functor for Function1 implements andThen style
lefttoright function composition, the Contravariant functor implements
compose style righttoleft composition. In other words, the following expres
sions are all equivalent:

val func3a: Int => Double =
 a => func2(func1(a))


val func3b: Int => Double =
 func2.compose(func1)


// This wonot actually compile:
import cats.syntax.contravariant._ // for contramap
val func3c: Int => Double =
 func2.contramap(func1)
// error: value contramap is not a member of Double => Double
// val func3c = func2.contramap(func1)
//                 ^^^^^^^^^^^^^^^

The problem here is that the Contravariant for Function1 fixes the return
type and leaves the parameter type varying, requiring the compiler to elimi
nate type parameters from right to left

           contramap
A => X                      B => A              B => X


type F[A] = A => Double

The compiler fails simply because of its lefttoright bias. We can prove this
by creating a type alias that flips the parameters on Function1:
type <=[B, A] = A => B

type F[A] = Double <= A

If we retype func2 as an instance of <=, we reset the required order of elimi
nation and we can call contramap as desired:

val func2b: Double <= Double = func2

val func3c = func2b.contramap(func1)
// func3c: Int => Double = scala.Function1$$Lambda$7919/0x00000008424d3040@50061a2d

The difference between func2 and func2b is purely syntactic--both refer to
the same value and the type aliases are otherwise completely compatible. In
credibly, however, this simple rephrasing is enough to give the compiler the
hint it needs to solve the problem.



///Id Monad
It wraps a value but does nothing with it. 
Because Monad requires type constructor, simple type can not be used, so use Id type 

type Id[A] = A

This type definition will dictate the details of the monad implementation:
implicit val idMonad = new Monad[Id] {
  override def unit[A](a: => A): Id[A] = a
  override def flatMap[A, B](a: Id[A])(f: A => Id[B]): Id[B] = f(a)
}

///Example from cats 
import cats._
import cats.implicits._ 
 
def sumSquare[F[_]: Monad](a: F[Int], b: F[Int]): F[Int] =
     for {
      x <- a
      y <- b
     } yield x*x + y*y


This method works well on Options and Lists 
sumSquare(Some(2):Option[Int], Some(3):Option[Int])

but we canot call it passing in plain values:
sumSquare(3, 4)

//There comes Id monad 
sumSquare(3 : Id[Int], 4 : Id[Int])


///Monad Composition 

Functor[F[_]].compose[G[_]: Functor]: Functor[({type f[x]=F[G[x]]})#f] =  {   
        val F = this
        val G = implicitly[Functor[G]]
        new Functor[({type f[x]=F[G[x]]})#f] {
            override def map[A, B](fga: F[G[A]])(f: A => B): F[G[B]] =
                F.map(fga)(ga => G.map(ga)(f))
        }
    }
    
Applicative[F[_]].compose[G[_]]( implicit  G: Applicative[G]): Applicative[({type f[x] = F[G[x]]})#f] = {
    val F = this

    def fab[A, B]: G[A => B] => G[A] => G[B] = (gf: G[A => B]) => (ga: G[A]) => G.ap(gf)(ga)

    def fg[B, A](f: F[G[A => B]]): F[G[A] => G[B]] = F.map(f)(gab => fab(gab) )

    new Applicative[({type f[x] = F[G[x]]})#f] {
      def pure[A](a: A) = F.pure(G.pure(a))
      override def ap[A, B](f: F[G[A => B]])(a: F[G[A]]): F[G[B]] =
        F.ap(fg(f) /*F[G[A] => G[B]]*/ )(a)
    }
  }
Unlike Functors and Applicatives, not all Monads compose. 
This means that even if M[_] and N[_] are both Monads, M[N[_]] is not guaranteed to be a Monad.

However, many common cases do. 
One way of expressing this is to provide instructions on how to compose any outer monad 
(F in the following example) with a specific inner monad (Option in the following example).

This sort of construction is called a monad transformer.

Cats has an OptionT monad transformer, which adds a lot of useful functions 
to the simple implementation below.

import cats.*
import cats.implicits._

case class OptionT[F[_], A](value: F[Option[A]])

implicit def optionTMonad[F[_]](implicit F: Monad[F]): Monad[OptionT[F, *]] = {
  new Monad[OptionT[F, *]] {
    def pure[A](a: A): OptionT[F, A] = OptionT(F.pure(Some(a)))
    def flatMap[A, B](fa: OptionT[F, A])(f: A => OptionT[F, B]): OptionT[F, B] =
      OptionT {
        F.flatMap(fa.value) { /*Option[A]*/
          case None => F.pure(None)
          case Some(a) => f(a).value
        }
      }

    def tailRecM[A, B](a: A)(f: A => OptionT[F, Either[A, B]]): OptionT[F, B] =
      OptionT {
        F.tailRecM(a)(a0 => F.map(f(a0).value) {
          case None => Either.right[A, Option[B]](None)
          case Some(b0) => b0.map(Some(_))
        })
      }
  }
}



///State monad
The state monad is build around a function that takes state as an argument 
and returns a result and modified state 

The signature of such a function looks like this: 

type StatefulFunction[S, A] = S => (S, A).
//OR in case class 
case class State[S, A](runF: S => (S, A))

To compose this computation with the next one 
ie we now have State[S, A] and we need to transform to  State[S, B].
This type of monadic composition is called Kleisli composition / Kleisli arrow, 
It is frequently named >>= (basically it is flatMap)

final case class State[S, A](runF: S => (S, A)) {
  def compose[B](f: A => State[S, B]): State[S, B] = {
    val composedRuns = (s: S) => {
      val (nextState, a) = runF(s)
      f(a).runF(nextState)  //(S,B)
    }
    State(composedRuns)
  }
}

object State {
  def apply[S, A](a: S => (S,A) ): State[S, A] = State(a)
  def get[S]: State[S, S] = State(s => (s, s))  //A becomes S 
  def set[S](s: => S): State[S, Unit] = State(_ => (s, ())) 
}

And then 
implicit def stateMonad[S] = new Monad[State[S, *]] {
  override def pure[A](a: => A): State[S, A] = State(s => (s, a))
  override def flatMap[A, B](a: State[S, A])(f: A => State[S, B]): State[S,B] = a.compose(f)
}

///More Examples from Cats 
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/IndexedStateT.scala

IndexedStateT[F, SA, SB, A] is a stateful computation in a context `F` yielding
a value of type `A`. The state transitions from a value of type `SA` to a value
of type `SB`.
Note IndexedStateT[F, S, S, A] is StateT[F, S, A] monad and StateT[Eval, S, A]  is  State[S,A]

//Few implementations 
object IndexedStateT 
  def apply[F[_], SA, SB, A](f: SA => F[(SB, A)])(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, A] =
    new IndexedStateT(F.pure(f))
    
  def applyF[F[_], SA, SB, A](runF: F[SA => F[(SB, A)]]): IndexedStateT[F, SA, SB, A] =
    new IndexedStateT(runF)
    
  def modify[F[_], SA, SB](f: SA => SB)(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =
  def modifyF[F[_], SA, SB](f: SA => F[SB])(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =
  def set[F[_], SA, SB](sb: SB)(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =
  def setF[F[_], SA, SB](fsb: F[SB])(implicit F: Applicative[F]): IndexedStateT[F, SA, SB, Unit] =

//Note Actually the fn is not S => (S,A) but 
//SA => F[(SB, A)] and stores inside context F 
class IndexedStateT[F[_], SA, SB, A](val runF: F[SA => F[(SB, A)]])

 def run(initial: SA)(implicit F: FlatMap[F]): F[(SB, A)] =
    F.flatMap(runF)(f /*SA => F[(SB, A)]*/ => f(initial) /*F[(SB, A)]*/)

  def run(initial: SA)(implicit F: FlatMap[F]): F[(SB, A)] =
    Run with the provided initial state value
  def runS(s: SA)(implicit F: FlatMap[F]): F[SB] = F.map(run(s))(_._1)
    Run with the provided initial state value and return the final state
    (discarding the final value).
  def runA(s: SA)(implicit F: FlatMap[F]): F[A] = F.map(run(s))(_._2)
    Run with the provided initial state value and return the final value
    (discarding the final state).
  def runEmpty(implicit S: Monoid[SA], F: FlatMap[F]): F[(SB, A)] = run(S.empty)
    Run with `S` empty monoid value as the initial state.
  def runEmptyS(implicit S: Monoid[SA], F: FlatMap[F]): F[SB] = runS(S.empty)
    Run with `S` empty monoid value as the initial state and return the final
    state (discarding the final value).
  def runEmptyA(implicit S: Monoid[SA], F: FlatMap[F]): F[A] = runA(S.empty)
    Run with `S` empty monoid value as the initial state and return the final
    value (discarding the final state).
 /*
  object AndThen
    apply[A, B](f: A => B): AndThen[A, B]
  class AndThen[-T, +R] extends (T => R) 
    Stack safe T => R 
      def andThen[A](g: R => A): AndThen[T, A]
      def compose[A](g: A => T): AndThen[A, R]
  //Example 
  val seed = AndThen((x: Int) => x + 1)
  val f = (0 until 10000).foldLeft(seed)((acc, _) => acc.andThen(_ + 1))
 // This should not trigger stack overflow 
 f(0)
 */
 def flatMap[B, SC](fas: A => IndexedStateT[F, SB, SC, B])(implicit F: FlatMap[F]): IndexedStateT[F, SA, SC, B] =
    //applyF[F[_], SA, SB, A](arg: F[SA => F[(SB, A)]])
    //val runF: F[SA => F[(SB, A)]]
    IndexedStateT.applyF(F.map(runF) { safsba /*SA => F[(SB, A)]*/ =>
      //1st run       //2nd run 
      AndThen(safsba).andThen { fsba /*F[(SB, A)]*/=>
        F.flatMap(fsba) { /*(SB, A)*/case (sb, a) =>
          fas(a).run(sb) /*F[(SB, A)]*/
        }
      }
    })
    
  def flatMapF[B](faf: A => F[B])(implicit F: FlatMap[F]): IndexedStateT[F, SA, SB, B] =
  def mapK[G[_]](f: F ~> G)(implicit F: Functor[F]): IndexedStateT[G, SA, SB, A] =
  def contramap[S0](f: S0 => SA)(implicit F: Functor[F]): IndexedStateT[F, S0, SB, A] =
  def bimap[SC, B](f: SB => SC, g: A => B)(implicit F: Functor[F]): IndexedStateT[F, SA, SC, B] =
  def dimap[S0, S1](f: S0 => SA)(g: SB => S1)(implicit F: Functor[F]): IndexedStateT[F, S0, S1, A] =

 def map[B](f: A => B)(implicit F: Functor[F]): IndexedStateT[F, SA, SB, B] =
    transform { case (s, a) => (s, f(a)) }
    
 def transform[B, SC](f: (SB, A) => (SC, B))(implicit F: Functor[F]): IndexedStateT[F, SA, SC, B] =
    IndexedStateT.applyF(F.map(runF) { sfsa =>
      AndThen(sfsa).andThen { fsa =>
        F.map(fsa) { case (s, a) => f(s, a) }
      }
    })
    
  def transformF[G[_], B, SC]( f: F[(SB, A)] => G[(SC, B)])(implicit F: FlatMap[F], G: Applicative[G]): IndexedStateT[G, SA, SC, B] =
    IndexedStateT(s => f(run(s)))
    //Exmaple 
    import cats.implicits._
    type ErrorOr[A] = Either[String, A]
    val xError: IndexedStateT[ErrorOr, Int, Int, Int] = IndexedStateT.get
    val xOpt: IndexedStateT[Option, Int, Int, Int] = xError.transformF(_.toOption)
    val input = 5
    xError.run(input)
    //res0: ErrorOr[(Int, Int)] = Right((5,5))
    xOpt.run(5)
    //res1: Option[(Int, Int)] = Some((5,5))
  
  def transformS[R](f: R => SA, g: (R, SB) => R)(implicit F: Functor[F]): IndexedStateT[F, R, R, A] =
    StateT.applyF(F.map(runF) { sfsa => (r: R) =>
      val sa = f(r)
      val fsba = sfsa(sa)
      F.map(fsba) { case (sb, a) => (g(r, sb), a) }
    })  
    //Example 
    This is useful when you are working with many focused `StateT`s and want to pass in a
    global state containing the various states needed for each individual `StateT`.

    import cats.implicits._ // needed for StateT.apply
    type GlobalEnv = (Int, String)
    val x: StateT[Option, Int, Double] = StateT((x: Int) => Option((x + 1, x.toDouble)))
    val xt: StateT[Option, GlobalEnv, Double] = x.transformS[GlobalEnv](_._1, (t, i) => (i, t._2))
    val input = 5
    x.run(input)
    //res0: Option[(Int, Double)] = Some((6,5.0))
    xt.run((input, "hello"))
    //res1: Option[(GlobalEnv, Double)] = Some(((6,hello),5.0))
    
  def modify[SC](f: SB => SC)(implicit F: Functor[F]): IndexedStateT[F, SA, SC, A] =
     Modify the state (`S`) component.
  def inspect[B](f: SB => B)(implicit F: Functor[F]): IndexedStateT[F, SA, SB, B] =
    Inspect a value from the input state, without modifying the state.
  def get(implicit F: Functor[F]): IndexedStateT[F, SA, SB, SB] =
    Get the input state, without modifying the state.
 
 
 
type State[S,A] = IndexedStateT[Eval, S,S,A]

object State 
  def apply[S, A](f: S => (S, A)): State[S, A] = IndexedStateT.applyF(Now((s: S) => Now(f(s))))
    So State is IndexedStateT[Eval[S => Eval[(S, A)]], S,S,A]
  def pure[S, A](a: A): State[S, A] = State(s => (s, a))
    Return `a` and maintain the input state.
  def empty[S, A](implicit A: Monoid[A]): State[S, A] = pure(A.empty)
    Return `A` empty monoid value and maintain the input state.
  def modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
    Modify the input state and return Unit.
  def inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
    Inspect a value from the input state, without modifying the state.
  def get[S]: State[S, S] = inspect(identity)
    Return the input state without modifying it.
  def set[S](s: S): State[S, Unit] = State(_ => (s, ()))
    Set the state to `s` and return Unit.
//Exmaple 
import cats._ 
import cats.implicits._ 
import cats.data._

//Simple case 
val s = State[Double,Int] { (state:Double) =>
    println("Executed")
    //must return (Double, Int)
    (state+1, state.toInt)
    }
//must return new v:Int , map does not have access currentState 
val new_s = s.map { (v:Int)/*initiaState.toInt*/ => v * 10 }
new_s.run(10.0)/*Eval*/.value 
//Executed 
//(Double, Int) = (11.0,100)

//must return S[Double,Int], flatMap has access to currentState 
val newss = new_s.flatMap{ (v:Int)/*100*/ =>  State[Double,Int] { (state:Double)/*11*/ =>
    println("Again Executed")
    //must return (Double, Int)
    (state+1, state.toInt+v)
    //11+1 , 11+100
    } 
}
newss.run(10.0)/*Eval*/.value 
//Executed
//Again Executed
//val res20: (Double, Int) = (12.0,111)


//Using shortcut methods of object State 
//Note method[S], S is for State and method[S,A] where first type is for State 
val getDemo = State.get[Int]
// getDemo: State[Int, Int] = cats.data.IndexedStateT@796af713
getDemo.runF
//cats.Eval[Int => cats.Eval[(Int, Int)]]
getDemo.run(10).value    //run return Eval[(Int, Int)], hence .value 
// res1: (Int, Int) = (10, 10)


val setDemo = State.set[Int](30)
// setDemo: State[Int, Unit] = cats.data.IndexedStateT@f9e66fa
//run(initial: SA)(implicit F: FlatMap[F]): F[(SB, A)]
setDemo.run(10).value
// res2: (Int, Unit) = (30, ())


val pureDemo = State.pure[Int, String]("Result")
// pureDemo: State[Int, String] = cats.data.IndexedStateT@439e3ee4
pureDemo.run(10).value
// res3: (Int, String) = (10, "Result")

//inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
val inspectDemo = State.inspect[Int, String](x => s"${x}!")
// inspectDemo: State[Int, String] = cats.data.IndexedStateT@77263be4
inspectDemo.run(10).value
// res4: (Int, String) = (10, "10!")

//modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
val modifyDemo = State.modify[Int](_ + 1)
// modifyDemo: State[Int, Unit] = cats.data.IndexedStateT@44ddcbfc
modifyDemo.run(10).value
// res5: (Int, Unit) = (11, ())

//OR With for comprehension 

import cats.data.State
import State._

//Note method[S] is for State and method[S,A] where first type is for State 

// return_value_A_of_[S,A] <- State.method 
//as [S,A].flatMap fn takes A 
val program: State[Int, (Int, Int, Int)] = for {
    a <- State.get[Int]               //A=S, Returns initialState 
    _ <- State.set[Int](a + 1)        //Returns  ()
    b <- State.get[Int]               //Returns above state , ie a+1
    _ <- State.modify[Int](_ + 1)     //Return (), modify State to _ + 1
    c <- State.inspect[Int, Int](_ * 1000) //gets value after value = state * 3000 
} yield (a, b, c)
// program: State[Int, (Int, Int, Int)] = cats.data.IndexedStateT@42c9d44a

//OR - flatMap gets value and must return State (which gets state as well) , map gets only value 
State.get[Int].flatMap{ (a:Int)/*state*/ => State[Int,Int]{ state => (state, a) }}
State.get[Int].flatMap{ (a:Int) /*state*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/*()*/ => State[Int,Unit]{ state => (state, ()) }}
}
State.get[Int].flatMap{ (a:Int) /*state*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/*()*/ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => State[Int,Int]{ state => (state, a) }}
    }
}
State.get[Int].flatMap{ (a:Int)/*state*/ => 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/* () */ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => 
            State.modify[Int](_ + 1)/*State[S,()], state=state+1*/.flatMap{ (v2:Unit) /*()*/ =>   State[Int,Unit]{ state => (state, ()) }}
        }
    }
}

val program = State.get[Int].flatMap{ (a:Int) /*state*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/* () */ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => 
            State.modify[Int](_ + 1)/*State[S,()], state=state+1*/.flatMap{ (v2:Unit) /*()*/ =>  
                State.inspect[Int, Int](_ * 1000)/*State[Int, Int], v=state*1000*/.map { (c:Int)/*v*/ => 
                    (a,b,c) 
               }
            }
        }
    }
}

val (state, result) = program.run(1).value
// state: Int = 3
// result: (Int, Int, Int) = (1, 2, 3000)
 
///example  State from cats - postorder calculation 
https://github.com/typelevel/cats/blob/master/core/src/main/scala/cats/data/IndexedStateT.scala

import cats._ 
import cats.implicits._ 
import cats.data._

//State[S,A] = S => (S,A) , where state=S, computation is A 
type CalcState[A] = State[List[Int], A] //S is List[A]
//Monad can take only one type, fix one if you have two types


  
/* All operations should be 
State[List[Int], Int] { oldState =>
     val newState = someTransformation(oldState)
     val result    = someCalculation
     (newState, result)
 }
*/
 
//Simply push the operands 
//apply[S, A](f: S => (S, A)): State[S, A] 
def operand(num: Int): CalcState[Int] =
    State[List[Int], Int] { stack => //state , List[Int]
        println(s"operand, state=$stack")
        (num :: stack, num)
}
    
def operator(func: (Int, Int) => Int): CalcState[Int] =
   State[List[Int], Int] { //state , List[Int]
       case b :: a :: tail =>
         println(s"operator, state=${b :: a :: tail}")
         val ans = func(a, b)
         (ans :: tail, ans)
       case _ =>
         sys.error("Fail!")
}  

def evalOne(sym: String): CalcState[Int] =
  sym match {
      case "+" => operator(_ + _)
      case "-" => operator(_ - _)
      case "*" => operator(_ * _)
      case "/" => operator(_ / _)
      case num => operand(num.toInt)
  }
  
//0.pure[CalcState] ie CalcState[Int].pure(0) = State[List[Int], 0)
def evalAll(input: List[String]): CalcState[Int] =
   input.foldLeft(0.pure[CalcState]) { (state, ele) => //a : State[List[Int], Int] , b:String 
       state.flatMap(_ => evalOne(ele)) 
       // _ is value, Int , evalOne returns CalcState 
       //a.flatMap() return CalcState which becomes input in next iteration 
   }
   
val program = evalAll(List("1", "2", "+", "3", "*"))
//program.runF
//cats.Eval[List[Int] => cats.Eval[(List[Int], Int)]]

//Takes initial State , List[Int]
//Run return Eval, so .value 
program.run(Nil).value 
/*
operand, state=List()
operand, state=List(1)
operator, state=List(2, 1)
operand, state=List(3)
operator, state=List(3, 3)
val res11: (List[Int], Int) = (List(9),9)
*/


// Get the state, ignore the result:
val justTheState = program.runS(Nil).value

// Get the result, ignore the state:
val justTheResult = program.runA(Nil).value

//OR 
val program = for {
    _    <- evalOne("1")
    _    <- evalOne("2")
    ans <- evalOne("+")
} yield ans

val (state, result) = program.run(Nil).value
//val state: List[Int] = List(3)
//val result: Int = 3
/*
class State:
     def __init__(self, runF): # lambda S : (S, A)
        self.runF = runF 
     def __str__(self):
        return f"State({self.runF})"
     def run(self, state):
        return self.runF(state)
     def flatMap(self, fnAToState): # lambda A : State 
         def inner(state):
            new_state, a = self.runF(state)
            return fnAToState(a).runF(new_state) #(S, B)
         return State(inner)
     def map(self, fnA):  # lambda A : B
        def fn(a):
            return State( lambda s: (s, fnA(a)))
        return self.flatMap(fn)


def ns(state):
    print("Executed")
    return (state+1, int(state))

s = State(ns)
new_s = s.map(lambda a : a*10)
new_s.run(10.0)
#Executed
#(11.0, 100)

def nss(state, a):
    print("Again Executed")
    return (state+1, int(state)+a)

newss = new_s.flatMap(lambda a: State(lambda s, a=a: nss(s,a=a)))
newss.run(10.0)
#Executed
#Again Executed
#(12.0, 111)
newss1 = newss.flatMap(lambda a: State(lambda s, a=a: nss(s,a=a)))
newss1.run(10.0)
#Executed
#Again Executed
#Again Executed
#(13.0, 123)

#Complex example 
def operand(num): #State[ (), int]
    def inner_operand(stack):
        print(f"operand, state={stack}")
        return ( (num,) + stack , num)
    return State(inner_operand) 

def operator(func):     # (Int, Int) => Int
    def inner_operator(stack):
        b,a,*tail = stack 
        print(f"operator, state={stack}")
        ans = func(a,b)
        return ( (ans,)+ tuple(tail), ans)
    return State(inner_operator)

def evalOne(sym, convertFn=int): #str
    ops = { '+' : lambda : operator(lambda a,b: a+b),
            '-' : lambda : operator(lambda a,b: a-b),
            '*' : lambda : operator(lambda a,b: a*b),
            '/' : lambda : operator(lambda a,b: a/b), }
    default = lambda e=sym: operand(convertFn(e))
    return ops.get(sym, default)()    

from functools import reduce 

def evalAll(input, convertFn=int, defaultV=0): # tuple[String]
    def inner_evalall(state, ele):
        return state.flatMap( lambda _ : evalOne(ele, convertFn))
    return reduce(inner_evalall, input, State(lambda s: (s, defaultV)))

program = evalAll(("1", "2", "+", "3", "*"))
program.run( () )
#operand, state=()
#operand, state=(1,)
#operator, state=(2, 1)
#operand, state=(3,)
#operator, state=(3, 3)
#((9,), 9)
*/

///Reader monad
The Reader will have access to read-only system properties. 
Because of this, the reader monad is often known as a mechanism for dependency injection
because it takes some outside configuration and makes it available for the function it wraps.

final case class Reader[R, A](runF: R => A) {
  def compose[B](f: A => Reader[R, B]): Reader[R, B] =
    Reader { r: R =>
      f(runF(r)/*A*/).runF(r) //B
    }
}

object Reader {
  def apply[R, A](f: R => A): Reader[R, A] = Reader(f)
}


implicit def readerMonad[R] = new Monad[Reader[R, *]] {
  override def pure[A](a: A): Reader[R, A] = Reader(_ => a)
  override def flatMap[A, B](a: Reader[R, A])(f: A => Reader[R, B]):  Reader[R, B] = a.compose(f)
}
///Reader monad from cats 
type Reader[A,B] = Kleisli[Id, A,B]

case class Kleisli[F[_], -A, B](run: A => F[B])
  def ap[C, D, AA <: A](f: Kleisli[F, AA, C])(implicit F: Apply[F], ev: B As (C => D)): Kleisli[F, AA, D] 
  def dimap[C, D](f: C => A)(g: B => D)(implicit F: Functor[F]): Kleisli[F, C, D] 
  def map[C](f: B => C)(implicit F: Functor[F]): Kleisli[F, A, C] 
  def mapF[N[_], C](f: F[B] => N[C]): Kleisli[N, A, C] 
  def mapK[G[_]](f: F ~> G): Kleisli[G, A, B] 
  def flatMap[C, AA <: A](f: B => Kleisli[F, AA, C])(implicit F: FlatMap[F]): Kleisli[F, AA, C] 
  def flatMapF[C](f: B => F[C])(implicit F: FlatMap[F]): Kleisli[F, A, C] 
  def andThen[C](f: B => F[C])(implicit F: FlatMap[F]): Kleisli[F, A, C] 
  def andThen[C](k: Kleisli[F, B, C])(implicit F: FlatMap[F]): Kleisli[F, A, C] 
  def compose[Z, AA <: A](f: Z => F[AA])(implicit F: FlatMap[F]): Kleisli[F, Z, B] 
  def compose[Z, AA <: A](k: Kleisli[F, Z, AA])(implicit F: FlatMap[F]): Kleisli[F, Z, B]
  def traverse[G[_], AA <: A](f: G[AA])(implicit F: Applicative[F], G: Traverse[G]): F[G[B]] 
  def lift[G[_]](implicit G: Applicative[G]): Kleisli[λ[α => G[F[α]]], A, B] 
  def local[AA](f: AA => A): Kleisli[F, AA, B]
  def lower(implicit F: Applicative[F]): Kleisli[F, A, F[B]] 
  def first[C](implicit F: Functor[F]): Kleisli[F, (A, C), (B, C)] 
  def second[C](implicit F: Functor[F]): Kleisli[F, (C, A), (C, B)] 
  def tap[AA <: A](implicit F: Functor[F]): Kleisli[F, AA, AA] 
  def tapWith[C, AA <: A](f: (AA, B) => C)(implicit F: Functor[F]): Kleisli[F, AA, C]
  def tapWithF[C, AA <: A](f: (AA, B) => F[C])(implicit F: FlatMap[F]): Kleisli[F, AA, C] 
  def toReader: Reader[A, F[B]] 
  def apply(a: A): F[B] 
  
object Kleisli    
  def applyK[F[_], A](a: A): Kleisli[F, A, *] ~> F 
  def liftF[F[_], A, B](x: F[B]): Kleisli[F, A, B] 
  def liftK[F[_], A]: F ~> Kleisli[F, A, *] 
  def pure[F[_], A, B](x: B)(implicit F: Applicative[F]): Kleisli[F, A, B]
  def ask[F[_], A](implicit F: Applicative[F]): Kleisli[F, A, A] 
  def local[M[_], A, R](f: R => R)(fa: Kleisli[M, R, A]): Kleisli[M, R, A]
  def fromFunction[M[_], R]: KleisliFromFunctionPartiallyApplied[M, R] 
  def liftFunctionK[F[_], G[_], A](f: F ~> G): Kleisli[F, A, *] ~> Kleisli[G, A, *] 


import cats._ 
import cats.implicits._ 
import cats.data._

Note flatMap and map, Fn both gets A , flatMap Fn must return Reader[R,B] eg via Reader { R => B }
wherease map Fn returns B such that map and flatMap both returns Reader[R,B]

//Simple case 
case class Configuration(v:String)

val s = Reader[Configuration,String] { (conf:Configuration) =>
    println("Executed")
    //must return String
    "first"
    }
//must return new v:String , map does not have access Configuration 
val new_s = s.map { (v:String)/*first*/ => s"map_$v" }
scala> new_s.run(Configuration("conf"))/*Id*/
//Executed
//cats.Id[String] = mapFirst

//flatMap has access to Configuration 
val newss = new_s.flatMap{ (v:String)/*map_first*/ =>  Reader[Configuration,String] { 
(conf:Configuration) =>
    println("Again Executed")
    //must return String
    s"${v}_flatMap_${conf.v}"    
  } 
}
newss.run(Configuration("conf"))/*Id*/
//OR 
newss(Configuration("conf")) //apply 
//Executed
//Again Executed
//val res36: cats.Id[String] = map_first_flatMap_conf

//Complex Usagecase 
The classic use of Readers is to build programs that accept a configuration
as a parameter. 
Our configuration will consist of two databases: a list of valid users
and a list of their passwords


final case class Db(
     usernames: Map[Int, String],
     passwords: Map[String, String]
)

type DbReader[A] = Reader[Db, A]  //Reader[R,A] , R ie db is configuration 

def findUsername(userId: Int): DbReader[Option[String]] =
   Reader(db => db.usernames.get(userId))
   
def checkPassword(username: String, password: String): DbReader[Boolean] =
   Reader(db => db.passwords.get(username).contains(password))
   
//Finally create a checkLogin method to check the password for a given user ID. 
//Flatmap Fn takes always A ,  A <- Reader[R,A]
def checkLogin( userId: Int, password: String): DbReader[Boolean] =
   for {
      username /*Option[String]*/  <- findUsername(userId)  //flatMap 
      passwordOk /*Boolean*/ <- username.map { username /*String*/ =>
                         checkPassword(username, password) /*DbReader[Boolean]*/
                    }/*Option[DbReader[Boolean]]*/.getOrElse {
                         false.pure[DbReader]
                    }
   } yield passwordOk

val users = Map(
     1 -> "dade",
     2 -> "kate",
     3 -> "margo"
 )

val passwords = Map(
     "dade"   -> "zerocool",
     "kate"   -> "acidburn",
     "margo" -> "secret"
 )


val db = Db(users, passwords)

//run returns Id 
checkLogin(1, "zerocool").run(db)
// res7: cats.package.Id[Boolean] = true
checkLogin(4, "davinci").run(db)
// res8: cats.package.Id[Boolean] = false



///Writer monad
Its main purpose is to provide a facility to write into some kind of log by passing 
this log between computations. 

The Writer takes two type arguments, one for the log entry, W:Monoid, 
and one for the result, A. 

final case class Writer[W: Monoid, A](runF: (W, A)) {
  def compose[B](f: A => Writer[W, B]): Writer[W, B] = Writer {
    val (w, a) = runF
    val (ww, b) = f(a).runF
    val www = implicitly[Monoid[W]].combine(w, ww)
    (www, b)
  }
}

object Writer {
    def apply[W: Monoid, A](a: => A): Writer[W, A] = Writer((implicitly[Monoid[W]].identity, a))
}

implicit def writerMonad[W : Monoid] = new Monad[Writer[W, *]] {
  override def unit[A](a: => A): Writer[W, A] = Writer(a)
  override def flatMap[A, B](a: Writer[W, A])(f: A => Writer[W, B]):  Writer[W, B] = a.compose(f)
}


///Example from cats 
type Writer[W,V] = WriterT[Id, W, V]
//syntax 
extension (a: A) 
  def tell: Writer[A, Unit] = Writer(a, ())
  def writer[W](w: W): Writer[W, A] = Writer(w, a)


case class WriterT[F[_], L, V](run: F[(L, V)]) 
  def tell(l: L)(implicit functorF: Functor[F], semigroupL: Semigroup[L]): WriterT[F, L, V] =
    mapWritten(semigroupL.combine(_, l))
      //Example:
      val writer = WriterT.liftF[Option, List[String], Int](Some(123))
      writer.tell(List("a","b","c")).tell(List("d","e","f"))
      //res0: WriterT[Option, List[String], Int] = WriterT(Some((List(a, b, c, d, e, f),123)))

  def written(implicit functorF: Functor[F]): F[L] =
    functorF.map(run)(_._1)
      //Example:
      val writer: WriterT[Option, List[String], Int] = WriterT.liftF(Some(123))
      writer.tell(List("a","b","c")).written.getOrElse(Nil)
      //res0: List[String] = List(a, b, c)

  def value(implicit functorF: Functor[F]): F[V] =
    functorF.map(run)(_._2)
       //Example:
       val writer: WriterT[Option, List[String], Int] = WriterT.liftF(Some(123))
       val wt: WriterT[Option, List[String], Int] = writer.tell(List("error"))
       //res0: WriterT[Option, List[String], Int] = WriterT(Some((List(error),123)))
       wt.value
       //res1: Option[Int] = Some(123)

  def listen(implicit F: Functor[F]): WriterT[F, L, (V, L)] =
    WriterT(F.map(run) { case (l, v) =>
      (l, (v, l))
    })
    //Example:
    val writer: WriterT[Option, String, Int] = WriterT.liftF(Some(123))
    val wt: WriterT[Option, String, Int] = writer.tell("error").tell(" log")
    //res0: WriterT[Option, String, Int] = WriterT(Some((error log,123)))
    wt.listen
    //res1: WriterT[Option, String, (Int,String)] = WriterT(Some((error log,(123,error log))))

  def ap[Z](f: WriterT[F, L, V => Z])(implicit F: Apply[F], L: Semigroup[L]): WriterT[F, L, Z] =
    WriterT(F.map2(f.run, run) { case ((l1, fvz), (l2, v)) =>
      (L.combine(l1, l2), fvz(v))
    })
    //Example:
    val writer: WriterT[Option, String, Int] = WriterT.liftF(Some(123))
    val wt: WriterT[Option, String, Int] = writer.tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(Some((error,123)))
    val func = WriterT.liftF[Option, String, Int => List[Int]](Some(i => List(i)))
    val func2 = func.tell("log")
    wt.ap(func2)
    //res1: WriterT[Option, String, List[Int]] = WriterT(Some((logerror,List(123))))
  
  def map[Z](fn: V => Z)(implicit functorF: Functor[F]): WriterT[F, L, Z] =
    WriterT {
      functorF.map(run) { z =>
        (z._1, fn(z._2))
      }
    }
    //Example:
    val wr1: WriterT[Option, String, Int] = WriterT.liftF(None)
    val wr2 = wr1.tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(None)
    scala> wr2.map(_ * 2)
    //res1: WriterT[Option, String, Int] = WriterT(None)
    val wr3: WriterT[Option, String, Int] = WriterT.liftF(Some(456))
    val wr4 = wr3.tell("error")
    wr4.map(_ * 2)
    //res2: WriterT[Option, String, Int] = WriterT(Some((error,912)))

  def imap[Z](f: V => Z)(g: Z => V)(implicit F: Invariant[F]): WriterT[F, L, Z] =
    WriterT {
      F.imap(run)(z => (z._1, f(z._2)))(z => (z._1, g(z._2)))
    }
    //Example:
    val wr1: WriterT[Option, String, Int] = WriterT.liftF(Some(123))
    val wr2 = wr1.tell("log...")
    wr2.imap(_ * 2)(_ / 2)
    //res0: WriterT[Option, String, Int] = WriterT(Some((log...,246)))

  def flatMap[U](f: V => WriterT[F, L, U])(implicit flatMapF: FlatMap[F], semigroupL: Semigroup[L]): WriterT[F, L, U] =
    WriterT {
      flatMapF.flatMap(run) { lv =>
        flatMapF.map(f(lv._2).run) { lv2 =>
          (semigroupL.combine(lv._1, lv2._1), lv2._2)
        }
      }
    }
    //Example:
    val wr1 = WriterT.liftF[Option, String, Int](Some(123)).tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(Some(error,123))
    val func = (i:Int) => WriterT.liftF[Option, String, Int](Some(i * 2)).tell(i.show)
    wr1.flatMap(func)
    //res1: WriterT[Option, String, Int] = WriterT(Some((error123,246)))

  def mapBoth[M, U](f: (L, V) => (M, U))(implicit functorF: Functor[F]): WriterT[F, M, U] =
    WriterT(functorF.map(run)(f.tupled))
    //Example:
    val wr1 = WriterT.liftF[Option, String, Int](Some(123)).tell("quack")
    //res0: WriterT[Option, String, Int] = WriterT(Some(quack,123))
    wr1.mapBoth((s,i) => (s + " " + s, i * 2))
    //res1: WriterT[Option, String, Int] = WriterT(Some((quack quack,246)))

  def bimap[M, U](f: L => M, g: V => U)(implicit functorF: Functor[F]): WriterT[F, M, U] =
    mapBoth((l, v) => (f(l), g(v)))

  def mapWritten[M](f: L => M)(implicit functorF: Functor[F]): WriterT[F, M, V] =
    mapBoth((l, v) => (f(l), v))
    //Example:
    val writer = WriterT.liftF[Option, String, Int](Some(246)).tell("error")
    //res0: WriterT[Option, String, Int] = WriterT(Some((error,246)))
    writer.mapWritten(i => List(i))
    //res1: WriterT[Option, List[String], Int] = WriterT(Some((List(error),246)))

  def swap(implicit functorF: Functor[F]): WriterT[F, V, L] =
    mapBoth((l, v) => (v, l))

  def reset(implicit monoidL: Monoid[L], functorF: Functor[F]): WriterT[F, L, V] =
    mapWritten(_ => monoidL.empty)

  def show(implicit F: Show[F[(L, V)]]): String = F.show(run)

  def foldLeft[C](c: C)(f: (C, V) => C)(implicit F: Foldable[F]): C =
    F.foldLeft(run, c)((z, lv) => f(z, lv._2))

  def foldRight[C](lc: Eval[C])(f: (V, Eval[C]) => Eval[C])(implicit F: Foldable[F]): Eval[C] =
    F.foldRight(run, lc)((lv, z) => f(lv._2, z))
    
  def traverse[G[_], V1](f: V => G[V1])(implicit F: Traverse[F], G: Applicative[G]): G[WriterT[F, L, V1]] =
    G.map(
      F.traverse(run)(lv => G.tupleLeft(f(lv._2), lv._1))
    )(WriterT.apply)

  def compare(that: WriterT[F, L, V])(implicit Ord: Order[F[(L, V)]]): Int =
    Ord.compare(run, that.run)

object WriterT 
  def liftF[F[_], L, V](fv: F[V])(implicit monoidL: Monoid[L], F: Applicative[F]): WriterT[F, L, V] =
    WriterT(F.map(fv)(v => (monoidL.empty, v)))

  def liftK[F[_], L](implicit monoidL: Monoid[L], F: Applicative[F]): F ~> WriterT[F, L, *] =
    new (F ~> WriterT[F, L, *]) { def apply[A](a: F[A]): WriterT[F, L, A] = WriterT.liftF(a) }

  def putT[F[_], L, V](vf: F[V])(l: L)(implicit functorF: Functor[F]): WriterT[F, L, V] =
    WriterT(functorF.map(vf)(v => (l, v)))

  def put[F[_], L, V](v: V)(l: L)(implicit applicativeF: Applicative[F]): WriterT[F, L, V] =
    WriterT.putT[F, L, V](applicativeF.pure(v))(l)

  def tell[F[_], L](l: L)(implicit applicativeF: Applicative[F]): WriterT[F, L, Unit] =
    WriterT.put[F, L, Unit](())(l)

  def value[F[_], L, V](v: V)(implicit applicativeF: Applicative[F], monoidL: Monoid[L]): WriterT[F, L, V] =
    WriterT.put[F, L, V](v)(monoidL.empty)

  def valueT[F[_], L, V](vf: F[V])(implicit functorF: Functor[F], monoidL: Monoid[L]): WriterT[F, L, V] =
    WriterT.putT[F, L, V](vf)(monoidL.empty)

//Use Writer 
extension (a: A) 
  def tell: Writer[A, Unit] = Writer(a, ())
  def writer[W](w: W): Writer[W, A] = Writer(w, a)
case class Writer[L,V] 
    def written: Id[L]
    def value: Id[V]
    def run: Id[(L,V)]
    def map[Z](fn: V => Z): Writer[L, Z]
    def flatMap[U](f: V => Writer[L, U])(implicit semigroupL: Semigroup[L]): Writer[L, U]
    def mapBoth[M, U](f: (L, V) => (M, U)): Writer[M, U]
    def mapWritten[M](f: L => M): Writer[M, V] 
    def swap: Writer[V, L] 
    def reset(implicit monoidL: Monoid[L]): Writer[L, V] 
    def show: String 
    def foldLeft[C](c: C)(f: (C, V) => C): C
  
  
Note Writer[W,A], flatMap and map, Fn both gets A , flatMap Fn must return Writer[R,B] 
eg via Writer { returns (W,B) or via b.tell or b.writer(w:W) }
wherease map Fn returns B such that map and flatMap both returns Writer[R,B] 


import cats._ 
import cats.implicits._ 
import cats.data._

//If we have a log and no result we can create a Writer[Unit] using the 'tell'
Vector("msg1", "msg2", "msg3").tell
// res2: Writer[Vector[String], Unit] = WriterT( (Vector("msg1", "msg2", "msg3"), ()) )

val b = 123.writer(Vector("msg1", "msg2", "msg3"))
// b: Writer[Vector[String], Int] = WriterT((Vector("msg1", "msg2", "msg3"), 123) )

b.value  // Int = 123
b.written
// aLog: Vector[String] = Vector("msg1", "msg2", "msg3")

//We can extract both values at the same time using the run method:
val (log, result) = b.run
// log: Vector[String] = Vector("msg1", "msg2", "msg3")
// result: Int = 123

b.flatMap{ (v:Int) =>
            Writer( Vector("msg4"), v+10 )
         }.flatMap { (v:Int) =>
            (v+20).writer( Vector("msg5") )
         }.flatMap{ (v:Int) =>
            Vector("msg6").tell.map{ (v1:Unit) => v+30}
         }.run 
         
type Logged[A] = Writer[Vector[String], A] //joins via Vector.combine 

// flatMap_arg <- Writer[L,V]
val writer1 = for {
   a <- 10.pure[Logged]   //Writer((Vector(),10))//10
   _ <- Vector("a", "b", "c").tell   //Unit
   b <- 32.writer(Vector("x", "y", "z")) //32
 } yield a + b
 // writer1: cats.data.WriterT[cats.package.Id, Vector[String], Int] = WriterT((Vector("a", "b", "c", "x", "y", "z"), 42) )
//OR 
10.pure[Logged].flatMap( a => Vector("a", "b", "c").tell.flatMap( _ => 
    32.writer(Vector("x", "y", "z")).map ( b => (a+b) )))

writer1.run
// res3: (Vector[String], Int) = (Vector("a", "b", "c", "x", "y", "z")        , 42)


//Complex example 
Writers are useful for logging operations in multithreaded environments.

The factorial function below computes a factorial and prints out the inter
mediate steps as it runs. The slowly helper function ensures this takes a while
to run, even on the very small examples below:

import cats._ 
import cats.implicits._ 
import cats.data._

def slowly[A](body: => A) =
     try body finally Thread.sleep(100)


def factorial(n: Int): Int = {
     val ans = slowly(if(n == 0) 1 else n * factorial(n - 1))
     println(s"fact $n $ans")
     ans
 }

factorial(5)
// fact 0 1
// fact 1 1
// fact 2 2
// fact 3 6
// fact 4 24
// fact 5 120
// res9: Int = 120

If we start several factorials in parallel, the log messages can become inter
leaved on standard out. This makes it difficult to see which messages come
from which computation:

import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.duration._

//vector of Future => Future of Vector 
Await.result(Future.sequence(Vector(
    Future(factorial(5)),
    Future(factorial(5))
)), 5.seconds)


//Solution 

 
//In our case
type Logged[A] = Writer[Vector[String], A] //joins via Vector.combine 

def slowly[A](body: => A) =
     try body finally Thread.sleep(100)

def factorial(n: Int): Logged[Int] =
    for {
        ans <- if(n == 0) {
                1.pure[Logged]
            } else {
                slowly(factorial(n - 1).map(_ * n)) // map from Writer 
            }
        _  <- Vector(s"fact $n $ans").tell
    } yield ans


val (log, res) = factorial(5).run
 // log: Vector[String] = Vector(
 //     "fact 0 1",
 //     "fact 1 1",
 //     "fact 2 2",
 //     "fact 3 6",
 //     "fact 4 24",
 //     "fact 5 120"
 // )
 // res: Int = 120


Await.result(Future.sequence(Vector(
   Future(factorial(5)),
   Future(factorial(5))
 ))/* Future[Vector[Logged[Int]]] */
 .map(/*Vector[Logged[Int]]*/ _.map(/*Logged[Int]]*/_.written))  , 5.seconds)
// res: scala.collection.immutable.Vector[cats.Id[Vector[String]]] =
//     Vector(
//         Vector(fact 0 1, fact 1 1, fact 2 2, fact 3 6, fact 4 24, fact        5 120),
//         Vector(fact 0 1, fact 1 1, fact 2 2, fact 3 6, fact 4 24, fact        5 120)
//     )


///ApplicativeError and MonadError
Applicative Error
Description

ApplicativeError extends Applicative to provide handling for types that represent the quality of an exception or an error, for example, Either[E, A]
TypeClass Definition

ApplicativeError is defined by the following trait

trait ApplicativeError[F[_], E] extends Applicative[F] {
  def raiseError[A](e: E): F[A]
  def handleErrorWith[A](fa: F[A])(f: E => F[A]): F[A]
  def handleError[A](fa: F[A])(f: E => A): F[A]
  def attempt[A](fa: F[A]): F[Either[E, A]]
  //More functions elided
}

Use Case
Either

We can start with a less abstract way of performing a function. Here we will divide one number by another.

def attemptDivide(x: Int, y: Int): Either[String, Int] = {
   if (y == 0) Left("divisor is zero")
   else {
      Right(x / y)
   }
}

While fine in the above approach, we can abstract the Either away to support any other kind of “error” type without having to create multiple functions with different “container” types.

import cats._
import cats.implicits._

def attemptDivideApplicativeError[F[_]](x: Int, y: Int)(implicit ae: ApplicativeError[F, String]): F[Int] = {
   if (y == 0) ae.raiseError("divisor is error")
   else {
      ae.pure(x/y)
   }
}

The above method summons ApplicativeError to provide behavior representing an error where the end-user, based on type, will get their appropriate response.

ApplicativeError is an Applicative, which means all Applicative functions are available for use. One such method is pure, which will return the F[_] representation, where F could represent Either.

Another method that you will see is raiseError, which will generate the specific error type depending on what F[_] represents. If F[_] is an Either, then ae.raiseError will return Left. If F[_] represents a Validation, then ae.raiseError will return Invalid. For example, if we want to use an Either as our error representation, we can do the following:

type OnError[A] = Either[String, A]
val e: OnError[Int] = attemptDivideApplicativeError(30, 10)

or simply via assignment

val f: Either[String, Int] = attemptDivideApplicativeError(30, 10)

Validated

Given the same function attemptDivideApplicativeError, we can call that function again but with a different return type, since the ApplicativeError can support other “error” based types. Here we will use cats.data.Validated when calling attemptDivideApplicativeError. Notice that attemptDivideApplicativeError is the same as we defined above, so we make no other changes.

import cats.implicits._
import cats.data.Validated

type MyValidated[A] = Validated[String, A]
val g = attemptDivideApplicativeError[MyValidated](30, 10)

We can inline the right projection type alias, MyValidated, doing the following:

val h = attemptDivideApplicativeError[({ type T[A] = Validated[String, A]})#T](30, 10)

Or we can use KindProjector to make this more refined and readable

val j = attemptDivideApplicativeError[Validated[String, *]](30, 10)

It is an Applicative after all

As a Reminder, this is an Applicative so all the methods of Applicative are available to you to use in manipulating your values, ap, mapN, etc. In the following example, notice we are using Applicative’s map2, and of course, pure which also is a form of Applicative.

import cats.implicits._
def attemptDivideApplicativeErrorWithMap2[F[_]](x: Int, y: Int)(implicit ae: ApplicativeError[F, String]): F[_] = {
   if (y == 0) ae.raiseError("divisor is error")
   else {
     val fa = ae.pure(x)
     val fb = ae.pure(y)
     ae.map2(fa, fb)(_ / _)
   }
}

Handling Errors

ApplicativeError has methods to handle what to do when F[_] represents an error. In the following example, attemptDivideApplicativeErrorAbove2 creates an error representation if the divisor is 0 or 1 with the message “Bad Math” or “Waste of Time”.
We will feed the result from attemptDivideApplicativeErrorAbove2 into the handler method, where this method will pattern match on the message and provide an alternative outcome.

import cats.implicits._
def attemptDivideApplicativeErrorAbove2[F[_]](x: Int, y: Int)(implicit ae: ApplicativeError[F, String]): F[Int] =
  if (y == 0) ae.raiseError("Bad Math")
  else if (y == 1) ae.raiseError("Waste of Time")
  else ae.pure(x / y)

def handler[F[_]](f: F[Int])(implicit ae: ApplicativeError[F, String]): F[Int] = {
  ae.handleError(f) {
    case "Bad Math"      => -1
    case "Waste of Time" => -2
    case _               => -3
  }
}

Running the following will result in Right(-1)

handler(attemptDivideApplicativeErrorAbove2(3, 0))

handleErrorWith is nearly the same as handleError but instead of returning a value A, we will return F[_]. This could provide us the opportunity to make it very abstract and return a value from a Monoid.empty.

def handlerErrorWith[F[_], M[_], A](f: F[A])(implicit F: ApplicativeError[F, String], M:Monoid[A]): F[A] = {
  F.handleErrorWith(f)(_ => F.pure(M.empty))
}

Running the following will result in Right(0)

handlerErrorWith(attemptDivideApplicativeErrorAbove2(3, 0))

MonadError
Description

Since a Monad extends an Applicative, there is naturally a MonadError that will extend the functionality of the ApplicativeError to provide flatMap composition.
TypeClass Definition

The Definition for MonadError extends Monad which provides the methods, flatMap, whileM_. MonadError also provides error handling methods like ensure, ensureOr, adaptError, rethrow.

trait MonadError[F[_], E] extends ApplicativeError[F, E] with Monad[F] {
  def ensure[A](fa: F[A])(error: => E)(predicate: A => Boolean): F[A] 
  def ensureOr[A](fa: F[A])(error: A => E)(predicate: A => Boolean): F[A]
  def adaptError[A](fa: F[A])(pf: PartialFunction[E, E]): F[A]
  def rethrow[A, EE <: E](fa: F[Either[EE, A]]): F[A]
}

Use Case

Given a method that accepts a tuple of coordinates, it finds the closest city. For this example we will hard-code “Minneapolis, MN,” but you can imagine for the sake of In this example, you would either consult a database or a web service.

def getCityClosestToCoordinate[F[_]](x: (Int, Int))(implicit ae: ApplicativeError[F, String]): F[String] = {
  ae.pure("Minneapolis, MN")
}

Next, let’s follow up with another method, getTemperatureByCity, that given a city, possibly a city that was just discovered by its coordinates, we get the temperature for that city. Here, for the sake of demonstration, we are hardcoding a temperature of 78°F.

def getTemperatureByCity[F[_]](city: String)(implicit ae: ApplicativeError[F, String]): F[Int] = {
  ae.pure(78)
}

With the methods that we will compose in place let’s create a method that will compose the above methods using a for comprehension which interprets to a flatMap-map combination.

getTemperatureFromByCoordinates parameterized type [F[_]:MonadError[*[_], String] injects F[_] into MonadError[*[_], String] thus if the “error type” you wish to use is Either[String, *], the Either would be placed in the hole of MonadError, in this case, MonadError[Either[String, *], String]

getTemperatureFromByCoordinates accepts a Tuple2 of Int and Int, and we return F which represents our MonadError which can be a type like Either or Validated. In the method, since either getCityClosestToCoordinate and getTemperatureByCity both return potential error types and they are monadic we can compose them with a for comprehension.

def getTemperatureByCoordinates[F[_]: MonadError[*[_], String]](x: (Int, Int)): F[Int] = {
  for { c <- getCityClosestToCoordinate[F](x)
        t <- getTemperatureByCity[F](c) } yield t
}

Invoking getTemperatureByCoordinates we can call it with the following sample, which will return 78.

NOTE: infix -> creates a Tuple2. 1 -> "Bob" is the same as (1, "Bob")

type MyEither[A] = Either[String, A]
getTemperatureByCoordinates[MyEither](44 -> 93)

With TypeLevel Cats, how you structure your methods is up to you, if you wanted to create getTemperatureByCoordinates without a Scala context bound for MonadError, but create an implicit parameter for your MonadError you can have access to some additional methods.

In the following example, we create an implicit MonadError parameter and call it me. Using the me reference, we can call any one of its specialized methods, like raiseError, to raise an error representation when things go wrong.

def getTemperatureFromByCoordinatesAlternate[F[_]](x: (Int, Int))(implicit me: MonadError[F, String]): F[Int] = {
  if (x._1 < 0 || x._2 < 0) me.raiseError("Invalid Coordinates")
  for { c <- getCityClosestToCoordinate[F](x)
        t <- getTemperatureByCity[F](c) } yield t
}




