package first

class ScalaWeather( var location: String, private val unit:String = "c", private val json:Boolean=true )  {  

   override def toString = s"ScalaWeather(${location})"
   //own components 
   private val url  = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
   def encode = s"select * from weather.forecast where woeid in (select woeid from geo.places(1) where text='${location}') and u='${unit}'"
   def base_url = s"""${url}?q=${java.net.URLEncoder.encode(encode, "UTF-8")}&"""
   def full_url = s"""${base_url}format=${if (json) "json" else "xml"} """ 
   println(full_url)
   def  get = scala.io.Source.fromURL(full_url).mkString
   
 }
 


 
object Main{
    def main(args:Array[String]){
        val location = args(0)
        val unit = if (args.size >= 2) args(1) else "c"
        val json = if (args.size >= 3) args(2).toBoolean else true 
        val w = new ScalaWeather(location, unit, json)
        println(w.get)  
    
    }
}

object Main2 extends App{
    val Array(location, unit, json) = 
        if (args.size >= 3) args.slice(0,3)
        else if (args.size == 2) args :+ "true"
        else args :+ "c" :+ "true"
    val w = new ScalaWeather(location, unit, json.toBoolean)
    println(w.get)  
}