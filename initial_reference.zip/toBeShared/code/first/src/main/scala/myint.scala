package first 

class MyInt(val x: Int) extends Ordered[MyInt]{
    def this() { this(0) }
    override def toString = s"MyInt(${this.x})"
    override def hashCode = x.hashCode
    override def equals(o:Any) = o match {
        case _:MyInt => o.hashCode == this.hashCode
        case _       => false
    }
    def +(o:MyInt) = MyInt(this.x + o.x)
    def compare(o:MyInt) = this.x compare o.x
    println("this is primary ctor")
}
object MyInt{
    def apply(x:Int) = new MyInt(x)
}

case class MyInt2(x: Int) extends Ordered[MyInt2]{
    def +(o:MyInt2) = MyInt2(this.x + o.x)
    def compare(o:MyInt2) = this.x compare o.x
}







