package web 

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.{ContentTypes, HttpEntity}
import akka.http.scaladsl.server.Directives._  //core of the Routing DSL
import akka.stream.ActorMaterializer
import scala.io.StdIn



import first.ScalaWeather

object WebServer {
  def main(args: Array[String]) {
    implicit val system = ActorSystem()
    implicit val materializer = ActorMaterializer()   //A ActorMaterializer takes the list of transformations comprising a Flow and materializes them actual values 
    implicit val executionContext = system.dispatcher  // needed for the future flatMap/onComplete in the end

    val route =
      get {
        pathSingleSlash {
          complete(HttpEntity(ContentTypes.`text/html(UTF-8)`,"<html><body>Rest Server</body></html>"))
        }
       } ~  
      get {
        (pathPrefix("get_weather" / """\w+""".r) | (pathPrefix("get_weather") & parameter("location".as[String]))) { loc =>  
            val json_str = (new ScalaWeather(loc)).getModifiedJsonString
            complete(HttpEntity(ContentTypes.`application/json`, json_str))
        }        
      }~  
      get {
        (pathPrefix("get_weather_xml" / """\w+""".r / """\w+""".r) | (pathPrefix("get_weather_xml") & parameters("location" ,"format" ? "xml"))) {(loc, format) =>  
            val xm = (new ScalaWeather(loc)).getModifiedXMLString
            val prefix = """<?xml version="1.0"?>"""
            complete(HttpEntity(ContentTypes.`text/xml(UTF-8)`,prefix+"\n"+xm.toString))
        }        
      }

    // `route` will be implicitly converted to `Flow` using `RouteResult.route2HandlerFlow`
    val bindingFuture = Http().bindAndHandle(route, "localhost", 8080)
    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done
  }
}