Place files like custom.properties and jre.properties here. Files
placed here will be copied to the Karaf etc/ directory.

Exclude the Karaf default version of the file in bin.xml.

Additional configuration files for etc should be placed into
src/main/resources/etc.
