

import akka.actor._
import local.Rational




object Prog9Remote extends App  {
  val system = ActorSystem("SrvSystem")
  val remoteActor = system.actorOf(Props[Server], name = "Server")
  //Thread.sleep(1000000)//no need as actor is not terminated 
 }

class Server extends Actor {
  
  def receive = {
    case Rational(a, b) =>
		println(s"$a,$b" )
		val result : Float = a.toFloat / b.toFloat
        sender ! (f"$result%.2f")
	case "stop" =>
        context.stop(self)
    case _ =>
        println("Unknown msg")
    }
}
