
import akka.actor._
import local.Rational

object Prog9Client extends App {

  implicit val system = ActorSystem("CliSystem")
  val localActor = system.actorOf(Props[Client], name = "Client")  // the local actor
  localActor ! "start"                                             // Send a message 
}

class Client extends Actor {

  // create the remote actor
  val remote = context.actorSelection("akka.tcp://SrvSystem@127.0.0.1:2552/user/Server")  //actorFor("akka://SrvSystem/user/Server")    //
  var a = 0
  var b = 0

  def receive = {
    case "start" =>
        println("Type two integers and press return OR 0,0 for exit")
		a = readInt
		//println(a)
		b = readInt
		//println(b)
		if (a == 0 && b == 0) {
			//remote ! "stop"
			context.stop(self)
			context.system.terminate()
			}
		else { remote ! Rational(a, b) }
    case res:String  =>
        println(s"Result : $res" )
		self ! "start"
    case _ =>
        println("Unknown msg")
  }
}
