package first;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedInputStream;

public class JavaWeather {
    String location;
    String unit ;
    boolean json  ;
    String full_url;
    
    public JavaWeather (String location , String unit, boolean json )  {  
        this.location = location;
        this.unit = unit;
        this.json = json;
        _build();
    }
    public JavaWeather (String location , String unit)  {  
        this(location, unit, true);
    }
    public JavaWeather (String location )  {  
        this(location, "c", true);
    }
    @Override
    public String toString() 
    { 
        String str = "JavaWeather("+this.location+")";
        return str ;
    } 

   private void _build(){
       String  url  = "http://query.yahooapis.com/v1/public/yql";
       String encode = String.format("select * from weather.forecast where woeid in (select woeid from geo.places(1) where text='%s') and u='%s'", location, unit);
       String base_url = "";
       try {
            base_url = String.format("%s?q=%s&", url, URLEncoder.encode(encode, "UTF-8"));
         } catch(Exception  ex) {
            System.out.println(ex.getMessage()); 
         }
       if (json)
            this.full_url = String.format("%sformat=json",base_url);
       else 
            this.full_url = String.format("%sformat=xml",base_url);
       System.out.println(full_url);
   }
   public String  get(){
   try {
        URL url = new URL(full_url);
        BufferedInputStream bis = new BufferedInputStream(url.openStream());
        int count=0;
        byte[] buffer = new byte[1024];
        String strFileContents = ""; 
        while((count = bis.read(buffer,0,1024)) != -1)
        {
             strFileContents += new String(buffer, 0, count);
        }
        bis.close();
        return strFileContents;
      } catch(Exception  ex) {
            System.out.println(ex.getMessage()); 
            return "";
         }
 }
 
}