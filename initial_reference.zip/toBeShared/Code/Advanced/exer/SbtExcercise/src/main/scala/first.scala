package first

import play.api.libs.json._

class ScalaWeather( var location: String, private val unit:String = "c", private val json:Boolean=true )  {  

   override def toString = s"ScalaWeather(${location})"

   //own components 
   private val url  = "http://query.yahooapis.com/v1/public/yql"
   def encode = s"select * from weather.forecast where woeid in (select woeid from geo.places(1) where text='${location}') and u='${unit}'"
   def base_url = s"""${url}?q=${java.net.URLEncoder.encode(encode, "UTF-8")}&"""
   def full_url = s"""${base_url}format=${if (json) "json" else "xml"} """ 
   println(full_url)
   def  get = scala.io.Source.fromURL(full_url).mkString
   //Advanced 
   def get_xml = {
     val string = if(!json) get else (new ScalaWeather(this.location,this.unit,false)).get
     scala.xml.XML.loadString(string)
   }
   def get_json = {
        val string = if(json) get else (new ScalaWeather(this.location,this.unit,true)).get
        Json.parse(string)
   }
    //pretty advanced 
   def getModifiedXMLString = {
    /*   
    x \ "results" \ "channel" \ "item" \ "forecast" map{ e => e \@ "high"}    
    x \\ "forecast" map{ e => e \@ "high"}
    
     <forcasts>
        <weather date=todays_date>
        <text>  </text>
        <high>  </high>
        <low>   </low>
        </weather>
    </forecasts>
    */
    def  snippets(e:scala.xml.Node) = <weather date={e \@ "date"}>
                    <text>{e \@ "text"}</text>
                    <high>{e \@ "high"}</high>
                    <low>{e \@ "low"}</low>
                    </weather>
    
    val xmlValue = this.get_xml 
    val result = <forecasts> {  xmlValue \ "results" \ "channel" \ "item" \ "forecast" map(e => snippets(e))}</forecasts>
   
    result.toString
   }

   def getModifiedJsonString ={
      val jsvalue = this.get_json 
      /*    
       //this returns Seq[JsValue]      
       (jsvalue \\ "forecast").map{_.as[JsArray]}.flatMap(_.value).flatMap{ case e:JsObject => 
                   Map( (e \ "date").as[String] -> 
                            Map("text" -> (e \ "text").as[String],
                                 "low" ->  (e \ "low").as[String],
                                 "high" -> (e \ "high").as[String]
                                )
                        )}.toMap
       }
      
      { 'todays_date':{'text': .., 'high':..., 'low': ..}, 'tomorrow_date': {...} .. like five days data}
      
      */
      val arr = (jsvalue \ "query" \ "results" \ "channel" \ "item" \ "forecast").as[JsArray]
      val obj = arr.value.flatMap{case e:JsObject => 
                        Map( (e \ "date").as[String] -> 
                                Map("text" -> (e \ "text").as[String],
                                     "low" ->  (e \ "low").as[String],
                                     "high" -> (e \ "high").as[String]
                                    )
                            )}.toMap
      val json = Json.toJson(obj)
      json.toString         
   }
 }

 object Main extends App{
    val location = args(0)
    val unit = if (args.size >= 2 ) args(1) else "c"
    val json = if (args.size >= 3 ) args(2).toBoolean else true
    val w = new ScalaWeather(location, unit, json)
    println(w.get)
 }
 
 object Main2  {         			 
	def main(args: Array[String]) {  
		val location = args(0)
        val unit = if (args.size >= 2 ) args(1) else "c"
        val json = if (args.size >= 3 ) args(2).toBoolean else true
        val w = new ScalaWeather(location, unit, json)
        println(w.get)
	}
 }
 
