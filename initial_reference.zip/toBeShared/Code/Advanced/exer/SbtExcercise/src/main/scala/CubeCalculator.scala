package support 

object CubeCalculator extends App {
  def cube(x: Int) = {
    x * x * x
  }
  //write here main code 
  args foreach println
}
/* OR 
object Stub {
  def main(args: Array[String]) {
   // do something
   args foreach println
  }
}
*/

class Stub {
  // do something
}