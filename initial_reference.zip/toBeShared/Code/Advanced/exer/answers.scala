JQ1: Write generic Stack class in Java or scala with below specification (10)
- size operation returns the size 
- top operation to peek top element without removing 
- pop operation which removes the top element 
- push operation which pushes into stack 

import java.util.*;

class Stack <T> {
   private ArrayList<T> stack = new ArrayList<T> ();
   private int top = 0;
   public int size () { return top; }
   public void push (T item) {
      stack.add (top++, item);   }
   public T pop () {
      return stack.remove (--top);
   }
   public T top(){
    stack.get(top);
   }
}

//Scala Stack 
class Stack[T] {
  private var elems: List[T] = Nil
  def push(x: T) { elems = x :: elems }
  def top: T = elems.head
  def pop()={ val s = top; elems = elems.tail; s }
  def size:Int = elems.size 
}
object Stack{
    def apply[T] = new Stack[T]
}

val x = Stack[Int]
x.push(17)
println(x.pop)


SQ5. Create a txt file (20)
name,age,salary
ABC,2,3.0
XYZ,2,4.0
ABCD,10,9.0
AXYZ,10,18.0
Read this file and convert to List[Person]
where Person is case class with attributes name,age,salary 
Then find  age vs sum of salary (ie groupby on age)

case class Person(name:String,age:Int,salary:Double)
val lines = scala.io.Source.fromFile("../../QA/csv.txt").getLines.drop(1).map(_.trim).map(_.split(",")).map{case Array(x,y,z) =>(x,y.toInt,z.toDouble) }
val answer = lines.map{r => (Person.apply _).tupled(r)}.toList
answer.groupBy(_.age).map{case(k,v) => k -> v.map(_.salary).sum}


SQ2.Write a Class case class Complex with + operation handled and comparison possible 
Complex has two arg real, img and + adds real, real and imaginary (20)

case class Complex(re:Double, im:Double) extends Ordered[Complex]{
    def +(o:Complex) = Complex(this.re+o.re, this.im+o.im)
    def compare(o:Complex) = implicitly[Ordering[Tuple2[Double, Double]]].compare((this.re, this.im), (o.re,o.im))
    override def toString = s"""${this.re} ${if(this.im < 0)'-' else '+'} ${this.im.abs}j"""
}

//Then Create a List of few Complex numbers and do sorting on them 
import scala.util._ 
val rnd = Random
val lst = (1 to 10).toList.map{ _ => Complex(rnd.nextInt(10),rnd.nextInt(10))}
lst.sorted
lst.sortBy(_.im)
//Then create a List of few Numbers and do an operation which sum's all real parts and all imaginary parts 
lst.fold(Complex(0,0)){(r,e) => r+e}
//Or tuple way 
lst.map( Complex.unapply(_).get).foldLeft( (0.0,0.0) ){ case ( (r,i), (er,ei) ) => (r+er, i+ei) }


SQ3.Handle above class with + operation with any T  (10)
which has Numeric implicits conversion as well operation possible 
with Double(or Int widening to Double) as LHS of + operations 
//Use case 
Complex(1,2) + 2
2 + Complex(2,3)
//answers
case class Complex(re:Double, im:Double) extends Ordered[Complex]{
    def this(x:Double) {this(x,0)}
    def +(o:Complex) = Complex(this.re+o.re, this.im+o.im)
    //for RHS T 
    def +[T](o:T)(implicit ev:Numeric[T])={
        println("using +[T]")
        import ev._ 
        Complex(this.re+o.toDouble, this.im)
    }
    def compare(o:Complex) = implicitly[Ordering[Tuple2[Double, Double]]].compare((this.re, o.re), (this.im,o.im))
    override def toString = s"""${this.re} ${if(this.im < 0)'-' else '+'} ${this.im.abs}j"""
}
object Complex extends ((Double,Double) => Complex) {
    //LHS Double 
    implicit def convertNumber[T](x:T)(implicit ev:Numeric[T]) = new Complex(ev.toDouble(x))
}
//Usage 
scala>    Complex(1,2) + 2
using +[T]
res30: Complex = Complex(3.0,2.0)

scala> 2 + Complex(2,3)
res31: Complex = Complex(4.0,3.0)




SQ4. Enhance above class with Generic  T wich has numeric implicits (10)

case class Complex[T](re:T, im:T )(implicit ev: Numeric[T]) extends Ordered[Complex[T]]{
    import ev._    
    def +(o:Complex[T])= Complex(this.re+o.re, this.im+o.im)
    override def toString = s"""${this.re} ${if(this.im < Numeric.zero)'-' else '+'} ${this.im.abs}j"""
    def compare(o:Complex[T]) = implicitly[Ordering[Tuple2[T, T]]].compare((this.re, o.re), (this.im,o.im))
    //for RHS T 
    //as generic U and T are not same, only option is to convert to toDouble to add
    //But changes result type , Not implicit Double must be in scope(by default not there unlike Int)
    def +[U](o:U)(implicit ev:Numeric[U])={
        println("using +[U]")
        Complex(this.re.toDouble+ev.toDouble(o), this.im.toDouble )
    }
   def +[U](o:Complex[U])(implicit ev:Numeric[U])= Complex(this.re.toDouble+ev.toDouble(o.re), this.im.toDouble+ev.toDouble(o.im) )    
}
object Complex {
    //for LHS T, but T must match with RHS T 
    def apply[U](implicit ev:Numeric[U])(x:T) = new Complex[U](x, implicitly[Numeric[U]].zero)
    implicit def convertNumber[T :Numeric](x:T) = new Complex[T](x, implicitly[Numeric[T]].zero)
}







