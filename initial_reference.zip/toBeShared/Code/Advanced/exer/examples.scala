/*****************   Intro *******************/
//******( example : write imperative count)

val s = " I am OK"

for (c <- s) {
var count = 0
 for (c1 <- s){
	if (c == c1) {
		count = count + 1
	}	
 }
  println(s"${c} counts ${count}")
}

val wds = s.split(raw"\s+")

for (c <- wds) {
var count = 0
 for (c1 <- wds){
	if (c == c1) {
		count = count + 1
	}	
 }
  println(s"${c} counts ${count}")
}


//******(example : write count using Map and its function)

val s = "I am OK"

val wds = s.split(raw"\s+")


def count[T](xs: List[T]): Map[T,Int] = {
    val xss = xs.toSet
	val out = for { c <- xss } yield { c -> xs.count( (ch) => ch == c ) }   // c:T <- xs.toSet ... c requires type!!
	out.toMap
}

	
println(s"${count(s.toList)}")

println(s"${count(wds.toList)}")

//Adding to List

implicit class ListOPs[T](xs:List[T]) {
      def freq:Map[T,Int] = {
       val ss = xs.toSet
       val ms = ss.map( e => e -> xs.count( c => e == c))
       ms.toMap
      }
     }

"Ok Ok".toList.freq  //res20: Map[Char,Int] = Map(O -> 2, k -> 2,   -> 1)


//******(example:  Rational Case class)

trait MinMax[T]{  
   def max(other: T): T 
   def min(other:T) :T 
 
 }

case class Rational (val n: Int, val d:Int) extends  MinMax[Rational] with Ordered[Rational]   {
	require( d != 0)
		
	def this (x: Tuple2[Int,Int])  = this(x._1, x._2)
	
	def + ( other : Rational ) : Rational = {
		new Rational(  process(this.n * other.d + this.d * other.n , this.d * other.d))
	}

	def - ( other : Rational ) : Rational = {
		new Rational( process(this.n * other.d - this.d * other.n , this.d * other.d))
	}

	def * ( other : Rational ) : Rational = {
		new Rational( process(this.n * other.n, this.d * other.d))
	}
	
	def / ( other : Rational ) : Rational = {
		new Rational( process(this.n * other.d, this.d * other.n))
	}
	
	def compare(other: Rational) =   (this.n * other.d)-(other.n * this.d)      // returns -1, 0, +1
	
	def max (other: Rational) : Rational  =  if (this > other) this else other 
	def min (other: Rational) : Rational  =  if (this < other) this else other
	
    private def process(x:Int, y:Int) = {  //write GCD
    
        (x,y)
    }

}

object Rational extends ( (Int,Int) => Rational) {
	implicit def intToRational( x: Int) : Rational = new Rational(x,1)
}


val first = Rational(1,2)

first match {
	case Rational(x,y) => println(s"$x,$y")
	case _ =>
}




/*****************   Advanced *******************/

//******(example: extend stackable trait)

abstract class A { def m(x:Int)  }
class B extends A { def m(x:Int) = println(x)}


trait Square extends A { abstract override def m(x:Int) = super.m(x*x) } //calls next one in chain
trait Filter extends A { abstract override def m(x:Int) = super.m( if(x>0) x else 0) }

val b = new B with Filter
b.m(-2)  //0

val b = new B with Square with Filter   // First Filter, then Square, then B
b.m(-2) //0
b.m(2)   //4


//******(example: implement generic mean, median, sd using Numeric)
def mean[T:Numeric, C[T] <: Seq[T]](l: C[T])={    
    import Numeric.Implicits._
    if (l.isEmpty ) 0.0 else l.sum.toDouble/ l.size.toDouble
    }
    
def mean[T: Numeric](xs: Seq[T]):Double =
  implicitly[Numeric[T]].toDouble(xs.sum) / xs.size

def mean[T: Numeric](xs: Seq[T]):Double = {
   val num = implicitly[Numeric[T]]
   import num._
   xs.sum.toDouble / xs.size
  }
  
def sd[T: Numeric](xs: Seq[T]):Double = {
    val num = implicitly[Numeric[T]]
    import scala.math._
    import num._
    val  m = xs.sum.toDouble / xs.size
    if (xs.isEmpty) 0.0 else  sqrt( xs.map { x:T  => (x.toDouble-m) * (x.toDouble-m) }.sum ) / xs.size.toDouble
 }
    

def mode[T](lst: Seq[T]):T ={  					//throw clause is needed to have if's return type as T
     if (lst.isEmpty) throw new Exception("Oh") else lst.sortBy{ e => lst.count{ l => l == e} }.last       
    }
mode(List(1,2,3,4,1,3,3,4,3,4)) 

	

def median[T:Numeric](lst:Seq[T])={
    val num = implicitly[Numeric[T]]
    import num._
    val list = lst.sorted   
    val m = list.size / 2
    if (list.size % 2 == 1)   list(m).toDouble else  (list(m).toDouble + list(m+1).toDouble)/2
   }
median(List(1,2,3,4,1,3,3,4,3,4))

	
//for one or more same frequencies
def mode_multi[T:Numeric](list: Seq[T])= {
      val fr =  list.groupBy{ e => list.count{ l => l == e} } 
      val m = fr.toList.sortBy { e => e._1 }     
      mean(m.last._2.toSet.toList) 
    }
	
val l = List(1,2,3,2,1,2)
mode_multi(l)


//Put sd, mean, median, mode to List


//Way-1

class MyList[T:Numeric](xs: Seq[T]) {
    import java.lang.Math._
    def mean:Double =  implicitly[Numeric[T]].toDouble(xs.sum) / xs.size
	def mode:T = xs.sortBy{ e => xs.count{ l => l == e} }.last 
}
implicit def listToMyList[T:Numeric](l: Seq[T]) = new MyList(l)

val l = List(1, 2, 3, 2, 1, 2, 1)

l.mean //res38: Double = 1.7142857142857142

//Way-2
implicit class MyList[T:Numeric](xs: Seq[T]) {
    import java.lang.Math._
    def mean:Double =  implicitly[Numeric[T]].toDouble(xs.sum) / xs.size
	def mode:T = xs.sortBy{ e => xs.count{ l => l == e} }.last 
}

//****(example : implement default value using type class)
//for AnyRef, it can be null.asInstanceOf[T]

//:paste

class Default[+A](val default: A)

trait AnyRefType {
  // for any Reference type 
  implicit def defaultNull[A <: AnyRef]:Default[A] = new Default[A](null.asInstanceOf[A])  
}

object Default extends AnyRefType {
  def value[A](implicit ev: Default[A]): A = ev.default

  //all implicits 
  implicit object DefaultDouble extends Default[Double](0.0)
  implicit object DefaultFloat extends Default[Float](0.0F)
  implicit object DefaultInt extends Default[Int](0)
  implicit object DefaultLong extends Default[Long](0L)
  implicit object DefaultShort extends Default[Short](0)
  implicit object DefaultByte extends Default[Byte](0)
  implicit object DefaultChar extends Default[Char]('\u0000')
  implicit object DefaultBoolean extends Default[Boolean](false)
  implicit object DefaultUnit extends Default[Unit](())
  implicit object DefaultInt extends Default[String]("")

  implicit def defaultSeq[A]: Default[Seq[A]] = new Default[Seq[A]](Seq()) //as object can not have [A]
  implicit def defaultSet[A]: Default[Set[A]] = new Default[Set[A]](Set())
  implicit def defaultMap[A, B]: Default[Map[A, B]] = new Default[Map[A, B]](Map[A, B]())
  implicit def defaultOption[A]: Default[Option[A]] = new Default[Option[A]](None)

 }

Default.value[Int]   //0
//alternate implementation
case class Default[A](){
      var value:A = _
      }


Default[Int].value //res8: Int = 0

Default[Seq[_]].value //res9: Seq[Any] = null

//******(example : Size of List. write recursive dirsList and size)
@scala.annotation.tailrec 
def size[T] (xs: List[T], s:BigInt = 0 ):BigInt = {
  xs match {
     case Nil => s
     case h :: t => size(t, (1 : BigInt ) + s)
  }
}

@scala.annotation.tailrec 
def size[T] (xs: List[T], s:BigInt = 0 ):BigInt =   //tailrec OK
  if (xs.isEmpty) s else size( xs.tail, (1 : BigInt ) + s  )


def size[T, C[T]<:Seq[T]] (xs: C[T], s:BigInt = 0 ):BigInt =  //tailRec is not OK, because x.tail might return different results for different runs, unless the underlying collection type is ordered
  if (xs.isEmpty) s else size( xs.tail, (1 : BigInt ) + s  )

//tail rec max

def _max[T : Ordering ](in:List[T], mx:T = null.asInstanceOf[T]):T = in match {
  case Nil => mx
  case hd :: tl => {
       val n = implicitly[Ordering[T]]
       import n._
       _max(tl, if (hd > mx ) hd else mx )
    }
 }
 
  
 //recursive files list and size using java.io.File.listFiles and java.io.File.length
 //not tail.rec
 def filesList(dir:String):Array[java.io.File]= {
   val files = (new java.io.File(dir)).listFiles.filter { _.isFile}
   val dirs   = (new java.io.File(dir)).listFiles.filter { _.isDirectory}
   val subdirList = dirs.flatMap{ subdir =>  filesList(dir + "/" + subdir.getName ) }
   files ++ subdirList
  }   
 val total = filesList(".").map { _.length }.toList.sum
 
 
//Alternate implement
import java.io._

def getListOfSubDirectories(dir: File): List[String] = {
      val files = dir.listFiles
      val dirs = for {
        file <- files
        if file.isDirectory
      } yield file.getName
      dirs.toList
    }

//Recursive list file

def recurseDirList( dir:String) :List[String] = {
    val  lst = getListOfSubDirectories( new File(dir)).map( subdir => dir + "/" + subdir)
    if ( ! lst.isEmpty)
     lst ++ lst.flatMap( subdir => recurseDirList(subdir) )
     else Nil
}

//Files with size, tailrec
@scala.annotation.tailrec
def recurseDirList( dirs:Array[String], m: Map[java.io.File, Long] = Map()):Map[java.io.File, Long]  = {
   val files = dirs.flatMap{ dir => (new java.io.File(dir)).listFiles.filter { _.isFile}.map { f => f -> f.length }}.toMap
   val subdirs   = dirs.flatMap{ dir => (new java.io.File(dir)).listFiles.filter { _.isDirectory}.map { d => dir + "/" + d.getName }}
   //print(files);   println(subdirs.toList)
   if (subdirs.isEmpty) return m++files else recurseDirList(subdirs, m ++ files )    
}

val m = recurseDirList(Array("."))
m.toList.sortBy{ case (k,v) => v }.last


//******(example: Download concurrent 10 pages)

import scala.concurrent.{future, blocking, Future, Await, ExecutionContext.Implicits.global}
import scala.concurrent.duration._

def get(url: String) = scala.io.Source.fromURL(url).getLines.toList.mkString

// Retrieve URLs from somewhere
val urls = List("http://www.google.com",
                      "http://yahoo.com",
                      "http://bing.com",
                      "http://jskdlsycds.com", //invalid url-1
                      "http://amazon.com",
                      "http://hackerne.ws",
                      "http://firstpost.com",
                      "http://rediff.com",
                      "http://wowslskdleodd.com") //invalid url-2
//OR
val urls = Iterator.continually("http://www.google.co.in").take(10).toList

// Download image (blocking operation)
val htmls: List[Future[Int]] = urls.map {
  url => Future { blocking { get(url).length } }
}
val list:List[Int] = htmls.map { f =>  Await.result(f, 1.second)	 }

//OR using parallel Map, it returns a Future 
val fs : Future[List[Int]] = Future.traverse(urls){ url => Future{ blocking { get(url).length } } }
val list:List[Int] = Await.result(fs, Duration.Inf)


//OR Use sequence to convert imagesFuts from List[Future[...]] to a Future[List[...]].
val htmls: List[Future[Int]] = urls.map {
  url => Future { blocking { get(url).length } }
}
val fhtmls: Future[List[Int]] = Future.sequence(htmls)
val list:List[Int] = Await.result(fs, Duration.Inf)





//Future to Find Prime Number


def is_prime(np:Int):Boolean ={
        if ( np == 2) return true
        else if (np % 2 == 0)  return false
        def sqrt_n = scala.math.sqrt(np).asInstanceOf[Int]
        for (i <- 3 to (sqrt_n + 1, 2) ){
            if (np % i == 0 ) return false    
            }
        return true
    } 

val nums = List.range(3, 1000, 2)
val fs : Future[List[(Int, Boolean)]] = Future.traverse(nums){ n => Future{ (n, is_prime(n) ) } } 
val maps = Await.result(fs, Duration.Inf).toMap





//recursion - other examples



//imperative way to find seive of prime numbers
val res = scala.collection.mutable.ListBuffer.empty[Int]
var lst = (2 to 100).toList

while (! lst.isEmpty ) {
    res  += lst.head
    lst = lst.filter { i => i % res.last != 0 }
}

println(res.mkString(":"))

//recursive way

@scala.annotation.tailrec
def seive[T :Integral](res : List[T], lst :List[T]) : List[T] ={
   val num =implicitly[Integral[T]]
   import num._
   lst match {
     case Nil => res
     case hd :: tail => seive( res :+ hd , tail.filter{ i => i % hd != 0 } )
   }	
}


seive(List[Int](), (2 to 100).toList)







//Class example , MyInt with +,- and ==  and its ScalaTestCase

class MyInt(val x:Int) extends Ordered[MyInt] {

   def this() { this(0) }
   
   override def hashCode = x.hashCode
   override def toString =  s"MyInt($x)"
   override def equals(o :Any) = o match {
          case _:MyInt =>  o.hashCode == this.hashCode
		  case _ => false
		  }
    def +[T:Numeric]( o:T ) = {
	       val num = implicitly[Numeric[T]]
		   import num._
		   MyInt(this.x + o.toInt)
		 }
	def +:[T:Numeric]( o:T ) = {
	       val num = implicitly[Numeric[T]]
		   import num._
		   MyInt(this.x + o.toInt)
		 }
    def +( o:MyInt ) = MyInt(this.x + o.x)
	def compare(o:MyInt)  =  this.x compare o.x
}
object MyInt {
   def apply(x:Int) = new MyInt(x)
   object Implicits {
   implicit def intToMyInt(x:Int) = new MyInt(x)
   }
}


import org.scalatest.{FunSuite, BeforeAndAfter}

object MyIntTest extends FunSuite with BeforeAndAfter {     

  // these first two instance should be equal
  val a = MyInt(1)
  val c = MyInt(2)
  val d = MyInt(1)

  test("same == same ") { assert(a == d) }
  test("same != different") { assert(a != c ) }
  test(" + ") { assert(a + d == c) }
  test("+ Int ")  { assert(a + 1 == c ) }
  test("Int + ")  { assert(1 +: a == c) }
  test("Int +  2nd case")  { import MyInt.Implicits._ ; assert(1 + a == c) }
}

scala> org.scalatest.run(MyIntTest)


//Implement Binary Search

//items must be sorted

@scala.annotation.tailrec
def binary_search[T:Ordering](value:T, items:Seq[T], low:Int =0, hg:Int = -1):Int = {    
    val ord = implicitly[Ordering[T]]
    import ord._	
    val high = if(hg != -1) hg else items.size
    val pos = (high + low)/2
    
    if (items(pos) == value)  pos
    else if ( pos == items.size || high == low || pos == low) -1
    else if (items(pos) < value) binary_search(value, items, pos + 1, high)
    else  binary_search(value, items, low, pos)
 }



for(v <- 1 to 7)
    println(s"$v  ${binary_search(v, List(1, 2, 3, 5)) }" )
	
	






//Implement infinite prime Iterator



import  java.lang.Math._


    
def is_prime(np:Int):Boolean ={
        if ( np == 2) return true
        else if (np % 2 == 0)  return false
        def sqrt_n = sqrt(np).asInstanceOf[Int]
        for (i <- 3 to (sqrt_n + 1, 2) ){
            if (np % i == 0 ) return false    
            }
        return true
    }   

is_prime(11)  //true

class NextP extends Iterator[Int]{             //BigInt has problem with sqrt      
    private var (np:Int, first:Boolean) = (1 , true)  
    def hasNext  = true 
    def next = {  
                if(first) { first = false;  2}
                else {			 
			         np += 2
                    while( !is_prime ) { np += 2}
                    np
			       }
            }
			
	private def is_prime:Boolean ={
        if ( np == 2) return true
        else if (np % 2 == 0)  return false
        def sqrt_n = sqrt(np).asInstanceOf[Int]
        for (i <- List.range(3,sqrt_n + 1, 2) ){
            if (np % i == 0 ) return false    
            }
        return true
    }   
   }
    

    
val  f = new NextP()
f.take(100).toList


//Implement Map processing

def process[A,B](in1:Map[A,B], in2:Map[A,B]) ={
    var u_dict = collection.mutable.Map[A,B]()
    var i_dict = collection.mutable.Map[A,B]()
    var d_dict = collection.mutable.Map[A,B]()
    var x_dict = collection.mutable.Map[A,B]()
    for ( (k1,v1) <- in1){
        u_dict(k1) = in1(k1)
        if (in2 contains k1 ) {
              i_dict(k1) = in1(k1)
            }
        else{
              d_dict(k1) = in1(k1)
              x_dict(k1) = in1(k1)
            }
    }
    for ((k2,v2) <- in2){
        if ( ! (in1 contains k2) ){
            u_dict(k2) = in2(k2)
            x_dict(k2) = in2(k2)
            }
        }
    (u_dict.toMap, i_dict.toMap, d_dict.toMap, x_dict.toMap)
}            


val in1 = Map( "ok" -> 1, "nok" ->  2)
val in2 = Map( "nok" -> 2, "new" -> 3)
process(in1, in2)







	
// merge 

def merge[A,B:Numeric](in1:Map[A,B], in2:Map[A,B]) ={
    val nu = implicitly[Numeric[B]]
    var m_dict = collection.mutable.Map[A,B]()
    in1.foreach{case (k1, v1) =>
        m_dict(k1) = v1                       //Initial values
        if(in2 contains k1)
            m_dict(k1) = nu.plus(v1, in2(k1))         // merge
    }
    in2.foreach{ case (k2, v2) =>                        // Pending elements
        if (! (in1 contains k2))
            m_dict(k2) = v2
    }
    m_dict.toMap
}
    
    
val in1 = Map( "ok" -> 1, "nok" ->  2)
val in2 = Map( "nok" -> 2, "new" -> 3)
merge(in1, in2)


//With closure


def merge[A,B](in1:Map[A,B], in2:Map[A,B])( f: (B, B) => B ) ={   //curried form such that type inference can flow
    
    var m_dict = collection.mutable.Map[A,B]()
    in1.foreach{case (k1, v1) =>
        m_dict(k1) = v1                       //Initial values
        if(in2 contains k1)
            m_dict(k1) = f(v1, in2(k1))         // merge
    }
    in2.foreach{ case (k2, v2) =>                        // Pending elements
        if (! (in1 contains k2))
            m_dict(k2) = v2
    }
    m_dict.toMap
}

val in1 = Map( "ok" -> 1, "nok" ->  2)
val in2 = Map( "nok" -> 2, "new" -> 3)





merge(in1, in2){ (a,b) => a +b }



//file size - Using class which contains files list and recursive Out for dirs

import java.io._

class Out( var dir:String = ""){
   var noOfFiles:Int = _
   var totalSize:Long = _
   lazy val files:collection.mutable.Map[String, Long] = {
     val ms = collection.mutable.Map[String, Long]()   
     val fs = (new File(dir)).listFiles.filter { _.isFile}
      noOfFiles = fs.size
      totalSize  = fs.map { _.length }.toList.sum
      fs foreach { file =>	      
         ms(file.getName) = file.length
      }
	ms
   }
   lazy val dirs:collection.mutable.ListBuffer[Out] = {
     val ds = collection.mutable.ListBuffer[Out]()
     val subdirs   = (new java.io.File(dir)).listFiles.filter { _.isDirectory}
	 subdirs foreach { subdir =>
	      val subOut = new Out( dir + "/" + subdir.getName)
		  subOut.files;  subOut.dirs;
          ds.append( subOut )
         }
      ds
   }
   override def toString =  s"{$dir: [$noOfFiles, $totalSize, ${files.toString}, ${dirs.toString} ] }"
   
   
}

val o = new Out(".")
o

  
