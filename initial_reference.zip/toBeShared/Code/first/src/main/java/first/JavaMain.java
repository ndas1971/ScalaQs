package first;

public class  JavaMain {

    public static void main(String[] args){
        String location = args[0];
        String unit = "c";
        if (args.length >= 2 ) 
            unit = args[1] ;
        boolean json = true ;
        if (args.length >= 3 ) 
            if (args[2].equals("false"))
                json = false ;
        JavaWeather w = new JavaWeather(location, unit, json);
        System.out.println(w.get());
   }
 }