
import akka.actor._
import akka.pattern._
import org.scalatest._
import akka.util._
import scala.concurrent.Await
import scala.concurrent.duration._

import local.Rational

/**
object RationalTest extends FlatSpec with Matchers with BeforeAndAfter  {

  
  var remote: ActorRef = null
  
    
  before {
    implicit val system = ActorSystem("CliSystem")
    remote = system.actorFor("akka.tcp://SrvSystem@127.0.0.1:2552/user/Server")  
  }

  after {
    
  }

  
  "A RationalServer" should "operate correct when sent two valid integers" in {
    
		implicit val timeout = Timeout(5 seconds)
		val future = remote ? Rational(1,2)
		val result = Await.result(future, timeout.duration).asInstanceOf[String]

		result should equal ("0.5")
    }

}
*/
