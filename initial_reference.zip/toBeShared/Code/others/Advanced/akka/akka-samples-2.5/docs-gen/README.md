These projects are mirrors of sample to convert `README.md` into Paradox documentation.
