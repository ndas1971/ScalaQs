package first 

class WeatherTest extends org.scalatest.FunSuite {
  test("Java and Scala are Same ") {
    //note contains time info so, can not be compared directly 
    assert( (new ScalaWeather("mumbai")).get.apply(18) === (new JavaWeather("mumbai")).get.apply(18)   )
  }
}
