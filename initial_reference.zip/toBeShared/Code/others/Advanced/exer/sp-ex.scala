

//boston.csv 
    :Attribute Information (in order):
        - CRIM     per capita crime rate by town
        - ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
        - INDUS    proportion of non-retail business acres per town
        - CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
        - NOX      nitric oxides concentration (parts per 10 million)
        - RM       average number of rooms per dwelling
        - AGE      proportion of owner-occupied units built prior to 1940
        - DIS      weighted distances to five Boston employment centres
        - RAD      index of accessibility to radial highways
        - TAX      full-value property-tax rate per $10,000
        - PTRATIO  pupil-teacher ratio by town
        - B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
        - LSTAT    % lower status of the population
        - MEDV     Median value of owner-occupied homes in $1000 s

"crim", "zn",   "indus", "chas", "nox",  "rm",  "age",  "dis",  "rad", "tax", "ptratio", "b",   "lstat","medv"
0.00632, 18,     2.31,    "0",    0.538,  6.575, 65.2,   4.09,  1,      296,   15.3,      396.9, 4.98,   24

1. read data in boston 
2. Create a new column crimxmedv = crim X medv 
3. select columns crimxmedv , tax 
4. what is the max value of crim 
5. what is max value of medv 
5. select rows of crim where medv is max 
6. select rows of medv where crim is max 
7. how many unique value in chas and rad 
8. what is max and min value of medv for each chas 
9. put crimxmedv and tax in csv 










// eventTime,deviceId,signal  (5188 line)
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70

1.Create Text file 
2. read text file in DF 
3. extract each column  and then 'cast' to correct type with name eventTime,deviceId,signal
col1 - timestamp, column2 - string, column3-int 
4. group by deviceId and collect all signals into a list 'signals'
5. select eventTime,deviceId,signals, it is size and dump into csv file 

 

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 1. read data in boston 
val boston = spark.read.format("csv").option("header",true).
  option("inferSchema",true).load("../data/spark/boston.csv")
2. Create a new column crimxmedv = crim X medv 
boston.withColumn("crimxmedv", col("crim") * col("medv"))
3. select columns crimxmedv , tax 
val df = boston.withColumn("crimxmedv", col("crim") * col("medv")).
   select("crimxmedv","tax")
4. what is the max value of crim 
boston.agg(max("crim")).show
val mc = boston.agg(max("crim")).collect.apply(0).getDouble(0)
5. what is max value of medv 
boston.agg(max("medv")).show
val mm = boston.agg(max("medv")).collect.apply(0).getDouble(0)
5. select rows of crim where medv is max 
boston.select("medv").where(s"crim == $mc").show

6. select rows of medv where crim is max 
boston.select("crim").where(s"medv == $mm").show

7. how many unique value in chas and rad 
boston.select("chas").distinct.show 

8. what is max and min value of medv for each chas 
boston.groupBy("chas").agg($"chas", max($"medv").as("max_medv"),
    min($"medv").alias("min_medv")).show 

9. put crimxmedv and tax in csv 
df.repartition(1).write.format("csv").
  option("header",true).save("../data/spark/processed")

  
  
// eventTime,deviceId,signal  (5188 line)
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70

1.Create Text file 
2. read text file in DF 
val device = spark.read.format("text").load("../data/spark/device.txt")
//[value: string]

3. extract each column  and then 'cast' to correct type with name eventTime,deviceId,signal
col1 - timestamp, column2 - string, column3-int 
val extracted = device.withColumn("splits", split(col("value"), ",")).
  withColumn("eventTime", to_timestamp(col("splits").getItem(0))).
  withColumn("deviceId", col("splits").getItem(1).cast("string")).
  withColumn("signal", col("splits").getItem(2).cast("int")).
  select("eventTime", "deviceId","signal")
  


4. group by deviceId and collect all signals into a list 'signals'
val df = extracted.groupBy("deviceId").
    agg(collect_list(col("signal")).alias("signals")).
    select($"deviceId", $"signals", size($"signals").as("size"))
    


5. select deviceId,signals, it's size and dump into csv file '
df.repartition(1).write.format("csv").
  option("header",true).save("../data/spark/deviced-processed ")
 
 
 
 
 
 
 
 
 