set HADOOP_HOME=this_directory

#then start sbt console for spark applications