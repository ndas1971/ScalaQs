///*** Quick HDFS commands
 
//all are in admin console 
//1.Format the filesystem:
$ hdfs namenode -format

//2.Start NameNode daemon and DataNode daemon:
$ start-dfs & start-yarn
//start history server if required to check logs 
$ mapred --config c:/hadoop/etc/hadoop historyserver
//linux
$ sbin/mr-jobhistory-daemon.sh --config $HADOOP_CONFIG_DIR start historyserver

//check all process started 
$ jps 

//The hadoop daemon log output is written to the $HADOOP_LOG_DIR directory 
//(defaults to $HADOOP_HOME/logs).


//3.Browse the web interface for the NameNode; by default it is available at:
//NameNode - http://localhost:50070/

///Example of running mapReduce Job 
//4.Make the HDFS directories required to execute MapReduce jobs:
$ hdfs dfs -mkdir /user
$ hdfs dfs -mkdir /user/<username>

//5.Copy the input files into the distributed filesystem:
$ cd  c:\hadoop
$ hdfs dfs -put etc/hadoop input   //input means /user/das/input 
$ hdfs dfs -ls input 
$ hdfs dfs -ls hdfs://localhost:19000/user/das/input  //as per core-site.xml


//7.Examine the output files: Copy the output files from the distributed filesystem to the local filesystem and examine them:
$ hdfs dfs -get output output
$ cat output/*
//or   
$ hdfs dfs -cat output/*

//*/

//8.When you're done, stop the daemons with: 
$ stop-yarn & stop-dfs
  
///For Error 
IOException: Incompatible clusterIDs in C:\tmp\hadoop-das\dfs\data: 
namenode clusterID = CID-3f4c81-1e4f-4a7a-b0d8-4b9faeaaba48; datanode clusterID = CID-fa647c5c-d7d6-4e38-bc18-d4799b0a72e9

$ hdfs namenode -format
$ hdfs namenode -format -clusterId CID-fa647c5c-d7d6-4e38-bc18-d4799b0a72e9
 
//Run an example YARN job 
cd  c:\hadoop
hadoop fs -mkdir  example
hadoop fs -put license.txt  example/
hadoop fs -ls example/
 
//Run an example YARN job 
yarn jar share\hadoop\mapreduce\hadoop-mapreduce-examples-*.jar wordcount example/license.txt out
 
//9. Check delete 
hadoop fs -ls out
hadoop fs -rm -r -f  out


///*Checking: Check the following pages in your browser: 
Resource Manager:  http://localhost:8088
Web UI of the NameNode daemon:  http://localhost:50070
HDFS NameNode web interface:  http://localhost:8042

///* Debugging
//To review per-container launch environment, 
//increase yarn.nodemanager.delete.debug-delay-sec to a large value (e.g. 36000), 
//yarn-site.xml
<property> 
      <name>yarn.nodemanager.delete.debug-delay-sec</name> 
      <value>3600</value> 
</property>
//then access the application cache through 
//yarn.nodemanager.local-dirs on the nodes on which containers are launched

//By default - yarn.nodemanager.local-dirs is ${hadoop.tmp.dir}/nm-local-dir ie c:/tmp/nm-local-dir

//An applications localized file directory will be found in: 
//${yarn.nodemanager.local-dirs}/usercache/${user}/appcache/application_${appid}. 
//Individual containers work directories, called container_${contid}, will be subdirectories of this. 

///* To leave safe mode (maintenance mode)
hdfs dfsadmin -safemode get
hdfs dfsadmin -safemode leave

///* check yarn logs 
//find application id from yarn-resourcemanager cmd shell windows 
$ yarn logs -applicationId application_1487592307594_0001 > log.txt

//check logs from yarn.nodemanager.log-dirs of yarn-site.xml
//as per above it is c:/deps/logs/userlogs/...


///*** Imports 
//or in sbt console 
$ sbt console 
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.{functions => F}
import org.apache.spark.ml.{linalg => ML}
import org.apache.spark.mllib.{linalg => MLLIB}
import org.apache.spark.ml._
import org.apache.spark.ml.feature._
import org.apache.spark.ml.evaluation._
import org.apache.spark.ml.param._
import org.apache.spark.ml.regression._
import org.apache.spark.ml.tuning._
import org.apache.spark.ml.classification._
import org.apache.spark.mllib.evaluation._
import org.apache.spark.mllib.regression._
import org.apache.spark.mllib.classification._
import org.apache.spark.mllib.tree._
import org.apache.spark.mllib.tree.configuration._
import org.apache.spark.mllib.tree.model._
import org.apache.spark.mllib.clustering._
import org.apache.spark.graphx._
import org.apache.spark.graphx.lib._
import scala.concurrent.duration._

val conf = new SparkConf().setAppName("EXPERIMENT").setMaster("local[*]")
implicit val sc = new SparkContext(conf)
implicit val sqlContext =new SQLContext(sc)
implicit val spark = sqlContext.sparkSession

import spark.implicits._ 
import scala.concurrent.duration._ 
import scala.reflect.runtime.universe._ 
def getType[T:TypeTag](obj: T) = typeTag[T].tpe


//do activities here 
sc.stop()



///*** spark-shell 


//usage 
$ hdfs namenode -format
$ start-dfs 
$ hdfs dfs -mkdir /user
$ hdfs dfs -mkdir /user/rps
$ hdfs dfs -put README  /user/rps/README


//Example code:wordcount.py


import org.apache.spark._ 

object WordCount {
    def main(args: Array[String]) {
        //Driver program 
        val inputFile =  "hdfs://localhost:19000/user/das/README"  // if HDFS is running,OR "file://D:/PPT/README" 
          
        val conf = new SparkConf().setAppName("wordCount") //.setMaster(master_url) //when running without spark-submit
        //Create a Scala Spark Context.
        val sc = SparkContext(conf=conf)
        //Load our input data.
        val input =  sc.textFile(inputFile)  //default partitions, or use textFile(inputFile,100)
        //Split up into words.
        val words = input.flatMap(line => line.split(" "))  //on executors 
        //Transform into word and count. 
        val counts = words.map(word => (word, 1)).  //on executors,Shuffle boundary , creates map files for reduce phase 
                           reduceByKey(v1, v2 => v1 + v2) //same key, func for values 
          
        //Some logging 
        println(counts.toDebugString)  //each indents is one stage 

        //print, returns list
        val output = counts.collect()  //on driver , action, hence now getting executed 
        output.foreach(println) //on driver , action, hence now getting executed 
    }
}
//Under 0.Basic 
$ sbt console 

//Check application web UI at http://localhost:4040(http://<driver>:4040 )
//check Spark properties in the 'Environment' tab
//spark properties are at conf/spark-defaults.conf, SparkConf(), or the command line will appear.


///Spark - Usage - local mode 
$ spark-submit --class examples.WordCountSubmit --master local[4] target/scala-2.11/learning-assembly.jar

$ spark-submit --class examples.WordCountSubmit  --master local[4] --conf spark.eventLog.enabled=true
  --conf "spark.executor.extraJavaOptions=-verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps" myApp.jar

///Spark -  In Master/workers mode (admin console)
//no output , but check in http://localhost:8080/ and note down address 
$ spark-class org.apache.spark.deploy.master.Master 
$ spark-class org.apache.spark.deploy.worker.Worker spark://<<from_above>>

//usage - master/workr mode (localhost/127.0.0.1 etc does not work)
$ spark-submit --class examples.WordCountSubmit --master spark://192.168.1.2:7077 target/scala-2.11/learning-assembly.jar



///Spark -  Yarn mode (yarn should be running)
$ set HADOOP_CONF_DIR=c:\hadoop\etc\hadoop
$ spark-submit --class examples.WordCountSubmit  --master yarn --deploy-mode client target/scala-2.11/learning-assembly.jar



//check logs - from resource manager node 
$ yarn logs -applicationId application_1538932953443_003



///Spark -   cluster mode, no stdout
$ spark-submit --class examples.WordCountSubmit  --master yarn --deploy-mode cluster target/scala-2.11/learning-assembly.jar


//so check output from, from resource manager node 
$ yarn logs -applicationId application_1538932953443_003
//get Application_id from spark-submit log

//if error, first check and understand 
$ yarn logs -applicationId application_1538922916380_0019

//for WARNING : Neither spark.yarn.jars nor spark.yarn.archive
$ jar cv0f spark-libs.jar -C %SPARK_HOME%/jars/ .
$ hdfs dfs -put spark-libs.jar /user/das/
//then update spark-defaults.conf
spark.yarn.jars=hdfs://localhost:19000/user/das/*.jar

//for error Exception in thread "main" java.lang.NoSuchMethodError: io.netty.buffer.PooledBy
//make sure that spark/jars/netty-all-4.1.17.Final.jar is same as ./hdfs/lib/netty-all-*.Final.jar


//Term	Meaning
Application 	
    User program built on Spark. Consists of a driver program and executors on the cluster.
Application jar 	
    A jar containing the user's Spark application. In some cases users will want to create an "uber jar" containing their application along with its dependencies. The user's jar should never include Hadoop or Spark libraries, however, these will be added at runtime.
Driver program 	
    The process running the main() function of the application and creating the SparkContext
Cluster manager 	
    An external service for acquiring resources on the cluster (e.g. standalone manager, Mesos, YARN)
Deploy mode 	
    Distinguishes where the driver process runs. 
    In "cluster" mode, the framework launches the driver inside of the cluster. 
    In "client" mode, the submitter launches the driver outside of the cluster.
Worker node 	
    Any node that can run application code in the cluster
Executor 	
    A process launched for an application on a worker node, that runs tasks and keeps data in memory or disk storage across them. Each application has its own executors.
Task 	
    A unit of work that will be sent to one executor
Job 	
    A parallel computation consisting of multiple tasks that gets spawned in response to a Spark action (e.g. save, collect); you'll see this term used in the driver's logs.
Stage 	
    Each job gets divided into smaller sets of tasks called stages that depend on each other (similar to the map and reduce stages in MapReduce); you'll see this term used in the driver's logs.

$ spark-submit -h
Usage: spark-submit [options] <app jar | python file | R file> [app arguments]
Usage: spark-submit --kill [submission ID] --master [spark://...]
Usage: spark-submit --status [submission ID] --master [spark://...]
Usage: spark-submit run-example [options] example-class [example args]

Options:
  --master MASTER_URL         spark://host:port, mesos://host:port, yarn,
                              k8s://https://host:port, or local (Default: local[*]).
  --deploy-mode DEPLOY_MODE   Whether to launch the driver program locally ("client") or
                              on one of the worker machines inside the cluster ("cluster")
                              (Default: client).
  --class CLASS_NAME          Your applications main class (for Java / Scala apps).
  --name NAME                 A name of your application.
  --jars JARS                 Comma-separated list of jars to include on the driver
                              and executor classpaths.
  --packages                  Comma-separated list of maven coordinates of jars to include
                              on the driver and executor classpaths. Will search the local
                              maven repo, then maven central and any additional remote
                              repositories given by --repositories. The format for the
                              coordinates should be groupId:artifactId:version.
  --exclude-packages          Comma-separated list of groupId:artifactId, to exclude while
                              resolving the dependencies provided in --packages to avoid
                              dependency conflicts.
  --repositories              Comma-separated list of additional remote repositories to
                              search for the maven coordinates given with --packages.
  --py-files PY_FILES         Comma-separated list of .zip, .egg, or .py files to place
                              on the PYTHONPATH for Python apps.
  --files FILES               Comma-separated list of files to be placed in the working
                              directory of each executor. File paths of these files
                              in executors can be accessed via SparkFiles.get(fileName).

  --conf PROP=VALUE           Arbitrary Spark configuration property.
  --properties-file FILE      Path to a file from which to load extra properties. If not
                              specified, this will look for conf/spark-defaults.conf.

  --driver-memory MEM         Memory for driver (e.g. 1000M, 2G) (Default: 1024M).
  --driver-java-options       Extra Java options to pass to the driver.
  --driver-library-path       Extra library path entries to pass to the driver.
  --driver-class-path         Extra class path entries to pass to the driver. Note that
                              jars added with --jars are automatically included in the
                              classpath.

  --executor-memory MEM       Memory per executor (e.g. 1000M, 2G) (Default: 1G).

  --proxy-user NAME           User to impersonate when submitting the application.
                              This argument does not work with --principal / --keytab.

  --help, -h                  Show this help message and exit.
  --verbose, -v               Print additional debug output.
  --version,                  Print the version of current Spark.

 Cluster deploy mode only:
  --driver-cores NUM          Number of cores used by the driver, only in cluster mode
                              (Default: 1).

 Spark standalone or Mesos with cluster deploy mode only:
  --supervise                 If given, restarts the driver on failure.
  --kill SUBMISSION_ID        If given, kills the driver specified.
  --status SUBMISSION_ID      If given, requests the status of the driver specified.

 Spark standalone and Mesos only:
  --total-executor-cores NUM  Total cores for all executors.

 Spark standalone and YARN only:
  --executor-cores NUM        Number of cores per executor. (Default: 1 in YARN mode,
                              or all available cores on the worker in standalone mode)

 YARN-only:
  --queue QUEUE_NAME          The YARN queue to submit to (Default: "default").
  --num-executors NUM         Number of executors to launch (Default: 2).
                              If dynamic allocation is enabled, the initial number of
                              executors will be at least NUM.
  --archives ARCHIVES         Comma separated list of archives to be extracted into the
                              working directory of each executor.
  --principal PRINCIPAL       Principal to be used to login to KDC, while running on
                              secure HDFS.
  --keytab KEYTAB             The full path to the file that contains the keytab for the
                              principal specified above. This keytab will be copied to
                              the node running the Application Master via the Secure
                              Distributed Cache, for renewing the login tickets and the
                              delegation tokens periodically.
//Setting up for execution(heap, core )
To increase parallelism
    spark.default.parallelism for join/cogroup for RD. or spark.sql.shuffle.partitions for join/cogroup for DataFrame
local mode(master and executors are multi threaded) 
    --driver-memory  2g   //heapsize for driver 
Standalone cluster mode (master and executors are multihosted),with spark.eventLog.enabled to true  
    UI is http://<driver-node>:4040, for master http://masterhost:8080 or for worker, http://workerhost:8081, history server: http://<server-url-where-historyserver-started>:18080 
    In client mode(default), the driver is launched in the same process as the client that submits the application. 
    Use this if you are colocated with master/worker 
    In cluster mode, however, the driver is launched from one of the Worker processes inside the cluster, 
    and the client process exits as soon as it fulfills its responsibility of submitting the application without waiting for the application to finish
    Currently, the standalone mode does not support cluster mode for Python applications, use YARN for that
    --master spark://207.184.161.138:7077 
    --deploy-mode cluster or client 
    --driver-memory 2g      //heapsize for driver 
    --executor-memory 20G   //heapsize for each executor  
    --total-executor-cores 100 //total cores for executors 
    -conf "spark.eventLog.enabled=true"
Yarn with spark.eventLog.enabled to true 
    UI is http://<driver-node>:4040  , history server: http://<server-url-where-historyserver-started>:18080
    In cluster mode, the Spark driver runs inside an application master process which is managed by YARN on the cluster, and the client can go away after initiating the application. 
    Use this when you are farway from cluster 
    In client mode, the driver runs in the client process, and the application master is only used for requesting resources from YARN.
    Use this if you are co-located inside cluster 
    --master yarn \
    --deploy-mode cluster or client 
    --driver-memory 3g      //heapsize for driver , use only in cluster mode, for client mode = keep the default of spark.yarn.am.memory 
    --executor-memory 20G   //heapsize for each executor
    --num-executors 50      //how many total executors 
    --executor-cores 6      //no of core per executor ie how many tasks  
    --conf "spark.eventLog.enabled=true" 
    --conf "spark.driver.maxResultSize=2g"  //max size for handling result in driver eg for collect 
    --driver-cores 2        //only for cluster mode , client mode=keep the default spark.yarn.am.cores 
    --jars "jar1.jat,jar2.jar,..." //jars transfered to cluster and are included on the driver and executor classpaths.    
    For example 
    Dynamic allocation 
        https://jaceklaskowski.gitbooks.io/mastering-apache-spark/spark-dynamic-allocation.html
    static allocation 
        10 Nodes
        16 cores per Node
        64GB RAM per Node
    Calculation 
        To have or good HDFS throughput, 5 core per executors => --executor-cores = 5 
        Leave 1 core per node for Hadoop/Yarn daemons => Num cores available per node = 16-1 = 15
        So, Total available of cores in cluster = 15 x 10 = 150
        Number of available executors = (total cores/num-cores-per-executor) = 150/5 = 30
        Leaving 1 executor for ApplicationManager => --num-executors = 29
        Number of executors per node = 30/10 = 3
        Memory for os and other stuff 3G = 64GB-4G = 60GB
        Memory per executor = 60GB/3 = 20GB
        Counting off heap overhead = 7%(memoryOverhead )of 20GB = 2GB. So, --executor-memory = 20 - 2 = 18GB
    Note keep below yarn-conf 
        yarn.nodemanager.resource.memory-mb(must be atleast60GB)  controls the maximum sum of memory used by the containers on each node.
        yarn.nodemanager.resource.cpu-vcores(must be atleast 15) controls the maximum sum of cores used by the containers on each node




















///*** Spark shell 
$ spark-shell --master local[4] --driver-memory 2G
//sc(spark context) and spark(spark session) are autocreated 

>>> spark.conf.get("spark.app.name")
'spark-shell'
>>> sc.getConf.get("spark.app.name")
'spark-shellShell'
>>> sc.getConf.getAll //spark.sparkContext.getConf()/_conf.getAll()
[('spark.app.id', 'local-1532678326302'), ('spark.sql.catalogImplementation', 'hive'), 
('spark.driver.host', '192.168.1.2'), ('spark.rdd.compress', 'True'), 
('spark.serializer.objectStreamReset', '100'), ('spark.master', 'local[*]'), 
('spark.executor.id', 'driver'), ('spark.submit.deployMode', 'client'), 
('spark.driver.port', '60209'), ('spark.app.name', 'spark-shellShell'), 
('spark.ui.showConsoleProgress', 'true')]

//SQL parameters 
spark.sql("set -v").show(200, truncate=false)
spark.sql("set -v").select($"key",'value).show(200, truncate=false) //'
spark.sql("set -v").select($"key",'value).count  //'


///Properties that specify some time duration should be configured with a unit of time. 
//The following format is accepted:
    25ms (milliseconds)
    5s (seconds)
    10m or 10min (minutes)
    3h (hours)
    5d (days)
    1y (years)


//Properties that specify a byte size should be configured with a unit of size. 
//The following format is accepted:
    1b (bytes)
    1k or 1kb (kibibytes = 1024 bytes)
    1m or 1mb (mebibytes = 1024 kibibytes)
    1g or 1gb (gibibytes = 1024 mebibytes)
    1t or 1tb (tebibytes = 1024 gibibytes)
    1p or 1pb (pebibytes = 1024 tebibytes)



//For example 
//Note all Higher order functions are lazy, to force, use some Action at the end 
>>> val rdd = sc.parallelize(0 to 100) //default no of partitions = no of cores //org.apache.spark.rdd.RDD[Int]
>>> rdd.count()
100 
>>> rdd.getNumPartitions
4
        
//Manually modifying 
>>> val ints = sc.parallelize(0 to 100, 2) //two partitions 
>>> ints.getNumPartitions
2
//check patition with values 
//RDD[T].mapPartitionsWithIndex[U](f: (Int, Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U]): RDD[U] 
>>> ints.mapPartitionsWithIndex((index,values)=> Iterator( index->values.toList)).collect()
res7: Array[(Int, List[Int])] = Array((0,List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24
, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46,
47, 48, 49)), (1,List(50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66,
67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89
, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100)))

  
//By default, Spark tries to read data into an RDD from the nodes that are close to it.
//By default, a partition is created for each HDFS partition, which by default is 64MB 
def RDD[T].partitions: Array[Partition]  

//For example 
scala> sc.parallelize(1 to 100).count
res0: Long = 100 
//shows 4/4
//ie 4 Tasks in Total because it is a  4core laptop 
//and by default the number of partitions is the number of all available cores.     
        
//Manually modifying 
scala> val ints = sc.parallelize(1 to 100, 2)
ints: org.apache.spark.rdd.RDD[Int] = ParallelCollectionRDD[1] at parallelize at <console>:24

scala> ints.partitions.size
res2: Int = 2


//smaller/more numerous partitions allow work to be distributed among more workers, 
//but larger/fewer partitions allow work to be done in larger chunks, which may result in the work getting done more quickly as long as all workers are kept busy, due to reduced overhead.
        
//Spark can only run 1 concurrent task for every partition of an RDD, 
//up to the number of cores in your cluster. 
// you generally want at least as many as the number of executors for parallelism. 
//You can get this computed value by calling  sc.defaultParallelism .

>>> sc.defaultParallelism  //no of cores 
4


//Modify the no of partitions to 400 
rdd = sc.textFile("hdfs://file.txt", 400) 

//For compressed file, # of partion is always 1 as .gz etc can not work in parallel
//After reading change the partition via repartition or coalesce

//coalesce uses existing partitions to minimize the amount of data that's shuffled. repartition creates new partitions and does a full shuffle. coalesce results in partitions with different amounts of data (sometimes partitions that have much different sizes) and repartition results in roughly equal sized partitions

//Both returns new RDD 
def repartition(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T]
//repartition  is coalesce with  numPartitions  and  shuffle  enabled.      
def coalesce(numPartitions: Int, shuffle: Boolean = false)(implicit ord: Ordering[T] = null): RDD[T]

scala> val rdd = sc.parallelize(0 to 10, 8)
rdd: org.apache.spark.rdd.RDD[Int] = ParallelCollectionRDD[0] at parallelize at <console>:24

scala> rdd.partitions.size
res0: Int = 8

scala> rdd.coalesce(numPartitions=8, shuffle=false)  
res1: org.apache.spark.rdd.RDD[Int] = CoalescedRDD[1] at coalesce at <console>:27

scala> res1.toDebugString
res2: String =
(8) CoalescedRDD[1] at coalesce at <console>:27 []
 |  ParallelCollectionRDD[0] at parallelize at <console>:24 []

scala> rdd.coalesce(numPartitions=8, shuffle=true)
res3: org.apache.spark.rdd.RDD[Int] = MapPartitionsRDD[5] at coalesce at <console>:27

scala> res3.toDebugString
res4: String =
(8) MapPartitionsRDD[5] at coalesce at <console>:27 []
 |  CoalescedRDD[4] at coalesce at <console>:27 []
 |  ShuffledRDD[3] at coalesce at <console>:27 []
 +-(8) MapPartitionsRDD[2] at coalesce at <console>:27 []
    |  ParallelCollectionRDD[0] at parallelize at <console>:24 []
      
      
///Detals of execution 
//Application -> Job -> many stages, stage boundary at map and reduce(ShuffleBoundary)
//stage -> many task , each task -> one partition of RDD - uses one core of Executors , 
//one core -> one thread 
//RDD -> many partitions 
//node -> many executors 

//Transformations like repartition and reduceByKey induce stage boundaries(shuffling is required)
//Transformations with (usually) Narrow dependencies:Each partition of the parent RDD is used by at most one partition of the child RDD. 
�	map
�	mapValues
�	flatMap
�	filter
�	mapPartitions
�	mapPartitionsWithIndex
//Transformations with (usually) Wide dependencies: (might cause a shuffle):Each partition of the parent RDD may be used by multiple child partitions 
�	cogroup
�	groupWith
�	join
�	leftOuterJoin
�	rightOuterJoin
�	groupByKey
�	reduceByKey
�	combineByKey
�	distinct
�	intersection
�	repartition
�	coalesce


//To increase parallelism - increase partitions - use spark.conf/sc.getConf.set(key,value)
1.Explicitely mention more partitions eg in sc.textfile(), rdd1.reduceByKey(_ + _, numPartitions = X), where X=parent partitions*1.5,(heuristic) 
2.Use rdd.coalesce(no) to decrease partition with min shuffle, or rdd/df.repartition(no) to increase with full shuffle    
3.Set spark.sql.shuffle.partitions configures the number of partitions that are used when shuffling data frame for joins or aggregations.
4.Set spark.default.parallelism is the default number of partitions in raw RDDs returned by transformations like join, reduceByKey, and parallelize 


///Stages 
//A stage is consisting of many parallel tasks where one task is on one  partition 

//When a job is submitted, a new stage is created with the parent ShuffleMapStage, they can be created from scratch or linked to, i.e. shared, if other jobs use them already.
//DAGScheduler splits up a job into a collection of stages. 
//Each stage contains a sequence of narrow transformations that can be completed without shuffling the entire data set, separated at shuffle boundaries, i.e. where shuffle occurs.


//stage is uniquely identified by  id . 
//When a stage is created, 
//DAGScheduler increments internal counter  nextStageId  to track the number of stage submissions.
     
      
///Introduction to RDD Lineage - check in Spark WebUI 
//evaluation of RDD is lazy in nature. 
//It means a series of transformations are performed on an RDD, which is not even evaluated immediately.

//While we create a new RDD from an existing Spark RDD, 
//that new RDD also carries a pointer to the parent RDD in Spark. 
//That is same as all the dependencies between the RDDs those are logged in a graph, 
//rather than the actual data. 
//It is what we call as lineage graph.

//RDD lineage is nothing but the graph of all the parent RDDs of an RDD. 
//We also call it an RDD operator graph or RDD dependency graph. 
//To be very specific, it is an output of applying transformations to the spark. 
//Then, it creates a logical execution plan.
//physical execution plan or execution DAG is known as DAG of stages.

//Check data\rdd-lineage.jpg to see the RDD lineage created because of below operations 
//After an action has been called, this is a graph of what transformations need to be executed.
val r00 = sc.parallelize(0 to 9)
val r01 = sc.parallelize(0 to 90 by 10)

val r10 = r00 cartesian r01
val r11 = r00.map(n => (n, n))
val r12 = r00 zip r01
val r13 = r01.keyBy(_ / 20)
val r20 = Seq(r11, r12, r13).foldLeft(r10)(_ union _)




///ToDebugString Method to get RDD Lineage Graph in Spark

scala> val wordCount1 = sc.textFile("README.md").flatMap(_.split("\\s+")).map((_, 1)).reduceByKey(_ + _)
wordCount1: org.apache.spark.rdd.RDD[(String, Int)] = ShuffledRDD[21] at reduceByKey at <console>:24

scala> wordCount1.toDebugString
res13: String =
(2) ShuffledRDD[21] at reduceByKey at <console>:24 []
+-(2) MapPartitionsRDD[20] at map at <console>:24 []
|  MapPartitionsRDD[19] at flatMap at <console>:24 []
|  README.md MapPartitionsRDD[18] at textFile at <console>:24 []
|  README.md HadoopRDD[17] at textFile at <console>:24 []

//for indication of shuffle boundary, this method 'toDebugString method' uses indentations.
//N in round brackets refers, numbers that show the level of parallelism at each stage.
//For example, (2) in the above output.
scala> wordCount1.getNumPartitions
res14: Int = 2

//Another Example 
//First number is id, second is actual data,
RDD 1: (1, 1), (2, 1), (3, 1)
RDD 2: (3, 2), (4, 2), (5, 2)
RDD 3: (2, 3), (3, 3), (5, 3)

//to get the most recent data in the result.
//In the result : (1, 1), (2, 3), (3, 3), (4, 2), (5, 3).

//the ideas are:
1: rdd1.union(rdd2).union(rdd3).reduceByKey(v2);
2. rdd1.fullOuterJoin(rdd2).reduceByKey(v2).fullOuterJoin(rdd3).reduceByKey(v2)
3. rdd1.cogroup(rdd2).reduceByKey(v2).cogroup(rdd3).reduceByKey(v2); //cogroup allows to group more, than one rdd, but it�s an example.

// toDebugString look like:
union
(12) ShuffledRDD[8] at reduceByKey at DatasetsTest.java:67 []
 +-(12) UnionRDD[7] at union at DatasetsTest.java:67 []
    |   UnionRDD[6] at union at DatasetsTest.java:67 []
    |   MapPartitionsRDD[3] at mapToPair at DatasetsTest.java:63 []
    |   ParallelCollectionRDD[0] at parallelize at DatasetsTest.java:60 []
    |   MapPartitionsRDD[4] at mapToPair at DatasetsTest.java:64 []
    |   ParallelCollectionRDD[1] at parallelize at DatasetsTest.java:61 []
    |   MapPartitionsRDD[5] at mapToPair at DatasetsTest.java:65 []
    |   ParallelCollectionRDD[2] at parallelize at DatasetsTest.java:62 []

cogroup
(4) MapPartitionsRDD[16] at mapToPair at DatasetsTest.java:84 []
 |  MapPartitionsRDD[15] at cogroup at DatasetsTest.java:84 []
 |  MapPartitionsRDD[14] at cogroup at DatasetsTest.java:84 []
 |  CoGroupedRDD[13] at cogroup at DatasetsTest.java:84 []
 +-(4) MapPartitionsRDD[12] at mapToPair at DatasetsTest.java:84 []
 |  |  MapPartitionsRDD[11] at cogroup at DatasetsTest.java:84 []
 |  |  MapPartitionsRDD[10] at cogroup at DatasetsTest.java:84 []
 |  |  CoGroupedRDD[9] at cogroup at DatasetsTest.java:84 []
 |  +-(4) MapPartitionsRDD[3] at mapToPair at DatasetsTest.java:63 []
 |  |  |  ParallelCollectionRDD[0] at parallelize at DatasetsTest.java:60 []
 |  +-(4) MapPartitionsRDD[4] at mapToPair at DatasetsTest.java:64 []
 |     |  ParallelCollectionRDD[1] at parallelize at DatasetsTest.java:61 []
 +-(4) MapPartitionsRDD[5] at mapToPair at DatasetsTest.java:65 []
    |  ParallelCollectionRDD[2] at parallelize at DatasetsTest.java:62 []

join
(4) MapPartitionsRDD[18] at mapToPair at DatasetsTest.java:85 []
 |  MapPartitionsRDD[17] at fullOuterJoin at DatasetsTest.java:85 []
 |  MapPartitionsRDD[16] at fullOuterJoin at DatasetsTest.java:85 []
 |  MapPartitionsRDD[15] at fullOuterJoin at DatasetsTest.java:85 []
 |  CoGroupedRDD[14] at fullOuterJoin at DatasetsTest.java:85 []
 +-(4) MapPartitionsRDD[13] at mapToPair at DatasetsTest.java:85 []
 |  |  MapPartitionsRDD[12] at fullOuterJoin at DatasetsTest.java:85 []
 |  |  MapPartitionsRDD[11] at fullOuterJoin at DatasetsTest.java:85 []
 |  |  MapPartitionsRDD[10] at fullOuterJoin at DatasetsTest.java:85 []
 |  |  CoGroupedRDD[9] at fullOuterJoin at DatasetsTest.java:85 []
 |  +-(4) MapPartitionsRDD[3] at mapToPair at DatasetsTest.java:64 []
 |  |  |  ParallelCollectionRDD[0] at parallelize at DatasetsTest.java:61 []
 |  +-(4) MapPartitionsRDD[4] at mapToPair at DatasetsTest.java:65 []
 |     |  ParallelCollectionRDD[1] at parallelize at DatasetsTest.java:62 []
 +-(4) MapPartitionsRDD[5] at mapToPair at DatasetsTest.java:66 []
    |  ParallelCollectionRDD[2] at parallelize at DatasetsTest.java:63 []


//number in braces (12 and 4) are number of partitions to process. 
//Different indentation means different stages. 
//Different stage means different shuffle, which in turn means the data will be sent over the network.
//So, there will be just one network hop for union and 4 network hops for both join and cogroup.            


///Two kinds of partitioning available in Spark:
Hash partitioning, org.apache.spark.HashPartitioner(numPartitions)
    p = k.hashCode() % numPartitions
    in java, k.hashCode 
Range partitioning
    Assumptions: (a) Keys non-negative, (b) 800 is the biggest key in the RDD
    Set of ranges: from (800/4): [1-200), [201-400), [401-600), [601-800] 

    In scala, org.apache.spark.RangePartitioner(numPartitions,rdd)
    May use  sortByKey(ascending=True, numPartitions=None, keyfunc=lambda x: x) ,uses rangePartitioner , hence use this if required 
    keyBy returns tuple, rdd.map(x => (keyfunc(x), x))
    rdd.keyBy(keyfunc).sortByKey(ascending, numPartitions).values()
//Custom partitioner      
case class CP(partitions:Int) extends Partitioner{
        def getPartition(key: Any): Int = {
                if(key == 17850 || key == 12583) return 0
                    import scala.util.Random 
                    val r = new Random
                    return r.nextInt(partitions-1)+1  //1... partions-1
                 }
        def numPartitions: Int = partitions
        }       
        
val data = Array(17850, 12583, 12584, 17851)
val r = new scala.util.Random
val rdddata = (0 to 100).toList.map(i => (data(r.nextInt(4)),i,i*2) )
val rdd = sc.parallelize(rdddata)

val keyedRDD = rdd.keyBy( _._1 )
>>> keyedRDD.partitionBy(new CP(3)).map(_._1).glom().collect().foreach(x=>println(x.size))
50
24
27
        
        

//Automatically partitioners:
//Some operations on RDDs automatically result in an RDD with a known partitioner for when it makes sense. 
//E.g. by default, when using sortByKey, a RangePartitioner is used. 
//Further, the default partitioner when using groupByKey, is a HashPartitioner, .
//Operations on Pair RDDs that hold to and propagate a partitioner:
�	cogroup
�	groupWith
�	join
�	leftOuterJoin
�	rightOuterJoin
�	groupByKey
�	reduceByKey
�	foldByKey
�	combineByKey
�	partitionBy
�	sort
�	mapValues (if parent has a partitioner)
�	flatMapValues (if parent has a partitioner)
�	filter (if parent has a partitioner)





    
    
///*** Few Imp methods of SparkContext    and RDD 
    
//Few Important methods of SparkContext
class org.apache.spark.SparkContext
    def makeRDD[T](seq: Seq[T], numSlices: Int = defaultParallelism)(implicit arg0: ClassTag[T]): RDD[T]
        Distribute a local Scala collection to form an RDD.
        Note Array has implicit conversion to Seq 
        >>> sc.makeRDD(List(0, 2, 3, 4, 6), 5).glom().collect() //glom() returns Array of each partition's value seperately
        Array[Array[Int]] = Array(Array(0), Array(2), Array(3), Array(4), Array(6))
        
    def parallelize[T](seq: Seq[T], numSlices: Int = defaultParallelism)(implicit arg0: ClassTag[T]): RDD[T]
        Distribute a local scala collection to form an RDD. 
        List, range, Buffer are subclass of Seq, but not Set and Map are not, but these have .toSeq method 
        Note Array can be converted to Seq implicitly(scala.collection.mutable.WrappedArray (a subtype of scala.collection.Seq))
        Note T can be anything, even a Tuple . In Spark, Paired RDD is RDD[(K,V)]
        >>> sc.parallelize(List(0, 2, 3, 4, 6), 5).glom().collect() //glom() returns Array of each partition's value seperately
        Array[Array[Int]] = Array(Array(0), Array(2), Array(3), Array(4), Array(6))
        >>> sc.parallelize(0 to 6 by 2, 5).glom().collect()
        res5: Array[Array[Int]] = Array(Array(), Array(0), Array(2), Array(4), Array(6))
        
    def range(start: Long, end: Long, step: Long = 1, numSlices: Int = defaultParallelism): RDD[Long]
        Create a new RDD of int containing elements from start to end (exclusive), 
        >>> sc.range(0,5).collect()
        res7: Array[Long] = Array(0, 1, 2, 3, 4)   
        
    def union[T](rdds: Seq[RDD[T]])(implicit arg0: ClassTag[T]): RDD[T]
        Build the union of a list of RDDs of same type 
        val textFile = sc.parallelize(Array("Hello"))
        val parallelized = sc.parallelize(Array("World!"))
        >>> sc.union(Array(textFile, parallelized)).collect.sorted 
        res5: Array[String] = Array(Hello, World!)        
        
    def hadoopConfiguration: org.apache.hadoop.conf.Configuration 
        A default Hadoop Configuration for the Hadoop code (e.g. file systems) 
        This is for global 
        These configuration is from core-default.xml: Read-only defaults for hadoop.
        and core-site.xml: Site-specific configuration for a given hadoop installation.
        check https://hadoop.apache.org/docs/r2.7.3/api/org/apache/hadoop/conf/Configuration.html
        Use Configuration.dumpConfiguration(sc.hadoopConfiguration, new java.io.PrintWriter(scala.Console.out) )
        to dump all and get(name)/set(name,value) to get/set single config items 
        
    def textFile(path: String, minPartitions: Int = defaultMinPartitions): RDD[String]
        Read a text file linewise       
        Note Path supports running on directories, compressed files, and wildcards as well. 
        >>> val textFile = sc.textFile(path)
        >>> textFile.collect()
        ["Hello world!"]    
        
    def wholeTextFiles(path: String, minPartitions: Int = defaultMinPartitions): RDD[(String, String)]
        read a directory containing multiple text files, and returns each of them as (filename, content) pairs.
        This is in contrast with textFile, which would return one record per line in each file.        
    
    def sequenceFile[K, V](path: String, minPartitions: Int = defaultMinPartitions)(implicit km: ClassTag[K], vm: ClassTag[V], kcf: () => WritableConverter[K], vcf: () => WritableConverter[V]): RDD[(K, V)]
    def sequenceFile[K, V](path: String, keyClass: Class[K], valueClass: Class[V]): RDD[(K, V)]
    def sequenceFile[K, V](path: String, keyClass: Class[K], valueClass: Class[V], minPartitions: Int): RDD[(K, V)]
        Read a Hadoop SequenceFile(=(K,V) pair) with arbitrary key and value Writable class from HDFS, a local file system (available on all nodes), 
        or any Hadoop-supported file system URI
        �path � path to Hadoop file, hdfs://, file:// etc 
        //Create a RDD of K,V and save as sequence file , coalesce repartitions to one, hence creates one file 
        >>> sc.parallelize(List(("foo", """{"foo": 1}"""), ("bar", """{"bar": 2}"""))).coalesce(1).saveAsSequenceFile("example")
        //Read K,V , mention, scala type
        val rdd_k_v = sc.sequenceFile[String,String]("example")   
        >>> rdd_k_v.collect()
        res1: Array[(String, String)] = Array((foo,{"foo": 1}), (bar,{"bar": 2}))
        val rdd_v = rdd_k_v.values
        >>> rdd_v.first
        res2: String = {"foo": 1}           

    def newAPIHadoopFile[K, V, F <: InputFormat[K, V]](path: String, fClass: Class[F], kClass: Class[K], vClass: Class[V], conf: Configuration = hadoopConfiguration): RDD[(K, V)]
    def newAPIHadoopFile[K, V, F <: InputFormat[K, V]](path: String)(implicit km: ClassTag[K], vm: ClassTag[V], fm: ClassTag[F]): RDD[(K, V)]
        Based on org.apache.hadoop.mapreduce.InputFormat (new MapReduce API)
        Create a new org.apache.hadoop.conf.Configuration object to be used with this API 
        new Configuration(true).set(String name, String value)
        //Example with new deliminator , K=Line number, V= text line 
        import org.apache.hadoop.io.LongWritable
        import org.apache.hadoop.io.Text
        import org.apache.hadoop.conf.Configuration
        import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
        val conf = new Configuration
        conf.set("textinputformat.record.delimiter", "##")
        val data = sc.newAPIHadoopFile("mydata.txt", classOf[TextInputFormat], classOf[LongWritable], classOf[Text], conf).map(_._2.toString)
        data: org.apache.spark.rdd.RDD[(org.apache.hadoop.io.LongWritable, org.apache.hadoop.io.Text)] = NewHadoopRDD[0] at newAPIHadoopFile at <console>:19

        
    def newAPIHadoopRDD[K, V, F <: InputFormat[K, V]](conf: Configuration = hadoopConfiguration, fClass: Class[F], kClass: Class[K], vClass: Class[V]): RDD[(K, V)]
        Create a new org.apache.hadoop.conf.Configuration object to be used with this API 
        Note configuration contains connection detail. This is used for HBase reading 
        
    def objectFile[T](path: String, minPartitions: Int = defaultMinPartitions)(implicit arg0: ClassTag[T]): RDD[T]
        Load an RDD saved as a SequenceFile containing serialized objects, 
        with NullWritable keys and BytesWritable values that contain a serialized partition.

    def binaryFiles(path: String, minPartitions: Int = defaultMinPartitions): RDD[(String, PortableDataStream)]
        Get an RDD for a Hadoop-readable dataset as PortableDataStream 
        for each file (useful for binary data)
        
    def binaryRecords(path: String, recordLength: Int, conf: Configuration = hadoopConfiguration): RDD[Array[Byte]]
        Load data from a flat binary file, assuming the length of each record is constant.
        Create a new org.apache.hadoop.conf.Configuration object to be used with this API             
            
                        
            
            
///Spark - RDD - Printing elements of an RDD

//in local mode, OK 
//in cluster mode - stdout is executer/another machines stdout, hence check SPARK_WORKER_DIR or sparkUI/ResourceManagerUI
rdd.foreach(x=> println(x)) 
rdd.map(x => println(x)) //Wrong as map is transformation, hence lazy 

//This can cause the driver to run out of memory- hence safer is to use take 
rdd.take(100) //==> returns list 


///RDD- Understanding Execution 
//WRONG Usage - this might work in local mode, but fails in other 
var counter = 0
val rdd = sc.parallelize(data)

// Wrong: Donot do this!!
def increment_counter(x:Int){
    counter += x
}
    
rdd.foreach(increment_counter)

printf("Counter value: %d", counter)


//Spark natively supports accumulators of numeric types, 
//and programmers can add support for new types.
val accum = sc.accumulator(0) //Driver
sc.parallelize(Array(1, 2, 3, 4)).foreach(x => accum.add(x)) //Executor
accum.value  //10  //Driver 

//OR 
val accum = sc.longAccumulator("My Accumulator") //Driver
sc.parallelize(Array(1, 2, 3, 4)).foreach(x => accum.add(x))//Executor
accum.value  //res2: Long = 10 //Driver

//Otheres are collectionAccumulator[T](name: String), collectionAccumulator[T]
//doubleAccumulator(name: String), doubleAccumulator, longAccumulator(name: String), longAccumulator




///Spark - RDD - Shared Variables - Broadcast Variables

sc.broadcast(value)
    Broadcast variables allow the programmer to keep a read-only variable cached 
    on each machine rather than shipping a copy of it with tasks. 
    Once created by Driver, 
    it can  be used(.value) in any functions that run on the cluster 
 
//Example 
val b = sc.broadcast(Array(1, 2, 3, 4, 5))
>>> b.value     //Driver 
[1, 2, 3, 4, 5]
>>> sc.parallelize(Array(0, 0)).flatMap(x => b.value).collect() //closure in executor 
es41: Array[Int] = Array(1, 2, 3, 4, 5, 1, 2, 3, 4, 5)








///Spark - RDD - Persistence

//You can mark an RDD to be persisted using the persist() or cache() methods on it. 
//The first time it is computed in an action, it will be kept in memory on the nodes.

//The cache() method is a shorthand for using the default storage level, 
//which is StorageLevel.MEMORY_ONLY 

//Spark automatically monitors cache usage on each node 
//and drops out old data partitions in a least-recently-used (LRU) fashion. 
//OR use the RDD.unpersist() method.


///StorageLevel describes how an RDD is persisted (and addresses the following concerns):
    Does RDD use disk?
    How much of RDD is in memory?
    Does RDD use off-heap memory?
    Should an RDD be serialized (while persisting)?
    How many replicas (default: 1) to use (can only be less than 40)?

//Example 
val lines = sc.textFile("README.md")
>>> lines.getStorageLevel
res0: org.apache.spark.storage.StorageLevel = StorageLevel(disk=false, memory=false, offheap=..)


//There are the following StorageLevel (number _2 in the name denotes 2 replicas):
MEMORY_ONLY         
    Store RDD as deserialized Java objects in the JVM. If the RDD does not fit in memory, 
    some partitions will not be cached and will be recomputed on the fly each time they are needed. 
    This is the default level.  
MEMORY_AND_DISK     
    Store RDD as deserialized Java objects in the JVM. 
    If the RDD does not fit in memory, store the partitions that dont fit on disk, 
    and read them from there when theyre needed.  
MEMORY_ONLY_SER     
    (Java and Scala)  Store RDD as serialized Java objects (one byte array per partition). 
    This is generally more space-efficient than deserialized objects, especially 
    when using a fast serializer, but more CPU-intensive to read.  
MEMORY_AND_DISK_SER 
    (Java and Scala)  Similar to MEMORY_ONLY_SER, but spill partitions that dont fit in memory 
    to disk instead of recomputing them on the fly each time they re needed.  
DISK_ONLY           
    Store the RDD partitions only on disk.  
MEMORY_ONLY_2, MEMORY_AND_DISK_2, etc.  
    Same as the levels above, but replicate each partition on two cluster nodes.  
OFF_HEAP (experimental)     
    Similar to MEMORY_ONLY_SER, but store the data in off-heap memory. 
    This requires off-heap memory to be enabled.  

///Which Storage Level to Choose
�If your RDDs fit comfortably with the default storage level (MEMORY_ONLY), leave them that way. 
 This is the most CPU-efficient option, allowing operations on the RDDs to run as fast as possible.

�If not, try using MEMORY_ONLY_SER and selecting a fast serialization library to make the objects much more space-efficient, 
 but still reasonably fast to access. (Java and Scala)

�Don�t spill to disk unless the functions that computed your datasets are expensive, 
 or they filter a large amount of the data. 
 Otherwise, recomputing a partition may be as fast as reading it from disk.

�Use the replicated storage levels if you want fast fault recovery 
 (e.g. if using Spark to serve requests from a web application). 
 All the storage levels provide full fault tolerance by recomputing lost data, 
 but the replicated ones let you continue running tasks on the RDD without waiting to recompute a lost partition.
  
            
       


       
///Spark - RDD - Passing Functions in the driver program to run on the cluster. 
//IMP*** functions along with captured variables must be serialized - else ERROR 
//Note if captured variables are not serializable(eg contains complicated state eg socket/DB/file connection). IT WOULD FAIL 


//Followings are performant
//Anonymous function syntax, which can be used for short pieces of code.
//Static methods in a global singleton object. 
//For example, you can define object MyFunctions and then pass MyFunctions.func1

object MyFunctions {
  def func1(s: String): String = { ... }
}

myRdd.map(MyFunctions.func1)

//For class methods, check captured variable  
//Note: For below type of cases, 
//whole object/class needs to be sent to cluster which might  not be performant 
class MyClass extends Serializable {
  def func1(s: String): String = { ... }
  def doStuff(rdd: RDD[String]): RDD[String] = { rdd.map(func1) }
}
//OR 
class MyClass extends Serializable  {
  val field = "Hello"
  def doStuff(rdd: RDD[String]): RDD[String] = { rdd.map(x => field + x) }
}

//One Solution - copy field into a local variable 
def doStuff(rdd: RDD[String]): RDD[String] = {
  val field_ = this.field
  rdd.map(x => field_ + x)
}
    
//Using kyro serialization(note by default DF uses advanced serialization, called Encoders, hence no need to use kyro)
//hence kyro is required only if using spark RDD features 
//Since Spark 2.0.0,Spark use Kryo serializer(bydefault) when shuffling RDDs with simple types, arrays of simple types, or string type
conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
//For custom class registration, use scala 
//if "buffer limit exceeded" exception inside Kryo. 
conf.set("spark.kryoserializer.buffer.max", "64m")  //<2048m 
//Then use StorageLevel.MEMORY_ONLY in persist() (in scala MEMORY_ONLY_SER)


    
//Example - Bad code 
val connection = createNewConnection()  // executed at the driver
rdd.foreach { record =>         ////connection is getting serialized and sent to executor 
connection.send(record) // executed at the worker
}



//One solution is to open connection in executor 
//But for each element, connection would be opened - not performant
rdd.foreach { record =>
    val connection = createNewConnection()
    connection.send(record)
    connection.close()
  }


//Better solution can be Partitionwise 
rdd.foreachPartition { partitionOfRecords =>
    val connection = createNewConnection()
    partitionOfRecords.foreach(record => connection.send(record))
    connection.close()
  }

               
            
///RDD Operations Examples     
//Note there is no Map[K,V], for K,V pair, it is RDD[(K,V)] , called pairedRDD[K,V] 

//RDD[T] is converted to belwo via implicits operations 
rdd:RDD[Double]  --> DoubleRDDFunctions
rdd: RDD[T](implicit num: Numeric[T] -->  DoubleRDDFunctions
rdd: RDD[(K, V)])(implicit arg0: Ordering[K]) -->  OrderedRDDFunctions[K, V, (K, V)]
rdd: RDD[(K, V)] --> PairRDDFunctions[K, V]
rdd: RDD[(K, V)] --> SequenceFileRDDFunctions[K, V] 
     
//Examples  
org.apache.spark.rdd.CoGroupedRDD[K] extends RDD[(K, Array[Iterable[_]])]
    Returns of cogroup
    All RDD operations are possible, now Type is (K, Array[Iterable[_]])   
    
org.apache.spark.rdd.OrderedRDDFunctions[K, V, P <: Product2[K, V]] extends Logging with Serializable
	Extra functions available on RDDs of (key, value) pairs where the K is sortable through an implicit conversion.
    filterByRange(lower: K, upper: K): RDD[P]//inclusive range lower to upper.
    repartitionAndSortWithinPartitions(partitioner: Partitioner): RDD[(K, V)]
       val rdd = sc.parallelize(Array((0, 5), (3, 8), (2, 6), (0, 8), (3, 8), (1, 3)))
        //repartition with whether key 
        case class CustomPartitioner(partitions:Int) extends Partitioner{
            def getPartition(key: Any): Int = {
                        key.asInstanceOf[Int] % partitions 
                     }
            def numPartitions: Int = partitions
            }
        val rdd2 = rdd.repartitionAndSortWithinPartitions(CustomPartitioner(2))//org.apache.spark.rdd.RDD[(Int, Int)]
        >>> rdd2.glom().collect()
       res47: Array[Array[(Int, Int)]] = Array(Array((0,5), (0,8), (2,6)), Array((1,3), (3,8), (3,8)))

    sortByKey(ascending: Boolean = true, numPartitions: Int = self.partitions.length): RDD[(K, V)]
        val tmp = Array(('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5))
        >>> sc.parallelize(tmp).sortByKey().first
        ('1', 3)
        >>> sc.parallelize(tmp).sortByKey(true, 1).collect()
        [('1', 3), ('2', 5), ('a', 1), ('b', 2), ('d', 4)]
        
     
        
org.apache.spark.rdd.DoubleRDDFunctions extends Logging with Serializable
    Extra functions available on RDDs of Doubles through an implicit conversion.
    histogram(buckets_or_bucketCount), mean(),popStdev(), popVariance() etc 
    stats() Returns StatCounter which has count,max,mean,min,popStdev,popVariance,stdev,sum,variance: Double
         >>> sc.parallelize(Array(1, 2, 3)).mean()
            2.0  
        
org.apache.spark.rdd.SequenceFileRDDFunctions[K, V] extends Logging with Serializable
    saveAsSequenceFile(path: String, codec: Option[Class[_ <: CompressionCodec]] = None): Unit
      
     
org.apache.spark.rdd.PairRDDFunctions[K, V] extends Logging with Serializable
	Extra functions available on RDDs of (key, value) pairs through an implicit conversion.
    def collectAsMap(): Map[K, V]
        For RDD of (K,V)
        Return the key-value pairs in this RDD to the driver as a dictionary.
        val  m = sc.parallelize(Array((1, 2), (3, 4))).collectAsMap()
        >>> m(1)
        2
        >>> m(3)
        4
    def keys: RDD[K]
        Return an RDD with the keys of each tuple.
        val m = sc.parallelize(Array((1, 2), (3, 4))).keys
        >>> m.collect()
        [1, 3]
    def values: RDD[V]
        Return an RDD with the values of each tuple.
        val m = sc.parallelize(Array((1, 2), (3, 4))).values
        >>> m.collect()
        [2, 4]

    def lookup(key: K): Seq[V]
        Return the list of values in the RDD for key key.
        val l = (0 to 1000).toList
        val rdd = sc.parallelize(l.zip(l), 10)
        >>> rdd.lookup(42)  // slow
        res52: Seq[Int] = WrappedArray(42)
        val sorted = rdd.sortByKey().cache 
        >>> sorted.lookup(42)  // fast
        res52: Seq[Int] = WrappedArray(42)
        >>> sorted.lookup(1024)
        res54: Seq[Int] = ArrayBuffer()
        val rdd2 = sc.parallelize(Array((('a', 'b'), 'c'))).groupByKey()
        >>> rdd2.lookup(('a', 'b'))(0)
        res56: Iterable[Char] = CompactBuffer(c)

    def mapValues[U](f: (V) => U): RDD[(K, U)]
        Pass each value in the key-value pair RDD through a map function without changing the keys; this also retains the original RDDs partitioning.
        val x = sc.parallelize(Array(("a", Array("apple", "banana", "lemon")), ("b", Array("grapes"))))
        >>> def f(x:Array[_])= x.size
        >>> x.mapValues(f).collect()
        res58: Array[(String, Int)] = Array((a,3), (b,1))
        
    def flatMapValues[U](f: (V) => TraversableOnce[U)): RDD[(K, U)]
        Pass each value in the key-value pair RDD through a flatMap function without changing the keys; this also retains the original RDDs partitioning.
        val x = sc.parallelize(Array(("a", Seq("x", "y", "z")), ("b", Seq("p", "r"))))
        >>> def f[T](x:T) = x
        >>> x.flatMapValues(f).collect()
        res60: Array[(String, String)] = Array((a,x), (a,y), (a,z), (b,p), (b,r))

    def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def cogroup[W](other: RDD[(K, W))): RDD[(K, (Iterable[V], Iterable[W)))]
    def cogroup[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W)))]
    def cogroup[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W)))]
        For each key k in this or other1 or other2 or other3, 
        return a resulting RDD that contains a tuple with the list of values 
        for that key in this, other1, other2 and other3.
        Note Result is a PairedRDD 
        We can use Result of this to instantiate , CoGroupedRDD[K] extends RDD[(K, Array[Iterable[_]))]
        for many other methods 
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2), ("a",3)))
        val rdd = x.cogroup(y).cache //org.apache.spark.rdd.RDD[(String, (Iterable[Int], Iterable[Int]))]
        >>> x.cogroup(y).collect()
        res51: Array[(String, (Iterable[Int], Iterable[Int]))] = Array((a,(CompactBuffer(1),CompactBuffer(2, 3))), (b,(CompactBuffer(4),CompactBuffer())))
        val rdd2 = new  CoGroupedRDD(Seq(rdd), Partitioner.defaultPartitioner(rdd)) //org.apache.spark.rdd.CoGroupedRDD[String]
        >>> rdd2.groupByKey().collect()
        
    def groupWith[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def groupWith[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def groupWith[W](other: RDD[(K, W))): RDD[(K, (Iterable[V], Iterable[W)))]
        Alias for cogroup.
        val w = sc.parallelize(Array(("a", 5), ("b", 6)))
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2)))
        val z = sc.parallelize(Array(("b", 42)))
        >>> w.groupWith(x, y, z).collect() 
         Array[(String, (Iterable[Int], Iterable[Int], Iterable[Int], Iterable[Int]))] = 

        
    def subtractByKey[W](other: RDD[(K, W)], p: Partitioner)(implicit arg0: ClassTag[W)): RDD[(K, V)]
    def subtractByKey[W](other: RDD[(K, W)], numPartitions: Int)(implicit arg0: ClassTag[W)): RDD[(K, V)]
    def subtractByKey[W](other: RDD[(K, W)))(implicit arg0: ClassTag[W)): RDD[(K, V)]
        Return an RDD with the pairs from this whose keys are not in other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4), ("b", 5), ("a", 2)))
        val y = sc.parallelize(Array(("a", 3), ("c", null )))
        >>> x.subtractByKey(y).collect()
        res65: Array[(String, Int)] = Array((b,4), (b,5))

    def groupByKey(): RDD[(K, Iterable[V))]
    def groupByKey(numPartitions: Int): RDD[(K, Iterable[V))]
    def groupByKey(partitioner: Partitioner): RDD[(K, Iterable[V))]
        Group the values for each key in the RDD into a single sequence.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.groupByKey().mapValues(_.size).collect()
        res66: Array[(String, Int)] = Array((a,2), (b,1))
        >>> rdd.groupByKey().mapValues(_.toList).collect()
        Array[(String, List[Int])] = Array((a,List(1, 1)), (b,List(1)))
    
    def partitionBy(partitioner: Partitioner): RDD[(K, V)]
        Return a copy of the RDD partitioned using the specified partitioner.
        val pairs = sc.parallelize(Array(1, 2, 3, 4, 2, 4, 1)).map(x => (x, x))
        >>> pairs.partitionBy(new HashPartitioner(2)).glom().collect()
        res68: Array[Array[(Int, Int)]] = Array(Array((2,2), (4,4), (2,2), (4,4)), Array((1,1), (3,3), (1,1)))

    def aggregateByKey[U](zeroValue: U)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): RDD[(K, U)]
    def aggregateByKey[U](zeroValue: U, numPartitions: Int)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): RDD[(K, U)]
    def aggregateByKey[U](zeroValue: U, partitioner: Partitioner)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): RDD[(K, U)]
        Aggregate the values of each key, using given combine functions and a neutral "zero value".
            //sum by Key 
            >>> sc.parallelize(Array((0,1), (0,2), (1,3), (1,4))).aggregateByKey(0)((u,v)=> u+v, (u1,u2)=> u1+u2).collect()
            res69: Array[(Int, Int)] = Array((0,3), (1,7))
            //Average by key 
            //ZeroValue=(0,0), first index =sum, 2ndindex=count 
               
            >>> sc.parallelize(Array((0,1), (0,2), (1,3), (1,4))).aggregateByKey((0,0))((u,v)=>(u._1+v, u._2+1), (u1,u2) => (u1._1+u2._1,u1._2+u2._2)).mapValues( t => t._1/t._2.toDouble).collect()
            res1: Array[(Int, Double)] = Array((0,1.5), (1,3.5))        

    def foldByKey(zeroValue: V)(func: (V, V) => V): RDD[(K, V)]
    def foldByKey(zeroValue: V, numPartitions: Int)(func: (V, V) => V): RDD[(K, V)]
    def foldByKey(zeroValue: V, partitioner: Partitioner)(func: (V, V) => V): RDD[(K, V)]
        Merge the values for each key using an associative function and a neutral "zero value" which may be added to the result an arbitrary number of times, and must not change the result (e.g., Nil for list concatenation, 0 for addition, or 1 for multiplication.).
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> from operator import add
        >>> rdd.foldByKey(0)(_+_).collect()
        res2: Array[(String, Int)] = Array((a,2), (b,1))
    
    def reduceByKey(func: (V, V) => V): RDD[(K, V)]
    def reduceByKey(func: (V, V) => V, numPartitions: Int): RDD[(K, V)]
    def reduceByKey(partitioner: Partitioner, func: (V, V) => V): RDD[(K, V)]
        Merge the values for each key using an associative and commutative reduce function.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.reduceByKey(_+_).collect()
        res3: Array[(String, Int)] = Array((a,2), (b,1))

    def reduceByKeyLocally(func: (V, V) => V): Map[K, V]
        Merge the values for each key using an associative and commutative reduce function, but return the results immediately to the master as a Map.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.reduceByKeyLocally(_+_).toList 
        res4: List[(String, Int)] = List((a,2), (b,1))

    def countByKey(): Map[K, Long]
        Count the number of elements for each key, collecting the results to a local Map.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.countByKey().toList
        [('a', 2), ('b', 1)]
    
    def fullOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Option[V], Option[W)))]
    def fullOuterJoin[W](other: RDD[(K, W))): RDD[(K, (Option[V], Option[W)))]
    def fullOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Option[V], Option[W)))]
        Perform a full outer join of this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2), ("c", 8)))
        >>> x.fullOuterJoin(y).collect()
        res5: Array[(String, (Option[Int], Option[Int]))] = Array((a,(Some(1),Some(2))), (b,(Some(4),None)), (c,(None,Some(8))))
        
    def join[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (V, W))]
    def join[W](other: RDD[(K, W))): RDD[(K, (V, W))]
    def join[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (V, W))]
        Return an RDD containing all pairs of elements with matching keys in this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2), ("a", 3)))
        >>> x.join(y).collect()
        res6: Array[(String, (Int, Int))] = Array((a,(1,2)), (a,(1,3)))   

    
    def leftOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (V, Option[W)))]
    def leftOuterJoin[W](other: RDD[(K, W))): RDD[(K, (V, Option[W)))]
    def leftOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (V, Option[W)))]
        Perform a left outer join of this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2)))
        >>> x.leftOuterJoin(y).collect()
        res7: Array[(String, (Int, Option[Int]))] = Array((a,(1,Some(2))), (b,(4,None)))

    def rightOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Option[V], W))]
    def rightOuterJoin[W](other: RDD[(K, W))): RDD[(K, (Option[V], W))]
    def rightOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Option[V], W))]
        Perform a right outer join of this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2)))
        >>> y.rightOuterJoin(x).collect()
        res8: Array[(String, (Option[Int], Int))] = Array((a,(Some(2),1)), (b,(None,4)))

    def sampleByKey(withReplacement: Boolean, fractions: Map[K, Double], seed: Long = Utils.random.nextLong): RDD[(K, V)]
    def sampleByKeyExact(withReplacement: Boolean, fractions: Map[K, Double], seed: Long = Utils.random.nextLong): RDD[(K, V)]
        Return a subset of this RDD sampled by key (via stratified sampling) containing exactly math.ceil(numItems * samplingRate) for each stratum (group of pairs with the same key).
        val fractions = Map("a"-> 0.2, "b"-> 0.1) //for key a, 20%, for key b, 10% 
        val rdd = sc.parallelize(fractions.keys.toSeq).cartesian(sc.parallelize(0 to 1000)) //org.apache.spark.rdd.RDD[(String, Int)]
        val sample = rdd.sampleByKey(false, fractions, 2).groupByKey().collect().toMap
        
    def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C): RDD[(K, C)]
    def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, numPartitions: Int): RDD[(K, C)]
    def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, partitioner: Partitioner, mapSideCombine: Boolean = true, serializer: Serializer = null): RDD[(K, C)]
        It does not provide combiner classtag information to the shuffle     
    def combineByKeyWithClassTag[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C)(implicit ct: ClassTag[C]): RDD[(K, C)]
    def combineByKeyWithClassTag[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, numPartitions: Int)(implicit ct: ClassTag[C]): RDD[(K, C)]
    def combineByKeyWithClassTag[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, partitioner: Partitioner, mapSideCombine: Boolean = true, serializer: Serializer = null)(implicit ct: ClassTag[C]): RDD[(K, C)]
        For RDD of (K,V), 
        //createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C
        Turns an RDD[(K, V)] into a result of type RDD[(K, C)], for a 'combined type' C.
        For same Key, K, 
            �createCombiner, which converts first V into a C 
            �mergeValue, to merge a V(from remaining Vs) into a C 
            �mergeCombiners, to combine two C into a single one.
        >>> val x = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        def cc(x:Int) = x.toString
        def mv(c:String, v:Int) = c + v.toString
        def mc(c1:String, c2:String) = c1+c2
        x.combineByKeyWithClassTag[String](cc _,mv _ ,mc _).collect.sorted 
        //[('a', '11'), ('b', '1')]
        x.combineByKey(cc _,mv _ ,mc _).collect.sorted 

    
org.apache.spark.rdd.RDD[T] extends Serializable with Logging   
    def collect[U](f: PartialFunction[T, U])(implicit arg0: ClassTag[U)): RDD[U]
        Return an RDD that contains all matching values by applying f.
    def collect(): Array[T]
        
    def ++(other: RDD[T)): RDD[T]  //union 
    def union(other: RDD[T)): RDD[T]
        Return the union of this RDD and another one.
        val rdd = sc.parallelize(Array(1, 1, 2, 3))
        >>> rdd.union(rdd).collect()
        [1, 1, 2, 3, 1, 1, 2, 3]
        
    def cartesian[U](other: RDD[U))(implicit arg0: ClassTag[U)): RDD[(T, U)]
        Return the Cartesian product of this RDD and another one, 
        that is, the RDD of all pairs of elements (a, b) where a is in this and b is in other.
        val rdd = sc.parallelize(Array(1, 2))
        >>> rdd.cartesian(rdd).collect()
        [(1, 1), (1, 2), (2, 1), (2, 2)]
        >>> rdd.cartesian(rdd).collect{case (x,y) if x % 2 == 0 => y }.collect()
        res14: Array[Int] = Array(1, 2)
        
    def count(): Long
        Return the number of elements in the RDD.
        >>> sc.parallelize(Array(2, 3, 4)).count()
        3
        
    def countByValue()(implicit ord: Ordering[T] = null): Map[T, Long]
        Return the count of each unique value in this RDD as a local map of (value, count) pairs.
        >>> sc.parallelize(Array(1, 2, 1, 2, 2), 2).countByValue().toList 
        [(1, 2), (2, 3)]
        
    def distinct(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T]
    def distinct(): RDD[T]
        Return a new RDD containing the distinct elements in this RDD.
        >>> sc.parallelize(Array(1, 1, 2, 3)).distinct().collect()
        [1, 2, 3]

    def filter(f: (T) => Boolean): RDD[T]
        Return a new RDD containing only the elements that satisfy a predicate.
        val rdd = sc.parallelize(Array(1, 2, 3, 4, 5))
        >>> rdd.filter(_ % 2 == 0).collect()
        [2, 4]
    
    def first(): T
        Return the first element in this RDD.
        >>> sc.parallelize(Array(2, 3, 4)).first()
        2
        
    def flatMap[U](f: (T) => TraversableOnce[U))(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by first applying a function to all elements of this RDD, 
        and then flattening the results.
        val rdd = sc.parallelize(Array(2, 3, 4))
        >>> rdd.flatMap(x => 1 to x )).collect()
        [1, 1, 1, 2, 2, 3]
        >>> rdd.flatMap(x => Array((x, x), (x, x))).collect()
        res15: Array[(Int, Int)] = Array((2,2), (2,2), (3,3), (3,3), (4,4), (4,4))

    def aggregate[U](zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): U
        Aggregate the elements of each partition, 
        and then the results for all the partitions, using given combine functions 
        and a neutral "zero value"
        Like foldLeft(zeroValue)(seqOp) on each Partition
        then results collected from each partition are aggregated using combOp
             >>> sc.parallelize(Array(1, 2, 3, 4)).aggregate((0, 0))((u,v)=>(u._1+v, u._2+1), (u1,u2) => (u1._1+u2._1,u1._2+u2._2))
            (10, 4)
    
    def fold(zeroValue: T)(op: (T, T) => T): T
        Aggregate the elements of each partition, and then the results for all the partitions, 
        using a given associative function and a neutral "zero value".
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).fold(0)(_+_)
        15
    
    def reduce(f: (T, T) => T): T
        Reduces the elements of this RDD using the specified commutative 
        and associative binary operator.
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).reduce(_+_)
        15
    
    def treeAggregate[U](zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U, depth: Int = 2)(implicit arg0: ClassTag[U)): U
        Aggregates the elements of this RDD in a multi-level tree pattern.
        depth � suggested depth of the tree (default: 2) 
        val rdd = sc.parallelize(Array(-5, -4, -3, -2, -1, 1, 2, 3, 4), 10)
        >>> rdd.treeAggregate(0)(_+_ , _+_ ,2)        -5
    
    def treeReduce(f: (T, T) => T, depth: Int = 2): T
        Reduces the elements of this RDD in a multi-level tree pattern.
        val rdd = sc.parallelize(Array(-5, -4, -3, -2, -1, 1, 2, 3, 4], 10)
        >>> rdd.treeReduce(_+_, 2)        -5

    def foreach(f: (T) => Unit): Unit
        Applies a function f to all elements of this RDD.
        >>> def f[T](x:T) = println(x)
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).foreach(f) 
    
    def foreachPartition(f: (Iterator[T]) => Unit): Unit
        Applies a function f to each partition of this RDD.
        >>> def f[T](iterator:Iterator[T])=   for (x <- iterator) println(x)
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).foreachPartition(f)    

    def glom(): RDD[Array[T]]
        Return an RDD created by coalescing all elements within each partition into an array.
        val rdd = sc.parallelize(Array(1, 2, 3, 4), 2)
        >>> rdd.glom().collect()
        res15: Array[Array[Int]] = Array(Array(1, 2), Array(3, 4))
        
    def groupBy[K](f: (T) => K, p: Partitioner)(implicit kt: ClassTag[K], ord: Ordering[K] = null): RDD[(K, Iterable[T))]
    def groupBy[K](f: (T) => K, numPartitions: Int)(implicit kt: ClassTag[K)): RDD[(K, Iterable[T))]
    def groupBy[K](f: (T) => K)(implicit kt: ClassTag[K)): RDD[(K, Iterable[T))]
        Return an RDD of grouped items.   Note result is Paired RDD, so implicits PairedRDD functions are applicable 
        val rdd = sc.parallelize(Array(1, 1, 2, 3, 5, 8))
        val result = rdd.groupBy( _ % 2).collect() // Array[(Int, Iterable[Int])]
        >>> result.map{case (i,j) => (i, j.toList)}

    def intersection(other: RDD[T], numPartitions: Int): RDD[T]
    def intersection(other: RDD[T], partitioner: Partitioner)(implicit ord: Ordering[T] = null): RDD[T]
    def intersection(other: RDD[T)): RDD[T]
        Return the intersection of this RDD and another one.
        val rdd1 = sc.parallelize(Array(1, 10, 2, 3, 4, 5))
        val rdd2 = sc.parallelize(Array(1, 6, 2, 3, 7, 8))
        >>> rdd1.intersection(rdd2).collect()
        [1, 2, 3]
    
    def isCheckpointed: Boolean
        Return whether this RDD is checkpointed and materialized, either reliably or locally.
        
    def isEmpty(): Boolean
        >>> sc.parallelize(Array()).isEmpty()
        true
        >>> sc.parallelize(Array(1)).isEmpty()
        false
        
    def keyBy[K](f: (T) => K): RDD[(K, T)]
        Creates tuples of the elements in this RDD by applying f.
        Note result is Paired RDD, so implicits PairedRDD functions are applicable 
        val x = sc.parallelize(range(0,3)).keyBy(x => x*x)
        >>> x.collect()
        [(0, 0), (1, 1), (4, 2)]

    def map[U](f: (T) => U)(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by applying a function to all elements of this RDD.
        val rdd = sc.parallelize(Array("b", "a", "c"))
        >>> rdd.map(x => (x, 1)).collect().sorted
        [('a', 1), ('b', 1), ('c', 1)]

    def mapPartitions[U](f: (Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by applying a function to each partition of this RDD.
        val rdd = sc.parallelize(Array(1, 2, 3, 4), 2)
        >>> def f(iterator:Iterator[Int]) = iterator.map(x=>x*x)
        >>> rdd.mapPartitions(f).glom().collect
        res26: Array[Array[Int]] = Array(Array(1, 4), Array(9, 16))
    
    def mapPartitionsWithIndex[U](f: (Int, Iterator[T]) => Iterator[U), preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by applying a function to each partition of this RDD, while tracking the index of the original partition.
        val rdd = sc.parallelize(Array(1, 2, 3, 4), 4)
        >>> def f(index:Int,iterator:Iterator[Int]) = iterator.map(x=>x*index)
        >>> rdd.mapPartitionsWithIndex(f).sum()
        7.0

    def max()(implicit ord: Ordering[T]): T
    def min()(implicit ord: Ordering[T]): T
        Returns the max of this RDD as defined by the implicit Ordering[T].
        val rdd = sc.parallelize(Array(1.0, 5.0, 43.0, 10.0))
        >>> rdd.max()
        43.0            
  
    def randomSplit(weights: Array[Double), seed: Long = Utils.random.nextLong): Array[RDD[T]]
        Randomly splits this RDD with the provided weights.
        val rdd = sc.parallelize(0 to 500, 1)
        >>> val rdds = rdd.randomSplit(Array(2, 3), 17)
        >>> rdds(0).collect().size + rdds(1).collect().size
        501  

    def sample(withReplacement: Boolean, fraction: Double, seed: Long = Utils.random.nextLong): RDD[T]
        Return a sampled subset of this RDD.
        val rdd = sc.parallelize(0 to 100, 4)
        >>> 6 <= rdd.sample(false, 0.1, 81).count() &&  rdd.sample(false, 0.1, 81).count() <= 14
        true

    def saveAsObjectFile(path: String): Unit
    def saveAsTextFile(path: String, codec: Class[_ <: CompressionCodec)): Unit
    def saveAsTextFile(path: String): Unit

    def sortBy[K](f: (T) => K, ascending: Boolean = true, numPartitions: Int = this.partitions.length)(implicit ord: Ordering[K), ctag: ClassTag[K)): RDD[T]
        Return this RDD sorted by the given key function.
        val tmp = Array(('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5))
        >>> sc.parallelize(tmp).sortBy(_._1).collect()
        res32: Array[(Char, Int)] = Array((1,3), (2,5), (a,1), (b,2), (d,4))
    
    def subtract(other: RDD[T), p: Partitioner)(implicit ord: Ordering[T] = null): RDD[T]
    def subtract(other: RDD[T), numPartitions: Int): RDD[T]
    def subtract(other: RDD[T]): RDD[T]
        Return an RDD with the elements from this that are not in other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4), ("b", 5), ("a", 3)))
        val y = sc.parallelize(Array(("a", 3), ("c", 2)))
        >>> x.subtract(y).collect().sorted
        res34: Array[(String, Int)] = Array((a,1), (b,4), (b,5))

    def take(num: Int): Array[T]
        Take the first num elements of the RDD.
         >>> sc.parallelize(Array(2, 3, 4, 5, 6)).cache().take(2)
        [2, 3]
        
    def takeOrdered(num: Int)(implicit ord: Ordering[T]): Array[T]
        Returns the first k (smallest) elements from this RDD as defined by the specified implicit Ordering[T] and maintains the ordering.
        >>> sc.parallelize(Array(10, 1, 2, 9, 3, 4, 5, 6, 7)).takeOrdered(6)
        [1, 2, 3, 4, 5, 6]

    def takeSample(withReplacement: Boolean, num: Int, seed: Long = Utils.random.nextLong): Array[T]
        Return a fixed-size sampled subset of this RDD in an array
        val rdd = sc.parallelize(0 to 10)
        >>>rdd.takeSample(true, 20, 1).size
        20
   
    def toDebugString: String
        A description of this RDD and its recursive dependencies for debugging.
        
    def toLocalIterator: Iterator[T]
        Return an iterator that contains all of the elements in this RDD.
        val rdd = sc.parallelize(0 to 10)
        >>> rdd.toLocalIterator().toList 
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def top(num: Int)(implicit ord: Ordering[T]): Array[T]
        Returns the top k (largest) elements from this RDD as defined by the specified implicit Ordering[T] and maintains the ordering.
        >>> sc.parallelize(Array(10, 4, 2, 12, 3)).top(1)
        [12]        
    
    def zip[U](other: RDD[U))(implicit arg0: ClassTag[U)): RDD[(T, U)]
        Zips this RDD with another one, returning key-value pairs with the first element in each RDD, 
        second element in each RDD, etc.Note this and other must have same partitions and same number of elements in each parition 
        Note result is Paired RDD, so implicits PairedRDD functions are applicable 
        val x = sc.parallelize(0 to 5)
        val y = sc.parallelize(1000 to 1005)
        >>> x.zip(y).collect()
        res35: Array[(Int, Int)] = Array((0,1000), (1,1001), (2,1002), (3,1003), (4,1004), (5,1005))
       
    def zipWithIndex(): RDD[(T, Long)]
        Zips this RDD with its element indices.
        >>> sc.parallelize(Array("a", "b", "c", "d"), 3).zipWithIndex().collect()
        [('a', 0), ('b', 1), ('c', 2), ('d', 3)]

    def zipWithUniqueId(): RDD[(T, Long)]
        Zips this RDD with generated unique Long ids.
        >>> sc.parallelize(Array("a", "b", "c", "d", "e"), 3).zipWithUniqueId().collect()
        [('a', 0), ('b', 1), ('c', 4), ('d', 2), ('e', 5)]
  
    def coalesce(numPartitions: Int, shuffle: Boolean = false, partitionCoalescer: Option[PartitionCoalescer] = Option.empty)(implicit ord: Ordering[T] = null): RDD[T]
        Return a new RDD that is reduced into numPartitions partitions.
         >>> sc.parallelize(Array(1, 2, 3, 4, 5), 3).glom().collect()
        [[1), [2, 3), [4, 5]]
        >>> sc.parallelize(Array(1, 2, 3, 4, 5), 3).coalesce(1).glom().collect()
        [[1, 2, 3, 4, 5]]
        
    def partitions: Array[Partition]
    def unpersist(blocking: Boolean = true): RDD.this.type
    def persist(): RDD.this.type
    def persist(newLevel: StorageLevel): RDD.this.type
    def cache(): RDD.this.type
    def checkpoint(): Unit
    def getCheckpointFile: Option[String]
    def localCheckpoint(): RDD.this.type
    def getNumPartitions: Int
    def context: SparkContext
    def sparkContext: SparkContext
    def getStorageLevel: StorageLevel
    val id: Int

     
     
///*** Shuffling  Affect 
case class CFFPurchase(customerId: Int, destination: String, price: Double)

val purchases = List( CFFPurchase(100, "Geneva", 22.25),
                      CFFPurchase(100, "Zurich", 42.10),
                      CFFPurchase(100, "Fribourg", 12.40),
                      CFFPurchase(100, "St.Gallen", 8.20),
                      CFFPurchase(100, "Lucerne", 31.60),
                      CFFPurchase(100, "Basel", 16.20) )

                      
val purchasesRdd = sc.parallelize(purchases,3)
>>> purchasesRdd.glom().collect()
[[CFFPurchase(customerId=100, destination='Geneva', price=22.25), CFFPurchase(customerId=100, destination='Zurich', price=42.1)), 
[CFFPurchase(customerId=100, destination='Fribourg', price=12.4), CFFPurchase(customerId=100, destination='St.Gallen', price=8.2)), 
[CFFPurchase(customerId=100, destination='Lucerne', price=31.6), CFFPurchase(customerId=100, destination='Basel', price=16.2)]]

//Calculate how many trips, and how much money was spent by each individual customer over the course of the month.
val purchasesPerMonth = purchasesRdd.map( p => (p.customerId, p.price) ) // pair RDD
                                    .groupByKey()                        // RDD[K, Iterable[V]] i.e RDD[p.customerId, Iterable[p.price]]
                                    .map( p => (p._1, (p._2.size, p._2.sum)) )
                                   
 
    
purchasesPerMonth.collect()
>>> purchasesPerMonth.toDebugString()
(3) PythonRDD[32] at RDD at PythonRDD.scala:48 []
 |  MapPartitionsRDD[31] at mapPartitions at PythonRDD.scala:122 []
 |  ShuffledRDD[30] at partitionBy at NativeMethodAccessorImpl.java:0 []
 +-(3) PairwiseRDD[29] at groupByKey at <stdin>:2 []
    |  PythonRDD[28] at groupByKey at <stdin>:2 []
    |  ParallelCollectionRDD[16] at parallelize at PythonRDD.scala:175 []


*** Mastering_spark.docx :: Spark Shuffling

//Can we do a better job?,use reduceByKey.

val purchasesPerMonth = purchasesRdd.map( p => (p.customerId, (1, p.price)) ) // pair RDD
                                    .reduceByKey( (v1, v2) => (v1._1 + v2._1, v1._2 + v2._2) )
                                                       

purchasesPerMonth.collect()                          
>>>purchasesPerMonth.toDebugString()
(3) PythonRDD[27] at RDD at PythonRDD.scala:48 []
 |  MapPartitionsRDD[26] at mapPartitions at PythonRDD.scala:122 []
 |  ShuffledRDD[25] at partitionBy at NativeMethodAccessorImpl.java:0 []
 +-(3) PairwiseRDD[24] at reduceByKey at <stdin>:3 []
    |  PythonRDD[23] at reduceByKey at <stdin>:3 []
    |  ParallelCollectionRDD[16] at parallelize at PythonRDD.scala:175 []
    
    
//Operations that might cause a shuffle:
�	cogroup
�	groupWith
�	join
�	leftOuterJoin
�	rightOuterJoin
�	groupByKey
�	reduceByKey
�	combineByKey
�	distinct
�	intersection
�	repartition
�	coalesce

//Common scenarios where Network Shuffle can be avoided using Partitioning
1.	reduceByKey running on a pre-partitioned RDD will cause the values to be computed locally, 
     requiring only the final reduced value to be sent from worker to the driver.
2.	join called on 2 RDDs that are pre-partitioned with the same partitioner 
    and cached on the same machine will cause the join to be computed locally, with no shuffling across the network.



    
    
        
///*** Example Iris

val iris = sc.textFile(raw"D:\Desktop\PPT\spark\data\iris.csv", 8)

>>> iris.take(5)
es44: Array[String] = Array('SepalLength,SepalWidth,PetalLength,PetalWidth,Name', '5.1,3.5,1.4,0.2,Iris-setosa', '4.9,3.0,1.4,0.2,Iris-setosa', '4.7,3.2,1.3,0.2,Iris-setosa', '4.6,3.1,1.5,0.2,Iris-setosa')

//remove header 
val iris1 = iris.zipWithIndex().filter(t => t._2 != 0).map(t => t._1.split(","))

val iris2 = iris1.map(t => (t.last , t.init.map(x=>x.toDouble)))

val uniqueName = iris2.groupByKey().keys.collect


//Create a Partitioner based on "Name"
case class NamePartioner(partitions:Int, lst:Array[String]) extends Partitioner{
    def getPartition(key: Any): Int = {
                lst.indexOf(key.asInstanceOf[String]) % partitions
             }
    def numPartitions: Int = partitions
    }

val iris3 = iris2.groupByKey(NamePartioner(3,uniqueName))//new org.apache.spark.HashPartitioner(3)) 
//Array[(String, Iterable[Array[Double]])]

>>> iris3.glom().take(3)  //ie each partition has only one element ie (Name, Iterable( Array(1st row), Array(2nd Row )) )
es49: Array[Array[(String, Iterable[Array[Double]])]] = Array(Array((Iris-setosa,CompactBuffer([D@788bbbaa, [D@5d3ccbc3, [D@7a369174, [D@7a95626b, [D@5fe6d078,[D@64bf6a94, [D@2accea46, [D@7b9b434e, [D@12973955, [D@de31a59, [D@40b04f79, [D

>>> iris3.first()
es50: (String, Iterable[Array[Double]]) = (Iris-setosa,CompactBuffer([D@12f2ea1

iris3.foreachPartition(it => println(it.toList))


//preserve key and partitioning 
//it contains only one element (as partition contains one element)
//func: (it: Iterator[(String, Iterable[Array[Double]])], which: Int):Iterator[(String, List[Double])]
def func(it:Iterator[(String, Iterable[Array[Double]])], which:Int=0)={
    val lst = it.toList(0) //tuple (String, Iterable[Array[Double]])
    //println(lst)
    //must return a iterator  for that partition
    List( (lst._1, lst._2.toList.map(array => array(which)))).iterator
}
//OR 

def func(it:Iterator[(String, Iterable[Array[Double]])], which:Int=0)={
    def each(key:String, lst: Iterable[Array[Double]]) = {
        val value = lst.toList.map(array => array(which))))
        (key -> value)
    }
    it.toList.map{case(key, lst) => each(key,lst)}.iterator //keep the key , must return iter 
}


val iris4 = iris3.mapPartitions(it => func(it,0), true)
>>> iris4.first
res51: (String, List[Double]) = (Iris-setosa,List(5.1, 4.9, 4.7, 4.6, 5.0, 5.4..

val iris5 = iris4.map(t => (t._1, Map("max"-> t._2.max) ))   

>>> iris5.collect()            
res81: Array[(String, scala.collection.immutable.Map[String,Double])] = Array((Iris-virginica,Map(max -> 7.9)), (Iris-versicolor,Map(max -> 7.0)), (Iris-setosa,Map(max -> 5.8)))           
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

    







       


///*** HandsOn Device.txt 
//Open device.txt 
//eventTime,deviceId,signal 

Q1. Count of unique deviceId and count by each deviceId 

Q2. Parition based on DeviceId and get all signals and size 

Q3.Find deviceId and its signal between 2017-08-23T00:00:00.002Z - 2017-08-23T00:10:00.002Z 


Q4. Find all Device IDs between 10 min windows    
    

    
///Ans: 
val lines = sc.textFile("./data/spark/device.txt")

//Q1. Count of deviceId 
val propValue = "2017-08-23T00:00:00.002Z"
val DATE_STRING_ISO_8601 = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
val sdfISO8601 = new java.text.SimpleDateFormat(DATE_STRING_ISO_8601)
sdfISO8601.parse(propValue)


val rows = lines.map(l => l.split(',')).map(r =>  (sdfISO8601.parse(r(0)),r(1),r(2).toInt)) //(java.util.Date, String, Int)
val kv_rows = rows.keyBy(r => r._2)  //('mine', (datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), 'mine', 20))

val unq = kv_rows.map(t => t._1).distinct().collect()
//['yours', 'his', 'mine']



kv_rows.countByKey()
//Map(his -> 6, yours -> 6, mine -> 6)




Q2. Parition based on DeviceId and get all signals and size 
    
case class NamePartioner(lst:Array[String]) extends org.apache.spark.Partitioner{
    def getPartition(key: Any): Int = {
                lst.indexOf(key.asInstanceOf[String]) % numPartitions
             }
    def numPartitions: Int = lst.size
    }    

def key(r:(java.util.Date, String, Int))=r._2 //not infered?
    
val kv = rows.groupBy(key _, NamePartioner(unq)) //('yours', Iterable)
kv.getNumPartitions
kv.keys.collect()

//RDD[(String, Iterable[(java.util.Date, String, Int)])]
def partFunc1(itr:Iterator[(String, Iterable[(java.util.Date, String, Int)])])={ 
    val lst = itr.toList(0) //single value , [(key, itr)]
    //or if many values, then itr.toList.map{case(key, lst) => }
    val value = lst._2.toList.map(_._3) 
    Iterator( (lst._1, value, value.size)  ) //keep the key , must return iter 
}


kv.mapPartitions(it => partFunc1(it), true).collect() 

//OR if many values 
def partFunc1(itr:Iterator[(String, Iterable[(java.util.Date, String, Int)])])={ 
    def each(key:String, lst: Iterable[(java.util.Date, String, Int)]) = {
        val value = lst.toList.map(_._3) 
        (key, value, value.size)
    }
    itr.toList.map{case(key, lst) => each(key,lst)}.iterator //keep the key , must return iter 
}
kv.mapPartitions(it => partFunc1(it), true).collect() 



Q3.Find deviceId and it's' signal between 2017-08-23T00:00:00.002Z - 2017-08-23T00:10:00.002Z 
val start = sdfISO8601.parse("2017-08-23T00:00:00.002Z")
val end = sdfISO8601.parse("2017-08-23T00:10:00.002Z")

def partFunc2(itr:Iterator[(String, Iterable[(java.util.Date, String, Int)])], start:java.util.Date =start,end:java.util.Date =end)={
    val lst = itr.toList(0) //single value , [(key, itr)]
    val value = lst._2.toList.filter(r => (r._1 == start) || (r._1.after(start) && r._1.before(end))).map(_._3)
    Iterator( (lst._1, value, value.size)  ) //keep the key , must return iter 
}

def partFunc2(itr:Iterator[(String, Iterable[(java.util.Date, String, Int)])], start:java.util.Date =start,end:java.util.Date =end)={
    def each(key:String, lst: Iterable[(java.util.Date, String, Int)]) = {
        val value = lst.toList.filter(r => (r._1 == start) || (r._1.after(start) && r._1.before(end))).map(_._3)
        (key, value, value.size)
    }
    itr.toList.map{case(key, lst) => each(key,lst)}.iterator //keep the key , must return iter 
}

kv.mapPartitions(it => partFunc2(it), true).collect() 





Q4. Find all Device IDs between 10 minute windows    
//get max and min in each partitions
def partFunc3(itr:Iterator[(String, Iterable[(java.util.Date, String, Int)])])={
    val lst = itr.toList(0) //single value , [(key, itr)]
    val value = lst._2.toList.map(_._1) 
    Iterator( (lst._1, value.max, value.min)  )//keep the key , must return iter 
}  //Iterator[(String, java.util.Date, java.util.Date)]

def partFunc3(itr:Iterator[(String, Iterable[(java.util.Date, String, Int)])])={
    def each(key:String, lst: Iterable[(java.util.Date, String, Int)]) = {
        val value = lst.toList .map(_._1) 
        (key, value.max, value.min)
    }
    itr.toList.map{case(key, lst) => each(key,lst)}.iterator //keep the key , must return iter 
}

//get all max and min 
//Note fold does not work as there is no combine op in that method, Use Aggregate 


//FInd all min and max Dates 
//(String, java.util.Date, java.util.Date)
val ds = kv.mapPartitions(it => partFunc3(it), true).aggregate(Array[java.util.Date]())((r,t) => r :+ t._2 :+ t._3, (r,l) => r++l)

//find overall min and max 
val min_d = ds.min 
val max_d = ds.max 


def getBins(mx:java.util.Date, mn:java.util.Date, each:Int)={
    import java.time._ 
    def add(date:java.util.Date)={
        val instant = Instant.ofEpochMilli(date.getTime())
        val ldt = LocalDateTime.ofInstant(instant, ZoneOffset.UTC)
        val ldt2 = ldt.plusMinutes(each) 
        val instant2 = ldt2.toInstant(ZoneOffset.UTC);
        java.util.Date.from(instant2)
    }
    val bins = scala.collection.mutable.ArrayBuffer[(java.util.Date, java.util.Date)]()    
    //first 
    bins += (mn -> add(mn))  //-> must 
    while (bins.last._2.before(mx)){
        bins += (bins.last._2 -> add(bins.last._2))
    }
    //last bin 
    bins += (bins.last._2 -> add(bins.last._2)) //for anything beyond 
    bins.toArray
}

val bins = getBins(max_d, min_d, 10) //Array[(java.util.Date, java.util.Date)]

    
//put exact bin number 
def by(r:(java.util.Date, String, Int), bins:Array[(java.util.Date, java.util.Date)]=bins )=
    bins.zipWithIndex.filter{case((st,en), i) => (r._1 == st) || (r._1.after(st) && r._1.before(en))}.map{case((st,en), i) => i}.apply(0)

case class NamePartioner1(num:Int) extends org.apache.spark.Partitioner{
    def getPartition(key: Any): Int = {
                key.asInstanceOf[Int] % numPartitions
             }
    def numPartitions: Int = num
    }  
    
    
//RDD[(Int, Iterable[(java.util.Date, String, Int)]
val date_kv = rows.groupBy((r:(java.util.Date, String, Int)) => by(r), NamePartioner1(bins.size)) //('yours', Iterable)

>>> date_kv.glom().collect()
res35: Array[Array[(Int, Iterable[(java.util.Date, String, Int)])]] = Array(Array((0,CompactBuffer((Wed Aug 23 00:00:00 IST 2017,mine,20), (Wed Aug 23 00:05:00
IST 2017,mine,30), (Wed Aug 23 00:09:00 IST 2017,mine,40), (Wed Aug 23 00:00:00IST 2017,yours,20), (Wed Aug 23 00:05:00 IST 2017,yours,30), (Wed Aug 23 00:09:0
0 IST 2017,yours,40), (Wed Aug 23 00:00:00 IST 2017,his,20), (Wed Aug 23 00:05:00 IST 2017,his,30), (Wed Aug 23 00:09:00 IST 2017,his,40)))), Array((1,CompactBu
ffer((Wed Aug 23 00:11:00 IST 2017,mine,50), (Wed Aug 23 00:11:00 IST 2017,yours,50), (Wed Aug 23 00:11:00 IST 2017,his,50)))), Array(), Array(), Array((4,Compa
ctBuffer((Wed Aug 23 00:49:59 IST 2017,mine,70), (Wed Aug 23 00:49:59 IST 2017,yours,70), (Wed Aug 23 00:49:59 IST 2017,his,70)))), Array(), Array((6,Compact...


//flatten it now , but some partition might be empty as no deviceId in that group 
//Iterator[(Int, Iterable[(java.util.Date, String, Int)])]

def partFunc41(itr:Iterator[(Int, Iterable[(java.util.Date, String, Int)])], bins:Array[(java.util.Date, java.util.Date)]= bins)={ 
    def each(key:Int, lst: Iterable[(java.util.Date, String, Int)]) = {
        val value = lst.toList.map(_._2) 
        (key -> (value, value.size, bins(key)))
    }
    itr.toList.map{case (key, lst) => each(key,lst)}.iterator //keep the key , must return iter 
}

val res = date_kv.mapPartitions(itr => partFunc41(itr,bins), true)//RDD[(Int, (Iterable[String], Int, (java.util.Date, jav.util.Date)))] 

//print window vs deviceIds 
//(Int, (List[String], Int, (java.util.Date, java.util.Date)))
res.map{case (index, (ds,c,win)) => (win,ds)}.foreach(println)






///*** Spark - DataFrames - SparkSession 
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.{functions => F}

//concept 
Dataset[T]
    Typed one     
    T(each element) can be primitives , Array, Seq, Set, Map of those 
    or case class or Tuple of these (for whom Encoder is present, for implicits, check SQLImplicits)
    map,filter,reduce.. can handle T as each element 
    To convert from DataFrame to Dataset[U], use df.as[U], U is case class or tuple or a class child of Product 
DataFrame 
    untyped, each element is Row(*Any) ie type val DataFrame = Dataset[Row] 
    map,filter,reduce only can handle Row(Any*) , use case Pattern matching or casting Any to Type 
    Row elements can be of StructType(another row), primitives(LongType, StringType,...), ArrayType of other elements , MapType 
    Use apply(index/key), getItem(index/key) or getField(fieldName) or field1.field2 for accessing nested element of MapType, ArrayType, StructType
    

    
///Displaying DataFrame - Note various options of show 
def  show(numRows: Int, truncate: Int): Unit 
def  show(numRows: Int, truncate: Boolean): Unit 
def  show(truncate: Boolean): Unit 
def  show(): Unit   //Displays the top 20 rows of Dataset in a tabular form.
def  show(numRows: Int): Unit 
//to display all columns and all rows use 
df.show(Int.MaxValue, false)


///Column : A column in a DataFrame.

//Columns have +, -, like, and many operations , check http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.Column
//Also column can take any functions defined in http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$

//A new column is constructed based on the input columns present in a dataframe:
import spark.implicits._   //for conversion from $"col" to Column
df("columnName")            // On a specific DataFrame.
F.col("columnName")           // A generic column no yet associated with a DataFrame.
F.col("columnName.field")     // Extracting a struct field
F.col("`a.column.with.dots`") // Escape `.` in column names.
$"columnName"               // Scala short hand for a named column.
F.expr("a + 1")               // A column that is constructed from a parsed SQL Expression.
F.lit("abc")                  // A column that produces a literal (constant) value.
'columnName                   //from symbol , only inside method which expects Column , '
F.col("aliasName.columnName"), $"aliasName.columnName", if you create a alias of DataFrame by .alias("aliasName")
Many methods also take string ColumnName eg "aliasName.columnName", "columnName", "columnName.field" etc 

//Many Methods 
explain(extended: Boolean): Unit
apply(extraction: Any): Column //for complex type 
%, *, +, -, / , <, <=, ===(note the equality), =!=(note for enequality),...
&&, !, ||
alias(alias: String): Column,   as(alias: String, metadata: Metadata): Column
as(aliases: Seq[String]): Column,   as(alias: String): Column,  cast(to: String): Column//to is string of DataType 
contains(other: Any): Column, asc: Column, asc_nulls_first: Column, asc_nulls_last: Column, desc: Column, desc_nulls_first: Column, desc_nulls_last: Column
endsWith/startsWith(literal: String): Column,   endsWith/startsWith(other: Column): Column 
getField(fieldName: String): Column,    getItem(key: Any): Column
isin(list: Any*): Column,   like(literal: String): Column,  rlike(literal: String): Column
when(condition: Column, value: Any): Column,    otherwise(value: Any): Column
over(window: WindowSpec): Column
substr(startPos: Int, len: Int): Column     substr(startPos: Column, len: Column): Column
as[U](implicit arg0: Encoder[U]): TypedColumn[Any, U], expr: Expression



///Row 
val row = Row(1, true, "a string", null)  //Any*
val firstValue = row(0)
val fourthValue = row(3)

val firstValue = row.getInt(0)// firstValue: val Int = 1
val isNull = row.isNullAt(3)// isNull: val Boolean = true

import org.apache.spark.sql._
val pairs = spark.sql("SELECT key, value FROM src").rdd.map {
  case Row(key: Int, value: String) =>
    key -> value
}  

//many methods 
apply(i: Int): Any 
fieldIndex(name: String): Int 
getAs[T](fieldName: String): T 
getAs[T](i: Int): T 
getBoolean(i: Int): Boolean , getInt(i:Int):Int,,getDate(i: Int): java.sql.Date ,getTimestamp(i: Int): java.sql.Timestamp , ....
getList[T](i: Int): List[T],getMap[K, V](i: Int): Map[K, V] ,getSeq[T](i: Int): Seq[T] ,getStruct(i: Int): Row 
getValuesMap[T](fieldNames: Seq[String]): Map[String, T] 
isNullAt(i: Int): Boolean 
schema: StructType 
size: Int 
toSeq: Seq[Any] 
Row.empty: Row 
Row.fromSeq(values: Seq[Any]): Row ,Row.fromTuple(tuple: Product): Row 
Row.merge(rows: Row*): Row 
  
  
  
///Convert to To RDD[Row] ie each element is Row(*Any) 
df.rdd 

///Creation of DF (untyped, manipulate Row(Any*) or by columnName) or DS(typed, manipulate by case class attributes or tuple access)



import spark.implicits._ 

//If  RDD[Row], must use schema in createDataFrame , Row can contain another Row, ArrayType, MapType, primitives 
//Seq[Product],RDD[Product], use createDataFrame, no schema is required , Product is case class 
spark.createDataFrame(rowRDD: RDD[Row], schema: StructType): DataFrame
spark.createDataFrame[A <: Product](data: Seq[A])(implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[A]): DataFrame
spark.createDataFrame[A <: Product](rdd: RDD[A])(implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[A]): DataFrame

//If Seq[T], RDD[T], where T must not be Row 
//use createDataSet or toDS() or df.as[T] for DataSet or toDF()/toDF(*cols) for DataFrame , no schema is required 
//but Encoders[T] must be present , T /each element must ie primitives , Array, Seq, Set, Map of those 
//or case class or Tuple of these or nested of these(for implicits, check SQLImplicits)
toDF(colNames: String*): DataFrame 
toDF(): DataFrame 
toDS(): Dataset[T]  
spark.createDataset[T](data: RDD[T])(implicit arg0: Encoder[T]): Dataset[T]
spark.createDataset[T](data: Seq[T])(implicit arg0: Encoder[T]): Dataset[T]


//FOr RDD[Row], use createDataFrame with schema of StructType 
//for RDD[caseclass or tuple) use createDataFrame without schema 

//FOr RDD[tuple or case class or Array or Map or Primitives..] use toDF(cols*) or toDS() or createDataset without schema
//for Seq[tuple or caseclass or Array or Map or Primitives..], use above as well 



///Spark - DataFrame - Getting a row or column of DF 
df.select(*cols)
    Projects a set of expressions and returns a new DataFrame.
    cols � var args  of column names (string) 
           or expressions involving Column instances 
           If one of the column names is '*', 
           that column is expanded to include all columns in the current DataFrame. 
df.show(n =20, val truncate =True)
    Prints the first n rows to the console.
df.columns
    Returns all column names as a list.
    >>> df.columns
    ['age', 'name']
df.collect()
    Returns all the records as a list of Row.
    >>> df.collect()
    [Row(age =2, val name =u'Alice'), Row(age =5, val name =u'Bob')]
 
    
//Getting a named column is 
df.select("colname")  //return DataFrame , to display, do .show()
df.select(df["colname"])
df.select(F.col("colname"))
df.select(df.colName)

//To get Single column based on   column index 
df.select(F.col(df.columns[index])) //return DataFrame, to display, do .show()


//To get a row 
///Not straight forward as DF are distributed 
val myIndex = 1
val values = (df.rdd.zipWithIndex.     //(k,v),index 
            filter((t,i) => i == myIndex).
            map((t,i) => t)
            collect())
println(values(0))
// (u'b', 2)








///From RDD[Row] and schema , use createDataFrame
// Create an RDD an specify schema 
import spark.implicits._
val peopleRDD = spark.sparkContext.textFile(raw".\data\spark\people.txt")
// The schema is encoded in a string
val schemaString = "name age"
// Generate the schema based on the string of schema
val fields = schemaString.split(" ").map(fieldName => StructField(fieldName, StringType, nullable = true)).toList
val schema = StructType(fields)
// Convert records of the RDD (people) to Rows
val rowRDD = peopleRDD.
  map(_.split(",")).
  map(attributes => Row(attributes(0), attributes(1).trim))
// Apply the schema to the RDD
val peopleDF = spark.createDataFrame(rowRDD, schema)  //toDF() does not work for Row as Row does not have implicit Encoder 


//Using createDataset but with T as product 
case class Person(name: String, age: Long)
val data = Seq(Person("Michael", 29), Person("Andy", 30), Person("Justin", 19))
val ds = spark.createDataset(data)
ds.show()


///From RDD[T] where T is not Row, but case class or Tuple 
import spark.implicits._  //toDF()
case class Person(name: String, age: Long)
val peopleDF = spark.sparkContext.
  textFile(raw".\data\spark\people.txt").
  map(_.split(",")).
  map(attributes => Person(attributes(0), attributes(1).trim.toInt)).
  toDF()  //peopleDF: org.apache.spark.sql.val DataFrame = [name: string, age: bigint]
  
peopleDF.map{case Row(name: String, age: Long) => name } //res87: org.apache.spark.sql.Dataset[String] = [value: string]
>>> peopleDF.printSchema
root
 |-- name: string (nullable = true)
 |-- age: long (nullable = false)

 
//DS 
peopleDF.as[Person] //res90: org.apache.spark.sql.Dataset[Person] = [name: string, age: bigint]

val peopleDF2 = spark.sparkContext.
  textFile(raw".\data\spark\people.txt").
  map(_.split(",")).
  map(attributes => Person(attributes(0), attributes(1).trim.toInt)).
  toDS()  //peopleDF2: org.apache.spark.sql.Dataset[Person] = [name: string, age: bigint]
  
peopleDF2.map(_.name) //res88: org.apache.spark.sql.Dataset[String] = [value: string]
>>> peopleDF2.printSchema
root
 |-- name: string (nullable = true)
 |-- age: long (nullable = false)


///From Seq[T]
case class UserEvent(id: Int, data: String, isLast: Boolean)
case class UserSession(userEvents: Seq[UserEvent])


>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDS()
res2: org.apache.spark.sql.Dataset[(Int, String, Boolean)] = [_1: int, _2: string ... 1 more field]

//DF column names must match to UserEvent attribute name 
>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDF().as[UserEvent]
org.apache.spark.sql.AnalysisException: cannot resolve '`id`' given input columns: [_1, _2, _3];

>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDS().map{case (id,data,isLast) => UserEvent(id,data,isLast)}
res91: org.apache.spark.sql.Dataset[UserEvent] = [id: int, data: string ... 1 more field]

>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDF("id", "data","isLast").as[UserEvent]
res4: org.apache.spark.sql.Dataset[UserEvent] = [id: int, data: string ... 1 more field]

//each element is Product , Seq[Product] , Array[Product], Set[Product], Map and nested of this 
>>> Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)).toDF()
es104: org.apache.spark.sql.val DataFrame = [id: int, data: string ... 1 more field

>>> Seq( Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)), Seq( UserEvet(1,"XYZ",true), UserEvent(2,"yz",false))).toDF()
res96: org.apache.spark.sql.val DataFrame = [value: array<struct<id:int,data:string,isLast:boolean>>]
>>> res96.map{case Row(value:Seq[_]) => value.size}
res99: org.apache.spark.sql.Dataset[Int] = [value: int]

>>> Seq( Seq( (1,"XYZ",true), (2,"yz",false)), Seq( (1,"XYZ",true), (2,"yz",false))).toDF("userEvents")
res8: org.apache.spark.sql.val DataFrame = [userEvents: array<struct<_1:int,_2:string,_3:boolean>>]

>>> Seq( Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)), Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false))).toDF("userEvents").as[UserSession]
res12: org.apache.spark.sql.Dataset[UserSession] = [userEvents: array<struct<id:int,data:string,isLast:boolean>>]

>>> Seq( Array( (1,"XYZ",true), (2,"yz",false)), Array( (1,"XYZ",true), (2,"yz",false))).toDF("userEvents")
res100: org.apache.spark.sql.val DataFrame = [userEvents: array<struct<_1:int,_2:string,_3:boolean>>]

>>>  Seq( Set( (1,"XYZ",true), (2,"yz",false)), Set( (1,"XYZ",true), (2,"yz",false))).toDF("userEvents")
res101: org.apache.spark.sql.val DataFrame = [userEvents: array<struct<_1:int,_2:string,_3:boolean>>]

>>> res101.collect
res102: Array[org.apache.spark.sql.Row] = Array([WrappedArray([1,XYZ,true], [2,yz,false])], [WrappedArray([1,XYZ,true], [2,yz,false])])

>>>  Seq( Map( 1-> (1,"XYZ",true), 2->(2,"yz",false)), Map(1-> (1,"XYZ",true), 2-> (2,"yz",false))).toDF("userEvents")
res103: org.apache.spark.sql.val DataFrame = [userEvents: map<int,struct<_1:int,_2:string,_3:boolean>>]


//Each element is Seq[UserEvent], then convert to UserSession 
>>> Seq( Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)), Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)))
    .toDS()
    .map { case ue @ Seq(v @ _*) => UserSession(ue) }
res13: org.apache.spark.sql.Dataset[UserSession] = [userEvents: array<struct<id:int,data:string,isLast:boolean>>]








///Complex types 
//from RDD of  tuples, val Schema =  explicit schema 
//Note Column type/value could be Simple type or another complex type 
//ie cell value could be a Array, a Dict/map or structtype or combination 
//sql.functions have many methods which work on cellvalue as array, map or another struct type 
//note metadata is additional info that can be attached to a column 
ArrayType(elementType, val containsNull =True)
MapType(keyType, valueType, val valueContainsNull =True)
StructField(name, dataType, val nullable =True, val metadata =None)
StructType(fields =None) with add(field, val data_type =None, val nullable =True, val metadata =None)

//Complex type , in scala - no string type of below, but in python possible 
StructType      "struct<field_name:field_type,...>"  or "field_name:field_type, .."
MapType         "map<k_type_string, v_type_string>"
ArrayType       "array<element_type>"
//Note StructType(fields) represent a Row.

//Row, schema is must , use createDataFrame
val rdd1 = sc.parallelize(Array(Row("Alice", 1)))
spark.createDataFrame(rdd1, StructType(Array(StructField("name", StringType),StructField("age",IntegerType)))).collect()  //[Row(a =u'Alice', val b =1)]

//tuple/caseclass , use toDF etc 
val rdd2 = sc.parallelize(Array(("Alice", 1)))
rdd2.toDF("name", "age")
rdd2.toDF() 
rdd2.toDS() 


//ArrayType , Row, schema is must , use createDataFrame
val rdd1 = sc.parallelize(Array( Row(Array("Alice", "1"))))
val df = spark.createDataFrame(rdd1, StructType(Array(StructField("array",ArrayType(StringType)) )))//[array: array<string>]

//Array , use toDF etc 
val rdd2 = sc.parallelize(Array( Array("Alice", "1")))

scala> rdd2.toDF()
res28: org.apache.spark.sql.DataFrame = [value: array<string>]
scala> rdd2.toDF("array")
res29: org.apache.spark.sql.DataFrame = [array: array<string>]
scala> rdd2.toDS()
res30: org.apache.spark.sql.Dataset[Array[String]] = [value: array<string>]

//access 
>>> df("array").getItem(1).cast("int")
Column<b'CAST(value[1] AS INT)'>
>>> df.select(df("array").getItem(1).cast("int"))
DataFrame[CAST(value[1] AS INT): int]
>>> df.select(df("array").getItem(1).cast("int")).show()
+---------------------+
|CAST(value[1] AS INT)|
+---------------------+
|                    1|
+---------------------+


//column is ArrayType and MapType and StructType
case class SomeClass(a:Int, b:Int)

val data = sc.parallelize(Array( ("name", Array(10,20), Map("age" -> 30), SomeClass(a =1, b =2))  ))


val df = data.toDF() //DataFrame[_1: string, _2: array<bigint>, _3: map<string,bigint>, _4: struct<a:bigint,b:bigint>]
>>> df.select(F.col("_1"), F.col("_2").getItem(0).alias("first"), F.col("_3").getItem("age"),F.col("_4").getField("a"))
//DataFrame[_1: string, first: bigint, _3[age]: bigint, _4.a: bigint]
+----+-----+-------+----+
|  _1|_2[0]|_3[age]|_4.a|
+----+-----+-------+----+
|name|   10|     30|   1|
+----+-----+-------+----+
//alternate syntax 
>>> df.select(F.col("_1"), F.col("_2")(0).alias("first"), F.col("_3")("age"),F.col("_4.a"))



    





///Example -  Basic creation and Operations on DF 


val df = spark.read.json(raw"./data/spark/people.json")
// Displays the content of the DataFrame to stdout
df.show()
// +----+-------+
// | age|   name|
// +----+-------+
// |null|Michael|
// |  30|   Andy|
// |  19| Justin|
// +----+-------+

// spark, df are from the previous example
// Print the schema in a tree format
df.printSchema()
// root
// |-- age: long (nullable = true)
// |-- name: string (nullable = true)

// Select only the "name" column
df.select("name").show()
// +-------+
// |   name|
// +-------+
// |Michael|
// |   Andy|
// | Justin|
// +-------+

// Select everybody, but increment the age by 1
df.select(df("name"), df("age") + 1).show()
// +-------+---------+
// |   name|(age + 1)|
// +-------+---------+
// |Michael|     null|
// |   Andy|       31|
// | Justin|       20|
// +-------+---------+

// Select people older than 21
df.filter(df("age") > 21).show()
// +---+----+
// |age|name|
// +---+----+
// | 30|Andy|
// +---+----+

// Count people by age
df.groupBy("age").count().show()
// +----+-----+
// | age|count|
// +----+-----+
// |  19|    1|
// |null|    1|
// |  30|    1|
// +----+-----+

// Register the DataFrame as a SQL temporary view
df.createOrReplaceTempView("people")

val sqlDF = spark.sql("SELECT * FROM people")
sqlDF.show()
// +----+-------+
// | age|   name|
// +----+-------+
// |null|Michael|
// |  30|   Andy|
// |  19| Justin|
// +----+-------+

// Register the DataFrame as a global temporary view
df.createGlobalTempView("people")

// Global temporary view is tied to a system preserved database `global_temp`
spark.sql("SELECT * FROM global_temp.people").show()
// +----+-------+
// | age|   name|
// +----+-------+
// |null|Michael|
// |  30|   Andy|
// |  19| Justin|
// +----+-------+

// Global temporary view is cross-session
spark.newSession().sql("SELECT * FROM global_temp.people").show()
// +----+-------+
// | age|   name|
// +----+-------+
// |null|Michael|
// |  30|   Andy|
// |  19| Justin|
// +----+-------+




///word count 
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.{functions => F}


val inputFile = "hdfs://localhost:19000/user/das/README"

val spark = SparkSession 
 .builder()
 .appName("wordCount") 
 .config("spark.sql.warehouse.dir", "spark-warehouse") 
 .enableHiveSupport() 
 .getOrCreate() 


val input = spark.read.text(inputfile)

input.printSchema()


val words = input.select(F.split("value"," ").alias("words"))
val counts = words.select(F.explode("words").alias("word"))
val grp = counts.groupBy("word").count()

print(grp.collect()) //Row(word,count)

counts.createOrReplaceTempView("words")
val sqlDF = spark.sql("SELECT word, count(*) FROM words group by word")
sqlDF.show()




///*** Important methods of SparkSession and Dataframe, Column and sql.functions 

class org.apache.spark.sql.SparkSession
    def  range(start: Long, end: Long, step: Long): Dataset[Long]
    def  range(start: Long, end: Long): Dataset[Long]
    def  range(end: Long): Dataset[Long]
        Create a DataFrame   containing elements in a range from start to end (exclusive) with step value step.
        >>> spark.range(1, 7, 2).collect()
        >>> spark.range(3).collect()
        Array[Long] = Array(0, 1, 2)
        //create a Dataset using spark.range starting from 5 to 100, with increments of 5
        val numDS = spark.range(5, 100, 5)
        // reverse the order and display first 5 items
        import org.apache.spark.sql.{functions => F}
        numDS.orderBy(F.desc("id")).show(5)
        //compute descriptive stats and display them
        numDS.describe().show()  
        
    def table(tableName: String): DataFrame
        Returns the specified table/view as a DataFrame.
        >>> numDS.createOrReplaceTempView("table1")
        >>> val df2 = spark.table("table1") //df2: org.apache.spark.sql.DataFrame = [id: bigint]
        scala> df2.collect()
        res54: Array[org.apache.spark.sql.Row] = Array([5], [10], [15], [20], [25], [30] , [35], [40], [45], [50], [55], [60], [65], [70], [75], [80], [85], [90], [95])
        

        
//Examples 
import spark.implicits._
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql._ 
import org.apache.spark.sql.types._ 

val df = sc.parallelize(Array((2, "Alice"), (5, "Bob"))).toDF("age", "name")
val df2 = sc.parallelize(Array(("Tom",80), ("Bob",85))).toDF("name", "height")
val df3 = sc.parallelize(Array(("Alice",2),("Bob",5))).toDF("name", "age")
                       
//only way to get None                        
case class Detail(name:Option[String], age:Option[Int], height:Option[Int])
val df4 = sc.parallelize(Array(Detail(Some("Alice"),Some(10),Some(80)) ,
                               Detail(Some("Bob"),Some(5),None) ,
                               Detail(Some("Tom"),None,None),
                               Detail(None,None,None)) ).toDF("name", "age", "height")    
                           
val sdf = sc.parallelize(Array( ("Tom",1479441846),("Bob",1479442946))).toDF("name", "time")


///Reference 
class org.apache.spark.sql.Column extends Logging
    def explain(extended: Boolean): Unit
        Prints the expression to the console for debugging purposes.        
    Between Two cols, hence use F.col("name"), and with literal use F.lit(value)
        def %(other: Any): Column
        def *(other: Any): Column
        def +(other: Any): Column
        def -(other: Any): Column
        def /(other: Any): Column  
        def <(other: Any): Column
        def <=(other: Any): Column
        def <=>(other: Any): Column
            Equality test that is safe for null values.
        def =!=(other: Any): Column
            Inequality test.
        def !==(other: Any): Column
            Inequality test. 
        def ===(other: Any): Column
            Equality test.        
        def equalTo(other: Any): Column
        def equals(that: Any): Boolean
        def >(other: Any): Column
        def >=(other: Any): Column
        def ||(other: Any): Column
            Boolean OR.        
        def &&(other: Any): Column
        def unary_!: Column
            Inversion of boolean expression, 
        def unary_-: Column
            Unary minus, i.e.
        def bitwiseAND(other: Any): Column
            Compute bitwise AND of this expression with another expression.
        def bitwiseOR(other: Any): Column
        def bitwiseXOR(other: Any): Column
        
    def contains(other: Any): Column
        Contains the other element.
    def isin(list: Any*): Column
        A boolean expression that is evaluated to true if the value of this expression is contained 
        by the evaluated values of the arguments.
        //Examples 
        >>> df.select(F.col("name").isin("Bob", "Mike")).collect()
        res99: Array[org.apache.spark.sql.Row] = Array([false], [true])
        >>> df.filter((df("age").isin(1, 2, 3)).collect()
        res113: Array[org.apache.spark.sql.Row] = Array([2,Alice])
        
    def like(literal: String): Column
        SQL like expression.
    def rlike(literal: String): Column
        SQL RLIKE expression (LIKE with Regex).
        //Examples 
        >>> df.filter($"name".rlike("ice$")).collect()
        res101: Array[org.apache.spark.sql.Row] = Array([2,Alice]) 
        >>> df.filter('name.like("Al%")).collect() //'
        res102: Array[org.apache.spark.sql.Row] = Array([2,Alice])
        
    def as[U](implicit arg0: Encoder[U]): TypedColumn[Any, U]
        Create Typed Column     
        
    def alias(alias: String): Column
        Gives the column an alias.
    def as(alias: String, metadata: Metadata): Column
    def as(alias: Symbol): Column
    def as(aliases: Seq[String]): Column
        Assigns the given aliases to the results of a table generating function.
    def as(alias: String): Column
    def name(alias: String): Column
        Gives the column a name (alias).
        //Examples 
        >>> df.select($"age".alias("age2")).collect()
        res103: Array[org.apache.spark.sql.Row] = Array([2], [5])
        
    def cast(to: String): Column
        Casts the column to a different data type, 
        using the canonical string representation of the DataType(eg IntegerType.typeName, integer)
    def cast(to: DataType): Column
    //Examples 
        >>> df.select('age.cast("string").alias("ages")).collect() //'
        res104: Array[org.apache.spark.sql.Row] = Array([2], [5])
        >>> df.select($"age".cast(StringType).alias("ages")).collect()
        res106: Array[org.apache.spark.sql.Row] = Array([2], [5])
        
    def asc: Column
    def asc_nulls_first: Column
    def asc_nulls_last: Column
    def desc: Column
    def desc_nulls_first: Column
    def desc_nulls_last: Column

    def endsWith(literal: String): Column
    def endsWith(other: Column): Column
    def startsWith(literal: String): Column
        String starts with another string literal.
    def startsWith(other: Column): Column
        //Examples 
        >>> df.filter('name.startsWith("Al")).collect() //'
        res110: Array[org.apache.spark.sql.Row] = Array([2,Alice])
        >>> df.filter('name.endsWith("ice")).collect()   //'
        res112: Array[org.apache.spark.sql.Row] = Array([2,Alice])
        
    def substr(startPos: Int, len: Int): Column
        An expression that returns a substring.
    def substr(startPos: Column, len: Column): Column
        //Examples 
        >>> df.select('name.substr(1, 3).alias("col")).collect()  //'
        [res114: Array[org.apache.spark.sql.Row] = Array([Ali], [Bob])
        
    def apply(extraction: Any): Column
        Extracts a value or values from a complex type.
    def getField(fieldName: String): Column
        An expression that gets a field by name in a StructType.
    def getItem(key: Any): Column
        An expression that gets an item at position ordinal out of an array, 
        or gets a value by key key in a MapType.
        //Example 
        case class SomeClass(a:Int, b:Int)
        val data = sc.parallelize(Array( ("name", Array(10,20), Map("age" -> 30), SomeClass(a =1, b =2))  ))
        val df = data.toDF() //DataFrame[_1: string, _2: array<bigint>, _3: map<string,bigint>, _4: struct<a:bigint,b:bigint>]
        >>> df.select(F.col("_1"), F.col("_2").getItem(0).alias("first"), F.col("_3").getItem("age"),F.col("_4").getField("a"))
        //DataFrame[_1: string, first: bigint, _3[age]: bigint, _4.a: bigint]
        +----+-----+-------+----+
        |  _1|_2[0]|_3[age]|_4.a|
        +----+-----+-------+----+
        |name|   10|     30|   1|
        +----+-----+-------+----+
        //alternate syntax 
        >>> df.select(F.col("_1"), F.col("_2")(0).alias("first"), F.col("_3")("age"),F.col("_4.a"))

        
    def isNaN: Column
        True if the current expression is NaN.
    def isNotNull: Column
    def isNull: Column
        True if the current expression is null. 
        Often combined with  DataFrame.filter to select rows with non-null values.
        //Examples 
        >>> df4.filter('height.isNotNull).collect()  //'
        res118: Array[org.apache.spark.sql.Row] = Array([Alice,10,80])
        
    def when(condition: Column, value: Any): Column
        Evaluates a list of conditions and returns one of multiple possible result expressions.       
    def otherwise(value: Any): Column
        Evaluates a list of conditions and returns one of multiple possible result expressions.
        //Examples 
        >>> df.select(F.col("name"), F.when('age > 4, 1).when('age < 3, -1).otherwise(0)).show() //'
        +-----+------------------------------------------------------------+
        | name|CASE WHEN (age > 4) THEN 1 WHEN (age < 3) THEN -1 ELSE 0 END|
        +-----+------------------------------------------------------------+
        |Alice|                                                          -1|
        |  Bob|                                                           1|

        
       


class org.apache.spark.sql.Dataset[T] extends Serializable
	type DataFrame = Dataset[Row] 
    Note toDF(..)/toDF()/toDS() only works with RDD[T], Seq[T} when T is not a Row ie T is caseclass/tuple/Array/Map/Nested these 
    If you have RDD[Row], use spark.createDataFrame() with schema     

    //Methods 
    def localCheckpoint(eager: Boolean): Dataset[T]
        Locally checkpoints a Dataset and return the new Dataset.
    def checkpoint(eager: Boolean): Dataset[T]
        Returns a checkpointed version of this Dataset.
    def localCheckpoint(): Dataset[T]
    def checkpoint(): Dataset[T]
        Eagerly checkpoint a Dataset and return the new Dataset.
        
    def unpersist(): Dataset.this.type
    def unpersist(blocking: Boolean): Dataset.this.type
    def storageLevel: StorageLevel
    def persist(newLevel: StorageLevel): Dataset.this.type
    def persist(): Dataset.this.type
    def cache(): Dataset.this.type
        Persist this Dataset with the default storage level (MEMORY_AND_DISK).
        //Examples 
        >>> df.cache()
        
    def toJSON: Dataset[String]
        Returns the content of the Dataset as a Dataset of JSON strings.
        //Examples 
        >>> df.toJSON.show(truncate=false)
            ------------------------+
            value                   |
            ------------------------+
            {"age":2,"name":"Alice"}|
            {"age":5,"name":"Bob"}  |
            ------------------------+
            
    def columns: Array[String]
        //Exmples 
        >>> df.columns
            es172: Array[String] = Array(age, name)
    def printSchema(): Unit
    lazy val rdd: RDD[T]
    def schema: StructType
        Note schema("fieldName") gives fieldName 
        //Examples 
        >>> df.schema
        res7: org.apache.spark.sql.types.StructType = StructType(StructField(age,IntegerType,false), StructField(name,StringType,true))
    def dtypes: Array[(String, String)]
        //Examples 
        >>> df.dtypes
        res5: Array[(String, String)] = Array((age,IntegerType), (name,StringType))        

    def explain(): Unit
    def explain(extended: Boolean): Unit
        Prints the plans (logical and physical) to the console for debugging purposes.
    def hint(name: String, parameters: Any*): Dataset[T]
        Specifies some hint on the current Dataset.
        
    def inputFiles: Array[String]
        Returns a best-effort snapshot of the files that compose this Dataset.
    def isLocal: Boolean
        Returns true if the collect and take methods can be run locally (without any Spark executors).        
        
    def collect(): Array[T]
        Returns an array that contains all rows in this Dataset.
        //Examples 
        >>> df.collect()
        Array[org.apache.spark.sql.Row] = Array([2,Alice], [5,Bob])
    def collectAsList(): List[T]
        Returns a Java list that contains all rows in this Dataset.
        
    def count(): Long
        Returns the number of rows in the Dataset.
        //Examples 
        >>> df.count()
        
    def describe(cols: String*): DataFrame
        Computes basic statistics for numeric and string columns, 
        including count, mean, stddev, min, and max.
        //Examples 
        >>> df.describe("age", "name").show()
        >>> df.describe().show() //DF 
        
    def summary(statistics: String*): DataFrame
        Computes specified statistics for numeric and string columns. Available statistics are:
        - count - mean - stddev - min - max - arbitrary approximate percentiles specified as a percentage (eg, 75%)
        If no statistics are given, this function computes count, mean, stddev, min, approximate quartiles (percentiles at 25%, 50%, and 75%), and max
        //Examples 
        df.summary().show()
        df.summary("count", "min", "25%", "75%", "max").show()
        df4.select("age", "height").summary().show()
        
    def first(): T
        Returns the first row.
        //Examples 
        >>> df.first()
        es14: org.apache.spark.sql.Row = [2,Alice]
    def limit(n: Int): Dataset[T]
        Returns a new Dataset by taking the first n rows.   
    def head(): T
    def head(n: Int): Array[T]
        Returns the first n rows.
    def take(n: Int): Array[T]
    def takeAsList(n: Int): List[T]
    def toLocalIterator(): Iterator[T]

    def coalesce(numPartitions: Int): Dataset[T]
        when the fewer partitions are requested.
    def repartition(partitionExprs: Column*): Dataset[T]
        using spark.sql.shuffle.partitions as number of partitions.
    def repartition(numPartitions: Int, partitionExprs: Column*): Dataset[T]
    def repartition(numPartitions: Int): Dataset[T]
    def repartitionByRange(partitionExprs: Column*): Dataset[T]
    def repartitionByRange(numPartitions: Int, partitionExprs: Column*): Dataset[T]
        //Examples 
        >>> df.rdd.getNumPartitions
            res20: Int = 4
        >>> val dfp = df.repartition(2,F.col("age"))
        dfp: org.apache.spark.sql.Dataset[org.apache.spark.sql.Row] = [age: int, name: string]
        >>> dfp.rdd.getNumPartitions
        res22: Int = 2
        >>> spark.conf.get("spark.sql.shuffle.partitions")
        res23: String = 200
        >>> spark.conf.set("spark.sql.shuffle.partitions", 2)
        >>> spark.conf.get("spark.sql.shuffle.partitions")
        res25: String = 2
        >>> dfp.groupBy("name").agg(F.mean("age")).show()
        +-----+--------+
        | name|avg(age)|
        +-----+--------+
        |Alice|     2.0|
        |  Bob|     5.0|
        +-----+--------+

        >>> dfp.groupBy("name").agg(F.mean("age")).explain()
        == Physical Plan ==
        *(2) HashAggregate(keys=[name#95], functions=[avg(cast(age#94 as bigint))])
        +- Exchange hashpartitioning(name#95, 2)
           +- *(1) HashAggregate(keys=[name#95], functions=[partial_avg(cast(age#94 as bigint))])
              +- Exchange hashpartitioning(age#94, 2)
                 +- InMemoryTableScan [age#94, name#95]
                       +- InMemoryRelation [age#94, name#95], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
                             +- *(1) Project [_1#91 AS age#94, _2#92 AS name#95]
                                +- *(1) SerializeFromObject [assertnotnull(input[0, scala.Tuple2, true])._1 AS _1#91, staticinvoke(class org.apache.spark.unsafe.types.UTF8String, StringType, fromString, assertnotnull(input[0, scala.Tuple2, true])._2, true, false) AS _2#92]
                                   +- Scan ExternalRDDScan[obj#90]

        >>> dfp.groupBy("name").agg(F.mean("age")).rdd.toDebugString
        res33: String =
        (2) MapPartitionsRDD[111] at rdd at <console>:33 []
         |  MapPartitionsRDD[110] at rdd at <console>:33 []
         |  MapPartitionsRDD[109] at rdd at <console>:33 []
         |  ShuffledRowRDD[108] at rdd at <console>:33 []
         +-(2) MapPartitionsRDD[107] at rdd at <console>:33 []
            |  MapPartitionsRDD[106] at rdd at <console>:33 []
            |  ShuffledRowRDD[105] at rdd at <console>:33 []
            +-(4) MapPartitionsRDD[104] at rdd at <console>:33 []
               |  MapPartitionsRDD[103] at rdd at <console>:33 []
               |  MapPartitionsRDD[102] at rdd at <console>:33 []
               |  *(1) Project [_1#91 AS age#94, _2#92 AS name#95]
        +- *(1) SerializeFromObject [assertnotnull(input[0, scala.Tuple2, true])._1 AS _1#91, staticinvoke(class org.apache.spark.unsafe.types.UTF8String, StringType, fromStri...

        >>> spark.conf.set("spark.sql.shuffle.partitions", 200)
        >>> dfp.groupBy("name").agg(F.mean("age")).rdd.toDebugString
        res35: String =
        (200) MapPartitionsRDD[122] at rdd at <console>:33 []
          |   MapPartitionsRDD[121] at rdd at <console>:33 []
          |   MapPartitionsRDD[120] at rdd at <console>:33 []
          |   ShuffledRowRDD[119] at rdd at <console>:33 []
          +-(2) MapPartitionsRDD[118] at rdd at <console>:33 []
             |  MapPartitionsRDD[117] at rdd at <console>:33 []
             |  ShuffledRowRDD[116] at rdd at <console>:33 []
             +-(4) MapPartitionsRDD[115] at rdd at <console>:33 []
                |  MapPartitionsRDD[114] at rdd at <console>:33 []
                |  MapPartitionsRDD[113] at rdd at <console>:33 []
                |  *(1) Project [_1#91 AS age#94, _2#92 AS name#95]
        +- *(1) SerializeFromObject [assertnotnull(input[0, scala.Tuple2, true])._1 AS _1#91, staticinvoke(class org.apache.spark.unsafe.types.UTF8String, Strin...


    def apply(colName: String): Column
    def col(colName: String): Column
    def colRegex(colName: String): Column
        Selects column based on the column name specified as a regex and returns it as Column.  
        //Examples 
        >>> val dfc = sc.parallelize(Array(("a", 1), ("b", 2), ("c",  3))).toDF("Col1", "Col2")
        >>> dfc.select(dfc.colRegex(raw"Col1")).show() //does not work 
        
        
    def  select[U1, U2, U3, U4, U5](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2], c3: TypedColumn[T, U3], c4: TypedColumn[T, U4], c5: TypedColumn[T, U5]): Dataset[(U1, U2, U3, U4, U5)]
    def  select[U1, U2, U3, U4](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2], c3: TypedColumn[T, U3], c4: TypedColumn[T, U4]): Dataset[(U1, U2, U3, U4)]
    def  select[U1, U2, U3](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2], c3: TypedColumn[T, U3]): Dataset[(U1, U2, U3)]
    def  select[U1, U2](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2]): Dataset[(U1, U2)]
    def  select[U1](c1: TypedColumn[T, U1]): Dataset[U1]
        Typed select 
    def select(col: String, cols: String*): DataFrame
    def select(cols: Column*): DataFrame
        Selects a set of column based expressions.
        //Examples 
        >>> df.select("*").collect()
        [Row(age =2,name =u"Alice"), Row(age =5,name =u"Bob")]
        >>> df.select("name", "age").collect()
        [Row(name =u"Alice",age =2), Row(name =u"Bob",age =5)]
        >>> df.select(df.name, (df.age + 10).alias("age")).collect()
        [Row(name =u"Alice",age =12), Row(name =u"Bob",age =15)]
        
    def selectExpr(exprs: String*): DataFrame
        Selects a set of SQL expressions.
        This is a variant of select() that accepts SQL expressions.
        (numeric can have +,-,*,/ , string can have || for concatenation)
        (comparison val operators =, !=, > < >= <= )
        (has many functions , check  https://docs.oracle.com/cd/B28359_01/server.111/b28286/functions001.htm//SQLRF51174 )
        //Examples 
        >>> df.selectExpr("age * 2", "abs(age)").collect()
        [Row((age * 2)=4, abs(age)=2), Row((age * 2)=10, abs(age)=5)]
        
    def foreach(f: (T) => Unit): Unit
        Applies a function f to all rows.
        //Examples 
        >>> df.foreach(r => println(r.getInt(0)))
    def foreachPartition(f: (Iterator[T]) => Unit): Unit
        Applies a function f to each partition of this Dataset.
        //Examples 
        >>> df.foreachPartition(it => println(it.toList)) //four partitions 
            List()
            List()
            List([5,Bob])
            List([2,Alice])
    def reduce(func: (T, T) => T): T
        //Examples 
        >>> df.reduce{(r,e) => Row(r.getInt(0)+e.getInt(0), "total")}
            res44: org.apache.spark.sql.Row = [7,total]
            
    def transform[U](t: (Dataset[T]) => Dataset[U]): Dataset[U]
        Concise syntax for chaining custom transformations.
        By default, Encoders are present for case class, Tuples, primitives , not Row 
        //Examples 
        >>> df.transform( ds => ds.map{r => (r.getInt(0)+10, r.getString(1))})
        
    def flatMap[U](func: (T) => TraversableOnce[U])(implicit arg0: Encoder[U]): Dataset[U]       
    def map[U](func: (T) => U)(implicit arg0: Encoder[U]): Dataset[U]
    def mapPartitions[U](func: (Iterator[T]) => Iterator[U])(implicit arg0: Encoder[U]): Dataset[U]
        For DataFrame, T is Row and for Dataset, T is Caseclass/Tuple/Array/Map/Nested etc 
        By default, Encoders are present for case class, Tuples, primitives , not Row 
        //Examples 
        >>> df.map{r => r.getInt(0)}
            res41: org.apache.spark.sql.Dataset[Int] = [value: int]
        >>> df.map{case Row(a:Int,n:String) => (n -> a)}  //Row type is must as by default it is Any 
            res42: org.apache.spark.sql.Dataset[(String, Int)] = [_1: string, _2: int]
        
    def  filter(func: (T) => Boolean): Dataset[T]
        Returns a new Dataset that only contains elements where func returns true.
        //Examples 
        >>> df.filter{r => r.getInt(0) > 10 } 
    def filter(conditionExpr: String): Dataset[T]
    def where(conditionExpr: String): Dataset[T]
        Filters rows using the given SQL expression.
        Note &, | and ~ is used for combining boolean conditions 
    def filter(condition: Column): Dataset[T]
    def where(condition: Column): Dataset[T]
        Filters rows using the given condition. 
        //Examples         
        >>> df.filter(df.age > 3).collect()
        [Row(age =5,name =u"Bob")]
        >>> df.where(df("age") === F.lit(2)).collect() //Column == is ===
        [Row(age =2,name =u"Alice")]
        >>> df.filter("age > 3").collect()
        [Row(age =5,name =u"Bob")]
        >>> df.where("age = 2").collect()
        [Row(age =2,name =u"Alice")]
        >>> df.where("age == 2").collect()
        
    def show(numRows: Int, truncate: Int, vertical: Boolean): Unit
    def show(numRows: Int, truncate: Int): Unit
    def show(numRows: Int, truncate: Boolean): Unit
    def show(truncate: Boolean): Unit
    def show(): Unit
    def show(numRows: Int): Unit
        Displays the Dataset in a tabular form.         
       
    def createGlobalTempView(viewName: String): Unit
    def createOrReplaceGlobalTempView(viewName: String): Unit
    def createOrReplaceTempView(viewName: String): Unit
    def createTempView(viewName: String): Unit
    createGlobalTempView(name)
        Creates a global temporary view with this DataFrame.
        Local Temporary views in Spark SQL are session-scoped 
        and will disappear if the session that creates it terminates. 
        To share among all sessions and keep alive 
        until the Spark application terminates, create a global temporary view. 
        Global temporary view is tied to a system preserved database global_temp, 
        and use the qualified name to refer it, e.g. SELECT * FROM global_temp.view    
        //Examples 
        >>> df.createGlobalTempView("people")
        >>> val df2 = spark.sql("select * from global_temp.people")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
        >>> df.createGlobalTempView("people")  
        Traceback (most recent call last):
        ...
        AnalysisException: u"Temporary table "people" already exists;"
         >>> spark.catalog.listTables()
        []
        >>> spark.catalog.listDatabases()
        [Database(name ="default",description ="Default Hive database",locationUri ="file:/D:/Desktop/PPT/spark-warehouse")]
        >>> spark.catalog.dropGlobalTempView("people")
        >>> df.createGlobalTempView("people")
    createOrReplaceTempView(name)
        Creates or replaces a local temporary view with this DataFrame.
        //Examples 
        >>> df.createOrReplaceTempView("people")
        >>> val df2 = df.filter(df.age > 3)
        >>> df2.createOrReplaceTempView("people")
        >>> val df3 = spark.sql("select * from people")
        >>> sorted(df3.collect()) == sorted(df2.collect())
        True
        >>> spark.catalog.dropTempView("people")
    createTempView(name)
        Creates a local temporary view with this DataFrame.
        //Examples 
        >>> df.createTempView("people")
        >>> val df2 = spark.sql("select * from people")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
        >>> df.createTempView("people")  
        Traceback (most recent call last):
        ...
        AnalysisException: u"Temporary table "people" already exists;"
        >>> spark.catalog.dropTempView("people")
    registerTempTable(name)
        deprecated 
        Registers this RDD as a temporary table(hive) using the given name.
        //Examples 
        >>> df.registerTempTable("people")
        >>> val df2 = spark.sql("select * from people")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
        >>> spark.catalog.dropTempView("people")   //to delete temp table 
        //diif between temp and permanent table 
        >>> spark.catalog.listTables()
        []
        >>> df.write.saveAsTable("people")
        >>> spark.catalog.listTables()
        [Table(name ="people",database ="default",description =None,tableType ="MANAGED",isTemporary =False)]
        >>> val df = spark.table("people")
        >>> df.show()
        +---+-----+
        |age| name|
        +---+-----+
        |  2|Alice|
        |  5|  Bob|
        +---+-----+
        >>> df.registerTempTable("people")
        >>> spark.catalog.listTables()
        [Table(name ="people",database ="default",description =None,tableType ="MANAGED",isTemporary =False), 
         Table(name ="people",database =None,description =None,tableType ="TEMPORARY",isTemporary =True)]
        >>> df.registerTempTable("db.people")
        org.apache.spark.sql.utils.AnalysisException: "It is not allowed to add database prefix `db` for the TEMPORARY view name.;"

        >>> spark.sql("create database db")
        18/07/29 09:48:31 WARN ObjectStore: Failed to get database db, returning NoSuchObjectException
        >>> spark.sql("CREATE DATABASE IF NOT EXISTS new_db ")
        18/07/29 09:49:26 WARN ObjectStore: Failed to get database new_db, returning NoSuchObjectException

        >>> spark.catalog.listDatabases()
        [Database(name ="db",description ="",locationUri ="file:/D:/Desktop/PPT/spark-warehouse/db.db"), 
        Database(name ="default",description ="Default Hive database",locationUri ="file:/D:/Desktop/PPT/spark-warehouse"), 
        Database(name ="new_db",description ="",locationUri ="file:/D:/Desktop/PPT/spark-warehouse/new_db.db")]
 
        >>> df.write.saveAsTable("db.people")
        >>> spark.catalog.listTables()
        [Table(name ="people",database ="default",description =None,tableType ="MANAGED",isTemporary =False), 
        Table(name ="people",database =None,description =None,tableType ="TEMPORARY",isTemporary =True)]
        >>> spark.catalog.listTables("db")
        [Table(name ="people",database ="db",description =None,tableType ="MANAGED",isTemporary =False), 
        Table(name ="people",database =None,description =None,tableType ="TEMPORARY",isTemporary =True)]
        >>> spark.catalog.dropTempView("people")
        >>> spark.catalog.listTables()
        [Table(name ="people",database ="default",description =None,tableType ="MANAGED",isTemporary =False)]
        
        >>> spark.catalog.listTables("db")
        [Table(name ="people",database ="db",description =None,tableType ="MANAGED",isTemporary =False)]
        >>> sql("DROP table IF EXISTS db.people ")
        DataFrame[]
        >>> spark.catalog.listTables("db")
        []        
    
    //Basic Dataset functions
    def  as[U](implicit arg0: Encoder[U]): Dataset[U]
        Returns a new Dataset where each record has been mapped on to the specified type.
        //Examples 
        //Note case class has default encoders 
        case class Person(age:Int, name:String) //attr must be same as df column names 
        val people = df.as[Person]
        >>> val names = people.map(_.name)
            names: org.apache.spark.sql.Dataset[String] = [value: string]
        >>> val names = people.map(_.name).select(F.col("value").as("name"))
            names: org.apache.spark.sql.DataFrame = [name: string]

    def joinWith[U](other: Dataset[U], condition: Column): Dataset[(T, U)]
        Using inner equi-join twhere condition evaluates to true.        
    def joinWith[U](other: Dataset[U], condition: Column, joinType: String): Dataset[(T, U)]
        Only for Dataset, not from DataFrame ie for Row 
        Where U must have Encoders eg for caseclass/tuple/Array/Map/nested etc 
        Joins this Dataset returning a Tuple2 for each pair where condition evaluates to true.
        other
            Right side of the join.
        condition
            Join expression. eg $"LHS_ColumnName" === $"RHS_ColumnName"
        joinType
            Type of join to perform. Default inner. 
            Must be one of: inner, cross, outer, full, full_outer, left, left_outer, right, right_outer, left_semi, left_anti.
    def crossJoin(right: Dataset[_]): DataFrame
        Explicit cartesian join with another DataFrame.
        //Examples 
        >>> df.crossJoin(df).show()
            +---+-----+---+-----+
            |age| name|age| name|
            +---+-----+---+-----+
            |  2|Alice|  2|Alice|
            |  2|Alice|  5|  Bob|
            |  5|  Bob|  2|Alice|
            |  5|  Bob|  5|  Bob|
            +---+-----+---+-----+
            
    def join(right: Dataset[_], joinExprs: Column): DataFrame
        Inner join with another DataFrame, using the given join expression.
    def join(right: Dataset[_], usingColumns: Seq[String]): DataFrame
        Inner equi-join with another DataFrame using the given columns.
        usingColumns when column name is same in both DF 
    def join(right: Dataset[_], usingColumn: String): DataFrame
        Inner equi-join with another DataFrame using the given column.
    def join(right: Dataset[_]): DataFrame
        Join with another DataFrame.     
    def join(right: Dataset[_], usingColumns: Seq[String], joinType: String): DataFrame
    def join(right: Dataset[_], joinExprs: Column, joinType: String): DataFrame
        Join with another DataFrame, using the given join expression.
        right
            Right side of the join.
        joinExprs
            Join expression.
        joinType
            Type of join to perform. Default inner. 
            Must be one of: inner, cross, outer, full, full_outer, left, left_outer, right, right_outer, left_semi, left_anti.    
        //Examples 
        >>> df.join(df.withColumnRenamed("age","age2"),$"age" === $"age2" , "outer").show()//$"df1Key" === $"df2Key"
            +---+-----+----+-----+
            |age| name|age2| name|
            +---+-----+----+-----+
            |  5|  Bob|   5|  Bob|
            |  2|Alice|   2|Alice|
            +---+-----+----+-----+  
        //inner 
        df.join(df.withColumnRenamed("age","age2")).where($"age" === $"age2")
        >>> df.join(df,"age").show()
        ---+-----+-----+
        age| name| name|
        ---+-----+-----+
          2|Alice|Alice|
          5|  Bob|  Bob|
        ---+-----+-----+

        
    def alias(alias: Symbol): Dataset[T]
    def alias(alias: String): Dataset[T]
    def as(alias: Symbol): Dataset[T]
    def as(alias: String): Dataset[T]
        Returns a new Dataset with an alias set.
        >>> val df_as1 = df.alias("df_as1")
        >>> val df_as2 = df.alias("df_as2")
        >>> val joined_df = df_as1.join(df_as2, F.col("df_as1.name") === F.col("df_as2.name"), "inner")
        >>> joined_df.select("df_as1.name", "df_as2.name", "df_as2.age").collect()
            res47: Array[org.apache.spark.sql.Row] = Array([Alice,Alice,2], [Bob,Bob,5])
        
    def distinct(): Dataset[T]
        Returns a new Dataset that contains only the unique rows from this Dataset.
        >>> df.distinct.show()
        
    def dropDuplicates(col1: String, cols: String*): Dataset[T]
        Returns a new Dataset with duplicate rows removed, considering only the subset of columns.
    def dropDuplicates(colNames: Array[String]): Dataset[T]
    def dropDuplicates(colNames: Seq[String]): Dataset[T]
    def dropDuplicates(): Dataset[T]
        Returns a new Dataset that contains only the unique rows from this Dataset.
        >>> val dfd = sc.parallelize(Array(
                ("Alice",5,80),
                ("Alice",5,80), 
                ("Alice",10,80))).toDF("name", "age", "height")
        >>> dfd.dropDuplicates().show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        |  5|    80|Alice|
        | 10|    80|Alice|
        +---+------+-----+
        >>> dfd.dropDuplicates("name", "height").show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        |  5|    80|Alice|
        +---+------+-----+
        
    def na: DataFrameNaFunctions
        Returns a DataFrameNaFunctions for working with missing data.
            def drop(minNonNulls: Int, cols: Seq[String]): DataFrame
                Returns a new DataFrame that drops rows containing less than minNonNulls non-null 
                and non-NaN values in the specified columns.
            def drop(minNonNulls: Int, cols: Array[String]): DataFrame
            def drop(minNonNulls: Int): DataFrame
            def drop(how: String, cols: Seq[String]): DataFrame
            def drop(how: String, cols: Array[String]): DataFrame
            def drop(cols: Seq[String]): DataFrame
            def drop(cols: Array[String]): DataFrame
            def drop(how: String): DataFrame
                Returns a new DataFrame that drops rows containing null or NaN values.
                    �how � "any" or "all". 
                     If "any", drop a row if it contains any nulls. 
                     If "all", drop a row only if all its values are null.
             def drop(): DataFrame
                Returns a new DataFrame that drops rows containing any null or NaN values.
                
            def fill(valueMap: Map[String, Any]): DataFrame
            def fill(valueMap: Map[String, Any]): DataFrame
            def fill(value: Boolean, cols: Array[String]): DataFrame
            def fill(value: Boolean, cols: Seq[String]): DataFrame
                Returns a new DataFrame that replaces null values in specified boolean columns.
            def fill(value: Boolean): DataFrame
            def fill(value: String, cols: Seq[String]): DataFrame
                Returns a new DataFrame that replaces null values in specified string columns.
            def fill(value: String, cols: Array[String]): DataFrame
            def fill(value: Double, cols: Seq[String]): DataFrame
                Returns a new DataFrame that replaces null or NaN values in specified numeric columns.
            def fill(value: Long, cols: Seq[String]): DataFrame
            def fill(value: Double, cols: Array[String]): DataFrame
            def fill(value: Long, cols: Array[String]): DataFrame
            def fill(value: String): DataFrame
                Returns a new DataFrame that replaces null values in string columns with value.
            def fill(value: Double): DataFrame
                Returns a new DataFrame that replaces null or NaN values in numeric columns with value.
            def fill(value: Long): DataFrame

            def replace[T](cols: Seq[String], replacement: Map[T, T]): DataFrame
                Replaces values matching keys in replacement map.
            def replace[T](col: String, replacement: Map[T, T]): DataFrame
            def replace[T](cols: Array[String], replacement: Map[T, T]): DataFrame
            def replace[T](col: String, replacement: Map[T, T]): DataFrame
        //Examples 
        df4.na.drop().show()     //drop any row containing any null 
        df4.na.drop().dropDuplicates().show()
        df4.na.fill(50).show()
        df4.na.fill(Map("age"-> 50, "name" -> "unknown", "height" -> 60)).show()

    def stat: DataFrameStatFunctions
        Returns a DataFrameStatFunctions for working statistic functions support.          
            def approxQuantile(cols: Array[String], probabilities: Array[Double], relativeError: Double): Array[Array[Double]]
            def approxQuantile(col: String, probabilities: Array[Double], relativeError: Double): Array[Double]
            def corr(col1: String, col2: String): Double
            def corr(col1: String, col2: String, method: String): Double
            def cov(col1: String, col2: String): Double
            def crosstab(col1: String, col2: String): DataFrame
                Computes a pair-wise frequency table of the given columns.
            def freqItems(cols: Seq[String]): DataFrame
            def freqItems(cols: Seq[String], support: Double): DataFrame
            def freqItems(cols: Array[String]): DataFrame
            def freqItems(cols: Array[String], support: Double): DataFrame
                Finding frequent items for columns, possibly with false positives.
            def sampleBy[T](col: String, fractions: Map[T, Double], seed: Long): DataFrame
                Returns a stratified sample without replacement based on the fraction given on each stratum.

    def drop(col: Column): DataFrame
    def drop(colNames: String*): DataFrame
    def drop(colName: String): DataFrame
        Returns a new Dataset with a column dropped.   
        >>> df.drop("age")
        
    def withColumn(colName: String, col: Column): DataFrame
        Returns a new Dataset by adding a column or replacing the existing column that has the same name.
    def withColumnRenamed(existingName: String, newName: String): DataFrame
        Returns a new Dataset with a column renamed.
        >>> df.withColumn("age2", df("age") + 2).collect()
        [Row(age =2,name =u"Alice",age2 =4), Row(age =5,name =u"Bob",age2 =7)]
        >>> df.withColumnRenamed("age", "age2").collect()
        [Row(age2 =2,name =u"Alice"), Row(age2 =5,name =u"Bob")]
        
    def except(other: Dataset[T]): Dataset[T]
        Returns a new Dataset containing rows in this Dataset but not in another Dataset.
        >>> df.except(df)
            +---+----+
            |age|name|
            +---+----+
            +---+----+
    def intersect(other: Dataset[T]): Dataset[T]
        Returns a new Dataset containing rows only in both this Dataset and another Dataset.
        >>> df.intersect(df)
            +---+-----+
            |age| name|
            +---+-----+
            |  2|Alice|
            |  5|  Bob|
            +---+-----+
    def union(other: Dataset[T]): Dataset[T]
    def unionAll(other: Dataset[T]): Dataset[T]
        Returns a new Dataset containing union of rows in this Dataset and another Dataset.
        Must have  same number of columns etc 
        >>> df.union(df)
            +---+-----+
            |age| name|
            +---+-----+
            |  2|Alice|
            |  5|  Bob|
            |  2|Alice|
            |  5|  Bob|
            +---+-----+        
            
    def randomSplit(weights: Array[Double]): Array[Dataset[T]]
        //Examples 
        >>> val Array(d1,d2) = df.randomSplit(Array(0.3,0.7))
        >>> d1.collect()
        res120: Array[org.apache.spark.sql.Row] = Array()
        >>> d2.collect()
        res121: Array[org.apache.spark.sql.Row] = Array([2,Alice], [5,Bob])
    def randomSplit(weights: Array[Double], seed: Long): Array[Dataset[T]]
    def randomSplitAsList(weights: Array[Double], seed: Long): List[Dataset[T]]
    def sample(withReplacement: Boolean, fraction: Double): Dataset[T]
    def sample(withReplacement: Boolean, fraction: Double, seed: Long): Dataset[T]
    def sample(fraction: Double): Dataset[T]
    def sample(fraction: Double, seed: Long): Dataset[T]    
     
    def orderBy(sortExprs: Column*): Dataset[T]
    def orderBy(sortCol: String, sortCols: String*): Dataset[T]    
        //Examples 
        df.orderBy('age.desc).collect()  //' donot use desc with ()
        df.orderBy(F.desc("age"), F.asc("name")).collect()
        df.orderBy("age", "name").collect()

    def sort(sortExprs: Column*): Dataset[T]
    def sort(sortCol: String, sortCols: String*): Dataset[T]
        Returns a new Dataset sorted by the specified column, all in ascending order.
        //Examples 
        df.sort('age.desc).collect() //'
        df.sort("age").collect()
        df.sort(F.asc("age")).collect()
        
    def sortWithinPartitions(sortExprs: Column*): Dataset[T]
    def sortWithinPartitions(sortCol: String, sortCols: String*): Dataset[T]
        Returns a new Dataset with each partition sorted by the given expressions.
        //Examples 
        >>> df.sortWithinPartitions("age").show()
        +---+-----+
        |age| name|
        +---+-----+
        |  2|Alice|
        |  5|  Bob|
        +---+-----+   
        
    ///Untyped transformations
    def agg(expr: Column, exprs: Column*): DataFrame
    def agg(exprs: Map[String, String]): DataFrame
    def agg(aggExpr: (String, String), aggExprs: (String, String)*): DataFrame
        Aggregates on the entire Dataset without groups.
        //Examples 
        >>> df.agg(Map("age"-> "max")).collect()
            es154: Array[org.apache.spark.sql.Row] = Array([5])
        >>> df.agg(F.min("age")).collect()
        >>> df.agg(F.min("age"), F.min("age")).collect()
            es155: Array[org.apache.spark.sql.Row] = Array([2,2])
            
    def cube(col1: String, cols: String*): RelationalGroupedDataset
    def cube(cols: Column*): RelationalGroupedDataset
    def rollup(col1: String, cols: String*): RelationalGroupedDataset
    def rollup(cols: Column*): RelationalGroupedDataset
    def groupBy(col1: String, cols: String*): RelationalGroupedDataset
    def groupBy(cols: Column*): RelationalGroupedDataset
        Note above does not return DataFrame, use one of below methods, then use all DF methods eg select 
        Note, result Dataframe would contain groupBy columns and only aggregation columns/count/avg etc column. 
        No other columns would be present 
            def agg(expr: Column, exprs: Column*): DataFrame
            def agg(exprs: Map[String, String]): DataFrame
                Compute aggregates by specifying a map from column name to aggregate methods.
            def agg(aggExpr: (String, String), aggExprs: (String, String)*): DataFrame
            def avg(colNames: String*): DataFrame
            def count(): DataFrame
            def max(colNames: String*): DataFrame
            def mean(colNames: String*): DataFrame
            def min(colNames: String*): DataFrame
            def sum(colNames: String*): DataFrame
                //Examples 
                >>> df.groupby("name", "age").count().orderBy("name", "age").show()
                    +-----+---+-----+
                    | name|age|count|
                    +-----+---+-----+
                    |Alice|  2|    1|
                    |  Bob|  5|    1|
                    +-----+---+-----+
                >>> df.groupBy().avg().collect()
                    es159: Array[org.apache.spark.sql.Row] = Array([3.5])
                >>> df.groupBy("name").agg(Map("age"-> "mean")).collect()
                    es160: Array[org.apache.spark.sql.Row] = Array([Bob,5.0], [Alice,2.0])
            
            def pivot(pivotColumn: String, values: Seq[Any]): RelationalGroupedDataset
                Pivots a column of the current DataFrame and performs the specified aggregation.
            def pivot(pivotColumn: String): RelationalGroupedDataset
                more concise but less efficient
                With grouping column 'col' and For each distinct value of 'values' of 'pivotColumn', do the aggregation .agg(..)                
                Note return of this method is RelationalGroupedDataset
                //Example 
                case class CourseSales(course: String, year: Int, earnings: Double)
                val courseSales = spark.sparkContext.parallelize(
                      CourseSales("dotNET", 2012, 10000) ::
                        CourseSales("Java", 2012, 20000) ::
                        CourseSales("dotNET", 2012, 5000) ::
                        CourseSales("dotNET", 2013, 48000) ::
                        CourseSales("Java", 2013, 30000) :: Nil).toDF()
                courseSales.groupBy("year").pivot("course", Seq("dotNET", "Java")).agg(F.sum($"earnings"))
                    +----+-------+-------+
                    |year| dotNET|   Java|
                    +----+-------+-------+
                    |2013|48000.0|30000.0|
                    |2012|15000.0|20000.0|
                    +----+-------+-------+
                courseSales.groupBy("course").pivot("year", Seq(2012, 2013)).agg(F.sum($"earnings"))
                courseSales.groupBy($"year").pivot("course", Seq("dotNET", "Java")).agg(F.sum($"earnings"), F.avg($"earnings"))
                // Or without specifying column values (less efficient)
                courseSales.groupBy("year").pivot("course").sum("earnings")
                //Another example 
                val data = sc.parallelize(Array(
                        ("memories","book","q1",10),
                        ("dreams","book","q2",20),
                        ("reflections","book","q3",30),
                        ("how to build a house","book","q4",40),
                        ("wonderful life","music","q1",10),
                        ("million miles","music","q2",20),
                        ("run away","music","q3",30),
                        ("mind and body","music","q4",40))).toDF("product","category","quarter","profit")
                    // group column : category
                    // agg column : profit
                    // pivot column : quarter
                    // agg function : sum
                    //                       pivot column 
                    // group column      agg_function(agg_column)
                    data.groupBy("category").pivot("quarter").sum("profit").show()
                            --------+---+---+---+---+
                            category| q1| q2| q3| q4|
                            --------+---+---+---+---+
                               music| 10| 20| 30| 40|
                                book| 10| 20| 30| 40|
                            --------+---+---+---+---+
                    
    def  groupByKey[K](func: (T) => K)(implicit arg0: Encoder[K]): KeyValueGroupedDataset[K, T]
        Returns a KeyValueGroupedDataset where the data is grouped by the given key func.
        This is Typed operation 
        K must be case class, Tuples, primitives , not Row 
        //Examples 
        >>> val grp = df.groupByKey( r => r.getInt(0) % 2)
            res142: org.apache.spark.sql.KeyValueGroupedDataset[Int,org.apache.spark.sql.Row] = KeyValueGroupedDataset: [key: [value: int], value: [age: int, name: string]]
        >>> grp.count().show()
            +-----+--------+
            |value|count(1)|
            +-----+--------+
            |    1|       1|
            |    0|       1|
            +-----+--------+
        >>> grp.agg(F.sum("age").as[Int], F.first("name").as[String]).show()
            +-----+--------+------------------+
            |value|sum(age)|first(name, false)|
            +-----+--------+------------------+
            |    1|       5|               Bob|
            |    0|       2|             Alice|
            +-----+--------+------------------+
        >>> grp.agg(F.sum("age").as[Int], F.first("name").as[String])
            res150: org.apache.spark.sql.Dataset[(Int, Int, String)] = [value: int, sum(age) : bigint ... 1 more field]
        >>> grp.keys.collect()
            es152: Array[Int] = Array(1, 0)
        //KeyValueGroupedDataset: [key: [value: int], value: [age: int, name: string]]
        >>> grp.mapValues(row => row.getString(1))        
        //reference 
            TypedColumn[-T, U] extends Column
                To create a TypedColumn, use the 'as[U]' function on a Column., U must have encoders 
                Default from Encoders are primitivs, case class, tuples , etc 
                Also can be  F.expr("sum(...)"))    
            KeyValueGroupedDataset[K, V] extends Serializable
                def agg[U1, U2, U3, U4](col1: TypedColumn[V, U1], col2: TypedColumn[V, U2], col3: TypedColumn[V, U3], col4: TypedColumn[V, U4]): Dataset[(K, U1, U2, U3, U4)]
                def agg[U1, U2, U3](col1: TypedColumn[V, U1], col2: TypedColumn[V, U2], col3: TypedColumn[V, U3]): Dataset[(K, U1, U2, U3)]
                def agg[U1, U2](col1: TypedColumn[V, U1], col2: TypedColumn[V, U2]): Dataset[(K, U1, U2)]
                def agg[U1](col1: TypedColumn[V, U1]): Dataset[(K, U1)]
                    Computes the given aggregation, returning a Dataset of tuples for each unique key and the result of computing this aggregation over all elements in the group.
                   
                def count(): Dataset[(K, Long)]
                def keyAs[L](implicit arg0: Encoder[L]): KeyValueGroupedDataset[L, V]
                    Returns a new KeyValueGroupedDataset where the type of the key has been mapped to the specified type.
                def keys: Dataset[K]
                    Returns a Dataset that contains each unique key. 
                    
                def reduceGroups(f: (V, V) => V): Dataset[(K, V)]
                    Reduces the elements of each group of data using the specified binary function.
                def cogroup[U, R](other: KeyValueGroupedDataset[K, U])(f: (K, Iterator[V], Iterator[U]) => TraversableOnce[R])(implicit arg0: Encoder[R]): Dataset[R]
                    Applies the given function to each cogrouped data.                   
                def mapValues[W](func: (V) => W)(implicit arg0: Encoder[W]): KeyValueGroupedDataset[K, W]
                    Returns a new KeyValueGroupedDataset where the given function func has been applied to the data.    
                def mapGroups[U](f: (K, Iterator[V]) => U)(implicit arg0: Encoder[U]): Dataset[U]
                    Applies the given function to each group of data.
                def flatMapGroups[U](f: (K, Iterator[V]) => TraversableOnce[U])(implicit arg0: Encoder[U]): Dataset[U]
                    Applies the given function to each group of data.
                    
                def mapGroupsWithState[S, U](timeoutConf: GroupStateTimeout)(func: (K, Iterator[V], GroupState[S]) => U)(implicit arg0: Encoder[S], arg1: Encoder[U]): Dataset[U]
                    Applies the given function to each group of data, 
                    while maintaining a user-defined per-group state.
                def mapGroupsWithState[S, U](func: (K, Iterator[V], GroupState[S]) => U)(implicit arg0: Encoder[S], arg1: Encoder[U]): Dataset[U]
                    Applies the given function to each group of data, 
                    while maintaining a user-defined per-group state.
                def  flatMapGroupsWithState[S, U](outputMode: OutputMode, timeoutConf: GroupStateTimeout)(func: (K, Iterator[V], GroupState[S]) => Iterator[U])(implicit arg0: Encoder[S], arg1: Encoder[U]): Dataset[U]
                    Applies the given function to each group of data, while maintaining a user-defined per-group state.
                trait  GroupState[S] extends LogicalGroupState[S] 
                    def exists: Boolean 
                        Whether state exists or not.
                    def get: S 
                        Get the state value if it exists, or throw NoSuchElementException.
                    def getOption: Option[S] 
                        Get the state value as a scala Option.
                    def hasTimedOut: Boolean 
                        Whether the function has been called because the key has timed out.
                    def remove(): Unit 
                        Remove this state.
                    def update(newState: S): Unit 
                        Update the value of the state.
                    def getCurrentProcessingTimeMs(): Long 
                        Get the current processing time as milliseconds in epoch time.
                    def getCurrentWatermarkMs(): Long 
                        Get the current event time watermark as milliseconds in epoch time.
                    def setTimeoutDuration(duration: String): Unit 
                        Set the timeout duration for this key as a string.
                    def setTimeoutDuration(durationMs: Long): Unit 
                        Set the timeout duration in ms for this key.
                    def setTimeoutTimestamp(timestamp: Date, additionalDuration: String): Unit 
                        Set the timeout timestamp for this key as a java.sql.Date and an additional duration as a string 
                    def setTimeoutTimestamp(timestamp: Date): Unit 
                        Set the timeout timestamp for this key as a java.sql.Date.
                    def setTimeoutTimestamp(timestampMs: Long, additionalDuration: String): Unit 
                        Set the timeout timestamp for this key as milliseconds in epoch time and an additional duration as a string (e.g.
                    def setTimeoutTimestamp(timestampMs: Long): Unit 
                        Set the timeout timestamp for this key as milliseconds in epoch time.
                    //Examples 
                    import org.apache.spark.sql.streaming._
                    // A mapping function that maintains an integer state for string keys and returns a string.
                    // Additionally, it sets a timeout to remove the state if it has not received data for an hour.
                    def mappingFunction(key: String, value: Iterator[Int], state: GroupState[Int]): String = {

                      if (state.hasTimedOut) {                // If called when timing out, remove the state
                        state.remove()

                      } else if (state.exists) {              // If state exists, use it for processing
                        val existingState = state.get         // Get the existing state
                        val shouldRemove = ...                // Decide whether to remove the state
                        if (shouldRemove) {
                          state.remove()                      // Remove the state

                        } else {
                          val newState = ...
                          state.update(newState)              // Set the new state
                          state.setTimeoutDuration("1 hour")  // Set the timeout
                        }

                      } else {
                        val initialState = ...
                        state.update(initialState)            // Set the initial state
                        state.setTimeoutDuration("1 hour")    // Set the timeout
                      }
                      ...
                      // return something
                    }
                    dataset.groupByKey(...).mapGroupsWithState(GroupStateTimeout.ProcessingTimeTimeout)(mappingFunction)

    

        
        

        
///Other functions exploration 
import spark.implicits._
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql._ 
import org.apache.spark.sql.types._ 

val df = sc.parallelize(Array((2, "Alice"), (5, "Bob"))).toDF("age", "name")

//Collection functions
array(*cols)
    Creates a new array column.
    Each cell would contain array of original columns cell value 
    Note you can access only one Row columns 
    To collect all values of a column, use collect_list/set 
    Note array, map , struct column can be accessed based on index, key or field 
    from Column.getItem(key) or Column.getField(name)
    //Examples 
    >>> df.select(F.array("age", "age").alias("arr")).collect()
    [Row(arr =[2, 2]), Row(arr =[5, 5])]
map(*cols)
    Creates a new map column.
    Note you can access only one Row columns 
    >>> df.select(F.map($"name", $"age").alias("map")).collect()
    [Row(map ={u"Alice": 2}), Row(map ={u"Bob": 5})]
struct(*cols)
    Creates a new struct column.
    Note you can access only one Row columns 
    >>> df.select(struct($"age", $"name").alias("struct")).collect()
    [Row(struct =Row(age =2,name =u"Alice")), Row(struct =Row(age =5,name =u"Bob"))]
collect_list(col)
    returns a list of all col values with duplicates.
    >>> df.agg(F.collect_list($"age")).collect()
    [Row(collect_list(age)=[2, 5, 5])]
collect_set(col)
    returns a set of objects with duplicate elements eliminated.
    >>> df.agg(F.collect_set($"age")).collect()
    [Row(collect_set(age)=[5, 2])]
array_contains(col, value)
    val df2 = sc.parallelize( (Array("a", "b", "c"),2) :: (Array[String](),1) :: Nil).toDF("data", "count")
    >>> df2.select(F.array_contains($"data", "a")).collect()
    [Row(array_contains(data, a)=True), Row(array_contains(data, a)=False)]
size(col)
    returns the length of the array or map stored in the column.
    >>> df2.select(F.size('data)).collect()  //'
    [Row(size(data)=3), Row(size(data)=1), Row(size(data)=0)]
sort_array(col)
    sorts the input array in ascending or descending order 
    according to the natural ordering of the array elements.
    >>> df2.select(F.sort_array('data).alias("r")).collect() //'
    [Row(r =[1, 2, 3]), Row(r =[1]), Row(r =[])]
    
//Misc functions 
expr(str)
    Parses the expression string into the column that it represents
    All spark sql functions can be called 
    >>> df.select(F.expr("length(name)")).collect()
    res10: Array[org.apache.spark.sql.Row] = Array([5], [3])
lit(literal)
    Creates a Column of literal value.
    >>> df.select(F.expr("length(name)"), F.lit(2)).collect()
    res11: Array[org.apache.spark.sql.Row] = Array([5,2], [3,2])
greatest(*cols)
    Returns the greatest value of the list of column names, 
    skipping null values. 
    This function takes at least 2 parameters. Note you can access only one Row columns 
    It will return null iff all parameters are null.
    val df3 = sc.parallelize(Array( (1, 4, 3) ) ).toDF("a", "b", "c")
    >>> df3.select(F.greatest('a, 'b, 'c).alias("greatest")).collect() //'
    [Row(greatest =4)]
least(*cols)
    Returns the least value of the list of column names, skipping null values. 
    This function takes at least 2 parameters. It will return null iff all parameters are null.
    >>> df3.select(F.least('a, 'b, 'c).alias("least")).collect() //'
    [Row(least =1)]
    
//String functions
concat_ws(sep, *cols)
    Concatenates multiple input string columns together into a single string column, using the given separator.
    val df5 = sc.parallelize( ("abcd","123")::Nil).toDF("s", "d")
    >>> df5.select(F.concat_ws("-", 's, 'd).alias("s")).collect()
    [Row(s='abcd-123')] 
concat(*cols)
    Concatenates multiple input string columns together into a single string column.
    val df4 = sc.parallelize(Array( ("abcd","123") )).toDF("s", "d")
    >>> df4.select(F.concat('s, 'd).alias("s")).collect()
    [Row(s =u"abcd123")]
format_number(col, d)
    Formats the number X to a format like "//,�//,�//.�", rounded to d decimal places, 
    and returns the result as a string.
    >>> sc.parallelize(Array( Tuple1(5) )).toDF("a").select(F.format_number($"a", 4).alias("v")).collect()
    [Row(v =u"5.0000")]
format_string(format, *cols)
    Formats the arguments in printf-style and returns the result as a string column.
    val df5 = sc.parallelize( (5, "hello") :: Nil ).toDF("a", "b")
    >>> df5.select(F.format_string("%d %s", 'a, 'b).alias("v")).collect()
    [Row(v =u"5 hello")]     

instr(str, substr)
    Locate the position of the first occurrence of substr column in the given string. 
    Returns null if either of the arguments are null.
    val df6 = sc.parallelize( Tuple1("abcd") :: Nil ).toDF("s")
    >>> df6.select(F.instr($"s", "b").alias("s")).collect()
    [Row(s =2)]
length(col)
    Calculates the length of a string or binary expression.
    >>> df.select(F.length($"name").alias("length")).collect()
    [Row(length =3)]
levenshtein(left, right)
    Computes the Levenshtein distance of the two given strings.
    val df0 = sc.parallelize( ("kitten", "sitting") :: Nil ).toDF("l", "r")
    >>> df0.select(F.levenshtein($"l", $"r").alias("d")).collect()
    [Row(d =3)]
locate(substr, str,pos =1)
    Locate the position of the first occurrence of substr in a string column, after position pos.
    >>> df.select(F.locate("i", $"name", 1).alias("s")).collect()
        res24: Array[org.apache.spark.sql.Row] = Array([3], [0])
lower(col)
    Converts a string column to lower case.
lpad(col, len, pad)
    Left-pad the string column to width len with pad.
ltrim(col)
    Trim the spaces from left end for the specified string value.
repeat(col, n)
    Repeats a string column n times, and returns it as a new string column.
    val df7 = sc.parallelize( Tuple1("ab"):: Nil).toDF("s")
    >>> df7.select(F.repeat('s, 3).alias("s")).collect() #'
    [Row(s =u"ababab")]
reverse(col)
    Reverses the string column and returns it as a new string column.
rpad(col, len, pad)
    Right-pad the string column to width len with pad.
trim(col)
    Trim the spaces from both ends for the specified string column.
upper(col)
    Converts a string column to upper case.
rtrim(col)
    Trim the spaces from right end for the specified string value.
substring(str, pos, len)
    Substring starts at pos and is of length len when str is String type 
    val df8= sc.parallelize( Tuple1("abcd")::Nil).toDF("s")
    >>> df8.select(F.substring('s, 1, 2).alias("s")).collect() //'
    [Row(s =u"ab")]
substring_index(str, delim, count)
    Returns the substring from string str before count occurrences of the delimiter delim. 
    If count is positive, everything the left of the final delimiter (counting from left) is returned. 
    If count is negative, every to the right of the final delimiter (counting from the right) is returned. 
    substring_index performs a case-sensitive match when searching for delim.
    val df9 = sc.parallelize( Tuple1("a.b.c.d")::Nil).toDF("s")
    >>> df9.select(F.substring_index('s, ".", 2).alias("s")).collect()
    [Row(s =u"a.b")]
    >>> df9.select(F.substring_index('s, ".", -3).alias("s")).collect()
    [Row(s =u"b.c.d")]
translate(srcCol, matching, replace)
    A function translate any character in the srcCol by a character in matching. 
    The characters in replace is corresponding to the characters in matching. 
    The translate will happen when any character in the string matching with the character in the matching.
    >>> sc.parallelize( Tuple1("translate")::Nil).toDF("a").select(F.translate($"a", "rnlt", "123").alias("r")).collect()
    [Row(r =u"1a2s3ae")]

    
//Regex functions 
regexp_extract(col, pattern, idx)
    idx = particular group id to return 
    Extract a specific group matched by a Java regex, from the specified string column. 
    If the regex did not match, or the specified group did not match, an empty string is returned.
    val df1 = sc.parallelize( Tuple1("100-200")::Nil).toDF("str")
    >>> df1.select(F.regexp_extract($"str", raw"(\d+)-(\d+)", 1).alias("d")).collect()
    [Row(d =u"100")]
regexp_replace(e: Column, pattern: String, replacement: String)
regexp_replace(e: Column, pattern: Column, replacement: Column)
    Replace all substrings of the specified string value that match regexp with rep.
    >>> df1.select(F.regexp_replace($"str", raw"(\d+)-(\d+)", "$2-$1").alias("d")).collect()
    [Row(d =200-100)]
split(col, pattern)
    Splits str around pattern (pattern is a regular expression).
    >>> df1.select(F.split($"str", "-").alias("s")).collect()
    [Row(s =(100, 200))]       

//Date and time functions    
Used with col is DateType -> java.sql.Date or TimestampType -> java.sql.Timestamp   
current_date()
    Returns the current date as a "date" column.
    >>> df1.select(F.current_date().alias("s")).collect()
    res39: Array[org.apache.spark.sql.Row] = Array([2018-10-31]) //yyyy-MM-dd
current_timestamp()
    Returns the current timestamp as a "timestamp" column. 
    >>> df1.select(F.current_timestamp().alias("s")).collect()    
    res40: Array[org.apache.spark.sql.Row] = Array([2018-10-31 09:58:43.9])//yyyy-MM-dd hh:mm:ss.S
add_months(col, months)
    Returns the date that is months months after start
    >>> val df2 = sc.parallelize( Tuple1("2015-04-08")::Nil).toDF("d")
    df2: org.apache.spark.sql.DataFrame = [d: string]
    >>> df2.select(F.add_months($"d", 1).alias("d")).collect()
    res41: Array[org.apache.spark.sql.Row] = Array([2015-05-08])    
date_add(col, days)
    Returns the date that is days days after start
    >>> df2.select(F.date_add('d, 1).alias("d")).collect() //'
    res42: Array[org.apache.spark.sql.Row] = Array([2015-04-09])
date_format(col, format)
    Converts a date/timestamp/string to a value of string in the format specified 
    eg pattern- dd.MM.yyyy from java.text.SimpleDateFormat    
    >>> df2.select(F.date_format($"d", "MM/dd/yyyy").alias("date")).collect()
    [Row(date =u"04/08/2015")]
date_sub(col, days)
    Returns the date that is days days before start
    >>> df2.select(F.date_sub($"d", 1).alias("d")).collect()
    [Row(d =2015-04-07)]
datediff(col_end, col_start)
    Returns the number of days from start to end.
    >>> df2.select(F.datediff('d, 'd).alias("diff")).collect()
    [Row(diff =0)]
dayofmonth(col)
    Extract the day of the month of a given date as integer.
    >>> df2.select(F.dayofmonth($"d").alias("day")).collect()
    [Row(day =8)]
months_between(col_date1, col_date2)
    Returns the number of months between date1 and date2.
    val df3 = sc.parallelize( ("1997-02-28 10:30:00", "1996-10-30")::Nil).toDF("t", "d")
    >>> df3.select(F.months_between('t, 'd).alias("months")).collect()
    [Row(months =3.94959677)]
next_day(col, dayOfWeek)
    Returns the first date which is later than the value of the date column.
    Day of the week parameter is case insensitive, and accepts:"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun".
    >>> df2.select(F.next_day($"d", "Sun").alias("date")).collect()
    [Row(date =2015-04-12)]
trunc(col, format)
    Returns date truncated to the unit specified by the format.
    format � "year", "YYYY", "yy" or "month", "mon", "mm" 
    >>> df2.select(F.trunc($"d", "year").alias("year")).collect()
    [Row(year =2015-01-01)]
    >>> df2.select(F.trunc($"d", "mon").alias("month")).collect()
    [Row(month =2015-04-01)] 
    
//Conversion functions 
to_date(col)
    Converts the column of org.apache.spark.sql.types.StringType 
    or org.apache.spark.sql.types.TimestampType into org.apache.spark.sql.types.DateType.
    >>> df2.select(F.to_date('d).alias("date")).printSchema //'
        root
         |-- date: date (nullable = true)
to_json(col,options ={})
    Converts a column containing a StructType into a JSON string. 
    Throws an exception, in the case of an unsupported type.
    >>> df.select(F.to_json(F.struct($"age",$"name")).alias("json")).collect()
        res54: Array[org.apache.spark.sql.Row] = Array([{"age":2,"name":"Alice"}], [{"age":5,"name":"Bob"}])
to_utc_timestamp(col, tz)
    Given a timestamp, which corresponds to a certain time of day 
    in the given timezone, returns another timestamp that corresponds 
    to the same time of day in UTC.
    >>> df2.select(F.to_utc_timestamp($"d", "PST").alias("t")).collect()
    [Row(t =[2015-04-08 07:00:00.0])]    
from_unixtime(col_unixTimestamp, format ="yyyy-MM-dd HH:mm:ss")
    Converts the number of seconds from unix epoch (1970-01-01 00:00:00 UTC) 
    to a string representing the timestamp of that moment in the current system time zone 
    in the given format.
from_utc_timestamp(col_timestamp, tz)
    Given a timestamp, which corresponds to a certain time of day in UTC, 
    returns another timestamp that corresponds to the same time of day in the given timezone.
get_json_object(col, path)
    Extracts json object from a json string based on json path specified, 
    and returns json string of the extracted json object. 
    It will return null if the input json string is invalid.
    val data =Array( ("1", """{"f1": "value1", "f2": "value2"}"""), ("2", """{"f1": "value12"}"""))
    val df3 = sc.parallelize(data).toDF("key", "jstring")
    >>> df3.select($"key", F.get_json_object($"jstring", "$.f1").alias("c0"),
                get_json_object($"jstring", "$.f2").alias("c1") ).collect()
    [Row(key =u"1",c0 =u"value1",c1 =u"value2"), Row(key =u"2",c0 =u"value12",c1 =None)]
json_tuple(col, *fields)
    Creates a new row for a json column according to the given field names.
    >>> df3.select($"key", F.json_tuple($"jstring", "f1", "f2")).collect()
    [Row(key =u"1",c0 =u"value1",c1 =u"value2"), Row(key =u"2",c0 =u"value12",c1 =None)]
when(condition, value)
    Evaluates a list of conditions and returns one of multiple possible result expressions. 
        condition � a boolean Column expression.
        value � a literal value, or a Column expression.
    >>> df.select(F.when($"age" === F.lit(2), 3).otherwise(4).alias("age")).collect()
    [Row(age=3), Row(age=4)]
    >>> df.select(F.when('age === 2, 'age + 1).alias("age")).collect()
    [Row(age=3), Row(age=None)]
explode(col)
    Returns a new row for each element in the given array or map.
    val eDF = sc.parallelize( (1, Array(1,2,3), Map("a"-> "b")) :: Nil).toDF("a", "intlist", "mapfield")
    >>> eDF.select(F.explode($"intlist").alias("anInt")).collect()
    [Row(anInt=1), Row(anInt=2), Row(anInt=3)]
    >>> eDF.select(F.explode($"mapfield").as(Array("key", "value"))).show()
    +---+-----+
    |key|value|
    +---+-----+
    |  a|    b|
    +---+-----+
explode_outer(col)
    Returns a new row for each element in the given array or map. 
    Unlike explode, if the array/map is null or empty then null is produced.
    val eDF = sc.parallelize((1, Array("foo", "bar"), Map("x"-> 1.0)) :: (2, Array[String](), Map[String,Double]()) :: (3, null:Array[String], null:Map[String,Double]) :: Nil ).toDF("id", "an_array", "a_map")
    >>> eDF.select($"id", $"an_array", F.explode_outer($"a_map")).show()
    +---+----------+----+-----+
    | id|  an_array| key|value|
    +---+----------+----+-----+
    |  1|[foo, bar]|   x|  1.0|
    |  2|        []|null| null|
    |  3|      null|null| null|
    +---+----------+----+-----+
    >>> eDF.select($"id", $"a_map", F.explode_outer($"an_array")).show()
    +---+----------+----+
    | id|     a_map| col|
    +---+----------+----+
    |  1|[x -> 1.0]| foo|
    |  1|[x -> 1.0]| bar|
    |  2|        []|null|
    |  3|      null|null|
    +---+----------+----+
posexplode_outer(col)
posexplode(col)
    Returns a new row for each element with position in the given array or map.
    val eDF = sc.parallelize( (1, Array(1,2,3), Map("a"-> "b")) :: Nil).toDF("a", "intlist", "mapfield")
    >>> eDF.select(F.posexplode($"intlist")).show()
    +---+---+
    |pos|col|
    +---+---+
    |  0|  1|
    |  1|  2|
    |  2|  3|
    +---+---+
    >>> eDF.select(F.posexplode('mapfield)).show() //'
    +---+---+-----+
    |pos|key|value|
    +---+---+-----+
    |  0|  a|    b|
    +---+---+-----+



       
     



///functions Example - String interpretation with the array() method
val df = Seq(
  ("i like blue and red"),
  ("you pink and blue")
).toDF("word1")

val actualDF = df.withColumn(
  "colors",
  F.array(
    F.when(F.col("word1").contains("blue"), "blue"),
    F.when(F.col("word1").contains("red"), "red"),
    F.when(F.col("word1").contains("pink"), "pink"),
    F.when(F.col("word1").contains("cyan"), "cyan")
  )
)
//The array() function unfortunately includes null values in the colors column. 
actualDF.show(truncate = false)
+-------------------+------------------------+
|word1              |colors                  |
+-------------------+------------------------+
|i like blue and red|[blue, red, null, null] |
|you pink and blue  |[blue, null, pink, null]|
+-------------------+------------------------+

//OR 
val colors = Array("blue", "red", "pink", "cyan")

val actualDF = df.withColumn(
  "colors",
  F.array(
    colors.map{ c: String =>  F.when(F.col("word1").contains(c), c) }: _*
  )
)
actualDF.show(truncate=false)
+-------------------+------------------------+
|word1              |colors                  |
+-------------------+------------------------+
|i like blue and red|[blue, red, null, null] |
|you pink and blue  |[blue, null, pink, null]|
+-------------------+------------------------+

///Eliminating null from the arrays

val actualDF = df.withColumn(
  "colors",
  F.split(
    F.concat_ws(
      ",",
      F.when(F.col("word1").contains("blue"), "blue"),
      F.when(F.col("word1").contains("red"), "red"),
      F.when(F.col("word1").contains("pink"), "pink"),
      F.when(F.col("word1").contains("cyan"), "cyan")
    ),
    ","
  )
)

actualDF.show(truncate=false)
+-------------------+------------+
|word1              |colors      |
+-------------------+------------+
|i like blue and red|[blue, red] |
|you pink and blue  |[blue, pink]|
+-------------------+------------+

//Or use 
//build.sbt 
resolvers += "Spark Packages Repo" at "http://dl.bintray.com/spark-packages/maven"
libraryDependencies += "mrpowers" % "spark-daria" % "2.2.0_0.12.0"
//code 
import com.github.mrpowers.spark.daria.sql.functions._ 

val colors = Array("blue", "red", "pink", "cyan")

val actualDF = df.withColumn(
  "colors",
  arrayExNull(
    colors.map{ c: String =>
      when(col("word1").contains(c), c)
    }: _*
  )
)

actualDF.show(truncate=false)



///Example - Splitting a string into an ArrayType column

import spark.implicits._ 

val singersDF = Seq(  ("beatles", "help|hey jude"),  ("romeo", "eres mia")).toDF("name", "hit_songs")

//def withColumn(colName: String, col: Column): DataFrame
//Returns a new Dataset by adding a column or replacing the existing column that has the same name. 
val actualDF = singersDF.withColumn( "hit_songs", F.split(F.col("hit_songs"), "\\|") )

actualDF.show()
//output 
+-------+----------------+
|   name|       hit_songs|
+-------+----------------+
|beatles|[help, hey jude]|
|  romeo|      [eres mia]|
+-------+----------------+

actualDF.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- hit_songs: array (nullable = true)
 |    |-- element: string (containsNull = true)

  
///Directly creating an ArrayType column

val rdd = sc.parallelize( Seq( Row("bieber", Array("baby", "sorry")), Row("ozuna", Array("criminal"))))
val schema = StructType(StructField("name", StringType, true) :: StructField("hit_songs", ArrayType(StringType, true), true) ::Nil)
val singersDFA = spark.createDataFrame(rdd, schema)
 
singersDFA.show()
//output 
+------+-------------+
|  name|    hit_songs|
+------+-------------+
|bieber|[baby, sorry]|
| ozuna|   [criminal]|
+------+-------------+
singersDFA.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- hit_songs: array (nullable = true)
 |    |-- element: string (containsNull = true)

//Example - selecting 1st index 
singersDFA.select(
    F.col("name"),
    F.col("hit_songs")(0).as("First")
  ).show()
  
 
///Directly creating a MapType column

val singersDF = spark.createDataFrame(
  sc.parallelize(Seq(
    Row("sublime", Map(
      "good_song" -> "santeria",
      "bad_song" -> "doesn't exist")
    ),
    Row("prince_royce", Map(
      "good_song" -> "darte un beso",
      "bad_song" -> "back it up")
    )
  )), StructType(List(
    StructField("name", StringType, true),
    StructField("songs", MapType(StringType, StringType, true), true)
  ))
)

singersDF.show()
//output 
+------------+--------------------+
|        name|               songs|
+------------+--------------------+
|     sublime|Map(good_song -> ...|
|prince_royce|Map(good_song -> ...|
+------------+--------------------+

singersDF.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: string (valueContainsNull = true)

//Example - we can display the singer name and their bad song:
singersDF.select(
    F.col("name"),
    F.col("songs")("bad_song").as("bad song!")
  ).show()
//output 
+------------+-------------+
|        name|    bad song!|
+------------+-------------+
|     sublime|doesnt exist|
|prince_royce|   back it up|
+------------+-------------+

///Creating a schema with a column that uses MapType and ArrayType
val singersDFMA = spark.createDataFrame(
  sc.parallelize(Seq(
    Row("miley", Map(
      "good_songs" -> Array("party in the usa", "wrecking ball"),
      "bad_songs" -> Array("younger now"))
    ),
    Row("kesha", Map(
      "good_songs" -> Array("tik tok", "timber"),
      "bad_songs" -> Array("rainbow"))
    )
  )), StructType(List(
    StructField("name", StringType, true),
    StructField("songs", MapType(StringType, ArrayType(StringType, true), true), true)
  ))
)

singersDFMA.show()
//output
+-----+--------------------+
| name|               songs|
+-----+--------------------+
|miley|Map(good_songs ->...|
|kesha|Map(good_songs ->...|
+-----+--------------------+

singersDFMA.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: array (valueContainsNull = true)
 |    |    |-- element: string (containsNull = true)

// display the good songs for each singer.
singersDF
  .select(
    F.col("name"),
    F.col("songs")("good_songs").as("fun")
  ).show()
//output 
+-----+--------------------+
| name|                 fun|
+-----+--------------------+
|miley|[party in the usa...|
|kesha|   [tik tok, timber]|
+-----+--------------------+

///array_contains() and explode() methods for ArrayType columns
//forall() and exists() methods for ArrayType columns that function similar to the Scala forall() and exists() methods.
//The array_contains method returns true if the column contains a specified element.
val peopleDF = spark.createDataFrame(
  sc.parallelize(Seq(
    Row("bob", Array("red", "blue")),
    Row("maria", Array("green", "red")),
    Row("sue", Array("black"))
  )), StructType(List(
    StructField("name", StringType, true),
    StructField("favorite_colors", ArrayType(StringType, true), true)
  ))
)

val actualDF = peopleDF.withColumn(
  "likes_red",
  F.array_contains(F.col("favorite_colors"), "red")
)

actualDF.show()

+-----+---------------+---------+
| name|favorite_colors|likes_red|
+-----+---------------+---------+
|  bob|    [red, blue]|     true|
|maria|   [green, red]|     true|
|  sue|        [black]|    false|
+-----+---------------+---------+

//The explode() method creates a new row for every element in an array.
peopleDF.select(
  F.col("name"),
  F.explode(F.col("favorite_colors")).as("color")
).show()

+-----+-----+
| name|color|
+-----+-----+
|  bob|  red|
|  bob| blue|
|maria|green|
|maria|  red|
|  sue|black|
+-----+-----+

///Example complex example 
case class Person(userId: String, tech: Option[Tech])
case class Browser(family: Option[String],
               major: Option[Int] = None, 
               minor: Option[Int] = None,               
               language: Option[String],
               timesSeen: Long = 1
               )
case class Tech(browsers: Seq[Browser], 
                     oss: String)

import spark.implicits._ 
val df = Seq(Person("abc",Some(Tech(browsers=Seq(
    Browser(family=Some("IE"), major=Some(7), language=Some("en"), timesSeen=3),
    Browser(family=None, major=None, language=Some("en-us"), timesSeen=1),
    Browser(family=Some("Firefox"), major=None, language=None, timesSeen=1)
  ), oss="win"))),
  Person("abc",Some(Tech(browsers=Seq(
    Browser(family=Some("IE"), major=Some(7), language=Some("en"), timesSeen=3),
    Browser(family=None, major=None, language=Some("en-us"), timesSeen=1),
    Browser(family=Some("Firefox"), major=None, language=None, timesSeen=1)
  ), oss="win")))).toDF()
//df:[userId: string, tech: struct<browsers: array<struct<family:string,major:int,minor:int,language:string,timesSeen:bigint>>, oss: string>]

// Select two columns
df.select("userId", "tech.browsers").show()
//output 
+------+--------------------+
|userId|            browsers|
+------+--------------------+
|   abc|[[IE,7,null,en,3]...|
|   abc|[[IE,7,null,en,3]...|
+------+--------------------+


// Select the nested values only
df.select("tech.browsers").show(truncate = false)
+------------------------------------------------------------------------+
|browsers                                                                |
+------------------------------------------------------------------------+
|[[IE,7,null,en,3], [null,null,null,en-us,1], [Firefox,null,null,null,1]]|
|[[IE,7,null,en,3], [null,null,null,en-us,1], [Firefox,null,null,null,1]]|
+------------------------------------------------------------------------+

// Extract the family (nested value)
// This way you can iterate over the persons, and get their browsers
// Family values are nested
df.select("tech.browsers.family").show()
//output 
+-------------------+
|             family|
+-------------------+
|[IE, null, Firefox]|
|[IE, null, Firefox]|
+-------------------+

// Normalize the family: One row for each family
// Then you can iterate over all families
// Family values are un-nested, empty values/null/None are handled by explode()
df.select(F.explode(F.col("tech.browsers.family")).alias("family")).show()
+-------+
| family|
+-------+
|     IE|
|   null|
|Firefox|
|     IE|
|   null|
|Firefox|
+-------+

//
val families = df.select(F.explode(F.col("tech.browsers.family"))).map(row => row.getString(0)).distinct().collect().toList
println(families) //List(null, Firefox, IE)






///*** DF operations - UDF registration - Userdefined function to operate on DF columns 
//Always use UDF to convert a Column or many columns into a new Column 
//Note in UDF , you can access only one Row(all columns) at a time 
//The Columns schema would be the datatype in scala ie StringType is String  as given below 
BooleanType -> java.lang.Boolean
ByteType -> java.lang.Byte
ShortType -> java.lang.Short
IntegerType -> java.lang.Integer
FloatType -> java.lang.Float
DoubleType -> java.lang.Double
StringType -> String
DecimalType -> java.math.BigDecimal

DateType -> java.sql.Date
TimestampType -> java.sql.Timestamp

BinaryType -> byte array
ArrayType -> scala.collection.Seq 
MapType -> scala.collection.Map 
StructType -> org.apache.spark.sql.Row


//use sparkSession.udf.register(must to access from spark-sql) or org.apache.spark.sql.functions.udf

//register can take Function1 to Function22 as well as zero arg 
sparkSession.udf.register("myUDF", (arg1: Int, arg2: String) => arg2 + arg1)
//OR , udf can take Function1 to Function22 as well as zero arg
val myUDF = F.udf((arg1: Int, arg2: String) => arg2 + arg1)
//Usage 
val rescaledData = indexedData.withColumn("vd", myUDF($"col1", $"col2"))
val rescaledData = indexedData.select( myUDF($"col1", $"col2").alias("vd"))


///Example - Converting Many columns to One column 
//Option-1.Return a column of complex type. 
//The most general solution is a StructType but you can consider ArrayType or MapType as well.

import org.apache.spark.sql.functions._

val df = Seq( (1L, 3.0, "a"), (2L, -1.0, "b"), (3L, 0.0, "c") ).toDF("x", "y", "z")

case class Foobar(foo: Double, bar: Double)

val foobarUdf = F.udf((x: Long, y: Double, z: String) =>  Foobar(x * y, z.head.toInt * y))
val aUdf = F.udf((x: Long, y: Double, z: String) =>  Array(x * y, z.head.toInt * y))
val mUdf = F.udf((x: Long, y: Double, z: String) => Map(x * y -> z.head.toInt * y))

val df1 = df.withColumn("foobar", foobarUdf($"x", $"y", $"z")).withColumn("array", aUdf($"x", $"y", $"z")).withColumn("map", mUdf($"x", $"y", $"z"))
df1.show
//output 
+---+----+---+------------+-------------+------------------+
|  x|   y|  z|      foobar|        array|               map|
+---+----+---+------------+-------------+------------------+
|  1| 3.0|  a| [3.0,291.0]| [3.0, 291.0]| Map(3.0 -> 291.0)|
|  2|-1.0|  b|[-2.0,-98.0]|[-2.0, -98.0]|Map(-2.0 -> -98.0)|
|  3| 0.0|  c|   [0.0,0.0]|   [0.0, 0.0]|   Map(0.0 -> 0.0)|
+---+----+---+------------+-------------+------------------+

df1.printSchema
//output 
root
 |-- x: long (nullable = false)
 |-- y: double (nullable = false)
 |-- z: string (nullable = true)
 |-- foobar: struct (nullable = true)
 |    |-- foo: double (nullable = false)
 |    |-- bar: double (nullable = false)
 |-- array: array (nullable = true)
 |    |-- element: double (containsNull = false)
 |-- map: map (nullable = true)
 |    |-- key: double
 |    |-- value: double (valueContainsNull = false)
 
df1.select(F.col("foobar.foo"), F.col("array")(0).as("firstIndex"),F.col("map")(3.0).as("3Value")).show()
//output 
+----+----------+------+
| foo|firstIndex|3Value|
+----+----------+------+
| 3.0|       3.0| 291.0|
|-2.0|      -2.0|  null|
| 0.0|       0.0|  null|
+----+----------+------+


///2.Switch to RDD, reshape and rebuild DF:
import org.apache.spark.sql.types._
import org.apache.spark.sql.Row

def foobarFunc(x: Long, y: Double, z: String): Seq[Any] =   Seq(x * y, z.head.toInt * y)

val schema = StructType(df.schema.fields ++
  Array(StructField("foo", DoubleType), StructField("bar", DoubleType)))

val rows = df.rdd.map(r => Row.fromSeq( r.toSeq ++ foobarFunc(r.getAs[Long]("x"), r.getAs[Double]("y"), r.getAs[String]("z"))))

val df2 = sqlContext.createDataFrame(rows, schema)

df2.show
// +---+----+---+----+-----+
// |  x|   y|  z| foo|  bar|
// +---+----+---+----+-----+
// |  1| 3.0|  a| 3.0|291.0|
// |  2|-1.0|  b|-2.0|-98.0|
// |  3| 0.0|  c| 0.0|  0.0|
// +---+----+---+----+-----+


///User defined aggregate Function, UDAF - Use with groupBy(..).agg(UDAF)
//extend UserDefinedAggregateFunctions and define following four methods:
initialize(buffer: MutableAggregationBuffer): Unit 
    On a given node, this method is called once for each group ie called whenever key changes 
    Note, spark passes buffer to you based on bufferSchema
    Your job is to call buffer.get*(index) to get the value and buffer.update(i: Int, value: Any) 
    check get* methods from http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.expressions.MutableAggregationBuffer
        def  copy(): Row 
            Make a copy of the current Row object.
        def  get(i: Int): Any 
            Returns the value at position i.
        def  length: Int 
            Number of elements in the Row.
        def  update(i: Int, value: Any): Unit 
            Update the ith value of this buffer. 
        def anyNull: Boolean 
        def apply(i: Int): Any 
        def equals(o: Any): Boolean 
        def fieldIndex(name: String): Int 
        def getAs[T](fieldName: String): T 
        def getAs[T](i: Int): T 
        def getBoolean(i: Int): Boolean 
        def getByte(i: Int): Byte 
        def getDate(i: Int): Date 
        def getDecimal(i: Int): BigDecimal 
        def getDouble(i: Int): Double 
        def getFloat(i: Int): Float 
        def getInt(i: Int): Int 
        def getJavaMap[K, V](i: Int): Map[K, V] 
        def getList[T](i: Int): List[T] 
        def getLong(i: Int): Long 
        def getMap[K, V](i: Int): Map[K, V] 
        def getSeq[T](i: Int): Seq[T] 
        def getShort(i: Int): Short 
        def getString(i: Int): String 
        def getStruct(i: Int): Row 
        def getTimestamp(i: Int): Timestamp 
        def getValuesMap[T](fieldNames: Seq[String]): Map[String, T] 
        def hashCode(): Int 
        def isNullAt(i: Int): Boolean 
        def mkString(start: String, sep: String, end: String): String 
        def mkString(sep: String): String 
        def mkString: String 
        def schema: StructType 
        def size: Int 
        def toSeq: Seq[Any] 
        def toString(): String 
update(buffer: MutableAggregationBuffer, input: Row): Unit 
    For a given group, spark will call 'update' for each input record of that group.
merge(buffer1: MutableAggregationBuffer, buffer2: Row): Unit 
    if the function supports partial aggregates, spark might (as an optimization) 
    compute partial result and combine them together
evaluate(buffer: Row): Any 
    Once all the entries for a group are exhausted, 
    spark will call evaluate to get the final result.
//And below 
def inputSchema: StructType 
    A StructType represents data types of input arguments of this aggregate function
def  bufferSchema: StructType 
    A StructType represents data types of values in the aggregation buffer ie for MutableAggregationBuffer
def  dataType: DataType 
    The DataType of the returned value of this UserDefinedAggregateFunction.
def  deterministic: Boolean 
    Returns true iff this function is deterministic, i.e. given the same input, always return the same output. 
// UserDefinedAggregateFunction  is created using apply or distinct factory methods.
class  UserDefinedAggregateFunction
    def  apply(exprs: Column*): Column 
        Creates a Column for this UDAF using given Columns as input arguments.
    def  distinct(exprs: Column*): Column 
        Creates a Column for this UDAF using the distinct values of the given Columns as input arguments
//Then Register with for usage with spark-sql 
spark.register(name: String, udaf: UserDefinedAggregateFunction): UserDefinedAggregateFunction 
        
//If the function doesn�t support partial aggregates (or combiner)
initialize -> update -> update .....-> evaluate 
//if the function supports partial aggregates
   initialize -> update -> update .....->
                                        |
                                        v
initialize -> update -> update .....-> merge -> evaluate 
                                        ^
                                        |
   initialize -> update -> update .....->
   
   

//Below is a example showing how to write a custom function that computes mean.

import org.apache.spark.sql._
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.types._

//Extend UserDefinedAggregateFunction to write custom aggregate function
//You can also specify any constructor arguments. For instance you 
//can have CustomMean(arg1: Int, arg2: String)
class CustomMean() extends UserDefinedAggregateFunction {
    // Input Data Type Schema
    def inputSchema: val StructType = StructType(Array(StructField("item", DoubleType)))
    // Intermediate Schema
    def val bufferSchema = StructType(Array(
        StructField("sum", DoubleType),
        StructField("cnt", LongType)
        ))
    // Returned Data Type .
    def dataType: val DataType = DoubleType
    // Self-explaining
    def val deterministic = true
    // This function is called whenever key changes
    def initialize(buffer: MutableAggregationBuffer) = {
        buffer(0) = 0.toDouble // set sum to zero
        buffer(1) = 0L // set number of items to 0
    }
    // Iterate over each entry of a group
    def update(buffer: MutableAggregationBuffer, input: Row) = {
        buffer(0) = buffer.getDouble(0) + input.getDouble(0)
        buffer(1) = buffer.getLong(1) + 1
    }
    // Merge two partial aggregates
    def merge(buffer1: MutableAggregationBuffer, buffer2: Row) = {
        buffer1(0) = buffer1.getDouble(0) + buffer2.getDouble(0)
        buffer1(1) = buffer1.getLong(1) + buffer2.getLong(1)
    }
    // Called after all the entries are exhausted.
    def evaluate(buffer: Row) = {
        buffer.getDouble(0)/buffer.getLong(1).toDouble
    }
}
//Usage 
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{functions =>F}
import com.myudafs.CustomMean
// define UDAF
val customMean = new CustomMean()
// create test dataset
val data = (1 to 1000).map{x:Int => x match {
    case t if t <= 500 => Row("A", t.toDouble)
    case val t => Row("B", t.toDouble)
    }}
// create schema of the test dataset
val schema = StructType(Array(
    StructField("key", StringType),
    StructField("value", DoubleType)
    ))
// construct data frame
val rdd = sc.parallelize(data)
val df = spark.createDataFrame(rdd, schema)
// Calculate average value for each group
df.groupBy("key").agg(customMean(F.col("value")).as("custom_mean"),F.avg("value").as("avg")).show()



/// Another example - Custom UDAF to count rows

import org.apache.spark.sql._
import org.apache.spark.sql.expressions._
import org.apache.spark.sql.types._

class MyCountUDAF extends UserDefinedAggregateFunction {
  override def inputSchema: val StructType = {
    new StructType().add("id", LongType,nullable = true)
  }

  override def bufferSchema: val StructType = {
    new StructType().add("count", LongType,nullable = true)
  }

  override def dataType: val DataType = LongType

  override def deterministic: val Boolean = true

  override def initialize(buffer: MutableAggregationBuffer): val Unit = {
    println(s">>> initialize (buffer: $buffer)")
    buffer(0) = 0L
  }

  override def update(buffer: MutableAggregationBuffer, input: Row): val Unit = {
    println(s">>> update (buffer: $buffer -> input: $input)")
    buffer(0) = buffer.getLong(0) + 1
  }

  override def merge(buffer: MutableAggregationBuffer, row: Row): val Unit = {
    println(s">>> merge (buffer: $buffer -> row: $row)")
    buffer(0) = buffer.getLong(0) + row.getLong(0)
  }

  override def evaluate(buffer: Row): val Any = {
    println(s">>> evaluate (buffer: $buffer)")
    buffer.getLong(0)
  }
}
// UserDefinedAggregateFunction  is created using apply or distinct factory methods.

val dataset = spark.range(start = 0,end = 4,step = 1,numPartitions = 2)

// Use the UDAF
val mycount = new MyCountUDAF
val q = dataset.
  withColumn("group", "id % 2).
  groupBy("group).
  agg(mycount.distinct('id) as "count")  //'
scala> q.show
+-----+-----+
|group|count|
+-----+-----+
|    0|    2|
|    1|    2|
+-----+-----+
//to use in SQL 
spark.udf.register("mycount", mycount)
spark.sql("SELECT mycount(*) FROM range(5)")



























///***WinnersCurse example 
val lines =sc.textFile(raw".\data\spark\Cartier+for+WinnersCurse.csv")
val headers = lines.first

import org.apache.spark.sql.types._

val fs = headers.split(",").map(f => StructField(f, StringType))
//fs: Array[org.apache.spark.sql.types.StructField] = Array(StructField(auctionid,StringType,true), StructField(bid,StringType,true), StructField(bidtime,StringType,true), StructField(bidder,StringType,true), StructField(bidderrate,StringType,true), StructField(openbid,StringType,true), StructField(price,StringType,true))

val schema = StructType(fs)

val noheaders = lines.filter(_ != headers)
noheaders: org.apache.spark.rdd.RDD[String] = MapPartitionsRDD[10] at filter at <console>:33

>>> val rows = noheaders.map(_.split(",")).map(a => Row.fromSeq(a))
rows: org.apache.spark.rdd.RDD[org.apache.spark.sql.Row] = MapPartitionsRDD[12] at map at <console>:35

>>> val auctions = spark.createDataFrame(rows, schema)
auctions: org.apache.spark.sql.val DataFrame = [auctionid: string, bid: string, bidtime: string, bidder: string, bidderrate: string, openbid: string, price: string]

>>> auctions.printSchema
root
 |-- auctionid: string (nullable = true)
 |-- bid: string (nullable = true)
 |-- bidtime: string (nullable = true)
 |-- bidder: string (nullable = true)
 |-- bidderrate: string (nullable = true)
 |-- openbid: string (nullable = true)
 |-- price: string (nullable = true)

>>> auctions.dtypes
res28: Array[(String, String)] = Array((auctionid,StringType), (bid,StringType), (bidtime,StringType), (bidder,StringType), (bidderrate,StringType), (openbid,StringType), (price,StringType))

>>> auctions.show(5)


///Creating DataFrame from CSV file
>>> val header = lines.first
header: val String = auctionid,bid,bidtime,bidder,bidderrate,openbid,price

>>> lines.count
res3: val Long = 1349

>>> case class Auction(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate: Int, openbid: Float, price: Float)
defined class Auction

>>> val noheader = lines.filter(_ != header)
noheader: org.apache.spark.rdd.RDD[String] = MapPartitionsRDD[53] at filter at <console>:31

//get Row 
>>> val auctions = noheader.map(_.split(",")).map(r => Auction(r(0), r(1).toFloat, r(2).toFloat, r(3), r(4).toInt, r(5).toFloat, r(6).toFloat))
auctions: org.apache.spark.rdd.RDD[Auction] = MapPartitionsRDD[59] at map at <console>:35

>>> val df = auctions.toDF
df: org.apache.spark.sql.val DataFrame = [auctionid: string, bid: float, bidtime: float, bidder: string, bidderrate: int, openbid: float, price: float]

df.show

///Creating DataFrame from CSV files using spark-csv module
//Support for CSV data sources is available by default in Spark 2.0.0. No need for an external module.

>>> val df = spark.read.format("csv").option("header", "true").load(raw"D:\Desktop\PPT\spark\data\Cartier+for+WinnersCurse.csv")
df: org.apache.spark.sql.val DataFrame = [auctionid: string, bid: string, bidtime: string, bidder: string, bidderrate: string, openbid: string, price: string]

>>> df.printSchema
>>> df.show

///Querying DataFrame
>>> auctions.groupBy("bidder").count().show(5)
>>> auctions.groupBy("bidder").count().sort($"count".desc).show(5)

import org.apache.spark.sql.functions._

>>> auctions.groupBy("bidder").count().sort(desc("count")).show(5)
>>> df.select("auctionid").distinct.count
>>> df.groupBy("bidder").count.show

///Using SQL
df.registerTempTable("auctions") 
>>> val sql = spark.sql("SELECT count(*) AS count FROM auctions")
sql: org.apache.spark.sql.val DataFrame = [count: bigint]

//before the query is executed it is optimized by Catalyst query optimizer. 
//You can print the physical plan for a DataFrame using the explain operation.
>>> sql.explain
>>> sql.show

>>> val count = sql.collect()(0).getLong(0)
count: val Long = 1348

//Filtering
auctions.filter(F.col("bidder").like("c%")).show()
auctions.filter("bidder like "c%"").show()








///***iris example 
val iris =spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\iris.csv")
iris.show(5)
>>> iris.dtypes
res109: Array[(String, String)] = Array((SepalLength,DoubleType), (SepalWidth,DoubleType), (PetalLength,DoubleType), (PetalWidth,DoubleType), (Name,StringType))

 
//Return new DF 
>>> val iris1 = iris.withColumn("sepal_ratio" , round(iris("SepalWidth") / iris("SepalLength"), 2) )
-----------+----------+-----------+----------+-----------+-----------+
SepalLength|SepalWidth|PetalLength|PetalWidth|       Name|sepal_ratio|
-----------+----------+-----------+----------+-----------+-----------+
        5.1|       3.5|        1.4|       0.2|Iris-setosa|       0.69|
        4.9|       3.0|        1.4|       0.2|Iris-setosa|       0.61|

//Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:
iris.filter("SepalLength > 5 AND SepalLength < 5.2").show()
iris.filter((col("SepalLength") > 5) && ($"SepalLength" < 5.2) ).show()
iris.filter("SepalLength.between(5.01,5.1) ).show()  #"


iris.filter("SepalLength > 5").withColumn("SepalRatio", col("SepalWidth") / iris("SepalLength")).
    withColumn("PetalRatio" , $"PetalWidth" / "PetalLength)  //"
    


//CIf ploted learly two clusters 
val iris_m =iris.filter("SepalLength > 5").withColumn("SepalRatio", col("SepalWidth") / iris("SepalLength")).
    withColumn("PetalRatio" , $"PetalWidth" / $"PetalLength")

    
    
//Quick K-Means - Find those two clusters 

import org.apache.spark.mllib.clustering.{KMeans, KMeansModel}

iris_m.select(array(round($"SepalRatio",2),round($"PetalRatio",2)).alias("features")).show()
val parsedData =iris_m.select(array(round($"SepalRatio",2), round($"PetalRatio",2)).alias("features"))
//org.apache.spark.sql.val DataFrame = [features: array<double>]

val Array(trainData, testData) = parsedData.randomSplit(Array(3.0,1.0),seed =34)

// Build the model (cluster the data), MLIB only takes LabeledPoint(label,Vector_as_features) or Vector for unsupervised learning
//Vectors.dense takes Array[Double] or var args Double 
//train(data: RDD[Vector], k: Int, maxIterations: Int, initializationMode: String)
// val k =2,maxIterations =10,initializationMode ="random"
val clusters =KMeans.train(trainData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)) , 2,10, "random")

>>> clusters.clusterCenters
res18: Array[org.apache.spark.mllib.linalg.Vector] = Array([0.6938888888888889,0.19166666666666668], [0.4597142857142855,0.3385714285714285])

val predictedRDD =clusters.predict(testData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)))
//org.apache.spark.rdd.RDD[Int]

// Evaluate clustering by computing Within Set Sum of Squared Errors
val WSSSE = clusters.computeCost(testData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)))
println(s"Within Set Sum of Squared val Errors = $WSSSE")
val WSSSE = clusters.computeCost(trainData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)))
println(s"Within Set Sum of Squared val Errors = $WSSSE")



// Save and load model
clusters.save(sc, "KMeansModel")
val sameModel =KMeansModel.load(sc, "KMeansModel")


//OR Use VectorAssembler to convert to org.apache.spark.ml.linalg.DenseVector 
//
val parsedData =iris_m.select(round($"SepalRatio",2).alias("sr"),round($"PetalRatio",2).alias("pr"))
val assembler = new VectorAssembler().setInputCols(Array("pr", "sr")).setOutputCol("features")
val out =assembler.transform(parsedData)//org.apache.spark.sql.val DataFrame = [sr: double, pr: double ... 1 more field]
val parsedRdd = out.rdd.map(row => Vectors.dense(row.getAs[org.apache.spark.ml.linalg.DenseVector ](2).toArray))





      
//Unique Name 
>>> iris.select(collect_set("Name")).collect()
res0: Array[org.apache.spark.sql.Row] = Array([WrappedArray(Iris-virginica, Iris-setosa, Iris-versicolor)])

//String proessing 
iris.select(lower(col("Name"))).show(5)

//Note sql.functions return Column, hence usage of below is wrong, Write a UDF 
//>>> iris.select(substring(col("Name"), instr(col("Name"),"-")+1, length(col("Name")))).show(5)

//To work with SQL 
spark.udf.register("get", (s:String) => s.slice(s.indexOf("-")+1, s.size))
//OR 
val get = udf((s:String) => s.slice(s.indexOf("-")+1, s.size))

iris.select(get(col("Name")).alias("nm")).show(5)

//To show in SQL , must use 
iris.createOrReplaceTempView("iris")
spark.sql("select get(Name) as nm from iris").show()





//Statistic 
val stat =iris.describe().cache() //DataFrame[summary: string, SepalLength: string, SepalWidth: string, PetalLength: string, PetalWidth: string, Name: string]
stat.show(false)  //DF 
//create only one file, else no of val files = no of partitions 
stat.coalesce(1).write.format("csv").option("header","true").save("summary")

//groupBy 
iris.groupBy("Name").agg(Map("*" -> "count", "SepalLength" -> "min")).collect()
iris.groupBy("Name").agg(count("*"), stddev($"SepalLength")).collect()

//Pivoting a particular value 
iris.select(sort_array(collect_set($"SepalLength"))).collect()
[4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9

iris.agg(countDistinct($"SepalLength")).collect()  //35 
//find each distinct values count 
val irisd = iris.withColumn("cnt", count("SepalLength).over(org.apache.spark.sql.expressions.Window.partitionBy("SepalLength))).withColumn("maps", array($"SepalLength", $"cnt"))
irisd.select($"maps").distinct.collect
es43: Array[org.apache.spark.sql.Row] = Array([WrappedArray(6.9, 4.0)], [WrappeArray(6.2, 4.0)], [WrappedArray(5.2, 4.0)], [WrappedArray(4.4, 3.0)], [WrappedA


// Compute the avg of SepalWidth for evalue of SepalLength
//note These functions takes only ColumnName 
iris.groupBy("Name").pivot("SepalLength", Seq(6.9, 6.2)).avg("SepalWidth")
res49: Array[org.apache.spark.sql.Row] = Array([Iris-virginica,3.1333333333333333,3.0999999999999996], [Iris-setosa,null,null], [Iris-versicolor,3.1,2.55])

// Or without specifying column values (less efficient)
iris.groupBy("Name").pivot("SepalLength").avg("SepalWidth").collect

//Userdefined aggregate function, to use with GroupBy 
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}


//Extend UserDefinedAggregateFunction to write custom aggregate function
    initialize 
        On a given node, this method is called once for each group.
    update
        For a given group, spark will call �update� for each input record of that group.
    merge 
        if the function supports partial aggregates, spark might (as an optimization) 
        compute partial result and combine them together
    evaluate 
        Once all the entries for a group are exhausted, 
        spark will call evaluate to get the final result.
        
   
//You can also specify any constructor arguments. For instance you 
//can have CustomMean(arg1: Int, arg2: String)
//Example val Normalize = accumulate all values , then (each-mean)/std 
//As per definition or aggergation , it can only return one Value , hence array type 
class Normalize extends UserDefinedAggregateFunction {
    def mean(x:Seq[Double]) = x.toList.reduce(_+_)/x.toList.size  
    def std(x:Seq[Double]) = scala.math.sqrt(x.toList.map(e => scala.math.pow(e-mean(x),2)).sum/x.toList.size)

    // Input Data Type Schema ie for each group, what would be Data Frame schema 
    def inputSchema: val StructType = StructType(Seq(StructField("input",DoubleType,true)))
    // Intermediate Schema
    def val bufferSchema = StructType(Seq(StructField("temp",ArrayType(DoubleType,true),true)))
    // Returned Data Type .
    def dataType: val DataType = ArrayType(DoubleType,true)
    // Self-explaining
    def val deterministic = true
    // This function is called whenever key changes
    def initialize(buffer: MutableAggregationBuffer) = {  //bufferSchema
        buffer(0) = Seq[Double]()
    }
    // Iterate over each entry of a group
    def update(buffer: MutableAggregationBuffer, input: Row) = {
        buffer(0) = buffer.getSeq[Double](0) ++ Seq(input.getDouble(0))
    }
    // Merge two partial aggregates
    def merge(buffer1: MutableAggregationBuffer, buffer2: Row) = {
        buffer1(0) = buffer1.getSeq[Double](0) ++ buffer2.getSeq[Double](0)
    }
    // Called after all the entries are exhausted.
    def evaluate(buffer: Row) = {
        val lst = buffer.getSeq[Double](0)
        val m = mean(lst)
        val s = std(lst)        
        val tr = lst.toList.map(e => (e-m)/s ).toSeq 
        //println(s"$lst  $m  $s $tr")
        tr   //return Seq because dataType is ArrayType, if dataType is StructType(ArrayType), then return Row(tr)
    }
}
//Usage 
// define UDAF
val norm = new Normalize()
spark.udf.register("norm", norm)
val q = iris.groupBy("Name).agg(norm.apply("SepalLength).alias("NormedSepalLength"))  //"
q.collect() 
q.select(explode($"NormedSepalLength").alias("SepalLength"), $"Name").show()
+--------------------+--------------+
|         SepalLength|          Name|
+--------------------+--------------+
| -0.4575141833581041|Iris-virginica|
| -1.2518096405770391|Iris-virginica|
|  0.8133585481921916|Iris-virginica|

//With sql 
spark.sql("select Name, count(*) as cnt, min(SepalLength) as min from iris group by Name order by Name").show()
spark.sql("select Name, norm(SepalLength) as NormedSepalLength from iris group by Name order by Name").show()










///HandsON 
    :Attribute Information (in order):
        - CRIM     per capita crime rate by town
        - ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
        - INDUS    proportion of non-retail business acres per town
        - CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
        - NOX      nitric oxides concentration (parts per 10 million)
        - RM       average number of rooms per dwelling
        - AGE      proportion of owner-occupied units built prior to 1940
        - DIS      weighted distances to five Boston employment centres
        - RAD      index of accessibility to radial highways
        - TAX      full-value property-tax rate per $10,000
        - PTRATIO  pupil-teacher ratio by town
        - B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
        - LSTAT    % lower status of the population
        - MEDV     Median value of owner-occupied homes in $1000s

"crim", "zn",   "indus", "chas", "nox",  "rm",  "age",  "dis",  "rad", "tax", "ptratio", "b",   "lstat","medv"
0.00632, 18,     2.31,    "0",    0.538,  6.575, 65.2,   4.09,  1,      296,   15.3,      396.9, 4.98,   24

1. read data in boston 

2. Create a column val crimxmedv = crim X medv 

3. select columns crimxmedv , tax 

4. what is the max value of crim 


5. what is max value of medv 

5. select rows of crim where medv is max 


6. select rows of medv where crim is max 


7. how many unique value in chas and rad 


8. what is max and min value of medv for each chas 


9. put crimxmedv and tax in csv 


**ANS 
1. read data in boston 
val boston = spark.read.format("csv").option("header","true"). 
  option("inferSchema","true").load("./data/spark/boston.csv")
  
2. Create a column val crimxmedv = crim X medv 
boston.withColumn("crimxmedv", F.col("crim") * F.col("medv"))

3. select columns crimxmedv , tax 
val df = boston.withColumn("crimxmedv", F.col("crim") * F.col("medv")).select("crimxmedv","tax")
   
4. what is the max value of crim 
boston.agg(F.max(F.col("crim"))).show()

val mc = boston.agg(F.max(F.col("crim"))).collect()(0)(0)

5. what is max value of medv 
boston.agg(F.max("medv")).show()
val mm = boston.agg(F.max("medv")).collect()(0)(0)

5. select rows of crim where medv is max 
boston.select("medv").where(F.col("crim") === mc ).show()

6. select rows of medv where crim is max 
boston.select("crim").where(F.col("medv") === mm).show()

7. how many unique value in chas and rad 
boston.select("chas").distinct().show()

8. what is max and min value of medv for each chas 
boston.groupBy("chas").agg(F.col("chas"), F.max(F.col("medv")).alias("max_medv"),
    F.min(F.col("medv")).alias("min_medv")).show()

9. put crimxmedv and tax in csv 
df.repartition(1).write.format("csv"). \
  option("header","true").save("./data/spark/processed")

  
  
///HandsOn- eventTime,deviceId,signal  (5188 line)
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70


1.Create Text file 
2. read text file in DF 
3. extract each column  and then "cast" to correct type with name eventTime,deviceId,signal
col1 - timestamp, column2 - string, column3-int 
4. group by deviceId and collect all signals into a list "signals"
5. select deviceId,signals, it"s size and dump into csv file "









//Ans 
1.Create Text file 
2. read text file in DF 
val device = spark.read.format("text").load("./data/spark/device.txt")
///[value: string]

3. extract each column  and then "cast" to correct type with name eventTime,deviceId,signal
col1 - timestamp, column2 - string, column3-int 
val extracted = device.withColumn("splits", F.split(F.col("value"), ",")).
  withColumn("eventTime", F.to_timestamp(F.col("splits").getItem(0))).
  withColumn("deviceId", F.col("splits").getItem(1).cast("string")).
  withColumn("signal", F.col("splits").getItem(2).cast("int")).
  select("eventTime", "deviceId","signal")
  


4. group by deviceId and collect all signals into a list "signals"
val df = extracted.groupBy("deviceId"). 
    agg(F.collect_list(F.col("signal")).alias("signals")).
    select(F.col("deviceId"), F.col("signals"), F.size(F.col("signals")).alias("size"))
    


5. select deviceId,signals, it"s size and dump into csv file "
df.repartition(1).write.format("csv").
  option("header",true).save("./data/spark/deviced-processed ")
 

 

///HandsOn - melt and pivot like pandas

import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql.types._
import org.apache.spark.sql._

//pd.melt(df, id_vars)
def melt(df:DataFrame, id_vars:Array[String], value_vars:Array[String] ,var_name:String ="variable",value_name:String ="value")={    
    // Create array<struct<variable: str, value: ...>>
    val _vars_and_vals = F.array( (value_vars.map(c => F.struct(F.lit(c).alias(var_name), F.col(c).alias(value_name)))): _*)
    // Add to the DataFrame and explode
    val _tmp = df.withColumn("_vars_and_vals", F.explode(_vars_and_vals))
    val cols = id_vars.map(x=> F.col(x)) ++ Array(var_name, value_name).map(x => F.col("_vars_and_vals")(x).alias(x) )
    _tmp.select(cols: _*)
}

def unmelt(df:DataFrame, id_vars:Array[String], value_vars:Array[String],var_name:String ="variable",value_name:String ="value")={
    val ml_g = df.groupBy(id_vars(0), id_vars.slice(1,id_vars.size):_*).agg(F.collect_list(F.struct(var_name, value_name)).alias("lst"))
    val inner = "lst."+value_name
    val all_cols = id_vars.map(x=> F.col(x)) ++ value_vars.zipWithIndex.map{case(v:String,i:Int) => F.col(inner)(i).alias(v)}
    ml_g.select( all_cols: _*)
}

    

//Usage 
context,partition,var1,var2
1,A,X,Y
2,B,X,Y
3,C,Z,L


val df = spark.read.format("csv").option("header","true").option("inferSchema","true").load("./data/spark/melt.csv")
//output 
+-------+---------+----+----+
|context|partition|var1|var2|
+-------+---------+----+----+
|      1|        A|   X|   Y|
|      2|        B|   X|   Y|
|      3|        C|   Z|   L|
+-------+---------+----+----+


val id_vars = Array( "context", "partition")
val value_vars =Array("var1", "var2")


val ml = melt(df,id_vars, value_vars)
//output 
-------+---------+--------+-----+
context|partition|variable|value|
-------+---------+--------+-----+
      1|        A|    var1|    X|
      1|        A|    var2|    Y|
      2|        B|    var1|    X|
      2|        B|    var2|    Y|
      3|        C|    var1|    Z|
      3|        C|    var2|    L|
-------+---------+--------+-----+

unmelt(ml, id_vars, value_vars).show()   
//output 
+-------+---------+----+----+
|context|partition|var1|var2|
+-------+---------+----+----+
|      2|        B|   X|   Y|
|      3|        C|   Z|   L|
|      1|        A|   X|   Y|
+-------+---------+----+----+




///handsOn - Check stack function 
//https://people.apache.org/~pwendell/spark-nightly/spark-master-docs/latest/api/sql///stack
//stack(n, expr1, ..., exprk) - Separates expr1, ..., exprk into n rows.

> SELECT stack(2, 1, 2, 3);
 1  2
 3  NULL

//scala
val df = sc.parallelize( ("G",Some(4),2,None)::("H",None,4,Some(5))::Nil).toDF("A","X","Y","Z")
df.show()
+---+----+---+----+
|  A|   X|  Y|   Z|
+---+----+---+----+
|  G|   4|  2|null|
|  H|null|  4|   5|
+---+----+---+----+

df.selectExpr("A", """stack(3, "X", X, "Y", Y, "Z", Z) as (B, C)""").where("C is not null").show()
+---+---+---+
|  A|  B|  C|
+---+---+---+
|  G|  X|  4|
|  G|  Y|  2|
|  H|  Y|  4|
|  H|  Z|  5|
+---+---+---+


 
_______________________________________________________________________________________________

 
///*** Spark and JSON Datasets


// A JSON dataset is pointed to by path.
// The path can be either a single text file or a directory storing text files
val path = "./data/spark/people.json"
val peopleDF = spark.read.json(path)

val jsonStrings = Array( """{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}""" )
val otherPeopleRDD = sc.parallelize(jsonStrings)
val otherPeople = spark.read.json(otherPeopleRDD)
otherPeople.show()


//Complete example 
//JSON Lines (newline-delimited JSON) is supported by default. 
//For JSON (one record per file), set the multiLine parameter to true.
//If the schema parameter is not specified, 
//this function goes through the input once to determine the input schema
//put rec*.json to input-json

val df = spark.read.
  format("json").option("multiLine", "true").
  load("data/spark/input-json")
  
val schema = df.schema

//spread one record by * 
df.select(F.col("empId"), F.col("details.phoneNumbers")(0).alias("phs")).
   select("empId", "phs.*").show()
  
//or only office phone 
df.select(F.col("empId"), F.col("details.phoneNumbers.number")(1).alias("phs"))

//OR Explode 
df.select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs")).
   select("empId", "phs.*").show()
//empId|      number|  type
df.select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs")).
   select("empId", "phs.*").where("type == 'office'").select("empId", "number").
   repartition(1).write.
   format("csv").mode("overwrite").
   save("data/spark/output-csv-from_json")

  

  

  
//With Structured Streaming feature 

val schema = df.schema  //from above 

import scala.concurrent.duration._
import org.apache.spark.sql.streaming._

//schema is must , not without groupBy , "complete" is not allowed as state requirement is high 
val q1 = spark.readStream.
  format("json").
  schema(schema).option("multiLine", "true").
  load("data/spark/input-json").
  select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs")).
  select("empId", "phs.*").where("type == 'office'").select("empId", "number").
  writeStream.
  outputMode("append").
  trigger(Trigger.ProcessingTime(10.seconds)).
  format("console").
  start()

//  
val q2 = spark.readStream.
   format("json").
   schema(schema).option("multiLine", "true").
   load("data/spark/input-json").
   select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs")).
   select("empId", "phs.*").where("type == 'office'").select("empId", "number").
   groupBy("empId").agg(F.first("number").alias("first_office_number")).
   writeStream.
   outputMode("complete").
   trigger(Trigger.ProcessingTime(10.seconds)).
   format("console").
   start()

val q1 = spark.readStream.format("json").
      schema(schema).option("multiLine", "true").
      load("./data/spark/input-json").
      select(F.col("empId"), F.explode(F.col("details.phoneNumbers")).alias("phs")).
      select("empId", "phs.*").
      where("type == 'office'").select("empId", "number").
      writeStream.
      outputMode("append").
      format("csv").
      trigger(Trigger.ProcessingTime(10.seconds)).
      option("checkpointLocation", "./stream_1").
      start("./data/spark/out_csv_from_json_stream") 
  
spark.streams.active.map(q => q.stop)
  
  
  
  
///*** Parquet Files and spark 

//Parquet is a columnar format that is supported by many other data processing systems
//default format is parquet in spark when none mentioned 
val peopleDF = spark.read.json("./data/spark/people.json")

// DataFrames can be saved as Parquet files, maintaining the schema information.
peopleDF.write.mode("overwrite").parquet("./data/spark/people.parquet")

// Read in the Parquet file created above.
// Parquet files are self-describing so the schema is preserved.
// The result of loading a parquet file is also a DataFrame.
val parquetFile = spark.read.parquet("./data/spark/people.parquet")

// Parquet files can also be used to create a temporary view and then used in SQL statements.
parquetFile.createOrReplaceTempView("parquetFile")
val teenagers = spark.sql("SELECT name FROM parquetFile WHERE age >= 13 AND age <= 19")
teenagers.show()
// +------+
// |  name|
// +------+
// |Justin|
// +------+

  




  
///Spark - Parquet - Schema Merging
//Like ProtocolBuffer, Avro, and Thrift, Parquet also supports schema evolution. 
//Users can start with a simple schema, and gradually add more columns to the schema as needed. 


// spark is from the previous example.
// Create a simple DataFrame, stored into a partition directory
val sc = spark.sparkContext

val squaresDF = sc.parallelize(1 to 6).map(i => (i,i*i)).toDF("single", "double")
squaresDF.write.mode("overwrite").parquet("data/spark/test_table/key=1")

// Create another DataFrame in a new partition directory,
// adding a new column and dropping an existing column
val cubesDF = sc.parallelize(6 to 11).map(i => (i,i*i*i)).toDF("single", "triple")
cubesDF.write.mode("overwrite").parquet("data/spark/test_table/key=2")

// Read the partitioned table
val mergedDF = spark.read.option("mergeSchema", "true").parquet("data/spark/test_table")
mergedDF.printSchema()









///Parquet 
//data 
//https://docs.snowflake.net/manuals/user-guide/sample-data-tpcds.html
git clone https://github.com/Teradata/tpcds.git
cd tp*
mvn package -DskipTests -Dmaven.test.skip=true

If you wanted to generate just the call_center table at a scale of 10MB(default=1GB), you would run
header info missing, add it seperately
$ java -jar tpcds-1.3-SNAPSHOT-jar-with-dependencies.jar --do-not-terminate --suffix .csv  --table store_sales --scale 0.001

//Parquet 1.10.1 
Download https://mvnrepository.com/artifact/org.apache.parquet/parquet-tools/1.10.1
Usage 
$ hadoop jar parquet-tools-1.10.1.jar meta store_sales/ss_sold_date_sk=2452621/part-00077-57653b27-17f1-4069-85f2-7d7adf7ab7df.snappy.parquet

sparkMeasure 
$ spark-shell --packages ch.cern.sparkmeasure:spark-measure_2.11:0.15 //0.11 works

val stageMetrics = ch.cern.sparkmeasure.StageMetrics(spark)
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_sales_price=-1").collect())
stageMetrics.printAccumulables


//code
import spark.implicits._ 

spark.read.format("csv").option("sep", "|").option("inferSchema", true).option("header", true).load("data/spark/store_sales.csv").
  repartition($"ss_sold_date_sk").write.
  partitionBy("ss_sold_date_sk").mode("overwrite").
  parquet("data/spark/store_sales")
  
val df_raw = spark.read.
          format("parquet").
          load("data/spark/store_sales") //1784 tasks as there are 1784 parquet partition 
          
//convert one(eg ss_sales_price) to Decimal 
import org.apache.spark.sql.types._ 
val df = df_raw.withColumn("ss_sales_price", $"ss_sales_price" cast(DecimalType(7,2)))
    
df.createOrReplaceTempView("store_sales")

Baseline 
// query (1), this is a full scan of the table store_sales
//ss_sales_price can never be -1, so full table scan 
spark.sql("select * from store_sales where ss_sales_price=-1.0").collect()
//56 memory partitions 
val stageMetrics = ch.cern.sparkmeasure.StageMetrics(spark)
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_sales_price=-1.0").collect())


Here are the key metrics from stage aggregated performance metrics from the Spark Web UI 
Aggregated Metrics by Executor
Executor ID  	Address 	Task Time 	Total Tasks 	Failed Tasks 	Killed Tasks 	Succeeded Tasks 	Input Size / Records 	Blacklisted
driver
	Home-E402:35310 	26 s 	56 	0 	0 	56 	17.2 MB / 0 	false
//OR sparkMeasure 
> stageMetrics.printAccumulables
executorCpuTime => 18921 (19 s)
executorDeserializeCpuTime => 109 (0.1 s)
executorDeserializeTime => 204 (0.2 s)
executorRunTime => 58732 (59 s)
input.bytesRead => 37472475 (35.0 MB)
input.recordsRead => 120527
jvmGCTime => 873 (0.9 s)
resultSize => 83150 (81.0 KB)
duration total => 58476 (58 s)
number of output rows => 120527
scan time total => 58189 (58 s)



Partition pruning(containing partition key in where clause)
// query (2), example of partition pruning
spark.sql("select * from store_sales where ss_sold_date_sk=2452455 and ss_sales_price=-1.0").collect()
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_sold_date_sk=2452455 and ss_sales_price=-1.0").collect())
stageMetrics.printAccumulables


executorCpuTime => 15 (15 ms)
executorRunTime => 16 (16 ms)
input.bytesRead => 10324 (10.0 KB)
resultSize => 1385 (1385 Bytes)
duration total => 9 (9 ms)
scan time total => 8 (8 ms) 



Column projection(read only few columns)
spark.sql("desc store_sales").show(50)
+--------------------+------------+-------+
|            col_name|   data_type|comment|
+--------------------+------------+-------+
|     ss_sold_time_sk|         int|   null|
|          ss_item_sk|         int|   null|


// query (3), an example of column pruning
spark.sql("select ss_sold_date_sk, ss_item_sk, ss_list_price from store_sales where ss_sales_price=-1.0").collect()
stageMetrics.runAndMeasure(spark.sql("select ss_sold_date_sk, ss_item_sk, ss_list_price from store_sales where ss_sales_price=-1.0").collect())
stageMetrics.printAccumulables
//Faster than baseline query 
executorCpuTime => 12703 (13 s)
executorDeserializeCpuTime => 93 (93 ms
executorDeserializeTime => 126 (0.1 s)
executorRunTime => 18767 (19 s)
input.bytesRead => 37353839 (35.0 MB)
input.recordsRead => 120527
jvmGCTime => 380 (0.4 s)
resultSize => 81602 (79.0 KB)
duration total => 18704 (19 s)
number of output rows => 120527
scan time total => 18618 (19 s)

    
 
Predicate push down

Spark can push the filter to Parquet and Parquet can evaluate it against its metadata. 
As a consequence Spark and Parquet can skip performing I/O on data altogether 
with an important reduction in the workload and increase in performance. 

predicates on column of type DECIMAL are not pushed down, 
while INT (integer) values are pushed down
operators that can be pushed down are "= <, <=, > , >=" (check ParquetFilters.scala )

To be more accurate the granularity at which Parquet stores metadata that can be used 
for predicate push down is called "row group" and is a subset of Parquet files. 
Hierarchically, a Parquet file consists of one or more "row groups". 
A row group contains data grouped ion "column chunks", one per column. 
Column chunks are structured in pages. 
Each column chunk contains one or more pages.
Parquet files have several metadata structures, containing among others the schema, 
the list of columns and details about the data stored there, 
such as name and datatype of the columns, their size, number of records 
and basic statistics as minimum and maximum value 

// query (4), example of predicate push down
spark.sql("select * from store_sales where ss_quantity=-1").collect()
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_quantity=-1").collect())
stageMetrics.printAccumulables

//faster than baseline 
executorCpuTime => 13078 (13 s)
executorDeserializeCpuTime => 46 (46 ms)
executorDeserializeTime => 126 (0.1 s)
executorRunTime => 17968 (18 s)
input.bytesRead => 18031716 (17.0 MB)
jvmGCTime => 580 (0.6 s)
resultSize => 79280 (77.0 KB)
duration total => 17796 (18 s)
scan time total => 17780 (18 s)
    
spark.sql("select * from store_sales where ss_quantity=-1").explain(extended=true)    
//checked for PushedFilters: [IsNotNull(ss_quantity), EqualTo(ss_quantity,-1)]
         
//Here also PushedFilters: [IsNotNull(ss_sales_price)], but DECIMAL          
spark.sql("select * from store_sales where ss_sales_price=-1.0").explain(extended=true)        
               
    





                 
                 
                 
    
///*** Spark and Hive
//Either no external support ie no hive-site.xml in spark/conf 
//or a hive-site.xml in spark/conf 

//Example 
val warehouseLocation = "spark-warehouse" //should match to location of HDFS hive , hive-site.xml's hive.metastore.warehouse.dir

val spark = SparkSession.\
  builder.\
  appName("Spark Hive Example").master("local[*]").\
  config("spark.sql.warehouse.dir", warehouseLocation).\
  config("hive.warehouse.subdir.inherit.perms", False).  \
  config("hive.exec.dynamic.partition", "true").\
  config("hive.exec.dynamic.partition.mode", "nonstrict").\
  config("spark.sql.sources.partitionOverwriteMode", "dynamic").  \
  enableHiveSupport().\
  getOrCreate()
  
///chgrp does not match expected pattern for group 
spark.conf.set("hive.warehouse.subdir.inherit.perms", false)
//Spark either OVERWRITEs all partitions or appends to the partitions
//to support overwrite only affected partition (like Hive) use  
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
//When partition key is variable ie dynamic 
spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")

//Note, spark uses Default:1.2.1 HIVE
//if external HIVE lib is in classpath and/or hive-site.xml in classpath(The default configuration uses Hive 1.2.1 with the default warehouse in  spark.sql.warehouse.dir)
//those would be used instead of builtin hive lib or configuration 
//in that case set spark.sql.hive.metastore.version to External HIVE version 
//and spark.sql.hive.metastore.jars  to locaton of all HIVE jars, depedendencies, etc 
//check https://github.com/apache/spark/blob/master/sql/hive/src/main/scala/org/apache/spark/sql/hive/HiveUtils.scala


//Then it uses Metastore RDBMS configured in hive-site.xml 
//or by default, it uses file based derby rdbms with ./metastore_db dir 

//it uses hive.metastore.warehouse.dir(default  /user/hive/warehouse) from hive-site.sml for actual HDFS storge for hive data 
//and sets that to spark.sql.warehouse.dir, else spark.sql.warehouse.dir(default ./spark-warehouse) is the spark storage for spark-SQL data 

//Note HIVE paraquet and SPARk SQL paraquet SerDe are different 
//to make it same , use spark.sql.hive.convertMetastoreParquet  as false

//check - create table syntax 
//https://docs.databricks.com/spark/latest/spark-sql/language-manual/create-table.html

//managed means droping table => drop data, external means = drop table => does not drop data, only drops metastore data 
//spark dataframe column name/type and Hive table column name/type must be exactly same for interoperability
spark-SQL 
    'using HIVE' as data source for Hive Table 
    Has TEMPORAY table (session scoped) Also has temporary View 
    Has managed (default), external (when LOCATION is set) table (note no external key word)
    Can use AS <select_statement> for populating table (but donot mention column name)(and can not be used with TEMPORARY, use TEMPORARY view instead)
    Has PARTITIONED BY (COL) for creating partition(as subdir struture) based on COL 
    Has CLUSTERED BY (COL) INTO n  - Each partition is  split into n buckets by COL 
    USING <data source> - TEXT, CSV, JSON, JDBC, PARQUET, ORC, HIVE, and LIBSVM
    Use spark.sql.sources.partitionOverwriteMode as "dynamic" to only overwrite required partition, else by default whole data would be overwritten 
    Note USING HIVE takes many options which complements HIVEQL syntax 
    eg fileFormat for STORED AS 
    CREATE TABLE src(id int) USING hive OPTIONS(fileFormat ="parquet", ) 
    eg with "textfile" fileFormat, use fieldDelim, escapeDelim, collectionDelim, mapkeyDelim, lineDelim
HIVEQL 
    STORED AS  - for format, could be TEXTFILE, SEQUENCEFILE, RCFILE, ORC, PARQUET, and AVRO
    No TEMPORARY table or VIEW 
    Has managed (default), EXTERNAL (when LOCATION is set) table (Has EXTERNAL keyword)
    has PARTITIONED BY (COL)  (no cluster by) 
    Can use AS <select_statement> for populating table (but donot mention column name)
    has ROW FORMAT SERDE ... or ROW FORMAT DELIMITED FIELDS TERMINATED BY "one_char" only with TEXTFILE
    By default only overwrites required partition 
    For tables in Hive, where partitioned data already exists in S3 or HDFS, 
    run below command to update the Hive Metastore with the tables partition structure
    spark.sql("MSCK REPAIR TABLE hive_part_tbl")

//Note Spark uses own parquet SerDe for performance reason  and converts Hive to own Serde , 
//check more https://spark.apache.org/docs/latest/sql-programming-guide.html//hiveparquet-schema-reconciliation
//OR disbale by   spark.sql.hive.convertMetastoreParquet  as false (default true)

//Table partitioning - stored as dir with partition key 
//partition discovery only finds partitions under the given paths by default. 
//or set basePath along with path arg to a keyed dir 

//WHile INSERT INTO TABLE or INSERT OVERWRITE TABLE(for only required partition overwrite)
//PARTITION (COL =value, COL =value) , value can be literal only 
//if value needs to be variable, use hive.exec.dynamic.partition", "true" and "hive.exec.dynamic.partition.mode", "nonstrict"
//DF equivalent is df.write.partitionBy(columnVar)


//Example - Note spark-shell automatically does enableHiveSupport
>>> spark.conf.get("spark.sql.catalogImplementation")
"hive"
     

 
 
 
 
///SparkSQL 
//For syntax, check : https://docs.databricks.com/spark/latest/spark-sql/index.html



///SQL parameters 
spark.sql("set -v").show(200,truncate=false)
spark.sql("set -v").select(F.col("key"),F.col("value")).show(200,truncate=false) ///"
spark.sql("set -v").select(F.col("key"),F.col("value")).count()  
///SQL functions 
spark.sql("show all functions").show(200,truncate=false)
spark.sql("show all functions").count()

spark.sql("desc function explode").show(truncate=false)
spark.sql("desc database default").show(truncate=false)
spark.sql("show  functions like 'r.+'").show(200,truncate=false) ///regex 



///Table Examples 
spark.conf.get("spark.sql.warehouse.dir")

//When using other file system other than hdfs, users see warning message regarding hdfs chgrp

spark.sql("CREATE TABLE IF NOT EXISTS src (key INT, value STRING)")
///load data is only for Hive table 
spark.sql("LOAD DATA LOCAL INPATH './data/spark/kv1.txt' INTO TABLE src")

/// Queries are expressed in HiveQL
spark.sql("SELECT * FROM src").show()

/// Aggregation queries are also supported.
spark.sql("SELECT COUNT(*) FROM src").show()

/// The results of SQL queries are themselves DataFrames and support all normal functions.
val sqlDF = spark.sql("SELECT key, value FROM src WHERE key < 10 ORDER BY key")


/// You can also use DataFrames to create temporary views within a SparkSession.
case class Record(key:Int, value:String)
val recordsDF = sc.parallelize( (1 to 100).toList.map(i => Record(i, "val_"+i))).toDF()
recordsDF.createOrReplaceTempView("records")

/// Queries can then join DataFrame data with data stored in Hive.
spark.sql("SELECT * FROM records r JOIN src s ON r.key = s.key").show()


// Create a Hive managed Parquet table
// Using HIVE-QL , Note spark DF column name and Hive table column name must be exactly same 
spark.sql("CREATE TABLE hive_records(key int, value string) STORED AS PARQUET")
// Save DataFrame to the Hive managed table
val df = spark.table("src")
df.write.mode("overwrite").saveAsTable("hive_records")
// After insertion, the Hive managed table has data now
spark.sql("SELECT * FROM hive_records").show()


//Using same location in Spark-QL and Hive-QL 
// Prepare a Parquet data directory
val dataDir = "data/spark/parquet_data"
spark.range(10).write.mode("overwrite").parquet(dataDir)
val par_df = spark.read.parquet(dataDir)
par_df.show()

// Create a Hive external Parquet table
spark.sql("DROP TABLE IF EXISTS hive_ints")
spark.catalog.listTables.collect()

//if true, spark uses own Hive Serde and converts between hive and spark 
spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")
//NOte, column name in HIve paraquet has to be same (case sensitive) as spark dataframe 
spark.sql(s"CREATE  EXTERNAL TABLE hive_ints(id bigint) STORED AS PARQUET LOCATION '$dataDir'" )
spark.catalog.refreshTable("hive_ints")


// The Hive external table should already have data
spark.sql("SELECT * FROM hive_ints").show()


// Turn on flag for Hive Dynamic Partitioning
spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
// Create a Hive partitioned table using DataFrame API
spark.sql("DROP TABLE IF EXISTS hive_part_tbl")
df.write.partitionBy("key").format("hive").saveAsTable("hive_part_tbl")

//For tables in Hive, where partitioned data already exists in S3 or HDFS, 
//run below command to update the Hive Metastore with the table"s partition structure
spark.sql("MSCK REPAIR TABLE hive_part_tbl")

// Partitioned column `key` will be moved to the end of the schema.
spark.sql("SELECT * FROM hive_part_tbl").show()


///new DB 
spark.sql("CREATE DATABASE IF NOT EXISTS new_db ")
spark.sql("USE new_db")

///For reading only as insert into requires hdfs like file structure 
spark.sql("""CREATE TABLE IF NOT EXISTS v1 (name STRING, age INT) 
           USING csv 
           OPTIONS ("path"="./data/spark/people.csv", "inferSchema"="true", "header"="true")""")
           
///Queries are expressed in HiveQL
spark.sql("FROM new_db.v1").show(truncate =False)

spark.sql("desc EXTENDED v1").show(truncate =False)

///Insert into 
spark.sql("""CREATE TABLE IF NOT EXISTS v3 (name STRING, age INT) 
           USING csv""")
 
spark.sql("""INSERT INTO v3  SELECT * FROM v1""")
spark.sql("""INSERT INTO v3 VALUES ("NEW1",20), ("NEW1",30)""")
spark.sql("select * from v3").show()

///json 
spark.sql("""CREATE OR REPLACE TEMPORARY VIEW v2 (name STRING, age INT) 
           USING json 
           OPTIONS ("path"="data/spark/people.json", "inferSchema"="true")""")
spark.sql("select * from v2").show()
spark.sql("desc EXTENDED v2").show(truncate =False)          
spark.sql("""INSERT INTO v3  SELECT * FROM v2""")
spark.sql("select * from v3").show()

///With partition - Partioned By should include any columns defined in table 
spark.sql("DROP TABLE IF EXISTS v4")
spark.sql("""CREATE TABLE IF NOT EXISTS v4 (name STRING, age INT) 
           USING csv PARTITIONED BY (name)""")
           
///Note v4 has two columns including partitioned by 
spark.sql("INSERT INTO v4 PARTITION(name ="NEW1") VALUES (20), (30)")   
spark.sql("select * from v4").show()   

///conf:dynamic should be on , either through config() or 
spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
  
spark.sql("INSERT INTO v4  PARTITION(name) SELECT age, name FROM v1")      
///age,name must be explicit , not * as partitioned column should be last    
spark.sql("INSERT INTO v4  PARTITION(name) SELECT age,name FROM v2")   
///check 
val df = spark.sql("SELECT age, name FROM v1")
///only one record for any number of update of same record 
df.write.mode("overwrite").insertInto("v4") ///not to be used with Partitionby 
///or append 
df.write.mode("append").insertInto("v4")
spark.sql("select * from v4").show()  

///catalogs 
spark.catalog.currentDatabase
spark.catalog.databaseExists("new_db")
spark.catalog.listColumns("new_db", "v1")
spark.catalog.listDatabases().show()
spark.catalog.listFunctions("new_db").show(200,truncate=false)
spark.catalog.listFunctions()
spark.catalog.listTables("new_db").show()
spark.catalog.listTables().show()  




///Hands ON Example ,
// start hdfs by  " start-dfs " and stop by "stop-dfs"
//External Table , does not drop table when deleted , creates files under /data   
spark.sql("""CREATE TABLE boxes (width INT, length INT, height INT) USING CSV
    OPTIONS ("path"="data/spark/boxes.csv", "header"="true") PARTITIONED BY (width, length)""")


//insert 
spark.sql("""INSERT INTO boxes PARTITION (width = 3,length = 4)
  SELECT id FROM RANGE(1, 3)""")
  
spark.sql("""INSERT INTO boxes PARTITION (width = 4,length = 3)
  VALUES (7), (8)""")
  
//Create another table 
spark.sql("""CREATE TABLE rectangles
    USING PARQUET
    OPTIONS ("path"="data/spark/rectangles.PARQUET")
    PARTITIONED BY (width)
    CLUSTERED BY (length) INTO 8 buckets
    AS SELECT * FROM boxes  """)
    
//If hdfs 
$ hdfs dfs -cat "/data/sql/boxes.csv/val width =3/val length =4/*"
//or 
$ hdfs dfs -cat "hdfs://localhost:19000/data/sql/boxes.csv/val width =3/val length =4/*"
height
1
height
2
    

//Example - Basic select 
>>> spark.sql("SELECT * FROM boxes").show(truncate =false)
+------+-----+------+
|height|width|length|
+------+-----+------+
|7     |4    |3     |
|8     |4    |3     |
|1     |3    |4     |
|2     |3    |4     |
+------+-----+------+

//More examples 
//in code, below select return DF, hence do .show(truncate =False)
spark.sql("SELECT width, length FROM boxes WHERE height=7").show(truncate =false)
spark.sql("SELECT DISTINCT width, length FROM boxes WHERE height=7 LIMIT 2").show(truncate =false)
spark.sql("SELECT * FROM VALUES (1, 2, 3) AS (width, length, height)").show(truncate =false)
spark.sql("SELECT * FROM VALUES (1, 2, 3), (2, 3, 4) AS (width, length, height)").show(truncate =false)
spark.sql("SELECT * FROM boxes ORDER BY width").show(truncate =false)
spark.sql("SELECT * FROM boxes DISTRIBUTE BY width SORT BY width").show(truncate =false)
spark.sql("SELECT * FROM boxes CLUSTER BY length").show(truncate =false)

//Samplings 
spark.sql("SELECT * FROM boxes TABLESAMPLE (3 ROWS)").show(truncate =false)
spark.sql("SELECT * FROM boxes TABLESAMPLE (25 PERCENT)").show(truncate =false)

//Joins
spark.sql("SELECT * FROM boxes INNER JOIN rectangles ON boxes.width = rectangles.width").show(truncate =false)
spark.sql("SELECT * FROM boxes FULL OUTER JOIN rectangles USING (width, length)").show(truncate =false)
spark.sql("SELECT * FROM boxes NATURAL JOIN rectangles").show(truncate =false)

//Lateral View
//Generate zero or more output rows for each input row using a table-generating function. 
//The most common built-in function used with LATERAL VIEW is explode.
spark.sql("SELECT * FROM boxes LATERAL VIEW explode(Array(1, 2, 3)) my_view").show(truncate =false)
spark.sql("SELECT name, my_view.grade FROM students LATERAL VIEW OUTER explode(grades) my_view AS grade").show(truncate =false)

///Aggregation
ROLLUP
    Create a grouping set at each hierarchical level of the specified expressions. 
    For instance, For instance, GROUP BY a, b, c WITH ROLLUP is equivalent to GROUP BY a, b, c GROUPING SETS ((a, b, c), (a, b), (a), ()).
    The total number of grouping sets will be N + 1, where N is the number of group expressions.
CUBE
    Create a grouping set for each possible combination of set of the specified expressions. 
    For instance, GROUP BY a, b, c WITH CUBE is equivalent to GROUP BY a, b, c GROUPING SETS ((a, b, c), (a, b), (b, c), (a, c), (a), (b), (c), ()). 
    The total number of grouping sets will be 2^N, where N is the number of group expressions.
GROUPING SETS
    Perform a group by for each subset of the group expressions specified in the grouping sets. 
    For instance, GROUP BY x, y GROUPING SETS (x, y) is equivalent to the result of GROUP BY x unioned with that of GROUP BY y.

spark.sql("SELECT height, COUNT(*) AS num_rows FROM boxes GROUP BY height").show(truncate =false)
spark.sql("SELECT width, AVG(length) AS average_length FROM boxes GROUP BY width").show(truncate =false)
spark.sql("SELECT width, length, height FROM boxes GROUP BY width, length, height WITH ROLLUP").show(truncate =false)
spark.sql("SELECT width, length, avg(height) FROM boxes GROUP BY width, length GROUPING SETS (width, length)").show(truncate =false)








///***Spark and  Avro - data serialization system
//Can use backend as Hive 

//using command ine - 
$ bin/spark-submit  --packages com.databricks:spark-avro_2.11:4.0.0
$ spark-shell   --packages com.databricks:spark-avro_2.11:4.0.0


//Example schema - Json notation 
//user.avsc 
{"namespace": "example.avro",
 "type": "record",
 "name": "User",
 "fields": [
     {"name": "name", "type": "string"},
     {"name": "favorite_color", "type": ["string", "null"]},
     {"name": "favorite_numbers", "type": {"type": "array", "items": "int"}}
 ]
}

             

///Hive vs Avro vs Parquet vs ORC comparison 
http://stat-computing.org/dataexpo/2009/the-data.html
The compressed bz2 download measures at 108.5 Mb, and uncompressed at 657.5 

//external means data would not be dropped when dropping metadata 
//make partition=Year,Month,DayofMonth
//flight_arrivals should be directory containing txt file 
spark.sql(
"""
Create external table flight_arrivals (
year               int,
month              int,
DayofMonth         int,
DayOfWeek          int,
DepTime            int,
CRSDepTime         int,
ArrTime            int,
CRSArrTime         int,
UniqueCarrier      string,
FlightNum          int,
TailNum            string,
ActualElapsedTime  int,
CRSElapsedTime     int,
AirTime            int,
ArrDelay           int,
DepDelay           int,
Origin             string,
Dest               string,
Distance           int,
TaxiIn             int,
TaxiOut            int,
Cancelled          int,
CancellationCode   int,
Diverted           int,
CarrierDelay       string,
WeatherDelay       string,
NASDelay           string,
SecurityDelay      string,
LateAircraftDelay  string
) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
location 'data/spark/flight_arrivals'
""")

spark.sql("select count(*) from flight_arrivals").collect
//70000


//Converting to an ORC and Parquet and avro managed table, using default settings for both formats:
spark.sql("create table flight_arrivals_orc stored as ORC as select * from flight_arrivals")
spark.sql("create table flight_arrivals_parquet stored as Parquet as select * from flight_arrivals")
spark.sql("create table flight_arrivals_avro stored as avro as select * from flight_arrivals")
//hive 
//spark.sql("create table flight_arrivals_hive stored as hive as select * from flight_arrivals")
spark.read.table("flight_arrivals").write.format("hive").saveAsTable("flight_arrivals_hive")


//Lets have a look at the disk usage for both:

1.25 M   spark-warehouse/flight_arrivals_orc
1.01 M   spark-warehouse/flight_arrivals_parquet
6.01 M   spark-warehouse/flight_arrivals_avro
6.66 M   spark-warehouse/flight_arrivals_hive

//Query 
def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0).toDouble/10e9 + " secs")
    result
}

time(spark.sql("select count(*) from flight_arrivals").collect)
//0.0327917529 secs
time(spark.sql("select count(*) from flight_arrivals_orc").collect)
//0.0198595686 secs
time(spark.sql("select count(*) from flight_arrivals_parquet").collect)
//0.0744379274 secs
time(spark.sql("select count(*) from flight_arrivals_avro").collect)
//0.2932839871 secs
time(spark.sql("select count(*) from flight_arrivals_hive").collect)
//0.0391906782 secs
               
               
               
///Parquet 
//data 
//https://docs.snowflake.net/manuals/user-guide/sample-data-tpcds.html
git clone https://github.com/Teradata/tpcds.git
cd tp*
mvn package -DskipTests -Dmaven.test.skip=true

If you wanted to generate just the call_center table at a scale of 10MB(default=1GB), you would run
header info missing, add it seperately
$ java -jar tpcds-1.3-SNAPSHOT-jar-with-dependencies.jar --do-not-terminate --suffix .csv  --table store_sales --scale 0.001

//Parquet 1.10.1 
Download https://mvnrepository.com/artifact/org.apache.parquet/parquet-tools/1.10.1
Usage 
$ hadoop jar parquet-tools-1.10.1.jar meta store_sales/ss_sold_date_sk=2452621/part-00077-57653b27-17f1-4069-85f2-7d7adf7ab7df.snappy.parquet

sparkMeasure 
$ spark-shell --packages ch.cern.sparkmeasure:spark-measure_2.11:0.15 //0.11 works

val stageMetrics = ch.cern.sparkmeasure.StageMetrics(spark)
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_sales_price=-1").collect())
stageMetrics.printAccumulables


//code
import spark.implicits._ 

spark.read.format("csv").option("sep", "|").option("inferSchema", true).option("header", true).load("data/spark/store_sales.csv").
  repartition($"ss_sold_date_sk").write.
  partitionBy("ss_sold_date_sk").mode("overwrite").
  parquet("data/spark/store_sales")
  
val df_raw = spark.read.
          format("parquet").
          load("data/spark/store_sales") //1784 tasks as there are 1784 parquet partition 
          
//convert one(eg ss_sales_price) to Decimal 
import org.apache.spark.sql.types._ 
val df = df_raw.withColumn("ss_sales_price", $"ss_sales_price" cast(DecimalType(7,2)))
    
df.createOrReplaceTempView("store_sales")

Baseline 
// query (1), this is a full scan of the table store_sales
//ss_sales_price can never be -1, so full table scan 
spark.sql("select * from store_sales where ss_sales_price=-1.0").collect()
//56 memory partitions 
val stageMetrics = ch.cern.sparkmeasure.StageMetrics(spark)
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_sales_price=-1.0").collect())


Here are the key metrics from stage aggregated performance metrics from the Spark Web UI 
Aggregated Metrics by Executor
Executor ID  	Address 	Task Time 	Total Tasks 	Failed Tasks 	Killed Tasks 	Succeeded Tasks 	Input Size / Records 	Blacklisted
driver
	Home-E402:35310 	26 s 	56 	0 	0 	56 	17.2 MB / 0 	false
//OR sparkMeasure 
> stageMetrics.printAccumulables
executorCpuTime => 18921 (19 s)
executorDeserializeCpuTime => 109 (0.1 s)
executorDeserializeTime => 204 (0.2 s)
executorRunTime => 58732 (59 s)
input.bytesRead => 37472475 (35.0 MB)
input.recordsRead => 120527
jvmGCTime => 873 (0.9 s)
resultSize => 83150 (81.0 KB)
duration total => 58476 (58 s)
number of output rows => 120527
scan time total => 58189 (58 s)



Partition pruning(containing partition key in where clause)
// query (2), example of partition pruning
spark.sql("select * from store_sales where ss_sold_date_sk=2452455 and ss_sales_price=-1.0").collect()
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_sold_date_sk=2452455 and ss_sales_price=-1.0").collect())
stageMetrics.printAccumulables


executorCpuTime => 15 (15 ms)
executorRunTime => 16 (16 ms)
input.bytesRead => 10324 (10.0 KB)
resultSize => 1385 (1385 Bytes)
duration total => 9 (9 ms)
scan time total => 8 (8 ms) 



Column projection(read only few columns)
spark.sql("desc store_sales").show(50)
+--------------------+------------+-------+
|            col_name|   data_type|comment|
+--------------------+------------+-------+
|     ss_sold_time_sk|         int|   null|
|          ss_item_sk|         int|   null|


// query (3), an example of column pruning
spark.sql("select ss_sold_date_sk, ss_item_sk, ss_list_price from store_sales where ss_sales_price=-1.0").collect()
stageMetrics.runAndMeasure(spark.sql("select ss_sold_date_sk, ss_item_sk, ss_list_price from store_sales where ss_sales_price=-1.0").collect())
stageMetrics.printAccumulables
//Faster than baseline query 
executorCpuTime => 12703 (13 s)
executorDeserializeCpuTime => 93 (93 ms
executorDeserializeTime => 126 (0.1 s)
executorRunTime => 18767 (19 s)
input.bytesRead => 37353839 (35.0 MB)
input.recordsRead => 120527
jvmGCTime => 380 (0.4 s)
resultSize => 81602 (79.0 KB)
duration total => 18704 (19 s)
number of output rows => 120527
scan time total => 18618 (19 s)

    
 
Predicate push down

Spark can push the filter to Parquet and Parquet can evaluate it against its metadata. 
As a consequence Spark and Parquet can skip performing I/O on data altogether 
with an important reduction in the workload and increase in performance. 

predicates on column of type DECIMAL are not pushed down, 
while INT (integer) values are pushed down
operators that can be pushed down are "= <, <=, > , >=" (check ParquetFilters.scala )

To be more accurate the granularity at which Parquet stores metadata that can be used 
for predicate push down is called "row group" and is a subset of Parquet files. 
Hierarchically, a Parquet file consists of one or more "row groups". 
A row group contains data grouped ion "column chunks", one per column. 
Column chunks are structured in pages. 
Each column chunk contains one or more pages.
Parquet files have several metadata structures, containing among others the schema, 
the list of columns and details about the data stored there, 
such as name and datatype of the columns, their size, number of records 
and basic statistics as minimum and maximum value 

// query (4), example of predicate push down
spark.sql("select * from store_sales where ss_quantity=-1").collect()
stageMetrics.runAndMeasure(spark.sql("select * from store_sales where ss_quantity=-1").collect())
stageMetrics.printAccumulables

//faster than baseline 
executorCpuTime => 13078 (13 s)
executorDeserializeCpuTime => 46 (46 ms)
executorDeserializeTime => 126 (0.1 s)
executorRunTime => 17968 (18 s)
input.bytesRead => 18031716 (17.0 MB)
jvmGCTime => 580 (0.6 s)
resultSize => 79280 (77.0 KB)
duration total => 17796 (18 s)
scan time total => 17780 (18 s)
    
spark.sql("select * from store_sales where ss_quantity=-1").explain(extended=true)    
//checked for PushedFilters: [IsNotNull(ss_quantity), EqualTo(ss_quantity,-1)]
         
//Here also PushedFilters: [IsNotNull(ss_sales_price)], but DECIMAL          
spark.sql("select * from store_sales where ss_sales_price=-1.0").explain(extended=true)        
               
    
///Hive ORC Partitioning 
//https://nycopendata.socrata.com/Social-Services/311-Service-Requests-from-2010-to-Present/erm2-nwe9
//The data has about 19 million rows and 41 columns and it is about 11 GB. It is from 2010 to present.

//Hive to spark partitions 
//Number of partitions in latest versions depends on primarily on spark.sql.files.maxPartitionByte,

//For UniqueKey 
val partitionedByRange = df.repartitionByRange(4, $"Unique Key")

val nyc311_raw = spark.read.options(Map("header"->"true", 
                         "inferSchema"->"true")).
    csv("data/spark/311_Service_Requests_from_2010_to_Present_few.csv")
nyc311_raw.rdd.getNumPartitions //1  //for csv can not control num of partitions 

val cols = nyc311_raw.columns.map(e => e.replace(" ", "_").replace("(","").replace(")","").toLowerCase())
import org.apache.spark.sql._ 
//modify columns 
def dropDuplicates(col1: String, cols: String*): Dataset[T]
Returns a new Dataset with duplicate rows removed, considering only the subset of columns.
def dropDuplicates(): Dataset[T]
Returns a new Dataset that contains only the unique rows from this Dataset.
def withColumn(colName: String, col: Column): DataFrame
Returns a new Dataset by adding a column or replacing the existing column that has the same name.
def withColumnRenamed(existingName: String, newName: String): DataFrame
Returns a new Dataset with a column rename
def drop(colNames: String*): DataFrame
Returns a new Dataset with columns dropped.
def stat: DataFrameStatFunctions 
    advanced stats  
def summary(statistics: String*): DataFrame 
        "count", "min", "25%", "75%", "max", "mean", "50%", "stddev"
def na: DataFrameNaFunctions 
    def drop(how: String, cols: Seq[String]): DataFrame
    Returns a new DataFrame that drops rows containing null or NaN values in the specified columns.
    If how is "any", then drop rows containing any null or NaN values in the specified columns. If how is "all", then drop rows only if every specified column is null or NaN for that row. 
    def drop(cols: Seq[String]): DataFrame
    Returns a new DataFrame that drops rows containing any null or NaN values in the specified columns.
    def drop(how: String): DataFrame
    Returns a new DataFrame that drops rows containing null or NaN values.
    def drop(): DataFrame
    Returns a new DataFrame that drops rows containing any null or NaN values.
    def fill(valueMap: Map[String, Any]): DataFrame
    Returns a new DataFrame that replaces null values.
    The key of the map is the column name, and the value of the map is the replacement value. 
    def fill(value: String): DataFrame
    Returns a new DataFrame that replaces null values in string columns with value. 
    def replace[T](col: String, replacement: Map[T, T]): DataFrame
    Replaces values matching keys in replacement map.

//zipWithIndex = (value, index) 
val nyc311 = nyc311_raw.columns.zipWithIndex.
    foldLeft( nyc311_raw )( (r,t) => r.withColumnRenamed(t._1, cols(t._2)))
    
"""
To replicate 50 times 
val emptyDF = spark.createDataFrame(sc.emptyRDD[Row], nyc311_raw.schema)

//50 times as many recored with an extra UUID column
val bigDf = Range(0,50).foldLeft(emptyDF)((r,e) => r.union(nyc311_raw))
"""

nyc311.select("created_date","agency_name","city").show(10, truncate=false)
//convert created_date ,  closed_date to DATEformat 
import org.apache.spark.sql.{functions=>F}

//val to_date_time =  F.udf((x:String) => datetime.strptime(x, '%m/%d/%Y %I:%M:%S %p')) //TimestampType()
//nyc311_2 = nyc311.withColumn('created_date', to_date_time(F.col('created_date'))).withColumn('year', F.year('created_date'))
val nyc311_2 = nyc311.
    withColumn("created_date", to_timestamp(F.col("created_date"),"MM/dd/yyy hh:mm:ss aa")).
    withColumn("year", F.year($"created_date"))

nyc311_2.select("created_date", "year").show(10)
    
//create hive orc table 

nyc311_2.dtypes  //Array[(String, String)]
nyc311_2.schema(0).toDDL // sql string for one field 
nyc311_2.schema.filter(_.name == "year") //Seq[StructField] 
import org.apache.spark.sql.types._
val sql = StructType(nyc311_2.schema.filter(_.name != "year").toArray).toDDL 
val sql2 = nyc311_2.schema.filter(_.name != "year").foldLeft("")((r,e)=> if(r.isEmpty) r+e.name else r+", "+e.name)


//if true, spark uses own Hive Serde and converts between hive and spark 
spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")
//Spark either OVERWRITEs all partitions or appends to the partitions
//to support overwrite only affected partition (like Hive) use  
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
//When partition key is variable ie dynamic 
spark.conf.set("hive.exec.dynamic.partition", "true")
spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")

//def sample(withReplacement: Boolean, fraction: Double, seed: Long)
//nyc311_2.sample(false, 0.5, 42).createOrReplaceTempView('nyc311_table')
nyc311_2.createOrReplaceTempView("nyc311_table")


val create_partitioned_table_sql = s"""CREATE TABLE if not exists nyc311_orc_partitioned 
($sql) PARTITIONED BY (year INT) STORED AS ORC """
spark.sql(create_partitioned_table_sql)

//For dynamic partitioning to work in Hive, the partition column should be the last column in insert_sql above. Note: make sure the column names are lower case. 
val insert_sql = s"""INSERT INTO nyc311_orc_partitioned PARTITION (year) 
SELECT $sql2, year FROM nyc311_table"""

spark.sql(insert_sql)

spark.sql("show partitions nyc311_orc_partitioned").show()


//Create unpartitioned table
spark.sql("create table nyc311_orc_unpartitioned stored as orc as select * from nyc311_table")


def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0).toDouble/10e9 + " secs")
    result
}


val res_un = time(spark.sql("select agency_name, city, incident_zip, count(*) as frequency from nyc311_orc_unpartitioned where year = '2013' group by agency_name, city, incident_zip").collect())
//0.2363750471 secs

val res_p = time(spark.sql("select agency_name, city,incident_zip, count(*) as frequency from nyc311_orc_partitioned where year = '2013' group by agency_name, city, incident_zip").collect())
//0.1345090487 secs
 
//Incase with DF 
val df_p = spark.read.format("orc").table("nyc311_orc_partitioned")
df_p.rdd.getNumPartitions //3
df_p.explain(extended=true)
//PartitionCount: 6, PartitionFilters: []

//To read only one partition , Spark supports predicate push-down 
val df_p_1 = spark.read.format("orc").table("nyc311_orc_partitioned").where($"year" === 2013)
df_p_1.rdd.getNumPartitions //1
df_p_1.explain(extended=true)
//PartitionCount: 1, PartitionFilters: [isnotnull(year#3970), (year#3970 = 2013)], 

"""
Same as parquet 
Instead of adding your partitioned columns in the path, add them as filters. Modify your code to -

val dfWithColumn = spark.read.orc("/some/path/").where($"region_partition" === 1)

This will identify the schema properly and will read data only for "region_partition=1" directory.

"""
//Then insert into 
//overwrite only that partition , set relevant conf 
//Note for existsing table, partitionBy is not required as partition col is defined already 
//not to be used with Partitionby
df_p_1.write.mode("overwrite").insertInto("nyc311_orc_partitioned")

//store has normal hive table which is different than ORC, textfile, csv, parquet etc 
//year is variable, hence relevant conf should be on 
val df_p = spark.read.format("orc").table("nyc311_orc_partitioned")//read again as above changes df 
spark.sql("DROP TABLE IF EXISTS hive_part_tbl")
df_p.write.partitionBy("year").format("hive").saveAsTable("hive_part_tbl")



///Spark - Bucketing
Partitioning
    Partitioning data is often used for distributing load horizontally, 
    this has performance benefit, and helps in organizing data in a logical fashion. 
    Example: if we are dealing with a large employee table 
    and often run queries with WHERE clauses that restrict the results 
    to a particular country or department . 
    For a faster query response Hive table can be 
    PARTITIONED BY (country STRING, DEPT STRING). 
    Partitioning tables changes how Hive structures the data storage 
    and Hive will now create subdirectories reflecting the partitioning structure like
    .../employees/country=ABC/DEPT=XYZ.
    If query limits for employee from country=ABC, 
    it will only scan the contents of one directory country=ABC. 
    This can dramatically improve query performance,
    but only if the partitioning scheme reflects common filtering. 
    Partitioning feature is very useful in Hive, 
    however, a design that creates too many partitions may optimize some queries, 
    but be detrimental for other important queries. 
    Other drawback is having too many partitions is the large number of Hadoop files 
    and directories that are created unnecessarily and overhead to NameNode 
    since it must keep all metadata for the file system in memory.


Bucketing
    Bucketing is another technique for decomposing data sets into more manageable parts. 
    For example, suppose a table using date as the top-level partition 
    and employee_id as the second-level partition leads to too many small partitions. 
    Instead, if we bucket the employee table and use employee_id as the bucketing column, 
    the value of this column will be hashed by a user-defined number into buckets. 
    Records with the same employee_id will always be stored in the same bucket. 
    Assuming the number of employee_id is much greater than the number of buckets, 
    each bucket will have many employee_id. 
    While creating table you can specify like 
    CLUSTERED BY (employee_id) INTO XX BUCKETS; where XX is the number of buckets . 
    Bucketing has several advantages. The number of buckets is fixed 
    so it does not fluctuate with data. 
    If two tables are bucketed by employee_id, Hive can create a logically correct sampling. 
    Bucketing also aids in doing efficient map-side joins etc.
    def bucketBy(numBuckets: Int, colName: String, colNames: String*): DataFrameWriter[T] 
    def sortBy(colName: String, colNames: String*): DataFrameWriter[T] //used along with bucketing     
        One way to avoid the exchanges (and so optimize the join query) 
        is to use table bucketing that is applicable for all file-based data sources, 
        e.g. Parquet, ORC, JSON, CSV, that are saved as a table 
        using DataFrameWrite.saveAsTable 
        Bucketing is not supported for DataFrameWriter.save, 
        DataFrameWriter.insertInto and DataFrameWriter.jdbc methods.
        eg 
        people.write
          .bucketBy(42, "name")
          .sortBy("age")
          .saveAsTable("people_bucketed")

// Bucketing is enabled by default
//spark.sql.sources.bucketing.enabled
assert(spark.sessionState.conf.bucketingEnabled, "Bucketing disabled?!")

// Make sure that you don't end up with a BroadcastHashJoin and a BroadcastExchange
// For that, let's disable auto broadcasting
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)


///Example with no bucket and bucketing 
import org.apache.spark.sql.SaveMode
spark.range(10e4.toLong).write.mode("overwrite").saveAsTable("t10e4")
spark.range(10e6.toLong).write.mode("overwrite").saveAsTable("t10e6")

val tables = spark.catalog.listTables.where($"name" startsWith "t10e")
scala> tables.show
+-----+--------+-----------+---------+-----------+
| name|database|description|tableType|isTemporary|
+-----+--------+-----------+---------+-----------+
|t10e4| default|       null|  MANAGED|      false|
|t10e6| default|       null|  MANAGED|      false|
+-----+--------+-----------+---------+-----------+

val t4 = spark.table("t10e4")
val t6 = spark.table("t10e6")

assert(t4.count == 10e4)
assert(t6.count == 10e6)

def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0).toDouble/10e9 + " secs")
    result
}

// trigger execution of the join query
time(t4.join(t6, "id").foreach(_ => ()))
//1.5376773278 secs

t4.join(t6, "id").explain(extended=true)
contains SortMergeJoin with 'Exchange hashpartitioning' to shuffle the table datasets for the SortMergeJoin.


      
With bucketing, the Exchanges are no longer needed 
(as the tables are already pre-shuffled).

// Create bucketed tables
import org.apache.spark.sql.SaveMode
spark.range(10e4.toLong).
  write.
  bucketBy(4, "id").
  sortBy("id").
  mode("overwrite").
  saveAsTable("bucketed_4_10e4")
spark.range(10e6.toLong).
  write.
  bucketBy(4, "id").
  sortBy("id").
  mode("overwrite").
  saveAsTable("bucketed_4_10e6")

val bucketed_4_10e4 = spark.table("bucketed_4_10e4")
val bucketed_4_10e6 = spark.table("bucketed_4_10e6")

// trigger execution of the join query
time(bucketed_4_10e4.join(bucketed_4_10e6, "id").foreach(_ => ()))
//0.3325143314 secs
bucketed_4_10e4.join(bucketed_4_10e6, "id").explain(extended=true)
The above join query of the bucketed tables shows 
no  'Exchange hashpartitioning' as the shuffling has already been executed 
(before the query was run).


//Use SessionCatalog or DESCRIBE EXTENDED SQL command to find the bucketing information.

val bucketed_tables = spark.catalog.listTables.where($"name" startsWith "bucketed_")
scala> bucketed_tables.show
+---------------+--------+-----------+---------+-----------+
|           name|database|description|tableType|isTemporary|
+---------------+--------+-----------+---------+-----------+
|bucketed_4_10e4| default|       null|  MANAGED|      false|
|bucketed_4_10e6| default|       null|  MANAGED|      false|
+---------------+--------+-----------+---------+-----------+

val demoTable = "bucketed_4_10e4"

// DESC EXTENDED or DESC FORMATTED would also work
val describeSQL = sql(s"DESCRIBE EXTENDED $demoTable")
scala> describeSQL.show(numRows = 21, truncate = false)
+----------------------------+---------------------------------------------------------------+-------+
|col_name                    |data_type                                                      |comment|
+----------------------------+---------------------------------------------------------------+-------+
|id                          |bigint                                                         |null   |
|                            |                                                               |       |
|# Detailed Table Information|                                                               |       |
|Database                    |default                                                        |       |
|Table                       |bucketed_4_10e4                                                |       |
|Owner                       |jacek                                                          |       |
|Created Time                |Tue Oct 02 10:50:50 CEST 2018                                  |       |
|Last Access                 |Thu Jan 01 01:00:00 CET 1970                                   |       |
|Created By                  |Spark 2.3.2                                                    |       |
|Type                        |MANAGED                                                        |       |
|Provider                    |parquet                                                        |       |
|Num Buckets                 |4                                                              |       |
|Bucket Columns              |[`id`]                                                         |       |
|Sort Columns                |[`id`]                                                         |       |
|Table Properties            |[transient_lastDdlTime=1538470250]                             |       |
|Statistics                  |413954 bytes                                                   |       |
|Location                    |file:/Users/jacek/dev/oss/spark/spark-warehouse/bucketed_4_10e4|       |
|Serde Library               |org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe             |       |
|InputFormat                 |org.apache.hadoop.mapred.SequenceFileInputFormat               |       |
|OutputFormat                |org.apache.hadoop.hive.ql.io.HiveSequenceFileOutputFormat      |       |
|Storage Properties          |[serialization.format=1]                                       |       |
+----------------------------+---------------------------------------------------------------+-------+
//OR 
import org.apache.spark.sql.catalyst.TableIdentifier
val metadata = spark.sessionState.catalog.getTableMetadata(TableIdentifier(demoTable))
scala> metadata.bucketSpec.foreach(println)
4 buckets, bucket columns: [id], sort columns: [id]

///Bucketing constraints 
The number of buckets has to be between 0 and 100000 exclusive 
or Spark SQL throws an AnalysisException:
    Number of buckets should be greater than 0 but less than 100000. Got `[numBuckets]`

There are however requirements that have to be met before Spark Optimizer
gives a no-Exchange query plan:
    The number of memory partitions on both sides of a join has to be exactly the same.
    Both join operators have to use HashPartitioning partitioning scheme.
It is acceptable to use bucketing for one side of a join.

// Make sure that you don't end up with a BroadcastHashJoin and a BroadcastExchange
// For this, let's disable auto broadcasting
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

val bucketedTableName = "bucketed_4_id"
val large = spark.range(10e5.toLong)
import org.apache.spark.sql.SaveMode
large.repartition(4).write.
  bucketBy(4, "id").
  sortBy("id").
  mode("overwrite").
  saveAsTable(bucketedTableName)
val bucketedTable = spark.table(bucketedTableName)

val t1 = spark.
  range(4).
  repartition(4, $"id")  // Make sure that the number of partitions matches the other side
  //.sortWithinPartitions("id") // sort partitions //dont use as it creates two exchanges and sorts,SPARK-24025 

val q = t1.join(bucketedTable, "id")
scala> q.explain
== Physical Plan ==
*(4) Project [id#169L]
+- *(4) SortMergeJoin [id#169L], [id#167L], Inner
   :- *(2) Sort [id#169L ASC NULLS FIRST], false, 0
   :  +- Exchange hashpartitioning(id#169L, 4)
   :     +- *(1) Range (0, 4, step=1, splits=8)
   +- *(3) Sort [id#167L ASC NULLS FIRST], false, 0
      +- *(3) Project [id#167L]
         +- *(3) Filter isnotnull(id#167L)
            +- *(3) FileScan parquet default.bucketed_4_id[id#167L] Batched: true, Format: Parquet, Location: InMemoryFileIndex[file:/Users/jacek/dev/oss/spark/spark-warehouse/bucketed_4_id], PartitionFilters: [], PushedFilters: [IsNotNull(id)], ReadSchema: struct<id:bigint>

q.foreach(_ => ())




//Bucket Pruning-Optimizing Filtering on Bucketed Column (Reducing Bucket Files to Scan)

As of Spark 2.4, Spark SQL supports bucket pruning to optimize filtering 
on bucketed column (by reducing the number of bucket files to scan).

Bucket pruning supports the following predicate expressions:
    EqualTo (=)
    EqualNullSafe (<=>)
    In
    InSet
    And and Or of the above

FileSourceStrategy execution planning strategy is responsible 
for selecting only LogicalRelations over HadoopFsRelation 
with the bucketing specification with the following:
    There is exactly one bucketing column
    The number of buckets is greater than 1



// Enable INFO logging level of FileSourceStrategy logger to see the details of the strategy
import org.apache.spark.sql.execution.datasources.FileSourceStrategy
val logger = FileSourceStrategy.getClass.getName.replace("$", "")
import org.apache.log4j.{Level, Logger}
Logger.getLogger(logger).setLevel(Level.INFO)

val q57 = q.where($"id" isin (50, 70))
scala> val sparkPlan57 = q57.queryExecution.executedPlan
18/11/17 23:18:04 INFO FileSourceStrategy: Pruning directories with:
18/11/17 23:18:04 INFO FileSourceStrategy: Pruned 2 out of 4 buckets.
18/11/17 23:18:04 INFO FileSourceStrategy: Post-Scan Filters: id#0L IN (50,70)
18/11/17 23:18:04 INFO FileSourceStrategy: Output Data Schema: struct<id: bigint>
18/11/17 23:18:04 INFO FileSourceScanExec: Pushed Filters: In(id, [50,70])
//check 
PushedFilters: [IsNotNull(id), In(id, [50,70])], 

///difference with Hive bucketing 
Unlike bucketing in Apache Hive, 
Spark SQL creates the bucket files per the number of buckets and memory partitions. 
In other words, the number of bucketing files is the number of buckets 
multiplied by the number of task writers (one per partition)


val large = spark.range(10e6.toLong)
//spark.conf.set("spark.sql.hive.convertMetastoreParquet", "false")
large.write.
  bucketBy(4, "id").
  sortBy("id").
  mode("overwrite").
  saveAsTable("bucketed_4_id")

scala> println(large.queryExecution.toRdd.getNumPartitions)
4

// That gives 4 (partitions/task writers) x 4 (buckets) = 16 files
// With _SUCCESS extra file and the ls -l header "total 794624" that gives 18 files
$ ls -tlr spark-warehouse/bucketed_4_id | wc -l
      34

      
SO we get warning 
WARN HiveExternalCatalog: Persisting bucketed data source table `default`
.`bucketed_4_id` into Hive metastore in Spark SQL specific format, 
which is NOT compatible with Hive.    
  
Hence it not currently possible to select via Hive or Impala from Spark bucketed tables.
Thats because DataFrame.saveAsTable creates RDD partitions but not Hive partitions, 

(check below whether it is working or not)
the workaround is to create the table via hql before calling DataFrame.saveAsTable. 
An example from SPARK-14927 looks like this:
spark.sql("create external table tmp.partitiontest1(val string) partitioned by (year int)")

Seq(2012 -> "a", 2013 -> "b", 2014 -> "c").toDF("year", "val")
  .write
  .partitionBy("year")
  .mode(SaveMode.Append)
  .saveAsTable("tmp.partitiontest1")
//note insertInto does not work with partitionBy

(another workaround)
It solves the number of files problem but might have some performance implications.
dataframe
  .withColumn("bucket", F.pmod(F.hash($"bucketColumn"), F.lit(numBuckets)))
  .repartition(numBuckets, $"bucket")
  .write
  .format(fmt)
  .bucketBy(numBuckets, "bucketColumn")
  .sortBy("bucketColumn")
  .option("path", "/path/to/your/table")
  .saveAsTable("table_name")

You can do the same with partitioning + bucketing.

dataframe
  .withColumn("bucket", F.pmod(F.hash($"bucketColumn"), F.lit(numBuckets)))
  .repartition(numBuckets, $"partitionColumn", $"bucket")
  .write
  .format(fmt)
  .partitionBy("partitionColumn")
  .bucketBy(numBuckets, "bucketColumn")
  .sortBy("bucketColumn")
  .option("path", "/path/to/your/table")
  .saveAsTable("table_name")



///Spark - Avro -   reading & and writing
// The Avro records get converted to Spark types, filtered, and
//then written back out as Avro records
//schema implicit , creates Dataframe( ie Row)
val df = spark.read.format("com.databricks.spark.avro").load(raw"./data/spark/users.avro")

val df = spark.read.format("com.databricks.spark.avro").load(raw"./data/spark/users.avro")
val subset = df.where("name = 'Ben'")
subset.write.mode("overwrite").format("com.databricks.spark.avro").save(raw"./data/spark/output")




///HandsOn - avro - append a new value to array col 

val addValue = F.udf( (arr:Array[Int], value:Int)=> arr :+ value)
val new_df = df.select(F.col("name"), F.col("favorite_color"), addValue(F.col("favorite_numbers"), F.lit(20)))


///HandsOn - avro - 
//  Saves the subset of the Avro records read in
val subset = df.where("name = 'Ben'")
//If "favorite_numbers" is empty update with something 
//ARRYtype is not supported as F.lit 
//df.select(F.col("name"), F.col("favorite_color"),
//    F.when(F.size(F.col("favorite_numbers")) === 0, F.lit(Array(1,2,3))).otherwise(F.col("favorite_numbers")))

val addValue = F.udf( (arr:Array[Int]) =>  if (arr.isEmpty) Array(1,2,3) else arr)
val subset = df.select(F.col("name"), F.col("favorite_color"), addValue(F.col("favorite_numbers")))
     
subset.write.mode("overwrite").format("com.databricks.spark.avro").save(raw"./data/spark/output")
 
//with schema 
val schema_rdd = spark.sparkContext.textFile(raw"./data/spark/user.avsc").collect()
val s = schema_rdd.mkString("")
val df = spark.read.format("com.databricks.spark.avro").option("avroSchema", s).load(raw"./data/spark/users.avro")










///*** Spark - DataFrame - Data Source - JDBC To Other Databases
//This functionality should be preferred over using JdbcRDD
// --conf spark.executor.val extraClassPath =postgresql-9.4.1207.jar if required in executor  
$ spark-shell  --jars postgresql-9.4.1207.jar
$ spark-submit  --jars postgresql-9.4.1207.jar
//mysql 
$ spark-submit   --jars mysql-connector-java-5.1.34.jar
$ spark-shell --jars mysql-connector-java-5.1.34.jar
//sqlite 
$ spark-submit   --jars sqlite-jdbc-3.21.0.1.jar
$ spark-shell --jars sqlite-jdbc-3.21.0.1.jar


//load
$ spark-shell --packages org.xerial:sqlite-jdbc:3.21.0.1



///Example - Sqlite 
val df = spark.read.json("./data/spark/people.json")
>>> df.dtypes
[("age", "bigint"), ("name", "string")]


df.write.format("jdbc").options(Map("url" -> "jdbc:sqlite:file.db",
                 "driver"  -> "org.sqlite.JDBC",
                 "dbtable"  -> "persons")).mode("append").save()
                 
                 
val dfs = spark.read.format("jdbc").options(Map("url" -> "jdbc:sqlite:file.db",
                 "driver"  -> "org.sqlite.JDBC",
                 "dbtable"  -> "persons")).load()
                 
//With push down queries 
val dfs = spark.read.format("jdbc").options(Map("url" -> "jdbc:sqlite:file.db",
                 "driver"  -> "org.sqlite.JDBC",
                 "dbtable"  -> "(select * from persons where age >= 19) as per").load()
                 

///HandsOn - Dump Iris into sql TAble                  
1.Dump Iris.csv into sql table 
2. then read from sql table 
   and find max, min of one column for each Name 
            
//Ans 
val iris = spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"data\spark\iris.csv")
          
iris.write.format("jdbc").options(Map("url" -> "jdbc:sqlite:iris.db",
                 "driver"  -> "org.sqlite.JDBC",
                 "dbtable"  -> "iris")).mode("overwrite").save()   

val iris1 = spark.read.format("jdbc").options(Map("url" -> "jdbc:sqlite:iris.db",
                 "driver"  -> "org.sqlite.JDBC",
                 "dbtable"  -> "iris")).load()    
                 
iris1.createOrReplaceTempView("iris")
val res = spark.sql("select Name, max(SepalLength), min(SepalLength) from iris group by Name order by Name")
res.show()







///*** MONGODB - Installation of Mongo DB 
///Download mongodb, - http://downloads.mongodb.org/win32/mongodb-win32-x86_64-2008plus-ssl-3.4.15.zip
//unzip to c:\mongodb , create data under it and add bin to Path 

///Start the service 
c:\mongodb\bin\mongod.exe --dbpath c:\mongodb\data --config c:\mongodb\mongod.cfg --service

///Update with Test data 
//Retrieve the dataset from https://raw.githubusercontent.com/mongodb/docs-assets/primer-dataset/primer-dataset.json? 
//save to a file named c:\mongodb\primer-dataset.json.

$ mongoimport --db mydb --collection restaurants --drop --file c:/mongodb/primer-dataset.json


///Test 
$ mongo 
> use mydb   /// use DB mydb
> show dbs	
> db		// show current db
> show collections
> val j = { name : "mongo" }
> val k = { x : 3 }
> db.examples.insert( j )  // on fly  create collections "examples"
> db.testData.insert( k )
> show collections
examples
system.indexes
testData
> db.testData.find()
{ "_id" : ObjectId("59709077f0d01b563cb7bef5"), "x" : 3 }


//spark 
$ spark-shell --packages org.mongodb.spark:mongo-spark-connector_2.11:2.3.0
            
//The spark.mongodb.input.uri specifies the MongoDB server address (127.0.0.1), the database to connect (test), and the collection (myCollection) from which to read data, and the read preference.
//The spark.mongodb.output.uri specifies the MongoDB server address (127.0.0.1), the database to connect (test), and the collection (myCollection) to which to write data. 

//OR Creating via spark Session 

from org.apache.spark.sql import SparkSession

val my_spark = SparkSession \
    .builder \
    .appName("myApp") \
    .config("spark.mongodb.input.uri", "mongodb://127.0.0.1/test.coll") \
    .config("spark.mongodb.output.uri", "mongodb://127.0.0.1/test.coll") \
    .getOrCreate()

///Write to MongoDB
val people = sc.parallelize( ("Bilbo Baggins",  50)::("Gandalf", 1000)::("Thorin", 195)::("Balin", 178)::("Kili", 77)::
   ("Dwalin", 169)::("Oin", 167)::("Gloin", 158)::("Fili", 82)::("Bombur", 0)::Nil).toDF("name", "age")

people.write.format("com.mongodb.spark.sql.DefaultSource").mode("append").save()

people.show()
//Output 
+-------------+----+
|         name| age|
+-------------+----+
|Bilbo Baggins|  50|
|      Gandalf|1000|
|       Thorin| 195|
|        Balin| 178|
|         Kili|  77|
|       Dwalin| 169|
|          Oin| 167|
|        Gloin| 158|
|         Fili|  82|
|       Bombur|null|
+-------------+----+
people.printSchema()
//Output 
root
 |-- _id: struct (nullable = true)
 |    |-- oid: string (nullable = true)
 |-- age: long (nullable = true)
 |-- name: string (nullable = true)


//to write to a different MongoDB collection, use the .option() method with .write().
people.write.format("com.mongodb.spark.sql.DefaultSource").mode("append").
    option("database","people").option("uri","mongodb://127.0.0.1/").option("collection", "contacts").save()

    
    
///Read from MongoDB
//from default input uri  
val df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()

//to read from a different MongoDB collection, use the .option method when reading data into a DataFrame.
val df = spark.read.format("com.mongodb.spark.sql.DefaultSource").
   option("uri","mongodb://127.0.0.1/people.contacts").load()

//in mongo shell 
> use people
> db.contacts.find()

///Aggregation while reading 
//collection named fruit
{ "_id" : 1, "type" : "apple", "qty" : 5 }
{ "_id" : 2, "type" : "orange", "qty" : 10 }
{ "_id" : 3, "type" : "banana", "qty" : 15 }


val pipeline = """{"$match": {"type": "apple"}}"""
val df = spark.read.format("com.mongodb.spark.sql.DefaultSource").option("pipeline", pipeline).load()
df.show()
//Output 
+---+---+-----+
|_id|qty| type|
+---+---+-----+
|1.0|5.0|apple|
+---+---+-----+

///Filters
val df = spark.read.format("com.mongodb.spark.sql.DefaultSource").load()
df.filter($"qty" >= 10).show()
//Output 

+---+----+------+
|_id| qty|  type|
+---+----+------+
|2.0|10.0|orange|
|3.0|15.0|banana|
+---+----+------+


//SQL
df.createOrReplaceTempView("temp")
val some_fruit = spark.sql("SELECT type, qty FROM temp WHERE type LIKE '%e%'")
some_fruit.show()
//output 

+------+----+
|  type| qty|
+------+----+
| apple| 5.0|
|orange|10.0|
+------+----+






///*** Structured Streaming 
///Note for outputMode
Any query           append, update 
join                append
groupby with WM     append, update, complete(no dropping) 
groupBy             update, complete 
//for sink 
FileSink            append 
kafkaSink           append, update, complete
console             append, update, complete
memory              append, complete (Table name is the queryName)



///Example - Kafka structured streaming - uses Kafka API 
//Update PATH with <<install>>\windows\bin and C:\windows\system32\wbem

//go through KafkaSource�s Options in day3.py 

$ spark-shell --packages spark-shell:spark-sql-kafka-0-10_2.11:2.3.0

///cd  to zookeeper dir and then kafka dir 
$ zookeeper-server-start.bat  conf/zoo.cfg  ///client binds to ..:2181
$ kafka-server-start.bat config/server.properties   ///server binds to localhost:9092, called broker-list 

$ kafka-console-producer.bat --broker-list localhost:9092 --topic topic1

 
/// time,key,value
2017-08-23T00:00:00.002Z,"mine",20


/// DataFrame w/ schema [eventTime: timestamp, deviceId: string, signal: bigint]
val rawData = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load() 

>>> rawData.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)  ///ingestion time 
 |-- timestampType: integer (nullable = true)
 
 
val eventsDF = rawData.
  select(F.col("value").cast("string")).          
  withColumn("tokens", F.split(col("value"), ",")).    
  withColumn("eventTime", F.to_timestamp(col("tokens").getItem(0))).
  withColumn("deviceId", F.col("tokens").getItem(1).cast("string")).
  withColumn("signal", F.col("tokens").getItem(2).cast("int")).
  select("eventTime", "deviceId", "signal")

val avgSignalDF = eventsDF.groupBy("deviceId").avg("signal")

///With only window 
//window(timeColumn: Column, windowDuration: String, slideDuration: String): Column
val windowedAvgSignalDF = eventsDF.
    groupBy(F.window($"eventTime", "5 minute")).
    count()

///OR sliding window 
val windowedAvgSignalDF =  eventsDF.
    groupBy(F.window($"eventTime", "10 minutes", "5 minutes")).
    count()
    
///With deviceId and window 
val windowedCountsDF = eventsDF.
    groupBy(
      $"deviceId",
      F.window($"eventTime", "10 minutes", "5 minutes")).  ///duration, sliding duration 
    count()

///Watermarking to Limit State while Handling Late Data
val windowedCountsDF =  eventsDF.
    withWatermark($"eventTime", "20 minutes"). ///late val data = records with eventtime before (currentEventtime - 20 min)
    groupBy(
      F.col("deviceId"),
      F.window(F.col("eventTime"), "5 minutes")).  ///eventtime in record is currentEventtime, tumbling window of 5 minutes 
    agg(F.collect_list(F.col("signal")).alias("signals")).
    select(F.col("deviceId"), F.col("signals"), F.size(F.col("signals")).alias("count"), F.col("window"))

    
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val sq = windowedCountsDF.writeStream.
  format("console").
  option("truncate", false).
  trigger(Trigger.ProcessingTime(10.seconds)).
  outputMode("update").  
  start()
  
  
//kafka sink -needs value


val sq2 = windowedCountsDF.select(F.col("deviceId").alias("value")).writeStream.
  format("kafka").
  option("topic", "topicName").
  option("kafka.bootstrap.servers", "localhost:9092").
  option("checkpointLocation", "./kafka-checkpoint1") .
  start() 
  
  
val df_value = windowedCountsDF.select(F.concat_ws(",",
        F.col("deviceId").cast("string"), 
        F.col("signals").cast("string"),
        F.col("count").cast("string"),
        F.col("window").cast("string")).alias("value")).show()

val sq2 = df_value.select(F.col("deviceId").alias("value")).writeStream.
  format("kafka").
  option("topic", "topicName").
  option("kafka.bootstrap.servers", "localhost:9092").
  option("checkpointLocation", "./kafka-checkpoint2") .
  start() 
  
//Another windows 
$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic topicName --from-beginning

//
sq.processAllAvailable()  ///testng purpose only , only once triggered   
  
/// After StreamingQuery was started,
/// the physical plan is complete (with batch-specific values)
>>> sq.explain()

>>> println(sq.lastProgress)


//purge all 
spark.streams.active 
spark.streams.active .map(q => q.stop())
  

>>> sq.isActive
false


///input 
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:00:00.002Z,"mine",20

  
///Output 
-------------------------------------------
Batch: 1
-------------------------------------------
+--------+----------------+-----+------------------------------------------+
|deviceId|signals         |count|window                                    |
+--------+----------------+-----+------------------------------------------+
|"mine"  |[70]            |1    |[2017-08-23 06:15:00, 2017-08-23 06:20:00]|
|"mine"  |[60, 60]        |2    |[2017-08-23 06:30:00, 2017-08-23 06:35:00]|
|"mine"  |[30, 40, 30, 40]|4    |[2017-08-23 05:35:00, 2017-08-23 05:40:00]|
|"mine"  |[20, 20]        |2    |[2017-08-23 05:30:00, 2017-08-23 05:35:00]|
|"mine"  |[50, 50]        |2    |[2017-08-23 05:40:00, 2017-08-23 05:45:00]|
+--------+----------------+-----+------------------------------------------+

-------------------------------------------
Batch: 2
-------------------------------------------
+--------+--------+-----+------------------------------------------+
|deviceId|signals |count|window                                    |
+--------+--------+-----+------------------------------------------+
|"mine"  |[70, 70]|2    |[2017-08-23 06:15:00, 2017-08-23 06:20:00]|
+--------+--------+-----+------------------------------------------+

-------------------------------------------
Batch: 3
-------------------------------------------
+--------+-------+-----+------+
|deviceId|signals|count|window|
+--------+-------+-----+------+
+--------+-------+-----+------+






///*** ML/MLIB - General flow of classification, regression 

1. Feature extractors (generally for Text data)
   Feature selection if input features are of high numbers 
   Feature Transformers to transform input data 
   input data is DF for ML and LabeledPoint for mlib 
   (containing label, features columns - could be dense or sparse Vector ) 
   sparse vector is identified by [#of_features, [indices], [corresponding_values]]
   Note, all feature columns in 2D data are part of only one column "features" in final DF 
   Use VectorAssembler or sql.functions.array() to merge all seperate feature columns to one "features" column 
   For ML, use setInputCol/setOutputCol/setLabelCol/setFeaturesCol etc 
   to set columns name for operation 
2. Classification or regression stage of transformed data 
3. if required inverse transformation of step 1
4. Random split input data into training and test 
   Dataset[T].randomSplit(weights: Array[Double]): Array[Dataset[T]] 
   RDD[T].randomSplit(weights: Array[Double], seed: val Long = Utils.random.nextLong): Array[RDD[T]] 
5. fit the training data to get "model" 
6. val predictions = model.transform(testData) to get prediction 
   Note in MLIB, call  predict
7. For ML, Use "evaluate" of MulticlassClassificationEvaluator 
   or BinaryClassificationEvaluator or RegressionEvaluator with above predictions 
   MulticlassClassificationEvaluator supports metricName as "f1" (default), "weightedPrecision", "weightedRecall", "accuracy")
   BinaryClassificationEvaluator (supports "areaUnderROC" (default), "areaUnderPR")
   RegressionEvaluator supports "rmse" (default): root mean squared error,"mse": mean squared error,"r2": R2 metric,"mae": mean absolute error 
7. For MLIB, similarly use many Metrics classes 
   BinaryClassificationMetrics,MulticlassMetrics,MultilabelMetrics,,RegressionMetrics
8. Note for Binary class or regression of test or training data , 
   Use model.summaryto get summary, BinaryLogisticRegressionSummary/LinearRegressionSummary/GeneralizedLinearRegressionSummary from model.summary 
   check "lazy val" variables which are importants for summary
   BinaryLogisticRegressionSummary have predictions 
   RegressionSummary have pValues, coefficientStandardErrors(form normal solver), residuals, aic (for GLM)

NOTE 
   1. .toDF, .toDS etc are implicits on Seq and RDD 
      primitives, date, timestamp, tuple , case class and  Seq, Array, Map of those only have implicits  Encoders 
      DenseVector and SparseVector donot have Encoders, Wrap them inside Tuple or case class 
   2. For Pipeline, use Pipeline
      For tuning use CrossValidator, TrainValidationSplit along with ParamGridBuilder
      all above and any classification, regression class have .params, .explainParams, .extractParamMap, 
      then use .setParamName to set any params
   3. Pipline,classification, regression class, CrossValidator,TrainValidationSplit trains on 
      "label" and "fetaures" columns of DF (which is SparseVector or DenseVector of all features- Use VectorAssembler to create such)
      or set those columns by setLabelCol and setFeaturesCol
      Outputs are in generally "prediction" and "probability" columns of "transform" DF 
      or set them by setPredictionCol, setProbabilityCol
    4. Model has .save(path) and ObjectModel.load(path) for saving/loading model 
       Check the model class name, after .fit(dataFrame) 
       

///ML: Default Input Column name in DF  for classifiation, regression 
//Param name  Type(s)     Default     Description
labelCol      Double      "label"     Label to predict 
featuresCol   Vector      "features"  Feature vector 

///ML: Default Output Column name in DF  for classifiation, regression 
//Param name          Type(s)     Default         Description
predictionCol       Double      "prediction"    Predicted label  
rawPredictionCol    Vector      "rawPrediction" Vector of length // classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"   Vector of length // classes equal to rawPrediction normalized to a multinomial distribution Classification only 
varianceCol         Double                      The biased sample variance of prediction Regression only 
///*** ML : Extracting, transforming and selecting features
// �Extraction: Extracting features from �raw� data
// �Transformation: Scaling, converting, or modifying features
// �Selection: Selecting a subset from a larger set of features

import org.apache.spark.ml.feature._ 
import org.apache.spark.mllib.feature._  //for MLIB 


//Some Transformation works on Column of Vector or convert Vector to Vector or simple element to Vector 

//Before ML regression/classifications, DF has two columns 
//,"label" should be Double and 
//"features" should be vector (dense or Sparse - eg (20,[0,5,9,17],[1.0,1.0,1.0,2.0])  )

//All these have below methods to set in and out columnname
//Applies transformations on input column and result is in output column of DF
def setInputCol(value: String)
def setOutputCol(value: String)
//Additionally , have methods for setting it"s paramaters eg 
def setMax(value: Double)
def setMin(value: Double)
//have many methods for manipulating Params 
def explainParams(): String
    Explains all params of this instance.
lazy val params: Array[Param[_]]
    Returns all params sorted by their names.
//Can save and read model 
instance.save(path: String): Unit
Object.load(path: String)
//Might have .fit(inputDF) to get fitted model and model.transform(inputDF) to get output DF 
//if model is not involved , use diretly instance.transform(inputDF) to get output DF 


///Summary - Feature Extractors 
?TF-IDF     
    Term frequency-inverse document frequency (TF-IDF) is multiplication of TF(HashingTF and CountVectorizer) and IDF 
    Reflects the importance of a term to a document 
    TF - generates the term frequency vectors
    IDF -  it down-weights columns which appear frequently in the corpus 
    ///*Result (in-sentence, tokenizer - words, TF-rawfeatures, out/TF-IDF- features)
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |label|sentence                           |words                                     |rawFeatures                              |features                                                                                                              |
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |0.0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |(20,[0,5,9,17],[1.0,1.0,1.0,2.0])        |(20,[0,5,9,17],[0.6931471805599453,0.6931471805599453,0.28768207245178085,1.3862943611198906])                        |
    |0.0  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|(20,[2,7,9,13,15],[1.0,1.0,3.0,1.0,1.0]) |(20,[2,7,9,13,15],[0.6931471805599453,0.6931471805599453,0.8630462173553426,0.28768207245178085,0.28768207245178085]) |
    |1.0  |Logistic regression models are neat|[logistic, regression, models, are, neat] |(20,[4,6,13,15,18],[1.0,1.0,1.0,1.0,1.0])|(20,[4,6,13,15,18],[0.6931471805599453,0.6931471805599453,0.28768207245178085,0.28768207245178085,0.6931471805599453])|
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+

?Word2Vec
    Transforms each column of Vector into a vector using the average of all words in the document
    ///*Result
    +------------------------------------------+----------------------------------------------------------------+
    |text                                      |result                                                          |
    +------------------------------------------+----------------------------------------------------------------+
    |[Hi, I, heard, about, Spark]              |[-0.008142343163490296,0.02051363289356232,0.03255096450448036] |
    |[I, wish, Java, could, use, case, classes]|[0.043090314205203734,0.035048123182994974,0.023512658663094044]|
    |[Logistic, regression, models, are, neat] |[0.038572299480438235,-0.03250147425569594,-0.01552378609776497]|
    +------------------------------------------+----------------------------------------------------------------+

    
?CountVectorizer
    Converts a collection of text documents to vectors of token counts.
    ///*Result 
    +---+---------------+-------------------------+
    |id |words          |features                 |
    +---+---------------+-------------------------+
    |0  |[a, b, c]      |(3,[0,1,2],[1.0,1.0,1.0])|
    |1  |[a, b, b, c, a]|(3,[0,1,2],[2.0,2.0,1.0])|
    +---+---------------+-------------------------+

///Summary - Feature Transformers 
?Tokenizer    
    takes text (such as a sentence) and breakes it into individual terms (usually words). 
    ///*Result (RegexTokenizer - .setPattern("\\W"))
    +---+-----------------------------------+------------------------------------------+
    |id |sentence                           |words                                     |
    +---+-----------------------------------+------------------------------------------+
    |0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |
    |1  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|
    |2  |Logistic,regression,models,are,neat|[logistic, regression, models, are, neat] |
    +---+-----------------------------------+------------------------------------------+
    
?StopWordsRemover
    Removes Stop words are words which should be excluded from the input, 
    typically because the words appear frequently and don�t carry as much meaning.
    ///*Result 
    +---+----------------------------+--------------------+
    |id |raw                         |filtered            |
    +---+----------------------------+--------------------+
    |0  |[I, saw, the, red, balloon] |[saw, red, balloon] |
    |1  |[Mary, had, a, little, lamb]|[Mary, little, lamb]|
    +---+----------------------------+--------------------+
    
?n-gram
     transform input feature/a Column Vector into sequence of n tokens (typically words) for some integer n
     ///*Result - setN(2)
    +---+------------------------------------------+------------------------------------------------------------------+
    |id |words                                     |ngrams                                                            |
    +---+------------------------------------------+------------------------------------------------------------------+
    |0  |[Hi, I, heard, about, Spark]              |[Hi I, I heard, heard about, about Spark]                         |
    |1  |[I, wish, Java, could, use, case, classes]|[I wish, wish Java, Java could, could use, use case, case classes]|
    |2  |[Logistic, regression, models, are, neat] |[Logistic regression, regression models, models are, are neat]    |
    +---+------------------------------------------+------------------------------------------------------------------+

     

?Binarizer
    Converts numerical features to binary (0/1) features using a threashold
    ///*Result  - setThreshold(0.5)
    +---+-------+-----------------+
    |id |feature|binarized_feature|
    +---+-------+-----------------+
    |0  |0.1    |0.0              |
    |1  |0.8    |1.0              |
    |2  |0.2    |0.0              |
    +---+-------+-----------------+
    
?PCA
    Converts a set of observations of possibly correlated variables into a set of values 
    of linearly uncorrelated variables called principal components
    ///*Result   - setK(3)  
    +---------------------+-----------------------------------------------------------+
    |features             |pcaFeatures                                                |
    +---------------------+-----------------------------------------------------------+
    |(5,[1,3],[1.0,7.0])  |[1.6485728230883807,-4.013282700516296,-5.524543751369388] |
    |[2.0,0.0,3.0,4.0,5.0]|[-4.645104331781534,-1.1167972663619026,-5.524543751369387]|
    |[4.0,0.0,0.0,6.0,7.0]|[-6.428880535676489,-5.337951427775355,-5.524543751369389] |
    +---------------------+-----------------------------------------------------------+
    
?PolynomialExpansion
    expands your features into a polynomial space, To include higher degree terms of features 
    which is formulated by an n-degree combination of original dimensions.
    ///*Result - setDegree(3)
    +----------+------------------------------------------+
    |features  |polyFeatures                              |
    +----------+------------------------------------------+
    |[2.0,1.0] |[2.0,4.0,8.0,1.0,2.0,4.0,1.0,2.0,1.0]     |
    |[0.0,0.0] |[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]     |
    |[3.0,-1.0]|[3.0,9.0,27.0,-1.0,-3.0,-9.0,1.0,3.0,-1.0]|
    +----------+------------------------------------------+
    
?Discrete Cosine Transform (DCT)
    transforms a length N real-valued Vector Column in the time domain 
    into another length N real-valued Vector Column  in the frequency domain
    /// Result
   +--------------------+----------------------------------------------------------------+
   |features            |featuresDCT                                                     |
   +--------------------+----------------------------------------------------------------+
   |[0.0,1.0,-2.0,3.0]  |[1.0,-1.1480502970952693,2.0000000000000004,-2.7716385975338604]|
   |[-1.0,2.0,4.0,-7.0] |[-1.0,3.378492794482933,-7.000000000000001,2.9301512653149677]  |
   |[14.0,-2.0,-5.0,1.0]|[4.0,9.304453421915744,11.000000000000002,1.5579302036357163]   |
   +--------------------+----------------------------------------------------------------+
 
    
?StringIndexer
     Encodes a string column of labels to a column of label indices. 
     The indices are in [0, numLabels), ordered by label frequencies, so the most frequent label gets index 0
    ///* Result 
    +---+--------+-------------+
    |id |category|categoryIndex|
    +---+--------+-------------+
    |0  |a       |0.0          |
    |1  |b       |2.0          |
    |2  |c       |1.0          |
    |3  |a       |0.0          |
    |4  |a       |0.0          |
    |5  |c       |1.0          |
    +---+--------+-------------+
   
?IndexToString
     Converts column of label indices back to a column containing the original labels as strings
    ///* Result 
    +---+--------+-------------+----------------+
    |id |category|categoryIndex|originalCategory|
    +---+--------+-------------+----------------+
    |0  |a       |0.0          |a               |
    |1  |b       |2.0          |b               |
    |2  |c       |1.0          |c               |
    |3  |a       |0.0          |a               |
    |4  |a       |0.0          |a               |
    |5  |c       |1.0          |c               |
    +---+--------+-------------+----------------+
 
 
?OneHotEncoder
    maps a column of label indices to a column of binary vectors, with at most a single one-value
    This encoding allows algorithms which expect continuous features, such as Logistic Regression, to use categorical features
    eg Use StringIndexer and the OneHotEncoder to convert string category to column to be used for Logit 
    ///* Result - in:category, StringIndexer:categoryIndex, out:categoryVec
    +---+--------+-------------+-------------+
    |id |category|categoryIndex|categoryVec  |
    +---+--------+-------------+-------------+
    |0  |a       |0.0          |(2,[0],[1.0])|
    |1  |b       |2.0          |(2,[],[])    |
    |2  |c       |1.0          |(2,[1],[1.0])|
    |3  |a       |0.0          |(2,[0],[1.0])|
    |4  |a       |0.0          |(2,[0],[1.0])|
    |5  |c       |1.0          |(2,[1],[1.0])|
    +---+--------+-------------+-------------+
    
?VectorIndexer
    Takes an input columns of type Vector and a parameter maxCategories 
    Decide which features should be categorical based on the number of distinct values, where features with at most maxCategories are declared categorical.
    Compute 0-based category indices for each categorical feature
    and transform original feature values to indices
    ///* Result - setMaxCategories(2)
    +---+--------------+--------------+
    |id |features      |indexed       |
    +---+--------------+--------------+
    |0  |[1.0,0.5,-1.0]|[0.0,0.0,-1.0]|
    |1  |[1.0,1.0,1.0] |[0.0,1.0,1.0] |
    |2  |[4.0,0.5,2.0] |[1.0,0.0,2.0] |
    +---+--------------+--------------+
    
    
?Interaction
    takes Vector OR double-valued columns, and generates a single vector column 
    that contains the product of all combinations of one value from each input column
    ///*Result, vec1<- VectorAssembler("id2", "id3", "id4"), vec2 <-VectorAssembler("id5", "id6", "id7")
    // val output = interactedCol of vec1 and vec2
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |id1|id2|id3|id4|id5|id6|id7|vec1          |vec2          |interactedCol                                         |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |1  |1  |2  |3  |8  |4  |5  |[1.0,2.0,3.0] |[8.0,4.0,5.0] |[8.0,4.0,5.0,16.0,8.0,10.0,24.0,12.0,15.0]            |
    |2  |4  |3  |8  |7  |9  |8  |[4.0,3.0,8.0] |[7.0,9.0,8.0] |[56.0,72.0,64.0,42.0,54.0,48.0,112.0,144.0,128.0]     |
    |3  |6  |1  |9  |2  |3  |6  |[6.0,1.0,9.0] |[2.0,3.0,6.0] |[36.0,54.0,108.0,6.0,9.0,18.0,54.0,81.0,162.0]        |
    |4  |10 |8  |6  |9  |4  |5  |[10.0,8.0,6.0]|[9.0,4.0,5.0] |[360.0,160.0,200.0,288.0,128.0,160.0,216.0,96.0,120.0]|
    |5  |9  |2  |7  |10 |7  |3  |[9.0,2.0,7.0] |[10.0,7.0,3.0]|[450.0,315.0,135.0,100.0,70.0,30.0,350.0,245.0,105.0] |
    |6  |1  |1  |4  |2  |8  |4  |[1.0,1.0,4.0] |[2.0,8.0,4.0] |[12.0,48.0,24.0,12.0,48.0,24.0,48.0,192.0,96.0]       |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+

?Normalizer
    transforms a dataset of Vector rows, normalizing each Vector to have p-norm(each val Vector = all features)
    ///* Result - setP(1.0)
    +---+--------------+------------------+
    |id |features      |normFeatures      |
    +---+--------------+------------------+
    |0  |[1.0,0.5,-1.0]|[0.4,0.2,-0.4]    |
    |1  |[2.0,1.0,1.0] |[0.5,0.25,0.25]   |
    |2  |[4.0,10.0,2.0]|[0.25,0.625,0.125]|
    +---+--------------+------------------+
 
?StandardScaler
    transforms a dataset of rows, normalizing each feature(ie Column) 
    to have unit standard deviation and/or zero mean. 
    ///*Result - setWithStd(true),setWithMean(false)
    +---+--------------+------------------------------------------------------------+
    |id |features      |scaledFeatures                                              |
    +---+--------------+------------------------------------------------------------+
    |0  |[1.0,0.5,-1.0]|[0.6546536707079771,0.09352195295828246,-0.6546536707079771]|
    |1  |[2.0,1.0,1.0] |[1.3093073414159542,0.18704390591656492,0.6546536707079771] |
    |2  |[4.0,10.0,2.0]|[2.6186146828319083,1.8704390591656492,1.3093073414159542]  |
    +---+--------------+------------------------------------------------------------+

    
?MinMaxScaler
    MinMaxScaler transforms a dataset of rows, 
    rescaling each feature(ie Column) to a specific range (often [0, 1]). 
    ///* Result
    +---+--------------+--------------+
    |id |features      |scaledFeatures|
    +---+--------------+--------------+
    |0  |[1.0,0.1,-1.0]|[0.0,0.0,0.0] |
    |1  |[2.0,1.1,1.0] |[0.5,0.1,0.5] |
    |2  |[3.0,10.1,3.0]|[1.0,1.0,1.0] |
    +---+--------------+--------------+

 
?MaxAbsScaler
    transforms a dataset of rows, rescaling each feature(ie Column) to range [-1, 1]
    ///* Result
    +---+--------------+----------------+
    |id |features      |scaledFeatures  |
    +---+--------------+----------------+
    |0  |[1.0,0.1,-8.0]|[0.25,0.01,-1.0]|
    |1  |[2.0,1.0,-4.0]|[0.5,0.1,-0.5]  |
    |2  |[4.0,10.0,8.0]|[1.0,1.0,1.0]   |
    +---+--------------+----------------+
   
?Bucketizer
    transforms a column of continuous feature to a column of feature bucket index(after n splits)
    ///*Result - .setSplits(Array(Double.NegativeInfinity, -0.5, 0.0, 0.5, Double.PositiveInfinity))
    +--------+----------------+
    |features|bucketedFeatures|
    +--------+----------------+
    |-999.9  |0.0             |
    |-0.5    |1.0             |
    |-0.3    |1.0             |
    |0.0     |2.0             |
    |0.2     |2.0             |
    |999.9   |3.0             |
    +--------+----------------+



 
?ElementwiseProduct
    scales each column of the dataset by a scalar multiplier.
    ///*Result with Vectors.dense(0.0, 1.0, 2.0)
    +---+-------------+-----------------+
    |id |vector       |transformedVector|
    +---+-------------+-----------------+
    |a  |[1.0,2.0,3.0]|[0.0,2.0,6.0]    |
    |b  |[4.0,5.0,6.0]|[0.0,5.0,12.0]   |
    +---+-------------+-----------------+
    
?SQLTransformer
    transforms column via SQL statement 
    ///*Result "SELECT *, (v1 + v2) AS v3, (v1 * v2) AS v4 from __THIS__ "
    +---+---+---+---+----+
    |id |v1 |v2 |v3 |v4  |
    +---+---+---+---+----+
    |0  |1.0|3.0|4.0|3.0 |
    |2  |2.0|5.0|7.0|10.0|
    +---+---+---+---+----+
    
?VectorAssembler
    combines a given list of columns into a single vector column
    ///*Result - features <- Array("hour", "mobile", "userFeatures")    
    +---+----+------+--------------+-------+-----------------------+
    |id |hour|mobile|userFeatures  |clicked|features               |
    +---+----+------+--------------+-------+-----------------------+
    |0  |18  |1.0   |[0.0,10.0,0.5]|1.0    |[18.0,1.0,0.0,10.0,0.5]|
    +---+----+------+--------------+-------+-----------------------+
    
?QuantileDiscretizer
    takes a column with continuous feature and outputs a column with binned categorical feature( eg n bin)
    ///*Result - setNumBuckets(3),in = hour,out =result     
    +---+----+------+
    |id |hour|result|
    +---+----+------+
    |0  |18.0|2.0   |
    |1  |19.0|2.0   |
    |2  |8.0 |1.0   |
    |3  |5.0 |1.0   |
    |4  |2.2 |0.0   |
    +---+----+------+

///Summary - Feature Selectors 
?VectorSlicer
    extracts subfeatures from a vector column.
    ///*Result   - setIndices(Array(1)) or setIndices(Array(1, 2)),in =userFeatures
    +--------------------+-------------+
    |userFeatures        |features     |
    +--------------------+-------------+
    |(3,[0,1],[-2.0,2.3])|(2,[0],[2.3])|
    |[-2.0,2.3,0.0]      |[2.3,0.0]    |
    +--------------------+-------------+
    
?RFormula
    selects columns specified by an R model formula    
    ~ separate target and terms
    + concat terms, �+ 0� means removing intercept
    - remove a term, �- 1� means removing intercept
    : interaction (multiplication for numeric values, or binarized categorical values)
    . all columns except target
    string input columns will be one-hot encoded, and numeric columns will be cast to doubles
    If the label column is of type string, it will be first transformed to double with StringIndexer. 
    If the label column does not exist in the DataFrame, the output label column will be created from the specified response variable in the formula.
    ///*Result - .setFormula("clicked ~ country + hour").setFeaturesCol("features").setLabelCol("label")
    // hence val label = clicked ,features = country + hour
    +---+-------+----+-------+--------------+-----+
    |id |country|hour|clicked|features      |label|
    +---+-------+----+-------+--------------+-----+
    |7  |US     |18  |1.0    |[0.0,0.0,18.0]|1.0  |
    |8  |CA     |12  |0.0    |[1.0,0.0,12.0]|0.0  |
    |9  |NZ     |15  |0.0    |[0.0,1.0,15.0]|0.0  |
    +---+-------+----+-------+--------------+-----+

    
?ChiSqSelector
    uses the Chi-Squared test of independence to decide which features to choose(by numTopFeatures, percentile , fpr)
    ///*Result - .setNumTopFeatures(1)
    // top 1 features selected,out =    selectedFeatures,in =features
    +---+------------------+-------+----------------+
    |id |features          |clicked|selectedFeatures|
    +---+------------------+-------+----------------+
    |7  |[0.0,0.0,18.0,1.0]|1.0    |[18.0]          |
    |8  |[0.0,1.0,12.0,0.0]|0.0    |[12.0]          |
    |9  |[1.0,0.0,15.0,0.1]|0.0    |[15.0]          |
    +---+------------------+-------+----------------+
    
?Userdefined Transformer 
    eg Add a constant term to input via extending UnaryTransformer
    ///*Result - setShift(0.5)
    +-----+------+
    |input|output|
    +-----+------+
    |0.0  |0.5   |
    |1.0  |1.5   |
    |2.0  |2.5   |
    |3.0  |3.5   |
    |4.0  |4.5   |
    +-----+------+
    
?Locality Sensitive Hashing
    a class of hashing techniques
    Two algorithms 
        Bucketed Random Projection for Euclidean Distance(hash bucket based on Euclidian distance)
        MinHash for Jaccard Distance 
    Various operations possibles
    Example - Bucketed Random Projection for Euclidean Distance
    ///* Result - .setBucketLength(2.0).setNumHashTables(3),in =keys,out =values 
    +---+-----------+-----------------------+
    |id |keys       |values                 |
    +---+-----------+-----------------------+
    |0  |[1.0,1.0]  |[[0.0], [0.0], [-1.0]] |
    |1  |[1.0,-1.0] |[[-1.0], [-1.0], [0.0]]|
    |2  |[-1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    |3  |[-1.0,1.0] |[[0.0], [0.0], [-1.0]] |
    +---+-----------+-----------------------+

    +---+----------+-----------------------+
    |id |keys      |values                 |
    +---+----------+-----------------------+
    |4  |[1.0,0.0] |[[0.0], [-1.0], [-1.0]]|
    |5  |[-1.0,0.0]|[[-1.0], [0.0], [0.0]] |
    |6  |[0.0,1.0] |[[0.0], [0.0], [-1.0]] |
    |7  |[0.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    +---+----------+-----------------------+
    ///*Result - Approximate similarity join with val threashold = 1.5 
    // val in = datasetA,datasetB (from above),out = below full DF 
    //check each row, eg id 1 is joined with id 4 with val distCol = 1.0 (min)
    +---------------------------------------------------+--------------------------------------------------+-------+
    |datasetA                                           |datasetB                                          |distCol|
    +---------------------------------------------------+--------------------------------------------------+-------+
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    +---------------------------------------------------+--------------------------------------------------+-------+
    ///*Result - Approximate nearest neighbor search, for Vectors.dense(1.0, 0.0)
    ///val in = datsetA(from above),out = below DF showing which ids are nearer via val distCol =1.0 min 
    +---+----------+-----------------------+-------+
    |id |keys      |values                 |distCol|
    +---+----------+-----------------------+-------+
    |1  |[1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|1.0    |
    |0  |[1.0,1.0] |[[0.0], [0.0], [-1.0]] |1.0    |
    +---+----------+-----------------------+-------+
    



///*** Intro Spark MLlib
///Extra Methods in Mlib 
org.apache.spark.mllib.linalg 
    object Vectors //factory methods 
        def fromJson(json: String): Vector
            Parses the JSON representation of a vector into a Vector.
        def fromML(v: ml.linalg.Vector): Vector
            Convert new linalg type to spark.mllib type.
    DenseVector 
        def asML: ml.linalg.DenseVector
            Convert this vector to the new mllib-local representation.
        def toJson: String
            Converts the vector to a JSON string.
        object DenseVector
            def fromML(v: ml.linalg.DenseVector): DenseVector
                Convert new linalg type to spark.mllib type.
    SparseVector 
        def asML: ml.linalg.SparseVector
            Convert this vector to the new mllib-local representation.
        def toJson: String
            Converts the vector to a JSON string.
        object SparseVector 
            def fromML(v: ml.linalg.SparseVector): SparseVector
                Convert new linalg type to spark.mllib type.        
    object Matrices //factory method 
        def fromML(m: ml.linalg.Matrix): Matrix
            Convert new linalg type to spark.mllib type.
    DenseMatrix
        def asML: ml.linalg.DenseMatrix
            Convert this matrix to the new mllib-local representation.
        object DenseMatrix
            def fromML(m: ml.linalg.DenseMatrix): DenseMatrix
                Convert new linalg type to spark.mllib type.
    SparseMatrix
        def asML: ml.linalg.SparseMatrix
            Convert this matrix to the new mllib-local representation.
        object SParseMatrix 
            def fromML(m: ml.linalg.SparseMatrix): SparseMatrix
                Convert new linalg type to spark.mllib type.       
// ML types 
org.apache.spark.ml.linalg 
    object Vectors //Factory methods
        def dense(values: Array[Double]): Vector
        def dense(firstValue: Double, otherValues: Double*): Vector
            Vectors.dense(Array(1.0, 2.0))
        def norm(vector: Vector, p: Double): Double
        def sparse(size: Int, elements: Iterable[(Integer, Double)]): Vector
        def sparse(size: Int, elements: Seq[(Int, Double)]): Vector
        def sparse(size: Int, indices: Array[Int], values: Array[Double]): Vector
            >>> Vectors.sparse(4, List((1, 1.0), (3, 5.5)))
            SparseVector(4, {1: 1.0, 3: 5.5})
            >>> Vectors.sparse(4, Array(1, 3), Array(1.0, 5.5))
            SparseVector(4, {1: 1.0, 3: 5.5})
        def sqdist(v1: Vector, v2: Vector): Double
        def zeros(size: Int): Vector
    DenseVector(ar)
        Column-major dense matrix.
        == for equality and (Int) for indexing
        new DenseVector(values: Array[Double])
        def apply(i: Int): Double
            Gets the value of the ith element.
        def argmax: Int
            Find the index of a maximal element.
        def compressed: Vector
            Returns a vector in either dense or sparse format, whichever uses less storage.
        def copy: DenseVector
            Makes a deep copy of this vector.
        def equals(other: Any): Boolean
        def foreachActive(f: (Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse vector.
        def hashCode(): Int
            Returns a hash code value for the vector.
        def numActives: Int
            Number of active entries.
        def numNonzeros: Int
            Number of nonzero elements.
        def size: Int
            Size of the vector.
        def toArray: Array[Double]
            Converts the instance to a double array.
        def toDense: DenseVector
            Converts this vector to a dense vector.
        def toSparse: SparseVector
            Converts this vector to a sparse vector with all explicit zeros removed.
        def toString(): String
        val values: Array[Double] 
        object DenseVector.unapply(dv: DenseVector): Option[Array[Double]] 
            extractor 
    SparseVector(size, *args)
        Sparse Vector, == and (Int) for indexing 
            new SparseVector(size: Int, indices: Array[Int], values: Array[Double])
        def apply(i: Int): Double
            Gets the value of the ith element.
        def argmax: Int
            Find the index of a maximal element.
        def compressed: Vector
            Returns a vector in either dense or sparse format, whichever uses less storage.
        def copy: SparseVector
            Makes a deep copy of this vector.
        def equals(other: Any): Boolean
        def foreachActive(f: (Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse vector.
        def hashCode(): Int
            Returns a hash code value for the vector.
        val indices: Array[Int]
            index array, assume to be strictly increasing.
        def numActives: Int
            Number of active entries.
        def numNonzeros: Int
            Number of nonzero elements.
        val size: Int
            size of the vector.
        def toArray: Array[Double]
            Converts the instance to a double array.
        def toDense: DenseVector
            Converts this vector to a dense vector.
        def toSparse: SparseVector
            Converts this vector to a sparse vector with all explicit zeros removed.
        def toString(): String
        val values: Array[Double]
            value array, must have the same length as the index array.
        object SparseVector.unapply(sv: SparseVector): Option[(Int, Array[Int], Array[Double])] 
            Extractor
    object Matrices #factory 
        def dense(numRows: Int, numCols: Int, values: Array[Double]): Matrix
            Creates a column-major dense matrix.
            Example:
                1.0 2.0
                3.0 4.0
                5.0 6.0
            is stored as [1.0, 3.0, 5.0, 2.0, 4.0, 6.0]. 
        def sparse(numRows: Int, numCols: Int, colPtrs: Array[Int], rowIndices: Array[Int], values: Array[Double]): Matrix
            Creates a column-major sparse matrix in Compressed Sparse Column (CSC) format.
            Example- following matrix
                1.0 0.0 4.0
                0.0 3.0 5.0
                2.0 0.0 6.0
            is stored as values: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0], 
            val numRows = 3 ,numCols = 3
            val rowIndices =[0, 2, 1, 0, 1, 2], row index of each from values
            val colPointers =[0, 2, 3, 6] , index of values where col number changes     
        def diag(vector: Vector): Matrix
            Generate a diagonal matrix in Matrix format from the supplied values.
        def eye(n: Int): Matrix
            Generate a dense Identity Matrix in Matrix format.
        def horzcat(matrices: Array[Matrix]): Matrix
            Horizontally concatenate a sequence of matrices.
        def vertcat(matrices: Array[Matrix]): Matrix
            Vertically concatenate a sequence of matrices.
        def ones(numRows: Int, numCols: Int): Matrix
            Generate a DenseMatrix consisting of ones.
        def rand(numRows: Int, numCols: Int, rng: Random): Matrix
            Generate a DenseMatrix consisting of i.i.d. uniform random numbers.
        def randn(numRows: Int, numCols: Int, rng: Random): Matrix
            Generate a DenseMatrix consisting of i.i.d. gaussian random numbers.
        def speye(n: Int): Matrix
            Generate a sparse Identity Matrix in Matrix format.
        def sprand(numRows: Int, numCols: Int, density: Double, rng: Random): Matrix
            Generate a SparseMatrix consisting of i.i.d. gaussian random numbers.
        def sprandn(numRows: Int, numCols: Int, density: Double, rng: Random): Matrix
            Generate a SparseMatrix consisting of i.i.d. gaussian random numbers.
        def zeros(numRows: Int, numCols: Int): Matrix
            Generate a Matrix consisting of zeros.
    DenseMatrix
        Dense matrix of column major order, 
        val has == and (Int,Int) for indexing 
        new DenseMatrix(numRows: Int, numCols: Int, values: Array[Double])
        new DenseMatrix(numRows: Int, numCols: Int, values: Array[Double], isTransposed: Boolean)
        def apply(i: Int, j: Int): Double
            Gets the (i, j)-th element.
        def colIter: Iterator[Vector]
            Returns an iterator of column vectors.
        def compressed: Matrix
            Returns a matrix in dense column major, dense row major, sparse row major, or sparse column major format, whichever uses less storage.
        def compressedColMajor: Matrix
            Returns a matrix in dense or sparse column major format, whichever uses less storage.
        def compressedRowMajor: Matrix
            Returns a matrix in dense or sparse row major format, whichever uses less storage.
        def copy: DenseMatrix
            Get a deep copy of the matrix.
        def equals(o: Any): Boolean
        def foreachActive(f: (Int, Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse matrix.
        def hashCode(): Int
        val isTransposed: Boolean
            whether the matrix is transposed.
        def multiply(y: Vector): DenseVector
            Convenience method for Matrix-Vector multiplication.
        def multiply(y: DenseVector): DenseVector
            Convenience method for Matrix-DenseVector multiplication.
        def multiply(y: DenseMatrix): DenseMatrix
            Convenience method for Matrix-DenseMatrix multiplication.
        def numActives: Int
            Find the number of values stored explicitly.
        val numCols: Int
            number of columns
        def numNonzeros: Int
            Find the number of non-zero active values.
        val numRows: Int
            number of rows
        def rowIter: Iterator[Vector]
            Returns an iterator of row vectors.
        def toArray: Array[Double]
            Converts to a dense array in column major.
        def toDense: DenseMatrix
            Converts this matrix to a dense matrix while maintaining the layout of the current matrix.
        def toDenseColMajor: DenseMatrix
            Converts this matrix to a dense matrix in column major order.
        def toDenseRowMajor: DenseMatrix
            Converts this matrix to a dense matrix in row major order.
        def toSparse: SparseMatrix
            Converts this matrix to a sparse matrix while maintaining the layout of the current matrix.
        def toSparseColMajor: SparseMatrix
            Converts this matrix to a sparse matrix in column major order.
        def toSparseRowMajor: SparseMatrix
            Converts this matrix to a sparse matrix in row major order.
        def toString(maxLines: Int, maxLineWidth: Int): String
            A human readable representation of the matrix with maximum lines and width
        def toString(): String
            A human readable representation of the matrix
        def transpose: DenseMatrix
            Transpose the Matrix.
        val values: Array[Double]
            matrix entries in column major if not transposed or in row major otherwise
        object DenseMatrix
            def diag(vector: Vector): DenseMatrix
                Generate a diagonal matrix in DenseMatrix format from the supplied values.
            def eye(n: Int): DenseMatrix
                Generate an Identity Matrix in DenseMatrix format.
            def ones(numRows: Int, numCols: Int): DenseMatrix
                Generate a DenseMatrix consisting of ones.
            def rand(numRows: Int, numCols: Int, rng: Random): DenseMatrix
                Generate a DenseMatrix consisting of i.i.d. uniform random numbers.
            def randn(numRows: Int, numCols: Int, rng: Random): DenseMatrix
                Generate a DenseMatrix consisting of i.i.d. gaussian random numbers.
            def zeros(numRows: Int, numCols: Int): DenseMatrix
                Generate a DenseMatrix consisting of zeros.        
    SparseMatrix
        Sparse matrix in CSC format,has == and (Int,Int) for indexing 
        new SparseMatrix(numRows: Int, numCols: Int, colPtrs: Array[Int], rowIndices: Array[Int], values: Array[Double])
        new SparseMatrix(numRows: Int, numCols: Int, colPtrs: Array[Int], rowIndices: Array[Int], values: Array[Double], isTransposed: Boolean)
        def apply(i: Int, j: Int): Double
            Gets the (i, j)-th element.
        def colIter: Iterator[Vector]
            Returns an iterator of column vectors.
        val colPtrs: Array[Int]
            the index corresponding to the start of a new column (if not transposed)
        def compressed: Matrix
            Returns a matrix in dense column major, dense row major, sparse row major, or sparse column major format, whichever uses less storage.
        def compressedColMajor: Matrix
            Returns a matrix in dense or sparse column major format, whichever uses less storage.
        def compressedRowMajor: Matrix
            Returns a matrix in dense or sparse row major format, whichever uses less storage.
        def copy: SparseMatrix
            Get a deep copy of the matrix.
        def equals(o: Any): Boolean
        def foreachActive(f: (Int, Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse matrix.
        def hashCode(): Int
        val isTransposed: Boolean
            whether the matrix is transposed.
        def multiply(y: Vector): DenseVector
            Convenience method for Matrix-Vector multiplication.
        def multiply(y: DenseVector): DenseVector
            Convenience method for Matrix-DenseVector multiplication.
        def multiply(y: DenseMatrix): DenseMatrix
            Convenience method for Matrix-DenseMatrix multiplication.
        def numActives: Int
            Find the number of values stored explicitly.
        val numCols: Int
            number of columns
        def numNonzeros: Int
            Find the number of non-zero active values.
        val numRows: Int
            number of rows
        val rowIndices: Array[Int]
            the row index of the entry (if not transposed).
        def rowIter: Iterator[Vector]
            Returns an iterator of row vectors.
        def toArray: Array[Double]
            Converts to a dense array in column major.
        def toDense: DenseMatrix
            Converts this matrix to a dense matrix while maintaining the layout of the current matrix.
        def toDenseColMajor: DenseMatrix
            Converts this matrix to a dense matrix in column major order.
        def toDenseRowMajor: DenseMatrix
            Converts this matrix to a dense matrix in row major order.
        def toSparse: SparseMatrix
            Converts this matrix to a sparse matrix while maintaining the layout of the current matrix.
        def toSparseColMajor: SparseMatrix
            Converts this matrix to a sparse matrix in column major order.
        def toSparseRowMajor: SparseMatrix
            Converts this matrix to a sparse matrix in row major order.
        def toString(maxLines: Int, maxLineWidth: Int): String
            A human readable representation of the matrix with maximum lines and width
        def toString(): String
            A human readable representation of the matrix
        def transpose: SparseMatrix
            Transpose the Matrix.
        val values: Array[Double]
            nonzero matrix entries in column major (if not transposed)
        object SparseMatrix
            def fromCOO(numRows: Int, numCols: Int, entries: Iterable[(Int, Int, Double)]): SparseMatrix
                Generate a SparseMatrix from Coordinate List (COO) format.
            def spdiag(vector: Vector): SparseMatrix
                Generate a diagonal matrix in SparseMatrix format from the supplied values.
            def speye(n: Int): SparseMatrix
                Generate an Identity Matrix in SparseMatrix format.
            def sprand(numRows: Int, numCols: Int, density: Double, rng: Random): SparseMatrix
                Generate a SparseMatrix consisting of i.i.d.
            def sprandn(numRows: Int, numCols: Int, density: Double, rng: Random): SparseMatrix
                Generate a SparseMatrix consisting of i.i.d.

                
                

//Example - Boston Housing Price Prediction - GradientBoostingRegressor
//Note in GradientBoostedTrees - In Python, predict cannot currently be used within an RDD transformation or action. Call predict directly on the RDD instead.
 
 


// Load data
//"crim","zn","indus","chas","nox","rm","age","dis","rad","tax","ptratio","b","lstat","medv"
val data =  spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw".\data\boston.csv")
headers 

val assembler = new VectorAssembler().setInputCols(data.columns.init).setOutputCol("features")
val df = assembler.transform(data).select($"features", $"medv")
val dataRdd = df.rdd.map( ow => LabeledPoint(row.getDouble(1), Vectors.dense(row.getAs[ML.DenseVector](0).toArray)))
val Array(trainingData, testData) = dataRdd.randomSplit(Array(3.0,1.0), 24)



// Train a GradientBoostedTrees model.
//  Notes: (a) Empty categoricalFeaturesInfo indicates all features are continuous.
//           OR dict(0 =2,4 =10) specifies that feature 0 is binary (taking values 0 or 1) and that feature 4 has 10 categories (values {0, 1, ..., 9})
//         (b) Use more iterations in practice.

// The defaultParams for Regression use SquaredError by default.
import org.apache.spark.mllib.tree.configuration.BoostingStrategy
val boostingStrategy = BoostingStrategy.defaultParams("Regression")
boostingStrategy.numIterations = 3 // Note: Use more iterations in practice.
boostingStrategy.treeStrategy.maxDepth = 5
// Empty categoricalFeaturesInfo indicates all features are continuous.
boostingStrategy.treeStrategy.categoricalFeaturesInfo = Map[Int, Int]()

val model = GradientBoostedTrees.train(trainingData, boostingStrategy)


val predTrain =model.predict(trainingData.map(point => point.features))
val vAPTrain = predTrain.zip(trainingData.map(point => point.label))
val metrics =  new org.apache.spark.mllib.evaluation.RegressionMetrics(vAPTrain) //predictionAndObservations: RDD[(Double, Double)]
metrics.r2 


// Evaluate model on test instances and compute test error
val predictions =model.predict(testData.map(point => point.features))
val valuesAndPreds =predictions.zip(testData.map(point => point.label))
val metrics = new org.apache.spark.mllib.evaluation.RegressionMetrics(valuesAndPreds)
metrics.r2
    
// Squared Error
print("MSE = %s" % metrics.meanSquaredError)
print("RMSE = %s" % metrics.rootMeanSquaredError)
// R-squared
print("R-val squared = %s" % metrics.r2)
// Mean absolute error
print("MAE = %s" % metrics.meanAbsoluteError)
// Explained variance
print("Explained val variance = %s" % metrics.explainedVariance)




//Example - Iris Classifications  - GradientBoostedTrees
//Binary and Multiclass(set numClasses)
    LogisticRegressionWithLBFGS
    DecisionTree
    RandomForest
//Only Binary 
    LogisticRegressionWithSGDD
    SVMWithSGD
    NaiveBayes
    GradientBoostedTrees


//Example 
from sklearn import datasets

// Load data
val data =  spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"data\iris.csv")


val assembler = new VectorAssembler().setInputCols(data.columns.init).setOutputCol("features")
val df_temp = assembler.transform(data).select($"features", $"Name")

//Convert Name string to indexes 
val indexer = new StringIndexer().setInputCol("Name").setOutputCol("target")
val df = indexer.fit(df_temp).transform(df_temp).select("features, "target)

val dataRdd = df.rdd.map( val row => LabeledPoint(row.getDouble(1), Vectors.dense(row.getAs[ML.DenseVector](0).toArray)))

val Array(trainingData, testData) = dataRdd.randomSplit(Array(3.0,1.0), 24)



// Train a GradientBoostedTrees model.
//  Notes: (a) Empty categoricalFeaturesInfo indicates all features are continuous.
//           OR dict(0 =2,4 =10) specifies that feature 0 is binary (taking values 0 or 1) and that feature 4 has 10 categories (values {0, 1, ..., 9})
//         (b) Use more iterations in practice.
// Train a RandomForest model.
// Empty categoricalFeaturesInfo indicates all features are continuous.
val numClasses = 3
val categoricalFeaturesInfo = Map[Int, Int]()
val numTrees = 3 // Use more in practice.
val featureSubsetStrategy = "auto" // Let the algorithm choose.
val impurity = "gini"
val maxDepth = 4
val maxBins = 32

val model = RandomForest.trainClassifier(trainingData, numClasses, categoricalFeaturesInfo,
  numTrees, featureSubsetStrategy, impurity, maxDepth, maxBins)


// Train error 
val predictions =model.predict(trainingData.map(point => point.features))
val predictionAndLabels =predictions.zip(trainingData.map(point => point.label))
val metrics = new MulticlassMetrics(predictionAndLabels)
>>> metrics.labels
res14: Array[Double] = Array(0.0, 1.0, 2.0)
//fMeasure(label =None,beta =None) , generally val beta =2 or 0.5 for F2 or F0.5 
metrics.labels.map( val e => metrics.fMeasure(e))


// Evaluate model on test instances and compute test error
val predictions =model.predict(testData.map(point => point.features))
val predictionAndLabels =predictions.zip(testData.map(point => point.label))
val metrics = new MulticlassMetrics(predictionAndLabels)
//fMeasure(label =None,beta =None) , generally val beta =2 or 0.5 for F2 or F0.5 
metrics.labels.map( val e => metrics.fMeasure(e))
    
// Squared Error, below all takes Label 
metrics.confusionMatrix
res23: org.apache.spark.mllib.linalg.Matrix =
17.0  0.0   0.0
0.0   11.0  0.0
0.0   4.0   9.0


// Statistics by class
"""
Value 1 is te Best 
confusion matrix 
    for binary: two rows and two columns
    that reports the number of true positives(TP), false negatives(FN), 
    and 2nd row as false positives(FP), and true negatives(TN)
precision 
    the ratio tp / (tp + fp) 
    where tp is the number of true positives and fp the number of false positives. 
    The precision is intuitively the ability of the classifier not to label as positive a sample that is negative.
recall 
    ratio tp / (tp + fn) 
    where tp is the number of true positives and fn the number of false negatives. 
    The recall is intuitively the ability of the classifier to find all the positive samples.
F-beta score
    weighted harmonic mean of the precision and recall, 
    where an F-beta score reaches its best value at 1 and worst score at 0.
    The F-beta score weights recall more than precision by a factor of beta. 
    val beta == 1.0 means recall and precision are equally important.
"""

val labels = dataRdd.map(point => point.label).distinct.collect
for(label <- labels.sorted){
    println(s"Class $label val precision = ${metrics.precision(label)}")
    println(s"Class $label val recall = ${metrics.recall(label)}" )
    println(s"Class $label F1 val Measure = ${metrics.fMeasure(label,beta =1.0)}" )
}









///*** Additional Structured streaming 
///Complete example with socket 
//https://eternallybored.org/misc/netcat/ 
$ nc -lk 9999

   
    
//code example 
import org.apache.spark.sql.{functions=>F}
import org.apache.spark.sql._


object StructuredNetworkWordCount {
  def main(args: Array[String]) {
    if (args.length < 2) {
      System.err.println("Usage: StructuredNetworkWordCount <hostname> <port>")
      System.exit(1)
    }

    val host = args(0)
    val port = args(1).toInt

    val spark = SparkSession
      .builder
      .appName("StructuredNetworkWordCount")
      .getOrCreate()

    import spark.implicits._

    // Create DataFrame representing the stream of input lines from connection to host:port
    val lines = spark.readStream
      .format("socket")
      .option("host", host)
      .option("port", port)
      .load()

    //[("value", "string")]
    // Split the lines into words
    val words = lines.select(
        // explode turns each item in an array into a separate row
        F.explode(
            F.split($"value", " ")
        ).alias("word")
    )

    // Generate running word count
    val wordCounts = words.groupBy("word").count()

    // Start running the query that prints the running counts to the console
    val query = wordCounts.
        writeStream.
        outputMode("complete").
        format("console").
        start()
        
    //query.awaitTermination()
    //in REPL 
    query.stop() 
  }
}




///Main methods of Reader and Write and Triggers 
//show the API reference 

///Available Triggers  
Trigger
    ProcessingTime
        Trigger.ProcessingTime(long intervalMs)
        Trigger.ProcessingTime(Duration interval)
        Trigger.ProcessingTime(String interval)
    Once
        Trigger.Once


///Output Modes
//Append mode (default) 

///Sink vs Supported Output mode 
//use checkpointLocation for Fault-tolerant:Yes
File Sink ("csv", "text", "json",....)
    Append 
        Fault-tolerant:Yes (exactly-once) , use checkpointLocation
        Supports writes to partitioned tables. 
Kafka Sink 
    Append, Update, Complete 
    Fault-tolerant:Yes (at-least-once) use checkpointLocation
Console Sink ("console")
    Append, Update, Complete 
        numRows: Number of rows to print every trigger (default: 20) 
        truncate: Whether to truncate the output if too long (default: true)  No  
Memory Sink ("memory")
    create a DF in memory 
    Fault-tolerant:Yes
    Append, Complete 
        But in Complete Mode, restarted query will recreate the full table. 
        Table name is the queryName.
        
        
///Query Type & Supported Output Modes
//"update" mode works with all except use Append with join queries 
Queries with aggregation 
    Aggregation on event-time with watermark 
        Append
            Append mode uses watermark to drop old aggregation state. 
            But the output of a windowed aggregation is delayed the late threshold specified in `withWatermark()` as by the modes semantics, 
            rows can be added to the Result Table only once after they are finalized (i.e. after watermark is crossed). 
        Update
            Update mode uses watermark to drop old aggregation state. 
        Complete 
            Complete mode does not drop old aggregation state since 
            by definition this mode preserves all data in the Result Table.  
    Other aggregations 
        Complete, Update 
            Since no watermark is defined  
            old aggregation state is not dropped. 
            Append mode is not supported as aggregates can update thus violating the semantics of this mode.  
Queries with joins 
    Append 
        Update and Complete mode not supported yet. 
Other queries 
    Append, Update 
        Complete mode not supported as it is infeasible to keep all unaggregated data in the Result Table.  

//Example - rate keeps on increasing number , schema : timestamp,value as long type 
//Append is default 
val query = spark.  
  readStream.
  format("rate").  
  option("rowsPerSecond", 1).
  load().
  writeStream.
  format("console").
  option("truncate", false).
  trigger(processingTime ="10 second"). 
  queryName("rate-once").
  start()
  
val query2 = spark.  
  readStream.
  format("rate").  
  option("rowsPerSecond", 1).
  load().
  writeStream.
  format("console").
  outputMode("complete").
  option("truncate", false).
  trigger(processingTime ="30 second"). 
  queryName("rate-once").
  start()
  
//purge all 
spark.streams.active 
[q.stop() for q in spark.streams.active ]
  

>>> query.isActive
false


>>> import pprint
>>> pprint.pprint(query.lastProgress)
{
  "id" : "2ae4b0a4-434f-4ca7-a523-4e859c07175b",
  "runId" : "24039ce5-906c-4f90-b6e7-bbb3ec38a1f5",
  "name" : "rate-once",
  "timestamp" : "2017-07-04T18:39:35.998Z",
  "numInputRows" : 0,
  "processedRowsPerSecond" : 0.0,
  "durationMs" : {
    "addBatch" : 1365,
    "getBatch" : 29,
    "getOffset" : 0,
    "queryPlanning" : 285,
    "triggerExecution" : 1742,
    "walCommit" : 40
  },
  "stateOperators" : [ ],
  "sources" : [ {
    "description" : "RateSource[val rowsPerSecond =1,rampUpTimeSeconds =0,numPartitions =8]",
    "startOffset" : null,
    "endOffset" : 0,
    "numInputRows" : 0,
    "processedRowsPerSecond" : 0.0
  } ],
  "sink" : {
    "description" : "org.apache.spark.sql.execution.streaming.ConsoleSink@7dbf277"
  }
}


///groupBy Operator 
//already seen earlier, lets see again 
//only supports Complete 
groupBy(*cols)
    cols � list of columns to group by. 
    Each element should be a column name (string) or an expression (Column). 
    Note .groupBy result is GroupedData , not DataFrame , 
    hence use .agg() to get DataFrame and then use all DF methods 
    

class GroupedData
    agg(*exprs)
        exprs � a dict mapping from column name (string)(could be *) to aggregate functions (string), 
        or a list/varargs of Column. 
    avg(*cols)
        cols � list/var args  of column names (string). 
               Non-numeric columns are ignored. 
    count()
    max(*cols)
    mean(*cols)
    min(*cols)
    pivot(pivot_col,values =None)
        pivot_col � Name of the column to pivot ie grouping on unique values of this column
        values � List of values of pivot_col on whose values above grouping would be done 
                 if None, all unique values of pivot_col is used 
    sum(*cols)
//Aggregate function
sql.functions.
    avg(col)
    count(col)
    countDistinct(col, *cols)    
    first(col,ignorenulls =false)
    grouping(col)
        indicates whether a specified column in a GROUP BY list is aggregated or not, 
        returns 1 for aggregated or 0 for not aggregated in the result set.
    grouping_id(*cols)
        returns the level of grouping, equals to
            (grouping(c1) << (n-1)) + (grouping(c2) << (n-2)) + ... + grouping(cn)
        The list of columns should match with grouping columns exactly, 
        or empty (means all the grouping columns).  
    kurtosis(col)
    last(col,ignorenulls =false)
    max(col)
    mean(col)
    min(col)
    skewness(col)
    stddev(col)
    stddev_pop(col)
    stddev_samp(col)
    sum(col)
    sumDistinct(col)
    var_pop(col)
    var_samp(col)
    variance(col)
 
//Exmple 

$ nc -lk 9999 

//Check timestamp 
///Some bug? - 16.6 m resolution 
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val q = spark.readStrea .
  option("includeTimestamp", "true").
  format("socket").
  option("host", "localhost").
  option("port", 9999).
  load().select(F.from_unixtime(F.col("timestamp").cast("long")*1000).alias("timestamp"), F.col("value")).
  writeStream.
  outputMode("append").option("truncate", "false").
  format("console").trigger(Trigger.ProcessingTime(10.seconds)).
  start()

///Note 
Any query           append, update 
join                append
groupby with WM     append, update, complete(no dropping) 
groupby             update, complete 

///groupBy only supports Complete , other wise use Append/Update 
val lines = spark.readStream.
  option("includeTimestamp", "true").
  format("socket").
  option("host", "localhost").
  option("port", 9999).
  load()
  //.withColumn("timestamp", current_timestamp())



>>> lines.printSchema()
root
 |-- value: string (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 
 
 
val words = lines.select(F.split(F.col("value"), raw"\s+").alias("words"), F.col("timestamp"))
val all_words = words.select(F.explode(F.col("words")).alias("word"), F.col("timestamp"))

//val counter = all_words.groupBy("word").count() ///org.apache.spark.sql.DataFrame = [value: string, count: bigint]
val counter = all_words.groupBy("word").agg(F.count("word").alias("count"), F.first("timestamp"), F.last("timestamp")).\
    select("*")

val query = counter.writeStream\
  .outputMode("complete")\
  .format("console").trigger(Trigger.ProcessingTime(10.seconds))\
  .start()

query.stop()


///groupByKey Operator - typed, groupBy - unTyped 


import spark.implicits._

case class Token(name: String, productId: Int, score: Double)
val data = Seq(
  Token("aaa", 100, 0.12),
  Token("aaa", 200, 0.29),
  Token("bbb", 200, 0.53),
  Token("bbb", 300, 0.42))
  
val tokens = data.toDS.cache 


scala> tokens.show
+----+---------+-----+
|name|productId|score|
+----+---------+-----+
| aaa|      100| 0.12|
| aaa|      200| 0.29|
| bbb|      200| 0.53|
| bbb|      300| 0.42|
+----+---------+-----+

scala> tokens.groupBy('name).avg().show
+----+--------------+----------+
|name|avg(productId)|avg(score)|
+----+--------------+----------+
| aaa|         150.0|     0.205|
| bbb|         250.0|     0.475|
+----+--------------+----------+

scala> tokens.groupBy('name, 'productId).agg(Map("score" -> "avg")).show
+----+---------+----------+
|name|productId|avg(score)|
+----+---------+----------+
| aaa|      200|      0.29|
| bbb|      200|      0.53|
| bbb|      300|      0.42|
| aaa|      100|      0.12|
+----+---------+----------+

scala> tokens.groupBy('name).count.show
+----+-----+
|name|count|
+----+-----+
| aaa|    2|
| bbb|    2|
+----+-----+

scala> tokens.groupBy('name).max("score").show
+----+----------+
|name|max(score)|
+----+----------+
| aaa|      0.29|
| bbb|      0.53|
+----+----------+

scala> tokens.groupBy('name).sum("score").show
+----+----------+
|name|sum(score)|
+----+----------+
| aaa|      0.41|
| bbb|      0.95|
+----+----------+

scala> tokens.groupBy('productId).sum("score").show  //'
+---------+------------------+
|productId|        sum(score)|
+---------+------------------+
|      300|              0.42|
|      100|              0.12|
|      200|0.8200000000000001|
+---------+------------------+

///Typed Grouping�groupByKey Operator
DS.groupByKey[K: Encoder](func: T => K): KeyValueGroupedDataset[K, T]
//Need Typed column,
//IN is V of KeyValueGroupedDataset[K, V] 
import org.apache.spark.sql.expressions.scalalang.typed 
    def  avg[IN](f: (IN) => Double): TypedColumn[IN, Double] 
    def  count[IN](f: (IN) => Any): TypedColumn[IN, Long] 
    def  sum[IN](f: (IN) => Double): TypedColumn[IN, Double] 
    def  sumLong[IN](f: (IN) => Long): TypedColumn[IN, Long] 

//use Column.as[U] (as last operator) or typed.method[Token] to get TypedColumn 


scala> tokens.groupByKey(_.productId).count.orderBy($"value").show
+-----+--------+
|value|count(1)|
+-----+--------+
|  100|       1|
|  200|       2|
|  300|       1|
+-----+--------+

import org.apache.spark.sql.expressions.scalalang._
val q = tokens.
  groupByKey(_.productId).
  agg(typed.sum[Token](_.score)).
  toDF("productId", "sum").
  orderBy('productId)   //'
scala> q.show
+---------+------------------+
|productId|               sum|
+---------+------------------+
|      100|              0.12|
|      200|0.8200000000000001|
|      300|              0.42|
+---------+------------------+

         

         
///HandsOn - groupByKey Operator - typed

// input stream

case class Data(timestamp:java.sql.Timestamp, data:Long,deviceId:Double)

val signals = spark.
  readStream.
  format("rate").
  option("rowsPerSecond", 1).
  load().
  withColumn("value", F.col("value") % 10).  
  withColumn("deviceId", F.round(F.rand() *10, 0)). 
  //rename value to data as value is ambiguous 
  select($"timestamp", $"value".alias("data"), $"deviceId").as[Data]  //attributes name must be same 
  
>>> signals.printSchema()
root
 |-- timestamp: timestamp (nullable = true)
 |-- value: long (nullable = true)
 |-- deviceId: double (nullable = false)
 
//Need Typed column,
//IN is V of KeyValueGroupedDataset[K, V] 
import org.apache.spark.sql.expressions.scalalang.typed 
    def  avg[IN](f: (IN) => Double): TypedColumn[IN, Double] 
    def  count[IN](f: (IN) => Any): TypedColumn[IN, Long] 
    def  sum[IN](f: (IN) => Double): TypedColumn[IN, Double] 
    def  sumLong[IN](f: (IN) => Long): TypedColumn[IN, Long] 

//Example - use .as[U] (last) or typed.method[Data] to get TypedColumn 
import org.apache.spark.sql.expressions.scalalang._ 

//Dataset[(Int, Double)]
val signalsByDevice = signals.groupByKey( data => if (data.deviceId < 5) 0 else 1).  //basedon deviceId
//res105: org.apache.spark.sql.KeyValueGroupedDataset[Int,Data] = KeyValueGroupedDataset: [key: [value: int], value: [timestamp: timestamp, data: bigint ... 1 more field(s)]]
                  agg(typed.sum[Data](_.data).alias("sumValues").as[Double]) //org.apache.spark.sql.Dataset[(Int, Double)]

//Dataset[(Int, Set[Long], Set[Double])]
val signalsByDevice = signals.groupByKey( data => if (data.deviceId < 5) 0 else 1). 
             agg(F.collect_set(F.col("data")).alias("values").as[Set[Long]], F.collect_set(F.col("deviceId")).alias("devices").as[Set[Double]])
    
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._    
             
val query = signalsByDevice.writeStream.
  outputMode("complete").
  format("console").trigger(Trigger.ProcessingTime(10.seconds)).
  start()
  


  
  
  
  
  
  
  
  
///dropDuplicates Operator�Streaming Deduplication
DS.dropDuplicates(col1: String, cols: String*): Dataset[T] 
//For a streaming Dataset, dropDuplicates will keep all data across triggers 
//as intermediate state to drop duplicates rows. 
//You can use withWatermark operator to limit how late the duplicate data can be 
//and system will accordingly limit the state. 
//In addition, too late data older than watermark will be dropped to avoid any possibility of duplicates.
//Subset is list of ColName strings 

 
 
///HandsOn- DropDuplicates 
// Start a streaming query

val rates = spark. 
  readStream.
  format("rate").  
  option("rowsPerSecond", 1).
  load()  //timestamp,value as long type 

val ids = rates.withColumn("id", F.col("value") % 5).dropDuplicates("id")

>>> ids.explain(True)
== Parsed Logical val Plan ==
Deduplicate [id//14]
+- AnalysisBarrier
      +- Project [timestamp//2, value//3L, cast(value//3L as string) AS id//14]
         +- StreamingRelationV2 org.apache.spark.sql.execution.streaming.RateSourceProvider@4df15842, rate, Map(rowsPerSecond -> 1), [timestamp//2, value//3L], StreamingRelation DataSource(org.apache.spark.sql.SparkSession@4e64ab0b,rate,List(),None,List(),None,Map(rowsPerSecond -> 1),None), rate, [timestamp//0, value//1L]



//Write 
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val q = ids.
  writeStream.
  format("memory").
  queryName("dups").
  outputMode("append").
  trigger(Trigger.ProcessingTime(30.seconds)).
  option("checkpointLocation", "checkpoint_dups_1"). 
  start()

//query.awaitTermination()
//query.stop() 
//q.processAllAvailable()

// Check out how dropDuplicates removes duplicates
// --> per single streaming batch (easy)
>>> spark.table("dups").show()
+----+---+
|time| id|
+----+---+
|   1|  1|
+----+---+


// --> across streaming batches (harder)
>>> spark.table("dups").show()
+----+---+
|time| id|
+----+---+
|   1|  1|
|   5|  2|
+----+---+

// Check out the internal state, Note numRowsUpdated is zero 

// Check out the internal state
scala> println(q.lastProgress.stateOperators(0).prettyJson)
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 1,
  "memoryUsedBytes" : 17751
}

// You could use web UI"s SQL tab instead
// Use Details for Query

>>>  spark.table("dups").show(truncate =false)
+----+---+
|time| id|
+----+---+
|   1|  1|
|   5|  2|
+----+---+

// Check out the internal state
// Check out the internal state
scala> println(q.lastProgress.stateOperators(0).prettyJson)
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 1,
  "memoryUsedBytes" : 17751
}


// Restart the streaming query
q.stop()

//note memory sink with complete is only supported with aggregation 

val counts = ids.groupBy("id").agg(F.first(F.col("timestamp")).alias("first_time"))
>>> counts.explain()
== Physical val Plan ==
*HashAggregate(keys =[id//246],functions =[first(time//255L, false)])

import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val q = counts. 
  writeStream.
  format("memory").
  queryName("dups").
  outputMode("complete"). 
  trigger(Trigger.ProcessingTime(30.seconds)).
  option("checkpointLocation", "checkpoint-dir"). 
  start()


// wait till the batch is triggered
>>>  spark.table("dups").show(truncate =false)








    
    
///withWatermark and group by with window 

withWatermark(eventTimeColAsString, delayThreshold)
    The current watermark is computed by looking at the maximum eventTime seen across 
    all of the partitions in a query minus a user-specified delayThreshold. 
    
    Due to the cost of coordinating this value across partitions, the actual watermark used is only guaranteed to be at least delayThreshold behind the actual event time.
    In some cases Spark may still process records that arrive more than delayThreshold late.

    delayThreshold is in the form of "2 minutes"
    
    Output mode must be Append or Update
    The aggregation must have either the eventTime column,  or a window on the event-time column
    withWatermark must be called before the aggregation , groupBy
    withWatermark must be called on the same column as the timestamp(eventTime) column used in the aggregate
    Spark might drop data if late as long as possible 
    
functions.window(eventTimeCol, windowDuration,slideDuration =None,startTime =None)
    Durations are provided as strings, e.g. "1 second", "1 day 12 hours", "2 minutes". 
    Valid interval strings are "week", "day", "hour", "minute", "second", "millisecond", "microsecond". 
    If the slideDuration is not provided, the windows will be tumbling windows.
    The output column will be a struct called "window" by default with the nested columns "start" and "end", 
    where "start" and "end" will be of org.apache.spark.sql.types.TimestampType.

    Only one window expression is supported in a query.
    null values are filtered out in window expression.

    

///With Streaming 
//timestamp, value is schema 
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val rates = spark. 
  readStream.
  format("rate"). 
  option("rowsPerSecond", 1).
  load().
  withColumnRenamed("timestamp", "eventTime").
  select(F.col("eventTime"), F.col("value"),(F.col("value") % 5).alias("mod")).
  withWatermark("eventTime", "2 minutes").
  groupBy(F.window($"eventTime", "1 minutes"), F.col("mod")).
  agg(F.collect_list("value").alias("clist"), F.first("eventTime").alias("f"), F.count("value").alias("c")).
  select("window","clist","mod", "c", "f").
  writeStream.
  format("console").
  outputMode("update").
  option("truncate", false).
  trigger(Trigger.ProcessingTime(30.seconds)). 
  queryName("rate-once").
  start()


  
  
  
  
  
  
  
  
///Streaming Joins 
//Joins can be cascaded, that is,df1.join(df2, ...).join(df3, ...).join(df4, ....).
//use joins only when the query is in Append output mode. 
//you cannot use other non-map-like operations before joins. 
//for example, Cannot use streaming aggregations before joins.

//Left Input     Right Input     Join Type
Static          Static          All types Supported, 
Stream          Static          Inner ,Left Outer 
Static          Stream          Inner Supported, Right Outer                                
Stream Stream                   inner, left outer and right outer (must have watermark)
                                Inner Supported, optionally specify watermark on both sides + time constraints for state cleanup  
                                Left Outer Conditionally supported, must specify watermark on right + time constraints for correct results, optionally specify watermark on left for all state cleanup  
                                Right Outer Conditionally supported, must specify watermark on left + time constraints for correct results, optionally specify watermark on right for all state cleanup  
                                Full Outer Not supported 

///Note 
Any query           append, update 
join                append
groupby with WM     append, update, complete(no dropping) 
groupby             update, complete 
                        
//Example 
val impressions = spark.  
  readStream.
  format("rate").  
  option("rowsPerSecond", 1).
  load().
  withColumnRenamed("timestamp", "impressionTime").
  select(F.col("impressionTime"), F.col("value"),(F.col("value") % 10).alias("impressionAdId"))

val clicks = spark.  
  readStream.
  format("rate").  
  option("rowsPerSecond", 1).
  load().
  withColumnRenamed("timestamp", "clickTime").
  select(F.col("clickTime"), F.col("value"),(F.col("value") % 10).alias("clickAdId"))

  
// Apply watermarks on event-time columns
val impressionsWithWatermark = impressions.withWatermark("impressionTime", "1 minute")
val clicksWithWatermark = clicks.withWatermark("clickTime", "2 minute")

// Join with event-time constraints
val data = impressionsWithWatermark.join(
  clicksWithWatermark,
  F.expr("""
    clickAdId = impressionAdId AND
    clickTime >= impressionTime AND
    clickTime <= impressionTime + interval 1 minute
    """), "inner")
  
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val q = data.writeStream.
  format("console").
  outputMode("append").
  option("truncate", false).
  trigger(Trigger.ProcessingTime(30.seconds)). 
  queryName("rate-once").
  start() 
  
  
  
///*** Example - Spark Streaming of FileSink eg csv 
///Break 
def breakFiles(file:String, n:Int, ext_length:val Int = 3):val Unit = {
    import java.io._
    def write(fileName:String, x:List[String]) {
        val pw = new PrintWriter(new File(fileName))
        x.foreach{val line => pw.println(line)}
        pw.close    
    }    
    def autoClose(f: => scala.io.Source)={
        val ls = f.getLines.toList
        f.close
        ls
    }
    val (onlyFileName, ext) = (file.slice(0, file.size-ext_length-1), file.slice(file.size-ext_length, file.size))
    val names = (1 to n).toList.map{val i => s"$onlyFileName$i.$ext"}
    val lines = autoClose(scala.io.Source.fromFile(file)) 
    val howmany = lines.size / n 
    lines.grouped(howmany).toList.zip(names).foreach{case (lst,n) => write(n,lst)}
}


///Example  CSV

///Schema 
val mySchema = StructType(Array(
 StructField("id", IntegerType),
 StructField("name", StringType),
 StructField("year", IntegerType),
 StructField("rating", DoubleType),
 StructField("duration", IntegerType)
))
///Put csv file (eg check data/kakfa-csv.csv) in ./kafka-csv dir
val df = spark.readStream.schema(mySchema).csv("./stream-csv/*.csv")

///Publish the Stream to Kafka
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val sq1 = df.selectExpr("CAST(id AS STRING) AS key", "to_json(struct(*)) AS value").
  writeStream.
  format("csv").option("header","true").
  option("checkpointLocation", "./csv_streaming"). /// So whenever there is restart, spark first recovers the old state and then start processing data from the stream
  trigger(Trigger.ProcessingTime(30.seconds)).start( "csv-out" )
  
///put in console 
val sq2 = df.writeStream.
    format("console").
    option("truncate","false").trigger(Trigger.ProcessingTime(10.seconds)).start()
    
///sq.awaitTermination()  ///blocks 
///sq.stop() 
sq1.processAllAvailable()  ///testng purpose only , only once triggered   
sq2.processAllAvailable() 






  
  
  
  
  
///HANDSON -kafka   groupBy Streaming Aggregation with Append Output Mode
///Append output mode requires that a streaming aggregation defines a watermark 
//(using withWatermark operator) on at least one of the grouping expressions 
//(directly or using window function).

//withWatermark operator has to be used before the aggregation operator (for the watermark to be used).


//Sorting is only supported on streaming aggregated Datasets with Complete output mode.


//Step1 
//create a file events.txt - seconds,id, batch 
1,1,1
15,2,1

//https://github.com/edenhill/kafkacat
$ kafkacat -P -b localhost:9092 -t topic1 -l events.txt 

// Alternatively (and slower due to JVM bootup)
$ cat events.txt  | kafka-console-producer.bat --broker-list localhost:9092 --topic topic1


//Start 
$ spark-shell --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0

1. Create idsPerbatch DF containing cols 
        event_time  <- timestamp based on seconds from input  
        id  <- id from input (string)
        batch <- batch from input (int) 
   Then Apply watermark on event_time and 10 seconds 
   and grouping on event_time
   Then collect all batch and id and event-time 
2. Dump this to console with append mode and processing time 5 seco
   

val idsPerBatch = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load().
  withColumn("tokens", F.split(F.col("value"), ",")).
  withColumn("seconds", F.col("tokens").getItem(0).cast("long")).
  withColumn("event_time", F.to_timestamp(from_unixtime(F.col("seconds")))). //<-- Event time has to be a timestamp
  withColumn("id", F.col("tokens").getItem(1)).
  withColumn("batch", F.col("tokens").getItem(2).cast("int")).
  withWatermark("event_time","10 seconds"). // <-- define watermark (before groupBy!)
  groupBy("event_time"). // <-- use event_time for grouping
  agg(F.collect_list("batch").alias("batches"), F.collect_list("id").alias("ids")).
  withColumn("event_time", F.to_timestamp(F.col("event_time"))) // <-- convert to human-readable date

>>> idsPerBatch.explain()

// Start the query and hence StateStoreSaveExec
// Note Append output mode
import org.apache.spark.sql.streaming._
import scala.concurrent.duration._

val sq = idsPerBatch.
  writeStream.
  format("console").
  option("truncate", false).
  trigger(Trigger.ProcessingTime(10.seconds)).
  outputMode("append"). // <-- Append output mode
  start()


// there"s only 1 stateful operator and hence 0 for the index in stateOperators
>>> println(sq.lastProgress["stateOperators"[0])
{
  "numRowsTotal" : 0,
  "numRowsUpdated" : 0,
  "memoryUsedBytes" : 77
}

// Current watermark
// We"ve just started so it"s the default start time
>>> println(sq.lastProgress["eventTime"]["watermark"])
1970-01-01T00:00:00.000Z


// it"s Append output mode so numRowsTotal is.
// no keys were available earlier (it"s just started!) and so numRowsUpdated is 0
>>> println(sq.lastProgress["stateOperators"[0])
{
  "numRowsTotal" : 2,
  "numRowsUpdated" : 2,
  "memoryUsedBytes" : 669
}

// Current watermark
// One streaming batch has passed so it"s still the default start time
// that will get changed the next streaming batch
// watermark is always one batch behind
>>> println(sq.lastProgress["eventTime"]["watermark"])
1970-01-01T00:00:00.000Z

// Could be 0 if the time to update the lastProgress is short
// FIXME Explain it in detail
>>> println(sq.lastProgress["numInputRows"])
2



sq.stop()


  
  
  
  
  
  
  
  
  
  
///*** Advanced Concepts 

///+++Broadcast Joins (aka Map-Side Joins)

//Spark SQL uses broadcast join (aka broadcast hash join) instead of hash join 
//to optimize join queries when the size of one side data is below spark.sql.autoBroadcastJoinThreshold.

//Broadcast join can be very efficient for joins between a large table (fact) 
//with relatively small tables (dimensions) that could then be used to perform a star-schema join. 
//It can avoid sending all data of the large table over the network.


//broadcast join is also called a replicated join (in the distributed system community) 
//or a map-side join (in the Hadoop community).


val threshold =  spark.conf.get("spark.sql.autoBroadcastJoinThreshold")
threshold.toInt / 1024 / 1024 //10

val q = spark.range(100).alias("a").join(spark.range(100).alias("b")).where("a.id == b.id")
>>> q.explain()
== Physical val Plan ==
*(2) BroadcastHashJoin [id//8L], [id//11L], Inner, BuildRight
:- *(2) Range (0, 100,step =1,splits =4)
+- BroadcastExchange HashedRelationBroadcastMode(List(input[0, bigint, false]))
   +- *(1) Range (0, 100,step =1,splits =4)

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
val q = spark.range(100).alias("a").join(spark.range(100).alias("b")).where("a.id == b.id")
>>> q.explain()
== Physical val Plan ==
*(5) SortMergeJoin [id//17L], [id//20L], Inner
:- *(2) Sort [id//17L ASC NULLS FIRST], false, 0
:  +- Exchange hashpartitioning(id//17L, 200)
:     +- *(1) Range (0, 100,step =1,splits =4)
+- *(4) Sort [id//20L ASC NULLS FIRST], false, 0
   +- ReusedExchange [id//20L], Exchange hashpartitioning(id//17L, 200)

//Force BroadcastHashJoin with broadcast hint (as function)
val qBroadcast = spark.range(100).alias("a").join(F.broadcast(spark.range(100)).alias("b")).where("a.id == b.id")
>>> qBroadcast.explain()
== Physical val Plan ==
*(2) BroadcastHashJoin [id//29L], [id//32L], Inner, BuildRight
:- *(2) Range (0, 100,step =1,splits =4)
+- BroadcastExchange HashedRelationBroadcastMode(List(input[0, bigint, false]))
   +- *(1) Range (0, 100,step =1,splits =4)

   
   
///+++ Spark with DISTRIBUTE BY & CLUSTER BY 
DISTRIBUTE BY           or df.repartition(col)
    Repartitions a DataFrame by the given expressions ie all the rows for which this expression is equal are on the same partition
    The number of partitions is equal to spark.sql.shuffle.partitions. 
    //Example - All same key goes to one partition 
    //SQL 
    SET spark.sql.shuffle.partitions = 2 //configures the number of partitions that are used when shuffling data for sql joins or aggregations
    SELECT * FROM df DISTRIBUTE BY key
    //DF 
    val df = spark.read.option("header","true").option("inferSchema", True).csv("./data/spark/example.csv")
    df.createOrReplaceTempView("df")
    spark.conf.set("spark.sql.shuffle.partitions", 2)
    import org.apache.spark.sql.{functions=> F}
    //repartition(numPartitions, *cols) , numpartitions can be col or int 
    df.repartition(F.col("key")) //or df.repartition(2, F.col("key"))
    df.rdd.glom().collect()
SORT BY                 or df.sortWithinPartitions(col)
    Sorts data within partitions by the given expressions.
    Note that this operation does not cause any shuffle.
    //In SQL:
    SELECT * FROM df SORT BY key
    //Equivalent in DataFrame API:
    //sortWithinPartitions(*cols, **kwargs)
    df.sortWithinPartitions("key")
CLUSTER BY              or df.repartition(col).sortWithinPartitions(col)
    a shortcut for using distribute by and sort by together on the same set of expressions.
    //In SQL:
    SET spark.sql.shuffle.partitions = 2
    SELECT * FROM df CLUSTER BY key
    //Equivalent in DataFrame API:
    spark.conf.set("spark.sql.shuffle.partitions", 2)
    df.repartition(F.col("key")).sortWithinPartitions("key") //df.repartition(2, F.col("key"))

///UseCase 
1.Skewed Data
    Your DataFrame is skewed if most of its rows are located on a small number of partitions, 
    while the majority of the partitions remain empty. 
    //Example 
    SET spark.sql.shuffle.partitions = 5
    SELECT * FROM df DISTRIBUTE BY key, value
    //or 
    spark.conf.set("spark.sql.shuffle.partitions", 5)
    //OR : df.repartition(5, F.col("key"))
    df.repartition(F.col("key"), F.col("value")).sortWithinPartitions("key", "value")

2.Multiple Joins
    When you join two DataFrames, Spark will repartition them both by the join expressions. 
    This means that if you are joining to the same DataFrame many times (by the same expressions each time), 
    Spark will be doing the repartitioning of this DataFrame each time.
    //Example 
    val data =(1 to 100).toList.map(key => (key, 1))
    val data1 =  scala.util.Random.shuffle(data)
    val data2 =  scala.util.Random.shuffle(data)
    
    //disable Broadcast join for experiment 
    sc.parallelize(data).toDF("a", "b").registerTempTable("df")
    sc.parallelize(data1).toDF("a", "b").registerTempTable("df1")
    sc.parallelize(data2).toDF("a", "b").registerTempTable("df2")

    spark.sql("SET spark.sql.autoBroadcastJoinThreshold = -1")

    spark.sql("CACHE TABLE df")     //df.cache()
    spark.sql("SELECT * FROM df JOIN df1 ON df.a = df1.a").show()
    spark.sql("SELECT * FROM df JOIN df2 ON df.a = df2.a").show()
    //or 
    val df = sc.parallelize(data).toDF("a", "b")
    val df1 = sc.parallelize(data1).toDF("a", "b")
    val df2 = sc.parallelize(data2).toDF("a", "b")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
    df.cache()
    df.join(df1).where(df("a") === df1("a")).show()  //note string version or query  is not suitable 
    df.join(df2).where(df("a") === df2("a")).show()
    //Check the result in SparkUI :Three jobs were executed. df is repartitioned two times 

    //Solution - repartition the DataFrame manually, only once, at the very beginning.
    val dfDist = spark.sql("SELECT * FROM df DISTRIBUTE BY a")
    dfDist.registerTempTable("df_dist")
    spark.sql("CACHE TABLE df_dist")
    spark.sql("SELECT * FROM df_dist JOIN df1 ON df_dist.a = df1.a").show()
    spark.sql("SELECT * FROM df_dist JOIN df2 ON df_dist.a = df2.a").show()
    //Check the result in SparkUI :Three jobs were executed. both of the jobs, one stage is skipped and the repartitioned DataFrame is taken from the cache
    import org.apache.spark.sql.functions as F
    val dfDist = df.repartition(F.col("a"))
    dfDist.cache()
    dfDist.join(df1).where("dfDist.a == df1.a").show()
    dfDist.join(df2).where("dfDist.a == df2.a").show()
    
    //Stage skipped means that data has been fetched from cache and there was no need to re-execute given stage. 
    //If  the next stage requires shuffling (*ByKey). Spark automatically caches generated data
    //in large number of intermediate files on disk, these files are preserved until the corresponding RDDs are no longer used and are garbage collected. 
    //This is done so the shuffle files don�t need to be re-created if the lineage is re-computed.
    
       
3.Sorting in Join
    Spark uses sort-based shuffle by default (as opposed to hash-based shuffle).
    when you join two DataFrames, Spark will repartition them both by the join expressions 
    and sort them within the partitions! 
    That means the code above can be further optimised by adding sort by to it:
    SELECT * FROM df DISTRIBUTE BY a SORT BY a
    //OR 
    SELECT * FROM df CLUSTER BY a
    //or 
    val dfDist = df.repartition(F.col("a")).sortWithinPartitions("a")

4.Multiple Join on Already Partitioned DataFrame
    if the DataFrame that you will be joining to is already partitioned correctly, 
    use only sort by , Donot use distribute by
    //Example 
    val dfDist = sql("SELECT a, count(*) FROM some_other_df GROUP BY a SORT BY a")
    dfDist.registerTempTable("df_dist")
    spark.sql("CACHE TABLE df_dist")
    spark.sql("SELECT * FROM df_dist JOIN df1 ON df_dist.a = df1.a").show()
    spark.sql("SELECT * FROM df_dist JOIN df2 ON df_dist.a = df2.a").show()  
    //or 
    val dfDist = df.sortWithinPartitions("a")


    
    
    
    
///+++ DataFrame and SQL Join Operators
//Queries can access multiple tables at once, or access the same table in such a way that multiple rows of the table are being processed at the same time. 

//A query that accesses multiple rows of the same or different tables at one time is called a join query.
spark.sql("select * from t1, t2 where t1.id = t2.id")

//OR specify a join condition (aka join expression) as part of join operators 
spark.sql("SELECT * FROM df_dist JOIN df1 ON df_dist.a = df1.a")

//OR use DF.join
val df = sc.parallelize(Array((2, "Alice"), (5, "Bob"))).toDF("age", "name")

val df2 = sc.parallelize(Array(("Tom",80), ("Bob",85))).toDF("name", "height")
val df3 = sc.parallelize(Array(("Alice",2),("Bob",5))).toDF("name", "age")
                       
//only way to get None                        
case class Detail(name:Option[String], age:Option[Int], height:Option[Int])
val df4 = sc.parallelize(Array(Detail(Some("Alice"),Some(10),Some(80)) ,
                               Detail(Some("Bob"),Some(5),None) ,
                               Detail(Some("Tom"),None,None),
                               Detail(None,None,None)) ).toDF("name", "age", "height")    

                               
crossJoin(other)
    Returns the cartesian product with another DataFrame.
        other: Right side of the cartesian product
    >>> df.select("age", "name").collect()
    [Row(age =2,name =u"Alice"), Row(age =5,name =u"Bob")]
    >>> df2.select("name", "height").collect()
    [Row(name =u"Tom",height =80), Row(name =u"Bob",height =85)]
    >>> df.crossJoin(df2.select("height")).select("age", "name", "height").collect()
    [Row(age =2,name =u"Alice",height =80), Row(age =2,name =u"Alice",height =85),
     Row(age =5,name =u"Bob",height =80), Row(age =5,name =u"Bob",height =85)]

     
     
def join(right: Dataset[_], joinExprs: Column): DataFrame
    Inner join with another DataFrame, using the given join expression.
def join(right: Dataset[_], usingColumns: Seq[String]): DataFrame
    Inner equi-join with another DataFrame using the given columns.
    usingColumns when column name is same in both DF 
def join(right: Dataset[_], usingColumn: String): DataFrame
    Inner equi-join with another DataFrame using the given column.
def join(right: Dataset[_]): DataFrame
    Join with another DataFrame.     
def join(right: Dataset[_], usingColumns: Seq[String], joinType: String): DataFrame
def join(right: Dataset[_], joinExprs: Column, joinType: String): DataFrame
    Join with another DataFrame, using the given join expression.
    right
        Right side of the join.
    joinExprs
        Join expression.
    joinType
        Type of join to perform. Default inner. 
        Must be one of: inner, cross, outer, full, full_outer, left, left_outer, right, right_outer, left_semi, left_anti.    

//The following performs a full outer join between df1 and df2.
>>> df.join(df2, df("name") === df2("name"), "outer").show()
[Row(name =None,height =80), Row(name ="Bob",height =85), Row(name ="Alice",height =None)]

>>> df.join(df2, Array("name"), "outer").select("name", "height").collect()
[Row(name ="Tom",height =80), Row(name ="Bob",height =85), Row(name ="Alice",height =None)]

val cond = (df("name") === df3("name")) && (df("age") === df3("age"))
>>> df.join(df3, cond, "outer").show()
[Row(name ="Alice",age =2), Row(name ="Bob",age =5)]

>>> df.join(df2, "name").show()
[Row(name ="Bob",height =85)]

>>> df.join(df4, Array("name", "age")).show() 
[Row(name ="Bob",age =5)]

//or using where or filter operators.
df.join(df2).where(df("name") === df2("name")).show()


//Note duplicate columns names are messy to select 
//use below 
df.select('name as "df_name", 'age as "df_age").join(df2.select('name as "df2_name"), 'df_name === 'df2_name)  //'
   
//OR , F.col("df_as1.name") === F.col("df_as2.name") requires aliases 
val df_as1 = df.alias("df_as1")
val df_as2 = df2.alias("df_as2")
val joined_df = df_as1.join(df_as2, F.col("df_as1.name") === F.col("df_as2.name"), "inner")
joined_df.select("df_as1.name", "df_as2.name", "df_as1.age").collect()




///HandsON - Example 
// Inner join with a single column that exists on both sides
val left = sc.parallelize((0, "zero") :: (1, "one") :: Nil).toDF("id", "left").alias("left")
val right = sc.parallelize((0, "zero"):: (2, "two"):: (3, "three"):: Nil).toDF("id", "right").alias("right")

// Inner join - for common "id" in both 
>>> left.join(right, "id").show()
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
+---+----+-----+

//for common left.left  and right.right
>>> left.join(right).where($"left.left" === $"right.right").show()  //this syntax requires alias 
+---+----+---+-----+
| id|left| id|right|
+---+----+---+-----+
|  0|zero|  0| zero|
+---+----+---+-----+

// Full outer - for all values of id in both DF, if some Id is not present, value is null 
//full, fullouter are synonyms
>>> left.join(right, Seq("id"), "fullouter").show()
+---+----+-----+
| id|left|right|
+---+----+-----+
|  1| one| null|
|  3|null|three|
|  2|null|  two|
|  0|zero| zero|
+---+----+-----+

>>> left.join(right, Seq("id"), "full").show()
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
|  3|null|three|
|  2|null|  two|
+---+----+-----+


//Get both only for IDs in left 
left.join(right, Seq("id"), "left").show()
left.join(right, Seq("id"), "left_outer").show()
//output
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  1| one| null|
+---+----+-----+

//Get both only for IDs in right 
left.join(right, Seq("id"), "right").show()
left.join(right, Seq("id"), "right_outer").show()
//output
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
|  3|null|three|
|  2|null|  two|
+---+----+-----+

//get Left for ID which are common 
left.join(right, Seq("id"), "left_semi").show()
//output
+---+----+
| id|left|
+---+----+
|  0|zero|
+---+----+

// Left anti - get Left for ID which are not common 
>>> left.join(right, Seq("id"), "leftanti").show()
+---+----+
| id|left|
+---+----+
|  1| one|
+---+----+

//partitions 

>>> left.rdd.getNumPartitions()
4
>>> right.rdd.getNumPartitions()
4
//spark.sql.shuffle.partitions 
>>> left.join(right, Seq("id"), "fullouter").rdd.getNumPartitions()
200



///HandsON- Example - inner (equijoin)
case class Person(id: Long, name: String, cityId: Long)
case class City(id: Long, name: String)
val family = Seq(
  Person(0, "Agata", 0),
  Person(1, "Iweta", 0),
  Person(2, "Patryk", 2),
  Person(3, "Maksym", 0)).toDS
val cities = Seq(
  City(0, "Warsaw"),
  City(1, "Washington"),
  City(2, "Sopot")).toDS

val joined = family.joinWith(cities, family("cityId") === cities("id"))
>>> joined.printSchema
root
 |-- _1: struct (nullable = false)
 |    |-- id: long (nullable = false)
 |    |-- name: string (nullable = true)
 |    |-- cityId: long (nullable = false)
 |-- _2: struct (nullable = false)
 |    |-- id: long (nullable = false)
 |    |-- name: string (nullable = true)
>>> joined.show
+---+------+------+---+------+
| id|  name|cityId| id|  name|
+---+------+------+---+------+
|  0| Agata|     0|  0|Warsaw|
|  1| Iweta|     0|  0|Warsaw|
|  3|Maksym|     0|  0|Warsaw|
|  2|Patryk|     2|  2| Sopot|
+---+------+------+---+------+



///*** DataSkew 
I am joining two big datasets using Spark RDD. 
One dataset is very much skewed so few of the executor tasks taking a long time 
to finish the job. How can I solve this scenario?

//Solutions 
Say you have to join two tables A and B on A.id=B.id. 
Lets assume that table A has skew on id=0.
    select A.id from A join B on A.id = B.id

There are two basic approaches to solve the skew join issue:
///Approach 1:
Break your query/dataset into 2 parts -
one containing only skew and the other containing non skewed data. 
In the above example. query will become -
    select A.id from A join B on A.id = B.id where A.id <> 0;
    select A.id from A join B on A.id = B.id where A.id = 0 and B.id = 0;

   
The first query will not have any skew, 
so all the tasks of ResultStage will finish at roughly the same time.

If we assume that B has only few rows with B.id = 0, then it will fit into memory. 
So Second query will be converted to a broadcast join. 
This is also called Map-side join in Hive.
Reference: https://cwiki.apache.org/confluence/display/Hive/Skewed+Join+Optimization
The partial results of the two queries can then be merged to get the final results.
//code 
import spark.implicits._ 
val df1 = spark.range(0,10000,2) //[id: bigint], else we get getNumPartitions=4
val df2 = spark.range(1,5,2)
val fact_table = df1.union(df2).map(e => (e%2, e)).
    toDF("key", "value"). //key=0 is data skew 
    repartition(3, $"key")  //since both hash value of 0 and 1 are even 
fact_table.createOrReplaceTempView("fact_table")
//dimension table is small 
val dim_table = spark.range(1,5,2).union(spark.range(0,6,2)).map(e => (e%2, e*3)).
    toDF("key", "value2").
    repartition(3, $"key")
dim_table.createOrReplaceTempView("dim_table")
    
def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0).toDouble/10e9 + " secs")
    result
}  
//disable BroadcastJoin 
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
time(spark.sql("select A.key, A.value, B.value2 from fact_table as A join dim_table as B on A.key = B.key").collect)
//0.7948357961 secs

//divide and union 
def func() = {
    val fh = spark.sql("select A.key, A.value, B.value2 from fact_table as A join dim_table as B on A.key = B.key where A.key <> 0")
    val sh = spark.sql("select A.key, A.value, B.value2 from fact_table as A join dim_table as B on A.key = B.key where A.key = 0 and B.key = 0")
    fh.union(sh)
}
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 10*1024*1024) //default 
time(func().collect)
// 0.2550047243 secs
Assumptions 
The assumption is that B has few rows with keys which are skewed in A

Advantages
If a small number of skewed keys make up for a significant percentage of the data, 
they will not become bottlenecks.

Disadvantages
The tables A and B have to be read and processed twice.
The user needs to be aware of the skew in the data and manually do the above process.



///Approach-2 


Add a column in the larger table (A), say skewLeft 
and populate it with random numbers between 0 to N-1 for all the rows.

Add a column in the smaller table (B), say skewRight. 
Replicate the smaller table N times. 
So values in new skewRight column will vary from 0 to N-1 for each copy of original data. For this, you can use the explode sql/dataset operator.

After 1 and 2, join the 2 datasets/tables with join condition updated to-
A.id = B.id && A.skewLeft = B.skewRight

//code 
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
import org.apache.spark.sql.{functions => F} 

val salt_bins = 20
val skewed_transformed_df = fact_table.
    withColumn("salt", (F.rand()*salt_bins).cast("int")).cache()

val small_transformed_df = dim_table.
    withColumn("replicate", F.array( (0 to salt_bins-1).map(F.lit).toList :_* )).
    select($"*", F.explode($"replicate").alias("salt")).drop($"replicate").cache()

time(skewed_transformed_df.join(small_transformed_df, 
    (skewed_transformed_df("key") === small_transformed_df("key")) && 
    (skewed_transformed_df("salt") === small_transformed_df("salt")) ).collect)
//0.2662952621 secs       

///In Sql 
spark.conf.set("spark.sql.shuffle.partitions", 8)
fact_table.createOrReplaceGlobalTempView("fact_table")
dim_table.createOrReplaceGlobalTempView("dimension_table")    
time( spark.sql("""
    select t1.key, count(*) from global_temp.fact_table t1, 
    global_temp.dimension_table t2 
    where t1.key=t2.key 
    group by t1.key 
    order by t1.key
    """).collect)
//0.2787087076 secs

val salted_fact_df = spark.sql("""
select concat(key,"_", floor(rand(12345)*19)) as salted_key, value 
from global_temp.fact_table
""")

salted_fact_df.createOrReplaceGlobalTempView("fact_table_optimized")

//replicating each row multiple times 
val exploded_dim_df = spark.sql("""
select key, value2, 
explode(array(0,1,2,3,4,5,6,7,8,
9,10,11,12,13,14,15,16,17,18,19)) 
as salted_key from global_temp.dimension_table""")

exploded_dim_df.createOrReplaceGlobalTempView("dimension_optimzed")
time( spark.sql("""
select key1, count(*) from 
    ( select split(t1.salted_key, "_")[0] as key1 
    from global_temp.fact_table_optimized t1 ,
    global_temp.dimension_optimzed t2 
    where t1.salted_key = concat(t2.key, "_", t2.salted_key)
    ) 
group by key1 order by key1""").collect)

    




///Skew because of large no of NULL 
skew was caused by a very large number of null values in the join column. 
The null values were not participating in the join, 
but since Spark partitions on the join column, 
the post-join partitions were very skewed as there was one gigantic partition 
containing all of the nulls.

I solved it by adding a new column which changed all null values 
to a well-distributed temporary value, such as "NULL_VALUE_X", 
where X is replaced by random numbers between say 1 and 10,000

//na =  null or NaN, isnan(e: Column)/isnull(e: Column) or isNaN/isNull/isNotNull
val null_table = fact_table.withColumn("extra", F.floor(F.rand()*6).cast("int")).
    withColumn("key", F.when( F.col("key") === 0 && ((F.col("extra") % 3) === 0), null). //or Double.NaN
        otherwise(F.col("key")))


val new_column_name = "key_with_distributed_nulls";
val numNullValues = 16; // Just use a number that will always be bigger than number of partitions
val new_column =
    F.when(F.col("key").isNull, F.concat(
        F.lit("NULL_KEY_"),
        F.round(F.rand() * numNullValues).cast("int"))
    ).otherwise(F.col("key"))
val null_table_distributed = null_table.withColumn(new_column_name, new_column)

time(null_table_distributed.join(dim_table, 
    (null_table_distributed(new_column_name) === dim_table("key"))).drop(new_column_name).collect)
//0.1043520444 secs  

///https://dataengi.com/2019/02/06/spark-data-skew-problem/
Skewed table (Hive)

Values that appear very often (heavy skew) are split out into separate files 
and rest of the values go to some other file [2]. 
The STORED AS DIRECTORIES option determines whether a skewed table 
uses the list bucketing feature, which creates subdirectories for skewed values.
(1,5,6) are values of Key where Skew data is present 

CREATE TABLE list_bucket_single (key STRING, value STRING)
  SKEWED BY (key) ON (1,5,6) [STORED AS DIRECTORIES];
  
CREATE TABLE list_bucket_multiple (col1 STRING, col2 int, col3 STRING)
  SKEWED BY (col1, col2) ON (('s1',1), ('s3',3), ('s13',13), ('s78',78)) 
  [STORED AS DIRECTORIES];
  
ALTER TABLE table_name SKEWED BY (col_name1, col_name2, ...)
  ON ([(col_name1_value, col_name2_value, ...) [, (col_name1_value, col_name2_value), ...]
  [STORED AS DIRECTORIES];

ALTER TABLE table_name NOT SKEWED;
ALTER TABLE table_name NOT STORED AS DIRECTORIES;

General create table 
(Partitions columns are not put in main columns list )
CREATE TABLE page_view(viewTime INT, userid BIGINT,
     page_url STRING, referrer_url STRING,
     ip STRING COMMENT 'IP Address of the User')
 COMMENT 'This is the page view table'
 PARTITIONED BY(dt STRING, country STRING)
 CLUSTERED BY(userid) SORTED BY(viewTime) INTO 32 BUCKETS
 ROW FORMAT DELIMITED
   FIELDS TERMINATED BY '\001'
   COLLECTION ITEMS TERMINATED BY '\002'
   MAP KEYS TERMINATED BY '\003'
 STORED AS SEQUENCEFILE;

//Example 
Not supported by spark-sql 
https://docs.databricks.com/spark/latest/spark-sql/index.html
functions 
https://spark.apache.org/docs/latest/api/sql/
  
 

Skewed Join (Spark)
The skew join optimization is performed on the specified column of the DataFrame and values 
    DataFrame and column name. .
    df.hint("skew", "col1")
    DataFrame and multiple columns
    df.hint("skew", ["col1","col2"])
    DataFrame, column name, and skew value
    df.hint("skew", "col1", "value")
Example
val joinResults = ds1.hint("skew", "col1").as("L").join(ds2.hint("skew", "col1").as("R"), $"L.col1" === $"R.col1")

//code 
import spark.implicits._ 
val df1 = spark.range(0,10000,2) //[id: bigint], else we get getNumPartitions=4
val df2 = spark.range(1,5,2)
val fact_table = df1.union(df2).map(e => (e%2, e)).
    toDF("key", "value"). //key=0 is data skew 
    repartition(3, $"key")  //since both hash value of 0 and 1 are even 
fact_table.createOrReplaceTempView("fact_table")
//dimension table is small 
val dim_table = spark.range(1,5,2).union(spark.range(0,6,2)).map(e => (e%2, e*3)).
    toDF("key", "value2").
    repartition(3, $"key")
dim_table.createOrReplaceTempView("dim_table")

def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block    // call-by-name, 
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0).toDouble/10e9 + " secs")
    result
}  
time(
  fact_table.hint("skew", "key", 0).as("L").join(dim_table.as("R"), $"L.key" === $"R.key").collect
)
//0.1453278795 secs

//Using sql 
-- skew with table name  
SELECT /*+ SKEW('orders') */ * FROM orders, customers WHERE c_custId = o_custId

-- skew with table name and single column
SELECT /*+ SKEW('orders', 'o_custId') */ *
  FROM orders, customers
  WHERE o_custId = c_custId

-- multiple columns
SELECT /*+ SKEW('orders', ('o_custId', 'o_storeRegionId')) */ *
  FROM orders, customers
  WHERE o_custId = c_custId AND o_storeRegionId = c_regionId
  
-- single column, single skew value
SELECT /*+ SKEW('orders', 'o_custId', 0) */ *
  FROM orders, customers
  WHERE o_custId = c_custId

-- single column, multiple skew values
SELECT /*+ SKEW('orders', 'o_custId', (0, 1, 2)) */ *
  FROM orders, customers
  WHERE o_custId = c_custId

-- multiple columns, multiple skew values
SELECT /*+ SKEW('orders', ('o_custId', 'o_storeRegionId'), ((0, 1001), (1, 1002))) */ *
  FROM orders, customers
  WHERE o_custId = c_custId AND o_storeRegionId = c_regionId

//Code 
time(
  spark.sql("""
      SELECT /*+ SKEW('fact_table', 'key', 0) */   L.key, L.value, R.value2
      FROM fact_table as L JOIN dim_table as R
      ON L.key = R.key 
  """).collect 
)
//0.9469131964 secs

///Joining with data replication:
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1) //disable, de:10M 
//smaller table is dim_table 
//Not this is accumulated in driver so driver memory should be adequate 
//and this is communicated to all executors 
time(
  spark.sql("""
      SELECT /*+  BROADCASTJOIN(dim_table) */   L.key, L.value, R.value2
      FROM fact_table as L JOIN dim_table as R
      ON L.key = R.key 
  """).collect 
)
//0.0761011879 secs
//or
time(
  fact_table.as("L").join(dim_table.hint("broadcast").as("R"), $"L.key" === $"R.key").collect
)
//0.0626663245 secs
fact_table.as("L").join(dim_table.hint("broadcast").as("R"), $"L.key" === $"R.key").explain 
//contains BroadcastHashJoin and BroadcastExchange with dim_table

//or 
import org.apache.spark.sql.{functions => F} 
time(
  fact_table.as("L").join(F.broadcast(dim_table).as("R"), $"L.key" === $"R.key").collect
)
//0.0593008619 secs


///Exmaple of broadcast join - User data is big Data , Deps is smaller 
import org.apache.spark.sql.{functions => F} 
val usersCSV = "data/spark/Spark+task+attachment+2+-+users.csv.gz"
val depsCSV  = "data/spark/Spark+task+attachment+1+-+deps.csv.gz"
//partition-1 
val depsIn  = spark.read.format("csv").option("header", "true").load(depsCSV)
val usersIn = spark.read.format("csv").option("header", "true").load(usersCSV)

val cores   = 4
val multiFactor = 2

// prepare data
import spark.implicits._
val deps_raw  = depsIn.sort('id, 'assigned_date, 'company_id, 'factory_id)
val users_raw = usersIn.repartition(cores*multiFactor)

//Its big data 
//so take a sample def sample(fraction: Double, seed: Long): Dataset[T] 
//lets take samples based on users.department_id and deps.id
import org.apache.spark.sql.types._ 
import org.apache.spark.sql._
val uniq = users_raw.select( $"department_id").map{case Row(s:String) => s}.collect.toSet.toList 
val r = scala.util.Random
val fews = r.shuffle(uniq).slice(0, if(uniq.size < 2) uniq.size else 2)

val users = users_raw.filter($"department_id".isin(fews:_*))
val deps = deps_raw.filter($"id".isin(fews:_*))


//broadcase join 
val joinExp   = $"users.department_id" === $"deps.id" && $"users.date_of_birth" === $"deps.assigned_date" && ($"users.company_id" === $"deps.company_id" || $"users.company_id" === $"deps.factory_id")
val countExpr = users.as('users).join(F.broadcast(deps).as('deps), joinExp, "inner")

time(countExpr.count())
//13.5137855191 secs

//Normal join -takes long time 
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1) //disable, de:10M 
val joinExp = $"users.department_id" === $"deps.id" && $"users.date_of_birth" === $"deps.assigned_date" && ($"users.company_id" === $"deps.company_id" || $"users.company_id" === $"deps.factory_id")
val countExpr2 = users.as('users).join(deps.as('deps), joinExp, "inner")
time(countExpr2.count())
//23.648306522 secs

///https://coxautomotivedatasolutions.github.io/datadriven/spark/data%20skew/joins/data_skew/
//Intelligent partitioning of join keys 

car_registrations.csv
    We have some cars (registration, make, model, engine size) (lets call this t1)
    smaller one 
car_makes.csv    
    We have a large dataset containing a lot more cars 
    and their sale prices (let�s call this t2)
We say two vehicles are 'similar' if they have the same make 
and model and engine sizes within 0.1 litres of each other 
For each car in t1, we want to calculate the average price of 'similar' vehicles in t2

    
//Because our datasets are small, Spark will try and do a broadcast join. In order to see our skew happening, we need to suppress this behaviour
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
val t1 = spark.read.option("inferSchema", true).option("header", true).csv("data/spark/car_registrations.csv")
val t2 = spark.read.option("inferSchema", true).option("header", true).csv("data/spark/car_makes.csv")

import scala.math.BigDecimal

t1.join(t2, Seq("make", "model")).
  filter(abs(t2("engine_size") - t1("engine_size")) <= BigDecimal("0.1")).
  groupBy("registration").
  agg(avg("sale_price").as("average_price")).collect()
//duration:26 secs 

//check http://localhost:4040/
If we look at our job in the Spark UI, (check MaxStageID - 1)
we can see that the stage for the join finishes 199/200 tasks very quickly, 
and then spends a significant amount of time on the final remaining task.

If we look at the stage detail and order the tasks by duration descending, 
we can see our long-running task took almost 40 times longer than all of the others.

This is because big Ford Fiesta partition partitions in car_makes.csv 

Tactic 1: 
What we really want to do is to break that big Ford Fiesta partition 
into smaller partitions, thereby distributing our processing better.

Looking again at our definition of 'similar' vehicles, 
in addition to the requirement that the make and model be the same, 
we also stipulate that the engine size can only vary by 0.1 litres. 

To achieve this we added a filter
(abs(t2("engine_size") - t1("engine_size")) <= 0.1)) after the join. 

Could we have added this inequality into the join condition 
and thereby made our partitions smaller?

Yes, we could have added the inequality into the join condition, 
but it would have made no difference to the execution plan. 
Spark can only partition on equality join conditions. 

This makes sense, as it works out the partition number 
by performing a hash on the join key - how would this work with a range?

However, there is a way we can get engine size into the join key, 
and it�s due to an important quality of the data in this column: 
it�s discrete  - it only varies in increments of 0.1.


If we take t1, and add two rows for each original row, 
with engine sizes 0.1 either side, 
we end up with three times as much data for t1 
which you may think seems like a bad thing 
(surely just adding more data will make it slower?) 
However, we can now include engine_size in our join_condition 
to achieve the desired result (every original record from t1 will be joined 
to every record from t2 with the same make, model, and engine size +/- 0.1). 

The result is a much more even partition distribution.

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

t1.withColumn("engine_size", explode(array($"engine_size" - BigDecimal("0.1"), $"engine_size", $"engine_size" + BigDecimal("0.1")))).
  join(t2, Seq("make", "model", "engine_size")).
  groupBy("registration").
  agg(avg("sale_price").as("average_price")).
  collect()
//21S 

If we look in the Spark UI, (check MaxStageID - 1)
we can see that our processing is a lot more distributed - 
there doesn�t seem to be any skew at all now!
     

 

//generate Dummy data 
import scala.util.Random
import scala.math.BigDecimal

case class MakeModel(make: String, model: String)
case class T1(registration: String, make: String, model: String, engine_size: BigDecimal)
case class T2(make: String, model: String, engine_size: BigDecimal, sale_price: Double)

val makeModelSet: Seq[MakeModel] = Seq(
  MakeModel("FORD", "FIESTA")
  , MakeModel("NISSAN", "QASHQAI")
  , MakeModel("HYUNDAI", "I20")
  , MakeModel("SUZUKI", "SWIFT")
  , MakeModel("MERCEDED_BENZ", "E CLASS")
  , MakeModel("VAUCHALL", "CORSA")
  , MakeModel("FIAT", "500")
  , MakeModel("SKODA", "OCTAVIA")
  , MakeModel("KIA", "RIO")
)

def randomMakeModel(): MakeModel = {
  val makeModelIndex = if (Random.nextBoolean()) 0 else Random.nextInt(makeModelSet.size)
  makeModelSet(makeModelIndex)
}

def randomEngineSize() = BigDecimal(s"1.${Random.nextInt(9)}")

def randomRegistration(): String = s"${Random.alphanumeric.take(7).mkString("")}"

def randomPrice() = 500 + Random.nextInt(5000)

def randomT1(): T1 = {
  val makeModel = randomMakeModel()
  T1(randomRegistration(), makeModel.make, makeModel.model, randomEngineSize())
}
def randomT2(): T2 = {
  val makeModel = randomMakeModel()
  T2(makeModel.make, makeModel.model, randomEngineSize(), randomPrice())
}
import spark.implicits._ 
val t1 = Seq.fill(10000)(randomT1()).toDS()
val t2 = Seq.fill(100000)(randomT2()).toDS()
t1.repartition(1).write.mode("overwrite").option("header", true).csv("car_registrations.csv")
t2.repartition(1).write.mode("overwrite").option("header", true).csv("car_makes.csv")


///Iterative Broadcasting 



//One example - User data is big Data , Deps is smaller 
import org.apache.spark.sql.{functions => F} 
val usersCSV = "data/spark/Spark+task+attachment+2+-+users.csv.gz"
val depsCSV  = "data/spark/Spark+task+attachment+1+-+deps.csv.gz"
//partition-1 
val depsIn  = spark.read.format("csv").option("header", "true").load(depsCSV)
val usersIn = spark.read.format("csv").option("header", "true").load(usersCSV)

// prepare data
val cores   = 4
val multiFactor = 1

import spark.implicits._
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql._
val deps = depsIn.sort('id) //'
val users = usersIn.repartition(cores*multiFactor, $"id")

def time[R](block: => R): R = {
    val t0 = System.nanoTime()
    val result = block // call-by-name
    val t1 = System.nanoTime()
    println("Elapsed time: " + (t1 - t0) / 1000 / 1000 / 1000 + " sec")
    result
  }
  
//deps = id,name,assigned_date,company_id,factory_id,uuid 
//users = id,name,department_id,date_of_birth,company_id
def joinNormal(spark: SparkSession, users: DataFrame, deps: DataFrame): DataFrame = {
    // Explicitly disable the broadcastjoin
    import spark.implicits._ 
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
    val joinExp   = $"users.department_id" === $"deps.id" && $"users.date_of_birth" === $"deps.assigned_date" && ($"users.company_id" === $"deps.company_id" || $"users.company_id" === $"deps.factory_id")
    val selectExpr = List($"users.id", $"deps.id", $"users.name", $"deps.name")
    users.as('users)
      .join(
        deps.as('deps),
        joinExp  ,  //Seq("key"),
        "inner"
      )
      .select(
        selectExpr: _* 
      )
  }

//time(joinNormal(spark, users, deps).collect)
//290 sec

//iterative 
//Idea is that smaller one divided into many DFs and broadcasted 
//and the join is repeatedly built 
//deps = id,name,assigned_date,company_id,factory_id,uuid 
//users = id,name,department_id,date_of_birth,company_id

def joinIterative(spark: SparkSession,
                    users: DataFrame,
                    deps: DataFrame, noOfPasses:Int): DataFrame = {    

    import spark.implicits._ 
    //spark.conf.set("spark.sql.autoBroadcastJoinThreshold", 10*1024*1024)
    
    def dfWrite(df: DataFrame, name: String): Unit =
        df.
          write.
          mode("overwrite").
          parquet(name)

    def dfRead(spark: SparkSession, name: String): DataFrame =
        spark.
          read.
          parquet(name)
    
    @annotation.tailrec  //function must final or private or inner 
    def iterativeBroadcastJoin(spark: SparkSession,
                                         resultDF: DataFrame,
                                         broadcastDF: DataFrame, noOfPasses:Int,
                                         columns:Seq[Column], iteration: Int = 0): DataFrame = {    
        val joinExp   = $"users.department_id" === $"deps.id" && $"users.date_of_birth" === $"deps.assigned_date" && ($"users.company_id" === $"deps.company_id" || $"users.company_id" === $"deps.factory_id")
        
        // Join in the label
        //Returns the first column that is not null, or null if all inputs are null.

        val selectExpr = columns ++ Seq(F.coalesce(
              $"users.deps_id",
              $"deps.id"
            ).as("deps_id"),
            F.coalesce(
              $"users.deps_name",
              $"deps.name"
            ).as("deps_name")) 

        if (iteration < noOfPasses) {
          val tableName = s"tmp_broadcast_table_itr_$iteration.parquet"

          val out = resultDF.as('users).join(
            broadcastDF.as('deps)
              .filter($"deps.pass" === F.lit(iteration)), //this condition can be anything 
            joinExp,
            "left_outer"
          ).select(
              selectExpr:_*
          )

          dfWrite(out, tableName)

          iterativeBroadcastJoin(
            spark,
            dfRead(spark, tableName),
            broadcastDF,noOfPasses,columns,
            iteration + 1
          )
        } else resultDF    
    }
    
    
    //call that 
    val b_deps = F.broadcast(deps.withColumn("pass", F.floor(F.rand()*noOfPasses).cast("int")))
    //all columns except two empty columns 
    val columns = users.columns.map( s => F.col(s"users.$s")).toSeq
    //from selectExpr, output from other table $"deps.id", $"deps.name
    //create two empty column 
    iterativeBroadcastJoin(
      spark,
      users
        .withColumn("deps_id", lit(null))
        .withColumn("deps_name", lit(null)),
      b_deps,  noOfPasses, columns 
    ).filter($"deps_id".isNotNull)
}
time(joinIterative(spark, users, deps,2).collect)
//259 sec

///Dynamic-sharding 
for array columns in spark

A lot of frameworks implementing the map-reduce paradigm show degraded performance 
in case of data skew. 
When there are outlier keys in the data with more than an order of magnitude 
more events than regular keys some tasks will take longer to compute. 
In fact, most likely hours longer.

Unfortunately, spark is a data parallel framework 
which only can handle simple rows well. 
It will not really consider complex types and especially not arrays of complex types 
when performing a shuffle. 
So a regular repartition will not resolve the problem of data skew 
for arrays with unequal number of elements.

Examples 
The following code returns a similar dataset exhibiting similar issues 
(https://stackoverflow.com/questions/46240688/how-to-equally-partition-array-data-in-spark-dataframe):

import scala.util.Random
import org.apache.spark.sql._
import org.apache.spark.sql.types.IntegerType
val localData = (1 to 100).map(i => (i,Seq.fill(Math.abs(Random.nextGaussian()*100).toInt)(Random.nextDouble)))
val df = sc.parallelize(localData).toDF("id","data").withColumn("data_size",size($"data"))
df.printSchema
root
 |-- id: integer (nullable = false)
 |-- data: array (nullable = true)
 |    |-- element: double (containsNull = false)
 |-- data_size: integer (nullable = false)

df.show(3)
+---+--------------------+---------+
| id|                data|data_size|
+---+--------------------+---------+
|  1|[0.15397263238637...|      131|
|  2|[0.97736166537028...|       42|
|  3|[0.09454220834717...|      112|
+---+--------------------+---------+


//To apply below functions 
import org.apache.spark.sql.{functions=>F}
import org.apache.spark.sql.types._

def myFunction(input:Seq[Double]):Option[Double]= {
  // some random but expensive function when the array is overly long.
  if(null == input){
    None
  }else{
    Some(input.max)
  }
}
val myUdf = F.udf(myFunction _)

//It can be executed like:

df.withColumn("max", myUdf(F.col("data"))).show

//To make it a bit more user-friendly and reusable:

def myTransform(column:String)(df:DataFrame) = {
  df.withColumn("max", myUdf(F.col(column)))
}



//dynamic sharding (division)
splitting the dataframe into small/large records, repartition seperately 
and then union back 


In order to derive the cutoff, there exist various possibilities. 
eg basic mean and stdev are faster  than approximative percentiles. 

def deriveCutoff(column: String, df: DataFrame, useMean: Boolean = true): Int = {
    import df.sparkSession.implicits._
    if (useMean) {
      df.select(
          (F.avg(F.col(column)) + F.stddev(F.col(column))).cast(IntegerType).as[Int])
        .head
    } else {
      val columnsOfInterest = Array(column)
      val percentiles = Array(.9)
      val relError = 0.01
      val approxQuantiles =
        df.stat.approxQuantile(columnsOfInterest, percentiles, relError)
      for (co <- columnsOfInterest.zipWithIndex) {
        for (q <- percentiles.zipWithIndex) {
          println(
            s"Column: ${co._1}, quantiles: ${q._1}, value: ${approxQuantiles(
              co._2)(q._2)}")
        }
      }
      approxQuantiles.head.head.toInt
    }
  }

//Then use 

val tmpSizeCol = "tmp_size_column"
def compute(function:DataFrame=> DataFrame, arrayColumn:String, parallelismRegular: Int, parallelismIncreased: Int)(df:DataFrame):DataFrame = {
	val withSize = df.withColumn(tmpSizeCol,F.size(F.col(arrayColumn)))
  // consider to persist prior to aggregation in case of iterative refinement a checkpoint  mith be useful
    df.cache //also you might not have enough RAM available: .persist(StorageLevel.DISK_ONLY), and should consider to repartition to make sure that less than 2GB fall into a single partition.
	val cutoff = deriveCutoff(tmpSizeCol, withSize, useMean=true)
	//def transform[U](t: (Dataset[T]) => Dataset[U]): Dataset[U] 
	val regular = withSize.filter(F.col(tmpSizeCol) <= cutoff).repartition(parallelismRegular).transform(function)
	val outlier = withSize.filter(F.col(tmpSizeCol) > cutoff).repartition(parallelismIncreased).transform(function)

	regular.union(outlier)
}

//Then, it can be applied like:
df.transform(compute(myTransform("data"), "data", 4, 40)).show




///+++ Extracting Data from Arbitrary JSON-Encoded Values�from_json Functions
from_json(col, schema,options ={})
    Parses a column containing a JSON string into a StructType with the specified schema. 
    Returns null, in the case of an unparseable string.

//from_json parses a column with a JSON-encoded value into a StructType 
//or ArrayType of StructType elements with the specified schema.

//Example 
val jsons = Seq("""{ "id": 0 }""").toDF("json")

import org.apache.spark.sql.types._
val schema = new StructType().add($"id".int.copy(nullable = false))


scala> jsons.select(F.from_json($"json", schema) as "ids").show
+---+
|ids|
+---+
|[0]|
+---+


///HandsON - from JSON 
//A schema can be one of the following:
    // DataType as a object or in the JSON format
    // StructType in the DDL format

// Define the schema for JSON-encoded messages
// Note that the schema is nested (on the addresses field)

import org.apache.spark.sql.types._
val addressesSchema = new StructType()
  .add($"city".string)
  .add($"state".string)
  .add($"zip".string)
val schema = new StructType()
  .add($"firstName".string)
  .add($"lastName".string)
  .add($"email".string)
  .add($"addresses".array(addressesSchema))
scala> schema.printTreeString
root
 |-- firstName: string (nullable = true)
 |-- lastName: string (nullable = true)
 |-- email: string (nullable = true)
 |-- addresses: array (nullable = true)
 |    |-- element: struct (containsNull = true)
 |    |    |-- city: string (nullable = true)
 |    |    |-- state: string (nullable = true)
 |    |    |-- zip: string (nullable = true)

// Generate the JSON-encoded schema
// That's the variant of the schema that from_json accepts
val schemaAsJson = schema.json

// Use prettyJson to print out the JSON-encoded schema
// Only for demo purposes
scala> println(schema.prettyJson)
{
  "type" : "struct",
  "fields" : [ {
    "name" : "firstName",
    "type" : "string",
    "nullable" : true,
    "metadata" : { }
  }, {
    "name" : "lastName",
    "type" : "string",
    "nullable" : true,
    "metadata" : { }
  }, {
    "name" : "email",
    "type" : "string",
    "nullable" : true,
    "metadata" : { }
  }, {
    "name" : "addresses",
    "type" : {
      "type" : "array",
      "elementType" : {
        "type" : "struct",
        "fields" : [ {
          "name" : "city",
          "type" : "string",
          "nullable" : true,
          "metadata" : { }
        }, {
          "name" : "state",
          "type" : "string",
          "nullable" : true,
          "metadata" : { }
        }, {
          "name" : "zip",
          "type" : "string",
          "nullable" : true,
          "metadata" : { }
        } ]
      },
      "containsNull" : true
    },
    "nullable" : true,
    "metadata" : { }
  } ]
}

// Let's "validate" the JSON-encoded schema
import org.apache.spark.sql.types._
val dt = DataType.fromJson(schemaAsJson)
scala> println(dt.sql)
STRUCT<`firstName`: STRING, `lastName`: STRING, `email`: STRING, `addresses`: ARRAY<STRUCT<`city`: STRING, `state`: STRING, `zip`: STRING>>>

// No exception means that the JSON-encoded schema should be fine
// Use it with from_json
val rawJsons = Seq("""
  {
    "firstName" : "Jacek",
    "lastName" : "Laskowski",
    "email" : "jacek@japila.pl",
    "addresses" : [
      {
        "city" : "Warsaw",
        "state" : "N/A",
        "zip" : "02-791"
      }
    ]
  }
""").toDF("rawjson")
val people = rawJsons
  .select(F.from_json($"rawjson", schemaAsJson, Map.empty[String, String]) as "json")
  .select("json.*") // <-- flatten the struct field
  .withColumn("address", explode($"addresses")) // <-- explode the array field
  .drop("addresses")  // <-- no longer needed
  .select("firstName", "lastName", "email", "address.*") // <-- flatten the struct field
scala> people.show
+---------+---------+---------------+------+-----+------+
|firstName| lastName|          email|  city|state|   zip|
+---------+---------+---------------+------+-----+------+
|    Jacek|Laskowski|jacek@japila.pl|Warsaw|  N/A|02-791|
+---------+---------+---------------+------+-----+------+

//options controls how a JSON is parsed and contains the same options as the json format.

val jsons = Seq("""{ id: 0 }""").toDF("json")

import org.apache.spark.sql.types._
val schema = new StructType()
  .add($"id".int.copy(nullable = false))
  .add($"corrupted_records".string)
val opts = Map("columnNameOfCorruptRecord" -> "corrupted_records")
scala> jsons.select(from_json($"json", schema, opts) as "ids").show
+----+
| ids|
+----+
|null|
+----+









///+++ DataFrame and SQL Multi-Dimensional Aggregation
//uses spark.sql.shuffle.partitions   

groupBy(cols: Column*): GroupedData
groupBy(col1: String, cols: String*): GroupedData
    groupBy operator groups the rows in a Dataset by columns (as Column expressions or names).
    groupBy gives a GroupedData to execute aggregate functions or operators.
cube(cols: Column*): GroupedData
cube(col1: String, cols: String*): GroupedData
	Returns GroupedData
    Calculates subtotals and a grand total across all combinations of 
    specified group of n + 1 dimensions 
    (with n being the number of columns as cols and col1 and one row for where values become null, 
    i.e. value does not matter or is ignored(subtotals or grandtotals).
rollup(cols: Column*): GroupedData
rollup(col1: String, cols: String*): GroupedData
	Returns GroupedData
    Calculates subtotals and a grand total over (ordered) combination of groups of n + 1 dimensions 
    (with n being the number of columns as cols and col1 and one row for where values become null, i.e. value does not matter or ignore).
    rollup operator is commonly used for analysis over hierarchical data; 
    e.g. total salary by department, division, and company-wide total.
    rollup operator is equivalent to GROUP BY ... WITH ROLLUP in SQL 
    (which in turn is equivalent to GROUP BY ... GROUPING SETS ((a,b,c),(a,b),(a),()) 
    when used with 3 columns: a, b, and c).     
GROUPING SETS SQL Clause
    GROUP BY ... GROUPING SETS (...)
    GROUPING SETS clause generates a dataset that is equivalent to union operator of multiple groupBy operators.    
    It is most general of all 
    
///Example 
val df =sc.parallelize(Array((2, "Alice"), (5, "Bob"))).toDF("age","name")

//create cartesian product of (null, all values from name) x (null, all values from age)
//null means  any value of that column possible ie subtotals or grandtotal 
>>> df.cube($"name", 'age).count().orderBy("name", "age").show() //'
+-----+----+-----+
| name| age|count|
+-----+----+-----+
| null|null|    2|
| null|   2|    1|
| null|   5|    1|
|Alice|null|    1|
|Alice|   2|    1|
|  Bob|null|    1|
|  Bob|   5|    1|
+-----+----+-----+


//create cartesian product of (null, all values from name) x (null, all values from age)
//null means  any value of that column possible , subttal and grandtotals 
//and them remove rows with "null" of first column and only keeping null,null row
>>> df.rollup("name", "age").count().orderBy("name", "age").show()
+-----+----+-----+
| name| age|count|
+-----+----+-----+
| null|null|    2|
|Alice|null|    1|
|Alice|   2|    1|
|  Bob|null|    1|
|  Bob|   5|    1|
+-----+----+-----+

//groupBy 
>>> df.groupBy("name", "age").count().orderBy("name", "age").show()
+-----+---+-----+
| name|age|count|
+-----+---+-----+
|Alice|  2|    1|
|  Bob|  5|    1|
+-----+---+-----+


///Another example 
// Borrowed from Microsoft"s "Summarizing Data Using ROLLUP" article
val inventory = Seq(
  ("table", "blue", 124),
  ("table", "red", 223),
  ("chair", "blue", 101),
  ("chair", "red", 210)).toDF("item", "color", "quantity")

scala> inventory.show
+-----+-----+--------+
| item|color|quantity|
+-----+-----+--------+
|chair| blue|     101|
|chair|  red|     210|
|table| blue|     124|
|table|  red|     223|
+-----+-----+--------+

// ordering and empty rows done manually for demo purposes
scala> inventory.rollup("item", "color").sum().show
+-----+-----+-------------+
| item|color|sum(quantity)|
+-----+-----+-------------+
|chair| blue|          101|
|chair|  red|          210|
|chair| null|          311|
|     |     |             |
|table| blue|          124|
|table|  red|          223|
|table| null|          347|
|     |     |             |
| null| null|          658|
+-----+-----+-------------+


// using struct function
scala> inventory.rollup(F.struct("item", "color") as "(item,color)").sum().show
+------------+-------------+
|(item,color)|sum(quantity)|
+------------+-------------+
| [table,red]|          223|
|[chair,blue]|          101|
|        null|          658|
| [chair,red]|          210|
|[table,blue]|          124|
+------------+-------------+

// using expr function
scala> inventory.rollup(F.expr("(item, color)") as "(item, color)").sum().show
+-------------+-------------+
|(item, color)|sum(quantity)|
+-------------+-------------+
|  [table,red]|          223|
| [chair,blue]|          101|
|         null|          658|
|  [chair,red]|          210|
| [table,blue]|          124|
+-------------+-------------+
  
  
///After Hands ON on roll up, do below 
///Details of cube - cube is more than rollup operator, 
//i.e. cube does rollup with aggregation over all the missing combinations given the columns.
val sales = Seq(
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)
).toDF("city", "year", "amount")


val q = sales.cube("city", "year")
  .agg(F.sum("amount").alias("amount"))
  .sort(F.col("city").desc, F.col("year").asc)
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|  <-- total in Warsaw in 2016
| Warsaw|2017|   200|  <-- total in Warsaw in 2017
| Warsaw|null|   300|  <-- total in Warsaw (across all years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total in 2015 (across all cities)
|   null|2016|   250|
|   null|2017|   250|
|   null|null|   550|  <-- grand total (across cities and years)
+-------+----+------+


///using GROUPING SETS SQL Clause

sales.createOrReplaceTempView("sales")

// equivalent to rollup("city", "year")
val q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|  <-- grand total across all cities and years
+-------+----+------+

// equivalent to cube("city", "year")
// note the additional (year) grouping set
val q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), (year), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total across all cities in 2015
|   null|2016|   250|  <-- total across all cities in 2016
|   null|2017|   250|  <-- total across all cities in 2017
|   null|null|   550|
+-------+----+------+


  
  
  
  
  
  

///cube and rollup vs manually creation 
//Multi-dimensional aggregate operators are enhanced variants of groupBy operator 
//that allow you to create queries for subtotals, grand totals and superset of subtotals in one go.

val sales = Seq(
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)
).toDF("city", "year", "amount")


// very labor-intense
// groupBy's unioned
val groupByCityAndYear = sales
  .groupBy("city", "year")  // <-- subtotals (city, year)
  .agg(F.sum("amount") as "amount")
val groupByCityOnly = sales
  .groupBy("city")          // <-- subtotals (city)
  .agg(F.sum("amount") as "amount")
  .select($"city", F.lit(null) as "year", $"amount")  // <-- year is null
val withUnion = groupByCityAndYear
  .union(groupByCityOnly)
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
>>> withUnion.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+

//grouping(*cols)  is an aggregate function that indicates whether a specified column is aggregated or not and:
//    returns  1  if the column is in a subtotal and is  NULL 
//    returns  0  if the underlying value is  NULL  or any other value
//grouping_id(*cols)  is an aggregate function that computes the level of grouping:
//    Returns 
//        0  for combinations of each column
//        1  for subtotals of column 1 ie other columns null 
//        2  for subtotals of column 2 ie other columns null 
//        And so on�

///Multi-dimensional aggregate operators are semantically equivalent to union operator 
//(or SQL�s UNION ALL) to combine single grouping queries.
val withRollup = sales
  .rollup("city", "year")
  .agg(F.sum("amount") as "amount", F.grouping_id() as "gid")
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
  .filter(F.grouping_id() =!= 3)
  .select("city", "year", "amount")
>>> withRollup.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+



    
    
///HandsON - rollup 
// Borrowed from http://stackoverflow.com/a/27222655/1305344
val quarterlyScores = Seq(
  ("winter2014", "Agata", 99),
  ("winter2014", "Jacek", 97),
  ("summer2015", "Agata", 100),
  ("summer2015", "Jacek", 63),
  ("winter2015", "Agata", 97),
  ("winter2015", "Jacek", 55),
  ("summer2016", "Agata", 98),
  ("summer2016", "Jacek", 97)).toDF("period", "student", "score")

scala> quarterlyScores.show
+----------+-------+-----+
|    period|student|score|
+----------+-------+-----+
|winter2014|  Agata|   99|
|winter2014|  Jacek|   97|
|summer2015|  Agata|  100|
|summer2015|  Jacek|   63|
|winter2015|  Agata|   97|
|winter2015|  Jacek|   55|
|summer2016|  Agata|   98|
|summer2016|  Jacek|   97|
+----------+-------+-----+

// ordering and empty rows done manually for demo purposes
scala> quarterlyScores.rollup("period", "student").sum("score").show
+----------+-------+----------+
|    period|student|sum(score)|
+----------+-------+----------+
|winter2014|  Agata|        99|
|winter2014|  Jacek|        97|
|winter2014|   null|       196|
|          |       |          |
|summer2015|  Agata|       100|
|summer2015|  Jacek|        63|
|summer2015|   null|       163|
|          |       |          |
|winter2015|  Agata|        97|
|winter2015|  Jacek|        55|
|winter2015|   null|       152|
|          |       |          |
|summer2016|  Agata|        98|
|summer2016|  Jacek|        97|
|summer2016|   null|       195|
|          |       |          |
|      null|   null|       706|
+----------+-------+----------+



///HandsOn cube and rollup  
import java.time._
import java.sql.Date
val expenses = Seq(
  ((2012, Month.DECEMBER, 12), 5),
  ((2016, Month.AUGUST, 13), 10),
  ((2017, Month.MAY, 27), 15))
  .map { case ((yy, mm, dd), a) => (LocalDate.of(yy, mm, dd), a) }
  .map { case (d, a) => (d.toString, a) }
  .map { case (d, a) => (Date.valueOf(d), a) }
  .toDF("date", "amount")
scala> expenses.show
+----------+------+
|      date|amount|
+----------+------+
|2012-12-12|     5|
|2016-08-13|    10|
|2017-05-27|    15|
+----------+------+

// rollup 
val q = expenses
  .rollup(year($"date") as "year", month($"date") as "month")
  .agg(F.sum("amount") as "amount")
  .sort($"year".asc_nulls_last, $"month".asc_nulls_last)
scala> q.show
+----+-----+------+
|year|month|amount|
+----+-----+------+
|2012|   12|     5|
|2012| null|     5|
|2016|    8|    10|
|2016| null|    10|
|2017|    5|    15|
|2017| null|    15|
|null| null|    30|
+----+-----+------+






///+++ Performance Tunng - Number of Partitions for groupBy Aggregation
//The goal of the case study is to fine tune the number of partitions used for groupBy aggregation.

//Given the following 2-partition dataset the task is to write a structured query 
//so there are no empty partitions (or as little as possible).

// 2-partition dataset
val ids = spark.range(start = 0, end = 4, step = 1, numPartitions = 2)
scala> ids.show
+---+
| id|
+---+
|  0|
|  1|
|  2|
|  3|
+---+
//(2) means number of partitions 
//indentation means Shuffle stage 
scala> ids.rdd.toDebugString
res1: String =
(2) MapPartitionsRDD[8] at rdd at <console>:26 []
 |  MapPartitionsRDD[7] at rdd at <console>:26 []
 |  MapPartitionsRDD[6] at rdd at <console>:26 []
 |  MapPartitionsRDD[5] at rdd at <console>:26 []
 |  ParallelCollectionRDD[4] at rdd at <console>:26 []

///By default Spark SQL uses spark.sql.shuffle.partitions number of partitions for aggregations and joins, i.e. 200 by default.
//That often leads to explosion of partitions for nothing 
//that does impact the performance of a query since these 200 tasks (per partition) have all to start and finish before you get the result.


///Case 1: Default Number of Partitions�spark.sql.shuffle.partitions Property

//how many partitions the following query really requires
val groupingExpr = 'id % 2 as "group" //'
val q = ids.
  groupBy(groupingExpr).
  agg(count($"id") as "count")

//You may have expected to have at most 2 partitions given the number of groups.
//Wrong!

scala> q.explain
== Physical Plan ==
*HashAggregate(keys=[(id#0L % 2)#17L], functions=[count(1)])
+- Exchange hashpartitioning((id#0L % 2)#17L, 200)
   +- *HashAggregate(keys=[(id#0L % 2) AS (id#0L % 2)#17L], functions=[partial_count(1)])
      +- *Range (0, 4, step=1, splits=2)

scala> q.rdd.toDebugString
res5: String =
(200) MapPartitionsRDD[16] at rdd at <console>:30 []
  |   MapPartitionsRDD[15] at rdd at <console>:30 []
  |   MapPartitionsRDD[14] at rdd at <console>:30 []
  |   ShuffledRowRDD[13] at rdd at <console>:30 []
  +-(2) MapPartitionsRDD[12] at rdd at <console>:30 []
     |  MapPartitionsRDD[11] at rdd at <console>:30 []
     |  MapPartitionsRDD[10] at rdd at <console>:30 []
     |  ParallelCollectionRDD[9] at rdd at <console>:30 []

//When you execute the query you should see 200 or so partitions in use in web UI.
scala> q.show
+-----+-----+
|group|count|
+-----+-----+
|    0|    2|
|    1|    2|
+-----+-----+


///Case 2: Using repartition Operator
//repartition operator is indeed a step in a right direction 
//when used with caution as it may lead to an unnecessary shuffle (aka exchange in Spark SQL�s parlance).

val groupingExpr = 'id % 2 as "group"  //'
val q = ids.
  repartition(groupingExpr). // <-- repartition per groupBy expression
  groupBy(groupingExpr).
  agg(count($"id") as "count")

//You may have expected 2 partitions again!
//Wrong! This is worse than case-1 
scala> q.explain
== Physical Plan ==
*HashAggregate(keys=[(id#6L % 2)#105L], functions=[count(1)])
+- Exchange hashpartitioning((id#6L % 2)#105L, 200)
   +- *HashAggregate(keys=[(id#6L % 2) AS (id#6L % 2)#105L], functions=[partial_count(1)])
      +- Exchange hashpartitioning((id#6L % 2), 200)
         +- *Range (0, 4, step=1, splits=2)

scala> q.rdd.toDebugString
res1: String =
(200) MapPartitionsRDD[57] at rdd at <console>:30 []
  |   MapPartitionsRDD[56] at rdd at <console>:30 []
  |   MapPartitionsRDD[55] at rdd at <console>:30 []
  |   ShuffledRowRDD[54] at rdd at <console>:30 []
  +-(200) MapPartitionsRDD[53] at rdd at <console>:30 []
      |   MapPartitionsRDD[52] at rdd at <console>:30 []
      |   ShuffledRowRDD[51] at rdd at <console>:30 []
      +-(2) MapPartitionsRDD[50] at rdd at <console>:30 []
         |  MapPartitionsRDD[49] at rdd at <console>:30 []
         |  MapPartitionsRDD[48] at rdd at <console>:30 []
         |  ParallelCollectionRDD[47] at rdd at <console>:30 []


///Case 3: Using repartition Operator With Explicit Number of Partitions
//repartition operator accepts an additional parameter for the number of partitions 
repartition(numPartitions: Int, partitionExprs: Column*): Dataset[T]

val groupingExpr = 'id % 2 as "group"  //'
val q = ids.
  repartition(numPartitions = 2, groupingExpr). // <-- repartition per groupBy expression
  groupBy(groupingExpr).
  agg(count($"id") as "count")

//You may have expected 2 partitions again!
//Correct!

scala> q.explain
== Physical Plan ==
*HashAggregate(keys=[(id#6L % 2)#129L], functions=[count(1)])
+- Exchange hashpartitioning((id#6L % 2)#129L, 200)
   +- *HashAggregate(keys=[(id#6L % 2) AS (id#6L % 2)#129L], functions=[partial_count(1)])
      +- Exchange hashpartitioning((id#6L % 2), 2)
         +- *Range (0, 4, step=1, splits=2)

scala> q.rdd.toDebugString
res14: String =
(200) MapPartitionsRDD[78] at rdd at <console>:30 []
  |   MapPartitionsRDD[77] at rdd at <console>:30 []
  |   MapPartitionsRDD[76] at rdd at <console>:30 []
  |   ShuffledRowRDD[75] at rdd at <console>:30 []
  +-(2) MapPartitionsRDD[74] at rdd at <console>:30 []
     |  MapPartitionsRDD[73] at rdd at <console>:30 []
     |  ShuffledRowRDD[72] at rdd at <console>:30 []
     +-(2) MapPartitionsRDD[71] at rdd at <console>:30 []
        |  MapPartitionsRDD[70] at rdd at <console>:30 []
        |  MapPartitionsRDD[69] at rdd at <console>:30 []
        |  ParallelCollectionRDD[68] at rdd at <console>:30 []


///Case 4: set spark.sql.shuffle.partitions Property Properly

import org.apache.spark.sql.internal.SQLConf.SHUFFLE_PARTITIONS
spark.conf.set(SHUFFLE_PARTITIONS.key, 2)

scala> spark.sessionState.conf.numShufflePartitions
res8: Int = 2

val q = ids.
  groupBy(groupingExpr).
  agg(count($"id") as "count")

scala> q.explain
== Physical Plan ==
*HashAggregate(keys=[(id#0L % 2)#40L], functions=[count(1)])
+- Exchange hashpartitioning((id#0L % 2)#40L, 2)
   +- *HashAggregate(keys=[(id#0L % 2) AS (id#0L % 2)#40L], functions=[partial_count(1)])
      +- *Range (0, 4, step=1, splits=2)

scala> q.rdd.toDebugString
res10: String =
(2) MapPartitionsRDD[31] at rdd at <console>:31 []
 |  MapPartitionsRDD[30] at rdd at <console>:31 []
 |  MapPartitionsRDD[29] at rdd at <console>:31 []
 |  ShuffledRowRDD[28] at rdd at <console>:31 []
 +-(2) MapPartitionsRDD[27] at rdd at <console>:31 []
    |  MapPartitionsRDD[26] at rdd at <console>:31 []
    |  MapPartitionsRDD[25] at rdd at <console>:31 []
    |  ParallelCollectionRDD[24] at rdd at <console>:31 []  //'


//'
    
    
    
    
    
    
    
    

///+++ Dataset Caching and Persistence
val ds = spark.range(5).cache

cache(): this.type
    cache merely executes the no-argument persist method.
persist(): this.type
persist(newLevel: StorageLevel): this.type
    persist caches the Dataset using the default storage level MEMORY_AND_DISK or newLevel and returns it.
unpersist(blocking: Boolean): this.type
    unpersist uncache the Dataset possibly by blocking the call.

// Cache Dataset -- it is lazy
scala> val df = spark.range(1).cache
df: org.apache.spark.sql.Dataset[Long] = [id: bigint]

// Trigger caching
scala> df.show
+---+
| id|
+---+
|  0|
+---+

// Visit http://localhost:4040/storage to see the Dataset cached. It should.

// You may also use queryExecution or explain to see InMemoryRelation
// InMemoryRelation is used for cached queries
scala> df.queryExecution.withCachedData
res0: org.apache.spark.sql.catalyst.plans.logical.LogicalPlan =
InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
   +- *Range (0, 1, step=1, splits=Some(8))

// Use the cached Dataset in another query
// Notice InMemoryRelation in use for cached queries
scala> df.withColumn("newId", 'id).explain(extended = true)  //'
== Parsed Logical Plan ==
'Project [*, 'id AS newId#16]
+- Range (0, 1, step=1, splits=Some(8))

== Analyzed Logical Plan ==
id: bigint, newId: bigint
Project [id#0L, id#0L AS newId#16L]
+- Range (0, 1, step=1, splits=Some(8))

== Optimized Logical Plan ==
Project [id#0L, id#0L AS newId#16L]
+- InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
      +- *Range (0, 1, step=1, splits=Some(8))

== Physical Plan ==
*Project [id#0L, id#0L AS newId#16L]
+- InMemoryTableScan [id#0L]
      +- InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
            +- *Range (0, 1, step=1, splits=Some(8))

// Clear in-memory cache using SQL
// Equivalent to spark.catalog.clearCache
scala> sql("CLEAR CACHE").collect
res1: Array[org.apache.spark.sql.Row] = Array()   //'

// Visit http://localhost:4040/storage to confirm the cleaning

//You can also use SQL�s CACHE TABLE [tableName] to cache tableName table in memory. 
//Unlike cache and persist operators, CACHE TABLE is an eager operation 
sql("CACHE TABLE [tableName]")

//use LAZY keyword to make caching lazy.

sql("CACHE LAZY TABLE [tableName]")

//Use SQL�s REFRESH TABLE [tableName] to refresh a cached table.

//Use SQL�s UNCACHE TABLE (IF EXISTS) [tableName] to remove a table from cache.

//Use SQL�s CLEAR CACHE to remove all tables from cache.


//Be careful what you cache, i.e. what Dataset is cached, as it gives different queries cached.

// cache after range(5)
val q1 = spark.range(5).cache.filter($"id" % 2 === 0).select("id")
scala> q1.explain
== Physical Plan ==
*Filter ((id#0L % 2) = 0)
+- InMemoryTableScan [id#0L], [((id#0L % 2) = 0)]
      +- InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
            +- *Range (0, 5, step=1, splits=8)

// cache at the end
val q2 = spark.range(1).filter($"id" % 2 === 0).select("id").cache
scala> q2.explain
== Physical Plan ==
InMemoryTableScan [id#17L]
   +- InMemoryRelation [id#17L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
         +- *Filter ((id#17L % 2) = 0)
            +- *Range (0, 1, step=1, splits=8)

//You can check whether a Dataset was cached or not using the following code:
//Note sharedState was private in release before 2.3.0
scala> :type q2
org.apache.spark.sql.Dataset[org.apache.spark.sql.Row]

val cache = spark.sharedState.cacheManager
scala> cache.lookupCachedData(q2.queryExecution.logical).isDefined
res0: Boolean = false






            
            
            
            
            
            
            
            

///+++ Generating Time based window Function
F.window(col_timestamp , windowDuration,slideDuration =None,startTime =None)
    Note this is time based window to be used witnin groupby(window(..)), 
    
    To have window based on current row +/- few rows or current row value +/- some range, 
    use Window class along with F.func(col).over(WindowClassInstance)        
    
    Bucketize rows into one or more time windows given a column with timestamp 
    Window starts are inclusive but the window ends are exclusive, 
    e.g. 12:05 will be in the window [12:05,12:10) but not in [12:00,12:05). 
    Windows can support microsecond precision. 
    Windows in the order of months are not supported.

    The time column must be of org.apache.spark.sql.types.TimestampType.
    Durations(windowDuration, slideDuration)  are provided as strings, 
    e.g. "1 second", "1 day 12 hours", "2 minutes".
    Valid interval strings are "week", "day", "hour", "minute", "second", "millisecond", "microsecond". 
    If the slideDuration is not provided, the windows will be tumbling windows.

    The startTime is the offset with respect to 1970-01-01 00:00:00 UTC 
    with which to start window intervals. 

    The output column will be a struct called "window" by default 
    with the nested columns "start" and "end", 
    where "start" and "end" will be of org.apache.spark.sql.types.TimestampType.

//Example 
val df = sc.parallelize( ("2016-03-11 09:00:07", 1)::Nil).toDF("date", "val")

val w = df.groupBy(window($"date", "5 seconds")).agg(F.sum("val").alias("sum"))
>>> w.select(F.col("window.start").cast("string").alias("start"), F.col("window.end").cast("string").alias("end"), $"sum").collect()
[Row(start =u"2016-03-11 09:00:05",end =u"2016-03-11 09:00:10",sum =1)] 




///HandsOn - window 
import java.sql.Timestamp
val levels = Seq(
  // (year, month, dayOfMonth, hour, minute, second)
  ((2012, 12, 12, 12, 12, 12), 5),
  ((2012, 12, 12, 12, 12, 14), 9),
  ((2012, 12, 12, 13, 13, 14), 4),
  ((2016, 8,  13, 0, 0, 0), 10),
  ((2017, 5,  27, 0, 0, 0), 15)).
  map { case ((yy, mm, dd, h, m, s), a) => (LocalDateTime.of(yy, mm, dd, h, m, s), a) }.
  map { case (ts, a) => (Timestamp.valueOf(ts), a) }.
  toDF("time", "level")
scala> levels.show
+-------------------+-----+
|               time|level|
+-------------------+-----+
|2012-12-12 12:12:12|    5|
|2012-12-12 12:12:14|    9|
|2012-12-12 13:13:14|    4|
|2016-08-13 00:00:00|   10|
|2017-05-27 00:00:00|   15|
+-------------------+-----+

val q = levels.select(F.window($"time", "5 seconds"), $"level")
scala> q.show(truncate = false)
+---------------------------------------------+-----+
|window                                       |level|
+---------------------------------------------+-----+
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|5    |
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|9    |
|[2012-12-12 13:13:10.0,2012-12-12 13:13:15.0]|4    |
|[2016-08-13 00:00:00.0,2016-08-13 00:00:05.0]|10   |
|[2017-05-27 00:00:00.0,2017-05-27 00:00:05.0]|15   |
+---------------------------------------------+-----+

scala> q.printSchema
root
 |-- window: struct (nullable = true)
 |    |-- start: timestamp (nullable = true)
 |    |-- end: timestamp (nullable = true)
 |-- level: integer (nullable = false)

// calculating the sum of levels every 5 seconds
val sums = levels.
  groupBy(F.window($"time", "5 seconds")).
  agg(F.sum("level") as "level_sum").
  select("window.start", "window.end", "level_sum")
scala> sums.show
+-------------------+-------------------+---------+
|              start|                end|level_sum|
+-------------------+-------------------+---------+
|2012-12-12 13:13:10|2012-12-12 13:13:15|        4|
|2012-12-12 12:12:10|2012-12-12 12:12:15|       14|
|2016-08-13 00:00:00|2016-08-13 00:00:05|       10|
|2017-05-27 00:00:00|2017-05-27 00:00:05|       15|
+-------------------+-------------------+---------+







///+++ Generating Records  based window Function

class Column
    over(window)
        Define a windowing column.
        
        
class org.apache.spark.sql.expressions.Window
    Rows between means current row +/- few rows (could be unboundedPreceding, unboundedFollowing) 
    Range between means current row value +/- value range(could be -Inf, +Inf as np.iinfo(np.int64).max/min) 
    
    PartitionBy on cols are must 

    classmethod  orderBy(*cols)
        Creates a WindowSpec with the ordering defined.        
    classmethod partitionBy(*cols)
        Creates a WindowSpec with the partitioning defined.
    classmethod rangeBetween(start, end)
    classmethod rowsBetween(start, end)
    val unboundedFollowing = 9223372036854775807
    val unboundedPreceding = -9223372036854775808L
    val currentRow = 0
    
///Example 
import org.apache.spark.sql.expressions._

// PARTITION BY country ORDER BY date RANGE BETWEEN 3 PRECEDING AND 3 FOLLOWING
val window = Window.orderBy("date").partitionBy("country").rangeBetween(-3, 3)

// ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
val window = Window.orderBy("name").rowsBetween(Window.unboundedPreceding, Window.currentRow)

val df =sc.parallelize(Array((2, "Alice"), (5, "Bob"))).toDF("age","name")
df.select(F.rank().over(window), F.min("age").over(window))

///difference between rangeBetween and rowsBetween
ROWS BETWEEN doesnot care about the exact values. 
    It cares only about the order of rows when computing frame.
RANGE BETWEEN considers values when computing frame.
    
//example using two window definitions:
ORDER BY x ROWS BETWEEN 2  PRECEDING AND CURRENT ROW
ORDER BY x RANGE BETWEEN 2  PRECEDING AND CURRENT ROW
//and data as
+---+
|  x|
+---+
| 10|
| 20|
| 30|
| 31|
+---+

//Assuming the current row is the one with value 31 for the first window 
//following rows will be included (current one, and two preceding):
+---+----------------------------------------------------+
|  x|ORDER BY x ROWS BETWEEN 2  PRECEDING AND CURRENT ROW|
+---+----------------------------------------------------+
| 10|                                               false|
| 20|                                                true|
| 30|                                                true|
| 31|                                                true|
+---+----------------------------------------------------+

//and for the second one following (current one, and all preceding where x >= 31 - 2):
+---+-----------------------------------------------------+
|  x|ORDER BY x RANGE BETWEEN 2  PRECEDING AND CURRENT ROW|
+---+-----------------------------------------------------+
| 10|                                                false|
| 20|                                                false|
| 30|                                                 true|
| 31|                                                 true|
+---+-----------------------------------------------------+



 
      
        
///Window function -  To be used as F.func(col).over(window)
//Spark SQL supports three kinds of window functions:
// ranking functions  - rank,dense_rank,percent_rank,ntile,row_number
// analytic functions - cum_dist,lag,lead
// aggregate functions
    avg(col)
    count(col)
    countDistinct(col, *cols)
    first(col,ignorenulls =false)
    kurtosis(col)
    last(col,ignorenulls =false)
    max(col)
    mean(col)
    min(col)
    skewness(col)
    stddev(col)
    stddev_pop(col)
    stddev_samp(col)
    sum(col)
    sumDistinct(col)
    var_pop(col)
    var_samp(col)
    variance(col)
    cume_dist()
        returns the cumulative distribution of values within a window partition, 
        i.e. the fraction of rows that are below the current row.
    dense_rank()
        returns the rank of rows within a window partition, without any gaps.
    rank()
        returns the rank of rows within a window partition.
        The difference between rank and denseRank is that 
        denseRank leaves no gaps in ranking sequence when there are ties. 
        For example, if you were ranking a competition using denseRank 
        and had three people tie for second place, you would say that all three were in second place 
        and that the next person came in third.
        Rank would give  sequential numbers, making the person that came in third place 
        (after the ties) would register as coming in fifth.
    lag(col,count =1,default =None)
        returns the value that is offset rows before the current row, 
        and defaultValue if there is less than offset rows before the current row. 
        For example, an offset of one will return the previous row at any given point 
        in the window partition.
    lead(col,count =1,default =None)
        returns the value that is offset rows after the current row
    ntile(n)
        returns the ntile group id (from 1 to n inclusive) 
        in an ordered window partition. 
        For example, if n is 4, the first quarter of the rows will get value 1, 
        the second quarter will get 2, the third quarter will get 3, 
        and the last quarter will get 4.
    percent_rank()
        returns the relative rank (i.e. percentile) of rows within a window partition.
    row_number()
        returns a sequential number starting at 1 within a window partition. 



//Example 
case class Salary(depName: String, empNo: Long, salary: Long)
val empsalary = Seq(
  Salary("sales", 1, 5000),
  Salary("personnel", 2, 3900),
  Salary("sales", 3, 4800),
  Salary("sales", 4, 4800),
  Salary("personnel", 5, 3500),
  Salary("develop", 7, 4200),
  Salary("develop", 8, 6000),
  Salary("develop", 9, 4500),
  Salary("develop", 10, 5200),
  Salary("develop", 11, 5200)).toDS

import org.apache.spark.sql.expressions.Window
// Windows are partitions of deptName
scala> val byDepName = Window.partitionBy('depName)  //'
byDepName: org.apache.spark.sql.expressions.WindowSpec = org.apache.spark.sql.expressions.WindowSpec@1a711314

scala> empsalary.withColumn("avg", F.avg('salary) over byDepName).show   //'
+---------+-----+------+-----------------+
|  depName|empNo|salary|              avg|
+---------+-----+------+-----------------+
|  develop|    7|  4200|           5020.0|
|  develop|    8|  6000|           5020.0|
|  develop|    9|  4500|           5020.0|
|  develop|   10|  5200|           5020.0|
|  develop|   11|  5200|           5020.0|
|    sales|    1|  5000|4866.666666666667|
|    sales|    3|  4800|4866.666666666667|
|    sales|    4|  4800|4866.666666666667|
|personnel|    2|  3900|           3700.0|
|personnel|    5|  3500|           3700.0|
+---------+-----+------+-----------------+



///Ordering in Windows�orderBy Methods
import org.apache.spark.sql.expressions.Window
val byDepnameSalaryDesc = Window.partitionBy('depname).orderBy('salary desc)

// a numerical rank within the current row's partition for each distinct ORDER BY value
scala> val rankByDepname = rank().over(byDepnameSalaryDesc)
rankByDepname: org.apache.spark.sql.Column = RANK() OVER (PARTITION BY depname ORDER BY salary DESC UnspecifiedFrame)

scala> empsalary.select('*, rankByDepname as 'rank).show
+---------+-----+------+----+
|  depName|empNo|salary|rank|
+---------+-----+------+----+
|  develop|    8|  6000|   1|
|  develop|   10|  5200|   2|
|  develop|   11|  5200|   2|
|  develop|    9|  4500|   4|
|  develop|    7|  4200|   5|
|    sales|    1|  5000|   1|
|    sales|    3|  4800|   2|
|    sales|    4|  4800|   2|
|personnel|    2|  3900|   1|
|personnel|    5|  3500|   2|
+---------+-----+------+----+



///Example - Difference on Column
//Compute a difference between values in rows in a column.

val pairs = for {
  x <- 1 to 5
  y <- 1 to 2
} yield (x, 10 * x * y)
val ds = pairs.toDF("ns", "tens")

>>> ds.show()
+---+----+
| ns|tens|
+---+----+
|  1|  10|
|  1|  20|
|  2|  20|
|  2|  40|
|  3|  30|
|  3|  60|
|  4|  40|
|  4|  80|
|  5|  50|
|  5| 100|
+---+----+

import org.apache.spark.sql.expressions.Window
val overNs = Window.partitionBy('ns).orderBy('tens)
val diff = F.lead('tens, 1).over(overNs)

scala> ds.withColumn("diff", diff - 'tens).show
+---+----+----+
| ns|tens|diff|
+---+----+----+
|  1|  10|  10|
|  1|  20|null|
|  3|  30|  30|
|  3|  60|null|
|  5|  50|  50|
|  5| 100|null|
|  4|  40|  40|
|  4|  80|null|
|  2|  20|  20|
|  2|  40|null|
+---+----+----+














///HandsOn - Partitioning Records�partitionBy Methods

// partition records into two groups
// * tokens starting with "h"
// * others



import org.apache.spark.sql.expressions.Window

scala> val byHTokens = Window.partitionBy('token startsWith "h")  //'
byHTokens: org.apache.spark.sql.expressions.WindowSpec = org.apache.spark.sql.expressions.WindowSpec@574985d8

val tokens = Seq("hello", "henry", "and", "harry")
  .zipWithIndex
  .map(_.swap)
  .toDF("id", "token")
  
// count the sum of ids in each group
val result = tokens.select('*, F.sum('id) over byHTokens as "sum over h tokens").orderBy('id) //'

scala> result.show
+---+-----+-----------------+
| id|token|sum over h tokens|
+---+-----+-----------------+
|  0|hello|                4|
|  1|henry|                4|
|  2|  and|                2|
|  3|harry|                4|
+---+-----+-----------------+




///Another HandsOn  -Top N per Group
//Top N per Group is useful when you need to compute the first and second best-sellers in category.

//Question: What are the best-selling and the second best-selling products in every category

val data = Seq(
  ("Thin",       "cell phone", 6000),
  ("Normal",     "tablet",     1500),
  ("Mini",       "tablet",     5500),
  ("Ultra thin", "cell phone", 5000),
  ("Very thin",  "cell phone", 6000),
  ("Big",        "tablet",     2500),
  ("Bendable",   "cell phone", 3000),
  ("Foldable",   "cell phone", 3000),
  ("Pro",        "tablet",     4500),
  ("Pro2",       "tablet",     6500))
  .toDF("product", "category", "revenue")

scala> data.show
+----------+----------+-------+
|   product|  category|revenue|
+----------+----------+-------+
|      Thin|cell phone|   6000|
|    Normal|    tablet|   1500|
|      Mini|    tablet|   5500|
|Ultra thin|cell phone|   5000|
| Very thin|cell phone|   6000|
|       Big|    tablet|   2500|
|  Bendable|cell phone|   3000|
|  Foldable|cell phone|   3000|
|       Pro|    tablet|   4500|
|      Pro2|    tablet|   6500|
+----------+----------+-------+

scala> data.where('category === "tablet").show  //'
+-------+--------+-------+
|product|category|revenue|
+-------+--------+-------+
| Normal|  tablet|   1500|
|   Mini|  tablet|   5500|
|    Big|  tablet|   2500|
|    Pro|  tablet|   4500|
|   Pro2|  tablet|   6500|
+-------+--------+-------+

//The question boils down to ranking products in a category 
//based on their revenue, and to pick the best selling and the second best-selling products 
//based the ranking.

import org.apache.spark.sql.expressions.Window
val overCategory = Window.partitionBy('category).orderBy('revenue.desc)

val ranked = data.withColumn("rank", F.dense_rank.over(overCategory))

scala> ranked.show
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|       Pro|    tablet|   4500|   3|
|       Big|    tablet|   2500|   4|
|    Normal|    tablet|   1500|   5|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
|  Bendable|cell phone|   3000|   3|
|  Foldable|cell phone|   3000|   3|
+----------+----------+-------+----+

scala> ranked.where('rank <= 2).show  //'
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
+----------+----------+-------+----+

///Revenue Difference per Category
import org.apache.spark.sql.expressions.Window
val reveDesc = Window.partitionBy('category).orderBy('revenue.desc)
val reveDiff =F.max('revenue).over(reveDesc) - 'revenue

scala> data.select('*, reveDiff as 'revenue_diff).show
+----------+----------+-------+------------+
|   product|  category|revenue|revenue_diff|
+----------+----------+-------+------------+
|      Pro2|    tablet|   6500|           0|
|      Mini|    tablet|   5500|        1000|
|       Pro|    tablet|   4500|        2000|
|       Big|    tablet|   2500|        4000|
|    Normal|    tablet|   1500|        5000|
|      Thin|cell phone|   6000|           0|
| Very thin|cell phone|   6000|           0|
|Ultra thin|cell phone|   5000|        1000|
|  Bendable|cell phone|   3000|        3000|
|  Foldable|cell phone|   3000|        3000|
+----------+----------+-------+------------+




///HandsOn - Running Total
//The running total is the sum of all previous lines including the current one.

val sales = Seq(
  (0, 0, 0, 5),
  (1, 0, 1, 3),
  (2, 0, 2, 1),
  (3, 1, 0, 2),
  (4, 2, 0, 8),
  (5, 2, 2, 8))
  .toDF("id", "orderID", "prodID", "orderQty")

scala> sales.show
+---+-------+------+--------+
| id|orderID|prodID|orderQty|
+---+-------+------+--------+
|  0|      0|     0|       5|
|  1|      0|     1|       3|
|  2|      0|     2|       1|
|  3|      1|     0|       2|
|  4|      2|     0|       8|
|  5|      2|     2|       8|
+---+-------+------+--------+

val orderedByID = Window.orderBy('id)

val totalQty = sum('orderQty).over(orderedByID).as('running_total)
val salesTotalQty = sales.select('*, totalQty).orderBy('id)  //'

scala> salesTotalQty.show
16/04/10 23:01:52 WARN Window: No Partition Defined for Window operation! Moving all data to a single partition, this can cause serious performance degradation.
+---+-------+------+--------+-------------+
| id|orderID|prodID|orderQty|running_total|
+---+-------+------+--------+-------------+
|  0|      0|     0|       5|            5|
|  1|      0|     1|       3|            8|
|  2|      0|     2|       1|            9|
|  3|      1|     0|       2|           11|
|  4|      2|     0|       8|           19|
|  5|      2|     2|       8|           27|
+---+-------+------+--------+-------------+

val byOrderId = orderedByID.partitionBy('orderID)
val totalQtyPerOrder = sum('orderQty).over(byOrderId).as('running_total_per_order)
val salesTotalQtyPerOrder = sales.select('*, totalQtyPerOrder).orderBy('id) //'

scala> salesTotalQtyPerOrder.show
+---+-------+------+--------+-----------------------+
| id|orderID|prodID|orderQty|running_total_per_order|
+---+-------+------+--------+-----------------------+
|  0|      0|     0|       5|                      5|
|  1|      0|     1|       3|                      8|
|  2|      0|     2|       1|                      9|
|  3|      1|     0|       2|                      2|
|  4|      2|     0|       8|                      8|
|  5|      2|     2|       8|                     16|
+---+-------+------+--------+-----------------------+








