
///*** REST client and  XML processing 
libraryDependencies += "org.apache.httpcomponents" % "httpclient" % "4.5.5"
//Example 
import java.io._
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.ClientProtocolException
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.DefaultHttpClient
import scala.collection.mutable.StringBuilder
import scala.xml.XML

object ScalaApacheHttpRestClient {

  def main(args: Array[String]) {
  
    // (1) get the content from the yahoo weather api url
    val content = getRestContent("http://weather.yahooapis.com/forecastrss?p=80020&u=f")
    
    // (2) convert it to xml
    val xml = XML.loadString(content)
    assert(xml.isInstanceOf[scala.xml.Elem])  // needed?

    // (3) search the xml for the nodes i want
    val temp = (xml \\ "channel" \\ "item" \ "condition" \ "@temp") text
    val text = (xml \\ "channel" \\ "item" \ "condition" \ "@text") text

    // (4) print the results
    val currentWeather = format("The current temperature is %s degrees, and the sky is %s.", temp, text.toLowerCase())
    println(currentWeather)
  }
  
  /**
   * Returns the text content from a REST URL. Returns a blank String if there
   * is a problem.
   */
  def getRestContent(url:String): String = {
    val httpClient = new DefaultHttpClient()
    val httpResponse = httpClient.execute(new HttpGet(url))
    val entity = httpResponse.getEntity()
    var content = ""
    if (entity != null) {
      val inputStream = entity.getContent()
      content = io.Source.fromInputStream(inputStream).getLines.mkString
      inputStream.close
    }
    httpClient.getConnectionManager().shutdown()
    return content
  }

}


///*** Accessing webservices via play ws (async-http-client)
//Build.sbt 
libraryDependencies += "com.typesafe.play" %% "play-ahc-ws-standalone" % "1.1.6"
//To add XML and JSON support using Play-JSON or Scala XML, add the following:
libraryDependencies += "com.typesafe.play" %% "play-ws-standalone-xml" % "1.1.6"
libraryDependencies += "com.typesafe.play" %% "play-ws-standalone-json" % "1.1.6"

//Example 
import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import play.api.libs.ws._
import play.api.libs.ws.ahc._

import scala.concurrent._ 
import scala.concurrent.duration._

object ScalaClient {
  import DefaultBodyReadables._
  import scala.concurrent.ExecutionContext.Implicits._

  def main(args: Array[String]): Unit = {
    // Create Akka system for thread and streaming management
    implicit val system = ActorSystem()
    system.registerOnTermination {
      System.exit(0)
    }
    implicit val materializer = ActorMaterializer()

    // Create the standalone WS client
    // no argument defaults to a AhcWSClientConfig created from
    // "AhcWSClientConfigFactory.forConfig(ConfigFactory.load, this.getClass.getClassLoader)"
    val ws = StandaloneAhcWSClient()

    call(ws)
      .andThen { case _ => wsClient.close() }
      .andThen { case _ => system.terminate() }
  }

  def call(wsClient: StandaloneWSClient): Future[Unit] = {
    wsClient.url("http://www.google.com").get().map { response =>
      val statusText: String = response.statusText
      val body = response.body[String]
      println(s"Got a response $statusText")
    }
  }
}

///*** Details of WS 

val request: WSRequest = ws.url(url)
//OR 
val complexRequest: WSRequest =
  request.addHttpHeaders("Accept" -> "application/json")
    .addQueryStringParameters("search" -> "play")
    .withRequestTimeout(10000.millis)

val futureResponse: Future[WSResponse] = complexRequest.get()


//Request with authentication
//Valid case objects for the AuthScheme are BASIC, DIGEST, KERBEROS, NTLM, and SPNEGO.
ws.url(url).withAuth(user, password, WSAuthScheme.BASIC).get()

//Request with follow redirects for If an HTTP call results in a 302 or a 301 redirect, 
ws.url(url).withFollowRedirects(true).get()

//Request with query parameters as a series of key/value tuples
ws.url(url).addQueryStringParameters("paramKey" -> "paramValue").get()

//Request with additional headers as a series of key/value tuples
ws.url(url).addHttpHeaders("headerKey" -> "headerValue").get()

//For sending plain text in a particular format, ,define the content type explicitly.
ws.url(url)
  .addHttpHeaders("Content-Type" -> "application/xml")
  .post(xmlString)

//Request with cookies
//by using DefaultWSCookie or by passing through play.api.mvc.Cookie. 
//Use addCookies to append cookies, and withCookies to overwrite all cookies.
ws.url(url).addCookies(DefaultWSCookie("cookieName", "cookieValue")).get()

//Request with virtual host,specified as a string.
ws.url(url).withVirtualHost("192.168.1.1").get()

//Request with timeout
//An infinite timeout can be set by passing Duration.Inf.
ws.url(url).withRequestTimeout(5000.millis).get()


//Submitting form data
//To post url-form-encoded data , use  Map[String, Seq[String]] 
//If the body is empty, use play.api.libs.ws.EmptyBody into the post method.
ws.url(url).post(Map("key" -> Seq("value")))



//Submitting JSON data
import play.api.libs.json._
val data = Json.obj(
  "key1" -> "value1",
  "key2" -> "value2"
)
val futureResponse: Future[WSResponse] = ws.url(url).post(data)


//Submitting XML data
val data = <person>
  <name>Steve</name>
  <age>23</age>
</person>
val futureResponse: Future[WSResponse] = ws.url(url).post(data)


//Processing the Response
//The WSResponse extends play.api.libs.ws.WSBodyReadables trait, 
//which contains type classes for Play JSON and Scala XML conversion. 


//Processing a response as JSON
//by calling response.json.
val futureResult: Future[String] = ws.url(url).get().map {
  response =>
    (response.json \ "person" \ "name").as[String]
}

//The JSON library has a useful feature 
//that will map an implicit Reads[T]  directly to a class:
import play.api.libs.json._

case class Person(name :String, age:Int)

implicit val personReads = Json.reads[Person]

val futureResult: Future[JsResult[Person]] = ws.url(url).get().map {
  response => (response.json \ "person").validate[Person]
}

//Processing a response as XML,by calling response.xml.
val futureResult: Future[scala.xml.NodeSeq] = ws.url(url).get().map {
  response =>
    response.xml \ "message"



///*** ws - typed Body 


import play.api.libs.ws.DefaultBodyReadables._
import play.api.libs.ws.DefaultBodyWritables._

//XML and JSON support:

import play.api.libs.ws.XMLBodyReadables._
import play.api.libs.ws.XMLBodyWritables._

import play.api.libs.ws.JsonBodyReadables._
import play.api.libs.ws.JsonBodyWritables._

//To use a BodyReadable in a response, 
//type the response explicitly:

val responseBody: Future[scala.xml.Elem] = ws.url(...).get().map { response =>
  response.body[scala.xml.Elem]
  //now  parse response 
}

val jsonBody: Future[JsValue] = ws.url(...).get().map { response =>
  response.body[JsValue]
  //now parse response 
}

//For when streaming the response, get the body as a Source:
ws.url(...).stream().map { response =>
   val source: Source[ByteString, NotUsed] = response.bodyAsSource
}

//To POST, use a type which has an implicit class mapping of BodyWritable:

val stringData = "Hello world"
ws.url(...).post(stringData).map { response => ... }

//custom BodyWritable, BodyReadable:

case class Foo(body: String)

implicit val fooBodyReadable = BodyReadable[Foo] { response =>
  import play.shaded.ahc.org.asynchttpclient.{ Response => AHCResponse }
  val ahcResponse = response.asInstanceOf[StandaloneAhcWSResponse].underlying[AHCResponse]
  Foo(ahcResponse.getResponseBody)
}


implicit val writeableOf_Foo: BodyWritable[Foo] = {
  // https://tools.ietf.org/html/rfc6838#section-3.2
  BodyWritable(foo => InMemoryBody(ByteString.fromString(foo.serialize)), application/vnd.company.category+foo)
}

///*** XML 

val v = <a> OK </a>  //space matters!!! , usually a signle Elem, v: scala.xml.Elem = <a> OK </a>
val v = <a>OK</a><a>NOK</a> //multiple ele , v: scala.xml.NodeBuffer = ArrayBuffer(<a>OK</a>, <a>NOK</a>)

"""
Class Node is the abstract superclass of all XML node classes.
    class  Elem extends Node with Serializable 
Class Text is a node holding just text. 
For example, the "stuff" part of <a>stuff</a> is of class Text.
Class NodeSeq holds a sequence of nodes . 
Individual Node is a one-element NodeSeq.
Any <, >, and & characters in the text will be escaped automatically by scala
Can put scala code inside {}, even nested XML

"""

<a> {"hello" + ", world"} </a>    //res1: scala.xml.Elem = <a> hello, world </a>

<a> {3 + 4} </a>  				//res3: scala.xml.Elem = <a> 7 </a>


val yearMade = 1955
<a>{ if (yearMade < 2000) <old>{yearMade}</old> else xml.NodeSeq.Empty }</a>

//Scala String would be escaped when used inside { }, to avoild 
scala> val bar=scala.xml.Unparsed(""""hello"""")
bar: scala.xml.Unparsed = "hello"

scala> val x = <script type="text/javascript">foo({bar});</script>
x: scala.xml.Elem = <script type="text/javascript">foo("hello");</script>

//Use text to get unescaped chars 
val amp = '&'
<a>{amp}</a>.toString  //res0: String = <a>&amp;</a>
import scala.xml._
import scala.xml._

<a>{amp}</a>.child(0)  //res1: scala.xml.Node = &amp;

val e1 = <a>{amp}</a>
scala> el.child(0)
res4: scala.xml.Node = &amp;
scala> el.child(0).text
res5: String = &

//To  include a curly brace (‘{’ or ‘}’) as XML text, write two curly braces in a row:
<a> {{brace yourself!}} </a>  //res7: scala.xml.Elem = <a> {brace yourself!} </a>


///*** XML - Methods of Elem
"""
x \ "div"     Searches the XML literal x for elements of type <div>. 
              Only searches immediate child nodes (no self or no grandchild or "descendant" nodes).
			  
x \@ "attr"	  Extracting attribute as string 

x \ "@attr"  Extracting attribute as NodeSeq 

x \\ "div"    Searches the XML literal x for elements of type <div>. 
              Returns matching  elements from child nodes at any depth of the XML tree.

x.attribute("name")   Returns the value of the given attribute in the current node.
                       <a x="10" y="20">foo</a>.attribute("x")   // returns Some(10).

x.attributes      Returns all attributes of the current node, prefixed and unprefixed, 
                  in no particular order.
                  val x = <a x="10" y="20">foo</a>.attributes  //scala.xml.MetaData =  x="10" y="20"
                   x("x")  //Seq[scala.xml.Node] = 10
                   
x.child           Returns the children of the current node.
                  <a><b>foo</b></a>.child   // returns <b>foo</b>.
					   
x.copy(...)       Returns a copy of the element, letting you replace data during the copy process.

x.label           The name of the current element. 
                       <a><b>foo</b></a>.label   // returns a.

x.text           Returns a concatenation of text(n) for each child n.

x.toString      Emits the XML literal as a String. 
                Use scala.xml.PrettyPrinter to format the output, if desired.
"""
//scala supports subset of XPath, only supports \ and \ "@" and \\


//Extracting text - call xml.Elem.text
<a>Sounds <tag/> good</a>.text  // String = Sounds good
<a> input ---&gt; output </a>.text // String = input --->output


//Extracting sub-elements

<a><b><c>hello</c></b></a> \ "b"    //< b><c>hello</c></b>
                                    // works only for sub-element, not first element or sub-sub element 

<a><b><c>hello</c></b></a> \ "c"   //scala.xml.NodeSeq =
<a><b><c>hello</c></b></a> \\ "c"  //scala.xml.NodeSeq = <c>hello</c>

<a><b><c>hello</c></b></a> \ "a"   //scala.xml.NodeSeq =
<a><b><c>hello</c></b></a> \\ "a"  / scala.xml.NodeSeq = <a><b><c>hello</c></b></a>

//Extracting attributes
val joe = <employee name="Joe" rank="code monkey" serial="123"/>
joe \@ "name"  	//scala.xml.NodeSeq = Joe
joe \ "@serial" 	//scala.xml.NodeSeq = 123


///*** XML - Serialization , Deserialization
//add toXML method

abstract class CCTherm {
  val description: String
  val yearMade: Int
  val dateObtained: String
 
  override def toString = description

  def toXML =
	<cctherm>
	  <description>{description}</description>
	  <yearMade>{yearMade}</yearMade>
	  <dateObtained>{dateObtained}</dateObtained>
	 </cctherm>

}


//Deserialization

object CCTherm {
def fromXML(node: scala.xml.Node): CCTherm =
	new CCTherm {
		val description = (node \ "description").text
		val yearMade = (node \ "yearMade").text.toInt
		val dateObtained = (node \ "dateObtained").text

		}
}

val therm = new CCTherm {    		// Anon class derives from CCTherm
 val description = "Desc"
 val yearMade = 1952
 val dateObtained = "somedate"
}

val node = therm.toXML
val nTherm = CCTherm.fromXML(node)   // Get back
//To convert XML to a string, call  node.toString 
node.toString 

//Saving and loading 
scala.xml.XML.save("therm1.xml", node)  // saving a node

val loadnode = xml.XML.loadFile("therm1.xml") 
val nTherm = CCTherm.fromXML(loadnode) 

val xml = xml.XML.loadString(content)     // from String


///*** XML - Pattern matching on XML

def proc(node: scala.xml.Node): String =
	node match {
		case <a>{contents}</a> => "It's an a: "+ contents  //can not contain any XML node
		case <b>{contents}</b> => "It's a b: "+ contents
		case _ => "It's something else."
}
proc(<a>apple</a>)  				//String = It's an a: apple
proc(<a>a <em>red</em> apple</a>)  // Fails , String = It's something else.

def proc(node: scala.xml.Node): String =   // binding to internal
	node match {
		case <a>{contents @ _*}</a> => "It's an a: "+ contents
		case <b>{contents @ _*}</b> => "It's a b: "+ contents
		case _ => "It's something else."
}

proc(<a>a <em>red</em> apple</a>)  //String = It's an a: ArrayBuffer(a ,<em>red</em>, apple)

//*** XML - With Nampespae 
val str = """<a  xmlns="http://graphml.graphdrawing.org/xmlns" xmlns:x="urn:x">
   <b>b1</b>
   <x:b>b2</x:b>
   <b>b3</b>
</a>"""

val x = xml.XML.loadString(str)
x \\ "b" text  //b1b2b3
x \\ "b" filter ( z => z.namespace == "http://graphml.graphdrawing.org/xmlns") text //b1b3
val unprefixedTitle = (x \ "b").filter(_.prefix == null).text //b1b3
val dublinCoreTitle = (x \ "b").filter(_.prefix == "x").text  //b2












///*** Details of Elem class Elem  extends Node  
// providing an immutable data object representing an XML element. 
def % (updates: MetaData) : Elem  
    Returns a new element with updated attributes, resolving namespace uris from this element scope.
val attributes : MetaData  
    Returns attribute meaning all attributes of this node, prefixed and unprefixed, in no particular order.
def basisForHashCode : Seq[Any]  
val child : Node*  
    the children of this node
def copy (prefix: String = ..., label: String = ..., attributes: MetaData = ..., scope: NamespaceBinding = ..., child: Seq[Node] = ...) : Elem  
    Returns a copy of this element with any supplied arguments replacing this element value for that field.
def doCollectNamespaces : Boolean  
    The logic formerly found in typeTag$, as best I could infer it.
def doTransform : Boolean  
val label : String  
    the element name
val prefix : String  
    namespace prefix (may be null, but not the empty string)
val scope : NamespaceBinding  
    the scope containing the namespace bindings
def text : String  
    Returns concatenation of text(n) for each child n.


///*** XML - Details of Node ,class Node  extends NodeSeq 
def attribute (uri: String, key: String) : Option[Seq[Node]]  
    Convenience method, looks up a prefixed attribute in attributes of this node.
def attribute (key: String) : Option[Seq[Node]]  
    Convenience method, looks up an unprefixed attribute in attributes of this node.
def attributes : MetaData  
    Returns attribute meaning all attributes of this node, prefixed and unprefixed, in no particular order.
def basisForHashCode : Seq[Any]  
def buildString (stripComments: Boolean) : String  
    String representation of this node 
def canEqual (other: Any) : Boolean  
    We insist we are only equal to other xml.
def child : Seq[Node]  
    Returns child axis i.
def descendant : List[Node]  
    Descendant axis (all descendants of this node, not including node itself) includes all text nodes, element nodes, comments and processing instructions.
def descendant_or_self : List[Node]  
    Descendant axis (all descendants of this node, including thisa node) includes all text nodes, element nodes, comments and processing instructions.
def doCollectNamespaces : Boolean  
    The logic formerly found in typeTag$, as best I could infer it.
def doTransform : Boolean  
def getNamespace (pre: String) : String  
    Convenience method, same as scope.getURI(pre) but additionally checks if scope is null.
def isAtom : Boolean  
    used internally.
def label : String  
    label of this node.
def nameToString (sb: StringBuilder) : StringBuilder  
    Appends qualified name of this node to StringBuilder.
def namespace : String  
    convenience, same as getNamespace(this.prefix)
def nonEmptyChildren : Seq[Node]  
    Children which do not stringify to "" (needed for equality) 
def prefix : String  
    prefix of this node
def scope : NamespaceBinding  
    method returning the namespace bindings of this node.
def strict_== (other: Equality) : Boolean  
def text : String  
    Returns a text representation of this node.
def theSeq : Seq[Node]  
    returns a sequence consisting of only this node 
def toString () : String  
    Same as toString(false).
def xmlType () : TypeSymbol  
    Returns a type symbol 
    
///*** XML - Detailsof NodeSeq ,class NodeSeq  extends Seq[Node] with SeqLike[Node, NodeSeq] with Equality  
//This class implements a wrapper around Seq[Node] that adds XPath and comprehension methods.
//Main methods from this class 
def \ (that: String) : NodeSeq  
    Projection function, which returns elements of this sequence based on the string that.
def \\ (that: String) : NodeSeq  
    Projection function, which returns elements of this sequence and of all its subsequences, based on the string that.
def apply (f: (Node) ? Boolean) : NodeSeq  
def apply (i: Int) : Node  
    Selects an element by its index in the immutable sequence.
def basisForHashCode : Seq[Any]  
def canEqual (other: Any) : Boolean  
    We insist we are only equal to other xml.
def iterator : Iterator[Node]  
    Creates a new iterator over all elements contained in this iterable object.
def length : Int  
    The length of the immutable sequence.
def strict_== (other: Equality) : Boolean  
def text : String  
def theSeq : Seq[Node]  
def toString () : String  
    Converts this immutable sequence to a string.
def xml_sameElements [A] (that: Iterable[A]) : Boolean 

//Other methods from Seq etc 
def ++ (that: TraversableOnce[Node]) : immutable.Seq[Node]  
    Concatenates this immutable sequence with the elements of a traversable collection.
def ++ [B >: A, That] (that: TraversableOnce[B])(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
    Concatenates this immutable sequence with the elements of a traversable collection.
def +: (elem: Node) : immutable.Seq[Node]  
    Prepends an element to this immutable sequence
def +: [B >: A, That] (elem: B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
    Prepends an element to this immutable sequence
def /: [B] (z: B)(op: (B, Node) ? B) : B  
    Applies a binary operator to a start value and all elements of this immutable sequence, going left to right.
def :+ (elem: Node) : immutable.Seq[Node]  
    Appends an element to this immutable sequence
def :+ [B >: A, That] (elem: B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
    Appends an element to this immutable sequence
def :\ [B] (z: B)(op: (Node, B) ? B) : B  
    Applies a binary operator to all elements of this immutable sequence and a start value, going right to left.
def addString (b: StringBuilder) : StringBuilder  
    Appends all elements of this immutable sequence to a string builder.
def addString (b: StringBuilder, sep: String) : StringBuilder  
    Appends all elements of this immutable sequence to a string builder using a separator string.
def addString (b: StringBuilder, start: String, sep: String, end: String) : StringBuilder  
    Appends all elements of this immutable sequence to a string builder using start, end, and separator strings.
def andThen [C] (k: (Node) ? C) : PartialFunction[Int, C]  
    Composes this partial function with a transformation function that gets applied to results of this partial function.
def collect [B] (pf: PartialFunction[Node, B]) : immutable.Seq[B]  
    Builds a new collection by applying a partial function to all elements of this immutable sequence on which the function is defined.
def collect [B, That] (pf: PartialFunction[Node, B])(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
    Builds a new collection by applying a partial function to all elements of this immutable sequence on which the function is defined.
def companion : GenericCompanion[Seq]  
    The factory companion object that builds instances of class immutable.
def compose [A] (g: (A) ? Int) : (A) => Node  
    (f compose g)(x) == f(g(x)) 
def contains (elem: Any) : Boolean  
    Tests whether this immutable sequence contains a given value as an element.
def containsSlice [B] (that: Seq[B]) : Boolean  
    Tests whether this immutable sequence contains a given sequence as a slice.
def copyToArray (xs: Array[Node], start: Int, len: Int) : Unit  
    Copies elements of this immutable sequence to an array.
def copyToArray [B >: A] (xs: Array[B], start: Int, len: Int) : Unit  
    Copies elements of this immutable sequence to an array.
def copyToArray (xs: Array[Node]) : Unit  
    Copies values of this immutable sequence to an array.
def copyToArray [B >: A] (xs: Array[B]) : Unit  
    Copies values of this immutable sequence to an array.
def copyToArray (xs: Array[Node], start: Int) : Unit  
    Copies values of this immutable sequence to an array.
def copyToArray [B >: A] (xs: Array[B], start: Int) : Unit  
    Copies values of this immutable sequence to an array.
def copyToBuffer [B >: A] (dest: Buffer[B]) : Unit  
    Copies all elements of this immutable sequence to a buffer.
def corresponds [B] (that: Seq[B])(p: (Node, B) ? Boolean) : Boolean  
    Tests whether every element of this immutable sequence relates to the corresponding element of another sequence by satisfying a test predicate.
def count (p: (Node) ? Boolean) : Int  
    Counts the number of elements in the immutable sequence which satisfy a predicate.
def diff (that: Seq[Node]) : immutable.Seq[Node]  
    Computes the multiset difference between this immutable sequence and another sequence.
def diff [B >: A] (that: Seq[B]) : NodeSeq  
    Computes the multiset difference between this immutable sequence and another sequence.
def distinct : NodeSeq  
    Builds a new immutable sequence from this immutable sequence without any duplicate elements.
def drop (n: Int) : NodeSeq  
    Selects all elements except first n ones.
def dropRight (n: Int) : NodeSeq  
    Selects all elements except last n ones.
def dropWhile (p: (Node) ? Boolean) : NodeSeq  
    Drops longest prefix of elements that satisfy a predicate.
def elements : Iterator[Node]  
def endsWith [B] (that: Seq[B]) : Boolean  
    Tests whether this immutable sequence ends with the given sequence.
def equals (other: Any) : Boolean  
    The equality method defined in AnyRef.
def equalsWith [B] (that: Seq[B])(f: (Node, B) ? Boolean) : Boolean  
    Tests whether every element of this immutable sequence relates to the corresponding element of another sequence by satisfying a test predicate.
def exists (p: (Node) ? Boolean) : Boolean  
    Tests whether a predicate holds for some of the elements of this immutable sequence.
def filter (p: (Node) ? Boolean) : NodeSeq  
    Selects all elements of this immutable sequence which satisfy a predicate.
def filterNot (p: (Node) ? Boolean) : NodeSeq  
	Selects all elements of this immutable sequence which do not satisfy a predicate.
def find (p: (Node) ? Boolean) : Option[Node]  
	Finds the first element of the immutable sequence satisfying a predicate, if any.
def findIndexOf (p: (Node) ? Boolean) : Int  
	Returns index of the first element satisfying a predicate, or -1.
def findLastIndexOf (p: (Node) ? Boolean) : Int  
	Returns index of the last element satisfying a predicate, or -1.
def first : Node  
def firstOption : Option[Node]  
	None if iterable is empty.
def flatMap [B] (f: (Node) ? Traversable[B]) : immutable.Seq[B]  
	[use case] Builds a new collection by applying a function to all elements of this immutable sequence and concatenating the results.
def flatMap [B, That] (f: (Node) ? Traversable[B])(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Builds a new collection by applying a function to all elements of this immutable sequence and concatenating the results.
def flatten [B] : immutable.Seq[B]  
	[use case] Converts this immutable sequence of traversable collections into a immutable sequence in which all element collections are concatenated.
def flatten [B] (implicit asTraversable: (Node) ? Traversable[B]) : Seq[B]  
	Converts this immutable sequence of traversable collections into a immutable sequence in which all element collections are concatenated.
def foldLeft [B] (z: B)(op: (B, Node) ? B) : B  
	Applies a binary operator to a start value and all elements of this immutable sequence, going left to right.
def foldRight [B] (z: B)(op: (Node, B) ? B) : B  
	Applies a binary operator to all elements of this immutable sequence and a start value, going right to left.
def forall (p: (Node) ? Boolean) : Boolean  
	Tests whether a predicate holds for all elements of this immutable sequence.
def foreach (f: (Node) ? Unit) : Unit  
	[use case] Applies a function f to all elements of this immutable sequence.
def foreach [U] (f: (Node) ? U) : Unit  
	Applies a function f to all elements of this immutable sequence.
def genericBuilder [B] : Builder[B, Seq[B]]  
	The generic builder that builds instances of immutable.
def groupBy [K] (f: (Node) ? K) : Map[K, NodeSeq]  
	Partitions this immutable sequence into a map of immutable sequences according to some discriminator function.
def grouped (size: Int) : Iterator[NodeSeq]  
	Partitions elements in fixed size immutable sequences.
def hasDefiniteSize : Boolean  
	Tests whether this immutable sequence is known to have a finite size.
def hashCode () : Int  
	Its be nice to make these final, but there are probably people out there subclassing the XML types, especially when it comes to equals.
def head : Node  
	Selects the first element of this immutable sequence.
def headOption : Option[Node]  
	Optionally selects the first element.
def indexOf (elem: Node, from: Int) : Int  
	[use case] Finds index of first occurrence of some value in this immutable sequence after or at some start index.
def indexOf [B >: A] (elem: B, from: Int) : Int  
	Finds index of first occurrence of some value in this immutable sequence after or at some start index.
def indexOf (elem: Node) : Int  
	[use case] Finds index of first occurrence of some value in this immutable sequence.
def indexOf [B >: A] (elem: B) : Int  
	Finds index of first occurrence of some value in this immutable sequence.
def indexOfSlice [B >: A] (that: Seq[B], from: Int) : Int  
	Finds first index after or at a start index where this immutable sequence contains a given sequence as a slice.
def indexOfSlice [B >: A] (that: Seq[B]) : Int  
	Finds first index where this immutable sequence contains a given sequence as a slice.
def indexWhere (p: (Node) ? Boolean, from: Int) : Int  
	Finds index of the first element satisfying some predicate after or at some start index.
def indexWhere (p: (Node) ? Boolean) : Int  
	Finds index of first element satisfying some predicate.
def indices : Range  
	Produces the range of all indices of this sequence.
def init : NodeSeq  
	Selects all elements except the last.
def intersect (that: Seq[Node]) : immutable.Seq[Node]  
	[use case] Computes the multiset intersection between this immutable sequence and another sequence.
def intersect [B >: A] (that: Seq[B]) : NodeSeq  
	Computes the multiset intersection between this immutable sequence and another sequence.
def isDefinedAt (idx: Int) : Boolean  
	Tests whether this immutable sequence contains given index.
def isEmpty : Boolean  
	Tests whether this immutable sequence is empty.
def isTraversableAgain : Boolean  
	Tests whether this immutable sequence can be repeatedly traversed.
def last : Node  
	Selects the last element.
def lastIndexOf (elem: Node, end: Int) : Int  
	[use case] Finds index of last occurrence of some value in this immutable sequence before or at a given end index.
def lastIndexOf [B >: A] (elem: B, end: Int) : Int  
	Finds index of last occurrence of some value in this immutable sequence before or at a given end index.
def lastIndexOf (elem: Node) : Int  
	[use case] Finds index of last occurrence of some value in this immutable sequence.
def lastIndexOf [B >: A] (elem: B) : Int  
	Finds index of last occurrence of some value in this immutable sequence.
def lastIndexOfSlice [B >: A] (that: Seq[B], end: Int) : Int  
	Finds last index before or at a given end index where this immutable sequence contains a given sequence as a slice.
def lastIndexOfSlice [B >: A] (that: Seq[B]) : Int  
	Finds last index where this immutable sequence contains a given sequence as a slice.
def lastIndexWhere (p: (Node) ? Boolean, end: Int) : Int  
	Finds index of last element satisfying some predicate before or at given end index.
def lastIndexWhere (p: (Node) ? Boolean) : Int  
	Finds index of last element satisfying some predicate.
def lastOption : Option[Node]  
	Optionally selects the last element.
def lengthCompare (len: Int) : Int  
	Compares the length of this immutable sequence to a test value.
def lift : (Int) ? Option[Node]  
	Turns this partial function into an plain function returning an Option result.
def map [B] (f: (Node) ? B) : immutable.Seq[B]  
	[use case] Builds a new collection by applying a function to all elements of this immutable sequence.
def map [B, That] (f: (Node) ? B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Builds a new collection by applying a function to all elements of this immutable sequence.
def max : Node  
	[use case] Finds the largest element.
def max [B >: A] (implicit cmp: Ordering[B]) : Node  
	Finds the largest element.
def min : Node  
	[use case] Finds the smallest element.
def min [B >: A] (implicit cmp: Ordering[B]) : Node  
	Finds the smallest element.
def mkString : String  
	Displays all elements of this immutable sequence in a string.
def mkString (sep: String) : String  
	Displays all elements of this immutable sequence in a string using a separator string.
def mkString (start: String, sep: String, end: String) : String  
	Displays all elements of this immutable sequence in a string using start, end, and separator strings.
def nonEmpty : Boolean  
	Tests whether the immutable sequence is not empty.
def orElse [A1 <: A, B1 >: B] (that: PartialFunction[A1, B1]) : PartialFunction[A1, B1]  
	Composes this partial function with a fallback partial function which gets applied where this partial function is not defined.
def padTo (len: Int, elem: Node) : immutable.Seq[Node]  
	[use case] Appends an element value to this immutable sequence until a given target length is reached.
def padTo [B >: A, That] (len: Int, elem: B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Appends an element value to this immutable sequence until a given target length is reached.
def partition (p: (Node) ? Boolean) : (NodeSeq, NodeSeq)  
	Partitions this immutable sequence in two immutable sequences according to a predicate.
def patch (from: Int, that: Seq[Node], replaced: Int) : immutable.Seq[Node]  
	[use case] Produces a new immutable sequence where a slice of elements in this immutable sequence is replaced by another sequence.
def patch [B >: A, That] (from: Int, patch: Seq[B], replaced: Int)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Produces a new immutable sequence where a slice of elements in this immutable sequence is replaced by another sequence.
def prefixLength (p: (Node) ? Boolean) : Int  
	Returns the length of the longest prefix whose elements all satisfy some predicate.
def product : Node  
	[use case] Multiplies up the elements of this collection.
def product [B >: A] (implicit num: Numeric[B]) : B  
	Multiplies up the elements of this collection.
def projection : SeqView[Node, NodeSeq]  
	returns a projection that can be used to call non-strict filter,map, and flatMap methods that build projections of the collection.
def reduceLeft [B >: A] (op: (B, Node) ? B) : B  
	Applies a binary operator to all elements of this immutable sequence, going left to right.
def reduceLeftOption [B >: A] (op: (B, Node) ? B) : Option[B]  
	Optionally applies a binary operator to all elements of this immutable sequence, going left to right.
def reduceRight [B >: A] (op: (Node, B) ? B) : B  
	Applies a binary operator to all elements of this immutable sequence, going right to left.
def reduceRightOption [B >: A] (op: (Node, B) ? B) : Option[B]  
	Optionally applies a binary operator to all elements of this immutable sequence, going right to left.
def repr : NodeSeq  
	The collection of type immutable sequence underlying this TraversableLike object.
def reverse : NodeSeq  
	Returns new immutable sequence wih elements in reversed order.
def reverseIterator : Iterator[Node]  
	An iterator yielding elements in reversed order.
def reverseMap [B] (f: (Node) ? B) : immutable.Seq[B]  
	[use case] Builds a new collection by applying a function to all elements of this immutable sequence and collecting the results in reversed order.
def reverseMap [B, That] (f: (Node) ? B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Builds a new collection by applying a function to all elements of this immutable sequence and collecting the results in reversed order.
def reversedElements : Iterator[Node]  
def sameElements (that: Iterable[Node]) : Boolean  
	[use case] Checks if the other iterable collection contains the same elements in the same order as this immutable sequence.
def sameElements [B >: A] (that: Iterable[B]) : Boolean  
	Checks if the other iterable collection contains the same elements in the same order as this immutable sequence.
def scanLeft [B, That] (z: B)(op: (B, Node) ? B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Produces a collection containing cummulative results of applying the operator going left to right.
def scanRight [B, That] (z: B)(op: (Node, B) ? B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Produces a collection containing cummulative results of applying the operator going right to left.
def segmentLength (p: (Node) ? Boolean, from: Int) : Int  
	Computes length of longest segment whose elements all satisfy some predicate.
def size : Int  
	The size of this immutable sequence, equivalent to length.
def slice (from: Int, until: Int) : NodeSeq  
	Selects an interval of elements.
def sliding [B >: A] (size: Int, step: Int) : Iterator[NodeSeq]  
def sliding [B >: A] (size: Int) : Iterator[NodeSeq]  
	Groups elements in fixed size blocks by passing a "sliding window" over them (as opposed to partitioning them, as is done in grouped.
def sortBy [B] (f: (Node) ? B)(implicit ord: Ordering[B]) : NodeSeq  
	Sorts this immutable.
def sortWith (lt: (Node, Node) ? Boolean) : NodeSeq  
	Sorts this immutable sequence according to a comparison function.
def sorted [B >: A] (implicit ord: Ordering[B]) : NodeSeq  
	Sorts this immutable sequence according to an Ordering.
def span (p: (Node) ? Boolean) : (NodeSeq, NodeSeq)  
	Splits this immutable sequence into a prefix/suffix pair according to a predicate.
def splitAt (n: Int) : (NodeSeq, NodeSeq)  
	Splits this immutable sequence into two at a given position.
def startsWith [B] (that: Seq[B]) : Boolean  
	Tests whether this immutable sequence starts with the given sequence.
def startsWith [B] (that: Seq[B], offset: Int) : Boolean  
	Tests whether this immutable sequence contains the given sequence at a given index.
def strict_!= (other: Equality) : Boolean  
def stringPrefix : String  
	Defines the prefix of this objects toString representation.
def sum : Node  
	[use case] Sums up the elements of this collection.
def sum [B >: A] (implicit num: Numeric[B]) : B  
	Sums up the elements of this collection.
def tail : NodeSeq  
	Selects all elements except the first.
def take (n: Int) : NodeSeq  
	Selects first n elements.
def takeRight (n: Int) : NodeSeq  
	Selects last n elements.
def takeWhile (p: (Node) ? Boolean) : NodeSeq  
	Takes longest prefix of elements that satisfy a predicate.
def toArray : Array[Node]  
	[use case] Converts this immutable sequence to an array.
def toArray [B >: A] (implicit arg0: ClassManifest[B]) : Array[B]  
	Converts this immutable sequence to an array.
def toBuffer [B >: A] : Buffer[B]  
	Converts this immutable sequence to a mutable buffer.
def toIndexedSeq [B >: A] : IndexedSeq[B]  
	Converts this immutable sequence to an indexed sequence.
def toIterable : Iterable[Node]  
	Converts this immutable sequence to an iterable collection.
def toIterator : Iterator[Node]  
	Returns an Iterator over the elements in this immutable sequence.
def toList : List[Node]  
	Converts this immutable sequence to a list.
def toMap [T, U] (implicit ev: <:<[Node, (T, U)]) : Map[T, U]  
	Converts this immutable sequence to a map.
def toSeq : Seq[Node]  
	Converts this immutable sequence to a sequence.
def toSet [B >: A] : Set[B]  
	Converts this immutable sequence to a set.
def toStream : Stream[Node]  
	Converts this immutable sequence to a stream.
def toTraversable : Traversable[Node]  
	Converts this immutable sequence to an unspecified Traversable.
def transpose [B] (implicit asTraversable: (Node) ? Traversable[B]) : Seq[Seq[B]]  
	Transposes this immutable sequence of traversable collections into a immutable sequence of immutable sequences.
def union (that: Seq[Node]) : immutable.Seq[Node]  
	[use case] Produces a new sequence which contains all elements of this immutable sequence and also all elements of a given sequence.
def union [B >: A, That] (that: Seq[B])(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	Produces a new sequence which contains all elements of this immutable sequence and also all elements of a given sequence.
def unzip [A1, A2] (implicit asPair: (Node) ? (A1, A2)) : (Seq[A1], Seq[A2])  
	Converts this immutable sequence of pairs into two collections of the first and second halfs of each pair.
def updated (index: Int, elem: Node) : immutable.Seq[Node]  
	[use case] A copy of this immutable sequence with one single replaced element.
def updated [B >: A, That] (index: Int, elem: B)(implicit bf: CanBuildFrom[NodeSeq, B, That]) : That  
	A copy of this immutable sequence with one single replaced element.
def view (from: Int, until: Int) : SeqView[Node, NodeSeq]  
	Creates a non-strict view of a slice of this immutable sequence.
def view : SeqView[Node, NodeSeq]  
	Creates a non-strict view of this immutable sequence.
def withFilter (p: (Node) ? Boolean) : FilterMonadic[Node, NodeSeq]  
	Creates a non-strict filter of this immutable sequence.
def xml_!= (other: Any) : Boolean  
def xml_== (other: Any) : Boolean  
def zip [B] (that: Iterable[B]) : immutable.Seq[(Node, B)]  
	[use case] Returns a immutable sequence formed from this immutable sequence and another iterable collection by combining corresponding elements in pairs.
def zip [A1 >: A, B, That] (that: Iterable[B])(implicit bf: CanBuildFrom[NodeSeq, (A1, B), That]) : That  
	Returns a immutable sequence formed from this immutable sequence and another iterable collection by combining corresponding elements in pairs.
def zipAll [B] (that: Iterable[B], thisElem: Node, thatElem: B) : immutable.Seq[(Node, B)]  
	[use case] Returns a immutable sequence formed from this immutable sequence and another iterable collection by combining corresponding elements in pairs.
def zipAll [B, A1 >: A, That] (that: Iterable[B], thisElem: A1, thatElem: B)(implicit bf: CanBuildFrom[NodeSeq, (A1, B), That]) : That  
	Returns a immutable sequence formed from this immutable sequence and another iterable collection by combining corresponding elements in pairs.
def zipWithIndex : immutable.Seq[(Node, Int)]  
	Zips this immutable sequence with its indices.
def zipWithIndex [A1 >: A, That] (implicit bf: CanBuildFrom[NodeSeq, (A1, Int), That]) : That  
	Zips this immutable sequence with its indices.
    
