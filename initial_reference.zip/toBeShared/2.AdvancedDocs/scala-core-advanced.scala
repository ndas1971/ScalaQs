///*** Important Note - Option, Try, Either , Future 

//Always use Option, Try, Either, Future, all = C[_] 
//Because You can use map , flatMap etc without checking/waitiing ofr result/failure/null etc 
//Note map , flatMap etc takes a Fn(one_arg) where one_arg is underlaying object 
//At the end use, get or getOrElse to get value or use match { pattern } which unwraps underlaying value 


//They are monadic
//(for Either, .left or .right value is monad, 
//but monadic function returns Either having transformed Right or Left 
//if operated on .right or .left respectvly and ignoring if contains Left or Right respectfully )

//	Given below Fn 	 and C[A], get C[B]	Transformation Name
a)      A=>B         C[A]=>C[B]        | Functor   , Given A=>B function, create C[A] =>C[B] ie map
b)      A=>C[B]      C[A]=>C[B]        | Monad      , Given A =>C[B], create C[A] =>C[B], ie flatMap
c)      C[A=>B]      C[A]=>C[B]        | Applicative , Given C[A=>B], create C[A]=>C[B] , ie apply applicable for  for more that one arity of function A => B



//Monadic has  below methods, which  does not operate on
//if None(Option), Failure(Try) or on .left if contains .right and vice versa(Either)
//  or Future is not completed/exception
//C[_]  = Option, Try, Either, Future
C[A].map[B](f: (A) => B): C[B]  
    unwraps value and transform to another, 
    results in same type of Option, Try, Either, Future
       
C[A].flatMap[B](f: (A) => C[B]): C[B]  
     unwraps value and transform to another, but another returns of C[_] which is flattened
     so, results in same type of Option, Try, Either, Future
     If you use map, it becomes C[C[_]]
     Note another has to be same of Option,Try,Either on which flatmap is used 

  
//below are not mondaic, but  Option has implicit conversion to Iterable
//And Future has implementation , Left and Right has implementation (not collect)
//Try has implementation (not collect)
C[A].collect[B](pf: PartialFunction[A, B]): C[B] 
    Note PartialFunction[-A, +B] extends (A) => B 
    collect{PF ie case x if guard => .. or case C() => }  
    map functionality with guard checking 
    But collects only Some, Success Future values 
    if PF returns None, non-success, filters out 

//below can be used, which unwarps the value, 
//Handles None, Failure , Left etc 
C[A].filter(p: (A) => Boolean): C[A]   
    unwarps  value and based on predicator, filters out 
    But  not monadic, means can not handle/ignore  None, Failure, Left etc 

C[A].foreach[U](f: (A) => U): Unit  
    not monadic function as it is for Iterable, so can not be used against above 
    
C[A].fold[B](ifEmpty: => B)(f: (A) => B): B 
    Returns the result of applying f to this C[A} value if the scala.Option is nonempty. 
    Otherwise, evaluates expression ifEmpty. 
    
//Exmaple Since Option is None, does not operate upon 
Option(null).asInstanceOf[Option[String]].filter{ _.length >0 }

///Option, Future, Try (not Either Left, Right) has withFilter, hence can be used 
//in 'for' comprehension as guard
C[A].withFilter(p: (A) => Boolean): C[A}

//Note Option, Future, Try (not Either Left, Right)  has many other Seq like methods, Check reference 
https://www.scala-lang.org/api/2.11.12/index.html#scala.Option
https://www.scala-lang.org/api/2.11.12/index.html#scala.util.Try
https://www.scala-lang.org/api/2.11.12/index.html#scala.util.Either
https://www.scala-lang.org/api/2.11.12/index.html#scala.concurrent.Future



///*** Usage , Note if arg is multiline, wrap it with {}
When a arg can be null, Create Option by 
Option(arg) : Option[T] , which is  Some(x) or None for null

When a arg can generate exception, create by  
Try(arg) :  Try[T] , which is  Success(arg) or Failure(exp) for exception

When you have two types, one represent Wrong/no/Failure/Bad( called Left)
other represents Right/Yes/success/Good (called Right) , use Either[leftT, rightT]
(can contain either Left or Right like Option contains either Some or None etc)
e.left gives left part(monadic, map, flatmap ignores right when operated on left)
e.right gives right part (monadic, map, flatmap ignores left when operated on right )
Create By 
Either.cond(predicate , right_value_callby_for predicate_true, left_value_callby)

when you have blocking operations , create Future by 
Future(arg) :Future  ,then await on the future 

Note Some(arg),None, Success(arg), Failure(exception), Left(arg),Right(arg)
Future.successful(arg), Future.failed(exception) will directly create corresponsing object 


//getting value 
Future          Await.result(f, duration) 
Option          get (throws exception if None) or getOrElse(same underlaying type as default)
Try             get (throws exception if Failure) or getOrElse(same underlaying type as default)
either.left     get (throws exception if Right) or getOrElse(same underlaying type as default)
either.right    get (throws exception if Left) or getOrElse(same underlaying type as default)

//Conversion 
future.value gives Option[Try[T]]

try.toOption   gives Some(x) or None if Failure 

option.toLeft(right) gives Left(x) if Some(x) else right if None 
option.toRight(left) gives Right(x) if Some(x) else left if None 

either.left.toOption        Returns a Some containing the Left value if it exists or a None if this is a Right.
either.right.toOption        Returns a Some containing the Right value if it exists or a None if this is a Left.


///*** Monad 

"""
Given: type constructor/container class C eg   List, Option etc	
Objective - To Get function of type  C[A]=>C[B] , A,B are any types
OR Given C[A] , get C[B]
From 			To			      Transformation Name
a) ( A=>B )     ( C[A]=>C[B] )   | Functor   , Given A=>B function, create C[A] =>C[B] ie Functor.map { A=>B}
b) ( A=>C[B] )  ( C[A]=>C[B] )   | Monad      , Given A =>C[B], create C[A] =>C[B], ie Monad.flatMap {A =>C[B] }
c) ( C[A=>B] )  ( C[A]=>C[B] )   | Applicative , Given C[A=>B], create C[A]=>C[B] , ie Applicative.apply 

"""
//Example Functor- ( A=>B )      => ( C[A]=>C[B] ): for example the container class is MyBox , 
class MyBox[T](val value:T) 
val boxedstring: MyBox[String] = new MyBox("Hello")

//How to get below function, MyBox[String] => MyBox[Int]
def lengthOf( a:MyBox[String]) : MyBox[Int] = ???

//Given:  String => Int eg length of String
def rawLengthOf(a:String) : Int = a.length

//we need to define Functor ie map as below
def map[A,B]( func:A=>B ) : MyBox[A]=>MyBox[B] = (a:MyBox[A]) => new MyBox( func(a.value) )

//And use it like below
 
val result:MyBox[Int] = map(rawLenghtOf)( boxedstring ) // applying the new function


//Example Monad ( A=>C[B] ) => ( C[A]=>C[B] )

//How to get below function, MyBox[String] => MyBox[Int]
def lengthOf( a:MyBox[String]) : MyBox[Int] = ???

//Given, String =>MyBox[Int]
def lengthOf(a:String) = new MyBox( a.length ) 

//define a  Monad ie flatMap
def flatMap[A,B]( func:A=>MyBox[B] ): MyBox[A]=>MyBox[B] = (a:MyBox[A]) => func( a.value )

//Use it like below

val result:MyBox[Int] = flatMap(lenghtOf)( boxedstring ) // applying the new function


//Example Applicative  ( C[A=>B] ) => ( C[A]=>C[B] )

//To define below function , MyBox[String] => MyBox[Int]
def lengthOf( a:MyBox[String]) : MyBox[Int] = ???

//Given MyBox[String =>Int]
val boxedLengthOf:MyBox[String=>Int] = new MyBox( (x:String) => x.length )

//define a  Applicative ie apply
def apply[A,B](b:MyBox[A=>B]): MyBox[A]=>MyBox[B] = (a:MyBox[A]) => new MyBox(b.value(a.value))

//Use it like below
val result:MyBox[Int] = apply(boxedLenghtOf)( boxedstring ) // applying the new function


//Note: In Scala, for comprehension is syntactic sugar for Monadic & Functor form ie flatMap and map
//Hence if you define flatMap and map, you can use it in 'for'


val first = List(1, 2)
val next = List(8, 9)
val last = List("ab", "cde", "fghi")

for {
  i <- first    // Here <- means 'Unbox container type to underlying type' of course container type must have flatMap
  j <- next
  k <- last
}
  yield(i * j * k.length)  //wrap into Container class again

//Equivalent to Monadic form
first flatMap {
  i => next flatMap {
    j => last map {
      k => i * j * k.length
    }
  }
}


//Different forms of  Functors or Monads or Applicative

//Functors is below
def map[A,B]( func:A=>B ) : MyBox[A]=>MyBox[B] = (a:MyBox[A]) => new MyBox( func(a.value) )

//Signature is 
//map takes a function of type A=>B 
//and returns a function which takes a MyBox[A].  
//In the end the result is of type MyBox[B].

( A=>B ) => ( MyBox[A]=>MyBox[B] )
 
//Note The second pair of parentheses can easily be left out:
( A=>B ) => MyBox[A] => MyBox[B]
 

//it is  a curried form that we can transform back into a multi-parameter function:
 
((A=>B), MyBox[A]) => MyBox[B]
 

//ie a function taking two parameters - a function A=>B and a MyBox[A]
//and resulting in MyBox[B]. 

//or reordering the args 
( MyBox[A],(A=>B)) => MyBox[B]
 

//in curried form 
MyBox[A] => (A=>B) => MyBox[B]
 
//ie 
def map[A,B](a:MyBox[A]): (A=>B)=>MyBox[B] = (func:A=>B) => new MyBox( func(a.value) )

//OR
def map[A,B](a:MyBox[A])(func:(A=>B)):MyBox[B] = new MyBox( func(a.value) )

//Or as member function

class MyBox[A](val value:A) {
 def map[B](func:A=>B) = new MyBox( func(this.value) )
}
//Use it like
 
val n = new MyBox("hello")
n.map( (a:String)=>a.length ).value // -> 5




//Relation between Functors or Monads or Applicative . How to convert one to another
// map:  ( A=>B ) => ( C[A]=>C[B] )     | Functor
// flatMap (A=>C[B] )  ( C[A]=>C[B] )   | Monad      
// apply  ( C[A=>B] )  ( C[A]=>C[B] )   | Applicative

//****Functor to Monad

def map[A,B]( func:A=>B ) : MyBox[A]=>MyBox[B] = (a:MyBox[A]) => new MyBox( func(a.value) )


//In functor: the result type B could be a contaner type eg
//List[String] when A => B is String=>List[String]  
//and Result type could be MyBox[List[String]] ie C[F[B]] ie one container is nested inside another
val boxedstring = new MyBox("Hello")
val splitter = (a:String) => a.split("").toList
map(splitter)( boxedstring ) // Result: MyBox[List[java.lang.String]]
 

//Similarly  (A=>B)could be even  (String=>MyBox[Char]) ie (A => C[D])
 
val boxhead = (a:String) => new MyBox(a.head)
map(boxhead)( boxedstring ) // Result: MyBox[MyBox[Char]]
 

//But we already have a function with  A=>C[B] - Monad, or flatMap
//flatMap takes  functions of type A=>MyBox[T], and results  in a MyBox[T].
//ie The result of flatMap is a flat Container, not a nested one!

//Given,
def map[A,B]( func:A=>B ) : MyBox[A]=>MyBox[B] = (a:MyBox[A]) => new MyBox( func(a.value) )
def flatMap[A,B]( func:A=>MyBox[B] ): MyBox[A]=>MyBox[B] = (a:MyBox[A]) => func( a.value )

//hence flatMap can be implemented as
def flatMap[A,B](func:A=>MyBox[B]) = (a:MyBox[A]) => map(func)(a).value

//Or in below way
def flatMap[A,B](func:A=>MyBox[B]) = (a:MyBox[A]) => flatten(map(func)(a))
def flatten[B](m:MyBox[MyBox[B]]):MyBox[B] = m.value



//Note it is often this flatten function that is considered the specific property of Monads, 
//and flatMap is only considered a convenience function


//**** Functor/Monad to Applicative 

//Until now we have only worked with functions that take one parameter.
//For functions taking two args ( or more), we can express as 
//Each function taking two  (or more)parameters and returning a result 
//OR as a function taking one parameter and returning another function which takes the second parameter and so on 
//and then returns the result (called curried form)

val conc = (a:String, b:String) =>  a + b    // two parameter
 
//or it's curried form
val conc = (a:String) => (b:String) =>  a + b

//Applying Functor on that
map(conc)(boxedstring) // Result: MyBox[String => String]  //Same as Applicative form

//So applicative  is a Functor with argument 
//of  function taking more than one parameter 
def apply[A,B](b:MyBox[A=>B]): MyBox[A]=>MyBox[B] = (a:MyBox[A]) => a flatMap { x => b flatMap { g => new MyBox( g(x) ) }}


//Example:

class MyBox[A](val value:A) {
 def map[B](func:A=>B) = new MyBox( func(value) )
 def flatMap[B](func:A=>MyBox[B]) = flatten(map(func))
 def flatten[B](m:MyBox[MyBox[B]]):MyBox[B] = m.value
 def apply[B](b:MyBox[A=>B]): MyBox[B] =  b flatMap { g => new MyBox( g(value) ) }
}



//Using with  for comprehension  and wrapper classes and implicit conversions

class MyBox[T](val value:T) {
   override def toString() = "MyBox("+value+")"
}
 
implicit class MyBoxWrapper[T](w:MyBox[T])  {  
    def unit[R](b: R):MyBox[R] = new MyBox(b)    
    def flatten[B](m:MyBox[MyBox[B]]):MyBox[B] = m.value
	
    def flatMap[R](f:T=>MyBox[R]):MyBox[R] = flatten(map(f))
    def map[R](f:T=>R):MyBox[R] = unit(f(w.value))	
    def apply[B](f: MyBox[T => B]): MyBox[B] = w flatMap { x => f flatMap { g => unit( g(x) ) }}	
    
}
 
def main(args:Array[String]) {
	val ma = new MyBox("hello world")
	println ( ma.map(a => a.length) )  //can call all String methods

	val res = for {
				a <- ma                 // unbox ma into underlying type String
			  } yield a.length + 2      //result MyBox[Int]

	println(res)

	val mb = new MyBox("hola mundo")

	val res2 = for {
				 a <- ma            //unbox ma into underlying type String
				 b <- mb			//unbox mb into underlying type String
			   } yield a.size + b.size  //can call all String methods, result MyBox[Int]

	println (res2)
	
	val res3 = ma.flatMap ( a => mb.map ( b => a.size + b.size ))
	println(res3)
}
main(Array[String](" "))
//REsults
MyBox(11)
MyBox(13)
MyBox(21)
MyBox(21)


//Monoid 

"""
A monoid is a set of objects with identity element and a associative binary operator
Example
•	numbers with + and zero (operation - is not associative)
•	lists with concatenation and Nil
•	sets with union with Empty set
"""

//For container type
trait MonoidC[M[_]]{
  def zero[A]:M[A]
  def op[A](x:M[A], y:M[A]):M[A]
  }
  
implicit val listMonoid: MonoidC[List] = new MonoidC[List] {
   def zero[A] = List[A]()
   def op[A](x:List[A], y:List[A])  = x ::: y
}

def work[T, C[_]](as : C[T])(implicit ev : MonoidC[C] ) = ev.op(ev.zero, as)
def |+|[T, C[_]](as : C[T], as2:C[T])(implicit ev : MonoidC[C] ) = ev.op( as , as2)

//OR using context bound
def work[T, C[_]:MonoidC](as:C[T]) = {
 val m = implicitly[MonoidC[C]]
 import m._
 op(zero, as)
}

//Usage
work(List(1,2,3,4))   //res2: List[Int] = List(1, 2, 3, 4)


//for non container type
trait MonoidN[A] {   
  def op(a1: A, a2: A): A
  def zero: A
 }

implicit val IntMonoid: MonoidN[Int] = new MonoidN[Int] {  //Type class for Int implementation
    def op(a: Int, b: Int): Int = a + b
    def zero: Int = 0
}

implicit val StringMonoid: MonoidN[String] = new MonoidN[String] { //Type class for String implementation
    def op(a: String, b: String): String = a + b
    def zero: String = ""
}
  
def work[T](as : T)(implicit ev : MonoidN[T] ) = ev.op(ev.zero, as)
def |+|(as : T, as2:T)(implicit ev : MonoidN[T] ) =  ev.op( as , as2)

//Usage
work(10)           //res3: Int = 10




///*** Lifting in scala 

//Lift of PF:PartialFunction[-A, +B] extends (A) => B 
//PartialFunction[A, B] is a function defined for some subset of the domain A(input arg) (as specified by the isDefinedAt method). 
//You can "lift" a PartialFunction[A, B] into a Function[A, Option[B]]. 
//That is, a function defined over the whole of A but whose values are of type Option[B]

scala> val pf: PartialFunction[Int, Boolean] = { case i if i > 0 => i % 2 == 0}
pf: PartialFunction[Int,Boolean] = <function1>

scala> pf.lift
res1: Int => Option[Boolean] = <function1>

scala> res1(-1)
res2: Option[Boolean] = None

scala> res1(1)
res3: Option[Boolean] = Some(false)

//Note any collection that extends PartialFunction[Int, A] 
// may be lifted; thus for instance
Seq(1,2,3).lift
Int => Option[Int] = <function1> //into a total function where values not defined in the collection are mapped onto None,

Seq(1,2,3).lift(2)
Option[Int] = Some(3)

Seq(1,2,3).lift(22)
Option[Int] = None

Seq(1,2,3).lift(2).getOrElse(-1)
Int = 3

Seq(1,2,3).lift(22).getOrElse(-1)
Int = -1


//Lift for method: "lift" a method invocation into a function
//this is called eta-expansion 
scala> def times2(i: Int) = i * 2
times2: (i: Int)Int

scala> val f = times2 _
f: Int => Int = <function1>

scala> f(4)
res0: Int = 8

///a lift function takes a function A => B, 
//the lifted function F[A] => F[B] can be applied to a functor or monad F[A].

def double(x: Int): Int = 2 * x, 
val xs = Seq(1, 2, 3). 

//We cannot double(xs) due to incompatible types. 
//but 
val doubleSeq = liftToSeq(double)(xs) // Seq(2, 4, 6).
def liftToSeq[A, B](f: A => B): (Seq[A] => Seq[B]) =  (seq: Seq[A]) => seq.map(f)

//A functor (as defined by scalaz) is for some "container" 
//F such that, if we have an F[A] and a function A => B, 
//then we can creates F[B] ( for example, F = List and the map method)

trait Functor[F[_]] { 
  def map[A, B](fa: F[A])(f: A => B): F[B]
}

//then Lift for Functor is , 
//if F is a functor, and we have a function A => B, we lift to function F[A] => F[B]. 
def lift[F[_]: Functor, A, B](f: A => B): F[A] => F[B]


//Lift for Monad Transformers
//a monad transformers are a way of "stacking" monads(flatMap) on top of each other (monads do not compose).
for {
  i <- first    // Here <- means 'Unbox container type to underlying type' ,container type must have flatMap
  j <- next
  k <- last
}
  yield(i * j * k.length) 
//equivalent to 
first flatMap {
  i => next flatMap {
    j => last map {
      k => i * j * k.length
    }
  }
}
//So for example, suppose you have a function which returns an IO[Stream[A]]. 
//Say, This can be converted to the monad transformer StreamT[IO, A]. (note flattening type param)

//you may wish to "lift" some other value IO[B] to StreamT[IO, B]
//from example , you may write 
StreamT.fromStream(iob map (b => Stream(b)))
//or , IO[B] has implementation 
iob.liftM[StreamT]

//why do I want to convert an IO[B] into a StreamT[IO, B]?. 
//The answer would be "to take advantage of composition possibilities". 
//example 
lazy val f: (A, B) => C = ???  
val cs =   for {
    a <- as                //as is a StreamT[IO, A] and StreamT has flatMap(a =>)
    b <- bs.liftM[StreamT] //bs was just an IO[B] and StreamT has map(a => )
  yield f(a, b) //StreamT[IO, C]

cs.toStream //is a Stream[IO[C]]



///***Higher kinded  types - Type constructor taking another type 

//first order function
//id : Int => Int
def id(x: Int) = x     //call as id(2) gets 2

//1-kind Type level function or type constructor
// Id :: * => *
//kind of Id is type to type
type Id[A] = A        //use as val x:Id[Int] = 2

//Higher order function, function taking a function
//id: ((Int => Int), Int) =>Int
def id(f: Int => Int, x:Int) = f(x)   //call as  id( (x) => x+ 1, 2)

scala> val f =  (x:Int,y:Int) => x+y
f: (Int, Int) => Int = <function2>

scala> :type f
(Int, Int) => Int

scala> val f =  (x:Int) => (y:Int) => x+y
f: Int => (Int => Int) = <function1>

scala> :type f
Int => (Int => Int)

scala> val f = (x:Int, y:Int => Int ) => y(x)
f: (Int, Int => Int) => Int = <function2>

scala> :type f
(Int, Int => Int) => Int

scala> val f = (x:Int) => (y:Int => Int ) => (z:Int) => y(x+z)
f: Int => ((Int => Int) => (Int => Int)) = <function1>

scala> :type f
Int => ((Int => Int) => (Int => Int))

scala> val f = (x:Int, y:Int => Int ) => (z:Int) => () => y(x+z)
f: (Int, Int => Int) => Int => (() => Int) = <function2>

scala> :type f
(Int, Int => Int) => Int => (() => Int)

scala> f(2, (x:Int) => x*x )(3)()
res3: Int = 25

//Higher kinded type, type taking another type
//Id :: (( * => * ) x  * ) => *
type @@[A,C[_]] = C[A]   //C[_] is container class, eg List, Seq etc ,

scala> val l: Int @@ List = List(1,2,3)
l: @@[Int,List] = List(1, 2, 3)

//Type Constructor in scala 2.11

:kind List     //:kind works with instance 
// scala.collection.immutable.List's kind is F[+A]

:kind -v List
// scala.collection.immutable.List's kind is F[+A]
// * -(+)-> *

scala> class A[T]
defined class A

scala> val a = new A[Int]
a: A[Int] = A@2bc9a775

scala> :type a
A[Int]

scala> :kind -v Int
scala.Ints kind is A
*
This is a proper type.

scala> :kind -v a
As kind is F[A]
* -> *
This is a type constructor: a 1st-order-kinded type.

scala> class C[T,U[X]]
defined class C

scala> val c = new C[Int,List]
c: C[Int,List] = C@4d95a72e

scala> :kind -v c
Cs kind is X[A1,F[A2]]
* -> (* -> *) -> *
This is a type constructor that takes type constructor(s): a higher-kinded type.

//Note: for higher kinded type, inside type can be represented by anything(even exitential)
scala> class D[T,U[_],X[_,_[_]]]  //same as D[T,U[Z],X[Z,X1[Z]]] as inside []'s type does not matter
defined class D

scala> val d = new D[Int,List,C]
d: D[Int,List,C] = D@52d6d273

scala> :kind -v d
Ds kind is Y[A1,F1[A2],X[A3,F2[A4]]]
* -> (* -> *) -> (* -> (* -> *) -> *) -> *
This is a type constructor that takes type constructor(s): a higher-kinded type.

//Usage - whenever you need to deal with container class
def size[T, C[X] <: Seq[X] ](x:C[T]) = x.size

//example: To remove complicated casting 

val map: Map[Option[Any], List[Any]] = Map(
   Some("foo") -> List("f", "O"),
   Some(42) -> List(2,3,4),
   Some(true) -> List(true, false, false))

//ugly cast
val xs: List[String] = map(Some("foo")).asInstanceOf[List[String]]
val ys: List[Int] = map(Some(42)).asInstanceOf[List[Int]]


//:Paste

class HOMap[ K[_], V[_]]( map : Map[ K[Any], V[Any] ]) {
 def apply[A](key: K[A]) : V[A] =  map(key.asInstanceOf[K[Any]]).asInstanceOf[V[A]]
}

object HOMap {
  type Pair[K[_], V[_]] = (K[A], V[A]) forSome {type A}
  def apply[K[+_], V[+_]](tuples: Pair[K,V]*) = new HOMap[K, V]( Map(tuples: _*) )
}

val map_b: HOMap[Option, List] = HOMap[Option, List](
  Some("foo") -> List("foo", "bar", "baz"),
  Some(42) -> List(1, 1, 2, 3, 5, 8),
  Some(true) -> List(true, false, true, false)
)

val xs_b: List[String] = map_b(Some("foo"))
val ys_b: List[Int] = map_b(Some(42))
println(xs_b)
println(ys_b)






 
///*** Type Recursion or f bound polymorphic- type bounded by own type - for container class

//Suppose , want to double a numeric type
trait Doubler[T] {
  def double: T         //note double returns T which is Doubler's contained type
}

//below is OK
case class Square(base: Double) extends Doubler[Square] {
  def double: Square = Square(base * 2)
}

//Below is illogical, but OK, as Doubler can take any Type
case class Person(firstname: String)
case class Square(base: Double) extends Doubler[Person] {
  override def double: Person = Person("some")
}

//How to put a constraint such that above is not possible
//ie Double must contain type which is related

//Make T <: Doubler[T] called f bound polymorphic or self recursive 
//means: T must be subtype of Doubler[T]
//Not possible to extends Doubler with a type which doesn’t extend Doubler in turn
 
//in Java, Enum<E extends Enum<E>>

trait Doubler[T <: Doubler[T]] {
  def double: T
}
//below is OK
case class Square(base: Double) extends Doubler[Square] {
  def double: Square = Square(base * 2)
}
//But
case class Person(firstname: String)
case class Square(base: Double) extends Doubler[Person] {} //Error as Person is not subtype of Doubler

//But below is still OK as Square is subtype of Doubler[T]
//but illogical

case class BadDoubler(kind: String) extends Doubler[Square] {
  override def double: Square = Square(5)
}

//to put a constraint, such that above is wrong , use self type such that self must be T
 
trait Doubler[T <: Doubler[T]] { self: T =>
  def double: T
}


// Another example - Using Ordered[_]

trait Container extends Ordered[Container]

class MyContainer extends Container {
  def compare(that: MyContainer): Int  = 0   //fails as it requires def compare(that: Container): Int from Ordered[Container]
}

//Solution use self recursive 

trait Container[A <: Container[A]] extends Ordered[A]

class MyContainer extends Container[MyContainer] { 
  def compare(that: MyContainer) = 0 
}

List(new MyContainer, new MyContainer, new MyContainer)
       

//Another example - How to enforce comparison with same type
 
// naive impl, any derived class of Fruit can be used for comparison

trait Fruit {
  final def compareTo(other: Fruit): Boolean = true 
}

class Apple  extends Fruit
class Orange extends Fruit

val apple = new Apple()
val orange = new Orange()

apple compareTo orange // compiles, but we want to make this NOT compile!

//Solution
// Create a new Type for each T, hence comparison fails

trait Fruit[T <: Fruit[T]] {
  final def compareTo(other: Fruit[T]): Boolean = true 
}

class Apple  extends Fruit[Apple]
class Orange extends Fruit[Orange]

val apple = new Apple
val orange = new Orange

orange compareTo apple  //NOK
orange compareTo orange  //res1: Boolean = true





///*** Type Members, projection and type lambda

trait HList{
  type Hd  
}
 
class IntList extends HList {
  type Hd = Int
}
implicitly[ Int =:= IntList#Hd ]   // # is type projection , 

val x: IntList#Hd = 10
 

//Type Lambda is often regarded as Type-Level Lambda. 
//ie accessing inner type without creating type
type L[A] = Map[Int,A]
val x:L[String] = Map(1->"Ok") //x: L[String] = Map(1 -> Ok)
implicitly[ L[String] =:= Map[Int,String] ] //OK

//or Directly accessing by ({type L[X] = Map[Int,X]})#L
val x:({type L[X] = Map[Int,X]})#L[String]  = Map(1->"Ok") //x: Map[Int,String] = Map(1 -> Ok)



//Example- Usage
trait Functor[A, +M[_]]{
  def map[B] (f: A => B): M[B]
}
 
//for Seq
case class SeqFunctor[A](seq: Seq[A]) extends Functor[A, Seq]{ 
  def map[B](f: A => B): Seq[B] = seq.map(f)
  }
 
val lst = List(1,2,3)
SeqFunctor(lst).map(_ * 10)  // prints List(10, 20, 30)
 

//But for Map, as Map take two Types, need to convert to one type container (either K or V)
 
case class MapFunctor[K,V](mapKV: Map[K,V]) extends 
     Functor[V, ({type L[X] = Map[K,X]})#L ]{  // L is container type
           def map[V2](f: V => V2): Map[K, V2] =  mapKV.map{ case (k,v) => (k, f(v))  }
}
 
MapFunctor(Map(1->1, 2->2, 3->3)).map(_ * 10)// Result: Map(1 -> 10, 2 -> 20, 3 -> 30)
 
//Another way to implement, use ` ` to define variable name

case class ReadableMapFunctor[K,V](mapKV: Map[K,V]){
  type `Map[K]`[V2] = Map[K, V2]
  def mapFunctor[V2] = new Functor[V, `Map[K]`] {
        def map[V2](f: V => V2): `Map[K]`[V2] = mapKV.map{ case (k,v) => (k, f(v))  }    
  }
} 

ReadableMapFunctor(Map(1->1, 2->2, 3->3)).mapFunctor.map(_*10)
//Map(1 -> 10, 2 -> 20, 3 -> 30)
 


 
///*** Type Projection - How to alias  parameter type 's type 

trait Item[K] {
  type Key = K
  var x:Key = _
}

def get[T <: Item[_]](k: T#Key) = k


class IntItem extends Item[Int]
class StringItem extends Item[String]

// we want the following to compile - no way we can create T#Key, eventhough we know T#key is Int for IntItem
get[IntItem](0)

scala> get[IntItem](0)
<console>:67: error: type mismatch;
 found   : Int(0)
 required: _$1
              get[IntItem](0)
                           ^

scala> get[IntItem](0.asInstanceOf[IntItem#Key])
<console>:67: error: type mismatch;
 found   : Int
 required: _$1
              get[IntItem](0.asInstanceOf[IntItem#Key])
                                         ^

scala> val v:IntItem#Key = 0
v: Int = 0

scala> get[IntItem](v)
<console>:68: error: type mismatch;
 found   : v.type (with underlying type Int)
 required: _$1
              get[IntItem](v)
                           ^

						   
//Solution - Option-1: Don't assign Key = K at parent trait and create a subtrait

trait ItemLike {
  type Key  
}

trait Item[K] extends ItemLike {
  type Key = K
  var x:Key = _
}

class IntItem extends Item[Int]
class StringItem extends Item[String]

def get[T <: ItemLike](e: T#Key) = e
get[IntItem](0)


//Solution - Option-2: Don't assign Key = K, but bound it 


trait Item[K] {
  type Key <: K
  var x:Key = _
}

class IntItem extends Item[Int] {
  type Key = Int
}

class StringItem extends Item[String] {
  type Key = String
}

def get[T <: Item[_]](e: T#Key) = e

get[IntItem](0)



//Solution-3 - Best, bound with lower and upper instead of assigning to K

trait Item[K] { 
  type Key >: K <: K 
  var x:Key = _
  }

def get[T <: Item[_]](k: T#Key) = k


class IntItem extends Item[Int]
class StringItem extends Item[String]

get[IntItem](0)





 
	  
	

///*** Type-Level Programming Example: Boolean
//below is NOK
trait A{
    type Key <: Up
}

                   ^
//But for Higher kind , inside type could be anything 
trait A{
    type K[X]
}
trait A{
    type Key[Up] <: Up
}

//Example 
trait Bool {
 type If[T <: Up, F <: Up, Up] <: Up  //all type parameters
}

trait True extends Bool {
 type If[T <: Up, F <: Up, Up] = T
}

trait False extends Bool {
 type If[T <: Up, F <: Up, Up] = F
}
 

//Example usage:
type Rep[A <: Bool] = A#If[ Int, Long, AnyVal ]

 
implicitly[ Rep[True] =:= Int ] //res1: =:=[Rep[Booleans.True],Int] = <function1>
implicitly[ Rep[False] =:= Long ] //res3: =:=[Rep[Booleans.False],Long] = <function1>
 
val x:Rep[True] = 2L  //Error
val x:Rep[True] = 2  //x: Rep[True] = 2

//Extension

object Bool {
 type &&[A <: Bool, B <: Bool] = A#If[B, False, Bool]
 type || [A <: Bool, B <: Bool] = A#If[True, B, Bool]
 type Not[A <: Bool] = A#If[False, True, Bool]
}
 
//Usage
import Bool._

implicitly[ True && False || Not[False] =:= True ]
 
class BoolRep[B <: Bool](val value: Boolean)

implicit val falseRep: BoolRep[False] = new BoolRep(false)
implicit val trueRep: BoolRep[True] = new BoolRep(true)

def toBoolean[B <: Bool](implicit b: BoolRep[B]): Boolean = b.value
 
toBoolean[ True && False || Not[False] ]  //res0: Boolean = true



///*** Concurrent Programming - Thread - Introduction

val hello = new Thread( new Runnable {
  def run() {
    Thread.sleep(2000)	
	println("hello world " + Thread.currentThread)
  }
})

hello.start
hello.join   //blocks 

//With Thread Pool

import java.util.concurrent._

class A extends Runnable {
	def run {  //run can not return any value, use Callable
		println("hello from Thread " + Thread.currentThread.getId)
	}
}

class A2 extends Callable[Int] {
	def call= {
		println("hello from Thread " + Thread.currentThread.getId)
		2
	}
}

val pool = Executors.newFixedThreadPool(5)  
for (i <- 1 to 10) {
	pool.execute(new A)     
}
val a = pool.submit(new A2) //pool.submit(Runnable or Callable) return java.util.concurrent.Future , has method get
a.get



//Synchronization
//for concurrent map, Use mutable.concurrent.TrieMap[T,U]

//Mutexes provide ownership semantics - via synchronized

class Person(var name: String) {
  def set(changedName: String) {
    this.synchronized {
      name = changedName
    }
  }
}


//volatile for volatile keyword as in java
// Java Memory Model ensures   that all threads see a consistent value for the variable 
//even without use of 'synchronized' block . This is finer controlled
class Person(@volatile var name: String) {
  def set(changedName: String) {
    name = changedName
  }
}


//AtomicReference , getAndSet(V newValue), 
//compareAndSet(V expect, V update) ,  set(V newValue)  

import java.util.concurrent.atomic.AtomicReference

class Person(val name: AtomicReference[String]) {
  def set(changedName: String) {
    name.set(changedName)
  }
}
