///*** Installation 

libraryDependencies += "co.theasi" %% "plotly" % "0.2.0"
libraryDependencies += "com.github.tototoshi" %% "scala-csv" % "1.3.5"


/// ~/.plotly/.credentials
$ set HOME=C:\Users\......
//Create account https://plot.ly/ssu
//Graphs are saved inside your Plotly account and you control the privacy. Public hosting is free. 
//For private hosting, you can use one of the paid plans.
{
    "username": "DemoAccount",
    "api_key": "lr1c37zw81"
}

//or 
import co.theasi.plotly._

implicit val server = new writer.Server {
  val credentials = writer.Credentials("<username>", "<api_key>")
  val url = "https://api.plot.ly/v2/"
}


///Reference 
//https://asidatascience.github.io/scala-plotly-client/latest/api/#co.theasi.plotly.package

case class Axis(options: AxisOptions) extends Product with Serializable 
case class AxisOptions(title: Option[String], tickLength: Option[Int], 
    zeroLine: Option[Boolean], gridWidth: Option[Int], grid: Option[Boolean], 
    line: Option[Boolean], lineColor: Option[Color], titleFont: Font, tickFont: Font, 
    autoTick: Option[Boolean], tickSpacing: Option[Double], tickColor: Option[Color], 
    tickLabels: Option[Boolean]) extends Product with Serializable 
case class LegendOptions(x: Option[Double], y: Option[Double], 
    xAnchor: Option[XAnchor.Value], yAnchor: Option[YAnchor.Value], 
    borderColor: Option[Color], backgroundColor: Option[Color], 
    font: Font, borderWidth: Option[Double]) extends Product with Serializable
case class Margins(top: Option[Int] = None, right: Option[Int] = None, bottom: Option[Int] = None, left: Option[Int] = None) extends Product with Serializable
case class MarkerOptions(size: Option[Int], color: Option[Color], 
        symbol: Option[String], lineWidth: Option[Int], 
        lineColor: Option[Color]) extends Product with Serializable 
case class Color(r: Int, g: Int, b: Int, a: Double) extends Product with Serializable
sealed trait Colorscale extends AnyRef
case class ColorscalePredef(s: String) extends Colorscale with Product with Serializable
case class Font(color: Option[Color], family: Option[List[String]], size: Option[Int]) extends Product with Serializable 


//1D plot 
trait Plot extends AnyRef 
case class CartesianPlot(series: Vector[CartesianSeries], options: CartesianPlotOptions) extends Plot with Product with Serializable
    def withBar[X, Y](xs: Iterable[X], ys: Iterable[Y])(implicit arg0: Writable[X], arg1: Writable[Y]): CartesianPlot
    Add a bar series to this plot.
    def withBox[X](xs: Iterable[X])(implicit arg0: Writable[X]): CartesianPlot
    Add a box plot to this plot.
    def withScatter[X, Y](xs: Iterable[X], ys: Iterable[Y], options: ScatterOptions): CartesianPlot
    Add a scatter plot to this plot.
    def xAxisOptions(newAxisOptions: AxisOptions): CartesianPlot
    Set the x-axis options for this plot.
    def yAxisOptions(newAxisOptions: AxisOptions): CartesianPlot
    Set the y-axis options for this plot.

case class CartesianPlotOptions(xAxis: Axis, yAxis: Axis) extends Product with Serializable
sealed trait CartesianSeries extends Series
sealed abstract class CartesianSeries1D[X <: PType] extends CartesianSeries
sealed abstract class CartesianSeries2D[X <: PType, Y <: PType] extends CartesianSeries 



//1D plot types 
case class Scatter[X <: PType, Y <: PType](xs: Iterable[X], ys: Iterable[Y], options: ScatterOptions) extends CartesianSeries2D[X, Y] with Product with Serializable
case class ScatterOptions(name: Option[String], mode: Seq[ScatterMode.Value], text: Option[TextValue], marker: MarkerOptions) extends SeriesOptions with Product with Serializable 

case class Bar[X <: PType, Y <: PType](xs: Iterable[X], ys: Iterable[Y], options: BarOptions) extends CartesianSeries2D[X, Y] with Product with Serializable
case class BarOptions(name: Option[String] = None) extends SeriesOptions with Product with Serializable

case class Box[X <: PType](xs: Iterable[X], options: BoxOptions) extends CartesianSeries1D[X] with Product with Serializable
case class BoxOptions(name: Option[String] = None) extends SeriesOptions with Product with Serializable 


//Figure 
sealed trait Series extends AnyRef
trait SeriesOptions extends AnyRef
case class SinglePlotFigure(plot: Plot, options: FigureOptions) extends Figure with Product with Serializable


trait Figure extends AnyRef
case class FigureOptions(title: Option[String], legendOptions: LegendOptions, margins: Margins, width: Option[Int], height: Option[Int], paperBackgroundColor: Option[Color], plotBackgroundColor: Option[Color]) extends Product with Serializable 


//Subplots 
case class Grid(columns: Map[String, Iterable[PType]] = Map.empty) extends Product with Serializable
case class GridFigure(plots: Vector[Plot], viewPorts: Vector[ViewPort], numberRows: Int, numberColumns: Int, options: FigureOptions) extends Figure with Product with Serializable
            Figure containing plots arranged on a grid.

case class RowFigure(impl: GridFigure) extends Figure with Product with Serializable
Figure containing plots arranged in a row.



//draw methods 
def draw(grid: Grid, fileName: String, fileOptions: FileOptions)(implicit server: Server): GridFile
def draw(grid: Grid, fileName: String)(implicit server: Server): GridFile
def draw(plot: Plot, fileName: String, fileOptions: FileOptions)(implicit server: Server): PlotFile
def draw(plot: Plot, fileName: String)(implicit server: Server): PlotFile
def draw(figure: Figure, fileName: String, fileOptions: FileOptions)(implicit server: Server): PlotFile
def draw(figure: Figure, fileName: String)(implicit server: Server): PlotFile 


///*** plotly - Line and Scatter Plots in Scala



///* Simple scatter plot

import co.theasi.plotly._
import util.Random

// Generate uniformly distributed x
val xs = (0 until 100)

// Generate random y
val ys = (0 until 100).map { i => i + 5.0 * Random.nextDouble }

val p = Plot().withScatter(xs, ys)

draw(p, "basic-scatter", writer.FileOptions(overwrite=true))
// returns  PlotFile(pbugnion:173,basic-scatter)
//saved in online account, now loginto plotly and go to MyFiles 


///* Lines and scatter plots

import co.theasi.plotly._
import util.Random

// Generate uniformly distributed x
val xs = (0 until 100)

// Generate random y
val ys0 = (0 until 100).map { i => Random.nextDouble }
val ys1 = ys0.map { _ + 5.0 }
val ys2 = ys0.map { _ - 5.0 }

val p = Plot()
  .withScatter(xs, ys0, ScatterOptions().mode(ScatterMode.Marker).name("marker"))
  .withScatter(xs, ys1,
    ScatterOptions()
      .mode(ScatterMode.Marker, ScatterMode.Line)
      .name("line+marker"))
  .withScatter(xs, ys2, ScatterOptions().mode(ScatterMode.Line).name("line"))

draw(p, "scatter-mode", writer.FileOptions(overwrite=true))


///* Style scatter plots

import co.theasi.plotly._
import util.Random

val n = 500

val xs = (0 until n).map { i => Random.nextDouble }
val ys0 = (0 until n).map { i => Random.nextDouble + 2.0 }
val ys1 = (0 until n).map { i => Random.nextDouble - 2.0 }

val p = Plot()
  .withScatter(xs, ys0, ScatterOptions()
                                .mode(ScatterMode.Marker)
                                .name("Above")
                                .marker(
                                  MarkerOptions()
                                        .size(10)
                                        .color(152, 0, 0, 0.8)
                                        .lineWidth(2)
                                        .lineColor(0, 0, 0)
                                    )
        )
  .withScatter(xs, ys1, ScatterOptions()
                            .mode(ScatterMode.Marker)
                            .name("Below")
                            .marker(
                                  MarkerOptions()
                                    .size(10)
                                    .color(255, 182, 193, 0.9)
                                    .lineWidth(2)
                                )
        )

draw(p, "styled-scatter", writer.FileOptions(overwrite=true))


///* Data labels on the plot

import co.theasi.plotly._

val gdpAmerica = Vector(12779.379640000001, 3822.1370840000004, 9065.800825, 36319.235010000004,
  13171.63885, 7006.580419, 9645.06142, 8948.102923, 6025.374752000001,
  6873.262326000001, 5728.353514, 5186.050003, 1201.637154,
  3548.3308460000003, 7320.880262000001, 11977.57496, 2749.320965,
  9809.185636, 4172.838464, 7408.905561, 19328.70901, 18008.50924,
  42951.65309, 10611.46299, 11415.805690000001)

val lifeExpectancyAmerica = Vector(75.32, 65.554, 72.39, 80.653, 78.553, 72.889,
  78.782, 78.273, 72.235, 74.994, 71.878, 70.259, 60.916, 70.198, 72.567,
  76.195, 72.899, 75.537, 71.752, 71.421, 78.746, 69.819, 78.242, 76.384, 73.747)

val labelAmerica = Vector(
  "Argentina",
  "Bolivia",
  "Brazil",
  "Canada",
  "Chile",
  "Colombia",
  "Costa Rica",
  "Cuba",
  "Dominican Republic",
  "Ecuador",
  "El Salvador",
  "Guatemala",
  "Haiti",
  "Honduras",
  "Jamaica",
  "Mexico",
  "Nicaragua",
  "Panama",
  "Paraguay",
  "Peru",
  "Puerto Rico",
  "Trinidad and Tobago",
  "United States",
  "Uruguay",
  "Venezuela"
)

val gdpEurope = Vector(5937.029525999999, 36126.4927, 33692.60508, 7446.298803, 10680.79282,
  14619.222719999998, 22833.30851, 35278.41874, 33207.0844, 30470.0167,
  32170.37442, 27538.41188, 18008.94444, 36180.789189999996, 40675.99635,
  28569.7197, 9253.896111, 36797.93332, 49357.19017, 15389.924680000002,
  20509.64777, 10808.47561, 9786.534714, 18678.31435, 25768.25759,
  28821.0637, 33859.74835, 37506.419069999996, 8458.276384, 33203.2612)

val lifeExpectancyEurope = Vector(76.423, 79.829, 79.441, 74.852, 73.005, 75.748, 76.486,
  78.332, 79.313, 80.657, 79.406, 79.483, 73.33800000000001, 81.757, 78.885, 80.546,
  74.543, 79.762, 80.196, 75.563, 78.098, 72.476, 74.002, 74.663, 77.926,
  80.941, 80.884, 81.70100000000001, 71.777, 79.425)

val labelEurope = Vector(
  "Albania",
  "Austria",
  "Belgium",
  "Bosnia and Herzegovina",
  "Bulgaria",
  "Croatia",
  "Czech Republic",
  "Denmark",
  "Finland",
  "France",
  "Germany",
  "Greece",
  "Hungary",
  "Iceland",
  "Ireland",
  "Italy",
  "Montenegro",
  "Netherlands",
  "Norway",
  "Poland",
  "Portugal",
  "Romania",
  "Serbia",
  "Slovak Republic",
  "Slovenia",
  "Spain",
  "Sweden",
  "Switzerland",
  "Turkey",
  "United Kingdom"
)

// Options common to both traces
val commonOptions = ScatterOptions()
  .mode(ScatterMode.Marker)
  .marker(MarkerOptions().size(12).lineWidth(1))

// Options common to both axes
val commonAxisOptions = AxisOptions()
  .tickLength(5)
  .gridWidth(2)

val xAxisOptions = commonAxisOptions.title("GDP per capita (dollars)").noZeroLine
val yAxisOptions = commonAxisOptions.title("Life expectancy (years)")

// The plot itself
val p = Plot()
  .withScatter(gdpAmerica, lifeExpectancyAmerica,
                    commonOptions.name("Americas").text(labelAmerica))
  .withScatter(gdpEurope, lifeExpectancyEurope,
                    commonOptions.name("Europe").text(labelEurope))
  .xAxisOptions(xAxisOptions)
  .yAxisOptions(yAxisOptions)

val figure = Figure()
  .plot(p) // add the plot to the figure
  .title("Life Expectancy v. Per Capita GDP, 2007")

draw(p, "life-expectancy-per-GDP-2007", writer.FileOptions(overwrite=true))


///* Categorical Dot Plot

val country = List("Switzerland (2011)",
  "Chile (2013)",
  "Japan (2014)",
  "United States (2012)",
  "Slovenia (2014)",
  "Canada (2011)",
  "Poland (2010)",
  "Estonia (2015)",
  "Luxembourg (2013)",
  "Portugal (2011)")

val votingPopulation = List(40.0, 45.7, 52, 53.6, 54.1, 54.2, 54.5, 54.7, 55.1, 56.6)
val registeredVoters = List(49.1, 42, 52.7, 84.3, 51.7, 61.1, 55.3, 64.2, 91.1, 58.9)

// Options common to both traces
val commonOptions = ScatterOptions()
  .mode(ScatterMode.Marker)
  .marker(MarkerOptions()
        .symbol("circle")
        .lineWidth(1)
        .size(16)
    )

val p = Plot()
  .withScatter(votingPopulation, country, commonOptions
            .name("Percent of estimated voting age population")
            .updatedMarker(_.color(156, 165, 196, 0.95).lineColor(156, 165, 196, 1.0)))
  .withScatter(registeredVoters, country, commonOptions
            .name("Percent of estimated registered voters")
            .updatedMarker(_.color(204, 204, 204, 0.95).lineColor(217, 217, 217, 1.0)))
  .xAxisOptions( // Plot axis options
        AxisOptions()
          .noGrid
          .withLine
          .lineColor(102, 102, 102)
          .titleColor(204, 204, 204)
          .tickFontColor(102, 102, 102)
          .noAutoTick
          .tickSpacing(10.0)
          .tickColor(102, 102, 102)
      )

// Add the plot to the figure
val figure = Figure()
  .plot(p)
  .title("Votes cast for ten lowest voting age population in OECD countries")
  .legend(LegendOptions()
    .yAnchor(YAnchor.Middle)
    .xAnchor(XAnchor.Right))
  .leftMargin(140)
  .rightMargin(40)
  .bottomMargin(50)
  .topMargin(80)
  .width(800)
  .height(600)
  .paperBackgroundColor(254, 247, 234)
  .plotBackgroundColor(254, 247, 234)

draw(figure, "lowest-oecd-votes-cast", writer.FileOptions(overwrite=true))


///*** plotly - Subplots in Scala


///* Subplots in a row

import co.theasi.plotly._
import util.Random

val xsLeft = (0 to 100).map { i => Random.nextGaussian }
val ysLeft = (0 to 100).map { i => Random.nextGaussian }

val xsRight = (0 to 100).map { i => Random.nextDouble }
val ysRight = (0 to 100).map { i => Random.nextDouble }

val figure = RowFigure(2)
  .plot(0) { // left-hand plot
    Plot().withScatter(
      xsLeft, ysLeft,
      ScatterOptions().mode(ScatterMode.Marker).name("left"))
  }
  .plot(1) { // right-hand plot
    Plot().withScatter(
      xsLeft, ysLeft,
      ScatterOptions().mode(ScatterMode.Marker).name("right"))
  }

draw(figure, "make-subplots", writer.FileOptions(overwrite=true))


///* Mixed 2D and 3D subplots

import co.theasi.plotly
import util.Random

// Left-hand side: Gaussian distributed random variates
val randomXs = (0 to 100).map { i => Random.nextGaussian }
val randomYs = (0 to 100).map { i => Random.nextGaussian }

val leftPlot = Plot()
  .withScatter(randomXs, randomYs, ScatterOptions().mode(ScatterMode.Marker))

// Gaussian PDF
def gaussian2D(x: Double, y: Double) = Math.exp(-x*x - y*y)

val xs = (-4.0 to 4.0 by 0.1).toVector
val ys = (-4.0 to 4.0 by 0.1).toVector
val zs = xs.map { x => ys.map { y => gaussian2D(x, y) } }

val rightPlot = ThreeDPlot().withSurface(xs, ys, zs)

// Figure with two subplots in a row
val figure = RowFigure(2)
  .plot(0) { leftPlot }
  .plot(1) { rightPlot }

draw(figure, "mixed-subplots", writer.FileOptions(overwrite=true))


///* A grid of subplots

import co.theasi.plotly
import util.Random

val xs = (0 to 100).map { i => Random.nextGaussian }
def ys = (0 to 100).map { i => Random.nextGaussian }

// Options common to all the series
val commonOptions = ScatterOptions()
  .mode(ScatterMode.Marker)
  .marker(MarkerOptions().size(5))

val figure = GridFigure(2, 3) // 2 rows, 3 columsn
  .plot(0, 0) { Plot().withScatter(xs, ys, commonOptions.name("top-left")) }
  .plot(0, 1) { Plot().withScatter(xs, ys, commonOptions.name("top-middle")) }
  .plot(0, 2) { Plot().withScatter(xs, ys, commonOptions.name("top-right")) }
  .plot(1, 0) { Plot().withScatter(xs, ys, commonOptions.name("bottom-left")) }
  .plot(1, 1) { Plot().withScatter(xs, ys, commonOptions.name("bottom-middle")) }
  .plot(1, 2) { Plot().withScatter(xs, ys, commonOptions.name("bottom-rigth")) }


draw(figure, "subplots-grid", writer.FileOptions(overwrite=true))


///*** plotly - 3D Surface plots in Scala
///* 3D surface plot

val xs = (-3.0 to 3.0 by 0.1).toVector
val ys = (-3.0 to 3.0 by 0.1).toVector

def gaussian2D(x: Double, y: Double) = Math.exp(-x*x - y*y)
val zs = xs.map { x => ys.map { y => gaussian2D(x, y) } }

val p = ThreeDPlot().withSurface(xs, ys, zs)

draw(p, "gaussian-surfaces")


///* Styled surface plot
import scala.io.Source
import com.github.tototoshi.csv._
import co.theasi.plotly._

object MountBruno extends App {

  val dataURL = "https://raw.githubusercontent.com/plotly/datasets/master/api_docs/mt_bruno_elevation.csv"
  val reader = CSVReader.open(Source.fromURL(dataURL))

  val firstRow :: dataRows = reader.all

  val data = dataRows.map {
    case index :: values => values
    case _ => throw new IllegalStateException("Empty file")
  }

  val axisOptions = AxisOptions().noGrid.noLine.noZeroLine.noTickLabels.title("")

  val p = ThreeDPlot()
    .withSurface(data, SurfaceOptions().colorscale("Earth").noScale)
    .xAxisOptions(axisOptions)
    .yAxisOptions(axisOptions)
    .zAxisOptions(axisOptions)

  val figure = Figure()
    .plot(p)
    .margins(0, 0, 0, 0)

  val outputFile = draw(figure, "Mt Bruno")
  println(outputFile)
}


///* Multiple surface plots
// z data
val z1 = Vector(
  Vector(8.83, 8.89, 8.81, 8.87, 8.9, 8.87),
  Vector(8.89, 8.94, 8.85, 8.94, 8.96, 8.92),
  Vector(8.84, 8.9, 8.82, 8.92, 8.93, 8.91),
  Vector(8.79, 8.85, 8.79, 8.9, 8.94, 8.92),
  Vector(8.79, 8.88, 8.81, 8.9, 8.95, 8.92),
  Vector(8.8, 8.82, 8.78, 8.91, 8.94, 8.92),
  Vector(8.75, 8.78, 8.77, 8.91, 8.95, 8.92),
  Vector(8.8, 8.8, 8.77, 8.91, 8.95, 8.94),
  Vector(8.74, 8.81, 8.76, 8.93, 8.98, 8.99),
  Vector(8.89, 8.99, 8.92, 9.1, 9.13, 9.11),
  Vector(8.97, 8.97, 8.91, 9.09, 9.11, 9.11),
  Vector(9.04, 9.08, 9.05, 9.25, 9.28, 9.27),
  Vector(9, 9.01, 9, 9.2, 9.23, 9.2),
  Vector(8.99, 8.99, 8.98, 9.18, 9.2, 9.19),
  Vector(8.93, 8.97, 8.97, 9.18, 9.2, 9.18)
)

val z2 = z1.map { _.map { _ + 1.0 } }
val z3 = z1.map { _.map { _ - 1.0 } }

val p = ThreeDPlot()
  .withSurface(z1)
  .withSurface(z2, SurfaceOptions().opacity(0.9).noScale)
  .withSurface(z3, SurfaceOptions().opacity(0.9).noScale)

draw(p, "multiple-surfaces")



///*** plotly -     3D surface subplots
///* 3D surface subplots

val xs = (-3.0 to 3.0 by 0.2).toVector
val ys = (-3.0 to 3.0 by 0.2).toVector

// 2-dimensional quantum harmonic oscillator energy levels
def gaussian2D(x: Double, y: Double): Double = Math.exp(-x*x - y*y)
val z00 = xs.map { x => ys.map { y => gaussian2D(x, y) } } 
val z01 = xs.map { x => ys.map { y => y*gaussian2D(x, y) } }
val z11 = xs.map { x => ys.map { y => x*y*gaussian2D(x, y) } }
val z20 = xs.map { x => ys.map { y => (1-2*x*x)*gaussian2D(x, y) } }

val options = SurfaceOptions().noScale

val figure = GridFigure(2, 2) // four plots split over two rows
  .title("Eigenfunctions of the 2D quantum harmonic oscillator")
  .plot(0, 0) { // top left
    ThreeDPlot()
      .withSurface(xs, ys, z00, options)
      .zAxisOptions(AxisOptions().title("psi_00"))
  }
  .plot(0, 1) { // top right
    ThreeDPlot()
      .withSurface(xs, ys, z01, options)
      .zAxisOptions(AxisOptions().title("psi_01"))
  }
  .plot(1, 0) { // bottom left
    ThreeDPlot()
      .withSurface(xs, ys, z11, options)
      .zAxisOptions(AxisOptions().title("psi_11"))
  }
  .plot(1, 1) { // bottom right
    ThreeDPlot()
      .withSurface(xs, ys, z20, options)
      .zAxisOptions(AxisOptions().title("psi_20"))
  }

draw(figure, "qho-eigenfunctions")
