
package local

trait MinMax[T]{  
   def max(other: T): T 
   def min(other:T) :T 
 
 }


case class Rational (val n: Int, val d:Int) extends  MinMax[Rational] with Ordered[Rational]   {
	require( d != 0)

		
	def this (x: Tuple2[Int,Int])  = this(x._1, x._2)
	
	def + ( other : Rational ) : Rational = {
		new Rational(  process(this.n * other.d + this.d * other.n , this.d * other.d))
	}

	def - ( other : Rational ) : Rational = {
		new Rational( process(this.n * other.d - this.d * other.n , this.d * other.d))
	}

	def * ( other : Rational ) : Rational = {
		new Rational( process(this.n * other.n, this.d * other.d))
	}
	
	def / ( other : Rational ) : Rational = {
		new Rational( process(this.n * other.d, this.d * other.n))
	}
	
	private def process( x: Int, y: Int):Tuple2[Int,Int]  = if ( x == y) (1,1) else (x,y)  // process with  gcd, but now dummy
	
	def compare(other: Rational) =   (this.n * other.d)-(other.n * this.d)      // returns -1, 0, +1
	
	
	def max (other: Rational) : Rational  =  if (this > other) this else other 
	def min (other: Rational) : Rational  =  if (this < other) this else other
	


}

object Rational {

	implicit def intToRational( x: Int) : Rational = new Rational(x,1)

}

