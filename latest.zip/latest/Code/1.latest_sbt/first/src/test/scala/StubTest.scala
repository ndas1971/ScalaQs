package support

import org.scalatest._

class StubTest extends FunSpec with Matchers {

  describe("you description here") {
    it("should do something") {
      "Hello world" should equal("Hello world")
    }
  }
  
  describe("Cube tester") {
    it("cubes when given number ") {
      CubeCalculator.cube(3) should equal(27)
    }
  }
}
