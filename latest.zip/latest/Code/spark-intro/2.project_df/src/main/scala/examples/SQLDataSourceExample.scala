package examples

// $ spark-submit --class examples.SQLDataSourceExample  --driver-class-path mysql-connector-java-5.1.34.jar  --conf spark.executor.extraClassPath=mysql-connector-java-5.1.34.jar  --jars mysql-connector-java-5.1.34.jar --master local[4] target/scala-2.11/learning-assembly.jar


import java.util.Properties
import org.apache.spark.sql.SparkSession

object SQLDataSourceExample {

  case class Person(name: String, age: Long)

  def main(args: Array[String]) {
    val spark = SparkSession
      .builder()
      .appName("Spark SQL data sources example")
      .getOrCreate()

    runBasicDataSourceExample(spark)
    runBasicParquetExample(spark)
    runParquetSchemaMergingExample(spark)
    runJsonDatasetExample(spark)
    runJdbcDatasetExample(spark)

    spark.stop()
  }

  private def runBasicDataSourceExample(spark: SparkSession): Unit = {

    val usersDF = spark.read.load(raw"D:/Desktop/PPT/spark/data/users.parquet")   //unicode escape because of backward-slash-and-u, so use /
    usersDF.select("name", "favorite_color").write.mode(org.apache.spark.sql.SaveMode.Ignore).save("namesAndFavColors.parquet")


    val peopleDF = spark.read.format("json").load(raw"D:/Desktop/PPT/spark/data/people.json")
    peopleDF.select("name", "age").write.mode(org.apache.spark.sql.SaveMode.Ignore).format("parquet").save("namesAndAges.parquet")


    val sqlDF = spark.sql("SELECT * FROM parquet.`D:/Desktop/PPT/spark/data/users.parquet`")
    sqlDF.show()

  }

  private def runBasicParquetExample(spark: SparkSession): Unit = {

    // Encoders for most common types are automatically provided by importing spark.implicits._
    import spark.implicits._

    val peopleDF = spark.read.json(raw"D:/Desktop/PPT/spark/data/people.json")

    // DataFrames can be saved as Parquet files, maintaining the schema information
    peopleDF.write.mode(org.apache.spark.sql.SaveMode.Ignore).parquet(raw"D:/Desktop/PPT/spark/data/people.parquet")

    // Read in the parquet file created above
    // Parquet files are self-describing so the schema is preserved
    // The result of loading a Parquet file is also a DataFrame
    val parquetFileDF = spark.read.parquet(raw"D:/Desktop/PPT/spark/data/people.parquet")

    // Parquet files can also be used to create a temporary view and then used in SQL statements
    parquetFileDF.createOrReplaceTempView("parquetFile")
    val namesDF = spark.sql("SELECT name FROM parquetFile WHERE age BETWEEN 13 AND 19")
    namesDF.map(attributes => "Name: " + attributes(0)).show()
    
  }

  private def runParquetSchemaMergingExample(spark: SparkSession): Unit = {

    // This is used to implicitly convert an RDD to a DataFrame.
    import spark.implicits._

    // Create a simple DataFrame, store into a partition directory
    val squaresDF = spark.sparkContext.makeRDD(1 to 5).map(i => (i, i * i)).toDF("value", "square")
    squaresDF.write.mode(org.apache.spark.sql.SaveMode.Ignore).parquet(raw"D:/Desktop/PPT/spark/data/test_table/key=1")

    // Create another DataFrame in a new partition directory,
    // adding a new column and dropping an existing column
    val cubesDF = spark.sparkContext.makeRDD(6 to 10).map(i => (i, i * i * i)).toDF("value", "cube")
    cubesDF.write.mode(org.apache.spark.sql.SaveMode.Ignore).parquet(raw"D:/Desktop/PPT/spark/data/test_table/key=2")

    // Read the partitioned table
    val mergedDF = spark.read.option("mergeSchema", "true").parquet(raw"D:/Desktop/PPT/spark/data/test_table")
    mergedDF.printSchema()
    
  }

  private def runJsonDatasetExample(spark: SparkSession): Unit = {
    // $example on:json_dataset$
    // A JSON dataset is pointed to by path.
    // The path can be either a single text file or a directory storing text files
    val path = raw"D:/Desktop/PPT/spark/data/people.json"
    val peopleDF = spark.read.json(path)

    // The inferred schema can be visualized using the printSchema() method
    peopleDF.printSchema()
    
    // Creates a temporary view using the DataFrame
    peopleDF.createOrReplaceTempView("people")

    // SQL statements can be run by using the sql methods provided by spark
    val teenagerNamesDF = spark.sql("SELECT name FROM people WHERE age BETWEEN 13 AND 19")
    teenagerNamesDF.show()
   

    // Alternatively, a DataFrame can be created for a JSON dataset represented by
    // an RDD[String] storing one JSON object per string
    val otherPeopleRDD = spark.sparkContext.makeRDD(
      """{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}""" :: Nil)
    val otherPeople = spark.read.json(otherPeopleRDD)
    otherPeople.show()
    
  }

  private def runJdbcDatasetExample(spark: SparkSession): Unit = {

    // Note: JDBC loading and saving can be achieved via either the load/save or jdbc methods
    // Loading data from a JDBC source
    val jdbcDF = spark.read
      .format("jdbc")
      .option("url", "jdbc:mysql://localhost:3306/")
      .option("dbtable", "information_schema.tables")  //let's load this table    under database information_schema
      .option("user", "root")
      .option("password", "")
      .load()
      
    jdbcDF.show()

    val connectionProperties = new Properties()
    connectionProperties.put("user", "root")
    connectionProperties.put("password", "")
    val jdbcDF2 = spark.read.jdbc("jdbc:mysql://localhost:3306/", "information_schema.tables", connectionProperties)

    // Saving data to a JDBC source
    jdbcDF.write
      .format("jdbc")
      .option("url", "jdbc:mysql://localhost:3306/")
      .option("dbtable", "spark.tables")  //store it under spark 
      .option("user", "root")
      .option("password", "")
      .mode(org.apache.spark.sql.SaveMode.Ignore)
      .save()

    jdbcDF2.write.mode(org.apache.spark.sql.SaveMode.Ignore).jdbc("jdbc:mysql://localhost:3306/", "spark.tables", connectionProperties)

  }
}
