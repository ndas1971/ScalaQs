///*** Reactive Streams (low level)
1.The Reactive Streams standard defines an upstream demand channel and a downstream data channel. 
2.Publishers do not send data until a request for N elements arrives via the demand channel, 
  at which point they are free to push up to N elements downstream either in batches or individually. 
3.When outstanding demand exists, the publisher is free to push data to the subscriber as it becomes available. 
4.When demand is exhausted, the publisher cannot send data except as a response to demand signalled from downstream. 
5.This lack of demand, or backpressure, propagates upstream in a controlled manner, 
  allowing the source node to choose between starting up more resources, slowing down, or dropping data.

// data and demand travel in opposite directions, 
//merging streams splits the upstream demand and splitting streams merges the downstream demand.

//RS is defined by the following minimal set of interfaces.

trait Publisher[T] {
  def subscribe(s: Subscriber[T]): Unit
}

trait Subscriber[T] {
    def onSubscribe(s: Subscription): Unit
    def onNext(t: T): Unit
    def onError(t: Throwable): Unit
    def onComplete(): Unit
}

trait Subscription {
   def request(n: Int): Unit
   def cancel(): Unit
}

///*** Few utility class 
sealed abstract class Done extends Serializable
    Typically used together with Future to signal completion but there is no actual value completed. 
    More clearly signals intent than Unit and is available both from Scala and Java (which Unit is not). 
sealed abstract class NotUsed extends AnyRef
    This type is used in generic type signatures wherever the actual value is of no importanc

    
///*** Akka Streams - Introduction 
//Akka Streams has two major components:
1.A high-level, type safe DSL for creating descriptions of stream processing graphs.
2.Machinery for transforming these descriptions into live stream processing graphs backed by Akka actors 
  and implementing the Reactive Streams standard.
  
//Akka Streams have below  key properties:
1.They implement the Reactive Streams specification, 
  whose three main goals backpressure, async and non-blocking boundaries 
  and interoperability between different implementations do fully apply for Akka Streams too.
2.They provide an abstraction for an evaluation engine for the streams, which is called Materializer.
3.Programs are formulated as reusable building blocks, 
  which are represented as the three main types Source, Sink and Flow. 
4.The building blocks form a graph whose evaluation is based on the Materializer(result in  Future)
  and needs to be explicitly triggered.


//build.sbt 
libraryDependencies += "com.typesafe.akka" %% "akka-stream" % "2.5.9"

//required imports 
import scala.concurrent._
import akka._
import akka.actor._
import akka.stream._
import akka.stream.scaladsl._
import akka.util._

implicit val system = ActorSystem("TestSystem")
implicit val materializer = ActorMaterializer()
import system.dispatcher


///*** Akka Streams - Source

//A Source is a data creator, it serves as an input source to the stream. 
//Each Source has a single output channel and no input channel.
// All the data flows through the output channel to whatever is connected to the Source.


//A Source can be created in multiple ways(check object Source)
//Source[+Out, +Mat], new Source(traversalBuilder: LinearTraversalBuilder, shape: SourceShape[Out])

scala> val s = Source.empty
s: akka.stream.scaladsl.Source[Nothing,akka.NotUsed] = ...

scala> val s = Source.single("single element")
s: akka.stream.scaladsl.Source[String,akka.NotUsed] = ...

scala> val s1 = Source(1 to 3)
s: akka.stream.scaladsl.Source[Int,akka.NotUsed] = ...

scala> val s2 = Source.single(Future("single value from a Future"))
s: akka.stream.scaladsl.Source[String,akka.NotUsed] = ...

//Reactive Streams are lazy and asynchronous by default. 
//This means one explicitly has to request the evaluation of the stream. 
//In Akka Streams this can be done through the run* methods. 
scala> s1 runForeach println 
res8: scala.concurrent.Future[akka.Done] = Future(<not completed>)
1
2
3
scala> s2.runForeach{ f => f.onSuccess{ case x:String => println(x) } }
scala.concurrent.Future[akka.Done] = Future(<not completed>)
single value from a Future

//infinite stream 
scala> val s = Source.repeat(5)
s: akka.stream.scaladsl.Source[Int,akka.NotUsed] = ...

scala> s take 3 runForeach println
res1: scala.concurrent.Future[akka.Done] = ...
5
5
5

//Since actor support is built-in, feed the stream with messages that are sent to an actor
//Source[+Out, +Mat]
def run(actor: ActorRef) = {   // (ActorRef) => Future[Unit]
  Future { Thread.sleep(300); actor ! 1 }
  Future { Thread.sleep(200); actor ! 2 }
  Future { Thread.sleep(100); actor ! 3 }   //this is return of run, but Future does not have any return 
}
//actorRef[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, ActorRef] 
//create Source materialized as Actor(behaves like actor), 
//Messages sent to this actor will be emitted to the stream if there is demand from downstream, 
//mapMaterializedValue[Mat2](f: (Mat) => Mat2): Source[Out, Mat2] //Convert Mat to Mat2
val s = Source.actorRef[Int](bufferSize = 0, OverflowStrategy.fail) //akka.stream.scaladsl.Source[Int,akka.actor.ActorRef]
  .mapMaterializedValue(run)    //Convert ActorRef to 'return of run', akka.stream.scaladsl.Source[Int,scala.concurrent.Future[Unit]]

scala> s runForeach println
res1: scala.concurrent.Future[akka.Done] = ...
3
2
1


///* Reference 
final class akka.stream.scaladsl.Source[+Out, +Mat] extends FlowOpsMat[Out, Mat] with Graph[SourceShape[Out], Mat]
	A Source is a set of stream processing steps that has one open output. 
	It can comprise any number of internal sources and transformations that are wired together, 
	or it can be an “atomic” source, e.g. from a collection or a file. 
	Materialization turns a Source into a Reactive Streams Publisher 
    //Constructors 
	new Source(traversalBuilder: LinearTraversalBuilder, shape: SourceShape[Out]) 
	//Type Members
    type Closed = RunnableGraph[Mat]
    type ClosedMat[+M] = RunnableGraph[M]
    type Repr[+O] = Source[O, Mat]
    type ReprMat[+O, +M] = Source[O, M]
    type Shape = SourceShape[Out]
        Type-level accessor for the shape parameter of this graph.
    //Value Members
    def ++[U >: Out, M](that: Graph[SourceShape[U], M]): Repr[U]
        Concatenates this Flow with the given Source so the first element emitted by that source is emitted after the last element of this flow.
    def addAttributes(attr: Attributes): Repr[Out]
        Add the given attributes to this Source.
    def alsoTo(that: Graph[SinkShape[Out], _]): Repr[Out]
        Attaches the given Sink to this Flow, meaning that elements that pass through will also be sent to the Sink.
    def alsoToMat[Mat2, Mat3](that: Graph[SinkShape[Out], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
        Attaches the given Sink to this Flow, meaning that elements that pass through will also be sent to the Sink.
    def asJava: javadsl.Source[Out, Mat]
        Converts this Scala DSL element to it s Java DSL counterpart.
    def ask[S](parallelism: Int)(ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
        Use the ask pattern to send a request-reply message to the target ref actor.
    def ask[S](ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
        Use the ask pattern to send a request-reply message to the target ref actor.
        
    def async(dispatcher: String, inputBufferSize: Int): Repr[Out]
        Put an asynchronous boundary around this Graph
    def async(dispatcher: String): Repr[Out]
        Put an asynchronous boundary around this Graph
    def async: Repr[Out]
        Put an asynchronous boundary around this Source
    def backpressureTimeout(timeout: FiniteDuration): Repr[Out]
        If the time between the emission of an element and the following downstream demand exceeds the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def batch[S](max: Long, seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by aggregating elements into batches until the subscriber is ready to accept them.
    def batchWeighted[S](max: Long, costFn: (Out) => Long, seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by aggregating elements into batches until the subscriber is ready to accept them.
    def buffer(size: Int, overflowStrategy: OverflowStrategy): Repr[Out]
        Adds a fixed size buffer in the flow that allows to store elements from a faster upstream until it becomes full.
    def collect[T](pf: PartialFunction[Out, T]): Repr[T]
        Transform this stream by applying the given partial function to each of the elements on which the function is defined as they pass through this processing step.
    def collectType[T](implicit tag: ClassTag[T]): Repr[T]
        Transform this stream by testing the type of each of the elements on which the element is an instance of the provided type as they pass through this processing step.
    
    def completionTimeout(timeout: FiniteDuration): Repr[Out]
        If the completion of the stream does not happen until the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def concat[U >: Out, Mat2](that: Graph[SourceShape[U], Mat2]): Repr[U]
        Concatenate the given Source to this Flow, meaning that once this Flow’s input is exhausted and all result elements have been generated, the Source’s elements will be produced.
    def concatMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Concatenate the given Source to this Flow, meaning that once this Flow’s input is exhausted and all result elements have been generated, the Source’s elements will be produced.
    def conflate[O2 >: Out](aggregate: (O2, O2) => O2): Repr[O2]
        Allows a faster upstream to progress independently of a slower subscriber by conflating elements into a summary until the subscriber is ready to accept them.
    def conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by conflating elements into a summary until the subscriber is ready to accept them.
    def delay(of: FiniteDuration, strategy: DelayOverflowStrategy = DelayOverflowStrategy.dropTail): Repr[Out]
        Shifts elements emission in time by a specified amount.
    def detach: Repr[Out]
        Detaches upstream demand from downstream demand without detaching the stream rates; in other words acts like a buffer of size 1.
    def divertTo(that: Graph[SinkShape[Out], _], when: (Out) => Boolean): Repr[Out]
        Attaches the given Sink to this Flow, meaning that elements will be sent to the Sink instead of being passed through if the predicate when returns true.
    
    def divertToMat[Mat2, Mat3](that: Graph[SinkShape[Out], Mat2], when: (Out) => Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
        Attaches the given Sink to this Flow, meaning that elements will be sent to the Sink instead of being passed through if the predicate when returns true.
    def drop(n: Long): Repr[Out]
        Discard the given number of elements at the beginning of the stream.
    def dropWhile(p: (Out) => Boolean): Repr[Out]
        Discard elements at the beginning of the stream while predicate is true.
    def dropWithin(d: FiniteDuration): Repr[Out]
        Discard the elements received within the given duration at beginning of the stream.
    def expand[U](extrapolate: (Out) => Iterator[U]): Repr[U]
        Allows a faster downstream to progress independently of a slower publisher by extrapolating elements from an older element until new element comes from the upstream.
    
    def filter(p: (Out) => Boolean): Repr[Out]
        Only pass on those elements that satisfy the given predicate.
    def filterNot(p: (Out) => Boolean): Repr[Out]
        Only pass on those elements that NOT satisfy the given predicate.
    def flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Repr[T]
        Transform each input element into a Source of output elements that is then flattened into the output stream by concatenation, fully consuming one Source after the other.
    def flatMapMerge[T, M](breadth: Int, f: (Out) => Graph[SourceShape[T], M]): Repr[T]
        Transform each input element into a Source of output elements that is then flattened into the output stream by merging, where at most breadth substreams are being consumed at any given time.
    def fold[T](zero: T)(f: (T, Out) => T): Repr[T]
        Similar to scan but only emits its result when the upstream completes, after which it also completes.
    def foldAsync[T](zero: T)(f: (T, Out) => Future[T]): Repr[T]
        Similar to fold but with an asynchronous function.
    def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Repr, Closed]
        This operation demultiplexes the incoming stream into separate output streams, one for each element key.
    def grouped(n: Int): Repr[Seq[Out]]
        Chunk up this stream into groups of the given size, with the last group possibly smaller than requested due to end-of-stream.
    def groupedWeightedWithin(maxWeight: Long, d: FiniteDuration)(costFn: (Out) => Long): Repr[Seq[Out]]
        Chunk up this stream into groups of elements received within a time window, or limited by the weight of the elements, whatever happens first.
    def groupedWithin(n: Int, d: FiniteDuration): Repr[Seq[Out]]
        Chunk up this stream into groups of elements received within a time window, or limited by the given number of elements, whatever happens first.
    def idleTimeout(timeout: FiniteDuration): Repr[Out]
        If the time between two processed elements exceeds the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def initialDelay(delay: FiniteDuration): Repr[Out]
        Delays the initial element by the specified duration.
    def initialTimeout(timeout: FiniteDuration): Repr[Out]
        If the first element has not passed through this stage before the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    
    def interleave[U >: Out](that: Graph[SourceShape[U], _], segmentSize: Int, eagerClose: Boolean): Repr[U]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleave[U >: Out](that: Graph[SourceShape[U], _], segmentSize: Int): Repr[U]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleaveMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2], request: Int, eagerClose: Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleaveMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2], request: Int)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def intersperse[T >: Out](inject: T): Repr[T]
        Intersperses stream with provided element, similar to how scala.collection.immutable.List.mkString injects a separator between a List's elements.
    def intersperse[T >: Out](start: T, inject: T, end: T): Repr[T]
        Intersperses stream with provided element, similar to how scala.collection.immutable.List.mkString injects a separator between a List's elements.
    def keepAlive[U >: Out](maxIdle: FiniteDuration, injectedElem: () => U): Repr[U]
        Injects additional elements if upstream does not emit for a configured amount of time.
    def limit(max: Long): Repr[Out]
        Ensure stream boundedness by limiting the number of elements from upstream.
    def limitWeighted[T](max: Long)(costFn: (Out) => Long): Repr[Out]
        Ensure stream boundedness by evaluating the cost of incoming elements using a cost function.
    
    def log(name: String, extract: (Out) => Any = ConstantFun.scalaIdentityFunction)(implicit log: LoggingAdapter = null): Repr[Out]
        Logs elements flowing through the stream as well as completion and erroring.
    def map[T](f: (Out) => T): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapAsync[T](parallelism: Int)(f: (Out) => Future[T]): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapAsyncUnordered[T](parallelism: Int)(f: (Out) => Future[T]): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapConcat[T](f: (Out) => Iterable[T]): Repr[T]
        Transform each input element into an Iterable of output elements that is then flattened into the output stream.
    def mapError(pf: PartialFunction[Throwable, Throwable]): Repr[Out]
        While similar to recover this stage can be used to transform an error signal to a different one *without* logging it as an error in the process.
    def mapMaterializedValue[Mat2](f: (Mat) => Mat2): ReprMat[Out, Mat2]
        Transform only the materialized value of this Source, leaving all other properties as they were.
    
    def merge[U >: Out, M](that: Graph[SourceShape[U], M], eagerComplete: Boolean = false): Repr[U]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking randomly when several elements ready.
    def mergeMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2], eagerComplete: Boolean = false)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking randomly when several elements ready.
    def mergeSorted[U >: Out, M](that: Graph[SourceShape[U], M])(implicit ord: Ordering[U]): Repr[U]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking always the smallest of the available elements (waiting for one element from each side to be available).
    def mergeSortedMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3)(implicit ord: Ordering[U]): ReprMat[U, Mat3]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking always the smallest of the available elements (waiting for one element from each side to be available).
    def monitor[Mat2]()(combine: (Mat, FlowMonitor[Out]) => Mat2): ReprMat[Out, Mat2]
        Materializes to FlowMonitor[Out] that allows monitoring of the current flow.
    def named(name: String): Repr[Out]
        Add a name attribute to this Source.
    def orElse[U >: Out, Mat2](secondary: Graph[SourceShape[U], Mat2]): Repr[U]
        Provides a secondary source that will be consumed if this stream completes without any elements passing by.
    def orElseMat[U >: Out, Mat2, Mat3](secondary: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Provides a secondary source that will be consumed if this stream completes without any elements passing by.
    
    def preMaterialize()(implicit materializer: Materializer): (Mat, ReprMat[Out, NotUsed])
        Materializes this Source, immediately returning (1) its materialized value, and (2) a new Source that can be used to consume elements from the newly materialized Source.
    def prefixAndTail[U >: Out](n: Int): Repr[(Seq[Out], Source[U, NotUsed])]
        Takes up to n elements from the stream (less than n only if the upstream completes before emitting n elements) and returns a pair containing a strict sequence of the taken element and a stream representing the remaining elements.
    def prepend[U >: Out, Mat2](that: Graph[SourceShape[U], Mat2]): Repr[U]
        Prepend the given Source to this Flow, meaning that before elements are generated from this Flow, the Source's elements will be produced until it is exhausted, at which point Flow elements will start being produced.
    def prependMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Prepend the given Source to this Flow, meaning that before elements are generated from this Flow, the Source's elements will be produced until it is exhausted, at which point Flow elements will start being produced.
    def recover[T >: Out](pf: PartialFunction[Throwable, T]): Repr[T]
        Recover allows to send last element on failure and gracefully complete the stream Since the underlying failure signal onError arrives out-of-band, it might jump over existing elements.
    def recoverWithRetries[T >: Out](attempts: Int, pf: PartialFunction[Throwable, Graph[SourceShape[T], NotUsed]]): Repr[T]
        RecoverWithRetries allows to switch to alternative Source on flow failure.
    
    def reduce[T >: Out](f: (T, T) => T): Repr[T]
        Similar to fold but uses first element as zero element.
    def runFold[U](zero: U)(f: (U, Out) => U)(implicit materializer: Materializer): Future[U]
        Shortcut for running this Source with a fold function.
    def runFoldAsync[U](zero: U)(f: (U, Out) => Future[U])(implicit materializer: Materializer): Future[U]
        Shortcut for running this Source with a foldAsync function.
    def runForeach(f: (Out) => Unit)(implicit materializer: Materializer): Future[Done]
        Shortcut for running this Source with a foreach procedure.
    def runReduce[U >: Out](f: (U, U) => U)(implicit materializer: Materializer): Future[U]
        Shortcut for running this Source with a reduce function.
    def runWith[Mat2](sink: Graph[SinkShape[Out], Mat2])(implicit materializer: Materializer): Mat2
        Connect this Source to a Sink and run it.
    def scan[T](zero: T)(f: (T, Out) => T): Repr[T]
        Similar to fold but is not a terminal operation, emits its current value which starts at zero and then applies the current and next value to the given function f, emitting the next current value.
    def scanAsync[T](zero: T)(f: (T, Out) => Future[T]): Repr[T]
        Similar to scan but with a asynchronous function, emits its current value which starts at zero and then applies the current and next value to the given function f, emitting a Future that resolves to the next current value.
    val shape: SourceShape[Out]
    
    def sliding(n: Int, step: Int = 1): Repr[Seq[Out]]
        Apply a sliding window over the stream and return the windows as groups of elements, with the last group possibly smaller than requested due to end-of-stream.
    def splitAfter(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams.
    def splitAfter(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams.
    def splitWhen(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams, always beginning a new one with the current element if the given predicate returns true for it.
    def splitWhen(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams, always beginning a new one with the current element if the given predicate returns true for it.
    
    val src: Source[Out, Future[T]]
    def statefulMapConcat[T](f: () => (Out) => Iterable[T]): Repr[T]
        Transform each input element into an Iterable of output elements that is then flattened into the output stream.
    def take(n: Long): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after the given number of elements.
    def takeWhile(p: (Out) => Boolean, inclusive: Boolean): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after predicate returns false for the first time, including the first failed element iff inclusive is true Due to input buffering some elements may have been requested from upstream publishers that will then not be processed downstream of this step.
    def takeWhile(p: (Out) => Boolean): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after predicate returns false for the first time, Due to input buffering some elements may have been requested from upstream publishers that will then not be processed downstream of this step.
  
    def takeWithin(d: FiniteDuration): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after the given duration.
    def throttle(cost: Int, per: FiniteDuration, maximumBurst: Int, costCalculation: (Out) => Int, mode: ThrottleMode): Repr[Out]
        Sends elements downstream with speed limited to cost/per.
        
    def throttle(elements: Int, per: FiniteDuration, maximumBurst: Int, mode: ThrottleMode): Repr[Out]
        Sends elements downstream with speed limited to elements/per.
    def throttleEven(cost: Int, per: FiniteDuration, costCalculation: (Out) => Int, mode: ThrottleMode): Repr[Out]
        This is a simplified version of throttle that spreads events evenly across the given time interval.
    def throttleEven(elements: Int, per: FiniteDuration, mode: ThrottleMode): Repr[Out]
        This is a simplified version of throttle that spreads events evenly across the given time interval.
    
    def to[Mat2](sink: Graph[SinkShape[Out], Mat2]): RunnableGraph[Mat]
        Connect this akka.stream.scaladsl.Source to a akka.stream.scaladsl.Sink, concatenating the processing steps of both.
    def toCompletionStage(): Source[Out, CompletionStage[T]]
    def toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]
        Connect this akka.stream.scaladsl.Source to a akka.stream.scaladsl.Sink, concatenating the processing steps of both.
    def toString(): String
    val traversalBuilder: LinearTraversalBuilder
    
    def via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Repr[T]
        Transform this Flow by appending the given processing steps.
    def viaMat[T, Mat2, Mat3](flow: Graph[FlowShape[Out, T], Mat2])(combine: (Mat, Mat2) => Mat3): Source[T, Mat3]
        Transform this Flow by appending the given processing steps.
    
    def watch(ref: ActorRef): Repr[Out]
        The stage fails with an akka.stream.WatchedActorTerminatedException if the target actor is terminated.
    def watchTermination[Mat2]()(matF: (Mat, Future[Done]) => Mat2): ReprMat[Out, Mat2]
        Materializes to Future[Done] that completes on getting termination message.
    def wireTap(that: Graph[SinkShape[Out], _]): Repr[Out]
        Attaches the given Sink to this Flow as a wire tap, meaning that elements that pass through will also be sent to the wire-tap Sink, without the latter affecting the mainline flow.
    def wireTapMat[Mat2, Mat3](that: Graph[SinkShape[Out], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
        Attaches the given Sink to this Flow as a wire tap, meaning that elements that pass through will also be sent to the wire-tap Sink, without the latter affecting the mainline flow.
    def withAttributes(attr: Attributes): Repr[Out]
        Replace the attributes of this Source with the given ones.
    
    def zip[U](that: Graph[SourceShape[U], _]): Repr[(Out, U)]
        Combine the elements of current flow and the given Source into a stream of tuples.
    def zipMat[U, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[(Out, U), Mat3]
        Combine the elements of current flow and the given Source into a stream of tuples.
    def zipWith[Out2, Out3](that: Graph[SourceShape[Out2], _])(combine: (Out, Out2) => Out3): Repr[Out3]
        Put together the elements of current flow and the given Source into a stream of combined elements using a combiner function.
    def zipWithIndex: Repr[(Out, Long)]
        Combine the elements of current flow into a stream of tuples consisting of all elements paired with their index.
    def zipWithMat[Out2, Out3, Mat2, Mat3](that: Graph[SourceShape[Out2], Mat2])(combine: (Out, Out2) => Out3)(matF: (Mat, Mat2) => Mat3): ReprMat[Out3, Mat3]
        Put together the elements of current flow and the given Source into a stream of combined elements using a combiner function.
object Source
    def actorRef[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, ActorRef]
        Creates a Source that is materialized as an akka.actor.ActorRef.
        Messages sent to this actor will be emitted to the stream if there is demand from downstream, 
        otherwise they will be buffered until request for demand is received.
        Depending on the defined akka.stream.OverflowStrategy it might drop elements if there is no space available in the buffer.
    def apply[T](iterable: Iterable[T]): Source[T, NotUsed]
        Helper to create Source from Iterable.
    def asSubscriber[T]: Source[T, Subscriber[T]]
        Creates a Source that is materialized as a org.reactivestreams.Subscriber
    def combine[T, U](first: Source[T, _], second: Source[T, _], rest: Source[T, _]*)(strategy: (Int) => Graph[UniformFanInShape[T, U], NotUsed]): Source[U, NotUsed]
        Combines several sources with fan-in strategy like Merge or Concat and returns Source.
    def combineMat[T, U, M1, M2, M](first: Source[T, M1], second: Source[T, M2])(strategy: (Int) => Graph[UniformFanInShape[T, U], NotUsed])(matF: (M1, M2) => M): Source[U, M]
        Combines two sources with fan-in strategy like Merge or Concat and returns Source with a materialized value.
    
    def cycle[T](f: () => Iterator[T]): Source[T, NotUsed]
        Creates Source that will continually produce given elements in specified order.
    def empty[T]: Source[T, NotUsed]
        A Source with no elements, i.e.
    def failed[T](cause: Throwable): Source[T, NotUsed]
        Create a Source that immediately ends the stream with the cause error to every connected Sink.
    
    def fromCompletionStage[T](future: CompletionStage[T]): Source[T, NotUsed]
        Starts a new Source from the given Future.
    def fromFuture[T](future: Future[T]): Source[T, NotUsed]
        Starts a new Source from the given Future.
    def fromFutureSource[T, M](future: Future[Graph[SourceShape[T], M]]): Source[T, Future[M]]
        Streams the elements of the given future source once it successfully completes.
    
    def fromGraph[T, M](g: Graph[SourceShape[T], M]): Source[T, M]
        A graph with the shape of a source logically is a source, this method makes it so also in type.
    def fromIterator[T](f: () => Iterator[T]): Source[T, NotUsed]
        Helper to create Source from Iterator.
    def fromPublisher[T](publisher: Publisher[T]): Source[T, NotUsed]
        Helper to create Source from Publisher.
    
    def fromSourceCompletionStage[T, M](completion: CompletionStage[_ <: Graph[SourceShape[T], M]]): Source[T, CompletionStage[M]]
        Streams the elements of an asynchronous source once its given completion stage completes.
    def lazily[T, M](create: () => Source[T, M]): Source[T, Future[M]]
        Creates a Source that is not materialized until there is downstream demand, when the source gets materialized the materialized future is completed with its value, if downstream cancels or fails without any demand the create factory is never called and the materialized Future is failed.
    def lazilyAsync[T](create: () => Future[T]): Source[T, Future[NotUsed]]
        Creates a Source from supplied future factory that is not called until downstream demand.
    
    def maybe[T]: Source[T, Promise[Option[T]]]
        Create a Source which materializes a scala.concurrent.Promise which controls what element will be emitted by the Source.
    def queue[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, SourceQueueWithComplete[T]]
        Creates a Source that is materialized as an akka.stream.scaladsl.SourceQueue.
    
    def repeat[T](element: T): Source[T, NotUsed]
        Create a Source that will continually emit the given element.
    def shape[T](name: String): SourceShape[T]
        INTERNAL API
    def single[T](element: T): Source[T, NotUsed]
        Create a Source with one element.
    
    def tick[T](initialDelay: FiniteDuration, interval: FiniteDuration, tick: T): Source[T, Cancellable]
        Elements are emitted periodically with the specified interval.
    def unfold[S, E](s: S)(f: (S) => Option[(S, E)]): Source[E, NotUsed]
        Create a Source that will unfold a value of type S into a pair of the next state S and output elements of type E.
    def unfoldAsync[S, E](s: S)(f: (S) => Future[Option[(S, E)]]): Source[E, NotUsed]
        Same as unfold, but uses an async function to generate the next state-element tuple.
    
    def unfoldResource[T, S](create: () => S, read: (S) => Option[T], close: (S) => Unit): Source[T, NotUsed]
        Start a new Source from some resource which can be opened, read and closed.
    def unfoldResourceAsync[T, S](create: () => Future[S], read: (S) => Future[Option[T]], close: (S) => Future[Done]): Source[T, NotUsed]
        Start a new Source from some resource which can be opened, read and closed.
    def zipN[T](sources: Seq[Source[T, _]]): Source[Seq[T], NotUsed]
        Combine the elements of multiple streams into a stream of sequences.
    def zipWithN[T, O](zipper: (Seq[T]) => O)(sources: Seq[Source[T, _]]): Source[O, NotUsed]
    

///*** Akka Streams - Sink
//A Sink is basically the opposite of a Source. 
//It is the endpoint of a stream and therefore consumes data. 
//A Sink[-In, +Mat] has a single input channel and no output channel. 


scala> val source = Source(1 to 3)
source: akka.stream.scaladsl.Source[Int,akka.NotUsed] = ...

scala> val sink = Sink.foreach[Int](elem => println(s"sink received: $elem"))
sink: akka.stream.scaladsl.Sink[Int,scala.concurrent.Future[akka.Done]] = ...

scala> val flow = source to sink
flow: akka.stream.scaladsl.RunnableGraph[akka.NotUsed] = ...

scala> flow.run()
res3: akka.NotUsed = NotUsed
sink received: 1
sink received: 2
sink received: 3


///* Reference 
final class akka.stream.scaladsl.Sink[-In, +Mat] extends Graph[SinkShape[In], Mat]
    A Sink is a set of stream processing steps that has one open input. Can be used as a Subscriber
	//Instance Constructors
	new Sink(traversalBuilder: LinearTraversalBuilder, shape: SinkShape[In]) 
    //Type Members
    type Shape = SinkShape[In]
        Type-level accessor for the shape parameter of this graph.
    //Value Members
    def addAttributes(attr: Attributes): Sink[In, Mat]
        Add the given attributes to this Sink.
    def asJava: javadsl.Sink[In, Mat]
        Converts this Scala DSL element to its Java DSL counterpart.
    def async(dispatcher: String, inputBufferSize: Int): Sink[In, Mat]
        Put an asynchronous boundary around this Graph
    def async(dispatcher: String): Sink[In, Mat]
        Put an asynchronous boundary around this Graph
    def async: Sink[In, Mat]
        Put an asynchronous boundary around this Source
    def contramap[In2](f: (In2) => In): Sink[In2, Mat]
        Transform this Sink by applying a function to each *incoming* upstream element before it is passed to the Sink
    def mapMaterializedValue[Mat2](f: (Mat) => Mat2): Sink[In, Mat2]
        Transform only the materialized value of this Sink, leaving all other properties as they were.
    def named(name: String): Sink[In, Mat]
        Add a name attribute to this Sink.
    def runWith[Mat2](source: Graph[SourceShape[In], Mat2])(implicit materializer: Materializer): Mat2
        Connect this Sink to a Source and run it.
    val shape: SinkShape[In]
    val sink: Sink[In, Future[T]]
    def toCompletionStage(): Sink[In, CompletionStage[T]]
    def toString(): String
    val traversalBuilder: LinearTraversalBuilder
    def withAttributes(attr: Attributes): Sink[In, Mat]
        Replace the attributes of this Sink with the given ones.
object Sink
    def actorRef[T](ref: ActorRef, onCompleteMessage: Any): Sink[T, NotUsed]
        Sends the elements of the stream to the given ActorRef.
        Sends the elements of the stream to the given ActorRef. 
        If the target actor terminates the stream will be canceled. When the stream is completed successfully 
        the given onCompleteMessage will be sent to the destination actor. 
        When the stream is completed with failure a akka.actor.Status.Failure message will be sent to the destination actor.
    def actorRefWithAck[T](ref: ActorRef, onInitMessage: Any, ackMessage: Any, onCompleteMessage: Any, onFailureMessage: (Throwable) => Any = Status.Failure): Sink[T, NotUsed]
        Sends the elements of the stream to the given ActorRef that sends back back-pressure signal.
    def asPublisher[T](fanout: Boolean): Sink[T, Publisher[T]]
        A Sink that materializes into a org.reactivestreams.Publisher.
    def cancelled[T]: Sink[T, NotUsed]
        A Sink that immediately cancels its upstream after materialization.
    def collection[T, That](implicit cbf: CanBuildFrom[Nothing, T, That with Traversable[_]]): Sink[T, Future[That]]
        A Sink that keeps on collecting incoming elements until upstream terminates.
    def combine[T, U](first: Sink[U, _], second: Sink[U, _], rest: Sink[U, _]*)(strategy: (Int) => Graph[UniformFanOutShape[T, U], NotUsed]): Sink[T, NotUsed]
        Combine several sinks with fan-out strategy like Broadcast or Balance and returns Sink.
    def fold[U, T](zero: U)(f: (U, T) => U): Sink[T, Future[U]]
        A Sink that will invoke the given function for every received element, giving it its previous output (or the given zero value) and the element as input.
    def foldAsync[U, T](zero: U)(f: (U, T) => Future[U]): Sink[T, Future[U]]
        A Sink that will invoke the given asynchronous function for every received element, giving it its previous output (or the given zero value) and the element as input.
    def foreach[T](f: (T) => Unit): Sink[T, Future[Done]]
        A Sink that will invoke the given procedure for each received element.
    def foreachParallel[T](parallelism: Int)(f: (T) => Unit)(implicit ec: ExecutionContext): Sink[T, Future[Done]]
        A Sink that will invoke the given function to each of the elements as they pass in.
    def fromGraph[T, M](g: Graph[SinkShape[T], M]): Sink[T, M]
        A graph with the shape of a sink logically is a sink, this method makes it so also in type.
    def fromSubscriber[T](subscriber: Subscriber[T]): Sink[T, NotUsed]
        Helper to create Sink from Subscriber.
    def head[T]: Sink[T, Future[T]]
        A Sink that materializes into a Future of the first value received.
    def headOption[T]: Sink[T, Future[Option[T]]]
        A Sink that materializes into a Future of the optional first value received.
    def ignore: Sink[Any, Future[Done]]
        A Sink that will consume the stream and discard the elements.
    def last[T]: Sink[T, Future[T]]
        A Sink that materializes into a Future of the last value received.
    def lastOption[T]: Sink[T, Future[Option[T]]]
        A Sink that materializes into a Future of the optional last value received.
    def lazyInit[T, M](sinkFactory: (T) => Future[Sink[T, M]], fallback: () => M): Sink[T, Future[M]]
        Creates a real Sink upon receiving the first element.
    def onComplete[T](callback: (Try[Done]) => Unit): Sink[T, NotUsed]
        A Sink that when the flow is completed, either through a failure or normal completion, apply the provided function with scala.util.Success or scala.util.Failure.
    def queue[T](): Sink[T, SinkQueueWithCancel[T]]
        Creates a Sink that is materialized as an akka.stream.scaladsl.SinkQueue.
    def reduce[T](f: (T, T) => T): Sink[T, Future[T]]
        A Sink that will invoke the given function for every received element, giving it its previous output (from the second element) and the element as input.
    def seq[T]: Sink[T, Future[Seq[T]]]
        A Sink that keeps on collecting incoming elements until upstream terminates.
    def shape[T](name: String): SinkShape[T]
        INTERNAL API





///*** Akka Streams - Runnable Flow
//Flow with attached input and output, can be executed.

val actor = system.actorOf(Props(new Actor {
  override def receive = {
    case msg => println(s"actor received: $msg")
  }
}))

scala> val sink = Sink.actorRef[Int](actor, onCompleteMessage = "stream completed")
sink: akka.stream.scaladsl.Sink[Int,akka.NotUsed] = ...

scala> val runnable = Source(1 to 3) to sink
runnable: akka.stream.scaladsl.RunnableGraph[akka.NotUsed] = ...

scala> runnable.run()
res3: akka.NotUsed = NotUsed
actor received: 1
actor received: 2
actor received: 3
actor received: stream completed

///* Reference 
final case class akka.stream.scaladsl.RunnableGraph[+Mat](traversalBuilder: TraversalBuilder) extends Graph[ClosedShape, Mat] with Product with Serializable
	Flow with attached input and output, can be executed.
	//Instance Constructors
	new RunnableGraph(traversalBuilder: TraversalBuilder) 
    //Type Members
    type Shape = ClosedShape
        Type-level accessor for the shape parameter of this graph.
    //Value Members
    def addAttributes(attr: Attributes): RunnableGraph[Mat]
        Add the given attributes to this Graph.
    def async(dispatcher: String, inputBufferSize: Int): RunnableGraph[Mat]
        Note that an async boundary around a runnable graph does not make sense
    def async(dispatcher: String): RunnableGraph[Mat]
        Note that an async boundary around a runnable graph does not make sense
    def async: RunnableGraph[Mat]
        Note that an async boundary around a runnable graph does not make sense
    def mapMaterializedValue[Mat2](f: (Mat) => Mat2): RunnableGraph[Mat2]
        Transform only the materialized value of this RunnableGraph, leaving all other properties as they were.
    def named(name: String): RunnableGraph[Mat]
    def run()(implicit materializer: Materializer): Mat
        Run this flow and return the materialized instance from the flow.
    def shape: ClosedShape.type
        The shape of a graph is all that is externally visible: its inlets and outlets.
    val traversalBuilder: TraversalBuilder
    def withAttributes(attr: Attributes): RunnableGraph[Mat] 
object RunnableGraph extends Serializable
    def fromGraph[Mat](g: Graph[ClosedShape, Mat]): RunnableGraph[Mat]
        A graph with a closed shape is logically a runnable graph, this method makes it so also in type.




///*** Akka Streams - Flow[-In, +Out, +Mat]
// They act as a connector between different streams and can be used to transform its elements.
//If a Flow is connected to a Source a new Source is the result. 
//Likewise, a Flow connected to a Sink creates a new Sink. 

//And a Flow connected with both a Source and a Sink results in a RunnableFlow. 
//they sit between the input and the output channel 
//but by themselves do not correspond to one of the flavors as long as they are not connected to either a Source or a Sink.


scala> val source = Source(1 to 3)
source: akka.stream.scaladsl.Source[Int,akka.NotUsed] = ...

scala> val sink = Sink.foreach[Int](println)
sink: akka.stream.scaladsl.Sink[Int,scala.concurrent.Future[akka.Done]] = ...

//object Flow.apply[T]: Flow[T, T, NotUsed] 
scala> val invert = Flow[Int].map(elem => elem * -1)
invert: akka.stream.scaladsl.Flow[Int,Int,akka.NotUsed] = ...

scala> val doubler = Flow[Int].map(elem => elem * 2)
doubler: akka.stream.scaladsl.Flow[Int,Int,akka.NotUsed] = ...

//Via the via method we can connect a Source with a Flow. 
//specify the input type because the compiler canot infer it for us. 

scala> val runnable = source via invert via doubler to sink
runnable: akka.stream.scaladsl.RunnableGraph[akka.NotUsed] = ...

scala> runnable.run()
res10: akka.NotUsed = NotUsed
-2
-4
-6

//s1 and s2 represent completely new streams - they do not share any data through their building blocks.
scala> val s1 = Source(1 to 3) via invert to sink
s1: akka.stream.scaladsl.RunnableGraph[akka.NotUsed] = ...

scala> val s2 = Source(-3 to -1) via invert to sink
s2: akka.stream.scaladsl.RunnableGraph[akka.NotUsed] = ...

scala> s1.run()
res10: akka.NotUsed = NotUsed
-1
-2
-3

scala> s2.run()
res11: akka.NotUsed = NotUsed
3
2
1



///*Reference 
final class akka.stream.scaladsl.Flow[-In, +Out, +Mat] extends FlowOpsMat[Out, Mat] with Graph[FlowShape[In, Out], Mat]
	A Flow is a set of stream processing steps that has one open input and one open output.
	//Instance Constructors
	new Flow(traversalBuilder: LinearTraversalBuilder, shape: FlowShape[In, Out]) 
    //Type Members
    type Closed = Sink[In, Mat]
    type ClosedMat[+M] = Sink[In, M]
    type Repr[+O] = Flow[In, O, Mat]
    type ReprMat[+O, +M] = Flow[In, O, M]
    type Shape = FlowShape[In, Out]
        Type-level accessor for the shape parameter of this graph.
    //Value Members
    def ++[U >: Out, M](that: Graph[SourceShape[U], M]): Repr[U]
        Concatenates this Flow with the given Source so the first element emitted by that source is emitted after the last element of this flow.
    def addAttributes(attr: Attributes): Repr[Out]
        Add the given attributes to this Flow.
    def alsoTo(that: Graph[SinkShape[Out], _]): Repr[Out]
        Attaches the given Sink to this Flow, meaning that elements that pass through will also be sent to the Sink.
    def alsoToMat[Mat2, Mat3](that: Graph[SinkShape[Out], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
        Attaches the given Sink to this Flow, meaning that elements that pass through will also be sent to the Sink.
    def asJava: javadsl.Flow[In, Out, Mat]
        Converts this Scala DSL element to its Java DSL counterpart.
    def ask[S](parallelism: Int)(ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
        Use the ask pattern to send a request-reply message to the target ref actor.
    def ask[S](ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
        Use the ask pattern to send a request-reply message to the target ref actor.
    def async(dispatcher: String, inputBufferSize: Int): Repr[Out]
        Put an asynchronous boundary around this Flow
    def async(dispatcher: String): Repr[Out]
        Put an asynchronous boundary around this Flow
    def async: Repr[Out]
        Put an asynchronous boundary around this Flow
    def backpressureTimeout(timeout: FiniteDuration): Repr[Out]
        If the time between the emission of an element and the following downstream demand exceeds the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def batch[S](max: Long, seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by aggregating elements into batches until the subscriber is ready to accept them.
    def batchWeighted[S](max: Long, costFn: (Out) => Long, seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by aggregating elements into batches until the subscriber is ready to accept them.
    def buffer(size: Int, overflowStrategy: OverflowStrategy): Repr[Out]
        Adds a fixed size buffer in the flow that allows to store elements from a faster upstream until it becomes full.
    def collect[T](pf: PartialFunction[Out, T]): Repr[T]
        Transform this stream by applying the given partial function to each of the elements on which the function is defined as they pass through this processing step.
    def collectType[T](implicit tag: ClassTag[T]): Repr[T]
        Transform this stream by testing the type of each of the elements on which the element is an instance of the provided type as they pass through this processing step.
    def completionTimeout(timeout: FiniteDuration): Repr[Out]
        If the completion of the stream does not happen until the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def concat[U >: Out, Mat2](that: Graph[SourceShape[U], Mat2]): Repr[U]
        Concatenate the given Source to this Flow, meaning that once this Flow’s input is exhausted and all result elements have been generated, the Source’s elements will be produced.
    def concatMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Concatenate the given Source to this Flow, meaning that once this Flow’s input is exhausted and all result elements have been generated, the Source’s elements will be produced.
    def conflate[O2 >: Out](aggregate: (O2, O2) => O2): Repr[O2]
        Allows a faster upstream to progress independently of a slower subscriber by conflating elements into a summary until the subscriber is ready to accept them.
    def conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by conflating elements into a summary until the subscriber is ready to accept them.
    def delay(of: FiniteDuration, strategy: DelayOverflowStrategy = DelayOverflowStrategy.dropTail): Repr[Out]
        Shifts elements emission in time by a specified amount.
    def detach: Repr[Out]
        Detaches upstream demand from downstream demand without detaching the stream rates; in other words acts like a buffer of size 1.
    def divertTo(that: Graph[SinkShape[Out], _], when: (Out) => Boolean): Repr[Out]
        Attaches the given Sink to this Flow, meaning that elements will be sent to the Sink instead of being passed through if the predicate when returns true.
    def divertToMat[Mat2, Mat3](that: Graph[SinkShape[Out], Mat2], when: (Out) => Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
        Attaches the given Sink to this Flow, meaning that elements will be sent to the Sink instead of being passed through if the predicate when returns true.
    def drop(n: Long): Repr[Out]
        Discard the given number of elements at the beginning of the stream.
    def dropWhile(p: (Out) => Boolean): Repr[Out]
        Discard elements at the beginning of the stream while predicate is true.
    def dropWithin(d: FiniteDuration): Repr[Out]
        Discard the elements received within the given duration at beginning of the stream.
    def expand[U](extrapolate: (Out) => Iterator[U]): Repr[U]
        Allows a faster downstream to progress independently of a slower publisher by extrapolating elements from an older element until new element comes from the upstream.
    def filter(p: (Out) => Boolean): Repr[Out]
        Only pass on those elements that satisfy the given predicate.
    def filterNot(p: (Out) => Boolean): Repr[Out]
        Only pass on those elements that NOT satisfy the given predicate.
    def flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Repr[T]
        Transform each input element into a Source of output elements that is then flattened into the output stream by concatenation, fully consuming one Source after the other.
    def flatMapMerge[T, M](breadth: Int, f: (Out) => Graph[SourceShape[T], M]): Repr[T]
        Transform each input element into a Source of output elements that is then flattened into the output stream by merging, where at most breadth substreams are being consumed at any given time.
    def fold[T](zero: T)(f: (T, Out) => T): Repr[T]
        Similar to scan but only emits its result when the upstream completes, after which it also completes.
    def foldAsync[T](zero: T)(f: (T, Out) => Future[T]): Repr[T]
        Similar to fold but with an asynchronous function.
    def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Repr, Closed]
        This operation demultiplexes the incoming stream into separate output streams, one for each element key.
    def grouped(n: Int): Repr[Seq[Out]]
        Chunk up this stream into groups of the given size, with the last group possibly smaller than requested due to end-of-stream.
    def groupedWeightedWithin(maxWeight: Long, d: FiniteDuration)(costFn: (Out) => Long): Repr[Seq[Out]]
        Chunk up this stream into groups of elements received within a time window, or limited by the weight of the elements, whatever happens first.
    def groupedWithin(n: Int, d: FiniteDuration): Repr[Seq[Out]]
        Chunk up this stream into groups of elements received within a time window, or limited by the given number of elements, whatever happens first.
    def idleTimeout(timeout: FiniteDuration): Repr[Out]
        If the time between two processed elements exceeds the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def initialDelay(delay: FiniteDuration): Repr[Out]
        Delays the initial element by the specified duration.
    def initialTimeout(timeout: FiniteDuration): Repr[Out]
        If the first element has not passed through this stage before the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def interleave[U >: Out](that: Graph[SourceShape[U], _], segmentSize: Int, eagerClose: Boolean): Repr[U]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleave[U >: Out](that: Graph[SourceShape[U], _], segmentSize: Int): Repr[U]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleaveMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2], request: Int, eagerClose: Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleaveMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2], request: Int)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def intersperse[T >: Out](inject: T): Repr[T]
        Intersperses stream with provided element, similar to how scala.collection.immutable.List.mkString injects a separator between a List elements.
    def intersperse[T >: Out](start: T, inject: T, end: T): Repr[T]
        Intersperses stream with provided element, similar to how scala.collection.immutable.List.mkString injects a separator between a List elements.
    def join[I2, O2, Mat2](bidi: Graph[BidiShape[Out, O2, I2, In], Mat2]): Flow[I2, O2, Mat]
        Join this Flow to a BidiFlow to close off the “top” of the protocol stack:
        +---------------------------+
        | Resulting Flow            |
        |                           |
        | +------+        +------+  |
        | |      | ~Out~> |      | ~~> O2
        | | flow |        | bidi |  |
        | |      | <~In~  |      | <~~ I2
        | +------+        +------+  |
        +---------------------------+
        The materialized value of the combined Flow will be the materialized value of the current flow (ignoring the BidiFlow’s value), use joinMat if a different strategy is needed.
    def join[Mat2](flow: Graph[FlowShape[Out, In], Mat2]): RunnableGraph[Mat]
        Join this Flow to another Flow, by cross connecting the inputs and outputs, creating a RunnableGraph.
        +------+        +-------+
        |      | ~Out~> |       |
        | this |        | other |
        |      | <~In~  |       |
        +------+        +-------+
        The materialized value of the combined Flow will be the materialized value of the current flow (ignoring the other Flow’s value), use joinMat if a different strategy is needed.
    def joinMat[I2, O2, Mat2, M](bidi: Graph[BidiShape[Out, O2, I2, In], Mat2])(combine: (Mat, Mat2) ⇒ M): Flow[I2, O2, M]
        Join this Flow to a BidiFlow to close off the “top” of the protocol stack:
        +---------------------------+
        | Resulting Flow            |
        |                           |
        | +------+        +------+  |
        | |      | ~Out~> |      | ~~> O2
        | | flow |        | bidi |  |
        | |      | <~In~  |      | <~~ I2
        | +------+        +------+  |
        +---------------------------+
        The combine function is used to compose the materialized values of this flow and that BidiFlow into the materialized value of the resulting Flow.
        It is recommended to use the internally optimized Keep.left and Keep.right combiners where appropriate instead of manually writing functions that pass through one of the values.
    def joinMat[Mat2, Mat3](flow: Graph[FlowShape[Out, In], Mat2])(combine: (Mat, Mat2) ⇒ Mat3): RunnableGraph[Mat3]
        Join this Flow to another Flow, by cross connecting the inputs and outputs, creating a RunnableGraph
        +------+        +-------+
        |      | ~Out~> |       |
        | this |        | other |
        |      | <~In~  |       |
        +------+        +-------+
        The combine function is used to compose the materialized values of this flow and that Flow into the materialized value of the resulting Flow.
        It is recommended to use the internally optimized Keep.left and Keep.right combiners where appropriate instead of manually writing functions that pass through one of the values.
    def keepAlive[U >: Out](maxIdle: FiniteDuration, injectedElem: () ⇒ U): Repr[U]
        Injects additional elements if upstream does not emit for a configured amount of time.
    def limit(max: Long): Repr[Out]
        Ensure stream boundedness by limiting the number of elements from upstream.
    def limitWeighted[T](max: Long)(costFn: (Out) ⇒ Long): Repr[Out]
        Ensure stream boundedness by evaluating the cost of incoming elements using a cost function.
    def log(name: String, extract: (Out) ⇒ Any = ConstantFun.scalaIdentityFunction)(implicit log: LoggingAdapter = null): Repr[Out]
        Logs elements flowing through the stream as well as completion and erroring.
    def map[T](f: (Out) ⇒ T): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapAsync[T](parallelism: Int)(f: (Out) ⇒ Future[T]): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapAsyncUnordered[T](parallelism: Int)(f: (Out) ⇒ Future[T]): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapConcat[T](f: (Out) ⇒ Iterable[T]): Repr[T]
        Transform each input element into an Iterable of output elements that is then flattened into the output stream.
    def mapError(pf: PartialFunction[Throwable, Throwable]): Repr[Out]
        While similar to recover this stage can be used to transform an error signal to a different one *without* logging it as an error in the process.
    def mapMaterializedValue[Mat2](f: (Mat) ⇒ Mat2): ReprMat[Out, Mat2]
        Transform the materialized value of this Flow, leaving all other properties as they were.
    def merge[U >: Out, M](that: Graph[SourceShape[U], M], eagerComplete: Boolean = false): Repr[U]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking randomly when several elements ready.
    def mergeMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2], eagerComplete: Boolean = false)(matF: (Mat, Mat2) ⇒ Mat3): ReprMat[U, Mat3]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking randomly when several elements ready.
    def mergeSorted[U >: Out, M](that: Graph[SourceShape[U], M])(implicit ord: Ordering[U]): Repr[U]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking always the smallest of the available elements (waiting for one element from each side to be available).
    def mergeSortedMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) ⇒ Mat3)(implicit ord: Ordering[U]): ReprMat[U, Mat3]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking always the smallest of the available elements (waiting for one element from each side to be available).
    def monitor[Mat2]()(combine: (Mat, FlowMonitor[Out]) ⇒ Mat2): ReprMat[Out, Mat2]
        Materializes to FlowMonitor[Out] that allows monitoring of the current flow.
    def named(name: String): Repr[Out]
        Add a name attribute to this Flow.
    def orElse[U >: Out, Mat2](secondary: Graph[SourceShape[U], Mat2]): Repr[U]
        Provides a secondary source that will be consumed if this stream completes without any elements passing by.
    def orElseMat[U >: Out, Mat2, Mat3](secondary: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) ⇒ Mat3): ReprMat[U, Mat3]
        Provides a secondary source that will be consumed if this stream completes without any elements passing by.
    def prefixAndTail[U >: Out](n: Int): Repr[(Seq[Out], Source[U, NotUsed])]
        Takes up to n elements from the stream (less than n only if the upstream completes before emitting n elements) and returns a pair containing a strict sequence of the taken element and a stream representing the remaining elements.
    def prepend[U >: Out, Mat2](that: Graph[SourceShape[U], Mat2]): Repr[U]
        Prepend the given Source to this Flow, meaning that before elements are generated from this Flow, the Source's elements will be produced until it is exhausted, at which point Flow elements will start being produced.
    def prependMat[U >: Out, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) ⇒ Mat3): ReprMat[U, Mat3]
        Prepend the given Source to this Flow, meaning that before elements are generated from this Flow, the Source's elements will be produced until it is exhausted, at which point Flow elements will start being produced.
    def recover[T >: Out](pf: PartialFunction[Throwable, T]): Repr[T]
        Recover allows to send last element on failure and gracefully complete the stream Since the underlying failure signal onError arrives out-of-band, it might jump over existing elements.
    def recoverWithRetries[T >: Out](attempts: Int, pf: PartialFunction[Throwable, Graph[SourceShape[T], NotUsed]]): Repr[T]
        RecoverWithRetries allows to switch to alternative Source on flow failure.
    def reduce[T >: Out](f: (T, T) ⇒ T): Repr[T]
        Similar to fold but uses first element as zero element.
    def runWith[Mat1, Mat2](source: Graph[SourceShape[In], Mat1], sink: Graph[SinkShape[Out], Mat2])(implicit materializer: Materializer): (Mat1, Mat2)
        Connect the Source to this Flow and then connect it to the Sink and run it.
    def scan[T](zero: T)(f: (T, Out) ⇒ T): Repr[T]
        Similar to fold but is not a terminal operation, emits its current value which starts at zero and then applies the current and next value to the given function f, emitting the next current value.
    def scanAsync[T](zero: T)(f: (T, Out) ⇒ Future[T]): Repr[T]
        Similar to scan but with a asynchronous function, emits its current value which starts at zero and then applies the current and next value to the given function f, emitting a Future that resolves to the next current value.
    val shape: FlowShape[In, Out]
    def sliding(n: Int, step: Int = 1): Repr[Seq[Out]]
        Apply a sliding window over the stream and return the windows as groups of elements, with the last group possibly smaller than requested due to end-of-stream.
    def splitAfter(p: (Out) ⇒ Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams.
    def splitAfter(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) ⇒ Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams.
    def splitWhen(p: (Out) ⇒ Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams, always beginning a new one with the current element if the given predicate returns true for it.
    def splitWhen(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) ⇒ Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams, always beginning a new one with the current element if the given predicate returns true for it.
    def statefulMapConcat[T](f: () ⇒ (Out) ⇒ Iterable[T]): Repr[T]
        Transform each input element into an Iterable of output elements that is then flattened into the output stream.
    def take(n: Long): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after the given number of elements.
    def takeWhile(p: (Out) ⇒ Boolean, inclusive: Boolean): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after predicate returns false for the first time, including the first failed element iff inclusive is true Due to input buffering some elements may have been requested from upstream publishers that will then not be processed downstream of this step.
    def takeWhile(p: (Out) ⇒ Boolean): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after predicate returns false for the first time, Due to input buffering some elements may have been requested from upstream publishers that will then not be processed downstream of this step.
    def takeWithin(d: FiniteDuration): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after the given duration.
    def throttle(cost: Int, per: FiniteDuration, maximumBurst: Int, costCalculation: (Out) ⇒ Int, mode: ThrottleMode): Repr[Out]
        Sends elements downstream with speed limited to cost/per.
    def throttle(elements: Int, per: FiniteDuration, maximumBurst: Int, mode: ThrottleMode): Repr[Out]
        Sends elements downstream with speed limited to elements/per.
    def throttleEven(cost: Int, per: FiniteDuration, costCalculation: (Out) ⇒ Int, mode: ThrottleMode): Repr[Out]
        This is a simplified version of throttle that spreads events evenly across the given time interval.
    def throttleEven(elements: Int, per: FiniteDuration, mode: ThrottleMode): Repr[Out]
        This is a simplified version of throttle that spreads events evenly across the given time interval.
    def to[Mat2](sink: Graph[SinkShape[Out], Mat2]): Sink[In, Mat]
        Connect this Flow to a Sink, concatenating the processing steps of both.
            +------------------------------+
            | Resulting Sink[In, Mat]      |
            |                              |
            |  +------+          +------+  |
            |  |      |          |      |  |
        In ~~> | flow | ~~Out~~> | sink |  |
            |  |   Mat|          |     M|  |
            |  +------+          +------+  |
            +------------------------------+
        The materialized value of the combined Sink will be the materialized value of the current flow (ignoring the given Sink’s value), use toMat if a different strategy is needed.
        See also toMat when access to materialized values of the parameter is needed.
        Definition Classes
            Flow → FlowOps
    def toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) ⇒ Mat3): Sink[In, Mat3]
        Connect this Flow to a Sink, concatenating the processing steps of both.
            +----------------------------+
            | Resulting Sink[In, M2]     |
            |                            |
            |  +------+        +------+  |
            |  |      |        |      |  |
        In ~~> | flow | ~Out~> | sink |  |
            |  |   Mat|        |     M|  |
            |  +------+        +------+  |
            +----------------------------+
        The combine function is used to compose the materialized values of this flow and that Sink into the materialized value of the resulting Sink.
        It is recommended to use the internally optimized Keep.left and Keep.right combiners where appropriate instead of manually writing functions that pass through one of the values.
        Definition Classes
            Flow → FlowOpsMat
    def toProcessor: RunnableGraph[Processor[In, Out]]
        Converts this Flow to a RunnableGraph that materializes to a Reactive Streams org.reactivestreams.Processor which implements the operations encapsulated by this Flow.
    def toString(): String
    val traversalBuilder: LinearTraversalBuilder
    def via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Repr[T]
        Transform this Flow by appending the given processing steps.
            +---------------------------------+
            | Resulting Flow[In, T, Mat]  |
            |                                 |
            |  +------+             +------+  |
            |  |      |             |      |  |
        In ~~> | this |  ~~Out~~>   | flow | ~~> T
            |  |   Mat|             |     M|  |
            |  +------+             +------+  |
            +---------------------------------+
        The materialized value of the combined Flow will be the materialized value of the current flow (ignoring the other Flow’s value), use viaMat if a different strategy is needed.
        See also FlowOpsMat.viaMat when access to materialized values of the parameter is needed.
        Definition Classes
            Flow → FlowOps
    def viaMat[T, Mat2, Mat3](flow: Graph[FlowShape[Out, T], Mat2])(combine: (Mat, Mat2) ⇒ Mat3): Flow[In, T, Mat3]
        Transform this Flow by appending the given processing steps.
            +---------------------------------+
            | Resulting Flow[In, T, M2]       |
            |                                 |
            |  +------+            +------+   |
            |  |      |            |      |   |
        In ~~> | this |  ~~Out~~>  | flow |  ~~> T
            |  |   Mat|            |     M|   |
            |  +------+            +------+   |
            +---------------------------------+
        The combine function is used to compose the materialized values of this flow and that flow into the materialized value of the resulting Flow.
        It is recommended to use the internally optimized Keep.left and Keep.right combiners where appropriate instead of manually writing functions that pass through one of the values.
        Definition Classes
            Flow → FlowOpsMat
    def watch(ref: ActorRef): Repr[Out]
        The stage fails with an akka.stream.WatchedActorTerminatedException if the target actor is terminated.
    def watchTermination[Mat2]()(matF: (Mat, Future[Done]) => Mat2): ReprMat[Out, Mat2]
        Materializes to Future[Done] that completes on getting termination message.
    def wireTap(that: Graph[SinkShape[Out], _]): Repr[Out]
        Attaches the given Sink to this Flow as a wire tap, meaning that elements that pass through will also be sent to the wire-tap Sink, without the latter affecting the mainline flow.
    def wireTapMat[Mat2, Mat3](that: Graph[SinkShape[Out], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
        Attaches the given Sink to this Flow as a wire tap, meaning that elements that pass through will also be sent to the wire-tap Sink, without the latter affecting the mainline flow.
    def withAttributes(attr: Attributes): Repr[Out]
        Replace the attributes of this Flow with the given ones.
    def zip[U](that: Graph[SourceShape[U], _]): Repr[(Out, U)]
        Combine the elements of current flow and the given Source into a stream of tuples.
    def zipMat[U, Mat2, Mat3](that: Graph[SourceShape[U], Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[(Out, U), Mat3]
        Combine the elements of current flow and the given Source into a stream of tuples.
    def zipWith[Out2, Out3](that: Graph[SourceShape[Out2], _])(combine: (Out, Out2) => Out3): Repr[Out3]
        Put together the elements of current flow and the given Source into a stream of combined elements using a combiner function.
    def zipWithIndex: Repr[(Out, Long)]
        Combine the elements of current flow into a stream of tuples consisting of all elements paired with their index.
    def zipWithMat[Out2, Out3, Mat2, Mat3](that: Graph[SourceShape[Out2], Mat2])(combine: (Out, Out2) => Out3)(matF: (Mat, Mat2) => Mat3): ReprMat[Out3, Mat3]
        Put together the elements of current flow and the given Source into a stream of combined elements using a combiner function.

object Flow	
    def apply[T]: Flow[T, T, NotUsed]
        Returns a Flow which outputs all its inputs.
    def fromFunction[A, B](f: (A) => B): Flow[A, B, NotUsed]
        Creates a [Flow] which will use the given function to transform its inputs to outputs.
    def fromGraph[I, O, M](g: Graph[FlowShape[I, O], M]): Flow[I, O, M]
        A graph with the shape of a flow logically is a flow, this method makes it so also in type.
    def fromProcessor[I, O](processorFactory: () => Processor[I, O]): Flow[I, O, NotUsed]
        Creates a Flow from a Reactive Streams org.reactivestreams.Processor
    def fromSinkAndSource[I, O](sink: Graph[SinkShape[I], _], source: Graph[SourceShape[O], _]): Flow[I, O, NotUsed]
        Creates a Flow from a Sink and a Source where the Flow's input will be sent to the Sink and the Flow's output will come from the Source.
        The resulting flow can be visualized as:
            +----------------------------------------------+
            | Resulting Flow[I, O, NotUsed]                |
            |                                              |
            |  +---------+                  +-----------+  |
            |  |         |                  |           |  |
        I  ~~> | Sink[I] | [no-connection!] | Source[O] | ~~> O
            |  |         |                  |           |  |
            |  +---------+                  +-----------+  |
            +----------------------------------------------+
        The completion of the Sink and Source sides of a Flow constructed using this method are independent. So if the Sink receives a completion signal, the Source side will remain unaware of that. If you are looking to couple the termination signals of the two sides use Flow.fromSinkAndSourceCoupled instead.
        See also fromSinkAndSourceMat when access to materialized values of the parameters is needed.
    def fromSinkAndSourceCoupled[I, O](sink: Graph[SinkShape[I], _], source: Graph[SourceShape[O], _]): Flow[I, O, NotUsed]
        Allows coupling termination (cancellation, completion, erroring) of Sinks and Sources while creating a Flow from them. Similar to Flow.fromSinkAndSource however couples the termination of these two stages.
        The resulting flow can be visualized as:
            +---------------------------------------------+
            | Resulting Flow[I, O, NotUsed]               |
            |                                             |
            |  +---------+                 +-----------+  |
            |  |         |                 |           |  |
        I  ~~> | Sink[I] | ~~~(coupled)~~~ | Source[O] | ~~> O
            |  |         |                 |           |  |
            |  +---------+                 +-----------+  |
            +---------------------------------------------+
        E.g. if the emitted Flow gets a cancellation, the Source of course is cancelled, however the Sink will also be completed. The table below illustrates the effects in detail:
        Returned Flow 	Sink (in) 	Source (out)
        cause: upstream (sink-side) receives completion 	effect: receives completion 	effect: receives cancel
        cause: upstream (sink-side) receives error 	effect: receives error 	effect: receives cancel
        cause: downstream (source-side) receives cancel 	effect: completes 	effect: receives cancel
        effect: cancels upstream, completes downstream 	effect: completes 	cause: signals complete
        effect: cancels upstream, errors downstream 	effect: receives error 	cause: signals error or throws
        effect: cancels upstream, completes downstream 	cause: cancels 	effect: receives cancel
        See also fromSinkAndSourceCoupledMat when access to materialized values of the parameters is needed.
    def fromSinkAndSourceCoupledMat[I, O, M1, M2, M](sink: Graph[SinkShape[I], M1], source: Graph[SourceShape[O], M2])(combine: (M1, M2) ⇒ M): Flow[I, O, M]
        Allows coupling termination (cancellation, completion, erroring) of Sinks and Sources while creating a Flow from them. Similar to Flow.fromSinkAndSource however couples the termination of these two stages.
        The resulting flow can be visualized as:
            +-----------------------------------------------------+
            | Resulting Flow[I, O, M]                             |
            |                                                     |
            |  +-------------+                 +---------------+  |
            |  |             |                 |               |  |
        I  ~~> | Sink[I, M1] | ~~~(coupled)~~~ | Source[O, M2] | ~~> O
            |  |             |                 |               |  |
            |  +-------------+                 +---------------+  |
            +-----------------------------------------------------+
        E.g. if the emitted Flow gets a cancellation, the Source of course is cancelled, however the Sink will also be completed. The table on Flow.fromSinkAndSourceCoupled illustrates the effects in detail.
        The combine function is used to compose the materialized values of the sink and source into the materialized value of the resulting Flow.
    def fromSinkAndSourceMat[I, O, M1, M2, M](sink: Graph[SinkShape[I], M1], source: Graph[SourceShape[O], M2])(combine: (M1, M2) ⇒ M): Flow[I, O, M]
        Creates a Flow from a Sink and a Source where the Flow's input will be sent to the Sink and the Flow's output will come from the Source.
        The resulting flow can be visualized as:
            +-------------------------------------------------------+
            | Resulting Flow[I, O, M]                              |
            |                                                      |
            |  +-------------+                  +---------------+  |
            |  |             |                  |               |  |
        I  ~~> | Sink[I, M1] | [no-connection!] | Source[O, M2] | ~~> O
            |  |             |                  |               |  |
            |  +-------------+                  +---------------+  |
            +------------------------------------------------------+
        The completion of the Sink and Source sides of a Flow constructed using this method are independent. So if the Sink receives a completion signal, the Source side will remain unaware of that. If you are looking to couple the termination signals of the two sides use Flow.fromSinkAndSourceCoupledMat instead.
        The combine function is used to compose the materialized values of the sink and source into the materialized value of the resulting Flow.
    def lazyInit[I, O, M](flowFactory: (I) => Future[Flow[I, O, M]], fallback: () => M): Flow[I, O, M]
        Creates a real Flow upon receiving the first element.





///*** Akka Streams - Source - Various methods 


import akka.stream._
import akka.stream.scaladsl._

import akka.{ NotUsed, Done }
import akka.actor.ActorSystem
import akka.util.ByteString
import scala.concurrent._
import scala.concurrent.duration._
import java.nio.file.Paths

implicit val system = ActorSystem("QuickStart")
implicit val materializer = ActorMaterializer()
    
object Main extends App {
      // Code here
      
      val source: Source[Int, NotUsed] = Source(1 to 100)
      
      //Actor gets created that runs the stream
      val done: Future[Done] = source.runForeach(i => println(i))(materializer)
      
      //To terminate Source system, ie the ActorSystem is  terminated
      implicit val ec = system.dispatcher
      done.onComplete(_ => system.terminate())
    }


 
//Another examples of using various methods of Source 
import akka.NotUsed
import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import akka.stream.scaladsl._

implicit val system = ActorSystem("reactive-tweets")
implicit val materializer = ActorMaterializer()

final case class Author(handle: String)

final case class Hashtag(name: String)

final case class Tweet(author: Author, timestamp: Long, body: String) {
  def hashtags: Set[Hashtag] = body.split(" ").collect {
    case t if t.startsWith("#") => Hashtag(t.replaceAll("[^#\\w]", ""))
  }.toSet
}

val akkaTag = Hashtag("#akka")

val tweets: Source[Tweet, NotUsed] = Source(
    Tweet(Author("rolandkuhn"), System.currentTimeMillis, "#akka rocks!") ::
    Tweet(Author("patriknw"), System.currentTimeMillis, "#akka !") ::
    Tweet(Author("bantonsson"), System.currentTimeMillis, "#akka !") ::
    Tweet(Author("drewhk"), System.currentTimeMillis, "#akka !") ::
    Tweet(Author("ktosopl"), System.currentTimeMillis, "#akka on the rocks!") ::
    Tweet(Author("mmartynas"), System.currentTimeMillis, "wow #akka !") ::
    Tweet(Author("akkateam"), System.currentTimeMillis, "#akka rocks!") ::
    Tweet(Author("bananaman"), System.currentTimeMillis, "#bananas rock!") ::
    Tweet(Author("appleman"), System.currentTimeMillis, "#apples rock!") ::
    Tweet(Author("drama"), System.currentTimeMillis, "we compared #apples to #oranges!") ::
    Nil)



//runWith() is a convenience method that automatically ignores the materialized value of any other stages 
//except those appended by the runWith() itself. 
//in below example it translates to using Keep.right as the combiner for materialized values.
//Source[+Out, +Mat].runWith[Mat2](sink: Graph[SinkShape[Out], Mat2])(implicit materializer: Materializer): Mat2
//Connect this Source to a Sink and run it.
tweets
.map(_.hashtags) // Get all sets of hashtags ...
.reduce(_ ++ _) // ... and reduce them to a single set, removing duplicates across all tweets
//identity , Nothing => Nothing
.mapConcat(identity) // Flatten the stream of tweets to a stream of hashtags, similar to flatMap, but for Streams 
.map(_.name.toUpperCase) // Convert all hashtags to upper case
.runWith(Sink.foreach(println)) // Attach the Flow to a Sink that will finally print the hashtags

val authors: Source[Author, NotUsed] =
  tweets
    .filter(_.hashtags.contains(akkaTag))
    .map(_.author)

authors.runWith(Sink.foreach(println))

///Flattening sequences in streams
//Source[+Out, +Mat].flatMapConcat[T, M](f: (Out) ⇒ Graph[SourceShape[T], M]): Source[T,Mat]
//Similar to  flatMap, Transform each input element into a Source of output elements that is then flattened into the output stream 
//by concatenation, fully consuming one Source after the other.
val hashtags: Source[Hashtag, NotUsed] = tweets.mapConcat(_.hashtags.toList)  //List,Seq etc Implicitely converted to Source 






///Back-pressure in action
//Akka Streams always propagates back-pressure information from stream Sinks (Subscribers) to their Sources (Publishers). 
//It is not an optional feature, and is enabled at all times

//With Akka Streams buffering can and must be handled explicitly
//Source[+Out, +Mat].buffer(size: Int, overflowStrategy: OverflowStrategy): Source[Out,Mat]
//Adds a fixed size buffer in the flow that allows to store elements from a faster upstream until it becomes full.
tweets
  .buffer(10, OverflowStrategy.dropHead)
  .map(slowComputation)
  .runWith(Sink.ignore)
  
//Reference 
object OverflowStrategy extends Serializable 
    def backpressure: OverflowStrategy
        If the buffer is full when a new element is available this strategy backpressures the upstream publisher until space becomes available in the buffer.
    def dropBuffer: OverflowStrategy
        If the buffer is full when a new element arrives, drops all the buffered elements to make space for the new element.
    def dropHead: OverflowStrategy
        If the buffer is full when a new element arrives, drops the oldest element from the buffer to make space for the new element.
    def dropNew: OverflowStrategy
        If the buffer is full when a new element arrives, drops the new element.
    def dropTail: OverflowStrategy
        If the buffer is full when a new element arrives, drops the youngest element from the buffer to make space for the new element.
    def fail: OverflowStrategy
        If the buffer is full when a new element is available this strategy completes the stream with failure.


        
///Materialized values
//Source[+Out, +Mat], Flow[-In, +Out, +Mat] and Sink[-In, +Mat]
//When you chain these together, you can explicitly combine their materialized values by toMat 

//Source[+Out, +Mat].toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) ⇒ Mat3): RunnableGraph[Mat3] 
//combine = Keep.right  means we need to keep right of (Mat,Mat2) ie of Future[Int] of sumSink
//Source[+Out, +Mat].via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Source[T,Mat]

val count: Flow[Tweet, Int, NotUsed] = Flow[Tweet].map(_ => 1)
val sumSink: Sink[Int, Future[Int]] = Sink.fold[Int, Int](0)(_ + _)
val counterGraph: RunnableGraph[Future[Int]] =  //Future[Int] = from Keep.right
  tweets
    .via(count)
    .toMat(sumSink)(Keep.right)

val sum: Future[Int] = counterGraph.run()
sum.foreach(c => println(s"Total tweets processed: $c"))

//A RunnableGraph may be reused and materialized multiple times
val sumSink = Sink.fold[Int, Int](0)(_ + _)
val counterRunnableGraph: RunnableGraph[Future[Int]] =
  tweetsInMinuteFromNow
    .filter(_.hashtags contains akkaTag)
    .map(t => 1)
    .toMat(sumSink)(Keep.right)

// materialize the stream once in the morning
val morningTweetsCount: Future[Int] = counterRunnableGraph.run()
// and once in the evening, reusing the flow
val eveningTweetsCount: Future[Int] = counterRunnableGraph.run()


///Broadcasting a stream - Using Graphs 
// Broadcast, - emits elements from its input port to all of its output ports.

//GraphDSL.create returns a Graph, in this example a Graph[ClosedShape, NotUsed] 
//where ClosedShape means that it is a fully connected graph or “closed” 
//Since it is closed it is possible to transform the graph into a RunnableGraph using RunnableGraph.fromGraph. 
//The runnable graph can then be run() to materialize a stream out of it.

//Both Graph and RunnableGraph are immutable, thread-safe, and freely shareable.
val writeAuthors: Sink[Author, NotUsed] = Sink.foreach(println)
val writeHashtags: Sink[Hashtag, NotUsed] = Sink.foreach(println)
val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder =>
  import GraphDSL.Implicits._

  val bcast = builder.add(Broadcast[Tweet](2))
  tweets ~> bcast.in
  bcast.out(0) ~> Flow[Tweet].map(_.author) ~> writeAuthors
  bcast.out(1) ~> Flow[Tweet].mapConcat(_.hashtags.toList) ~> writeHashtags
  ClosedShape
})
g.run()



///*** Akka Streams - Flow - RunnableGraph
//A RunnableGraph Flow that has both ends “attached” to a Source and Sink respectively, and is ready to be run().

//akka Streams do not allow null to be passed through the stream as an element. 
//Use scala.Option or scala.util.Either .


//It is possible to attach a Flow to a Source resulting in a composite source, 
//and it is also possible to prepend a Flow to a Sink to get a new sink. 

//After a stream is properly terminated by having both a source and a sink, 
//it will be represented by the RunnableGraph type, indicating that it is ready to be executed.

//even after constructing the RunnableGraph by connecting all the source, sink and different processing stages, 
//no data will flow through it until it is materialized. 

//Materialization is the process of allocating all resources needed to run the computation described 
//by a Graph (in Akka Streams this will often involve starting up Actors, resulting in Future). 

//Materialization is triggered at  “terminal operations”. 
//ie  run() and runWith() methods defined on Source and Flow and  runForeach(el => ...) (being an alias to runWith(Sink.foreach(el => ...))).

//Materialization is currently performed synchronously on the materializing thread. 
//The actual stream processing is handled by actors started up during the streams materialization, 
//which will be running on the thread pools they have been configured to run on - 
//which defaults to the dispatcher set in MaterializationSettings while constructing the ActorMaterializer.


//Flows are immutable, thread-safe, and freely shareable, 
//for example safe to share and send them between actors, to have one actor prepare the work, 
//and then have it be materialized at some completely different place in the code.

val source = Source(1 to 10)
val sink = Sink.fold[Int, Int](0)(_ + _)

// connect the Source to the Sink, obtaining a RunnableGraph
val runnable: RunnableGraph[Future[Int]] = source.toMat(sink)(Keep.right)

// materialize the flow and get the value of the FoldSink
val sum: Future[Int] = runnable.run()
    
//OR , materialize the flow, getting the Sinks materialized value
val sum: Future[Int] = source.runWith(sink)

//processing stages are immutable, 
val source = Source(1 to 10)
source.map(_ => 0) // has no effect on source, since it's immutable
source.runWith(Sink.fold(0)(_ + _)) // 55

val zeroes = source.map(_ => 0) // returns new Source[Int], with `map()` appended
zeroes.runWith(Sink.fold(0)(_ + _)) // 0

//Since a stream can be materialized multiple times, 
//the materialized value will also be calculated anew for each such materialization, 

// connect the Source to the Sink, obtaining a RunnableGraph
val sink = Sink.fold[Int, Int](0)(_ + _)
val runnable: RunnableGraph[Future[Int]] = Source(1 to 10).toMat(sink)(Keep.right)

// get the materialized value of the FoldSink
val sum1: Future[Int] = runnable.run()
val sum2: Future[Int] = runnable.run()

// sum1 and sum2 are different Futures!

///Defining sources, sinks and flows
// Create a source from an Iterable
Source(List(1, 2, 3))

// Create a source from a Future
Source.fromFuture(Future.successful("Hello Streams!"))

// Create a source from a single element
Source.single("only one element")

// an empty source
Source.empty

// Sink that folds over the stream and returns a Future
// of the final result as its materialized value
Sink.fold[Int, Int](0)(_ + _)

// Sink that returns a Future as its materialized value,
// containing the first element of the stream
Sink.head

// A Sink that consumes a stream without doing anything with the elements
Sink.ignore

// A Sink that executes a side-effecting call for every element of the stream
Sink.foreach[String](println(_))


///various ways to wire up different parts of a stream

// Explicitly creating and wiring up a Source, Sink and Flow
Source(1 to 6).via(Flow[Int].map(_ * 2)).to(Sink.foreach(println(_)))

// Starting from a Source
val source = Source(1 to 6).map(_ * 2)
source.to(Sink.foreach(println(_)))

// Starting from a Sink
val sink: Sink[Int, NotUsed] = Flow[Int].map(_ * 2).to(Sink.foreach(println(_)))
Source(1 to 6).to(sink)

// Broadcast to a sink inline
val otherSink: Sink[Int, NotUsed] =
  Flow[Int].alsoTo(Sink.foreach(println(_))).to(Sink.ignore)
Source(1 to 6).to(otherSink)



///* Operator Fusion
//By default Akka Streams will fuse the stream operators. Means 
1.passing elements from one processing stage to the next is a lot faster between fused stages 
  due to avoiding the asynchronous messaging overhead
2.fused stream processing stages does not run in parallel to each other, 
  meaning that only up to one CPU core is used for each fused part

//To allow for parallel processing , insert asynchronous boundaries explicitly
//(by Attributes.asyncBoundary using the method async on Source, Sink and Flow)

//This async can be applied successively, always having one such boundary enclose the previous ones 
//plus all processing stages that have been added since them

Source(List(1, 2, 3))
  .map(_ + 1).async  //-> by 1st Actor 
  .map(_ * 2)        // 2nd actor takes up 
  .to(Sink.ignore)


///Combining materialized values
//Since every processing stage in Akka Streams can provide a materialized value after being materialized, 
//Below methods of Source, Sink, Flow take combine: arg how these values should be composed to a final value when we plug these stages together. 
toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]
viaMat[T, Mat2, Mat3](flow: Graph[FlowShape[Out, T], Mat2])(combine: (Mat, Mat2) => Mat3): Source[T, Mat3]
zipWithMat[Out2, Out3, Mat2, Mat3](that: Graph[SourceShape[Out2], Mat2])(combine: (Out, Out2) => Out3)(matF: (Mat, Mat2) => Mat3): ReprMat[Out3, Mat3]
joinMat[I2, O2, Mat2, M](bidi: Graph[BidiShape[Out, O2, I2, In], Mat2])(combine: (Mat, Mat2) => M): Flow[I2, O2, M]
joinMat[Mat2, Mat3](flow: Graph[FlowShape[Out, In], Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]

object Keep 
    def both[L, R]: (L, R) ⇒ (L, R)
    def left[L, R]: (L, R) ⇒ L
    def none[L, R]: (L, R) ⇒ NotUsed
    def right[L, R]: (L, R) ⇒ R 

//Example 

// An source that can be signalled explicitly from the outside
val source: Source[Int, Promise[Option[Int]]] = Source.maybe[Int]

// A flow that internally throttles elements to 1/second, and returns a Cancellable
// which can be used to shut down the stream
val flow: Flow[Int, Int, Cancellable] = throttler

// A sink that returns the first element of a stream in the returned Future
val sink: Sink[Int, Future[Int]] = Sink.head[Int]

// By default, the materialized value of the leftmost stage is preserved
val r1: RunnableGraph[Promise[Option[Int]]] = source.via(flow).to(sink)

// Simple selection of materialized values by using Keep.right
val r2: RunnableGraph[Cancellable] = source.viaMat(flow)(Keep.right).to(sink)
val r3: RunnableGraph[Future[Int]] = source.via(flow).toMat(sink)(Keep.right)

// Using runWith will always give the materialized values of the stages added
// by runWith() itself
val r4: Future[Int] = source.via(flow).runWith(sink)
val r5: Promise[Option[Int]] = flow.to(sink).runWith(source)
val r6: (Promise[Option[Int]], Future[Int]) = flow.runWith(source, sink)

// Using more complex combinations
val r7: RunnableGraph[(Promise[Option[Int]], Cancellable)] =
  source.viaMat(flow)(Keep.both).to(sink)

val r8: RunnableGraph[(Promise[Option[Int]], Future[Int])] =
  source.via(flow).toMat(sink)(Keep.both)

val r9: RunnableGraph[((Promise[Option[Int]], Cancellable), Future[Int])] =
  source.viaMat(flow)(Keep.both).toMat(sink)(Keep.both)

val r10: RunnableGraph[(Cancellable, Future[Int])] =
  source.viaMat(flow)(Keep.right).toMat(sink)(Keep.both)

// It is also possible to map over the materialized values. In r9 we had a
// doubly nested pair, but we want to flatten it out
val r11: RunnableGraph[(Promise[Option[Int]], Cancellable, Future[Int])] =
  r9.mapMaterializedValue {
    case ((promise, cancellable), future) =>
      (promise, cancellable, future)
  }

// Now we can use pattern matching to get the resulting materialized values
val (promise, cancellable, future) = r11.run()

// Type inference works as expected
promise.success(None)
cancellable.cancel()
future.map(_ + 3)

// The result of r11 can be also achieved by using the Graph API
val r12: RunnableGraph[(Promise[Option[Int]], Cancellable, Future[Int])] =
  RunnableGraph.fromGraph(GraphDSL.create(source, flow, sink)((_, _, _)) { implicit builder => (src, f, dst) =>
    import GraphDSL.Implicits._
    src ~> f ~> dst
    ClosedShape
  })
  
  

///Source pre-materialization
//To have  a Source materialized value before the Source gets hooked up to the rest of the graph. 
//This is particularly useful in the case of “materialized value powered” Sources, 
//like Source.queue, Source.actorRef or Source.maybe.

Source[+Out,+Mat].preMaterialize()(implicit materializer: Materializer): (Mat, ReprMat[Out, NotUsed])
    Obtain its materialized value and another Source. 
    The latter can be used to consume messages from the original Source. 
    Note that this can be materialized multiple times.

//Example 

val matValuePoweredSource = Source.actorRef[String](bufferSize = 100, overflowStrategy = OverflowStrategy.fail)
val (actorRef, source) = matValuePoweredSource.preMaterialize()
actorRef ! "Hello!"
// pass source around for materialization
source.runWith(Sink.foreach(println))



///Stream ordering
//In Akka Streams almost all computation stages preserve input order of elements. 

//if inputs {IA1,IA2,...,IAn} “cause” outputs {OA1,OA2,...,OAk} 
//and inputs {IB1,IB2,...,IBm} “cause” outputs {OB1,OB2,...,OBl} 
//and all of IAi happened before all IBi then OAi happens before OBi.

//This property is even uphold by async operations such as mapAsync, 
//however an unordered version exists called mapAsyncUnordered which does not preserve this ordering.

//in the case of Junctions which handle multiple input streams (e.g. Merge) 
//the output order is, in general, not defined for elements arriving on different input ports. 
//OR use MergePreferred, MergePrioritized or GraphStage





///ActorMaterializer Lifecycle
//The materializer is bound to the lifecycle of the ActorRefFactory it is created from, 
//which in practice will be either an ActorSystem or ActorContext 
//(when the materializer is created within an Actor).


//When the materializer is shut down(mat.shutdown()) before the streams have run to completion, they will be terminated abruptly
implicit val system = ActorSystem("ExampleSystem")
implicit val mat = ActorMaterializer() // created from `system`

//Use KillSwitch for systematic shutdown 

//def delay(of: FiniteDuration, strategy: DelayOverflowStrategy = DelayOverflowStrategy.dropTail): Repr[Out]
val countingSrc = Source(Stream.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int]

val (killSwitch, last) = countingSrc
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(lastSnk)(Keep.both)
  .run()

doSomethingElse()

killSwitch.shutdown()

Await.result(last, 1.second) shouldBe 2

//Reference 
trait KillSwitch extends AnyRef
	A KillSwitch allows completion of Graphs from the outside by completing Graphs of FlowShape linked to the switch. Depending on whether the KillSwitch is a UniqueKillSwitch or a SharedKillSwitch one or multiple streams might be linked with the switch. For details see the documentation of the concrete subclasses of this interface.
    abstract def abort(ex: Throwable): Unit
        After calling KillSwitch#abort() the linked Graphs of FlowShape are failed.
    abstract def shutdown(): Unit
        After calling KillSwitch#shutdown() the linked Graphs of FlowShape are completed normally.
object KillSwitches
	Creates shared or single kill switches which can be used to control completion of graphs from the outside.
    def shared(name: String): SharedKillSwitch
        Creates a new SharedKillSwitch with the given name that can be used to control the completion of multiple streams from the outside simultaneously.
    def single[T]: Graph[FlowShape[T, T], UniqueKillSwitch]
        Creates a new Graph of FlowShape that materializes to an external switch that allows external completion of that unique materialization.
    def singleBidi[T1, T2]: Graph[BidiShape[T1, T1, T2, T2], UniqueKillSwitch]
        Creates a new Graph of FlowShape that materializes to an external switch that allows external completion of that unique materialization.
object DelayOverflowStrategy extends Serializable
	Represents a strategy that decides how to deal with a buffer of time based stage that is full but is about to receive a new element. 
    def backpressure: DelayOverflowStrategy
        If the buffer is full when a new element is available this strategy backpressures the upstream publisher until space becomes available in the buffer.
    def dropBuffer: DelayOverflowStrategy
        If the buffer is full when a new element arrives, drops all the buffered elements to make space for the new element.
    def dropHead: DelayOverflowStrategy
        If the buffer is full when a new element arrives, drops the oldest element from the buffer to make space for the new element.
    def dropNew: DelayOverflowStrategy
        If the buffer is full when a new element arrives, drops the new element.
    def dropTail: DelayOverflowStrategy
        If the buffer is full when a new element arrives, drops the youngest element from the buffer to make space for the new element.
    def emitEarly: DelayOverflowStrategy
        If the buffer is full when a new element is available this strategy send next element downstream without waiting
    def fail: DelayOverflowStrategy
        If the buffer is full when a new element is available this strategy completes the stream with failure.





//Incase of ActorMaterializer created within an Actor
//if we stop the Actor it would terminate the stream as well.
//We have bound the streams’ lifecycle to the surrounding actor’s lifecycle.
final class RunWithMyself extends Actor {
  implicit val mat = ActorMaterializer()

  Source.maybe
    .runWith(Sink.onComplete {
      case Success(done) => println(s"Completed: $done")
      case Failure(ex)   => println(s"Failed: ${ex.getMessage}")
    })

  def receive = {
    case "boom" =>
      context.stop(self) // will also terminate the stream
  }
}
//If ActorMaterializer is not created inside Actor, then there is no bound 
//streams would outlast life of Actor 
final class RunForever(implicit val mat: Materializer) extends Actor {

  Source.maybe
    .runWith(Sink.onComplete {
      case Success(done) => println(s"Completed: $done")
      case Failure(ex)   => println(s"Failed: ${ex.getMessage}")
    })

  def receive = {
    case "boom" =>
      context.stop(self) // will NOT terminate the stream (it's bound to the system!)
  }
}

///*** AkkaStream - Graphs 
///Reference 
trait akka.stream.Graph[+S <: Shape, +M] extends AnyRef
    //Subclasses 
    BidiFlow, Flow, RunnableGraph, Sink, Source, Balance, BidiFlow, Broadcast, Concat, 
    Flow, Interleave, Merge, MergePreferred, MergePrioritized, MergeSorted, Partition, 
    RunnableGraph, Sink, Source, Unzip, UnzipWith10, UnzipWith11, UnzipWith12, 
    UnzipWith13, UnzipWith14, UnzipWith15, UnzipWith16, UnzipWith17, UnzipWith18, 
    UnzipWith19, UnzipWith2, UnzipWith20, UnzipWith3, UnzipWith4, UnzipWith5, UnzipWith6, 
    UnzipWith7, UnzipWith8, UnzipWith9, Zip, ZipN, ZipWith10, ZipWith11, ZipWith12, ZipWith13, 
    ZipWith14, ZipWith15, ZipWith16, ZipWith17, ZipWith18, ZipWith19, ZipWith2, ZipWith20, 
    ZipWith3, ZipWith4, ZipWith5, ZipWith6, ZipWith7, ZipWith8, ZipWith9, ZipWithN, 
    AbstractGraphStageWithMaterializedValue, GraphStage, GraphStageWithMaterializedValue
    //Type Members
    type Shape = S
        Type-level accessor for the shape parameter of this graph.
    //Abstract Value Members
    abstract def shape: S
        The shape of a graph is all that is externally visible: its inlets and outlets.
    abstract def withAttributes(attr: Attributes): Graph[S, M] 
        Concrete Value Members
    def addAttributes(attr: Attributes): Graph[S, M]
        Add the given attributes to this Graph.
    def async(dispatcher: String, inputBufferSize: Int): Graph[S, M]
        Put an asynchronous boundary around this Graph
    def async(dispatcher: String): Graph[S, M]
        Put an asynchronous boundary around this Graph
    def async: Graph[S, M]
        Put an asynchronous boundary around this Graph
    def named(name: String): Graph[S, M] 
final class Balance[T] extends GraphStage[UniformFanOutShape[T, T]]
	Fan-out the stream to several streams. Each upstream element is emitted to the first available downstream consumer. It will not shut down until the subscriptions for at least two downstream subscribers have been established.
	A Balance has one in port and 2 or more out ports.
	Emits when any of the outputs stops backpressuring; emits the element to the first available output
	Backpressures when all of the outputs backpressure
	Completes when upstream completes
	Cancels when all downstreams cancel
        new Balance(outputPorts: Int, waitForAllDownstreams: Boolean) 
        def apply[T](outputPorts: Int, waitForAllDownstreams: Boolean = false): Balance[T] 
final class Broadcast[T] extends GraphStage[UniformFanOutShape[T, T]]
	Fan-out the stream to several streams emitting each incoming upstream element to all downstream consumers. It will not shut down until the subscriptions for at least two downstream subscribers have been established.
	Emits when all of the outputs stops backpressuring and there is an input element available
	Backpressures when any of the outputs backpressure
	Completes when upstream completes
	Cancels when If eagerCancel is enabled: when any downstream cancels; otherwise: when all downstreams cancel
        new Broadcast(outputPorts: Int, eagerCancel: Boolean) 
        def apply[T](outputPorts: Int, eagerCancel: Boolean = false): Broadcast[T] 
final class Concat[T] extends GraphStage[UniformFanInShape[T, T]]
	Takes multiple streams and outputs one stream formed from the input streams by first emitting all of the elements from the first stream and then emitting all of the elements from the second stream, etc.
	A Concat has one first port, one second port and one out port.
	Emits when the current stream has an element available; if the current input completes, it tries the next one
	Backpressures when downstream backpressures
	Completes when all upstreams complete
	Cancels when downstream cancels
        new Concat(inputPorts: Int) 
        def apply[T](inputPorts: Int = 2): Graph[UniformFanInShape[T, T], NotUsed] 
final class Interleave[T] extends GraphStage[UniformFanInShape[T, T]]
	Interleave represents deterministic merge which takes N elements per input stream, in-order of inputs, emits them downstream and then cycles/"wraps-around" the inputs.
	Emits when element is available from current input (depending on phase)
	Backpressures when downstream backpressures
	Completes when all upstreams complete (eagerClose=false) or one upstream completes (eagerClose=true)
	Cancels when downstream cancels
        new Interleave(inputPorts: Int, segmentSize: Int, eagerClose: Boolean) 
        def apply[T](inputPorts: Int, segmentSize: Int, eagerClose: Boolean = false): Graph[UniformFanInShape[T, T], NotUsed] 
final class Merge[T] extends GraphStage[UniformFanInShape[T, T]]
	Merge several streams, taking elements as they arrive from input streams (picking randomly when several have elements ready).
	Emits when one of the inputs has an element available
	Backpressures when downstream backpressures
	Completes when all upstreams complete (eagerComplete=false) or one upstream completes (eagerComplete=true), default value is false
	Cancels when downstream cancels
        new Merge(inputPorts: Int, eagerComplete: Boolean) 
        def apply[T](inputPorts: Int, eagerComplete: Boolean = false): Merge[T] 
final class MergePreferred[T] extends GraphStage[MergePreferredShape[T]]
	Merge several streams, taking elements as they arrive from input streams (picking from preferred when several have elements ready).
	A MergePreferred has one out port, one preferred input port and 1 or more secondary in ports.
	Emits when one of the inputs has an element available, preferring a specified input if multiple have elements available
	Backpressures when downstream backpressures
	Completes when all upstreams complete (eagerComplete=false) or one upstream completes (eagerComplete=true), default value is false
	Cancels when downstream cancels
        new MergePreferred(secondaryPorts: Int, eagerComplete: Boolean) 
        def apply[T](secondaryPorts: Int, eagerComplete: Boolean = false): MergePreferred[T] 
final class MergePrioritized[T] extends GraphStage[UniformFanInShape[T, T]]
	Merge several streams, taking elements as they arrive from input streams (picking from prioritized once when several have elements ready).
	A MergePrioritized has one out port, one or more input port with their priorities.
	Emits when one of the inputs has an element available, preferring a input based on its priority if multiple have elements available
	Backpressures when downstream backpressures
	Completes when all upstreams complete (eagerComplete=false) or one upstream completes (eagerComplete=true), default value is false
	Cancels when downstream cancels
        MergePrioritized.apply[T](priorities: Seq[Int], eagerComplete: Boolean = false): GraphStage[UniformFanInShape[T, T]] 
final class MergeSorted[T] extends GraphStage[FanInShape2[T, T, T]]
	Merge two pre-sorted streams such that the resulting stream is sorted.
	Emits when both inputs have an element available
	Backpressures when downstream backpressures
	Completes when all upstreams complete
	Cancels when downstream cancels
        new MergeSorted()(implicit arg0: Ordering[T]) 
final class Partition[T] extends GraphStage[UniformFanOutShape[T, T]]
	Fan-out the stream to several streams. emitting an incoming upstream element to one downstream consumer according to the partitioner function applied to the element
	Emits when emits when an element is available from the input and the chosen output has demand
	Backpressures when the currently chosen output back-pressures
	Completes when upstream completes and no output is pending
	Cancels when all downstreams have cancelled (eagerCancel=false) or one downstream cancels (eagerCancel=true)
        new Partition(outputPorts: Int, partitioner: (T) ⇒ Int, eagerCancel: Boolean) 
        def apply[T](outputPorts: Int, partitioner: (T) ⇒ Int): Partition[T] 
final class Unzip[A, B] extends UnzipWith2[(A, B), A, B]
	Takes a stream of pair elements and splits each pair to two output streams.
	An Unzip has one in port and one left and one right output port.
	Emits when all of the outputs stop backpressuring and there is an input element available
	Backpressures when any of the outputs backpressure
	Completes when upstream completes
	Cancels when any downstream cancels
        new Unzip() 
        def apply[A, B](): Unzip[A, B] 
class UnzipWith10[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10] extends GraphStage[FanOutShape10[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10]]
    new UnzipWith10(unzipper: (In) ⇒ (A1, A2, A3, A4, A5, A6, A7, A8, A9, A10)) 
class UnzipWith11[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11] extends GraphStage[FanOutShape11[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11]]
class UnzipWith12[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12]
	UnzipWith specialized for 12 outputs
class UnzipWith13[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13]
	UnzipWith specialized for 13 outputs
class UnzipWith14[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14]
	UnzipWith specialized for 14 outputs
class UnzipWith15[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15]
	UnzipWith specialized for 15 outputs
class UnzipWith16[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16]
	UnzipWith specialized for 16 outputs
class UnzipWith17[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17]
	UnzipWith specialized for 17 outputs
class UnzipWith18[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18]
	UnzipWith specialized for 18 outputs
class UnzipWith19[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19]
	UnzipWith specialized for 19 outputs
class UnzipWith2[In, A1, A2]
	UnzipWith specialized for 2 outputs
class UnzipWith20[In, A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20]
	UnzipWith specialized for 20 outputs
class UnzipWith3[In, A1, A2, A3]
	UnzipWith specialized for 3 outputs
class UnzipWith4[In, A1, A2, A3, A4]
	UnzipWith specialized for 4 outputs
class UnzipWith5[In, A1, A2, A3, A4, A5]
	UnzipWith specialized for 5 outputs
class UnzipWith6[In, A1, A2, A3, A4, A5, A6]
	UnzipWith specialized for 6 outputs
class UnzipWith7[In, A1, A2, A3, A4, A5, A6, A7]
	UnzipWith specialized for 7 outputs
class UnzipWith8[In, A1, A2, A3, A4, A5, A6, A7, A8]
	UnzipWith specialized for 8 outputs
class UnzipWith9[In, A1, A2, A3, A4, A5, A6, A7, A8, A9]
	UnzipWith specialized for 9 outputs    
final class Zip[A, B] extends ZipWith2[A, B, (A, B)]
	Combine the elements of 2 streams into a stream of tuples.
	A Zip has a left and a right input port and one out port
	Emits when all of the inputs has an element available
	Backpressures when downstream backpressures
	Completes when any upstream completes
	Cancels when downstream cancels
        new Zip() 
        def apply[A, B](): Zip[A, B] 
final class ZipN[A] extends ZipWithN[A, Seq[A]]
	Combine the elements of multiple streams into a stream of sequences.
	A ZipN has a n input ports and one out port
	Emits when all of the inputs has an element available
	Backpressures when downstream backpressures
	Completes when any upstream completes
	Cancels when downstream cancels
        new ZipN(n: Int) 
        def apply[A](n: Int): ZipN[A] 
class ZipWith10[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, O] extends GraphStage[FanInShape10[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, O]]
    new ZipWith10(zipper: (A1, A2, A3, A4, A5, A6, A7, A8, A9, A10) ⇒ O) 
class ZipWith11[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, O]
	ZipWith specialized for 11 inputs
class ZipWith12[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, O]
	ZipWith specialized for 12 inputs
class ZipWith13[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, O]
	ZipWith specialized for 13 inputs
class ZipWith14[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, O]
	ZipWith specialized for 14 inputs
class ZipWith15[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, O]
	ZipWith specialized for 15 inputs
class ZipWith16[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, O]
	ZipWith specialized for 16 inputs
class ZipWith17[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, O]
	ZipWith specialized for 17 inputs
class ZipWith18[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, O]
	ZipWith specialized for 18 inputs
class ZipWith19[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, O]
	ZipWith specialized for 19 inputs
class ZipWith2[A1, A2, O]
	ZipWith specialized for 2 inputs
class ZipWith20[A1, A2, A3, A4, A5, A6, A7, A8, A9, A10, A11, A12, A13, A14, A15, A16, A17, A18, A19, A20, O]
	ZipWith specialized for 20 inputs
class ZipWith3[A1, A2, A3, O]
	ZipWith specialized for 3 inputs
class ZipWith4[A1, A2, A3, A4, O]
	ZipWith specialized for 4 inputs
class ZipWith5[A1, A2, A3, A4, A5, O]
	ZipWith specialized for 5 inputs
class ZipWith6[A1, A2, A3, A4, A5, A6, O]
	ZipWith specialized for 6 inputs
class ZipWith7[A1, A2, A3, A4, A5, A6, A7, O]
	ZipWith specialized for 7 inputs
class ZipWith8[A1, A2, A3, A4, A5, A6, A7, A8, O]
	ZipWith specialized for 8 inputs
class ZipWith9[A1, A2, A3, A4, A5, A6, A7, A8, A9, O]
	ZipWith specialized for 9 inputs
object ZipWith extends ZipWithApply    
    Combine the elements of multiple streams into a stream of combined elements using a combiner function.
    Emits when all of the inputs has an element available
    Backpressures when downstream backpressures
    Completes when any upstream completes
    Cancels when downstream cancels 
    //Many other appky with N=20 apply methods  
        def apply[A1, A2, A3, O](zipper: (A1, A2, A3) ⇒ O): ZipWith3[A1, A2, A3, O]
        Create a new ZipWith specialized for 3 inputs.
        def apply[A1, A2, O](zipper: (A1, A2) ⇒ O): ZipWith2[A1, A2, O]
        Create a new ZipWith specialized for 2 inputs.

class ZipWithN[A, O] extends GraphStage[UniformFanInShape[A, O]]
	Combine the elements of multiple streams into a stream of sequences using a combiner function.
	A ZipWithN has a n input ports and one out port
	Emits when all of the inputs has an element available
	Backpressures when downstream backpressures
	Completes when any upstream completes
	Cancels when downstream cancels
        new ZipWithN(zipper: (Seq[A]) ⇒ O)(n: Int) 
        def apply[A, O](zipper: (Seq[A]) ⇒ O)(n: Int): ZipWithN[A, O] 
///General Structures of these Classes , only constructors and object apply are different 
final class Balance[T] extends GraphStage[UniformFanOutShape[T, T]]
    Fan-out the stream to several streams. Each upstream element is emitted to the first available downstream consumer. It will not shut down until the subscriptions for at least two downstream subscribers have been established.
    A Balance has one in port and 2 or more out ports.
    Emits when any of the outputs stops backpressuring; emits the element to the first available output
    Backpressures when all of the outputs backpressure
    Completes when upstream completes
    Cancels when all downstreams cancel 
    Instance Constructors
        new Balance(outputPorts: Int, waitForAllDownstreams: Boolean) 
    Type Members
        type Shape = UniformFanOutShape[T, T]
        Type-level accessor for the shape parameter of this graph.
    Value Members
        def addAttributes(attr: Attributes): Graph[UniformFanOutShape[T, T], NotUsed]
            Add the given attributes to this Graph.
        def async(dispatcher: String, inputBufferSize: Int): Graph[UniformFanOutShape[T, T], NotUsed]
            Put an asynchronous boundary around this Graph
        def async(dispatcher: String): Graph[UniformFanOutShape[T, T], NotUsed]
            Put an asynchronous boundary around this Graph
        def async: Graph[UniformFanOutShape[T, T], NotUsed]
            Put an asynchronous boundary around this Graph
        def createLogic(inheritedAttributes: Attributes): GraphStageLogic
        final def createLogicAndMaterializedValue(inheritedAttributes: Attributes): (GraphStageLogic, NotUsed)
        val in: Inlet[T]
        def initialAttributes: Attributes
        def named(name: String): Graph[UniformFanOutShape[T, T], NotUsed]
        val out: IndexedSeq[Outlet[T]]
        val outputPorts: Int
        val shape: UniformFanOutShape[T, T]
        def toString(): String
        val waitForAllDownstreams: Boolean
        final def withAttributes(attr: Attributes): Graph[UniformFanOutShape[T, T], NotUsed] 
object Balance
    def apply[T](outputPorts: Int, waitForAllDownstreams: Boolean = false): Balance[T]
        Create a new Balance with the specified number of output ports.

object akka.stream.scaladsl.GraphDSL extends GraphApply
    //Type Members
    class Builder[+M] 
        Value Members
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19, M20, M21, M22](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16], g17: Graph[Shape, M17], g18: Graph[Shape, M18], g19: Graph[Shape, M19], g20: Graph[Shape, M20], g21: Graph[Shape, M21], g22: Graph[Shape, M22])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19, M20, M21, M22) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19, M20, M21](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16], g17: Graph[Shape, M17], g18: Graph[Shape, M18], g19: Graph[Shape, M19], g20: Graph[Shape, M20], g21: Graph[Shape, M21])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19, M20, M21) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19, M20](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16], g17: Graph[Shape, M17], g18: Graph[Shape, M18], g19: Graph[Shape, M19], g20: Graph[Shape, M20])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19, M20) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16], g17: Graph[Shape, M17], g18: Graph[Shape, M18], g19: Graph[Shape, M19])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18, M19) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16], g17: Graph[Shape, M17], g18: Graph[Shape, M18])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17, M18) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16], g17: Graph[Shape, M17])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16, M17) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15], g16: Graph[Shape, M16])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15, M16) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14], g15: Graph[Shape, M15])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14, M15) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13], g14: Graph[Shape, M14])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13, M14) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12], g13: Graph[Shape, M13])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12, M13) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11], g12: Graph[Shape, M12])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11, M12) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10], g11: Graph[Shape, M11])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10, M11) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9, M10](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9], g10: Graph[Shape, M10])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9, M10) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8, M9](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8], g9: Graph[Shape, M9])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8, M9) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7, M8](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7], g8: Graph[Shape, M8])(combineMat: (M1, M2, M3, M4, M5, M6, M7, M8) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6, M7](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6], g7: Graph[Shape, M7])(combineMat: (M1, M2, M3, M4, M5, M6, M7) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5, M6](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5], g6: Graph[Shape, M6])(combineMat: (M1, M2, M3, M4, M5, M6) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4, M5](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4], g5: Graph[Shape, M5])(combineMat: (M1, M2, M3, M4, M5) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3, M4](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3], g4: Graph[Shape, M4])(combineMat: (M1, M2, M3, M4) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2, M3](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3])(combineMat: (M1, M2, M3) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat, M1, M2](g1: Graph[Shape, M1], g2: Graph[Shape, M2])(combineMat: (M1, M2) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graphs and passing their Shapes along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape, Mat](g1: Graph[Shape, Mat])(buildBlock: (Builder[Mat]) => (Graph.Shape) => S): Graph[S, Mat]
        Creates a new Graph by importing the given graph g1 and passing its Shape along with the GraphDSL.Builder to the given create function.
    def create[S <: Shape]()(buildBlock: (Builder[NotUsed]) => S): Graph[S, NotUsed]
        Creates a new Graph by passing a GraphDSL.Builder to the given create function.
    object Implicits
object Implicits
//Type Members
    implicit final class BidiFlowShapeArrow[I1, O1, I2, O2]
    sealed trait CombinerBase[+T]
    final class DisabledReversePortOps[In]
    implicit final class FanInOps[In, Out]
    implicit final class FanOutOps[In, Out]
    implicit final class FlowArrow[I, O, M]
    implicit final class FlowShapeArrow[I, O]
    trait PortOps[+Out]
    sealed trait ReverseCombinerBase[T]
    implicit class ReversePortOps[In]
    implicit final class SinkArrow[T]
    implicit final class SinkShapeArrow[T]
    implicit final class SourceArrow[T]
    implicit final class SourceShapeArrow[T] 
    //Value Members
    implicit def fanOut2flow[I, O](j: UniformFanOutShape[I, O])(implicit b: Builder[_]): PortOps[O]
    implicit def flow2flow[I, O](f: FlowShape[I, O])(implicit b: Builder[_]): PortOps[O]
    implicit def port2flow[T](from: Outlet[T])(implicit b: Builder[_]): PortOps[T] 
trait akka.stream.scaladsl.GraphDSL.Implicits.PortOps[+Out] extends FlowOps[Out, NotUsed] with CombinerBase[Out]
    //Type Members
    type Closed = Unit
    type Repr[+O] = PortOps[O] 
    //Abstract Value Members
    abstract def addAttributes(attr: Attributes): Repr[Out]
    abstract def async: Repr[Out]
        Put an asynchronous boundary around this Flow.
    abstract def importAndGetPort(b: Builder[_]): Outlet[Out]
    abstract def named(name: String): Repr[Out]
    abstract def outlet: Outlet[Out]
    abstract def to[Mat2](sink: Graph[SinkShape[Out], Mat2]): Closed
        Connect this Flow to a Sink, concatenating the processing steps of both.
    abstract def via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Repr[T]
        Transform this Flow by appending the given processing steps.
    abstract def withAttributes(attr: Attributes): Repr[Out] 
    //Concrete Value Members
    def ++[U >: Out, M](that: Graph[SourceShape[U], M]): Repr[U]
        Concatenates this Flow with the given Source so the first element emitted by that source is emitted after the last element of this flow.
    def alsoTo(that: Graph[SinkShape[Out], _]): Repr[Out]
        Attaches the given Sink to this Flow, meaning that elements that pass through will also be sent to the Sink.
    def ask[S](parallelism: Int)(ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
        Use the ask pattern to send a request-reply message to the target ref actor.
    def ask[S](ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
        Use the ask pattern to send a request-reply message to the target ref actor.
    def backpressureTimeout(timeout: FiniteDuration): Repr[Out]
        If the time between the emission of an element and the following downstream demand exceeds the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def batch[S](max: Long, seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by aggregating elements into batches until the subscriber is ready to accept them.
    def batchWeighted[S](max: Long, costFn: (Out) => Long, seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by aggregating elements into batches until the subscriber is ready to accept them.
    def buffer(size: Int, overflowStrategy: OverflowStrategy): Repr[Out]
        Adds a fixed size buffer in the flow that allows to store elements from a faster upstream until it becomes full.
    def collect[T](pf: PartialFunction[Out, T]): Repr[T]
        Transform this stream by applying the given partial function to each of the elements on which the function is defined as they pass through this processing step.
    def collectType[T](implicit tag: ClassTag[T]): Repr[T]
        Transform this stream by testing the type of each of the elements on which the element is an instance of the provided type as they pass through this processing step.
    def completionTimeout(timeout: FiniteDuration): Repr[Out]
        If the completion of the stream does not happen until the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def concat[U >: Out, Mat2](that: Graph[SourceShape[U], Mat2]): Repr[U]
        Concatenate the given Source to this Flow, meaning that once this Flow’s input is exhausted and all result elements have been generated, the Source’s elements will be produced.
    def conflate[O2 >: Out](aggregate: (O2, O2) => O2): Repr[O2]
        Allows a faster upstream to progress independently of a slower subscriber by conflating elements into a summary until the subscriber is ready to accept them.
    def conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
        Allows a faster upstream to progress independently of a slower subscriber by conflating elements into a summary until the subscriber is ready to accept them.
    def delay(of: FiniteDuration, strategy: DelayOverflowStrategy = DelayOverflowStrategy.dropTail): Repr[Out]
        Shifts elements emission in time by a specified amount.
    def detach: Repr[Out]
        Detaches upstream demand from downstream demand without detaching the stream rates; in other words acts like a buffer of size 1.
    def divertTo(that: Graph[SinkShape[Out], _], when: (Out) => Boolean): Repr[Out]
        Attaches the given Sink to this Flow, meaning that elements will be sent to the Sink instead of being passed through if the predicate when returns true.
    def drop(n: Long): Repr[Out]
        Discard the given number of elements at the beginning of the stream.
    def dropWhile(p: (Out) => Boolean): Repr[Out]
        Discard elements at the beginning of the stream while predicate is true.
    def dropWithin(d: FiniteDuration): Repr[Out]
        Discard the elements received within the given duration at beginning of the stream.
    def expand[U](extrapolate: (Out) => Iterator[U]): Repr[U]
        Allows a faster downstream to progress independently of a slower publisher by extrapolating elements from an older element until new element comes from the upstream.
    def filter(p: (Out) => Boolean): Repr[Out]
        Only pass on those elements that satisfy the given predicate.
    def filterNot(p: (Out) => Boolean): Repr[Out]
        Only pass on those elements that NOT satisfy the given predicate.
    def flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Repr[T]
        Transform each input element into a Source of output elements that is then flattened into the output stream by concatenation, fully consuming one Source after the other.
    def flatMapMerge[T, M](breadth: Int, f: (Out) => Graph[SourceShape[T], M]): Repr[T]
        Transform each input element into a Source of output elements that is then flattened into the output stream by merging, where at most breadth substreams are being consumed at any given time.
    def fold[T](zero: T)(f: (T, Out) => T): Repr[T]
        Similar to scan but only emits its result when the upstream completes, after which it also completes.
    def foldAsync[T](zero: T)(f: (T, Out) => Future[T]): Repr[T]
        Similar to fold but with an asynchronous function.
    def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, NotUsed, Repr, Closed]
        This operation demultiplexes the incoming stream into separate output streams, one for each element key.
    def grouped(n: Int): Repr[Seq[Out]]
        Chunk up this stream into groups of the given size, with the last group possibly smaller than requested due to end-of-stream.
    def groupedWeightedWithin(maxWeight: Long, d: FiniteDuration)(costFn: (Out) => Long): Repr[Seq[Out]]
        Chunk up this stream into groups of elements received within a time window, or limited by the weight of the elements, whatever happens first.
    def groupedWithin(n: Int, d: FiniteDuration): Repr[Seq[Out]]
        Chunk up this stream into groups of elements received within a time window, or limited by the given number of elements, whatever happens first.
    def idleTimeout(timeout: FiniteDuration): Repr[Out]
        If the time between two processed elements exceeds the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def initialDelay(delay: FiniteDuration): Repr[Out]
        Delays the initial element by the specified duration.
    def initialTimeout(timeout: FiniteDuration): Repr[Out]
        If the first element has not passed through this stage before the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def interleave[U >: Out](that: Graph[SourceShape[U], _], segmentSize: Int, eagerClose: Boolean): Repr[U]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def interleave[U >: Out](that: Graph[SourceShape[U], _], segmentSize: Int): Repr[U]
        Interleave is a deterministic merge of the given Source with elements of this Flow.
    def intersperse[T >: Out](inject: T): Repr[T]
        Intersperses stream with provided element, similar to how scala.collection.immutable.List.mkString injects a separator between a List's elements.
    def intersperse[T >: Out](start: T, inject: T, end: T): Repr[T]
        Intersperses stream with provided element, similar to how scala.collection.immutable.List.mkString injects a separator between a List's elements.
    def keepAlive[U >: Out](maxIdle: FiniteDuration, injectedElem: () => U): Repr[U]
        Injects additional elements if upstream does not emit for a configured amount of time.
    def limit(max: Long): Repr[Out]
        Ensure stream boundedness by limiting the number of elements from upstream.
    def limitWeighted[T](max: Long)(costFn: (Out) => Long): Repr[Out]
        Ensure stream boundedness by evaluating the cost of incoming elements using a cost function.
    def log(name: String, extract: (Out) => Any = ConstantFun.scalaIdentityFunction)(implicit log: LoggingAdapter = null): Repr[Out]
        Logs elements flowing through the stream as well as completion and erroring.
    def map[T](f: (Out) => T): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapAsync[T](parallelism: Int)(f: (Out) => Future[T]): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapAsyncUnordered[T](parallelism: Int)(f: (Out) => Future[T]): Repr[T]
        Transform this stream by applying the given function to each of the elements as they pass through this processing step.
    def mapConcat[T](f: (Out) => Iterable[T]): Repr[T]
        Transform each input element into an Iterable of output elements that is then flattened into the output stream.
    def mapError(pf: PartialFunction[Throwable, Throwable]): Repr[Out]
        While similar to recover this stage can be used to transform an error signal to a different one *without* logging it as an error in the process.
    def merge[U >: Out, M](that: Graph[SourceShape[U], M], eagerComplete: Boolean = false): Repr[U]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking randomly when several elements ready.
    def mergeSorted[U >: Out, M](that: Graph[SourceShape[U], M])(implicit ord: Ordering[U]): Repr[U]
        Merge the given Source to this Flow, taking elements as they arrive from input streams, picking always the smallest of the available elements (waiting for one element from each side to be available).
    def orElse[U >: Out, Mat2](secondary: Graph[SourceShape[U], Mat2]): Repr[U]
        Provides a secondary source that will be consumed if this stream completes without any elements passing by.
    def prefixAndTail[U >: Out](n: Int): Repr[(Seq[Out], Source[U, NotUsed])]
        Takes up to n elements from the stream (less than n only if the upstream completes before emitting n elements) and returns a pair containing a strict sequence of the taken element and a stream representing the remaining elements.
    def prepend[U >: Out, Mat2](that: Graph[SourceShape[U], Mat2]): Repr[U]
        Prepend the given Source to this Flow, meaning that before elements are generated from this Flow, the Source elements will be produced until it is exhausted, at which point Flow elements will start being produced.
    def recover[T >: Out](pf: PartialFunction[Throwable, T]): Repr[T]
        Recover allows to send last element on failure and gracefully complete the stream Since the underlying failure signal onError arrives out-of-band, it might jump over existing elements.
    def recoverWithRetries[T >: Out](attempts: Int, pf: PartialFunction[Throwable, Graph[SourceShape[T], NotUsed]]): Repr[T]
        RecoverWithRetries allows to switch to alternative Source on flow failure.
    def reduce[T >: Out](f: (T, T) => T): Repr[T]
        Similar to fold but uses first element as zero element.
    def scan[T](zero: T)(f: (T, Out) => T): Repr[T]
        Similar to fold but is not a terminal operation, emits its current value which starts at zero and then applies the current and next value to the given function f, emitting the next current value.
    def scanAsync[T](zero: T)(f: (T, Out) => Future[T]): Repr[T]
        Similar to scan but with a asynchronous function, emits its current value which starts at zero and then applies the current and next value to the given function f, emitting a Future that resolves to the next current value.
    def sliding(n: Int, step: Int = 1): Repr[Seq[Out]]
        Apply a sliding window over the stream and return the windows as groups of elements, with the last group possibly smaller than requested due to end-of-stream.
    def splitAfter(p: (Out) => Boolean): SubFlow[Out, NotUsed, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams.
    def splitAfter(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, NotUsed, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams.
    def splitWhen(p: (Out) => Boolean): SubFlow[Out, NotUsed, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams, always beginning a new one with the current element if the given predicate returns true for it.
    def splitWhen(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, NotUsed, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them to a stream of output streams, always beginning a new one with the current element if the given predicate returns true for it.
    def statefulMapConcat[T](f: () => (Out) => Iterable[T]): Repr[T]
        Transform each input element into an Iterable of output elements that is then flattened into the output stream.
    def take(n: Long): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after the given number of elements.
    def takeWhile(p: (Out) => Boolean, inclusive: Boolean): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after predicate returns false for the first time, including the first failed element iff inclusive is true Due to input buffering some elements may have been requested from upstream publishers that will then not be processed downstream of this step.
    def takeWhile(p: (Out) => Boolean): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after predicate returns false for the first time, Due to input buffering some elements may have been requested from upstream publishers that will then not be processed downstream of this step.
    def takeWithin(d: FiniteDuration): Repr[Out]
        Terminate processing (and cancel the upstream publisher) after the given duration.
    def throttle(cost: Int, per: FiniteDuration, maximumBurst: Int, costCalculation: (Out) => Int, mode: ThrottleMode): Repr[Out]
        Sends elements downstream with speed limited to cost/per.
    def throttle(elements: Int, per: FiniteDuration, maximumBurst: Int, mode: ThrottleMode): Repr[Out]
        Sends elements downstream with speed limited to elements/per.
    def throttleEven(cost: Int, per: FiniteDuration, costCalculation: (Out) => Int, mode: ThrottleMode): Repr[Out]
        This is a simplified version of throttle that spreads events evenly across the given time interval.
    def throttleEven(elements: Int, per: FiniteDuration, mode: ThrottleMode): Repr[Out]
        This is a simplified version of throttle that spreads events evenly across the given time interval.
    def watch(ref: ActorRef): Repr[Out]
        The stage fails with an akka.stream.WatchedActorTerminatedException if the target actor is terminated.
    def wireTap(that: Graph[SinkShape[Out], _]): Repr[Out]
        Attaches the given Sink to this Flow as a wire tap, meaning that elements that pass through will also be sent to the wire-tap Sink, without the latter affecting the mainline flow.
    def zip[U](that: Graph[SourceShape[U], _]): Repr[(Out, U)]
        Combine the elements of current flow and the given Source into a stream of tuples.
    def zipWith[Out2, Out3](that: Graph[SourceShape[Out2], _])(combine: (Out, Out2) => Out3): Repr[Out3]
        Put together the elements of current flow and the given Source into a stream of combined elements using a combiner function.
    def zipWithIndex: Repr[(Out, Long)]
        Combine the elements of current flow into a stream of tuples consisting of all elements paired with their index.
    def ~>(to: SinkShape[Out])(implicit b: Builder[_]): Unit
    def ~>(to: Graph[SinkShape[Out], _])(implicit b: Builder[_]): Unit
    def ~>[Out](flow: FlowShape[Out, Out])(implicit b: Builder[_]): PortOps[Out]
    def ~>[Out](junction: UniformFanOutShape[Out, Out])(implicit b: Builder[_]): PortOps[Out]
    def ~>[Out](junction: UniformFanInShape[Out, Out])(implicit b: Builder[_]): PortOps[Out]
    def ~>[Out](via: Graph[FlowShape[Out, Out], Any])(implicit b: Builder[_]): PortOps[Out]
    def ~>[U >: Out](to: Inlet[U])(implicit b: Builder[_]): Unit 
class Builder[+M] extends AnyRef
    def add[S <: Shape](graph: Graph[S, _]): S
        Import a graph into this module, performing a deep copy, discarding its materialized value and returning the copied Ports that are now to be connected.
    def asJava: javadsl.GraphDSL.Builder[M]
        Converts this Scala DSL element to it is Java DSL counterpart.
    def materializedValue: Outlet[M]
        Returns an Outlet that gives access to the materialized value of this graph.
abstract class akka.stream.Shape extends AnyRef
    A Shape describes the inlets and outlets of a Graph. 
    //subclasses 
    AbstractShape, AmorphousShape, BidiShape, ClosedShape, ClosedShape, 
    FanInShape, FanInShape1N, FanInShape10, FanInShape11, FanInShape12, FanInShape13, FanInShape14, FanInShape15, FanInShape16, FanInShape17, FanInShape18, FanInShape19, FanInShape2, FanInShape20, FanInShape21, FanInShape22, FanInShape3, FanInShape4, FanInShape5, FanInShape6, FanInShape7, FanInShape8, FanInShape9, 
    FanOutShape, FanOutShape10, FanOutShape11, FanOutShape12, FanOutShape13, FanOutShape14, FanOutShape15, FanOutShape16, FanOutShape17, FanOutShape18, FanOutShape19, FanOutShape2, FanOutShape20, FanOutShape21, FanOutShape22, FanOutShape3, FanOutShape4, FanOutShape5, FanOutShape6, FanOutShape7, FanOutShape8, FanOutShape9, 
    FlowShape, SinkShape, SourceShape, UniformFanInShape, UniformFanOutShape, MergePreferredShape, 
    //Instance Constructors
    new Shape() 
    //Abstract Value Members
    abstract def deepCopy(): Shape
        Create a copy of this Shape object, returning the same type as the original; this constraint can unfortunately not be expressed in the type system.
    abstract def inlets: Seq[Inlet[_]]
        Scala API: get a list of all input ports
    abstract def outlets: Seq[Outlet[_]]
        Scala API: get a list of all output ports
    //Concrete Value Members
    def getInlets: List[Inlet[_]]
        Java API: get a list of all input ports
    def getOutlets: List[Outlet[_]]
        Java API: get a list of all output ports
    def hasSamePortsAndShapeAs(s: Shape): Boolean
        Compare this to another shape and determine whether the arrangement of ports is the same (including their ordering).
    def hasSamePortsAs(s: Shape): Boolean
        Compare this to another shape and determine whether the set of ports is the same (ignoring their ordering).
    def requireSamePortsAndShapeAs(s: Shape): Unit
        Asserting version of #hasSamePortsAndShapeAs.
    def requireSamePortsAs(s: Shape): Unit
        Asserting version of #hasSamePortsAs.
Inlet.apply[T](name: String): Inlet[T]
Outlet.apply[T](name: String): Outlet[T]         
class UniformFanInShape[-T, +O] extends FanInShape[O]
	Instance Constructors
        new UniformFanInShape(outlet: Outlet[O], inlets: Array[Inlet[T]])
        new UniformFanInShape(n: Int, name: String)
        new UniformFanInShape(n: Int)
        new UniformFanInShape(n: Int, _init: Init[O]) 
	Value Members
        def deepCopy(): UniformFanInShape[T, O]
            Create a copy of this Shape object, returning the same type as the original; this constraint can unfortunately not be expressed in the type system.
        def getInlets: List[Inlet[_]]
            Java API: get a list of all input ports
        def getOutlets: List[Outlet[_]]
            Java API: get a list of all output ports
        def hasSamePortsAndShapeAs(s: Shape): Boolean
            Compare this to another shape and determine whether the arrangement of ports is the same (including their ordering).
        def hasSamePortsAs(s: Shape): Boolean
            Compare this to another shape and determine whether the set of ports is the same (ignoring their ordering).
        def in(n: Int): Inlet[T]
        final def inlets: Seq[Inlet[T]]
            Not meant for overriding outside of Akka.
        val n: Int
        final def out: Outlet[O]
        final def outlets: Seq[Outlet[O]]
            Scala API: get a list of all output ports
        def requireSamePortsAndShapeAs(s: Shape): Unit
            Asserting version of #hasSamePortsAndShapeAs.
        def requireSamePortsAs(s: Shape): Unit
            Asserting version of #hasSamePortsAs.
object UniformFanInShape
    def apply[I, O](outlet: Outlet[O], inlets: Inlet[I]*): UniformFanInShape[I, O] 
sealed trait Init[I] extends AnyRef
    Abstract Value Members
        abstract def inlet: Inlet[I]
        abstract def name: String
        abstract def outlets: Seq[Outlet[_]] 
class UniformFanOutShape[-I, +O] extends FanOutShape[I] 
	Instance Constructors
        new UniformFanOutShape(inlet: Inlet[I], outlets: Array[Outlet[O]])
        new UniformFanOutShape(n: Int, name: String)
        new UniformFanOutShape(n: Int)
        new UniformFanOutShape(n: Int, _init: Init[I]) 
	Concrete Value Members
        def deepCopy(): UniformFanOutShape[I, O]
            Create a copy of this Shape object, returning the same type as the original; this constraint can unfortunately not be expressed in the type system.
        def getInlets: List[Inlet[_]]
            Java API: get a list of all input ports
        def getOutlets: List[Outlet[_]]
            Java API: get a list of all output ports
        def hasSamePortsAndShapeAs(s: Shape): Boolean
            Compare this to another shape and determine whether the arrangement of ports is the same (including their ordering).
        def hasSamePortsAs(s: Shape): Boolean
            Compare this to another shape and determine whether the set of ports is the same (ignoring their ordering).
        final def in: Inlet[I]
        final def inlets: Seq[Inlet[I]]
            Scala API: get a list of all input ports
        def out(n: Int): Outlet[O]
        final def outlets: Seq[Outlet[O]]
            Not meant for overriding outside of Akka.
        def requireSamePortsAndShapeAs(s: Shape): Unit
            Asserting version of #hasSamePortsAndShapeAs.
        def requireSamePortsAs(s: Shape): Unit
            Asserting version of #hasSamePortsAs.
object UniformFanOutShape
    def apply[I, O](inlet: Inlet[I], outlets: Outlet[O]*): UniformFanOutShape[I, O] 



///Constructing Graphs
//Note Source,Sink,Flow and others are actually Graphs , Graph[+S <: Shape, +M]
class Flow[-In, +Out, +Mat] extends Graph[FlowShape[In, Out], Mat] 
class Sink[-In, +Mat] extends Graph[SinkShape[In], Mat] 
class Source[+Out, +Mat] extends Graph[SourceShape[Out], Mat] 
 
//Below junctions are available
Fan-out
    Broadcast[T] – (1 input, N outputs) given an input element emits to each output
    Balance[T] – (1 input, N outputs) given an input element emits to one of its output ports
    UnzipWith[In,A,B,...] – (1 input, N outputs) takes a function of 1 input that given a value for each input emits N output elements (where N <= 20)
    UnZip[A,B] – (1 input, 2 outputs) splits a stream of (A,B) tuples into two streams, one of type A and one of type B
Fan-in
    Merge[In] – (N inputs , 1 output) picks randomly from inputs pushing them one by one to its output
    MergePreferred[In] – like Merge but if elements are available on preferred port, it picks from it, otherwise randomly from others
    MergePrioritized[In] – like Merge but if elements are available on all input ports, it picks from them randomly based on their priority
    ZipWith[A,B,...,Out] – (N inputs, 1 output) which takes a function of N inputs that given a value for each input emits 1 output element
    Zip[A,B] – (2 inputs, 1 output) is a ZipWith specialised to zipping input streams of A and B into a (A,B) tuple stream
    Concat[A] – (2 inputs, 1 output) concatenates two streams (first consume one, then the second one)

        
//Junctions must always be created with defined type parameters, as otherwise the Nothing type will be inferred.
//GraphDSL.Builder object is mutable
//Once the GraphDSL has been constructed though, the GraphDSL instance is immutable, thread-safe, and freely shareable.

//def create[S <: Shape]()(buildBlock: (Builder[NotUsed]) ⇒ S): Graph[S, NotUsed]
//Creates a new Graph by passing a GraphDSL.Builder to the given create function. 
//def create[S <: Shape, Mat](g1: Graph[Shape, Mat])(buildBlock: (Builder[Mat]) ⇒ (Graph.Shape) ⇒ S): Graph[S, Mat] 
//with Mat 
val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder: GraphDSL.Builder[NotUsed] =>
  import GraphDSL.Implicits._
  val in = Source(1 to 10)
  val out = Sink.ignore

  val bcast = builder.add(Broadcast[Int](2))
  val merge = builder.add(Merge[Int](2))

  val f1, f2, f3, f4 = Flow[Int].map(_ + 10)  //Flow.apply[T]: Flow[T, T, NotUsed] //Multiple assignments like val x,y =1 , each would get different instance of same Flow operations 

  in ~> f1 ~> bcast ~> f2 ~> merge ~> f3 ~> out  //input of bcastTO first output of bcast .... first input of merge 
              bcast ~> f4 ~> merge               //                 2nd output of bcast ....... 2nd input of merge  , merge outputs one which goes to f3 
  ClosedShape
})
g.run()


//In the example below we prepare a graph that consists of two parallel streams, 
//in which we re-use the same instance of Flow, yet it will properly be materialized 
//as two connections between the corresponding Sources and Sinks:

//def create[S <: Shape, Mat, M1, M2](g1: Graph[Shape, M1], g2: Graph[Shape, M2])(combineMat: (M1, M2) ⇒ Mat)(buildBlock: (Builder[Mat]) ⇒ (Graph.Shape, Graph.Shape) ⇒ S): Graph[S, Mat] 
//def create[S <: Shape, Mat, M1, M2, M3](g1: Graph[Shape, M1], g2: Graph[Shape, M2], g3: Graph[Shape, M3])(combineMat: (M1, M2, M3) ⇒ Mat)(buildBlock: (Builder[Mat]) ⇒ (Graph.Shape, Graph.Shape, Graph.Shape) ⇒ S): Graph[S, Mat] 
val topHeadSink = Sink.head[Int]
val bottomHeadSink = Sink.head[Int]
val sharedDoubler = Flow[Int].map(_ * 2)

//Junctions have in or in(Int) as number of inputs 
//out or out(Int) as number of outputs 
//whereas Source , has .out, Sink has .in and flow as .out, .in 
//However, Zip*,Unzip* are  zips or unzips tuple, hence use inX, outX etc X=0,...maxnumber 
RunnableGraph.fromGraph(GraphDSL.create(topHeadSink, bottomHeadSink)((_, _)) { implicit builder => //(_, _) means Keep.both
  (topHS, bottomHS) =>
  import GraphDSL.Implicits._
  val broadcast = builder.add(Broadcast[Int](2))
  Source.single(1) ~> broadcast.in

  broadcast.out(0) ~> sharedDoubler ~> topHS.in
  broadcast.out(1) ~> sharedDoubler ~> bottomHS.in
  ClosedShape
})

///Constructing and combining Partial Graphs
//by returning a different Shape than ClosedShape, for example FlowShape(in, out), 
//Making a Graph a RunnableGraph requires all ports to be connected, 
//A partial graph returns the set of yet to be connected ports from the code block 

//Example - 3 inputs will pick the greatest int value of each zipped triple. 
//expose 3 input ports (unconnected sources) and one output port (unconnected sink).

//Junctions have in or in(Int) as number of inputs 
//out or out(Int) as number of outputs 
//whereas Source , has .out, Sink has .in and flow as .out, .in 
//However, Zip*,Unzip* are  zips or unzips tuple, hence use inX, outX etc X=0,...maxnumber 


val pickMaxOfThree = GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._
  //def apply[A1, A2, O](zipper: (A1, A2) ⇒ O): ZipWith2[A1, A2, O] 
  val zip1 = b.add(ZipWith[Int, Int, Int](math.max _))  //2 in 1 out 
  val zip2 = b.add(ZipWith[Int, Int, Int](math.max _))  //2 in 1 out 
  zip1.out ~> zip2.in0
  //apply[I, O](outlet: Outlet[O], inlets: Inlet[I]*): UniformFanInShape[I, O] 
  UniformFanInShape(zip2.out, zip1.in0, zip1.in1, zip2.in1)
}

val resultSink = Sink.head[Int]

val g = RunnableGraph.fromGraph(GraphDSL.create(resultSink) { implicit b => sink =>
  import GraphDSL.Implicits._

  // importing the partial graph will return its shape (inlets & outlets)
  val pm3 = b.add(pickMaxOfThree)

  Source.single(1) ~> pm3.in(0)
  Source.single(2) ~> pm3.in(1)
  Source.single(3) ~> pm3.in(2)
  pm3.out ~> sink.in
  ClosedShape
})

val max: Future[Int] = g.run()
Await.result(max, 300.millis) should equal(3)


///Constructing Sources, Sinks and Flows from Partial Graphs
1.Source is a partial graph with exactly one output, that is it returns a SourceShape.
  Create Source from  Source.fromGraph[T, M](g: Graph[SourceShape[T], M]): Source[T, M] 
  ie using GraphDSL.create and returning a  SourceShape(out: Outlet[T]) 
2.Sink is a partial graph with exactly one input, that is it returns a SinkShape.
  Create Sink from  Sink.fromGraph[T, M](g: Graph[SinkShape[T], M]): Sink[T, M] 
  ie using GraphDSL.create and returning a   SinkShape(in: Inlet[T])  
3.Flow is a partial graph with exactly one input and exactly one output, that is it returns a FlowShape.
  Create Source from  fromGraph[I, O, M](g: Graph[FlowShape[I, O], M]): Flow[I, O, M] 
  ie using GraphDSL.create and returning a   FlowShape(in: Inlet[I], out: Outlet[O]) 

//Example of Source 
val pairs = Source.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  // prepare graph elements
  val zip = b.add(Zip[Int, Int]())
  def ints = Source.fromIterator(() => Iterator.from(1))

  // connect the graph
  ints.filter(_ % 2 != 0) ~> zip.in0
  ints.filter(_ % 2 == 0) ~> zip.in1

  // expose port
  SourceShape(zip.out)
})

val firstPair: Future[(Int, Int)] = pairs.runWith(Sink.head)

//Example of FLow 
val pairUpWithToString =
  Flow.fromGraph(GraphDSL.create() { implicit b =>
    import GraphDSL.Implicits._

    // prepare graph elements
    val broadcast = b.add(Broadcast[Int](2))
    val zip = b.add(Zip[Int, String]())

    // connect the graph
    broadcast.out(0).map(identity) ~> zip.in0
    broadcast.out(1).map(_.toString) ~> zip.in1

    // expose ports
    FlowShape(broadcast.in, zip.out)
  })

pairUpWithToString.runWith(Source(List(1)), Sink.head)


///Combining Sources and Sinks with simplified API
//to combine sources and sinks with junctions like: Broadcast[T], Balance[T], Merge[In] and Concat[A] 
//without the need for using the Graph DSL. 
//The combine method takes care of constructing the necessary graph underneath

val sourceOne = Source(List(1))
val sourceTwo = Source(List(2))
//combine[T, U](first: Source[T, _], second: Source[T, _], rest: Source[T, _]*)(strategy: (Int) => Graph[UniformFanInShape[T, U], NotUsed]): Source[U, NotUsed]
//Merge.apply[T](inputPorts: Int, eagerComplete: Boolean = false): Merge[T] 
val merged = Source.combine(sourceOne, sourceTwo)(Merge(_))
val mergedResult: Future[Int] = merged.runWith(Sink.fold(0)(_ + _))



//for a Sink[T] but in this case it will be fan-out:

//Sends the elements of the stream to the given ActorRef.
val sendRmotely = Sink.actorRef(actorRef, "Done")
val localProcessing = Sink.foreach[Int](_ => /* do something usefull */ ())
//combine[T, U](first: Sink[U, _], second: Sink[U, _], rest: Sink[U, _]*)(strategy: (Int) ⇒ Graph[UniformFanOutShape[T, U], NotUsed]): Sink[T, NotUsed] 
//Broadcast.apply[T](outputPorts: Int, eagerCancel: Boolean = false): Broadcast[T] 
val sink = Sink.combine(sendRmotely, localProcessing)(Broadcast[Int](_))
Source(List(0, 1, 2)).runWith(sink)



//Implementation of Source.combine 
def combine[T, U](first: Source[T, _], second: Source[T, _], rest: Source[T, _]*)(strategy: Int ⇒ Graph[UniformFanInShape[T, U], NotUsed]): Source[U, NotUsed] =
    Source.fromGraph(GraphDSL.create() { implicit b ⇒
      import GraphDSL.Implicits._
      val c = b.add(strategy(rest.size + 2))
      first ~> c.in(0)
      second ~> c.in(1)

      @tailrec def combineRest(idx: Int, i: Iterator[Source[T, _]]): SourceShape[U] =
        if (i.hasNext) {
          i.next() ~> c.in(idx)
          combineRest(idx + 1, i)
        } else SourceShape(c.out)

      combineRest(2, rest.iterator)
    })


//Combines two sources with fan-in strategy like `Merge` or `Concat` and returns `Source` with a materialized value.
def combineMat[T, U, M1, M2, M](first: Source[T, M1], second: Source[T, M2])(strategy: Int ⇒ Graph[UniformFanInShape[T, U], NotUsed])(matF: (M1, M2) ⇒ M): Source[U, M] = {
    val secondPartiallyCombined = GraphDSL.create(second) { implicit b ⇒ secondShape ⇒
      import GraphDSL.Implicits._
      val c = b.add(strategy(2))
      secondShape ~> c.in(1)
      FlowShape(c.in(0), c.out)
    }
    first.viaMat(secondPartiallyCombined)(matF)
}
//Combine the elements of multiple streams into a stream of sequences.
def zipN[T](sources: immutable.Seq[Source[T, _]]): Source[immutable.Seq[T], NotUsed] = 
    zipWithN(ConstantFun.scalaIdentityFunction[immutable.Seq[T]])(sources).addAttributes(DefaultAttributes.zipN)
//Combine the elements of multiple streams into a stream of sequences using a combiner function.
def zipWithN[T, O](zipper: immutable.Seq[T] ⇒ O)(sources: immutable.Seq[Source[T, _]]): Source[O, NotUsed] = {
    val source = sources match {
      case immutable.Seq()       ⇒ empty[O]
      case immutable.Seq(source) ⇒ source.map(t ⇒ zipper(immutable.Seq(t))).mapMaterializedValue(_ ⇒ NotUsed)
      case s1 +: s2 +: ss        ⇒ combine(s1, s2, ss: _*)(ZipWithN(zipper))
    }

    source.addAttributes(DefaultAttributes.zipWithN)
}

///Shape and Predefined shapes
abstract class akka.stream.Shape extends AnyRef
    A Shape describes the inlets and outlets of a Graph. 
    Inlet.apply[T](name: String): Inlet[T]
    Outlet.apply[T](name: String): Outlet[T]  
    Instance Constructors
        new Shape() 
    Abstract Value Members
        abstract def deepCopy(): Shape
            Create a copy of this Shape object, returning the same type as the original; 
            this constraint can unfortunately not be expressed in the type system.
        abstract def inlets: Seq[Inlet[_]]
            Scala API: get a list of all input ports
        abstract def outlets: Seq[Outlet[_]]
            Scala API: get a list of all output ports
    Concrete Value Members
        def getInlets: List[Inlet[_]]
            Java API: get a list of all input ports
        def getOutlets: List[Outlet[_]]
            Java API: get a list of all output ports
        def hasSamePortsAndShapeAs(s: Shape): Boolean
            Compare this to another shape and determine whether the arrangement of ports is the same (including their ordering).
        def hasSamePortsAs(s: Shape): Boolean
            Compare this to another shape and determine whether the set of ports is the same (ignoring their ordering).
        def requireSamePortsAndShapeAs(s: Shape): Unit
            Asserting version of #hasSamePortsAndShapeAs.
        def requireSamePortsAs(s: Shape): Unit
            Asserting version of #hasSamePortsAs.

//Predefined Shape 
1.SourceShape, SinkShape, FlowShape for simpler shapes,
2.UniformFanInShape and UniformFanOutShape for junctions with multiple input (or output) ports of the same type,
3.FanInShape1, FanInShape2, …, FanOutShape1, FanOutShape2, … for junctions with multiple input (or output) ports of different types.

    


///Building reusable Graph components - Define CustomS Shape 

//Example - junction will have two input ports of type I (for the normal and priority jobs) 
//and an output port of type O

// A shape represents the input and output ports of a reusable
// processing module
case class PriorityWorkerPoolShape[In, Out](
  jobsIn:         Inlet[In],
  priorityJobsIn: Inlet[In],
  resultsOut:     Outlet[Out]) extends Shape {

  // It is important to provide the list of all input and output
  // ports with a stable order. Duplicates are not allowed.
  override val inlets: immutable.Seq[Inlet[_]] =  jobsIn :: priorityJobsIn :: Nil
  override val outlets: immutable.Seq[Outlet[_]] =  resultsOut :: Nil

  // A Shape must be able to create a copy of itself. Basically
  // it means a new instance with copies of the ports
  override def deepCopy() = PriorityWorkerPoolShape(
    jobsIn.carbonCopy(),
    priorityJobsIn.carbonCopy(),
    resultsOut.carbonCopy())

}
//OR , Since our shape has two input ports and one output port, use  FanInShape 
//Privide akka.stream.FanInShape.Init and all methods are pre-implemented 
//N in, 1 out 
sealed trait akka.stream.FanInShape.Init[O] extends AnyRef 
    abstract def inlets: Seq[Inlet[_]]
    abstract def name: String
    abstract def outlet: Outlet[O] 
abstract class FanInShape[+O] extends Shape 
    new FanInShape(init: Init[O]) 
    protected def construct(init: Init[O @uncheckedVariance]): FanInShape[O]
    protected def newInlet[T](name: String): Inlet[T] 
object FanInShape
    sealed trait Init[O]
    final case class Name[O](name: String)
    final case class Ports[O](outlet: Outlet[O], inlets: Seq[Inlet[_]]) extends Init[O] with Product with Serializable 
final case class Name[O](override val name: String) extends Init[O] {
    override def outlet: Outlet[O] = Outlet(s"$name.out")
    override def inlets: immutable.Seq[Inlet[_]] = Nil
  }
final case class Ports[O](override val outlet: Outlet[O], override val inlets: immutable.Seq[Inlet[_]]) extends Init[O] {
    override def name: String = "FanIn"
}
//For 1 in, N out 
abstract class FanOutShape[-I] extends Shape 
    new FanOutShape(init: Init[I]) 
    abstract def construct(init: Init[I]): FanOutShape[I] 
    protected def newOutlet[T](name: String): Outlet[T] 
sealed trait akka.stream.FanOutShape.Init[I] extends AnyRef   
    abstract def inlet: Inlet[I]
    abstract def name: String
    abstract def outlets: Seq[Outlet[_]]  
object FanOutShape
    sealed trait Init[I]
    final case class Name[I](name: String)
    final case class Ports[I](inlet: Inlet[I], outlets: Seq[Outlet[_]]) extends Init[I] with Product with Serializable 
final case class Name[I](override val name: String) extends Init[I] {
    override def inlet: Inlet[I] = Inlet(s"$name.in")
    override def outlets: immutable.Seq[Outlet[_]] = Nil
  }
final case class Ports[I](override val inlet: Inlet[I], override val outlets: immutable.Seq[Outlet[_]]) extends Init[I] {
    override def name: String = "FanOut"
}
    
//code 
import FanInShape.{ Init, Name }

class PriorityWorkerPoolShape2[In, Out](_init: Init[Out] = Name("PriorityWorkerPool")) extends FanInShape[Out](_init) {
  protected override def construct(i: Init[Out]) = new PriorityWorkerPoolShape2(i)

  val jobsIn = newInlet[In]("jobsIn")
  val priorityJobsIn = newInlet[In]("priorityJobsIn")
  // Outlet[Out] with name "out" is automatically created
}

//Example - wire up a Graph that represents our worker pool. 
//First, we will merge incoming normal and priority jobs using MergePreferred, 
//then we will send the jobs to a Balance junction which will fan-out to a configurable number of workers (flows),
//finally we merge all these results together and send them out through our only output port. 


object PriorityWorkerPool {
  def apply[In, Out](
    worker:      Flow[In, Out, Any],
    workerCount: Int): Graph[PriorityWorkerPoolShape[In, Out], NotUsed] = {
            GraphDSL.create() { implicit b =>
              import GraphDSL.Implicits._

              val priorityMerge = b.add(MergePreferred[In](1))
              val balance = b.add(Balance[In](workerCount))
              val resultsMerge = b.add(Merge[Out](workerCount))

              // After merging priority and ordinary jobs, we feed them to the balancer
              priorityMerge ~> balance

              // Wire up each of the outputs of the balancer to a worker flow
              // then merge them back
              for (i <- 0 until workerCount)
                balance.out(i) ~> worker ~> resultsMerge.in(i)

              // We now expose the input ports of the priorityMerge and the output
              // of the resultsMerge as our PriorityWorkerPool ports
              // -- all neatly wrapped in our domain specific Shape
              PriorityWorkerPoolShape(
                jobsIn = priorityMerge.in(0),
                priorityJobsIn = priorityMerge.preferred,
                resultsOut = resultsMerge.out)
            }

  }

}

//Usage - simulates some simple workers and jobs using plain strings and prints out the results. 


val worker1 = Flow[String].map("step 1 " + _)
val worker2 = Flow[String].map("step 2 " + _)

RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val priorityPool1 = b.add(PriorityWorkerPool(worker1, 4))
  val priorityPool2 = b.add(PriorityWorkerPool(worker2, 2))

  Source(1 to 100).map("job: " + _) ~> priorityPool1.jobsIn
  Source(1 to 100).map("priority job: " + _) ~> priorityPool1.priorityJobsIn

  priorityPool1.resultsOut ~> priorityPool2.jobsIn
  Source(1 to 100).map("one-step, priority " + _) ~> priorityPool2.priorityJobsIn

  priorityPool2.resultsOut ~> Sink.foreach(println)
  ClosedShape
}).run()




///*** Akka Stream - Bidirectional Flows
//A graph topology that is often useful is that of two flows going in opposite directions. 

//example a codec stage that serializes outgoing messages and deserializes incoming octet streams. 
//Another such stage could add a framing protocol that attaches a length header to outgoing data 
//and parses incoming frames back into the original octet stream chunks. 

//These two stages are meant to be composed, applying one atop the other as part of a protocol stack. 
//Use BidiFlow 

/**
 * A bidirectional flow of elements that consequently has two inputs and two
 * outputs, arranged like this:
 *
 * {{{
 *        +------+
 *  In1 ~>|      |~> Out1
 *        | bidi |
 * Out2 <~|      |<~ In2
 *        +------+
 * }}}
 */
//*Reference 
final class BidiFlow[-I1, +O1, -I2, +O2, +Mat] extends Graph[BidiShape[I1, O1, I2, O2], Mat]
    Instance Constructors
        new BidiFlow(traversalBuilder: TraversalBuilder, shape: BidiShape[I1, O1, I2, O2]) 
    Type Members
        type Shape = BidiShape[I1, O1, I2, O2]
            Type-level accessor for the shape parameter of this graph.
    Value Members
        def addAttributes(attr: Attributes): BidiFlow[I1, O1, I2, O2, Mat]
            Add the given attributes to this Source.
        def asJava: javadsl.BidiFlow[I1, O1, I2, O2, Mat]
        def async(dispatcher: String, inputBufferSize: Int): BidiFlow[I1, O1, I2, O2, Mat]
            Put an asynchronous boundary around this BidiFlow
        def async(dispatcher: String): BidiFlow[I1, O1, I2, O2, Mat]
            Put an asynchronous boundary around this BidiFlow
        def async: BidiFlow[I1, O1, I2, O2, Mat]
            Put an asynchronous boundary around this BidiFlow
        def atop[OO1, II2, Mat2](bidi: Graph[BidiShape[O1, OO1, II2, I2], Mat2]): BidiFlow[I1, OO1, II2, O2, Mat]
            Add the given BidiFlow as the next step in a bidirectional transformation pipeline.
        def atopMat[OO1, II2, Mat2, M](bidi: Graph[BidiShape[O1, OO1, II2, I2], Mat2])(combine: (Mat, Mat2) ⇒ M): BidiFlow[I1, OO1, II2, O2, M]
            Add the given BidiFlow as the next step in a bidirectional transformation pipeline.
        def join[Mat2](flow: Graph[FlowShape[O1, I2], Mat2]): Flow[I1, O2, Mat]
            Add the given Flow as the final step in a bidirectional transformation pipeline.
        def joinMat[Mat2, M](flow: Graph[FlowShape[O1, I2], Mat2])(combine: (Mat, Mat2) ⇒ M): Flow[I1, O2, M]
            Add the given Flow as the final step in a bidirectional transformation pipeline.
        def mapMaterializedValue[Mat2](f: (Mat) ⇒ Mat2): BidiFlow[I1, O1, I2, O2, Mat2]
            Transform only the materialized value of this BidiFlow, leaving all other properties as they were.
        def named(name: String): BidiFlow[I1, O1, I2, O2, Mat]
            Add a name attribute to this Flow.
        def reversed: BidiFlow[I2, O2, I1, O1, Mat]
            Turn this BidiFlow around by 180 degrees, logically flipping it upside down in a protocol stack.
        val shape: BidiShape[I1, O1, I2, O2]
        val traversalBuilder: TraversalBuilder
        def withAttributes(attr: Attributes): BidiFlow[I1, O1, I2, O2, Mat]
            Change the attributes of this Source to the given ones and seal the list of attributes.
object BidiFlow
    def bidirectionalIdleTimeout[I, O](timeout: FiniteDuration): BidiFlow[I, I, O, O, NotUsed]
        If the time between two processed elements *in any direction* exceed the provided timeout, the stream is failed with a scala.concurrent.TimeoutException.
    def fromFlows[I1, O1, I2, O2, M1, M2](flow1: Graph[FlowShape[I1, O1], M1], flow2: Graph[FlowShape[I2, O2], M2]): BidiFlow[I1, O1, I2, O2, NotUsed]
        Wraps two Flows to create a BidiFlow.
    def fromFlowsMat[I1, O1, I2, O2, M1, M2, M](flow1: Graph[FlowShape[I1, O1], M1], flow2: Graph[FlowShape[I2, O2], M2])(combine: (M1, M2) ⇒ M): BidiFlow[I1, O1, I2, O2, M]
        Wraps two Flows to create a BidiFlow.
    def fromFunctions[I1, O1, I2, O2](outbound: (I1) ⇒ O1, inbound: (I2) ⇒ O2): BidiFlow[I1, O1, I2, O2, NotUsed]
        Create a BidiFlow where the top and bottom flows are just one simple mapping stage each, expressed by the two functions.
    def fromGraph[I1, O1, I2, O2, Mat](graph: Graph[BidiShape[I1, O1, I2, O2], Mat]): BidiFlow[I1, O1, I2, O2, Mat]
        A graph with the shape of a flow logically is a flow, this method makes it so also in type.
    def identity[A, B]: BidiFlow[A, A, B, B, NotUsed] 
final case class BidiShape[-In1, +Out1, -In2, +Out2](in1: Inlet[In1], out1: Outlet[Out1], in2: Inlet[In2], out2: Outlet[Out2]) extends Shape with Product with Serializable
    A bidirectional flow of elements that consequently has two inputs and two outputs, arranged like this:
           +------+
     In1 ~>|      |~> Out1
           | bidi |
    Out2 <~|      |<~ In2
           +------+
    Instance Constructors
        new BidiShape(top: FlowShape[In1, Out1], bottom: FlowShape[In2, Out2])
            Java API for creating from a pair of unidirectional flows.
        new BidiShape(in1: Inlet[In1], out1: Outlet[Out1], in2: Inlet[In2], out2: Outlet[Out2]) 
    Value Members
        def deepCopy(): BidiShape[In1, Out1, In2, Out2]
            Create a copy of this Shape object, returning the same type as the original; this constraint can unfortunately not be expressed in the type system.
        def getInlets: List[Inlet[_]]
            Java API: get a list of all input ports
        def getOutlets: List[Outlet[_]]
            Java API: get a list of all output ports
        def hasSamePortsAndShapeAs(s: Shape): Boolean
            Compare this to another shape and determine whether the arrangement of ports is the same (including their ordering).
        def hasSamePortsAs(s: Shape): Boolean
            Compare this to another shape and determine whether the set of ports is the same (ignoring their ordering).
        val in1: Inlet[In1]
        val in2: Inlet[In2]
        val inlets: Seq[Inlet[_]]
        val out1: Outlet[Out1]
        val out2: Outlet[Out2]
        val outlets: Seq[Outlet[_]]
        def requireSamePortsAndShapeAs(s: Shape): Unit
            Asserting version of #hasSamePortsAndShapeAs.
        def requireSamePortsAs(s: Shape): Unit
            Asserting version of #hasSamePortsAs.
object BidiShape extends Serializable
    def fromFlows[I1, O1, I2, O2](top: FlowShape[I1, O1], bottom: FlowShape[I2, O2]): BidiShape[I1, O1, I2, O2]
    def of[In1, Out1, In2, Out2](in1: Inlet[In1], out1: Outlet[Out1], in2: Inlet[In2], out2: Outlet[Out2]): BidiShape[In1, Out1, In2, Out2]



    

//Example - STAGE-1:a codec stage that serializes outgoing messages and deserializes incoming octet streams. 
//A bidirectional flow is defined just like a unidirectional Flow 

trait Message
case class Ping(id: Int) extends Message
case class Pong(id: Int) extends Message

def toBytes(msg: Message): ByteString = {
  implicit val order = ByteOrder.LITTLE_ENDIAN
  msg match {
    case Ping(id) => ByteString.newBuilder.putByte(1).putInt(id).result()
    case Pong(id) => ByteString.newBuilder.putByte(2).putInt(id).result()
  }
}

def fromBytes(bytes: ByteString): Message = {
  implicit val order = ByteOrder.LITTLE_ENDIAN
  val it = bytes.iterator
  it.getByte match {
    case 1     => Ping(it.getInt)
    case 2     => Pong(it.getInt)
    case other => throw new RuntimeException(s"parse error: expected 1|2 got $other")
  }
}

val codecVerbose = BidiFlow.fromGraph(GraphDSL.create() { b =>
  // construct and add the top flow, going outbound
  val outbound = b.add(Flow[Message].map(toBytes))
  // construct and add the bottom flow, going inbound
  val inbound = b.add(Flow[ByteString].map(fromBytes))
  // fuse them together into a BidiShape
  BidiShape.fromFlows(outbound, inbound)
})

// this is the same as the above
val codec = BidiFlow.fromFunctions(toBytes _, fromBytes _)

//construct toBytes, fromBytes

def toBytes(msg: Message): ByteString = {
  implicit val order = ByteOrder.LITTLE_ENDIAN
  msg match {
    case Ping(id) => ByteString.newBuilder.putByte(1).putInt(id).result()
    case Pong(id) => ByteString.newBuilder.putByte(2).putInt(id).result()
  }
}

def fromBytes(bytes: ByteString): Message = {
  implicit val order = ByteOrder.LITTLE_ENDIAN
  val it = bytes.iterator
  it.getByte match {
    case 1     => Ping(it.getInt)
    case 2     => Pong(it.getInt)
    case other => throw new RuntimeException(s"parse error: expected 1|2 got $other")
  }
}

//Example - STAGE-2:add a framing protocol that attaches a length header to outgoing data 
//and parses incoming frames back into the original octet stream chunks. 
//since reversing a framing protocol means that any received chunk of bytes may correspond to zero or more messages. 

//using a GraphStage 
val framing = BidiFlow.fromGraph(GraphDSL.create() { b =>
  implicit val order = ByteOrder.LITTLE_ENDIAN

  def addLengthHeader(bytes: ByteString) = {
    val len = bytes.length
    ByteString.newBuilder.putInt(len).append(bytes).result()
  }

  class FrameParser extends GraphStage[FlowShape[ByteString, ByteString]] {

    val in = Inlet[ByteString]("FrameParser.in")
    val out = Outlet[ByteString]("FrameParser.out")
    override val shape = FlowShape.of(in, out)

    override def createLogic(inheritedAttributes: Attributes): GraphStageLogic = new GraphStageLogic(shape) {

      // this holds the received but not yet parsed bytes
      var stash = ByteString.empty
      // this holds the current message length or -1 if at a boundary
      var needed = -1

      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          if (isClosed(in)) run()
          else pull(in)
        }
      })
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val bytes = grab(in)
          stash = stash ++ bytes
          run()
        }

        override def onUpstreamFinish(): Unit = {
          // either we are done
          if (stash.isEmpty) completeStage()
          // or we still have bytes to emit
          // wait with completion and let run() complete when the
          // rest of the stash has been sent downstream
          else if (isAvailable(out)) run()
        }
      })

      private def run(): Unit = {
        if (needed == -1) {
          // are we at a boundary? then figure out next length
          if (stash.length < 4) {
            if (isClosed(in)) completeStage()
            else pull(in)
          } else {
            needed = stash.iterator.getInt
            stash = stash.drop(4)
            run() // cycle back to possibly already emit the next chunk
          }
        } else if (stash.length < needed) {
          // we are in the middle of a message, need more bytes,
          // or have to stop if input closed
          if (isClosed(in)) completeStage()
          else pull(in)
        } else {
          // we have enough to emit at least one message, so do it
          val emit = stash.take(needed)
          stash = stash.drop(needed)
          needed = -1
          push(out, emit)
        }
      }
    }
  }

  val outbound = b.add(Flow[ByteString].map(addLengthHeader))
  val inbound = b.add(Flow[ByteString].via(new FrameParser))
  BidiShape.fromFlows(outbound, inbound)
})

//With these implementations we can build a protocol stack and test it:

/* construct protocol stack
 *         +------------------------------------+
 *         | stack                              |
 *         |                                    |
 *         |  +-------+            +---------+  |
 *    ~>   O~~o       |     ~>     |         o~~O    ~>
 * Message |  | codec | ByteString | framing |  | ByteString
 *    <~   O~~o       |     <~     |         o~~O    <~
 *         |  +-------+            +---------+  |
 *         +------------------------------------+
 */
val stack = codec.atop(framing)

// test it by plugging it into its own inverse and closing the right end
val pingpong = Flow[Message].collect { case Ping(id) => Pong(id) }
val flow = stack.atop(stack.reversed).join(pingpong)
val result = Source((0 to 9).map(Ping)).via(flow).limit(20).runWith(Sink.seq)
Await.result(result, 1.second) should ===((0 to 9).map(Pong))


///*** Akka Stream -  Accessing the materialized value inside the Graph
//to feed back the materialized value of a Graph (partial, closed or backing a Source, Sink, Flow or BidiFlow). 
//This is possible by using builder.materializedValue which gives an Outlet 
//that can be used in the graph as an ordinary Source or outlet,
//and which will eventually emit the materialized value. 

//If the materialized value is needed at more than one place, call materializedValue any number of times to acquire the necessary number of outlets.

//Builder[+M].materializedValue: Outlet[M] 
//Flow[-In, +Out, +Mat], here Mat = Future[Int]
//FlowShape(in: Inlet[I], out: Outlet[O])
//Used  implicit def port2flow[T](from: Outlet[T])(implicit b: Builder[_]): PortOps[T] 
//PortOps[T].mapAsync[T](parallelism: Int)(f: (Out) ⇒ Future[T]): PortOps[T] 
//PortOps[T].outlet: Outlet[Out] 
import GraphDSL.Implicits._
val foldFlow: Flow[Int, Int, Future[Int]] = Flow.fromGraph(GraphDSL.create(Sink.fold[Int, Int](0)(_ + _)) { implicit builder => fold =>
  FlowShape(fold.in, builder.materializedValue.mapAsync(4)(identity).outlet)
})

//Note Three implicits are defined in GraphDSL.Implicits._
implicit def fanOut2flow[I, O](j: UniformFanOutShape[I, O])(implicit b: Builder[_]): PortOps[O]
implicit def flow2flow[I, O](f: FlowShape[I, O])(implicit b: Builder[_]): PortOps[O]
implicit def port2flow[T](from: Outlet[T])(implicit b: Builder[_]): PortOps[T] 

//Be careful not to introduce a cycle 
//where the materialized value actually contributes to the materialized value.

//WRONG - Example : where the materialized Future of a fold is fed back to the fold itself.
import GraphDSL.Implicits._
// This cannot produce any value:
val cyclicFold: Source[Int, Future[Int]] = Source.fromGraph(GraphDSL.create(Sink.fold[Int, Int](0)(_ + _)) { implicit builder => fold =>
  // - Fold cannot complete until its upstream mapAsync completes
  // - mapAsync cannot complete until the materialized Future produced by
  //   fold completes
  // As a result this Source will never emit anything, and its materialited
  // Future will never complete
  builder.materializedValue.mapAsync(4)(identity) ~> fold
  SourceShape(builder.materializedValue.mapAsync(4)(identity).outlet)
})



///*** Akka Stream - Graph cycles, liveness and deadlocks

//EXAMPLE - The graph takes elements from the source, prints them, then broadcasts those elements to a consumer 
//(Sink.ignore ) and to a feedback arc that is merged back into the main stream via a Merge junction.

// WARNING! The graph below deadlocks!
RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val merge = b.add(Merge[Int](2))
  val bcast = b.add(Broadcast[Int](2))

  source ~> merge ~> Flow[Int].map { s => println(s); s } ~> bcast ~> Sink.ignore
            merge                    <~                      bcast
  ClosedShape
})

//Since Akka Streams (and Reactive Streams in general) guarantee bounded processing 
//it means that only a bounded number of elements are buffered over any time span. 
//Since our cycle gains more and more elements, eventually all of its internal buffers become full, 
//backpressuring source forever. 

//To be able to process more elements from source elements would need to leave the cycle somehow.
//by replacing the Merge junction with a MergePreferred
//MergePreferred is unfair as it always tries to consume from a preferred input port 
//if there are elements available before trying the other lower priority input ports.

//Since we feed back through the preferred port it is always guaranteed that the elements in the cycles can flow

// WARNING! The graph below stops consuming from "source" after a few steps
RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val merge = b.add(MergePreferred[Int](1))
  val bcast = b.add(Broadcast[Int](2))

  source ~> merge ~> Flow[Int].map { s => println(s); s } ~> bcast ~> Sink.ignore
            merge.preferred              <~                  bcast
  ClosedShape
})

//we avoided the deadlock, but source is still back-pressured forever, 
//because buffer space is never recovered: 
//the only action we see is the circulation of a couple of initial elements from source.

//To make  cycle both live (not deadlocking) and fair we can introduce a dropping element on the feedback arc. 
//In this case, use buffer() operation giving it a dropping strategy OverflowStrategy.dropHead.
RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val merge = b.add(Merge[Int](2))
  val bcast = b.add(Broadcast[Int](2))

  source ~> merge ~> Flow[Int].map { s => println(s); s } ~> bcast ~> Sink.ignore
      merge <~ Flow[Int].buffer(10, OverflowStrategy.dropHead) <~ bcast
  ClosedShape
})
//OUPUT 
//The flow of elements does not stop, there are always elements printed
//We see that some of the numbers are printed several times over time (due to the feedback loop) but on average the numbers are increasing in the long term

//Note: the core problem was the unbalanced nature of the feedback loop.
// We circumvented this issue by adding a dropping element, 
//TO build a cycle that is balanced from the beginning , replace the Merge junction with a ZipWith. 
//Since ZipWith takes one element from source and feedback arc to inject one element(tuple) into the cycle, 
//we maintain the balance of elements.


// WARNING! The graph below never processes any elements
RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val zip = b.add(ZipWith[Int, Int, Int]((left, right) => right))
  val bcast = b.add(Broadcast[Int](2))

  source ~> zip.in0
  zip.out.map { s => println(s); s } ~> bcast ~> Sink.ignore
  zip.in1             <~                bcast
  ClosedShape
})

//OUTPUT -  no element is printed at all
//In order to get the first element from source into the cycle we need an already existing element in the cycle
//In order to get an initial element in the cycle we need an element from source

//These two conditions are a typical “chicken-and-egg” problem. 
//The solution is to inject an initial element into the cycle that is independent from source. 
//Use a Concat junction on the backwards arc that injects a single element using Source.single.
RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val zip = b.add(ZipWith((left: Int, right: Int) => left))
  val bcast = b.add(Broadcast[Int](2))
  val concat = b.add(Concat[Int]())
  val start = Source.single(0)

  source ~> zip.in0
  zip.out.map { s => println(s); s } ~> bcast ~> Sink.ignore
  zip.in1 <~ concat <~ start
             concat         <~          bcast
  ClosedShape
})


///*** Akka Stream - Buffers and working with rate

///Buffers for asynchronous stages
//To run a stage asynchronously it has to be marked explicitly as such using the .async method. 
//Being run asynchronously means that a stage, after handing out an element to its downstream 
//consumer is able to immediately process the next message. 
Source(1 to 3)
  .map { i => println(s"A: $i"); i }.async
  .map { i => println(s"B: $i"); i }.async
  .map { i => println(s"C: $i"); i }.async
  .runWith(Sink.ignore)
//OUTPUT , order is not A:1, B:1, C:1, A:2, B:2, C:2
A: 1
A: 2
B: 1
A: 3
B: 2
C: 1
B: 3
C: 2
C: 3

//While pipelining in general increases throughput, 
//in practice there is a cost of passing an element through the asynchronous (and therefore thread crossing) boundary which is significant. 

//Solution - Akka Streams introduces a buffer for every asynchronous processing stage.
akka.stream.materializer.max-input-buffer-size = 16
//OR 
val materializer = ActorMaterializer(
  ActorMaterializerSettings(system)
    .withInputBuffer(
      initialSize = 64,
      maxSize = 64))

//If the buffer size needs to be set for segments of a Flow only, 
//it is possible by defining a separate Flow with these attributes:
val section = Flow[Int].map(_ * 2).async
  .addAttributes(Attributes.inputBuffer(initial = 1, max = 1)) // the buffer size of this map is 1
val flow = section.via(Flow[Int].map(_ / 2)).async // the buffer size of this map is the default


///Buffers in Akka Streams
//Source[Out,Mat].buffer(size: Int, overflowStrategy: OverflowStrategy): Source[Out,Mat]
object OverflowStrategy extends Serializable 
    def backpressure: OverflowStrategy
        If the buffer is full when a new element is available this strategy backpressures the upstream publisher until space becomes available in the buffer.
    def dropBuffer: OverflowStrategy
        If the buffer is full when a new element arrives, drops all the buffered elements to make space for the new element.
    def dropHead: OverflowStrategy
        If the buffer is full when a new element arrives, drops the oldest element from the buffer to make space for the new element.
    def dropNew: OverflowStrategy
        If the buffer is full when a new element arrives, drops the new element.
    def dropTail: OverflowStrategy
        If the buffer is full when a new element arrives, drops the youngest element from the buffer to make space for the new element.
    def fail: OverflowStrategy
        If the buffer is full when a new element is available this strategy completes the stream with failure.

        
// Getting a stream of jobs from an imaginary external system as a Source
val jobs: Source[Job, NotUsed] = inboundJobsConnector()
jobs.buffer(1000, OverflowStrategy.backpressure)

jobs.buffer(1000, OverflowStrategy.dropTail)

jobs.buffer(1000, OverflowStrategy.dropNew)

jobs.buffer(1000, OverflowStrategy.dropHead)

//Compared to the dropping strategies above, 
//dropBuffer drops all the 1000 jobs it has enqueued once the buffer gets full. 
jobs.buffer(1000, OverflowStrategy.dropBuffer)
//OR 
jobs.buffer(1000, OverflowStrategy.fail)



///Understanding conflate
//def conflate[O2 >: Out](aggregate: (O2, O2) => O2): Repr[O2]
//def conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]

//When a fast producer can not be informed to slow down by backpressure 
//conflate might be useful to combine elements from a producer until a demand signal comes from a consumer.

//Example - summarizes fast stream of elements to a standard deviation, mean and count of elements 
//that have arrived while the stats have been calculated.
//scala.collection.immutable.Seq(_) = (x$1) => scala.collection.immutable.Seq(x$1))
val statsFlow = Flow[Double]
  .conflateWithSeed(immutable.Seq(_))(_ :+ _) //Creates a Seq of Double 
  .map { s =>  //Seq 
    val μ = s.sum / s.size
    val se = s.map(x => pow(x - μ, 2))
    val σ = sqrt(se.sum / se.size)
    (σ, μ, s.size)
  }

//Another possible use of conflate is to not consider all elements for summary 
//when the producer starts getting too fast. 
//Example - conflate can be used to randomly drop elements when the consumer is not able to keep up with the producer.
val p = 0.01
val sampleFlow = Flow[Double]
  .conflateWithSeed(immutable.Seq(_)) {
    case (acc, elem) if Random.nextDouble < p => acc :+ elem
    case (acc, _)                             => acc
  }
  .mapConcat(identity)



///Understanding expand
//def expand[U](extrapolate: (Out) => Iterator[U]): Repr[U]

//Expand helps to deal with slow producers which are unable to keep up with the demand coming from consumers. 
//Expand allows to extrapolate a value to be sent as an element to a consumer.

//Example - Flow sends the same element to consumer when producer does not send any new elements.
val lastFlow = Flow[Double]
  .expand(Iterator.continually(_))


//Expand also allows to keep some state between demand requests from the downstream. 
//Example - a flow that tracks and reports a drift between fast consumer and slow producer.
val driftFlow = Flow[Double]
      .expand(i => Iterator.from(0).map(i -> _))


///*** Akka Stream - Dynamic stream handling

//Controlling graph completion with KillSwitch
//A KillSwitch allows the completion of graphs of FlowShape from the outside
trait KillSwitch extends AnyRef
	A KillSwitch allows completion of Graphs from the outside by completing Graphs of FlowShape linked to the switch. Depending on whether the KillSwitch is a UniqueKillSwitch or a SharedKillSwitch one or multiple streams might be linked with the switch. For details see the documentation of the concrete subclasses of this interface.
    abstract def abort(ex: Throwable): Unit
        After calling KillSwitch#abort() the linked Graphs of FlowShape are failed.
    abstract def shutdown(): Unit
        After calling KillSwitch#shutdown() the linked Graphs of FlowShape are completed normally.
object KillSwitches
	Creates shared or single kill switches which can be used to control completion of graphs from the outside.
    def shared(name: String): SharedKillSwitch
        Creates a new SharedKillSwitch with the given name that can be used to control the completion of multiple streams from the outside simultaneously.
    def single[T]: Graph[FlowShape[T, T], UniqueKillSwitch]
        Creates a new Graph of FlowShape that materializes to an external switch that allows external completion of that unique materialization.
    def singleBidi[T1, T2]: Graph[BidiShape[T1, T1, T2, T2], UniqueKillSwitch]
        Creates a new Graph of FlowShape that materializes to an external switch that allows external completion of that unique materialization.


//UniqueKillSwitch - KillSwitches.single
//UniqueKillSwitch allows to control the completion of one materialized Graph of FlowShape. 

//shutdown 
val countingSrc = Source(Stream.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int]

val (killSwitch, last) = countingSrc
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(lastSnk)(Keep.both)
  .run()

doSomethingElse()

killSwitch.shutdown()

Await.result(last, 1.second) shouldBe 2

//Abort
val countingSrc = Source(Stream.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int]

val (killSwitch, last) = countingSrc
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(lastSnk)(Keep.both).run()

val error = new RuntimeException("boom!")
killSwitch.abort(error)

Await.result(last.failed, 1.second) shouldBe error



//SharedKillSwitch - KillSwitches.shared
//A SharedKillSwitch allows to control the completion of an arbitrary number graphs of FlowShape. 
//It can be materialized multiple times via its flow method, 
//and all materialized graphs linked to it are controlled by the switch

//Shutdown
val countingSrc = Source(Stream.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int]
val sharedKillSwitch = KillSwitches.shared("my-kill-switch")

val last = countingSrc
  .via(sharedKillSwitch.flow)
  .runWith(lastSnk)

val delayedLast = countingSrc
  .delay(1.second, DelayOverflowStrategy.backpressure)
  .via(sharedKillSwitch.flow)
  .runWith(lastSnk)

doSomethingElse()

sharedKillSwitch.shutdown()

Await.result(last, 1.second) shouldBe 2
Await.result(delayedLast, 1.second) shouldBe 1


//Abort
val countingSrc = Source(Stream.from(1)).delay(1.second)
val lastSnk = Sink.last[Int]
val sharedKillSwitch = KillSwitches.shared("my-kill-switch")

val last1 = countingSrc.via(sharedKillSwitch.flow).runWith(lastSnk)
val last2 = countingSrc.via(sharedKillSwitch.flow).runWith(lastSnk)

val error = new RuntimeException("boom!")
sharedKillSwitch.abort(error)

Await.result(last1.failed, 1.second) shouldBe error
Await.result(last2.failed, 1.second) shouldBe error


///Dynamic fan-in and fan-out with MergeHub, BroadcastHub and PartitionHub
        

//There are many cases when consumers or producers of a certain service (represented as a Sink, Source, or possibly Flow) are dynamic and not known in advance. 
//The Graph DSL does not allow to represent this, all connections of the graph must be known in advance 
//and must be connected upfront. 
//To allow dynamic fan-in and fan-out streaming, the Hubs should be used. 
//They provide means to construct Sink and Source pairs that are “attached” to each other, 
//but one of them can be materialized multiple times to implement dynamic fan-in or fan-out.

///Using the MergeHub
object MergeHub
	A MergeHub is a special streaming hub that is able to collect streamed elements from a dynamic set of producers. It consists of two parts, a Source and a Sink. The Source streams the element to a consumer from its merged inputs. Once the consumer has been materialized, the Source returns a materialized value which is the corresponding Sink. This Sink can then be materialized arbitrary many times, where each of the new materializations will feed its consumed elements to the original Source.
    def source[T]: Source[T, Sink[T, NotUsed]]
        Creates a Source that emits elements merged from a dynamic set of producers.
    def source[T](perProducerBufferSize: Int): Source[T, Sink[T, NotUsed]]
        Creates a Source that emits elements merged from a dynamic set of producers.

        
//A MergeHub allows to implement a dynamic fan-in junction point in a graph 
//where elements coming from different producers are emitted in a First-Comes-First-Served fashion. 
//If the consumer cannot keep up then all of the producers are backpressured. 

//The hub itself comes as a Source to which the single consumer can be attached. 
//It is not possible to attach any producers until this Source has been materialized (started). 
//This is ensured by the fact that we only get the corresponding Sink as a materialized value. 

// A simple consumer that will print to the console for now
val consumer = Sink.foreach(println)

// Attach a MergeHub Source to the consumer. This will materialize to a
// corresponding Sink.
val runnableGraph: RunnableGraph[Sink[String, NotUsed]] =
  MergeHub.source[String](perProducerBufferSize = 16).to(consumer)

// By running/materializing the consumer we get back a Sink, and hence
// now have access to feed elements into it. This Sink can be materialized
// any number of times, and every element that enters the Sink will
// be consumed by our consumer.
val toConsumer: Sink[String, NotUsed] = runnableGraph.run()

// Feeding two independent sources into the hub.
Source.single("Hello!").runWith(toConsumer)
Source.single("Hub!").runWith(toConsumer)


///Using the BroadcastHub
object BroadcastHub
	A BroadcastHub is a special streaming hub that is able to broadcast streamed elements to a dynamic set of consumers. It consists of two parts, a Sink and a Source. The Sink broadcasts elements from a producer to the actually live consumers it has. Once the producer has been materialized, the Sink it feeds into returns a materialized value which is the corresponding Source. This Source can be materialized an arbitrary number of times, where each of the new materializations will receive their elements from the original Sink.
    def sink[T]: Sink[T, Source[T, NotUsed]]
        Creates a Sink that receives elements from its upstream producer and broadcasts them to a dynamic set of consumers.
    def sink[T](bufferSize: Int): Sink[T, Source[T, NotUsed]]
        Creates a Sink that receives elements from its upstream producer and broadcasts them to a dynamic set of consumers.

//A BroadcastHub can be used to consume elements from a common producer by a dynamic set of consumers. 
//The rate of the producer will be automatically adapted to the slowest consumer. 

//In this case, the hub is a Sink to which the single producer must be attached first. 
//Consumers can only be attached once the Sink has been materialized (i.e. the producer has been started). 

// A simple producer that publishes a new "message" every second
val producer = Source.tick(1.second, 1.second, "New message")

// Attach a BroadcastHub Sink to the producer. This will materialize to a
// corresponding Source.
// (We need to use toMat and Keep.right since by default the materialized
// value to the left is used)
val runnableGraph: RunnableGraph[Source[String, NotUsed]] =
  producer.toMat(BroadcastHub.sink(bufferSize = 256))(Keep.right)

// By running/materializing the producer, we get back a Source, which
// gives us access to the elements published by the producer.
val fromProducer: Source[String, NotUsed] = runnableGraph.run()

// Print out messages from the producer in two independent consumers
fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.runForeach(msg => println("consumer2: " + msg))


///Combining dynamic stages to build a simple Publish-Subscribe service

//example that builds a Flow representing a publish-subscribe channel.
//The input of the Flow is published to all subscribers while the output streams all the elements published.

// Obtain a Sink and Source which will publish and receive from the "bus" respectively.
val (sink, source) =
  MergeHub.source[String](perProducerBufferSize = 16)
    .toMat(BroadcastHub.sink(bufferSize = 256))(Keep.both)
    .run()

// Ensure that the Broadcast output is dropped if there are no listening parties.
// If this dropping Sink is not attached, then the broadcast hub will not drop any
// elements itself when there are no subscribers, backpressuring the producer instead.
source.runWith(Sink.ignore)

// We create now a Flow that represents a publish-subscribe channel using the above
// started stream as its "topic". We add two more features, external cancellation of
// the registration and automatic cleanup for very slow subscribers.
val busFlow: Flow[String, String, UniqueKillSwitch] =
  Flow.fromSinkAndSource(sink, source)
    .joinMat(KillSwitches.singleBidi[String, String])(Keep.right)
    .backpressureTimeout(3.seconds)

val switch: UniqueKillSwitch =
  Source.repeat("Hello world!")
    .viaMat(busFlow)(Keep.right)
    .to(Sink.foreach(println))
    .run()

// Shut down externally
switch.shutdown()





///Using the PartitionHub
object PartitionHub
	A PartitionHub is a special streaming hub that is able to route streamed elements to a dynamic set of consumers. It consists of two parts, a Sink and a Source. The Sink e elements from a producer to the actually live consumers it has. The selection of consumer is done with a function. Each element can be routed to only one consumer. Once the producer has been materialized, the Sink it feeds into returns a materialized value which is the corresponding Source. This Source can be materialized an arbitrary number of times, where each of the new materializations will receive their elements from the original Sink.
    trait ConsumerInfo 
    def sink[T](partitioner: (Int, T) ⇒ Int, startAfterNrOfConsumers: Int, bufferSize: Int = defaultBufferSize): Sink[T, Source[T, NotUsed]]
        Creates a Sink that receives elements from its upstream producer and routes them to a dynamic set of consumers.
    def statefulSink[T](partitioner: () ⇒ (ConsumerInfo, T) ⇒ Long, startAfterNrOfConsumers: Int, bufferSize: Int = defaultBufferSize): Sink[T, Source[T, NotUsed]]
        Creates a Sink that receives elements from its upstream producer and routes them to a dynamic set of consumers.
trait ConsumerInfo extends javadsl.PartitionHub.ConsumerInfo
    Abstract Value Members
    abstract def consumerIdByIdx(idx: Int): Long
        Obtain consumer identifier by index
    abstract def consumerIds: IndexedSeq[Long]
        Sequence of all identifiers of current consumers.
    abstract def getConsumerIds: List[Long]
        Sequence of all identifiers of current consumers.
    abstract def queueSize(consumerId: Long): Int
        Approximate number of buffered elements for a consumer.
    abstract def size: Int
        Number of attached consumers.


//A PartitionHub can be used to route elements from a common producer to a dynamic set of consumers. 
//The selection of consumer is done with a function. 
//Each element can be routed to only one consumer.

//The rate of the producer will be automatically adapted to the slowest consumer. 
//In this case, the hub is a Sink to which the single producer must be attached first. 
//Consumers can only be attached once the Sink has been materialized (i.e. the producer has been started). 


// A simple producer that publishes a new "message-" every second
val producer = Source.tick(1.second, 1.second, "message")
  .zipWith(Source(1 to 100))((a, b) => s"$a-$b")

// Attach a PartitionHub Sink to the producer. This will materialize to a
// corresponding Source.
// (We need to use toMat and Keep.right since by default the materialized
// value to the left is used)
val runnableGraph: RunnableGraph[Source[String, NotUsed]] =
  producer.toMat(PartitionHub.sink(
    (size, elem) => math.abs(elem.hashCode) % size,
    startAfterNrOfConsumers = 2, bufferSize = 256))(Keep.right)

// By running/materializing the producer, we get back a Source, which
// gives us access to the elements published by the producer.
val fromProducer: Source[String, NotUsed] = runnableGraph.run()

// Print out messages from the producer in two independent consumers
fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.runForeach(msg => println("consumer2: " + msg))




///The above example illustrate a stateless partition function. 
//For more advanced stateful routing the statefulSink can be used. 
//Here is an example of a stateful round-robin function:

// A simple producer that publishes a new "message-" every second
val producer = Source.tick(1.second, 1.second, "message")
  .zipWith(Source(1 to 100))((a, b) => s"$a-$b")

// New instance of the partitioner function and its state is created
// for each materialization of the PartitionHub.
def roundRobin(): (PartitionHub.ConsumerInfo, String) => Long = {
  var i = -1L

  (info, elem) => {
    i += 1
    info.consumerIdByIdx((i % info.size).toInt)
  }
}

// Attach a PartitionHub Sink to the producer. This will materialize to a
// corresponding Source.
// (We need to use toMat and Keep.right since by default the materialized
// value to the left is used)
val runnableGraph: RunnableGraph[Source[String, NotUsed]] =
  producer.toMat(PartitionHub.statefulSink(
    () => roundRobin(),
    startAfterNrOfConsumers = 2, bufferSize = 256))(Keep.right)

// By running/materializing the producer, we get back a Source, which
// gives us access to the elements published by the producer.
val fromProducer: Source[String, NotUsed] = runnableGraph.run()

// Print out messages from the producer in two independent consumers
fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.runForeach(msg => println("consumer2: " + msg))



//Example - type of routing is to prefer routing to the fastest consumers. 
//The ConsumerInfo has an accessor queueSize that is approximate number of buffered elements for a consumer. 
//Larger value than other consumers could be an indication of that the consumer is slow. 
//Note that this is a moving target since the elements are consumed concurrently. H
//ere is an example of a hub that routes to the consumer with least buffered elements:
val producer = Source(0 until 100)

// ConsumerInfo.queueSize is the approximate number of buffered elements for a consumer.
// Note that this is a moving target since the elements are consumed concurrently.
val runnableGraph: RunnableGraph[Source[Int, NotUsed]] =
  producer.toMat(PartitionHub.statefulSink(
    () => (info, elem) => info.consumerIds.minBy(id => info.queueSize(id)),
    startAfterNrOfConsumers = 2, bufferSize = 16))(Keep.right)

val fromProducer: Source[Int, NotUsed] = runnableGraph.run()

fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.throttle(10, 100.millis, 10, ThrottleMode.Shaping)
  .runForeach(msg => println("consumer2: " + msg))

  
///*** Akka Stream - Error Handling in Streams

//to avoid complete stream failure, this can be done in a few different ways:
1.recover to emit a final element then complete the stream normally on upstream failure
2.recoverWithRetries to create a new upstream and start consuming from that on failure
3.Restarting sections of the stream after a backoff
4.Using a supervision strategy for stages that support it
5.a common pattern is to wrap the stream inside an actor, 
  and have the actor restart the entire stream on failure.
  
  
///Logging errors
Source(-5 to 5)
  .map(1 / _) //throwing ArithmeticException: / by zero
  .log("error logging")
  .runWith(Sink.ignore)

  
///Recover, def recover[T >: Out](pf: PartialFunction[Throwable, T]): Repr[T]
//recover allows you to emit a final element and then complete the stream on an upstream failure. 
Source(0 to 6).map(n =>
  if (n < 5) n.toString
  else throw new RuntimeException("Boom!")
).recover {
  case _: RuntimeException => "stream truncated"
}.runForeach(println)

//This will output:
    0
    1
    2
    3
    4
    stream truncated


///Recover with retries - recoverWithRetries[T >: Out](attempts: Int, pf: PartialFunction[Throwable, Graph[SourceShape[T], NotUsed]]): Repr[T]
//recoverWithRetries allows you to put a new upstream in place of the failed one, r
//ecovering stream failures up to a specified maximum number of times.
val planB = Source(List("five", "six", "seven", "eight"))

Source(0 to 10).map(n =>
  if (n < 5) n.toString
  else throw new RuntimeException("Boom!")
).recoverWithRetries(attempts = 1, {
  case _: RuntimeException => planB
}).runForeach(println)

//This will output:
    0
    1
    2
    3
    4
    five
    six
    seven
    eight



///Delayed restarts with a backoff stage
//Just as Akka provides the backoff supervision pattern for actors, 
//Akka streams also provides a RestartSource, RestartSink and RestartFlow for implementing exponential backoff supervision strategy, 
//starting a stage again when it fails or completes, each time with a growing time delay between restarts.

object akka.stream.scaladsl.RestartSource
    def onFailuresWithBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(sourceFactory: () ⇒ Source[T, _]): Source[T, NotUsed]
        Wrap the given Source with a Source that will restart it when it fails using an exponential backoff.
    def onFailuresWithBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(sourceFactory: () ⇒ Source[T, _]): Source[T, NotUsed]
        Wrap the given Source with a Source that will restart it when it fails using an exponential backoff.
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(sourceFactory: () ⇒ Source[T, _]): Source[T, NotUsed]
        Wrap the given Source with a Source that will restart it when it fails or complete using an exponential backoff.
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(sourceFactory: () ⇒ Source[T, _]): Source[T, NotUsed]
        Wrap the given Source with a Source that will restart it when it fails or complete using an exponential backoff.
object akka.stream.scaladsl.RestartSink 
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(sinkFactory: () ⇒ Sink[T, _]): Sink[T, NotUsed]
        Wrap the given Sink with a Sink that will restart it when it fails or complete using an exponential backoff.
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(sinkFactory: () ⇒ Sink[T, _]): Sink[T, NotUsed]
        Wrap the given Sink with a Sink that will restart it when it fails or complete using an exponential backoff.
object akka.stream.scaladsl.RestartFlow
    def onFailuresWithBackoff[In, Out](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(flowFactory: () ⇒ Flow[In, Out, _]): Flow[In, Out, NotUsed]
        Wrap the given Flow with a Flow that will restart it when it fails using an exponential backoff.
    def withBackoff[In, Out](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(flowFactory: () ⇒ Flow[In, Out, _]): Flow[In, Out, NotUsed]
        Wrap the given Flow with a Flow that will restart it when it fails or complete using an exponential backoff.
    def withBackoff[In, Out](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(flowFactory: () ⇒ Flow[In, Out, _]): Flow[In, Out, NotUsed]
        Wrap the given Flow with a Flow that will restart it when it fails or complete using an exponential backoff.
        
//Example -  create a backoff supervisor using akka.stream.scaladsl.RestartSource 
//which will supervise the given Source. 
//The Source in this case is a stream of Server Sent Events, produced by akka-http. 
//If the stream fails or completes at any point, the request will be made again, 
//in increasing intervals of 3, 6, 12, 24 and finally 30 seconds 
//(at which point it will remain capped due to the maxBackoff parameter):

val restartSource = RestartSource.withBackoff(
  minBackoff = 3.seconds,
  maxBackoff = 30.seconds,
  randomFactor = 0.2, // adds 20% "noise" to vary the intervals slightly
  maxRestarts = 20 // limits the amount of restarts to 20
) { () =>
  // Create a source from a future of a source
  Source.fromFutureSource {
    // Make a single request with akka-http
    Http().singleRequest(HttpRequest(
      uri = "http://example.com/eventstream"
    ))
      // Unmarshall it as a source of server sent events
      .flatMap(Unmarshal(_).to[Source[ServerSentEvent, NotUsed]])
  }
}

//The above RestartSource will never terminate unless the Sink it’s fed into cancels. 
// use it in combination with a KillSwitch, so that you can terminate it when needed:
val killSwitch = restartSource
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(Sink.foreach(event => println(s"Got event: $event")))(Keep.left)
  .run()

doSomethingElse()

killSwitch.shutdown()



///Supervision Strategies
//The stages that support supervision strategies are explicitly documented to do so,
// if there is nothing in the documentation of a stage saying that it adheres to the supervision strategy 
//it means it fails rather than applies supervision.


//There are three ways to handle exceptions from application code:
    Stop - The stream is completed with failure.
    Resume - The element is dropped and the stream continues.
    Restart - The element is dropped and the stream continues after restarting the stage. Restarting a stage means that any accumulated state is cleared. This is typically performed by creating a new instance of the stage.

//By default the stopping strategy is used for all exceptions, 
//i.e. the stream will be completed with failure when an exception is thrown.
implicit val materializer = ActorMaterializer()
val source = Source(0 to 5).map(100 / _)
val result = source.runWith(Sink.fold(0)(_ + _))
// division by zero will fail the stream and the
// result here will be a Future completed with Failure(ArithmeticException)



//The default supervision strategy for a stream can be defined on the settings of the materializer.
val decider: Supervision.Decider = {
  case _: ArithmeticException => Supervision.Resume
  case _                      => Supervision.Stop
}
implicit val materializer = ActorMaterializer(
  ActorMaterializerSettings(system).withSupervisionStrategy(decider))
val source = Source(0 to 5).map(100 / _)
val result = source.runWith(Sink.fold(0)(_ + _))
// the element causing division by zero will be dropped
// result here will be a Future completed with Success(228)



//The supervision strategy can also be defined for all operators of a flow.
implicit val materializer = ActorMaterializer()
val decider: Supervision.Decider = {
  case _: ArithmeticException => Supervision.Resume
  case _                      => Supervision.Stop
}
val flow = Flow[Int]
  .filter(100 / _ < 50).map(elem => 100 / (5 - elem))
  .withAttributes(ActorAttributes.supervisionStrategy(decider))
val source = Source(0 to 5).via(flow)

val result = source.runWith(Sink.fold(0)(_ + _))
// the elements causing division by zero will be dropped
// result here will be a Future completed with Success(150)

//Restart works in a similar way as Resume with the addition that accumulated state, 
//if any, of the failing processing stage will be reset.
implicit val materializer = ActorMaterializer()
val decider: Supervision.Decider = {
  case _: IllegalArgumentException => Supervision.Restart
  case _                           => Supervision.Stop
}
val flow = Flow[Int]
  .scan(0) { (acc, elem) =>
    if (elem < 0) throw new IllegalArgumentException("negative not allowed")
    else acc + elem
  }
  .withAttributes(ActorAttributes.supervisionStrategy(decider))
val source = Source(List(1, 3, -1, 5, 7)).via(flow)
val result = source.limit(1000).runWith(Sink.seq)
// the negative element cause the scan stage to be restarted,
// i.e. start from 0 again
// result here will be a Future completed with Success(Vector(0, 1, 4, 0, 5, 12))



///Errors from mapAsync
//Stream supervision can also be applied to the futures of mapAsync and mapAsyncUnordered 
//even if such failures happen in the future rather than inside the stage itself.

val authors: Source[Author, NotUsed] =
  tweets
    .filter(_.hashtags.contains(akkaTag))
    .map(_.author)

//To lookup their email address using:
def lookupEmail(handle: String): Future[String] = ???
//The Future is completed with Failure if the email is not found.

//Transforming the stream of authors to a stream of email addresses by using the lookupEmail service 
//can be done with mapAsync and we use Supervision.resumingDecider to drop unknown email addresses:
import ActorAttributes.supervisionStrategy
import Supervision.resumingDecider

val emailAddresses: Source[String, NotUsed] =
  authors.via(
    Flow[Author].mapAsync(4)(author => addressSystem.lookupEmail(author.handle))
      .withAttributes(supervisionStrategy(resumingDecider)))


///*** Akka Stream - Streaming IO
///Tcp 
object Framing
    def delimiter(delimiter: ByteString, maximumFrameLength: Int, allowTruncation: Boolean = false): Flow[ByteString, ByteString, NotUsed]
        Creates a Flow that handles decoding a stream of unstructured byte chunks into a stream of frames where the incoming chunk stream uses a specific byte-sequence to mark frame boundaries.
    def lengthField(fieldLength: Int, fieldOffset: Int, maximumFrameLength: Int, byteOrder: ByteOrder, computeFrameSize: (Array[Byte], Int) ⇒ Int): Flow[ByteString, ByteString, NotUsed]
        Creates a Flow that decodes an incoming stream of unstructured byte chunks into a stream of frames, assuming that incoming frames have a field that encodes their length.
    def lengthField(fieldLength: Int, fieldOffset: Int = 0, maximumFrameLength: Int, byteOrder: ByteOrder = ByteOrder.LITTLE_ENDIAN): Flow[ByteString, ByteString, NotUsed]
        Creates a Flow that decodes an incoming stream of unstructured byte chunks into a stream of frames, assuming that incoming frames have a field that encodes their length.
    def simpleFramingProtocol(maximumMessageLength: Int): BidiFlow[ByteString, ByteString, ByteString, ByteString, NotUsed]
        Returns a BidiFlow that implements a simple framing protocol.
    def simpleFramingProtocolDecoder(maximumMessageLength: Int): Flow[ByteString, ByteString, NotUsed]
        Protocol decoder that is used by Framing#simpleFramingProtocol
    def simpleFramingProtocolEncoder(maximumMessageLength: Int): Flow[ByteString, ByteString, NotUsed]
        Protocol encoder that is used by Framing#simpleFramingProtocol
object JsonFraming
    Provides JSON framing stages that can separate valid JSON objects from incoming ByteString objects.
    def objectScanner(maximumObjectLength: Int): Flow[ByteString, ByteString, NotUsed]
        Returns a Flow that implements a "brace counting" based framing stage for emitting valid JSON chunks.
        
//Echo server      
import akka.stream.scaladsl.Framing

val connections: Source[IncomingConnection, Future[ServerBinding]] =  Tcp().bind(host, port)
connections runForeach { connection ⇒
  println(s"New connection from: ${connection.remoteAddress}")

  val echo = Flow[ByteString]
    .via(Framing.delimiter(
      ByteString("\n"),
      maximumFrameLength = 256,
      allowTruncation = true))
    .map(_.utf8String)
    .map(_ + "!!!\n")
    .map(ByteString(_))

  connection.handleWith(echo)
}

$ echo -n "Hello World" | netcat 127.0.0.1 8888
Hello World!!!

///FileIO
//Streaming data from a file is as easy as creating a FileIO.fromPath given a target path, 
//and an optional chunkSize which determines the buffer size determined as one “element” in such stream:
import akka.stream.scaladsl._
val file = Paths.get("example.csv")

val foreach: Future[IOResult] = FileIO.fromPath(file)
  .to(Sink.ignore)
  .run()



//these processing stages are backed by Actors 
//and by default are configured to run on a pre-configured threadpool-backed dispatcher dedicated for File IO. 
//This is very important as it isolates the blocking file IO operations from the rest of the ActorSystem 
//allowing each dispatcher to be utilised in the most efficient way. 

//If you want to configure a custom dispatcher for file IO operations globally, 
FileIO.fromPath(file)
      .withAttributes(ActorAttributes.dispatcher("custom-blocking-io-dispatcher"))

      
///With FileIO 
// class akka.util.ByteString extends IndexedSeq[Byte] with IndexedSeqOptimized[Byte, ByteString] 
//all IndexedSeq operations can be done 
object akka.stream.scaladsl.FileIO
    Factories to create sinks and sources from files
    def fromPath(f: Path, chunkSize: Int, startPosition: Long): Source[ByteString, Future[IOResult]]
        Creates a Source from a files contents.
    def fromPath(f: Path, chunkSize: Int = 8192): Source[ByteString, Future[IOResult]]
        Creates a Source from a files contents.
    def toPath(f: Path, options: Set[OpenOption], startPosition: Long): Sink[ByteString, Future[IOResult]]
        Creates a Sink which writes incoming ByteString elements to the given file path.
    def toPath(f: Path, options: Set[OpenOption] = ...): Sink[ByteString, Future[IOResult]]
        Creates a Sink which writes incoming ByteString elements to the given file path.
    def fromFile(f: File, chunkSize: Int = 8192): Source[ByteString, Future[IOResult]]
        Creates a Source from a files contents.
    def toFile(f: File, options: Set[OpenOption] = ...): Sink[ByteString, Future[IOResult]]
        Creates a Sink which writes incoming ByteString elements to the given file.
final case class akka.stream.IOResult(count: Long, status: Try[Done]) extends Product with Serializable
    Holds a result of an IO operation.
    count
        Numeric value depending on context, for example IO operations performed or bytes processed.
    status
        Status of the result. Can be either akka.Done or an exception.
    Instance Constructors
        new IOResult(count: Long, status: Try[Done])
    Value Members
        val count: Long
        def getCount: Long
            Java API: Numeric value depending on context, for example IO operations performed or bytes processed.
        def getError: Throwable
            Java API: If the IO operation resulted in an error, returns the corresponding Throwable or throws UnsupportedOperationException otherwise.
        val status: Try[Done]
        def wasSuccessful: Boolean
            Java API: Indicates whether IO operation completed successfully or not.
        def withCount(value: Long): IOResult
        def withStatus(value: Try[Done]): IOResult     
object IOResult extends Serializable
    def createFailed(count: Long, ex: Throwable): IOResult
        JAVA API: Creates failed IOResult, count should be the number of bytes (or other unit, please document in your APIs) processed before failing
    def createSuccessful(count: Long): IOResult
        JAVA API: Creates successful IOResult
        
        
//Example 
//runWith() is a convenience method that automatically ignores the materialized value of any other stages 
//except those appended by the runWith() itself. 
//in below example it translates to using Keep.right as the combiner for materialized values.
//Source[+Out, +Mat].runWith[Mat2](sink: Graph[SinkShape[Out], Mat2])(implicit materializer: Materializer): Mat2
//Connect this Source to a Sink and run it.
//Note materializer = ActorMaterializer(), run, runWith etc run methods always returns Future[T]


val factorials = source.scan(BigInt(1))((acc, next) ⇒ acc * next)

val result: Future[IOResult] =
  factorials
    .map(num ⇒ ByteString(s"$num\n"))
    .runWith(FileIO.toPath(Paths.get("factorials.txt")))
        
//Reusable code 
//Source[+Out, +Mat].toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) ⇒ Mat3): RunnableGraph[Mat3] 
//combine = Keep.right  means we need to keep right of (Mat,Mat2) ie of FileIO.toPath
def lineSink(filename: String): Sink[String, Future[IOResult]] =
  Flow[String]
    .map(s ⇒ ByteString(s + "\n"))
    .toMat(FileIO.toPath(Paths.get(filename)))(Keep.right)

factorials.map(_.toString).runWith(lineSink("factorial2.txt"))

//Time-Based Processing
//Source[+Out, +Mat].throttle(elements: Int, per: FiniteDuration, maximumBurst: Int, mode: ThrottleMode): Source[Out, Mat]
//Sends elements downstream with speed limited to elements/per.
factorials
  .zipWith(Source(0 to 100))((num, idx) ⇒ s"$idx! = $num")
  .throttle(1, 1.second, 1, ThrottleMode.shaping)
  .runForeach(println)

//Reference 
object Keep 
    def both[L, R]: (L, R) ⇒ (L, R)
    def left[L, R]: (L, R) ⇒ L
    def none[L, R]: (L, R) ⇒ NotUsed
    def right[L, R]: (L, R) ⇒ R 
object ThrottleMode 
    object Enforcing extends ThrottleMode with Product with Serializable
        Makes throttle fail with exception when upstream is faster than throttle rate
    object Shaping extends ThrottleMode with Product with Serializable
        Tells throttle to make pauses before emitting messages to meet throttle rate
      
      
      
      
    

///*** Akka Stream - Pipelining and Parallel Processing 

///Pipelining - Example 
//The benefit of pipelining is that it can be applied to any sequence of processing steps 
//that are otherwise not parallelisable 
//(for example because the result of a processing step depends on all the information from the previous step). 


//Roland uses the two frying pans in an asymmetric fashion. 
//The first pan is only used to fry one side of the pancake 
//then the half-finished pancake is flipped into the second pan for the finishing fry on the other side. 
//Once the first frying pan becomes available it gets a new scoop of batter. 
//As an effect, most of the time there are two pancakes being cooked at the same time, 
//one being cooked on its first side and the second being cooked to completion. 

 //Flow[-In, +Out, +Mat]
// Takes a scoop of batter and creates a pancake with one side cooked
val fryingPan1: Flow[ScoopOfBatter, HalfCookedPancake, NotUsed] =
  Flow[ScoopOfBatter].map { batter => HalfCookedPancake() }

// Finishes a half-cooked pancake
val fryingPan2: Flow[HalfCookedPancake, Pancake, NotUsed] =
  Flow[HalfCookedPancake].map { halfCooked => Pancake() }

// With the two frying pans we can fully cook pancakes
val pancakeChef: Flow[ScoopOfBatter, Pancake, NotUsed] =
  Flow[ScoopOfBatter].via(fryingPan1.async).via(fryingPan2.async)

  
  
///Parallel processing- Example 
//The benefit of parallelizing is that it is easy to scale.


//Patrik uses the two frying pans symmetrically. 
//He uses both pans to fully fry a pancake on both sides, then puts the results on a shared plate. 
//Whenever a pan becomes empty, he takes the next scoop from the shared bowl of batter. 
//In essence he parallelizes the same process over multiple pans. 
//This is how this setup will look like if implemented using streams:


//Scaling - it is easy to add a third frying pan with Patrik’s method, 
//but Roland cannot add a third frying pan, since that would require a third processing step, 
//which is not practically possible in the case of frying pancakes.

//One drawback of the example code above that it does not preserve the ordering of pancakes. 

 //Flow[-In, +Out, +Mat]
val fryingPan: Flow[ScoopOfBatter, Pancake, NotUsed] =
  Flow[ScoopOfBatter].map { batter => Pancake() }

val pancakeChef: Flow[ScoopOfBatter, Pancake, NotUsed] = Flow.fromGraph(GraphDSL.create() { implicit builder =>
  val dispatchBatter = builder.add(Balance[ScoopOfBatter](2))
  val mergePancakes = builder.add(Merge[Pancake](2))

  // Using two frying pans in parallel, both fully cooking a pancake from the batter.
  // We always put the next scoop of batter to the first frying pan that becomes available.
  dispatchBatter.out(0) ~> fryingPan.async ~> mergePancakes.in(0)
  // Notice that we used the "fryingPan" flow without importing it via builder.add().
  // Flows used this way are auto-imported, which in this case means that the two
  // uses of "fryingPan" mean actually different stages in the graph.
  dispatchBatter.out(1) ~> fryingPan.async ~> mergePancakes.in(1)

  FlowShape(dispatchBatter.in, mergePancakes.out)
})



///Combining pipelining and parallel processing
//it is simple to combine the two approaches and streams provide a nice unifying language to express and compose them.

//To  parallelize pipelined processing stages. 
//if there are many independent jobs that do not depend on the results of each other

//Example 
//In the case of pancakes this means that we will employ two chefs, 
//each working using Roland’s pipelining method, but we use the two chefs in parallel, 

val pancakeChef: Flow[ScoopOfBatter, Pancake, NotUsed] =
  Flow.fromGraph(GraphDSL.create() { implicit builder =>

    val dispatchBatter = builder.add(Balance[ScoopOfBatter](2))
    val mergePancakes = builder.add(Merge[Pancake](2))

    // Using two pipelines, having two frying pans each, in total using
    // four frying pans
    dispatchBatter.out(0) ~> fryingPan1.async ~> fryingPan2.async ~> mergePancakes.in(0)
    dispatchBatter.out(1) ~> fryingPan1.async ~> fryingPan2.async ~> mergePancakes.in(1)

    FlowShape(dispatchBatter.in, mergePancakes.out)
  })

///To organize parallelized stages into pipelines. 

//Example - This would mean employing four chefs:
//the first two chefs prepare half-cooked pancakes from batter, 
//in parallel, then putting those on a large enough flat surface.
//the second two chefs take these and fry their other side in their own pans, 
//then they put the pancakes on a shared plate.



val pancakeChefs1: Flow[ScoopOfBatter, HalfCookedPancake, NotUsed] =
  Flow.fromGraph(GraphDSL.create() { implicit builder =>
    val dispatchBatter = builder.add(Balance[ScoopOfBatter](2))
    val mergeHalfPancakes = builder.add(Merge[HalfCookedPancake](2))

    // Two chefs work with one frying pan for each, half-frying the pancakes then putting
    // them into a common pool
    dispatchBatter.out(0) ~> fryingPan1.async ~> mergeHalfPancakes.in(0)
    dispatchBatter.out(1) ~> fryingPan1.async ~> mergeHalfPancakes.in(1)

    FlowShape(dispatchBatter.in, mergeHalfPancakes.out)
  })

val pancakeChefs2: Flow[HalfCookedPancake, Pancake, NotUsed] =
  Flow.fromGraph(GraphDSL.create() { implicit builder =>
    val dispatchHalfPancakes = builder.add(Balance[HalfCookedPancake](2))
    val mergePancakes = builder.add(Merge[Pancake](2))

    // Two chefs work with one frying pan for each, finishing the pancakes then putting
    // them into a common pool
    dispatchHalfPancakes.out(0) ~> fryingPan2.async ~> mergePancakes.in(0)
    dispatchHalfPancakes.out(1) ~> fryingPan2.async ~> mergePancakes.in(1)

    FlowShape(dispatchHalfPancakes.in, mergePancakes.out)
  })

val kitchen: Flow[ScoopOfBatter, Pancake, NotUsed] = pancakeChefs1.via(pancakeChefs2)




///*** Akka Stream - Substreams
//Stages that create substreams are listed on Nesting and flattening stages

//Substreams are represented as SubSource or SubFlow instances, 
//on which you can multiplex a single Source or Flow into a stream of streams.

//SubFlows cannot contribute to the super-flow’s materialized value since they are materialized later, 
//during the runtime of the flow graph processing.

trait SubFlow[+Out, +Mat, +F[+_], C] extends FlowOps[Out, Mat] 
    All flow operations are possible (as derived from FlowOps) and below 
    type Closed = C
    type Repr[+T] = SubFlow[T, Mat, F, C] 
    Abstract Value Members
        abstract def mergeSubstreamsWithParallelism(parallelism: Int): F[Out]
            Flatten the sub-flows back into the super-flow by performing a merge with the given parallelism limit.
        abstract def to[M](sink: Graph[SinkShape[Out], M]): C
            Attach a Sink to each sub-flow, closing the overall Graph that is being constructed.
    Concrete Value Members
        def concatSubstreams: F[Out]
            Flatten the sub-flows back into the super-flow by concatenating them.
        def mergeSubstreams: F[Out]
            Flatten the sub-flows back into the super-flow by performing a merge without parallelism limit (i.e.

///Nesting stages - groupBy
//def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Repr, Closed]

//This operation splits the incoming stream into separate output streams, one for each element key.
val source = Source(1 to 10).groupBy(3, _ % 3)

//if you add the Sink or Flow, that is added to each of the substreams
Source(1 to 10).groupBy(3, _ % 3).to(Sink.ignore).run()

//Substream has methods that allow  to merge or concat substreams into the master stream again.
//The mergeSubstreams method merges an unbounded number of substreams back to the master stream.
Source(1 to 10)
  .groupBy(3, _ % 3)
  .mergeSubstreams
  .runWith(Sink.ignore)

//limit the number of active substreams running and being merged at a time, 
//with either the mergeSubstreamsWithParallelism or concatSubstreams method.
Source(1 to 10)
  .groupBy(3, _ % 3)
  .mergeSubstreamsWithParallelism(2)
  .runWith(Sink.ignore)

//concatSubstreams is equivalent to mergeSubstreamsWithParallelism(1)
Source(1 to 10)
  .groupBy(3, _ % 3)
  .concatSubstreams
  .runWith(Sink.ignore)

///Nesting stages - splitWhen and splitAfter
//def splitWhen(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
//def splitWhen(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
//def splitAfter(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
//def splitAfter(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
object SubstreamCancelStrategy 
    def drain: SubstreamCancelStrategy
        Drain substream on cancellation in order to prevent stalling of the stream of streams.
    def propagate: SubstreamCancelStrategy
        Cancel the stream of streams if any substream is cancelled.


//if the predicate for splitWhen and splitAfter returns true, a new substream is generated, 
//and the succeeding elements after split will flow into the new substream.

//splitWhen flows the element on which the predicate returned true to a new substream, 
//whereas splitAfter flows the next element to the new substream after the element on which predicate returned true.
Source(1 to 10).splitWhen(SubstreamCancelStrategy.drain)(_ == 3)
Source(1 to 10).splitAfter(SubstreamCancelStrategy.drain)(_ == 3)

//These are useful when you scanned over something and you don’t need to care about anything behind it. 
//A typical example is counting the number of characters for each line like below.

    val text =
      "This is the first line.\n" +
        "The second line.\n" +
        "There is also the 3rd line\n"

    val charCount = Source(text.toList)
      .splitAfter { _ == '\n' }
      .filter(_ != '\n')
      .map(_ => 1)
      .reduce(_ + _)
      .to(Sink.foreach(println))
      .run()

//This prints out the following output.
23
16
26

///Flattening stages - flatMapConcat
//def flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Repr[T]
//def flatMapMerge[T, M](breadth: Int, f: (Out) => Graph[SourceShape[T], M]): Repr[T]

//The function f of flatMapConcat transforms each input element into a Source 
//that is then flattened into the output stream by concatenation.

//Like the concat operation on Flow, it fully consumes one Source after the other. 
//So, there is only one substream actively running at a given time.

//Then once the active substream is fully consumed, the next substream can start running. 
//Elements from all the substreams are concatenated to the sink.

Source(1 to 2)
  .flatMapConcat(i => Source(List.fill(3)(i)))
  .runWith(Sink.ignore)

///flatMapMerge
//flatMapMerge is similar to flatMapConcat, but it doesn’t wait for one Source to be fully consumed. 
//Instead, up to breadth number of streams emit elements at any given time.
Source(1 to 2)
  .flatMapMerge(2, i => Source(List.fill(3)(i)))
  .runWith(Sink.ignore)

  
  
///*** Akka Streams - Testing streams

///Built-in sources, sinks and combinators
//Testing a custom sink can be as simple as attaching a source 
//that emits elements from a predefined collection, running a constructed test flow 
//and asserting on the results that sink produced

//def toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]
val sinkUnderTest = Flow[Int].map(_ * 2).toMat(Sink.fold(0)(_ + _))(Keep.right)

val future = Source(1 to 4).runWith(sinkUnderTest)
val result = Await.result(future, 3.seconds)
assert(result == 20)

//Example - a source that produces an infinite stream of elements. 
//Such source can be tested by asserting that first arbitrary number of elements hold some condition. 
import system.dispatcher
import akka.pattern.pipe

val sourceUnderTest = Source.repeat(1).map(_ * 2)

val future = sourceUnderTest.take(10).runWith(Sink.seq)
val result = Await.result(future, 3.seconds)
assert(result == Seq.fill(10)(2))

///testing a flow ,attach a source and a sink. 
val flowUnderTest = Flow[Int].takeWhile(_ < 5)

val future = Source(1 to 10).via(flowUnderTest).runWith(Sink.fold(Seq.empty[Int])(_ :+ _))
val result = Await.result(future, 3.seconds)
assert(result == (1 to 4))



///Streams TestKit
//Akka Stream offers integration with Actors out of the box. 


//build.sbt 
libraryDependencies += "com.typesafe.akka" %% "akka-stream-testkit" % "2.5.11" % Test


object akka.testkit.typed.scaladsl.TestProbe 
    def apply[M](name: String)(implicit system: ActorSystem[_]): TestProbe[M]
    def apply[M]()(implicit system: ActorSystem[_]): TestProbe[M] 
trait akka.testkit.typed.scaladsl.TestProbe
    //Abstract Value Members
    abstract def awaitAssert[A](a: ⇒ A, max: Duration = Duration.Undefined, interval: Duration = 100.millis): A
        Evaluate the given assert every interval until it does not throw an exception and return the result.
    abstract def expectMessage[T <: M](max: FiniteDuration, hint: String, obj: T): T
        Receive one message from the test actor and assert that it equals the given object.
    abstract def expectMessage[T <: M](max: FiniteDuration, obj: T): T
        Receive one message from the test actor and assert that it equals the given object.
    abstract def expectMessage[T <: M](obj: T): T
        Same as expectMessage(remainingOrDefault, obj), but correctly treating the timeFactor.
    abstract def expectNoMessage(): Unit
        Assert that no message is received.
    abstract def expectNoMessage(max: FiniteDuration): Unit
        Assert that no message is received for the specified time.
    abstract def expectTerminated[U](actorRef: ActorRef[U], max: FiniteDuration): Unit
        Expect the given actor to be stopped or stop withing the given timeout or throw an AssertionError.
    abstract def ref: ActorRef[M]
        ActorRef for this TestProbe
    abstract def remaining: FiniteDuration
        Obtain time remaining for execution of the innermost enclosing within block or throw an AssertionError if no within block surrounds this call.
    abstract def remainingOr(duration: FiniteDuration): FiniteDuration
        Obtain time remaining for execution of the innermost enclosing within block or missing that it returns the given duration.
    abstract def remainingOrDefault: FiniteDuration
        Obtain time remaining for execution of the innermost enclosing within block or missing that it returns the properly dilated default for this case from settings (key "akka.actor.typed.test.single-expect-default").
	//Concrete Value Members
    def expectMessageType[T <: M](max: FiniteDuration)(implicit t: ClassTag[T]): T
        Expect a message of type T to arrive within max or fail.
    def expectMessageType[T <: M](implicit t: ClassTag[T]): T
        Same as expectMessageType[T](remainingOrDefault), but correctly treating the timeFactor.
    def fishForMessage(max: FiniteDuration)(fisher: (M) ⇒ FishingOutcome): Seq[M]
        Same as the other fishForMessage but with no hint
    def fishForMessage(max: FiniteDuration, hint: String)(fisher: (M) ⇒ FishingOutcome): Seq[M]
        Allows for flexible matching of multiple messages within a timeout, the fisher function is fed each incoming message, and returns one of the following effects to decide on what happens next:
    def within[T](max: FiniteDuration)(f: ⇒ T): T
        Same as calling within(0 seconds, max)(f).
    def within[T](min: FiniteDuration, max: FiniteDuration)(f: ⇒ T): T
        Execute code block while bounding its execution time between min and max.
        
        
//One test would be to materialize stream to a Future 
//and then use pipe pattern to pipe the result of that future to the probe.
import system.dispatcher
import akka.pattern.pipe

val sourceUnderTest = Source(1 to 4).grouped(2)

val probe = TestProbe()
sourceUnderTest.runWith(Sink.seq).pipeTo(probe.ref)
probe.expectMsg(3.seconds, Seq(Seq(1, 2), Seq(3, 4)))

//Instead of materializing to a future, 
//use a Sink.actorRef that sends all incoming elements to the given ActorRef.
case object Tick
val sourceUnderTest = Source.tick(0.seconds, 200.millis, Tick)

val probe = TestProbe()
val cancellable = sourceUnderTest.to(Sink.actorRef(probe.ref, "completed")).run()

probe.expectMsg(1.second, Tick)
probe.expectNoMsg(100.millis)
probe.expectMsg(3.seconds, Tick)
cancellable.cancel()
probe.expectMsg(3.seconds, "completed")


//use Source.actorRef and have full control over elements to be sent.
val sinkUnderTest = Flow[Int].map(_.toString).toMat(Sink.fold("")(_ + _))(Keep.right)

val (ref, future) = Source.actorRef(8, OverflowStrategy.fail)
  .toMat(sinkUnderTest)(Keep.both).run()

ref ! 1
ref ! 2
ref ! 3
ref ! akka.actor.Status.Success("done")

val result = Await.result(future, 3.seconds)
assert(result == "123")

//A sink returned by TestSink.probe allows manual control over demand 
//and assertions over elements coming downstream.
val sourceUnderTest = Source(1 to 4).filter(_ % 2 == 0).map(_ * 2)

sourceUnderTest
  .runWith(TestSink.probe[Int])
  .request(2)
  .expectNext(4, 8)
  .expectComplete()

//A source returned by TestSource.probe can be used for asserting demand 
//or controlling when stream is completed or ended with an error.
val sinkUnderTest = Sink.cancelled

TestSource.probe[Int]
  .toMat(sinkUnderTest)(Keep.left)
  .run()
  .expectCancellation()

//You can also inject exceptions and test sink behavior on error conditions.
val sinkUnderTest = Sink.head[Int]

val (probe, future) = TestSource.probe[Int]
  .toMat(sinkUnderTest)(Keep.both)
  .run()
probe.sendError(new Exception("boom"))

Await.ready(future, 3.seconds)
val Failure(exception) = future.value.get
assert(exception.getMessage == "boom")

//Test source and sink can be used together in combination when testing flows.
val flowUnderTest = Flow[Int].mapAsyncUnordered(2) { sleep =>
  pattern.after(10.millis * sleep, using = system.scheduler)(Future.successful(sleep))
}

val (pub, sub) = TestSource.probe[Int]
  .via(flowUnderTest)
  .toMat(TestSink.probe[Int])(Keep.both)
  .run()

sub.request(n = 3)
pub.sendNext(3)
pub.sendNext(2)
pub.sendNext(1)
sub.expectNextUnordered(1, 2, 3)

pub.sendError(new Exception("Power surge in the linear subroutine C-47!"))
val ex = sub.expectError()
assert(ex.getMessage.contains("C-47"))



///Fuzzing Mode
//For testing, it is possible to enable a special stream execution mode 
//that exercises concurrent execution paths more aggressively (at the cost of reduced performance) 
//and therefore helps exposing race conditions in tests. 
akka.stream.materializer.debug.fuzzing-mode = on



///*** Akka Stream - Stream References - Reactive Streams over the network
//Stream references, or “stream refs” for short, allow running Akka Streams across multiple nodes within an Akka Cluster. 

//A SourceRef can be offered to a remote actor system in order for it 
//to consume some source of data that we have prepared locally.
//materialize it by running it into the Sink.sourceRef.
//That sink materializes the SourceRef that you can then send to other nodes. 
//note that it materializes into a Future so ,use the pipeTo

//A SourceRef is by design “single-shot”. i.e. it may only be materialized onc
import akka.stream.SourceRef
import akka.pattern.pipe

case class RequestLogs(streamId: Int)
case class LogsOffer(streamId: Int, sourceRef: SourceRef[String])

class DataSource extends Actor {
  import context.dispatcher
  implicit val mat = ActorMaterializer()(context)

  def receive = {
    case RequestLogs(streamId) =>
      // obtain the source you want to offer:
      val source: Source[String, NotUsed] = streamLogs(streamId)

      // materialize the SourceRef:
      val ref: Future[SourceRef[String]] = source.runWith(StreamRefs.sourceRef())

      // wrap the SourceRef in some domain message, such that the sender knows what source it is
      val reply: Future[LogsOffer] = ref.map(LogsOffer(streamId, _))

      // reply to sender
      reply pipeTo sender()
  }

  def streamLogs(streamId: Long): Source[String, NotUsed] = ???
}

// Once it has handed out the SourceRef the remote side can run it like this:
val sourceActor = system.actorOf(Props[DataSource], "dataSource")

sourceActor ! RequestLogs(1337)
val offer = expectMsgType[LogsOffer]

// implicitly converted to a Source:
offer.sourceRef.runWith(Sink.foreach(println))
// alternatively explicitly obtain Source from SourceRef:
// offer.sourceRef.source.runWith(Sink.foreach(println))



///Sink Refs - offering to receive streaming data from a remote system(similar to “passive mode” in FTP)
//They can be used to offer the other side the capability to send 
//to the origin side data in a streaming, flow-controlled fashion. 

//The origin here allocates a Sink, 
//which streams the incoming data into various other systems (e.g. any of the Alpakka provided Sinks).
import akka.pattern.pipe
import akka.stream.SinkRef

case class PrepareUpload(id: String)
case class MeasurementsSinkReady(id: String, sinkRef: SinkRef[String])

class DataReceiver extends Actor {

  import context.dispatcher
  implicit val mat = ActorMaterializer()(context)

  def receive = {
    case PrepareUpload(nodeId) =>
      // obtain the source you want to offer:
      val sink: Sink[String, NotUsed] = logsSinkFor(nodeId)

      // materialize the SinkRef (the remote is like a source of data for us):
      val ref: Future[SinkRef[String]] = StreamRefs.sinkRef[String]().to(sink).run()

      // wrap the SinkRef in some domain message, such that the sender knows what source it is
      val reply: Future[MeasurementsSinkReady] = ref.map(MeasurementsSinkReady(nodeId, _))

      // reply to sender
      reply pipeTo sender()
  }

  def logsSinkFor(nodeId: String): Sink[String, NotUsed] = ???
}


//Using the offered SinkRef to send data to the origin of the Sink
//treat the SinkRef just as any other Sink and directly runWith or run with it.
val receiver = system.actorOf(Props[DataReceiver], "receiver")

receiver ! PrepareUpload("system-42-tmp")
val ready = expectMsgType[MeasurementsSinkReady]

// stream local metrics to Sink's origin:
localMetrics().runWith(ready.sinkRef)

///*** Akka Stream - Custom processing with GraphStage
abstract class akka.stream.stage.GraphStage[S <: Shape] extends GraphStageWithMaterializedValue[S, NotUsed]
	A GraphStage represents a reusable graph stream processing stage.
	A GraphStage consists of a Shape which describes its input and output ports and a factory function that creates a GraphStageLogic which implements the processing logic that ties the ports together.
	Instance Constructors
	new GraphStage() 
    //Type Members
    type Shape = S
        Type-level accessor for the shape parameter of this graph.
    //Abstract Value Members
    abstract def createLogic(inheritedAttributes: Attributes): GraphStageLogic
    abstract def shape: S
        The shape of a graph is all that is externally visible: its inlets and outlets.
    //Concrete Value Members
    def addAttributes(attr: Attributes): Graph[S, NotUsed]
        Add the given attributes to this Graph.
    def async(dispatcher: String, inputBufferSize: Int): Graph[S, NotUsed]
        Put an asynchronous boundary around this Graph
    def async(dispatcher: String): Graph[S, NotUsed]
        Put an asynchronous boundary around this Graph
    def async: Graph[S, NotUsed]
        Put an asynchronous boundary around this Graph
    def initialAttributes: Attributes 
    final def createLogicAndMaterializedValue(inheritedAttributes: Attributes): (GraphStageLogic, NotUsed)
    def named(name: String): Graph[S, NotUsed]
    final def withAttributes(attr: Attributes): Graph[S, NotUsed] 
abstract class GraphStageLogic extends AnyRef
	Represents the processing logic behind a GraphStage. 
    Roughly speaking, a subclass of GraphStageLogic is a collection of the following parts: 
    * A set of InHandler and OutHandler instances and their assignments to the Inlets and Outlets of the enclosing GraphStage 
    * Possible mutable state, accessible from the InHandler and OutHandler callbacks, but not from anywhere else (as such access would not be thread-safe) 
    * The lifecycle hooks preStart() and postStop() 
    * Methods for performing stream processing actions, like pulling or pushing elements
	The stage logic is completed once all its input and output ports have been closed. 
    This can be changed by setting setKeepGoing to true.
	The postStop lifecycle hook on the logic itself is called once all ports are closed. 
    This is the only tear down callback that is guaranteed to happen, 
    if the actor system or the materializer is terminated the handlers may never see 
    any callbacks to onUpstreamFailure, onUpstreamFinish or onDownstreamFinish. 
    Therefore stage resource cleanup should always be done in postStop.
	//Instance Constructors
        new GraphStageLogic(shape: Shape) 
    //Type Members
    class SubSinkInlet[T]
        INTERNAL API
    class SubSourceOutlet[T]
        INTERNAL API
    //Value Members
    final def abortEmitting(out: Outlet[_]): Unit
        Abort outstanding (suspended) emissions for the given outlet, if there are any.
    final def abortReading(in: Inlet[_]): Unit
        Abort outstanding (suspended) reading for the given inlet, if there is any.
    def afterPostStop(): Unit
        INTERNAL API
    def beforePreStart(): Unit
        INTERNAL API
    final def cancel[T](in: Inlet[T]): Unit
        Requests to stop receiving events from a given input port.
    final def complete[T](out: Outlet[T]): Unit
        Signals that there will be no more elements emitted on the given port.
    final def completeStage(): Unit
        Automatically invokes cancel() or complete() on all the input or output ports that have been called, then marks the stage as stopped.
    final def conditionalTerminateInput(predicate: () ⇒ Boolean): InHandler
        Input handler that terminates the state upon receiving completion if the given condition holds at that time.
    final def conditionalTerminateOutput(predicate: () ⇒ Boolean): OutHandler
        Output handler that terminates the state upon receiving completion if the given condition holds at that time.
    final def createAsyncCallback[T](handler: Procedure[T]): AsyncCallback[T]
        Java API: Obtain a callback object that can be used asynchronously to re-enter the current GraphStage with an asynchronous notification.
    final def eagerTerminateInput: InHandler
        Input handler that terminates the stage upon receiving completion.
    final def eagerTerminateOutput: OutHandler
        Output handler that terminates the stage upon cancellation.
    final def emit[T](out: Outlet[T], elem: T, andThen: Effect): Unit
    final def emit[T](out: Outlet[T], elem: T): Unit
        Emit an element through the given outlet, suspending execution if necessary.
    final def emit[T](out: Outlet[T], elem: T, andThen: () ⇒ Unit): Unit
        Emit an element through the given outlet and continue with the given thunk afterwards, suspending execution if necessary.
    final def emitMultiple[T](out: Outlet[T], elems: Iterator[T]): Unit
        Emit a sequence of elements through the given outlet, suspending execution if necessary.
    final def emitMultiple[T](out: Outlet[T], elems: Iterator[T], andThen: () ⇒ Unit): Unit
        Emit a sequence of elements through the given outlet and continue with the given thunk afterwards, suspending execution if necessary.
    final def emitMultiple[T](out: Outlet[T], elems: Iterator[T], andThen: Effect): Unit
        Java API
    final def emitMultiple[T](out: Outlet[T], elems: Iterator[T]): Unit
        Java API
    final def emitMultiple[T](out: Outlet[T], elems: Iterable[T]): Unit
        Emit a sequence of elements through the given outlet, suspending execution if necessary.
    final def emitMultiple[T](out: Outlet[T], elems: Iterable[T], andThen: () ⇒ Unit): Unit
        Emit a sequence of elements through the given outlet and continue with the given thunk afterwards, suspending execution if necessary.
    final def fail[T](out: Outlet[T], ex: Throwable): Unit
        Signals failure through the given port.
    final def failStage(ex: Throwable): Unit
        Automatically invokes cancel() or fail() on all the input or output ports that have been called, then marks the stage as stopped.
    final def getAsyncCallback[T](handler: (T) ⇒ Unit): AsyncCallback[T]
        Obtain a callback object that can be used asynchronously to re-enter the current GraphStage with an asynchronous notification.
    final def getHandler(out: Outlet[_]): OutHandler
        Retrieves the current callback for the events on the given Outlet
    final def getHandler(in: Inlet[_]): InHandler
        Retrieves the current callback for the events on the given Inlet
    final def getStageActor(receive: ((ActorRef, Any)) ⇒ Unit): StageActor
        Initialize a StageActorRef which can be used to interact with from the outside world "as-if" an Actor.
    final def grab[T](in: Inlet[T]): T
        Once the callback InHandler.onPush() for an input port has been invoked, the element that has been pushed can be retrieved via this method.
    final def hasBeenPulled[T](in: Inlet[T]): Boolean
        Indicates whether there is already a pending pull for the given input port.
    final def ignoreTerminateInput: InHandler
        Input handler that does not terminate the stage upon receiving completion.
    final def ignoreTerminateOutput: OutHandler
        Output handler that does not terminate the stage upon cancellation.
    val inCount: Int
    final def isAvailable[T](out: Outlet[T]): Boolean
        Return true if the given output port is ready to be pushed.
    final def isAvailable[T](in: Inlet[T]): Boolean
        Indicates whether there is an element waiting at the given input port.
    final def isClosed[T](out: Outlet[T]): Boolean
        Indicates whether the port has been closed.
    final def isClosed[T](in: Inlet[T]): Boolean
        Indicates whether the port has been closed.
    def materializer: Materializer
        The akka.stream.Materializer that has set this GraphStage in motion.
    val outCount: Int
    final def passAlong[Out, In <: Out](from: Inlet[In], to: Outlet[Out], doFinish: Boolean = true, doFail: Boolean = true, doPull: Boolean = false): Unit
        Install a handler on the given inlet that emits received elements on the given outlet before pulling for more data.
    def postStop(): Unit
        Invoked after processing of external events stopped because the stage is about to stop or fail.
    def preStart(): Unit
        Invoked before any external events are processed, at the startup of the stage.
    final def pull[T](in: Inlet[T]): Unit
        Requests an element on the given port.
    final def push[T](out: Outlet[T], elem: T): Unit
        Emits an element through the given output port.
    final def read[T](in: Inlet[T], andThen: Procedure[T], onClose: Effect): Unit
        Java API: Read an element from the given inlet and continue with the given function, suspending execution if necessary.
    final def read[T](in: Inlet[T])(andThen: (T) ⇒ Unit, onClose: () ⇒ Unit): Unit
        Read an element from the given inlet and continue with the given function, suspending execution if necessary.
    final def readN[T](in: Inlet[T], n: Int, andThen: Procedure[List[T]], onClose: Procedure[List[T]]): Unit
        Java API: Read a number of elements from the given inlet and continue with the given function, suspending execution if necessary.
    final def readN[T](in: Inlet[T], n: Int)(andThen: (Seq[T]) ⇒ Unit, onClose: (Seq[T]) ⇒ Unit): Unit
        Read a number of elements from the given inlet and continue with the given function, suspending execution if necessary.
    final def setHandler(out: Outlet[_], handler: OutHandler): Unit
        Assigns callbacks for the events for an Outlet
    final def setHandler(in: Inlet[_], handler: InHandler): Unit
        Assigns callbacks for the events for an Inlet
    final def setHandlers(in: Inlet[_], out: Outlet[_], handler: InHandler with OutHandler): Unit
        Assign callbacks for linear stage for both Inlet and Outlet
    final def setKeepGoing(enabled: Boolean): Unit
        Controls whether this stage shall shut down when all its ports are closed, which is the default.
    final def stageActor: StageActor
    def stageActorName: String
        Override and return a name to be given to the StageActor of this stage.
    def subFusingMaterializer: Materializer
        An akka.stream.Materializer that may run fusable parts of the graphs that it materializes within the same actor as the current GraphStage (if fusing is available).
    final def totallyIgnorantInput: InHandler
        Input handler that does not terminate the stage upon receiving completion nor failure.
    final def tryPull[T](in: Inlet[T]): Unit
        Requests an element on the given port unless the port is already closed.
object akka.stream.stage.GraphStageLogic
    class ConditionalTerminateInput
        Input handler that terminates the state upon receiving completion if the given condition holds at that time.
    class ConditionalTerminateOutput
        Output handler that terminates the state upon receiving completion if the given condition holds at that time.
    final class StageActor
        Minimal actor to work with other actors and watch them in a synchronous ways
    final case class StageActorRefNotInitializedException() 
    ///Value Members
    object EagerTerminateInput extends InHandler
        Input handler that terminates the stage upon receiving completion.
    object EagerTerminateOutput extends OutHandler
        Output handler that terminates the stage upon cancellation.
    object IgnoreTerminateInput extends InHandler
        Input handler that does not terminate the stage upon receiving completion.
    object IgnoreTerminateOutput extends OutHandler
        Output handler that does not terminate the stage upon cancellation.
    object StageActorRef
    object TotallyIgnorantInput extends InHandler
        Input handler that does not terminate the stage upon receiving completion nor failure.
trait OutHandler extends AnyRef
    Collection of callbacks for an output port of a GraphStage
    Abstract Value Members
        abstract def onPull(): Unit
            Called when the output port has received a pull, and therefore ready to emit an element, i.e.
    Concrete Value Members
        def onDownstreamFinish(): Unit
            Called when the output port will no longer accept any new elements.
trait InHandler extends AnyRef
    Collection of callbacks for an input port of a GraphStage    
    abstract def onPush(): Unit
        Called when the input port has a new element available.
    Concrete Value Members
    def onUpstreamFailure(ex: Throwable): Unit
        Called when the input port has failed.
    def onUpstreamFinish(): Unit
        Called when the input port is finished.
        
        
//The GraphStage abstraction can be used to create arbitrary graph processing stages with any number of input or output ports. 
//It is a counterpart of the GraphDSL.create() method 
//which creates new stream processing stages by composing others. 
//GraphStage creates a stage that is itself not divisible into smaller ones, 
//and allows state to be maintained inside it in a safe way.


//Example - new Source that will simply emit numbers from 1 until it is cancelled
import akka.stream.SourceShape
import akka.stream.Graph
import akka.stream.stage.GraphStage
import akka.stream.stage.OutHandler

//In order to emit from a Source in a backpressured stream one needs first to have demand from downstream. 
//To receive the necessary events one needs to register a subclass of OutHandler with the output port (Outlet). 
//This handler will receive events related to the lifecycle of the port. 

//In our case we need to override onPull() which indicates that we are free to emit a single element. 
//There is another callback, onDownstreamFinish() which is called if the downstream cancelled. 
//Since the default behavior of that callback is to stop the stage, we don’t need to override it. 
//In the onPull callback we will simply emit the next number


class NumbersSource extends GraphStage[SourceShape[Int]] {
  val out: Outlet[Int] = Outlet("NumbersSource")
  override val shape: SourceShape[Int] = SourceShape(out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      // All state MUST be inside the GraphStageLogic,
      // never inside the enclosing GraphStage.
      // This state is safe to access and modify from all the
      // callbacks that are provided by GraphStageLogic and the
      // registered handlers.
      private var counter = 1

      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          push(out, counter)
          counter += 1
        }
      })
    }
}
//Now we can use the source as any other built-in one:

// A GraphStage is a proper Graph, just like what GraphDSL.create would return
val sourceGraph: Graph[SourceShape[Int], NotUsed] = new NumbersSource

// Create a Source from the Graph to access the DSL
val mySource: Source[Int, NotUsed] = Source.fromGraph(sourceGraph)

// Returns 55
val result1: Future[Int] = mySource.take(10).runFold(0)(_ + _)

// The source is reusable. This returns 5050
val result2: Future[Int] = mySource.take(100).runFold(0)(_ + _)


///o create a custom Sink one can register a subclass InHandler with the stage Inlet. 
//The onPush() callback is used to signal the handler a new element has been pushed to the stage, 
//onPush() can be overridden to provide custom behavior.
//Please note, most Sinks would need to request upstream elements as soon as they are created: 
//this can be done by calling pull(inlet) in the preStart() callback.

import akka.stream.SinkShape
import akka.stream.stage.GraphStage
import akka.stream.stage.InHandler

class StdoutSink extends GraphStage[SinkShape[Int]] {
  val in: Inlet[Int] = Inlet("StdoutSink")
  override val shape: SinkShape[Int] = SinkShape(in)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {

      // This requests one element at the Sink startup.
      override def preStart(): Unit = pull(in)

      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          println(grab(in))
          pull(in)
        }
      })
    }
}


///the following operations are available on an output port:
1.push(out,elem) pushes an element to the output port. Only possible after the port has been pulled by downstream.
2.complete(out) closes the output port normally.
3.fail(out,exception) closes the port with a failure signal.

//The events corresponding to an output port can be received in an OutHandler instance 
//registered to the output port using setHandler(out,handler). 
//This handler has two callbacks:
1.onPull() is called when the output port is ready to emit the next element, push(out, elem) is now allowed to be called on this port.
2.onDownstreamFinish() is called once the downstream has cancelled and no longer allows messages to be pushed to it. No more onPull() will arrive after this event. If not overridden this will default to stopping the stage.

//there are two query methods available for output ports:
1.isAvailable(out) returns true if the port can be pushed
2.isClosed(out) returns true if the port is closed. At this point the port can not be pushed and will not be pulled anymore.


///The following operations are available for input ports:
1.pull(in) requests a new element from an input port. This is only possible after the port has been pushed by upstream.
2.grab(in) acquires the element that has been received during an onPush(). It cannot be called again until the port is pushed again by the upstream.
3.cancel(in) closes the input port.

//The events corresponding to an input port can be received in an InHandler instance 
//registered to the input port using setHandler(in, handler). 
//This handler has three callbacks:
1.onPush() is called when the input port has now a new element. Now it is possible to acquire this element using grab(in) and/or call pull(in) on the port to request the next element. It is not mandatory to grab the element, but if it is pulled while the element has not been grabbed it will drop the buffered element.
2.onUpstreamFinish() is called once the upstream has completed and no longer can be pulled for new elements. No more onPush() will arrive after this event. If not overridden this will default to stopping the stage.
3.onUpstreamFailure() is called if the upstream failed with an exception and no longer can be pulled for new elements. No more onPush() will arrive after this event. If not overridden this will default to failing the stage.

//there are three query methods available for input ports:
1.isAvailable(in) returns true if the port can be grabbed.
2.hasBeenPulled(in) returns true if the port has been already pulled. Calling pull(in) in this state is illegal.
3.isClosed(in) returns true if the port is closed. At this point the port can not be pulled and will not be pushed anymore.


///there are two methods available for convenience to complete the stage and all of its ports:
1.completeStage() is equivalent to closing all output ports and cancelling all input ports.
2.failStage(exception) is equivalent to failing all output ports and cancelling all input ports.

    
///The operations of this part of the GraphStage API are:
1.emit(out, elem) and emitMultiple(out, Iterable(elem1, elem2)) replaces the OutHandler with a handler that emits one or more elements when there is demand, and then reinstalls the current handlers
2.read(in)(andThen) and readN(in, n)(andThen) replaces the InHandler with a handler that reads one or more elements as they are pushed and allows the handler to react once the requested number of elements has been read.
3.abortEmitting() and abortReading() which will cancel an ongoing emit or read
//You should never call setHandler while they are running emit or read 


//The following methods are safe to call after invoking emit and read 
//(and will lead to actually running the operation when those are done): 
complete(out), completeStage(), emit, emitMultiple, abortEmitting() and abortReading()


///Example 

//Map calls push(out) from the onPush() handler and it also calls pull() from the onPull handler
//resulting in the conceptual wiring

class Map[A, B](f: A ⇒ B) extends GraphStage[FlowShape[A, B]] {

  val in = Inlet[A]("Map.in")
  val out = Outlet[B]("Map.out")

  override val shape = FlowShape.of(in, out)

  override def createLogic(attr: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          push(out, f(grab(in)))
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })
    }
}

///many-to-one stage  - filter.
//by adding a conditional in the onPush handler and decide between a pull(in) or push(out) call
class Filter[A](p: A ⇒ Boolean) extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("Filter.in")
  val out = Outlet[A]("Filter.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          if (p(elem)) push(out, elem)
          else pull(in)
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })
    }
}

///a one-to-many transformation 
//This is a stage that has state: an option with the last element it has seen indicating 
//if it has duplicated this last element already or not. 
//We must also make sure to emit the extra element if the upstream completes.

class Duplicator[A] extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("Duplicator.in")
  val out = Outlet[A]("Duplicator.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      // Again: note that all mutable state
      // MUST be inside the GraphStageLogic
      var lastElem: Option[A] = None

      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          lastElem = Some(elem)
          push(out, elem)
        }

        override def onUpstreamFinish(): Unit = {
          if (lastElem.isDefined) emit(out, lastElem.get)
          complete(out)
        }

      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          if (lastElem.isDefined) {
            push(out, lastElem.get)
            lastElem = None
          } else {
            pull(in)
          }
        }
      })
    }
}
//This example can be simplified by replacing the usage of a mutable state 
//with calls to emitMultiple which will replace the handlers, emit each of multiple elements 
//and then reinstate the original handlers:

class Duplicator[A] extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("Duplicator.in")
  val out = Outlet[A]("Duplicator.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {

      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          // this will temporarily suspend this handler until the two elems
          // are emitted and then reinstates it
          emitMultiple(out, Iterable(elem, elem))
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })
    }
}

//Usage of all above stage 
val resultFuture = Source(1 to 5)
  .via(new Filter(_ % 2 == 0))
  .via(new Duplicator())
  .via(new Map(_ / 2))
  .runWith(sink)
      
      
///Logging inside GraphStages - akka.stream.stage.StageLogging
import akka.stream.stage.{ GraphStage, GraphStageLogic, OutHandler, StageLogging }

final class RandomLettersSource extends GraphStage[SourceShape[String]] {
  val out = Outlet[String]("RandomLettersSource.out")
  override val shape: SourceShape[String] = SourceShape(out)

  override def createLogic(inheritedAttributes: Attributes) =
    new GraphStageLogic(shape) with StageLogging {
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          val c = nextChar() // ASCII lower case letters

          // `log` is obtained from materializer automatically (via StageLogging)
          log.debug("Randomly generated: [{}]", c)

          push(out, c.toString)
        }
      })
    }

  def nextChar(): Char =
    ThreadLocalRandom.current().nextInt('a', 'z'.toInt + 1).toChar
}
    
///Using timers
//to use timers in GraphStages by using TimerGraphStageLogic as the base class for the returned logic. 
//Timers can be scheduled by calling one of 
scheduleOnce(key,delay), schedulePeriodically(key,period) or schedulePeriodicallyWithInitialDelay(key,delay,period) 
//and passing an object as a key for that timer (can be any object, for example a String). 
//The onTimer(key) method needs to be overridden and it will be called once the timer of key fires. 
//It is possible to cancel a timer using cancelTimer(key)
// and check the status of a timer with isTimerActive(key). Timers will be automatically cleaned up when the stage completes.

//Timers can not be scheduled from the constructor of the logic, 
//but it is possible to schedule them from the preStart() lifecycle hook.

// each time an event is pushed through it will trigger a period of silence
class TimedGate[A](silencePeriod: FiniteDuration) extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("TimedGate.in")
  val out = Outlet[A]("TimedGate.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new TimerGraphStageLogic(shape) {

      var open = false

      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          if (open) pull(in)
          else {
            push(out, elem)
            open = true
            scheduleOnce(None, silencePeriod)
          }
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = { pull(in) }
      })

      override protected def onTimer(timerKey: Any): Unit = {
        open = false
      }
    }
}
    
///Using asynchronous side-channels
//In order to receive asynchronous events that are not arriving as stream elements 
//(for example a completion of a future or a callback from a 3rd party API) 
//one must acquire a AsyncCallback by calling getAsyncCallback() from the stage logic. 

//The method getAsyncCallback takes as a parameter a callback 
//that will be called once the asynchronous event fires. 

//It is important to not call the callback directly, 
//instead, the external API must call the invoke(event) method on the returned AsyncCallback. 
//The execution engine will take care of calling the provided callback in a thread-safe way. 
//The callback can safely access the state of the GraphStageLogic implementation.

//Sharing the AsyncCallback from the constructor risks race conditions, 
//therefore it is recommended to use the preStart() lifecycle hook instead.

//example -asynchronous side channel graph stage that starts dropping elements when a future completes:

// will close upstream in all materializations of the graph stage instance
// when the future completes
class KillSwitch[A](switch: Future[Unit]) extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("KillSwitch.in")
  val out = Outlet[A]("KillSwitch.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {

      override def preStart(): Unit = {
        val callback = getAsyncCallback[Unit] { (_) ⇒
          completeStage()
        }
        switch.foreach(callback.invoke)
      }

      setHandler(in, new InHandler {
        override def onPush(): Unit = { push(out, grab(in)) }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = { pull(in) }
      })
    }
}

///Custom materialized values
//Custom stages can return materialized values instead of NotUsed 
//by inheriting from GraphStageWithMaterializedValue instead of the simpler GraphStage. 

//The difference is that in this case the method createLogicAndMaterializedValue(inheritedAttributes) 
//needs to be overridden, and in addition to the stage logic the materialized value must be provided


//Example -the materialized value is a future containing the first element to go through the stream:
class FirstValue[A] extends GraphStageWithMaterializedValue[FlowShape[A, A], Future[A]] {

  val in = Inlet[A]("FirstValue.in")
  val out = Outlet[A]("FirstValue.out")

  val shape = FlowShape.of(in, out)

  override def createLogicAndMaterializedValue(inheritedAttributes: Attributes): (GraphStageLogic, Future[A]) = {
    val promise = Promise[A]()
    val logic = new GraphStageLogic(shape) {

      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          promise.success(elem)
          push(out, elem)

          // replace handler with one just forwarding
          setHandler(in, new InHandler {
            override def onPush(): Unit = {
              push(out, grab(in))
            }
          })
        }
      })

      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })

    }

    (logic, promise.future)
  }
}
    
///*** Akka Streams - Integrating with Actors

//For piping the elements of a stream as messages to an ordinary actor 
//use 'ask' in a mapAsync or use Sink.actorRefWithAck.

//Messages can be sent to a stream with Source.queue 
//or via the ActorRef that is materialized by Source.actorRef.   
    
//def ask[S](parallelism: Int)(ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]
//def ask[S](ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[S]): Repr[S]

implicit val askTimeout = Timeout(5.seconds)
val words: Source[String, NotUsed] =
  Source(List("hello", "hi"))

words
  .ask[String](parallelism = 5)(ref)
  // continue processing of the replies from the actor
  .map(_.toLowerCase)
  .runWith(Sink.ignore)   
    
//The actor must reply to the sender() for each message from the stream. 
//That reply will complete the Future of the ask and it will be the element that is emitted downstreams.

//In case the target actor is stopped, the stage will fail with an AskStageTargetActorTerminatedException
//The stream can be completed with failure by sending akka.actor.Status.Failure as reply from the actor.
class Translator extends Actor {
  def receive = {
    case word: String ⇒
      // ... process message
      val reply = word.toUpperCase
      sender() ! reply // reply to the ask
  }
}

//Source.queue 
//def queue[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, SourceQueueWithComplete[T]]

trait SourceQueueWithComplete[T] extends SourceQueue[T]
    This trait adds completion support to SourceQueue.
    abstract def complete(): Unit
        Complete the stream normally.
    abstract def fail(ex: Throwable): Unit
        Complete the stream with a failure.
    abstract def offer(elem: T): Future[QueueOfferResult]
        Method offers next element to a stream and returns future that: - completes with Enqueued if element is consumed by a stream - completes with Dropped when stream dropped offered element - completes with QueueClosed when stream is completed during future is active - completes with Failure(f) when failure to enqueue element from upstream - fails when stream is completed or you cannot call offer in this moment because of implementation rules (like for backpressure mode and full buffer you need to wait for last offer call Future completion)
    abstract def watchCompletion(): Future[Done]
        Method returns a Future that will be completed if the stream completes, or will be failed when the stage faces an internal failure or the the SourceQueueWithComplete.fail method is invoked.
object QueueOfferResult     
    final case class Failure(cause: Throwable)
        Type is used to indicate that stream is failed before or during call to the stream
    def dropped: QueueOfferResult
        Java API: The Enqueued singleton instance
    def enqueued: QueueOfferResult
        Java API: The Enqueued singleton instance
    object Dropped extends QueueOfferResult with Product with Serializable
        Type is used to indicate that stream is dropped an element
    object Enqueued extends QueueOfferResult with Product with Serializable
        Type is used to indicate that stream is successfully enqueued an element
    object QueueClosed extends QueueOfferResult with Product with Serializable
        Type is used to indicate that stream is completed before call


//Source.queue can be used for emitting elements to a stream from an actor
//SourceQueue.offer offer elements to the queue and they will be emitted to the stream if there is demand from downstream, 
//otherwise they will be buffered until request for demand is received. 
    
//Use overflow strategy akka.stream.OverflowStrategy.backpressure 
//to avoid dropping of elements if the buffer is full./
    
//SourceQueue.offer returns Future[QueueOfferResult] which completes with QueueOfferResult.Enqueued if element was added to buffer or sent downstream. 
//It completes with QueueOfferResult.Dropped if element was dropped.
// Can also complete with QueueOfferResult.Failure - when stream failed or QueueOfferResult.QueueClosed when downstream is completed.
  
//When used from an actor you 'pipe' the result of the Future back to the actor to continue processing.
    
    
    
///Source.actorRef
///actorRef[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, ActorRef] 
//Messages sent to the actor that is materialized by Source.actorRef will be emitted to the stream 
//if there is demand from downstream, otherwise they will be buffered until request for demand is received.
   
//The stream can be completed successfully by sending akka.actor.PoisonPill 
//or akka.actor.Status.Success to the actor reference.

//The stream can be completed with failure by sending akka.actor.Status.Failure to the actor reference. 
    
    
///Integrating with External Services
//Stream transformations and side effects involving external non-stream based services 
//can be performed with mapAsync or mapAsyncUnordered.

//For example, sending emails to the authors of selected tweets using an external email service:
def send(email: Email): Future[Unit] = {
  // ...
}

//start with the tweet stream of authors:
val authors: Source[Author, NotUsed] =
  tweets
    .filter(_.hashtags.contains(akkaTag))
    .map(_.author)


def lookupEmail(handle: String): Future[Option[String]] = ???
    
//Transforming the stream of authors to a stream of email addresses 
val emailAddresses: Source[String, NotUsed] =
  authors
    .mapAsync(4)(author ⇒ addressSystem.lookupEmail(author.handle))
    .collect { case Some(emailAddress) ⇒ emailAddress }
    
//sending the emails:
val sendEmails: RunnableGraph[NotUsed] =
  emailAddresses
    .mapAsync(4)(address ⇒ {
      emailServer.send(
        Email(to = address, title = "Akka", body = "I like your tweet"))
    })
    .to(Sink.ignore)

sendEmails.run()    
    
//mapAsync preserves the order of the stream elements. 
//Or use  mapAsyncUnordered:
val authors: Source[Author, NotUsed] =
  tweets.filter(_.hashtags.contains(akkaTag)).map(_.author)

val emailAddresses: Source[String, NotUsed] =
  authors
    .mapAsyncUnordered(4)(author ⇒ addressSystem.lookupEmail(author.handle))
    .collect { case Some(emailAddress) ⇒ emailAddress }

val sendEmails: RunnableGraph[NotUsed] =
  emailAddresses
    .mapAsyncUnordered(4)(address ⇒ {
      emailServer.send(
        Email(to = address, title = "Akka", body = "I like your tweet"))
    })
    .to(Sink.ignore)

sendEmails.run()
    
//Note external services must return a Future of the result. 
//OR  wrap the call in a Future. 

//If the service call involves blocking , make sure that you run it on a dedicated execution context, 
//to avoid starvation and disturbance of other tasks in the system.
val blockingExecutionContext = system.dispatchers.lookup("blocking-dispatcher")

val sendTextMessages: RunnableGraph[NotUsed] =
  phoneNumbers
    .mapAsync(4)(phoneNo ⇒ {
      Future {
        smsServer.send(
          TextMessage(to = phoneNo, body = "I like your tweet"))
      }(blockingExecutionContext)
    })
    .to(Sink.ignore)

sendTextMessages.run()
//The configuration of the "blocking-dispatcher" may look something like:
blocking-dispatcher {
  executor = "thread-pool-executor"
  thread-pool-executor {
    core-pool-size-min    = 10
    core-pool-size-max    = 10
  }
}

//An alternative for blocking calls is to perform them in a map operation, 
//using a dedicated dispatcher for that operation.
//that is not exactly the same as mapAsync, since the mapAsync may run several calls concurrently, 
//but map performs them one at a time.

val send = Flow[String]
  .map { phoneNo ⇒
    smsServer.send(TextMessage(to = phoneNo, body = "I like your tweet"))
  }
  .withAttributes(ActorAttributes.dispatcher("blocking-dispatcher"))
val sendTextMessages: RunnableGraph[NotUsed] =
  phoneNumbers.via(send).to(Sink.ignore)

sendTextMessages.run()


//For a service that is exposed as an actor, or if an actor is used as a gateway in front of an external service, 
//use ask:
import akka.pattern.ask

val akkaTweets: Source[Tweet, NotUsed] = tweets.filter(_.hashtags.contains(akkaTag))

implicit val timeout = Timeout(3.seconds)
val saveTweets: RunnableGraph[NotUsed] =
  akkaTweets
    .mapAsync(4)(tweet ⇒ database ? Save(tweet))
    .to(Sink.ignore)  
    
///*** Akka Streams - Integrating with Reactive Streams
//Reactive Streams defines a standard for asynchronous stream processing with non-blocking back pressure. 
//Akka Streams is one such library.
//An incomplete list of other implementations:
    Reactor (1.1+)
    RxJava
    Ratpack
    Slick

//The two most important interfaces in Reactive Streams are the Publisher and Subscriber.
import org.reactivestreams.Publisher
import org.reactivestreams.Subscriber

//Let us assume that a library provides a publisher of tweets:
def tweets: Publisher[Tweet]

//and another library knows how to store author handles in a database:
def storage: Subscriber[Author]

//Using an Akka Streams Flow we can transform the stream and connect those:
val authors = Flow[Tweet]
  .filter(_.hashtags.contains(akkaTag))
  .map(_.author)

Source.fromPublisher(tweets).via(authors).to(Sink.fromSubscriber(storage)).run()

//The Publisher is used as an input Source to the flow and the Subscriber is used as an output Sink.
//A Flow can also be also converted to a RunnableGraph[Processor[In, Out]] 
//which materializes to a Processor when run() is called. 
val processor: Processor[Tweet, Author] = authors.toProcessor.run()
tweets.subscribe(processor)
processor.subscribe(storage)

//A publisher can be connected to a subscriber with the subscribe method.
//It is also possible to expose a Source as a Publisher by using the Publisher-Sink:
val authorPublisher: Publisher[Author] =
  Source.fromPublisher(tweets).via(authors).runWith(Sink.asPublisher(fanout = false))

authorPublisher.subscribe(storage)

//A publisher that is created with Sink.asPublisher(fanout = false) 
//supports only a single subscription.
//A publisher that supports multiple subscribers using fan-out/broadcasting is created as follows:
def alert: Subscriber[Author]
def storage: Subscriber[Author]

val authorPublisher: Publisher[Author] =
  Source.fromPublisher(tweets).via(authors)
    .runWith(Sink.asPublisher(fanout = true))

authorPublisher.subscribe(storage)
authorPublisher.subscribe(alert)



//it is also possible to expose a Sink as a Subscriber by using the Subscriber-Source:
val tweetSubscriber: Subscriber[Tweet] =
  authors.to(Sink.fromSubscriber(storage)).runWith(Source.asSubscriber[Tweet])

tweets.subscribe(tweetSubscriber)


//It is also possible to use re-wrap Processor instances 
//as a Flow by passing a factory function that will create the Processor instances:
// An example Processor factory
def createProcessor: Processor[Int, Int] = Flow[Int].toProcessor.run()

val flow: Flow[Int, Int, NotUsed] = Flow.fromProcessor(() ⇒ createProcessor)



///Implementing Reactive Streams Publisher or Subscriber
// any Akka Streams Source can be exposed as a Reactive Streams Publisher 
//and any Sink can be exposed as a Reactive Streams Subscriber. 
//hence use Reactive Streams integrations with built-in stages(ag given above) or custom stages.

//DEPRECATED:
//ActorPublisher and ActorSubscriber traits are provided to support implementing Reactive Streams Publisher and Subscriber with an Actor.
//These can be consumed by other Reactive Stream libraries or used as an Akka Streams Source or Sink.

//ActorPublisher and ActorSubscriber cannot be used with remote actors, 
//because if signals of the Reactive Streams protocol (e.g. request) are lost the the stream may deadlock.


///ActorPublisher
//Extend akka.stream.actor.ActorPublisher in  Actor to make it a stream publisher that keeps track of the subscription life cycle and requested elements.

//Example Actor - dispatches incoming jobs to the attached subscriber:
//Steps 
1.send elements to the stream by calling onNext.
  You are allowed to send as many elements as have been requested by the stream subscriber. 
  This amount can be inquired with totalDemand. 
  It is only allowed to use onNext when isActive and totalDemand>0, 
  otherwise onNext will throw IllegalStateException.
2.When the stream subscriber requests more elements 
  the ActorPublisherMessage.Request message is delivered to this actor, and you can act on that event. 
  The totalDemand is updated automatically.
3.When the stream subscriber cancels the subscription 
  the ActorPublisherMessage.Cancel message is delivered to this actor. 
  After that subsequent calls to onNext will be ignored.
4.complete the stream by calling onComplete.
  After that you are not allowed to call onNext, onError and onComplete.
5.You can terminate the stream with failure by calling onError.
  After that you are not allowed to call onNext, onError and onComplete.
6.If you suspect that this ActorPublisher may never get subscribed to, 
  you can override the subscriptionTimeout method to provide a timeout 
  after which this Publisher should be considered canceled. The actor will be notified when the timeout triggers via an ActorPublisherMessage.SubscriptionTimeoutExceeded message and MUST then perform cleanup and stop itself.
7.If the actor is stopped the stream will be completed, 
  unless it was not already terminated with failure, completed or canceled.

//code 
object JobManager {
  def props: Props = Props[JobManager]

  final case class Job(payload: String)
  case object JobAccepted
  case object JobDenied
}

class JobManager extends ActorPublisher[JobManager.Job] {
  import akka.stream.actor.ActorPublisherMessage._
  import JobManager._

  val MaxBufferSize = 100
  var buf = Vector.empty[Job]

  def receive = {
    case job: Job if buf.size == MaxBufferSize ⇒
      sender() ! JobDenied
    case job: Job ⇒
      sender() ! JobAccepted
      if (buf.isEmpty && totalDemand > 0)
        onNext(job)
      else {
        buf :+= job
        deliverBuf()
      }
    case Request(_) ⇒
      deliverBuf()
    case Cancel ⇒
      context.stop(self)
  }

  @tailrec final def deliverBuf(): Unit =
    if (totalDemand > 0) {
      /*
       * totalDemand is a Long and could be larger than
       * what buf.splitAt can accept
       */
      if (totalDemand <= Int.MaxValue) {
        val (use, keep) = buf.splitAt(totalDemand.toInt)
        buf = keep
        use foreach onNext
      } else {
        val (use, keep) = buf.splitAt(Int.MaxValue)
        buf = keep
        use foreach onNext
        deliverBuf()
      }
    }
}

//useage as input Source to a Flow:
val jobManagerSource = Source.actorPublisher[JobManager.Job](JobManager.props)
val ref = Flow[JobManager.Job]
  .map(_.payload.toUpperCase)
  .map { elem ⇒ println(elem); elem }
  .to(Sink.ignore)
  .runWith(jobManagerSource)

ref ! JobManager.Job("a")
ref ! JobManager.Job("b")
ref ! JobManager.Job("c")



///ActorSubscriber
//Extend akka.stream.actor.ActorSubscriber in your Actor to make it a stream subscriber 
//with full control of stream back pressure. 
//It will receive ActorSubscriberMessage.OnNext, ActorSubscriberMessage.OnComplete 
and ActorSubscriberMessage.OnError messages from the stream. 
//It can also receive other, non-stream messages, in the same way as any actor.

//Example Actor -  dispatches incoming jobs to child worker actors:
object WorkerPool {
  case class Msg(id: Int, replyTo: ActorRef)
  case class Work(id: Int)
  case class Reply(id: Int)
  case class Done(id: Int)

  def props: Props = Props(new WorkerPool)
}

class WorkerPool extends ActorSubscriber {
  import WorkerPool._
  import ActorSubscriberMessage._

  val MaxQueueSize = 10
  var queue = Map.empty[Int, ActorRef]

  val router = {
    val routees = Vector.fill(3) {
      ActorRefRoutee(context.actorOf(Props[Worker]))
    }
    Router(RoundRobinRoutingLogic(), routees)
  }

  override val requestStrategy = new MaxInFlightRequestStrategy(max = MaxQueueSize) {
    override def inFlightInternally: Int = queue.size
  }

  def receive = {
    case OnNext(Msg(id, replyTo)) ⇒
      queue += (id -> replyTo)
      assert(queue.size <= MaxQueueSize, s"queued too many: ${queue.size}")
      router.route(Work(id), self)
    case Reply(id) ⇒
      queue(id) ! Done(id)
      queue -= id
      if (canceled && queue.isEmpty) {
        context.stop(self)
      }
    case OnComplete ⇒
      if (queue.isEmpty) {
        context.stop(self)
      }
  }
}

class Worker extends Actor {
  import WorkerPool._
  def receive = {
    case Work(id) ⇒
      // ...
      sender() ! Reply(id)
  }
}
//Usage -  as output Sink to a Flow:
val N = 117
val worker = Source(1 to N).map(WorkerPool.Msg(_, replyTo))
  .runWith(Sink.actorSubscriber(WorkerPool.props))    
    
    
///*** Akka Stream - Configuration

#####################################
# Akka Stream Reference Config File #
#####################################

akka {
  stream {

    # Default materializer settings
    materializer {

      # Initial size of buffers used in stream elements
      initial-input-buffer-size = 4
      # Maximum size of buffers used in stream elements
      max-input-buffer-size = 16

      # Fully qualified config path which holds the dispatcher configuration
      # to be used by ActorMaterializer when creating Actors.
      # When this value is left empty, the default-dispatcher will be used.
      dispatcher = ""

      blocking-io-dispatcher = "akka.stream.default-blocking-io-dispatcher"

      # Cleanup leaked publishers and subscribers when they are not used within a given
      # deadline
      subscription-timeout {
        # when the subscription timeout is reached one of the following strategies on
        # the "stale" publisher:
        # cancel - cancel it (via `onError` or subscribing to the publisher and
        #          `cancel()`ing the subscription right away
        # warn   - log a warning statement about the stale element (then drop the
        #          reference to it)
        # noop   - do nothing (not recommended)
        mode = cancel

        # time after which a subscriber / publisher is considered stale and eligible
        # for cancelation (see `akka.stream.subscription-timeout.mode`)
        timeout = 5s
      }

      # Enable additional troubleshooting logging at DEBUG log level
      debug-logging = off

      # Maximum number of elements emitted in batch if downstream signals large demand
      output-burst-limit = 1000

      # Enable automatic fusing of all graphs that are run. For short-lived streams
      # this may cause an initial runtime overhead, but most of the time fusing is
      # desirable since it reduces the number of Actors that are created.
      # Deprecated, since Akka 2.5.0, setting does not have any effect.
      auto-fusing = on

      # Those stream elements which have explicit buffers (like mapAsync, mapAsyncUnordered,
      # buffer, flatMapMerge, Source.actorRef, Source.queue, etc.) will preallocate a fixed
      # buffer upon stream materialization if the requested buffer size is less than this
      # configuration parameter. The default is very high because failing early is better
      # than failing under load.
      #
      # Buffers sized larger than this will dynamically grow/shrink and consume more memory
      # per element than the fixed size buffers.
      max-fixed-buffer-size = 1000000000

      # Maximum number of sync messages that actor can process for stream to substream communication.
      # Parameter allows to interrupt synchronous processing to get upsteam/downstream messages.
      # Allows to accelerate message processing that happening withing same actor but keep system responsive.
      sync-processing-limit = 1000

      debug {
        # Enables the fuzzing mode which increases the chance of race conditions
        # by aggressively reordering events and making certain operations more
        # concurrent than usual.
        # This setting is for testing purposes, NEVER enable this in a production
        # environment!
        # To get the best results, try combining this setting with a throughput
        # of 1 on the corresponding dispatchers.
        fuzzing-mode = off
      }

      io.tcp {
        # The outgoing bytes are accumulated in a buffer while waiting for acknoledgment
        # of pending write. This improves throughput for small messages (frames) without
        # sacrificing latency. While waiting for the ack the stage will eagerly pull
        # from upstream until the buffer exceeds this size. That means that the buffer may hold
        # slightly more bytes than this limit (at most one element more). It can be set to 0
        # to disable the usage of the buffer.
        write-buffer-size = 16 KiB
      }

      # configure defaults for SourceRef and SinkRef
      stream-ref {
        # Buffer of a SinkRef that is used to batch Request elements from the other side of the stream ref
        #
        # The buffer will be attempted to be filled eagerly even while the local stage did not request elements,
        # because the delay of requesting over network boundaries is much higher.
        buffer-capacity = 32

        # Demand is signalled by sending a cumulative demand message ("requesting messages until the n-th sequence number)
        # Using a cumulative demand model allows us to re-deliver the demand message in case of message loss (which should
        # be very rare in any case, yet possible -- mostly under connection break-down and re-establishment).
        #
        # The semantics of handling and updating the demand however are in-line with what Reactive Streams dictates.
        #
        # In normal operation, demand is signalled in response to arriving elements, however if no new elements arrive
        # within `demand-redelivery-interval` a re-delivery of the demand will be triggered, assuming that it may have gotten lost.
        demand-redelivery-interval = 1 second

        # Subscription timeout, during which the "remote side" MUST subscribe (materialize) the handed out stream ref.
        # This timeout does not have to be very low in normal situations, since the remote side may also need to
        # prepare things before it is ready to materialize the reference. However the timeout is needed to avoid leaking
        # in-active streams which are never subscribed to.
        subscription-timeout = 30 seconds
      }
    }

    # Deprecated, use akka.stream.materializer.blocking-io-dispatcher, this setting
    # It must still have a valid value becuase used from Akka HTTP.
    blocking-io-dispatcher = "akka.stream.default-blocking-io-dispatcher"

    default-blocking-io-dispatcher {
      type = "Dispatcher"
      executor = "thread-pool-executor"
      throughput = 1

      thread-pool-executor {
        fixed-pool-size = 16
      }
    }

  }

  # configure overrides to ssl-configuration here (to be used by akka-streams, and akka-http – i.e. when serving https connections)
  ssl-config {
    protocol = "TLSv1.2"
  }

  actor {

    serializers {
      akka-stream-ref = "akka.stream.serialization.StreamRefSerializer"
    }

    serialization-bindings {
      "akka.stream.SinkRef"                           = akka-stream-ref
      "akka.stream.SourceRef"                         = akka-stream-ref
      "akka.stream.impl.streamref.StreamRefsProtocol" = akka-stream-ref
    }

    serialization-identifiers {
      "akka.stream.serialization.StreamRefSerializer" = 30
    }
  }
}

# ssl configuration
# folded in from former ssl-config-akka module
ssl-config {
  logger = "com.typesafe.sslconfig.akka.util.AkkaLoggerBridge"
}
