///*** Promises
//Single update variable, update success with 'success', failure with 'failure' methods
// get result from promise.future
//For multiple updates, use akka.Agent

import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global

val p = Promise[Int]
val f = p.future

val producer = Future {
  //val r = produceSomething()
  Thread.sleep(2000)
  val r = 25
  p success r
  //continueDoingSomethingUnrelated()
  Thread.sleep(2000)
}

val consumer = Future {
  Thread.sleep(200)
  f onSuccess {
    case r =>    println(r) // doSomethingWithResult()
  }
   Thread.sleep(6000)
}

//The method completeWith completes the promise with another future

val f = Future { 1 }
val p = Promise[Int]

p completeWith f

p.future onSuccess {
  case x => println(x)
}


//trySuccess(value: T): Boolean 
//Tries to complete the promise with a value.

//first which takes two futures f and g and produces a third future 
//which is completed by either f or g (whichever comes first), but only given that it is successful.

def first[T](f: Future[T], g: Future[T]): Future[T] = {
  val p = promise[T]

  f onSuccess {
    case x => p.trySuccess(x)
  }

  g onSuccess {
    case x => p.trySuccess(x)
  }

  p.future
}

//Companion Object Promise
//Creates a completed Promise with the specified exception.
def failed[T](exception: Throwable): Promise[T]
//Creates a completed Promise with the specified result.
def successful[T](result: T): Promise[T] 
//Creates a completed Promise with the specified result or exception.
def fromTry[T](result: Try[T]): Promise[T] 








///*** Concurrent Programming - Agent -- Introduction
//Agents provide asynchronous change of individual locations


//Agent only for local thread systems
import akka.agent.Agent
import scala.concurrent.ExecutionContext.Implicits.global

val a = Agent[Int](3)  //initial value

val result = a.get  // or val f = a.future   to get a future

//To update 
a.send { x => x+1 }
a.get //4
//Or with Thread

class A( val a:Agent[Int], val flag:Boolean, val l:AnyRef ) extends Runnable {  
  def run() { if (flag) up() else re()}  
  def up() { 
	for(i <- 0 to 3) { Thread.sleep(5); println("updating..." + i + " " + Thread.currentThread + " "); a.send(_+1)} 
} 
  def re() {
	 for(i <- 0 to 3) { Thread.sleep(5); println("Reading..." + i + " " + Thread.currentThread + " "+ a.get); } 
  } 
} 


val ag = Agent(3)
val up = new A(ag, flag=true, null)
val re = new A(ag, flag=false, null)
new Thread(up).start; new Thread(re).start







///*** Akka Actor

"""
For a mutable state under concurrent  
wrap that mutable state inside an Actor 
and make the clients communicate with the Actor via message
 
 
To avoid the queue getting full, Make message processing (react, receive, etc.) 
be as short as possible. 

Long-running tasks should be handed off to an other actor:
1.  Actor A receives a message M from sender S
2.  A spawns a new actor C
3.  A sends (S, M) to C
4.  In parallel:
4a. A starts processing the next message.
4b. C does the long-running or dangerous (IO) task,
    When finished, sends the result to S,
    and C terminates.

Some alternatives in the process: 
�C sends (S, result) back to A who forwards to S
�A keeps a mapping ActorRef C => (Sender S, Message M) so in case it sees C fail, 
it can retry processing M with a new Actor.

it is guaranteed that the Actor will process all these messages serially 
Hence Actor's internal state  doesn't need synchronization, 
"""

//These are the rules for message sends by default 
//to change check Persistence
at-most-once delivery, i.e. no guaranteed delivery, 
    that message is delivered zero or one times
    For a given pair of actors, messages sent directly from the first to the second 
    will not be received out-of-order.


//Message sending 
! , tell
    send a message, 
    Note any message can be sent, eg, Int, String, any user defined Class/object(must be immutable and Serializable)
?,ask 
    Sends a message and wait for future
    
//An actor has a well-defined (non-cyclic) life-cycle.
1.RUNNING (created and started actor) - can receive messages
2.SHUTDOWN (when 'stop' is invoked) - canot do anything

//Important attributes of Actor 
1.The Actor own akka.actor.ActorRef is available as self, 
2.the current message sender as sender() 
3.the akka.actor.ActorContext as context. 
4.abstract method ,receive returns the initial behavior of the actor as a partial function 
 (behavior can be changed using context.become and context.unbecome).

//the Akka Actor receive message loop is exhaustive
//Otherwise an 
akka.actor.UnhandledMessage(message, sender, recipient) 
//will be published to the ActorSystem's EventStream.


import akka.actor._
import akka.event.Logging
import scala.util._
 
class MyActor extends Actor {
  val log = Logging(context.system, this)
  println(self.path)
  val rand = new Random(1234)
  def receive = {
    case "test" => log.info("received test")
                   Thread.sleep(1000)
                   if ( sender() != Actor.noSender ){
                        sender() ! rand.nextInt
                    }
    case _      => log.info("received unknown message")
  }
}

import akka.actor.{ActorSystem, Props}
implicit val system = ActorSystem("testSystem")
val firstRef = system.actorOf(Props[MyActor], "first-actor")
println(s"First: $firstRef")  //akka://testSystem/user/first-actor
firstRef ! "test"
//output 
[INFO] [03/30/2018 10:38:20.604] [testSystem-akka.actor.default-dispatcher-2] [akka.tcp://testSystem@127.0.0.1:2552/user/first-actor] received test


//Via selection 
val selection = system.actorSelection("akka.tcp://testSystem@127.0.0.1:2552/user/first-actor")
import ActorDSL._
import scala.concurrent.duration._

//with Actor-DSL , deprecated 
implicit val i = inbox()
selection ! Identify(1) // replies will go to `i`

val reply:ActorIdentity = i.receive().asInstanceOf[ActorIdentity]
reply.ref.get ! "test"
//or 
val transformedReply = i.select(5 seconds) {
  case ActorIdentity(correlationId, actorRefOption) => 
                            println("" + correlationId + " " + actorRefOption)
                            actorRefOption.map{ actorRef => actorRef ! "test" }
                            
}
//or 
import scala.concurrent.duration._ 
import scala.concurrent._
val timeout:FiniteDuration = 1 second
val fut = selection.resolveOne(timeout)
val actorRef = Await.result(fut, Duration.Inf)
actorRef ! "test"  //returns goes to deadletter

//Ask pattern 
import akka.pattern.{ ask, pipe }
import akka.util._ 
import akka.actor.{ActorSystem, Props}
import scala.concurrent.duration._ 

import system.dispatcher // The ExecutionContext that will be used
 
implicit val timeout = Timeout(5 seconds) // needed for `?` below

//from old example 
(firstRef ? "test") onSuccess { case f:Int => println(f) }


//Shutdown 
firstRef ! PoisonPill
system.terminate()


///* Messages can be any kind of object but have to be immutable.
// define as case class
final case class Result(x: Int, s: String, d: Double)
case object Request
 
// create a new case class message
val message = Result(1,"OK",2.5)

///* Tell: Fire-forget
actorA ! message

///* Ask: Send-And-Receive-Future
//onCompleteonComplete[U](f: (Try[T]) => U), onSuccess[U](pf: PartialFunction[T, U]), or onFailure[U](pf: PartialFunction[Throwable, U]) methods of the Future can be used to register 
//a callback to get a notification when the Future completes,

import akka.pattern.{ ask, pipe }
import akka.util._ 
import akka.actor.{ActorSystem, Props}
import scala.concurrent.duration._ 

implicit val system = ActorSystem("testSystem")
import system.dispatcher // The ExecutionContext that will be used
 
implicit val timeout = Timeout(5 seconds) // needed for `?` below

 
//the receiving actor must reply with sender() ! reply
val f: Future[Result] =
  for {
    x <- ask(actorA, Request).mapTo[Int] // call pattern directly
    s <- (actorB ask Request).mapTo[String] // call by implicit conversion
    d <- (actorC ? Request).mapTo[Double] // call by symbolic name
  } yield Result(x, s, d)
 
// pipeTo/pipe installs an onComplete-handler on the future
// and send Result to another Actor 
//must have implicit ExecutionContext in the context 
f pipeTo actorD // .. or ..
pipe(f) to actorD

//To complete the future with an exception you need send a Failure message to the sender. 
//This is not done automatically when an actor throws an exception while processing a message.
try {
  val result = operation()
  sender() ! result
} catch {
  case e: Exception =>
    sender() ! akka.actor.Status.Failure(e)
    throw e
}

//AskTimeoutException  :If the actor does not complete the future, raise this exception
import scala.concurrent.duration._
import akka.pattern.ask
val future = myActor.ask("hello")(5 seconds)

//OR with implicit argument of type akka.util.Timeout
import scala.concurrent.duration._
import akka.util.Timeout
import akka.pattern.ask
implicit val timeout = Timeout(5 seconds)
val future = myActor ? "hello"


///*forward a message from one actor to another. 
//the original sender reference is maintained in 'target' when sender() is used 
target forward message


///*Reply to messages, sender()
//store the ActorRef for replying later, or passing on to other actors. 
//If there is no sender (a message was sent without an actor or future context) 
//then the sender defaults to a 'dead-letter' actor ref.
case request =>
  val result = process(request)
  sender() ! result       // will have dead-letter actor as default
  
  
  
  
///*** Actor - Ping-Pong Example 
import akka.actor._

class A extends Actor {
  def receive = {
    case "test" => println("From A - test")
        sender ! "stop"  //sender must be another actor 
    case "stop" => println (" From A - stopped")
        context.stop(self)
    case "Ping" => 
        Thread.sleep(1000)
        println("From A - Ping")
        sender ! "Pong"
    
    case x: String => println("From A -" + x)
    case _ =>
    }
}

class B(val a:ActorRef) extends Actor {    
   //actorFor is non existing in latest akka , there are other ways to get actor
  //val tmp = act getOrElse context.system.actorFor ("akka://mySystem/user/A") 
  
  def receive = { 
    case "stop" => a ! "stop"
          println ("From B- stopped")
          context.stop(self)
    case "doIt" => println("From B - Done")
            a ! "test"
    case "Pong" => 
        Thread.sleep(1000)
        println("From B - Pong")
        a ! "Ping"
    case _  => 
    }
}



val system = ActorSystem("mySystem")  //akka://mySystem
val a = system.actorOf(Props[A], "A")  //Actor[akka://mySystem/user/A#748617404]
a ! "OK"
val b = system.actorOf(Props(new B(a)), "B")
b ! "Pong"
Thread.sleep(10000); b ! "doIt"
system.shutdown()


//ask pattern 
import scala.concurrent.duration._
import scala.concurrent._
import   akka.pattern._  //for ask or ?
import   akka.util._     //for TimeOut
import scala.concurrent.ExecutionContext.Implicits.global
//or 
//import system.dispatcher


implicit val timeout = Timeout(5 seconds)
val f = a ? "Ping"
val result = Await.result(f, Duration.Inf).asInstanceOf[String]
println(result)

//alternate 
val f: Future[String] = ask(a, "Ping").mapTo[String]  
val result = Await.result(f, Duration.Inf)

//with constructor args
val pp = Props(classOf[B], a);
val b = system.actorOf(pp, "B")  
b ! "doIt"


///*** Actor - Members of Actor 
type Receive = PartialFunction[Any, Unit] 
abstract def receive: Actor.Receive
    This defines the initial actor behavior, it must return a partial function with the actor logic.
implicit val context: ActorContext
    Stores the context for this actor, including self, and sender.
def postRestart(reason: Throwable): Unit
    User overridable callback: By default it calls preStart().
def postStop(): Unit
    User overridable callback.
def preRestart(reason: Throwable, message: Option[Any]): Unit
    User overridable callback: By default it disposes of all children and then calls postStop().
def preStart(): Unit
    User overridable callback.
implicit final val self: ActorRef
    The 'self' field holds the ActorRef for this actor.
final def sender(): ActorRef
    The reference sender Actor of the last received message.
def supervisorStrategy: SupervisorStrategy
    User overridable definition the strategy to use for supervising child actors.
def unhandled(message: Any): Unit
    User overridable callback.

///import the members in the context to avoid prefixing access with context.
class FirstActor extends Actor {
  import context._
  val myActor = actorOf(Props[MyActor], name = "myactor")
  def receive = {
    case x => myActor ! x
  }
}


///*** Actor - ActorSystem and Actor naming 
/ ,the  root guardian. 
    This is the parent of all actors in the system, and the last one to stop when the system itself is terminated.
/user ,the guardian. 
    This is the parent actor for all user created actors. 
    Every actor you create using the Akka library will have the constant path /user/ prepended to it.
    system.actorOf(), creates an actor directly under /user.
    context.actorOf() from an existing actor, creates actors under that existing actor 
/system ,the system guardian.
    Internal actor system 
    
//Example for Actor naming 
import akka.actor.{ Actor, Props, ActorSystem }
import scala.io.StdIn

class PrintMyActorRefActor extends Actor {
  override def receive: Receive = {
    case "printit" =>
      val secondRef = context.actorOf(Props.empty, "second-actor")
      println(s"Second: $secondRef")
  }
}

object ActorHierarchyExperiments extends App {
  val system = ActorSystem("testSystem")

  val firstRef = system.actorOf(Props[PrintMyActorRefActor], "first-actor")
  println(s"First: $firstRef")
  firstRef ! "printit"

  println(">>> Press ENTER to exit <<<")
  try StdIn.readLine()
  finally system.terminate()
}
//Output 
//First: Actor[akka://testSystem/user/first-actor#1053618476]
//Second: Actor[akka://testSystem/user/first-actor/second-actor#-1544706041]



///*** Actor - supervisorStrategy
case class  AllForOneStrategy(maxNrOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf, loggingEnabled: Boolean = true)(decider: Decider) extends SupervisorStrategy with Product with Serializable  
    Applies the fault handling Directive (Resume, Restart, Stop) specified in the Decider to all children when one fails, as opposed to akka.actor.OneForOneStrategy that applies it only to the child actor that failed. 
    maxNrOfRetries
        the number of times a child actor is allowed to be restarted, negative value means no limit, if the limit is exceeded the child actor is stopped
    withinTimeRange
        duration of the time window for maxNrOfRetries, Duration.Inf means no window
    loggingEnabled
        the strategy logs the failure if this is enabled (true), by default it is enabled
    decider
        mapping from Throwable to akka.actor.SupervisorStrategy.Directive, you can also use a scala.collection.immutable.Seq of Throwables which maps the given Throwables to restarts, otherwise escalates.
case class  OneForOneStrategy(maxNrOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf, loggingEnabled: Boolean = true)(decider: Decider) extends SupervisorStrategy with Product with Serializable  
    Applies the fault handling Directive (Resume, Restart, Stop) specified in the Decider to the child actor that failed, as opposed to akka.actor.AllForOneStrategy that applies it to all children. 
    maxNrOfRetries
        the number of times a child actor is allowed to be restarted, negative value means no limit, if the limit is exceeded the child actor is stopped
    withinTimeRange
        duration of the time window for maxNrOfRetries, Duration.Inf means no window
    loggingEnabled
        the strategy logs the failure if this is enabled (true), by default it is enabled
    decider
        mapping from Throwable to akka.actor.SupervisorStrategy.Directive, you can also use a scala.collection.immutable.Seq of Throwables which maps the given Throwables to restarts, otherwise escalates.
class  ClusterMetricsStrategy extends OneForOneStrategy  
    Default ClusterMetricsSupervisor strategy: A configurable akka.actor.OneForOneStrategy with restart-on-throwable decider. 

    
///Creating a Supervisor Strategy
import akka.actor.OneForOneStrategy
import akka.actor.SupervisorStrategy._
import scala.concurrent.duration._
 
override val supervisorStrategy = OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 1 minute) {
    case _: ArithmeticException      => Resume
    case _: NullPointerException     => Restart
    case _: IllegalArgumentException => Stop
    case _: Exception                => Escalate
  }

//one-for-one strategy, meaning that each child is treated separately 
//all-for-one strategy works very similarly, the only difference is that any decision is applied to all children of the supervisor, not only the failing one

//There are limits set on the restart frequency, namely maximum 10 restarts per minute; 
//The child actor is stopped if the limit is exceeded.

//The match statement is of type Decider, which is a PartialFunction[Throwable, Directive]


//Escalate is used if the defined strategy doesn't cover the exception that was thrown.
//the following exceptions are handled by default:
ActorInitializationException    will stop the failing child actor
ActorKilledException            will stop the failing child actor
Exception                       will restart the failing child actor
Other types of Throwable        will be escalated to parent actor

//If the exception escalate all the way up to the root guardian 
//it will handle it in the same way as the default strategy defined above.

//You can combine your own strategy with the default strategy:
import akka.actor.OneForOneStrategy
import akka.actor.SupervisorStrategy._
import scala.concurrent.duration._
 
override val supervisorStrategy =  OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 1 minute) {
    case _: ArithmeticException => Resume
    case t =>
      super.supervisorStrategy.decider.applyOrElse(t, (_: Any) => Escalate)
  }

//You can mute the default logging of a SupervisorStrategy 
//by setting loggingEnabled to false when instantiating it. 




///*** Actor - Props
import akka.actor.Props
 
val props1 = Props[MyActor]
val props3 = Props(classOf[ActorWithArgs], "arg", "arg2") // RECO , but not for value class arguments

val props2 = Props(new ActorWithArgs("arg")) // not RECO, especially within another actor 
val props7 = Props(new MyActor)  // not RECO, especially within another actor 

//via system 
system.actorOf(props1, "name")
system.actorOf(props2)
system.actorOf(Props[MyActor], "name")
system.actorOf(Props(classOf[MyActor], arg1, arg2), "name")

//via context 
context.actorOf(props1, "name")
context.actorOf(props2)
context.actorOf(Props[MyActor])
context.actorOf(Props(classOf[MyActor], arg1, arg2), "name")

///unsupported in above syntax 
1.An actor with AnyVal arguments.
2.An actor with default constructor values.

///How to handle value class 
class Argument(val value: String) extends AnyVal
class ValueClassActor(arg: Argument) extends Actor {
  def receive = { case _ => () }
}
 
object ValueClassActor {
  def props1(arg: Argument) = Props(classOf[ValueClassActor], arg) // fails at runtime
  def props2(arg: Argument) = Props(classOf[ValueClassActor], arg.value) // ok
  def props3(arg: Argument) = Props(new ValueClassActor(arg)) // ok
}



//*RECOMENDED Practice even for above unsupported case 
//provide factory methods on the companion object of each Actor 
//which help keeping the creation of suitable Props as close to the actor definition as possible. 


object DemoActor {
  /**
   * Create Props for an actor of this type.
   *
   * @param magicNumber The magic number to be passed to this actor�s constructor.
   * @return a Props for creating this actor, which can then be further configured
   *         (e.g. calling `.withDispatcher()` on it)
   */
  def props(magicNumber: Int): Props = Props(new DemoActor(magicNumber))
}
 
class DemoActor(magicNumber: Int) extends Actor {
  def receive = {
    case x: Int => sender() ! (x + magicNumber)
  }
}
 
class SomeOtherActor extends Actor {
  // Props(new DemoActor(42)) would not be safe
  context.actorOf(DemoActor.props(42), "demo")
  // ...
}

///Another good practice is to declare 
//what messages an Actor can receive in the companion object of the Actor, which makes easier to know what it can receive:

object MyActor {
  case class Greeting(from: String)
  case object Goodbye
}
class MyActor extends Actor with ActorLogging {
  import MyActor._
  def receive = {
    case Greeting(greeter) => log.info(s"I was greeted by $greeter.")
    case Goodbye           => log.info("Someone said goodbye to me.")
  }
}

///*** Actor - ActorRef and  sender()
//ActorRefs can be freely shared among actors by message passing. 
//Message passing conversely is their only purpose

//example 
import akka.pattern.ask
import scala.concurrent.Await
import akka.util.Timeout
import scala.concurrent.duration._

class ExampleActor extends Actor {
  val other = context.actorOf(Props[OtherActor], "childName") // will be destroyed and re-created upon restart by default

  def receive {
    case Request1(msg) => other ! msg    // uses this actor as sender reference, reply goes to us
    case Request2(msg) => other.tell(msg, sender()) // forward sender reference, enabling direct reply
    case Request3(msg) =>
      implicit val timeout = Timeout(5.seconds)
      (other ? msg) pipeTo sender()
      // the ask call will get a future from other's reply
      // when the future is complete, send its value to the original sender
  }
}


///*** Actor - Actors and shared mutable state
//Messages should be immutable, this is to avoid the shared mutable state trap.

//OR use below pattern 

class MyActor extends Actor {
 var state = ...
 def receive = {
    case newstate:TYPE => state = newstate //for handling  f => self ! f.value.get
    case _ =>
     //Wrongs
     // Very bad, shared mutable state, will break your application in weird ways
      Future { state = NewState }
      anotherActor ? message onSuccess { r => state = r }
 
     // Very bad, "sender" changes for every message,
     // shared mutable state bug
      Future { expensiveCalculation(sender()) }
      
      
 
    //Rights
 
    // Completely safe, "self" is OK to close over
    // and it's an ActorRef, which is thread-safe
      Future { expensiveCalculation() } onComplete { f => self ! f.value.get }
 
    // Completely safe, we close over a fixed value
    // and it's an ActorRef, which is thread-safe
      val currentSender = sender()
      Future { expensiveCalculation(currentSender) }
 }
}

///*** Actor - With Future

import akka.pattern._


//Futures need ExecutionContext
//Either get it by 
val system:ActorSystem = ... 
import system.dispatcher 
//OR create manually 
import scala.concurrent.{ ExecutionContext, Promise }

import java.util.concurrent.Executors
implicit val ec = ExecutionContext.fromExecutorService(Executors.newSingleThreadExecutor()) //or newFixedThreadPool(int nThreads) 
//https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/Executors.html



// Do stuff with your brand new  ExecutionContext
val f = Promise.successful("foo")

// Then shut your ExecutionContext down at some
// appropriate place in your program/application
ec.shutdown()

//Getting values of Future 
def  result(atMost: Duration)(implicit permit: CanAwait): T 
    Await and return the result (of type T) of this Awaitable.
def  value: Option[Try[T]] 
    The value of this Future.




//Within Actors
//Each actor is configured to be run on a MessageDispatcher, 
//and that dispatcher doubles as an ExecutionContext. 

class A extends Actor {
  import context.dispatcher
  val f = Future("hello")
  def receive = {
    case _ =>
  }
}


//Use with Actors

//Blocking 
import scala.concurrent.Await
import akka.pattern.ask
import akka.util.Timeout
import scala.concurrent.duration._

implicit val timeout = Timeout(5 seconds)
val future = actor ? msg // enabled by the �ask� import
val result = Await.result(future, timeout.duration).asInstanceOf[String]

//non-blocking 
//mapTo method will return a new Future
import scala.concurrent.Future
import akka.pattern.ask

val future: Future[String] = ask(actor, msg).mapTo[String]

//To send the result of a Future to an Actor, use the pipe construct:
import akka.pattern.pipe
future pipeTo actor


//Composing Futures
val f1 = ask(actor1, msg1)
val f2 = ask(actor2, msg2)

val a = Await.result(f1, 3 seconds).asInstanceOf[Int]
val b = Await.result(f2, 3 seconds).asInstanceOf[Int]

val f3 = ask(actor3, (a + b))

val result = Await.result(f3, 3 seconds).asInstanceOf[Int]

//or fully non blocking 
val f1 = ask(actor1, msg1)
val f2 = ask(actor2, msg2)

val f3 = for {
  a <- f1.mapTo[Int]
  b <- f2.mapTo[Int]
  c <- ask(actor3, (a + b)).mapTo[Int]
} yield c

f3 foreach println

//combine different Futures with each other
Future.sequence[A, M[X] <: TraversableOnce[X]](in: M[Future[A]])(implicit cbf: CanBuildFrom[M[Future[A]], A, M[A]], executor: ExecutionContext): Future[M[A]] 
Future.traverse[A, B, M[X] <: TraversableOnce[X]](in: M[A])(fn: (A) => Future[B])(implicit cbf: CanBuildFrom[M[A], B, M[B]], executor: ExecutionContext): Future[M[B]] 
Future.reduce[T, R >: T](futures: TraversableOnce[Future[T]])(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R] 
Future.fold[T, R](futures: TraversableOnce[Future[T]])(zero: R)(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R] 

// oddActor returns odd numbers sequentially from 1 as a List[Future[Int]]
val listOfFutures = List.fill(100)(akka.pattern.ask(oddActor, GetNext).mapTo[Int])

// Future.sequence is taking the List[Future[Int]] , returns Future[List[Int]]
val futureList = Future.sequence(listOfFutures)

// Find the sum of the odd numbers
val oddSum = futureList.map(_.sum)
oddSum foreach println

//traverse takes a sequence of A and applies a function A => Future[B]
//from A to Future<B> to return a Future[T[B]] where T is a subclass of Traversable. 

//For example, to use traverse to sum the first 100 odd numbers: 
//and returns a Future<Iterable<B>>, enabling parallel map over the sequence, 

val futureList = Future.traverse((1 to 100).toList)(x => Future(x * 2 - 1))
val oddSum = futureList.map(_.sum)
oddSum foreach println
//This is the same result as this example:
val futureList = Future.sequence((1 to 100).toList.map(x => Future(x * 2 - 1)))
val oddSum = futureList.map(_.sum)
oddSum foreach println

//fold takes a start-value, a sequence of Futures 
//and a function from the type of the start-value, a timeout, 
//and the type of the futures and returns something with the same type as the start-value, 
//and then applies the function to all elements in the sequence of futures, non-blockingly, 
//the execution will be started when the last of the Futures is completed.
// Create a sequence of Futures
val futures = for (i <- 1 to 1000) yield Future(i * 2)
val futureSum = Future.fold(futures)(0)(_ + _)
futureSum foreach println

//or 
// Create a sequence of Futures
val futures = for (i <- 1 to 1000) yield Future(i * 2)
val futureSum = Future.reduce(futures)(_ + _)
futureSum foreach println


//Callbacks
Future[+T].onFailure[U](pf: PartialFunction[Throwable, U])(implicit executor: ExecutionContext): Unit 
Future[+T].onSuccess[U](pf: PartialFunction[T, U])(implicit executor: ExecutionContext): Unit 
Future[+T].onComplete[U](f: (Try[T]) => U)(implicit executor: ExecutionContext): Unit

future onSuccess {
  case "bar"     => println("Got my bar alright!")
  case x: String => println("Got some random string: " + x)
}

future onFailure {
  case ise: IllegalStateException if ise.getMessage == "OHNOES" ?
  //OHNOES! We are in deep trouble, do something!
  case e: Exception ?
  //Do something else
}
future onComplete {
  case Success(result)  ? doSomethingOnSuccess(result)
  case Failure(failure) ? doSomethingOnFailure(failure)
}

//Define Ordering
//Since callbacks are executed in any order and potentially in parallel, 
//To execute in order  : andThen. 
//It creates a new Future with the specified callback, 
//a Future that will have the same result as the Future it�s called on, 
//which allows for ordering like in the following sample:
Future[+T].andThen[U](pf: PartialFunction[Try[T], U])(implicit executor: ExecutionContext): Future[T] 

val result = Future { loadPage(url) } andThen {
  case Failure(exception) => log(exception)
} andThen {
  case _ => watchSomeTV()
}
result foreach println



//Auxiliary Methods
Future[+T].fallbackTo[U >: T](that: Future[U]): Future[U] 
//Future fallbackTo combines 2 Futures into a new Future,
//and will hold the successful value of the second Future if the first Future fails.

val future4 = future1 fallbackTo future2 fallbackTo future3
future4 foreach println


//two Futures into a new Future that will hold a tuple of the two Futures successful results,
Future[+T].zip[U](that: Future[U]): Future[(T, U)] 

val future3 = future1 zip future2 map { case (a, b) ? a + " " + b }
future3 foreach println


//Exceptions
Future[+T].recover[U >: T](pf: PartialFunction[Throwable, U])(implicit executor: ExecutionContext): Future[U]

//takes non future type 
val future = akka.pattern.ask(actor, msg1) recover {
  case e: ArithmeticException => 0
}
future foreach println

//Or with recoverWith, which takes another future 
Future[+T].recoverWith[U >: T](pf: PartialFunction[Throwable, Future[U]])(implicit executor: ExecutionContext): Future[U] 


val future = akka.pattern.ask(actor, msg1) recoverWith {
  case e: ArithmeticException => Future.successful(0)
  case foo: IllegalArgumentException =>
    Future.failed[Int](new IllegalStateException("All br0ken!"))
}
future foreach println



//After
//akka.pattern.after makes it easy to complete a Future with a value 
//or exception after a timeout.

import akka.pattern.after

val delayed = akka.pattern.after(200 millis, using = system.scheduler)(Future.failed(
  new IllegalStateException("OHNOES")))
val future = Future { Thread.sleep(1000); "foo" }
val result = Future firstCompletedOf Seq(future, delayed)








///*** Actor - logging 
//applicantion.conf 
akka {
  loggers = ["akka.slf4j.Slf4jLogger"] # for example
  loglevel = "INFO"        # used when normal logging ("loggers") has been started
  stdout-loglevel = "WARN" # used during application start-up until normal logging is available
}

import akka.event.Logging
val log = Logging(<bus>, <source object>)
//for example inside actor 
val log = Logging(context.system, this)
...
log.info("hello world!")
 
//ActorLogging extends AnyRef
//Mix in ActorLogging into your Actor to easily obtain a reference to a logger, which is available under the name "log".

class MyActor extends Actor with akka.actor.ActorLogging {
  def receive = {
    case "pigdog" => log.info("We've got yet another pigdog on our hands")
  }
}

//Example 
import akka.event.Logging

class MyActor extends Actor {
  val log = Logging(context.system, this)
  override def preStart() = {
    log.debug("Starting")
  }
  override def preRestart(reason: Throwable, message: Option[Any]) {
    log.error(reason, "Restarting due to [{}] when processing [{}]",
      reason.getMessage, message.getOrElse(""))
  }
  def receive = {
    case "test" => log.info("Received test")
    case x      => log.warning("Received unknown message: {}", x)
  }
}

//The first parameter to Logging - any LoggingBus, 
//specifically system.eventStream 

//The second parameter to Logging is the source of this logging channel. 
//The source object is translated to a String according to the following rules:
1.if it is an Actor or ActorRef, its path is used
2.in case of a String it is used as is
3.in case of a class an approximation of its simpleName
4.and in all other cases a compile error occurs 


//The log message may contain argument placeholders {}, 
//which will be substituted if the log level is enabled. 
val args = Array("The", "brown", "fox", "jumps", 42)
system.log.debug("five parameters: {}, {}, {}, {}, {}", args)


//Logging of Dead Letters
//By default messages sent to dead letters are logged at info level. 
akka {
  log-dead-letters = 10
  log-dead-letters-during-shutdown = on
}


//Auxiliary logging options
akka {
  loglevel = "DEBUG"
}

//to know what config settings are loaded by Akka:
akka {
  # Log the complete configuration at INFO level when the actor system is started.
  # This is useful when you are uncertain of what configuration is used.
  log-config-on-start = on
}

//very detailed logging of user-level messages then wrap your actors� behaviors 
//with akka.event.LoggingReceive and enable the receive option:
akka {
  actor {
    debug {
      # enable function of LoggingReceive, which is to log any received message at
      # DEBUG level
      receive = on
    }
  }
}
//very detailed logging of all automatically received messages that are processed by Actors:
akka {
  actor {
    debug {
      # enable DEBUG logging of all AutoReceiveMessages (Kill, PoisonPill etc.)
      autoreceive = on
    }
  }
}
//very detailed logging of all lifecycle changes of Actors (restarts, deaths etc):
akka {
  actor {
    debug {
      # enable DEBUG logging of actor lifecycle changes
      lifecycle = on
    }
  }
}
//unhandled messages logged at DEBUG:
akka {
  actor {
    debug {
      # enable DEBUG logging of unhandled messages
      unhandled = on
    }
  }
}
//very detailed logging of all events, transitions and timers of FSM Actors 
//that extend LoggingFSM:
akka {
  actor {
    debug {
      # enable DEBUG logging of all LoggingFSMs for events, transitions and timers
      fsm = on
    }
  }
}
//to monitor subscriptions (subscribe/unsubscribe) on the ActorSystem.eventStream:
akka {
  actor {
    debug {
      # enable DEBUG logging of subscription changes on the eventStream
      event-stream = on
    }
  }
}
// see all messages that are sent through remoting at DEBUG log level, 
//this logs the messages as they are sent by the transport layer, not by an actor.
akka {
  remote {
    # If this is "on", Akka will log all outbound messages at DEBUG level,
    # if off then they are not logged
    log-sent-messages = on
  }
}
//to see all messages that are received through remoting at DEBUG log level, 
akka {
  remote {
    # If this is "on", Akka will log all inbound messages at DEBUG level,
    # if off then they are not logged
    log-received-messages = on
  }
}
//to see message types with payload size in bytes larger than a specified limit at INFO log level:
akka {
  remote {
    # Logging of message types with payload size in bytes larger than
    # this value. Maximum detected size per message type is logged once,
    # with an increase threshold of 10%.
    # By default this feature is turned off. Activate it by setting the property to
    # a value in bytes, such as 1000b. Note that for all messages larger than this
    # limit there will be extra performance and scalability cost.
    log-frame-size-exceeding = 1000b
  }
}
//Turn Off Logging
akka {
  stdout-loglevel = "OFF"
  loglevel = "OFF"
}
//configure which event handlers are created at system start-up and listen to logging events. 
akka {
  # Loggers to register at boot time (akka.event.Logging$DefaultLogger logs
  # to STDOUT)
  loggers = ["akka.event.Logging$DefaultLogger"]
  # Options: OFF, ERROR, WARNING, INFO, DEBUG
  loglevel = "DEBUG"
}

//Example of creating a listener:
import akka.event.Logging.Debug
import akka.event.Logging.Error
import akka.event.Logging.Info
import akka.event.Logging.InitializeLogger
import akka.event.Logging.LoggerInitialized
import akka.event.Logging.Warning

class MyEventListener extends Actor {
  def receive = {
    case InitializeLogger(_)                        => sender() ! LoggerInitialized
    case Error(cause, logSource, logClass, message) => // ...
    case Warning(logSource, logClass, message)      => // ...
    case Info(logSource, logClass, message)         => // ...
    case Debug(logSource, logClass, message)        => // ...
  }
}

//Logging to stdout during startup and shutdown
//When the actor system is starting up and shutting down the configured loggers are not used. 
//Instead log messages are printed to stdout (System.out). 
//The default log level for this stdout logger is WARNING and it can be silenced completely 
//by setting akka.stdout-loglevel=OFF.
 


//SLF4J
//Akka provides a logger for SLF4J. 
//This module is available in the �akka-slf4j.jar�. 
//It has a single dependency: the slf4j-api jar. 
//In your runtime, you also need a SLF4J backend. 
//We recommend Logback:
libraryDependencies += "ch.qos.logback" % "logback-classic" % "1.2.3"

//If you set the loglevel to a higher level than �DEBUG�, 
//any DEBUG events will be filtered out already at the source and will never reach the logging backend, regardless of how the backend is configured.
akka {
  loggers = ["akka.event.slf4j.Slf4jLogger"]
  loglevel = "DEBUG"
  logging-filter = "akka.event.slf4j.Slf4jLoggingFilter"
}


///*** Actor - Understanding the Methods in the Akka Actor Lifecycle
//Method                Description
constructor           
    An actor constructor is called just like any other Scala class constructor, 
    when an instance of the class is first created.         
preStart              
    Called right after the actor is started. 
    During restarts it is called by the default implementation of postRestart.
postStop              
    Called after an actor is stopped, it can be used to perform any needed cleanup work. 
preRestart(reason: Throwable, message: Option[Any])            
    when an actor is restarted, the old actor is informed of the process when preRestart is called with the exception that caused the restart, and the message that triggered
    the exception. The message may be None if the restart was not caused by processing a message.
postRestart(reason: Throwable)           
    The postRestart method of the new actor is invoked with the exception that caused the restart. In the default implementation, the preStart method is called.

    
    
//The postStop hook is invoked after an actor is fully stopped. 
//This enables cleaning up of resources
override def postStop() {
  // clean up some resources ...
}

//Initialization via preStart
//The method preStart() of an actor is only called once directly during the initialization of the first instance
//In the case of restarts, preStart() is called from postRestart()

//One useful usage of this pattern is to disable creation of new ActorRefs 
for children during restarts.
override def preStart(): Unit = {
  // Initialize children here
}
//and then  Overriding postRestart to disable the call to preStart() after restarts
override def postRestart(reason: Throwable): Unit = ()
 
 
// The default implementation of preRestart() stops all the children of the actor. 
//To opt-out from stopping the children
override def preRestart(reason: Throwable, message: Option[Any]): Unit = {
  // Keep the call to postStop(), but no stopping of children
  postStop()
}




    
//Example 
import akka.actor._

class Kenny extends Actor {
 println("entered the Kenny constructor")
 override def preStart { println("kenny: preStart") }
 override def postStop { println("kenny: postStop") }
 override def preRestart(reason: Throwable, message: Option[Any]) {
   println("kenny: preRestart")
   println(s" MESSAGE: ${message.getOrElse("")}")
   println(s" REASON: ${reason.getMessage}")
   super.preRestart(reason, message)
 }
 override def postRestart(reason: Throwable) {
   println("kenny: postRestart")
   println(s" REASON: ${reason.getMessage}")
   super.postRestart(reason)
 }
 def receive = {
   case ForceRestart => throw new Exception("Boom!")
   case _ => println("Kenny received a message")
 }
}

case object ForceRestart

object LifecycleDemo extends App {
 val system = ActorSystem("LifecycleDemo")
 val kenny = system.actorOf(Props[Kenny], name = "Kenny")

   println("sending kenny a simple String message")
   kenny ! "hello"
   Thread.sleep(1000)

   println("make kenny restart")
   kenny ! ForceRestart
   Thread.sleep(1000)

   println("stopping kenny")
   system.stop(kenny)

   println("shutting down system")
   system.shutdown
}

// Outputs
[info] Running LifecycleDemo
sending kenny a simple String message
entered the Kenny constructor
kenny: preStart

Kenny received a message
make kenny restart
[ERROR] [05/14/2013 10:21:54.953] [LifecycleDemo-akka.actor.default-dispatcher-4]
[akka://LifecycleDemo/user/Kenny] Boom!
java.lang.Exception: Boom!
at Kenny$$anonfun$receive$1.applyOrElse(Test.scala:19)
(many more lines of exception output ...)

kenny: preRestart
MESSAGE: ForceRestart
REASON: Boom!
kenny: postStop
entered the Kenny constructor
kenny: postRestart
REASON: Boom!
kenny: preStart
stopping kenny
shutting down system
kenny: postStop
[success]




///*** Actor - Stopping Actors
import akka.actor._

actorSystem.stop(anActor)
context.stop(childActor)
context.stop(self)
actor ! PoisonPill
actorSystem.terminate() //the system guardian actors will be stopped,

//Message                   Description
stop            method      The actor will continue to process its current message (if any), but no additional messages will be  processed. 
PoisonPill      message     A PoisonPill message will stop an actor when the message is processed. A PoisonPill message is queued just like an ordinary message and will be handled after other messages queued  ahead of it in its mailbox.
gracefulStop    method      terminate actors gracefully, waiting for them to timeout. The documentation   states that this is a good way to terminate actors in a specific order.
Kill            message     Kills the actor abruptly by raising Exception, but depends on exception handling strategy 


//PoisonPill
//stop the actor when the message is processed. 
//PoisonPill is enqueued as ordinary messages and will be handled after messages that were already queued in the mailbox.

victim ! PoisonPill

//Killing an Actor
//this will cause the actor to throw a ActorKilledException, triggering a failure. 
///The actor will suspend operation and its supervisor will be asked how to handle the failure, 
//which may mean resuming the actor, restarting it or terminating it completely. 

context.watch(victim) // watch the Actor to receive Terminated message once it dies
victim ! Kill

expectMsgPF(hint = "expecting victim to terminate") {
  case Terminated(v) if v == victim => v // the Actor has indeed terminated
}


//Graceful Stop
//gracefulStop is useful if you need to wait for termination 
//or compose ordered termination of several actors:

//When gracefulStop() returns successfully, 
//the actor�s postStop() hook will have been executed: there exists a happens-before edge between the end of postStop() and the return of gracefulStop().

import akka.pattern.gracefulStop
import scala.concurrent.Await
import akka.util.Timeout
import akk.actor._
import scala.concurrent.duration._

try {
  val stopped: Future[Boolean] = gracefulStop(actorRef, 5 seconds, Manager.Shutdown)
  Await.result(stopped, 6 seconds)
  // the actor has been stopped
} catch {
  // the actor wasn't stopped within 5 seconds
  case e: akka.pattern.AskTimeoutException =>
}

///* Stopping actors
//ActorContext  is used for stopping the actor itself or child actors 
//and the ActorSystem for stopping top level actors.
class MyActor extends Actor {
 
  val child: ActorRef = ???
 
  def receive = {
    case "interrupt-child" =>
      context stop child
 
    case "done" =>
      context stop self
  }
 
}


//The postStop hook is invoked after an actor is fully stopped. 
//This enables cleaning up of resources
override def postStop() {
  // clean up some resources ...
}


 
///*** Actor -  Identifying Actors via ActorSelection and  actorOf 
//actors may look up other actors by specifying absolute or relative paths�logical or physical
//and receive back an ActorSelection with the result


//both context(inside actor) and system(ActorSystem) have below methods 
def actorOf(props: Props, name: String): ActorRef
    Create new actor as child of this context with the given name, which must not be null, empty or start with �$�.
def actorOf(props: Props): ActorRef
    Create new actor as child of this context and give it an automatically generated name (currently similar to base64-encoded integer count, reversed and with �$� prepended, may change in the future).
def actorSelection(path: ActorPath): ActorSelection
    Construct an akka.actor.ActorSelection from the given path, which is parsed for wildcards (these are replaced by regular expressions internally).
    Messages can be sent via the ActorSelection( has ! or tell methods) 
def actorSelection(path: String): ActorSelection
    Construct an akka.actor.ActorSelection from the given path, which is parsed for wildcards (these are replaced by regular expressions internally).
    Messages can be sent via the ActorSelection( has ! or tell methods) 



// will look up this absolute path
val actorSelection = context.actorSelection("/user/serviceA/aggregator")
// will look up sibling beneath same supervisor
val actorSelection = context.actorSelection("../joe")

// will look all children to serviceB with names starting with worker
val actorSelection = context.actorSelection("/user/serviceB/worker*")
// will look up all siblings beneath same supervisor
val actorSelection = context.actorSelection("../*")

//Remote actor addresses may also be looked up, if remoting is enabled:
val actorSelection = context.actorSelection("akka.tcp://app@otherhost:1234/user/serviceB")



//and the path of the ActorSelection is looked up when delivering each message. 
//If the selection does not match any actors the message will be dropped.

///To acquire an ActorRef for an ActorSelection 
//OPTION-1:resolveOne method of the ActorSelection. 
//It returns a Future of the matching ActorRef if such an actor exists. 



//OPTION-2: Use built-in Identify message that all Actors will understand 
//and automatically reply to with a ActorIdentity message containing the ActorRef.
import akka.actor.{ Actor, Props, Identify, ActorIdentity, Terminated }
 
class Follower extends Actor {
  val identifyId = 1
  context.actorSelection("/user/another") ! Identify(identifyId)
 
  def receive = {
    case ActorIdentity(`identifyId`, Some(ref)) =>
      context.watch(ref)
      context.become(active(ref))
    case ActorIdentity(`identifyId`, None) => context.stop(self)
 
  }
 
  def active(another: ActorRef): Actor.Receive = {
    case Terminated(`another`) => context.stop(self)
  }
}





    


///*** Actor -  Receive timeout
//The ActorContext setReceiveTimeout defines the inactivity timeout 
//after which the sending of a ReceiveTimeout message is triggered

//Once set, the receive timeout stays in effect (i.e. continues firing repeatedly after inactivity periods). 
//Pass in Duration.Undefined to switch off this feature.

import akka.actor.ReceiveTimeout
import scala.concurrent.duration._
class MyActor extends Actor {
  // To set an initial delay
  context.setReceiveTimeout(30 milliseconds)
  def receive = {
    case "Hello" =>
      // To set in a response to a message
      context.setReceiveTimeout(100 milliseconds)
    case ReceiveTimeout =>
      // To turn it off
      context.setReceiveTimeout(Duration.Undefined)
      throw new RuntimeException("Receive timed out")
  }
}

///*** Actor - Timers, scheduled messages
//Used when scheduling periodic or single messages in an actor to itself only 
trait Timers extends Actor 
     final def timers: TimerScheduler
        Start and cancel timers via the enclosed TimerScheduler.
      
class TimerScheduler extends AnyRef        
    def cancel(key: Any): Unit
        Cancel a timer with a given key.
    def cancelAll(): Unit
        Cancel all timers.
    def isTimerActive(key: Any): Boolean
        Check if a timer with a given key is active.
    def startPeriodicTimer(key: Any, msg: Any, interval: FiniteDuration): Unit
        Start a periodic timer that will send msg to the self actor at a fixed interval.
    def startSingleTimer(key: Any, msg: Any, timeout: FiniteDuration): Unit
        Start a timer that will send msg once to the self actor after the given timeout.
        
//Each timer has a key and can be replaced or cancelled. 
//It�s guaranteed that a message from the previous incarnation of the timer with the same key is not received, 

//The timers are bound to the lifecycle of the actor that owns it, 
//and thus are cancelled automatically when it is restarted or stopped. 
//Note that the TimerScheduler is not thread-safe, 
//i.e. it must only be used within the actor that owns it.  
//code 
import scala.concurrent.duration._

import akka.actor.Actor
import akka.actor.Timers

object MyActor {
  private case object TickKey
  private case object FirstTick
  private case object Tick
}

class MyActor extends Actor with Timers {
  import MyActor._
  timers.startSingleTimer(TickKey, FirstTick, 500.millis)

  def receive = {
    case FirstTick =>
      // do something useful here
      timers.startPeriodicTimer(TickKey, Tick, 1.second)
    case Tick =>
    // do something useful here
  }
}


///*** Actor - Scheduler 
//The scheduler will throw an exception if attempts are made to schedule too far into the future (which by default is around 8 months (Int.MaxValue seconds). 
def schedule(initialDelay: FiniteDuration, interval: FiniteDuration)(f: => Unit)(implicit executor: ExecutionContext): Cancellable
    Schedules a function to be run repeatedly with an initial delay and a frequency.
def schedule(initialDelay: FiniteDuration, interval: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and frequency.
def scheduleOnce(delay: FiniteDuration)(f: =>  Unit)(implicit executor: ExecutionContext): Cancellable
    Schedules a function to be run once with a delay,
def scheduleOnce(delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent once with a delay, 

//trait Cancellable
def cancel(): Boolean
    Cancels this Cancellable and returns true if that was successful.
def isCancelled: Boolean
    Returns true if and only if this Cancellable has been successfully cancelled

//code 
import akka.actor.Actor
import akka.actor.Props
import scala.concurrent.duration._

//Schedule to send the �foo�-message to the testActor after 50ms:
//Use the system's dispatcher as ExecutionContext
import system.dispatcher

//Schedules to send the "foo"-message to the testActor after 50ms
system.scheduler.scheduleOnce(50 milliseconds, testActor, "foo")

//Schedules a function to be executed (send a message to the testActor) after 50ms
system.scheduler.scheduleOnce(50 milliseconds) {
  testActor ! System.currentTimeMillis
}

//Schedule to send the �Tick�-message to the tickActor after 0ms repeating every 50ms:

val Tick = "tick"
class TickActor extends Actor {
  def receive = {
    case Tick ? //Do something
  }
}
val tickActor = system.actorOf(Props(classOf[TickActor], this))
//Use system's dispatcher as ExecutionContext
import system.dispatcher

//This will schedule to send the Tick-message
//to the tickActor after 0ms repeating every 50ms
val cancellable =
  system.scheduler.schedule(
    0 milliseconds,
    50 milliseconds,
    tickActor,
    Tick)

//This cancels further Ticks to be sent
cancellable.cancel()




///*** Actor - Switching Between Different States with become
//context.become and context.unbecome
def  become(behavior: Receive, discardOld: Boolean): Unit 
Changes the Actor behavior to become the new 'Receive' (PartialFunction[Any, Unit]) handler. 
This method acts upon the behavior stack as follows:
    if discardOld = true it will replace the top element (i.e.default), no need for unbecome()
    if discardOld = false it will keep the current behavior and push the given one atop, must issue unbecome()
def unbecome(): Unit
    Reverts the Actor behavior to the previous one on the behavior stack.


//Example 
import akka.actor._

case object GoToSecondState
case object TryToFindSolution
case object GoToOneState

class OneActor extends Actor {
  import context._

	def oneState: Receive = {
	  case GoToSecondState =>
		   println("Moving to two State")
		   become(twoState)
	}

	def twoState: Receive = {
	  case TryToFindSolution =>
		   println("remaining in two State")
	  case GoToOneState =>
		   println("Moving to one state")
		   become(oneState)
	}

	def receive = {
	  case GoToOneState => become(oneState)
	  case GoToSecondState => become(twoState)
	}
}

object BecomeHulkExample extends App {
  val system = ActorSystem("StateChange")
  val actor = system.actorOf(Props[OneActor], name = "OneActor")
  actor ! GoToOneState // init to normalState
  actor ! GoToSecondState
  actor ! TryToFindSolution
  Thread.sleep(1000)
  actor ! GoToOneState
  system.terminate()
}


///If an exception is thrown while a message is being processed 
//(i.e. taken out of its mailbox and handed over to the current behavior), 
//then this message will be lost

//If an exception is thrown while a message is being processed, nothing happens to the mailbox. 
//If the actor is restarted, the same mailbox will be there. 
//So all messages on that mailbox will be there as well.

//If code within an actor throws an exception, 
//that actor is suspended and the supervision process is started 
//Depending on the supervisor�s decision the actor is resumed (as if nothing happened), 
//restarted (wiping out its internal state and starting from scratch) or terminated.


///* Initialization via message passing
var initializeMe: Option[String] = None
 
override def receive = {
  case "init" =>
    initializeMe = Some("Up and running")
    context.become(initialized, discardOld = true)
 
}
 
def initialized: Receive = {
  case "U OK?" => initializeMe foreach { sender() ! _ }
}


//Another example 
//the actor will revert to its original behavior when restarted by its Supervisor.
class HotSwapActor extends Actor {
  import context._
  def angry: Receive = {
    case "foo" => sender() ! "I am already angry?"
    case "bar" => become(happy)
  }
 
  def happy: Receive = {
    case "bar" => sender() ! "I am already happy :-)"
    case "foo" => become(angry)
  }
 
  def receive = {
    case "foo" => become(angry)
    case "bar" => become(happy)
  }
}

//The other way of using become does not replace 
//but add to the top of the behavior stack
case object Swap
class Swapper extends Actor {
  import context._
  val log = Logging(system, this)
 
  def receive = {
    case Swap =>
      log.info("Hi")
      become({
        case Swap =>
          log.info("Ho")
          unbecome() // resets the latest 'become' 
      }, discardOld = false) // push on top instead of replace
  }
}
 
object SwapperApp extends App {
  val system = ActorSystem("SwapperSystem")
  val swap = system.actorOf(Props[Swapper], name = "swapper")
  swap ! Swap // logs Hi
  swap ! Swap // logs Ho
  swap ! Swap // logs Hi
  swap ! Swap // logs Ho
  swap ! Swap // logs Hi
  swap ! Swap // logs Ho
}

///* The Stash trait enables an actor to temporarily stash away messages 
//that can not or should not be handled using the actor's current behavior
//The stash is backed by a scala.collection.immutable.Vector.

//If you want to enforce that your actor can only work with an unbounded stash, 
//then you should use the UnboundedStash trait instead.

//Note that the Stash trait can only be used together with actors that have a deque-based mailbox. 
//By default Stash based actors request a Deque based mailbox

//Important methods , Stash has all Actor's methods 
trait Stash extends UnrestrictedStash with RequiresMessageQueue[DequeBasedMessageQueueSemantics] 
trait UnboundedStash extends UnrestrictedStash with RequiresMessageQueue[UnboundedDequeBasedMessageQueueSemantics] 
    def stash(): Unit
        Adds the current message (the message that the actor received last) to the actors stash.
    def unstashAll(): Unit
        Prepends all messages in the stash to the mailbox(now handling begins), and then clears the stash.


//Example 
import akka.actor.Stash
class ActorWithProtocol extends Actor with Stash {
  def receive = {
    case "open" =>
      unstashAll()
      context.become({
        case "write" => // do writing...
        case "close" =>
          unstashAll()
          context.unbecome()
        case msg => stash()
      }, discardOld = false) // stack on top instead of replacing
    case msg => stash()
  }
}







///*** Actor -  Extending Actors using PartialFunction chaining
import akka.actor._ 

// protocol
case object GiveMeThings
final case class Give(thing: Any)

trait ProducerBehavior {
  this: Actor =>
 
  val producerBehavior: Receive = {
    case GiveMeThings =>
      sender() ! Give("thing")
  }
}
 
trait ConsumerBehavior {
  this: Actor with ActorLogging =>
 
  val consumerBehavior: Receive = {
    case ref: ActorRef =>
      ref ! GiveMeThings
 
    case Give(thing) =>
      log.info("Got a thing! It's {}", thing)
  }
}
 
class Producer extends Actor with ProducerBehavior {
  def receive = producerBehavior
}
 
class Consumer extends Actor with ActorLogging with ConsumerBehavior {
  def receive = consumerBehavior
}
//Use PartialFunction composition techinques 
class ProducerConsumer extends Actor with ActorLogging with ProducerBehavior with ConsumerBehavior {
  def receive = producerBehavior.orElse[Any, Unit](consumerBehavior)
}
//reference 
type Receive = PartialFunction[Any, Unit] 
trait  PartialFunction[-A, +B] extends (A) => B 
    def  andThen[C](k: (B) ? C): PartialFunction[A, C] 
        Composes this partial function with a transformation function 
        that gets applied to results of this partial function.
    def  applyOrElse[A1 <: A, B1 >: B](x: A1, default: (A1) ? B1): B1 
        Applies this partial function to the given argument 
        when it is contained in the function domain.
    def  compose[A](g: (A) ? A): (A) => B 
        Composes two instances of Function1 in a new Function1, 
        with this function applied last.
    def  lift: (A) => Option[B] 
        Turns this partial function into a plain function returning an Option result.
    def  orElse[A1 <: A, B1 >: B](that: PartialFunction[A1, B1]): PartialFunction[A1, B1] 
        Composes this partial function with a fallback partial function 
        which gets applied where this partial function is not defined.
    def  runWith[U](action: (B) => U): (A) => Boolean 
        Composes this partial function with an action function 
        which gets applied to results of this partial function.








///*** Actor - Dead Letters
//Messages which cannot be delivered will be delivered to a synthetic actor called /deadLetters

//An actor can handle below message 
 case class DeadLetter(message: Any, sender: ActorRef, recipient: ActorRef) extends AllDeadLetters with Product with Serializable  
//The subscribed actor will then receive all dead letters published in the (local) system from that point onwards. 
//Dead letters are not propagated over the network, 

import akka.actor._

class EchoActor extends Actor {

  def receive = {
    case msg => println(s"${self.path.name} - New msg received: $msg")
  }

}

object Main extends App {

  implicit val system = ActorSystem("dead-letters-usage-example")

  val deadLettersSubscriber = system.actorOf(Props[EchoActor], name = "dead-letters-subscriber")
  val echoActor = system.actorOf(Props[EchoActor], name = "generic-echo-actor")

  system.eventStream.subscribe(deadLettersSubscriber, classOf[DeadLetter])

  echoActor ! "First Message"
  // generic-echo-actor - New msg received: First Message
  
  echoActor ! PoisonPill
  echoActor ! "Second Message"
  // dead-letters-subscriber - New msg received: DeadLetter(Second Message,Actor[akka://dead-letters-usage-example/deadLetters],Actor[akka://dead-letters-usage-example/user/generic-echo-actor#317003256])
  // INFO  [RepointableActorRef]: Message [java.lang.String] from Actor[akka://dead-letters-usage-example/deadLetters] to Actor[akka://dead-letters-usage-example/user/generic-echo-actor#317003256] was not delivered. [1] dead letters encountered. This logging can be turned off or adjusted with configuration settings 'akka.log-dead-letters' and 'akka.log-dead-letters-during-shutdown'.

  system.deadLetters ! "Dead Message"
  // dead-letters-subscriber - New msg received: DeadLetter(Dead Message,Actor[akka://dead-letters-usage-example/deadLetters],Actor[akka://dead-letters-usage-example/deadLetters])
  // INFO  [DeadLetterActorRef]: Message [java.lang.String] from Actor[akka://dead-letters-usage-example/deadLetters] to Actor[akka://dead-letters-usage-example/deadLetters] was not delivered. [2] dead letters encountered. This logging can be turned off or adjusted with configuration settings 'akka.log-dead-letters' and 'akka.log-dead-letters-during-shutdown'.
} 










///*** Actor - Remote Akka 

//CLient 


import akka.actor._
import local.Rational

object Prog9Client extends App {

  implicit val system = ActorSystem("CliSystem")
  val localActor = system.actorOf(Props[Client], name = "Client")  // the local actor
  localActor ! "start"                                             // Send a message 
}

class Client extends Actor {

  // create the remote actor
  val remote = context.actorSelection("akka.tcp://SrvSystem@127.0.0.1:2552/user/Server")  //actorFor("akka://SrvSystem/user/Server")    //
  var a = 0
  var b = 0

  def receive = {
    case "start" =>
        println("Type two integers and press return OR 0,0 for exit")
		a = readInt
		println(a)
		b = readInt
		println(b)
		if (a == 0 && b == 0) {
			//remote ! "stop"
			context.stop(self)
			context.system.terminate()
			}
		else { remote ! Rational(a, b) }
    case res:String  =>
        println(s"Result : $res" )
		self ! "start"
    case _ =>
        println("Unknown msg")
  }
}



///Server
import akka.actor._
import local.Rational


object Prog9Remote extends App  {
  val system = ActorSystem("SrvSystem")
  val remoteActor = system.actorOf(Props[Server], name = "Server")
 }

class Server extends Actor {
  
  def receive = {
    case Rational(a, b) =>
		println(s"$a,$b" )
		val result : Float = a.toFloat / b.toFloat
        sender ! (f"$result%.2f")
	case "stop" =>
        context.stop(self)
    case _ =>
        println("Unknown msg")
    }
}

//server -application.conf 
akka {
  // loglevel = "DEBUG"
  // log-dead-letters = 10
  // log-dead-letters-during-shutdown = on

  actor {
    provider = "akka.remote.RemoteActorRefProvider"   // for local: akka.actor.LocalActorRefProvider
   }
   remote {
     enabled-transports = ["akka.remote.netty.tcp"]
     //log-sent-messages = on
     //log-received-messages = on
     netty.tcp {
      hostname = "127.0.0.1"
      port = 2552  //for client make it zero 
    }
   }
}

///*Creating Actors Remotely
//to use the creation functionality in Akka remoting 
// application.conf 
//The configuration instructs Akka to react when an actor with path /sampleActor is created, 
//i.e. using system.actorOf(Props(...), "sampleActor") etc 

//This specific actor will not be directly instantiated, 
//but instead the remote daemon of the remote system will be asked to create the actor, 
//which in this sample corresponds to sampleActorSystem@127.0.0.1:2553.

//The actor class SampleActor has to be available to the runtimes using it, 
//i.e. the classloader of the actor systems has to have a JAR containing the class.

akka {
  actor {
    deployment {
      /sampleActor {
        remote = "akka.tcp://sampleActorSystem@127.0.0.1:2553"
      }
    }
  }
}

//code 
val actor = system.actorOf(Props[SampleActor], "sampleActor")
actor ! "Pretty slick"


//Ensure serializability of Props when passing constructor arguments 
//Serializability of all Props can be tested by setting the configuration item akka.actor.serialize-creators=on. 
//Only Props whose deploy has LocalScope are exempt from this check.

//You can use asterisks as wildcard matches for the actor path sections, 
  /*/sampleActor        match all sampleActor on that level in the hierarchy. 
  /someParent/*         match all actors at a certain level 
  
//Non-wildcard matches always have higher priority to match than wildcards
//only the highest priority match is used. 
  /foo/bar is considered more specific than /foo/* and 

//it cannot be used to partially match section, like this: /foo*/bar, /f*o/bar etc.



///Programmatic Remote Deployment

import akka.actor.{ Props, Deploy, Address, AddressFromURIString }
import akka.remote.RemoteScope

val one = AddressFromURIString("akka.tcp://sys@host:1234")
val two = Address("akka.tcp", "sys", "host", 1234) // this gives the same


val ref = system.actorOf(Props[SampleActor].withDeploy(Deploy(scope = RemoteScope(address))))


 
//Remote deployment whitelist
//As remote deployment can potentially be abused by both users and even attackers 
//a whitelist feature is available to guard the ActorSystem from deploying unexpected actors. 
//Please note that remote deployment is not remote code loading, 
//the Actors class to be deployed onto a remote system needs to be present on that remote system. 

//Actor classes not included in the whitelist will not be allowed to be remote deployed
akka.remote.deployment {
  enable-whitelist = on
  
  whitelist = [
    "NOT_ON_CLASSPATH", # verify we donot throw if a class not on classpath is listed here
    "akka.remote.RemoteDeploymentWhitelistSpec.EchoWhitelisted"
  ]
}


///*** Actor - Remote - Artery
//Artery is a reimplementation of the old remoting module aimed at improving performance and stability. 
//It is mostly source compatible with the old implementation 
//and it is a drop-in replacement in many cases. 
//Main features of Artery compared to the previous implementation:
0.Aeron requires 64bit JVM to work reliably.
1.Based on Aeron (UDP) instead of TCP
2.Focused on high-throughput, low-latency communication
3.Isolation of internal control messages from user messages improving stability and reducing false failure detection in case of heavy traffic by using a dedicated subchannel.
4.Mostly allocation-free operation
5.Support for a separate subchannel for large messages to avoid interference with smaller messages
6.Compression of actor paths on the wire to reduce overhead for smaller messages
7.Support for faster serialization/deserialization using ByteBuffers directly
8.Built-in Flight-Recorder to help debugging implementation issues without polluting users logs with implementation specific events
9.Providing protocol stability across major Akka versions to support rolling updates of large-scale systems
//sbt 
"com.typesafe.akka" %% "akka-remote" % "2.5.5"

//Main diiference is in address (not akk.tcp)
akka://<actor system>@<hostname>:<port>/<actor path>


//application.conf 
akka {
  actor {
    provider = remote
  }
  remote {
    artery {
      enabled = on
      canonical.hostname = "127.0.0.1"
      canonical.port = 25520
    }
  }
}

//usages are same 
val selection =  context.actorSelection("akka://actorSystemName@10.0.0.1:25520/user/actorName")
selection ! "Pretty awesome feature"

///*** Actor - Where configuration is read from
//default is to parse all application.conf, application.json and application.properties found at class path
//The actor system then merges in all reference.conf resources found at class path to form the fallback configuration,
 
//For Akka application, keep configuration in application.conf at class path(for sbt, src/main/resources)
//For Akka-based library, keep its configuration in reference.conf at the root of the JAR file.
 
//Check details from 
//http://doc.akka.io/docs/akka/2.5/general/configuration.html
 
 
///Custom: application.conf
#In this file you can override any option defined in the reference files.
# Copy in parts of the reference files and modify as you please.
 
akka {
 
  # Loggers to register at boot time (akka.event.Logging$DefaultLogger logs
  # to STDOUT)
  loggers = ["akka.event.slf4j.Slf4jLogger"]
 
  # Log level used by the configured loggers (see "loggers") as soon
  # as they have been started; before that, see "stdout-loglevel"
  # Options: OFF, ERROR, WARNING, INFO, DEBUG
  loglevel = "DEBUG"
 
  # Log level for the very basic logger activated during ActorSystem startup.
  # This logger prints the log messages to stdout (System.out).
  # Options: OFF, ERROR, WARNING, INFO, DEBUG
  stdout-loglevel = "DEBUG"
 
  # Filter of log events that is used by the LoggingAdapter before
  # publishing log events to the eventStream.
  logging-filter = "akka.event.slf4j.Slf4jLoggingFilter"
 
  actor {
    provider = "cluster"
 
    default-dispatcher {
      # Throughput for default Dispatcher, set to 1 for as fair as possible
      throughput = 10
    }
  }
 
  remote {
    # The port clients should connect to. Default is 2552.
    netty.tcp.port = 4711
  }
}
 
 
//The settings as merged with the reference and parsed by the actor system 
final ActorSystem system = ActorSystem.create();
System.out.println(system.settings());
// this is a shortcut for system.settings().config().root().render()

//reading application.conf
import com.typesafe.config.{ConfigFactory,ConfigValueFactory}
import akka.event.Logging

val conf = ConfigFactory.load()
val akkaConfig  = conf.getConfig("akka")
println(akkaConfig.getInt("remote.netty.tcp.port"))
val curConfig = akkaConfig.withValue("remote.netty.tcp.port",ConfigValueFactory.fromAnyRef(0)) //current config is akka, hence prefix akka is not required
val system = ActorSystem("CliSystem", curConfig)


 
 
///***Actor -  Lifecycle Monitoring aka DeathWatch
import akka.actor.{ Actor, Props, Terminated }
 
class WatchActor extends Actor {
  val child = context.actorOf(Props.empty, "child")
  context.watch(child) // <-- this is the only call needed for registration
  var lastSender = context.system.deadLetters
 
  def receive = {
    case "kill" =>
      context.stop(child); lastSender = sender()
    case Terminated(child) => lastSender ! "finished"
  }
}
// the watching actor will receive a Terminated message 
//even if the watched actor has already been terminated at the time of registration.

//to deregister from watching another actor�s liveliness using 
context.unwatch(target)








///*** Actor -  Dispatchers
///Every ActorSystem will have a default dispatcher
// All MessageDispatcher implementations are also an ExecutionContext, 
//which means that they can be used to execute arbitrary code, for instance Futures.

//By default this is a "fork-join-executor", 
//Other type of dispatchers - doc.akka.io/docs/akka/2.5/scala/dispatchers.html
//Dispatchers implement the ExecutionContext interface and can thus be used to run Future invocations etc
// for use with Futures, Scheduler, etc.

import system.dispatcher // The ExecutionContext that will be used
//or a particular dispatcher 
implicit val executionContext = system.dispatchers.lookup("my-thread-pool-dispatcher")

///example that uses the "thread-pool-executor"
//application.conf 
my-thread-pool-dispatcher {
  # Dispatcher is the name of the event-based dispatcher
  type = Dispatcher
  # What kind of ExecutionService to use
  executor = "thread-pool-executor"
  # Configuration for the thread pool
  thread-pool-executor {
    # minimum number of threads to cap factor-based core number to
    core-pool-size-min = 2
    # No of core threads ... ceil(available processors * factor)
    core-pool-size-factor = 2.0
    # maximum number of threads to cap factor-based number to
    core-pool-size-max = 10
  }
  # Throughput defines the maximum number of messages to be
  # processed per actor before the thread jumps to the next actor.
  # Set to 1 for as fair as possible.
  throughput = 100
}

//Use it as
//application.conf
akka.actor.deployment {
  /myactor {
    dispatcher = my-dispatcher
  }
}

import akka.actor.Props
val myActor = context.actorOf(Props[MyActor], "myactor")


//An alternative to the deployment configuration is to define the dispatcher in code. 
import akka.actor.Props
val myActor = context.actorOf(Props[MyActor].withDispatcher("my-thread-pool-dispatcher"), "myactor1")


  
  
  
  
  
  
///*** Actor - Mailboxes

//An Akka Mailbox holds the messages that are destined for an Actor. 
//Normally each Actor has its own mailbox, 
//OR for example a BalancingPool, all routees will share a single mailbox instance.


///Requiring a Message Queue Type for an Actor
//actor extend the parameterized trait RequiresMessageQueue. 
//Other type of mail boxes - http://doc.akka.io/docs/akka/2.5/scala/mailboxes.html


import akka.dispatch.RequiresMessageQueue
import akka.dispatch.BoundedMessageQueueSemantics
 
class MyBoundedActor extends MyActor with RequiresMessageQueue[BoundedMessageQueueSemantics]

//The type parameter to the RequiresMessageQueue trait needs to be mapped to a mailbox 

bounded-mailbox {
  mailbox-type = "akka.dispatch.BoundedMailbox"
  mailbox-capacity = 1000
  mailbox-push-timeout-time = 10s
}
     
akka.actor.mailbox.requirements {
  "akka.dispatch.BoundedMessageQueueSemantics" = bounded-mailbox
}

    
///*Default Mailbox
//By default it is an unbounded mailbox, 
//which is backed by a java.util.concurrent.ConcurrentLinkedQueue

//SingleConsumerOnlyUnboundedMailbox is an even more efficient mailbox, 
//and it can be used as the default mailbox, but it cannot be used with a BalancingDispatcher.
akka.actor.default-mailbox {
  mailbox-type = "akka.dispatch.SingleConsumerOnlyUnboundedMailbox"
}

    
    


///*** Actor - Duration
scala.concurrent.duration.Duration
    Values of this type may represent infinite (Duration.Inf, Duration.MinusInf) 
    or finite durations, or be Duration.Undefined.
    Duration can be finite or infinite, calling toNanos etc might be unsafe 
    It all arithmatic operators , check 

final  class  FiniteDuration extends Duration 
    guaranteed to be finite, calling toNanos etc is safe
    new  FiniteDuration(length: Long, unit: TimeUnit) 


//Example 
import scala.concurrent.duration._

val duration = Duration(100, MILLISECONDS)
val duration = Duration(100, "millis")

duration.toNanos
duration < 1.second
duration <= Duration.Inf

//durations are constructable using a DSL 
//and support all expected arithmetic operations

//The DSL provided by the implicit conversions always allows construction of finite durations, 
//even for infinite Double inputs; use Duration.Inf instead.

val fivesec = 5.seconds   //recommended: use . notation always
val threemillis = 3.millis
val diff = fivesec - threemillis
assert(diff < fivesec)
val fourmillis = threemillis * 4 / 3 // you cannot write it the other way around
val n = threemillis / (1 millisecond)


//Extractors, parsing and arithmetic are also included:
val d = Duration("1.2 �s")
val Duration(length, unit) = 5 millis
val d2 = d * 2.5
val d3 = d2 + 1.millisecond


//Deadline
// support deriving a duration from this by calculating the difference between now and the deadline. 
val deadline = 10.seconds.fromNow
// do something
val rest = deadline.timeLeft

//akka.util.Timeout
case class  Timeout(duration: FiniteDuration)
    new Timeout(length: Long, unit: TimeUnit) 
    new Timeout(duration: FiniteDuration) 


//java.util.concurrent.TimeUnit Enum
DAYS            Time unit representing twenty four hours
HOURS           Time unit representing sixty minutes
MICROSECONDS    Time unit representing one thousandth of a millisecond
MILLISECONDS    Time unit representing one thousandth of a second
MINUTES         Time unit representing sixty seconds
NANOSECONDS     Time unit representing one thousandth of a microsecond
SECONDS         Time unit representing one second 





///*** Actor - Reference of API 
//instance methods  of ActorSystem 
def actorSelection(path: ActorPath): ActorSelection
	Construct an akka.actor.ActorSelection from the given path, which is parsed for wildcards (these are replaced by regular expressions internally).
def actorSelection(path: String): ActorSelection
	Construct an akka.actor.ActorSelection from the given path, which is parsed for wildcards (these are replaced by regular expressions internally).
	val startTime: Long
	Start-up time in milliseconds since the epoch.
def uptime: Long
	Up-time of this actor system in seconds.
    
//object ActorSystem methods 
val EnvHome: Option[String]
val GlobalHome: Option[String]
val SystemHome: Option[String]
val Version: String
def apply(name: String, config: Option[Config] = None, classLoader: Option[ClassLoader] = None, defaultExecutionContext: Option[ExecutionContext] = None): ActorSystem
	Creates a new ActorSystem with the specified name, the specified ClassLoader if given, otherwise obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.
def apply(name: String, config: Config, classLoader: ClassLoader): ActorSystem
	Creates a new ActorSystem with the specified name, the specified Config, and specified ClassLoader
def apply(name: String, config: Config): ActorSystem
	Creates a new ActorSystem with the specified name, and the specified Config, then obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.
def apply(name: String, bootstrapSetup: BootstrapSetup): ActorSystem
	Scala API: Shortcut for creating an actor system with custom bootstrap settings.
def apply(name: String, setup: ActorSystemSetup): ActorSystem
	Scala API: Creates a new actor system with the specified name and settings The core actor system settings are defined in BootstrapSetup
def apply(name: String): ActorSystem
	Creates a new ActorSystem with the specified name, obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.
def apply(): ActorSystem
	Creates a new ActorSystem with the name "default", obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.
def create(name: String, config: Config, classLoader: ClassLoader, defaultExecutionContext: ExecutionContext): ActorSystem
	Creates a new ActorSystem with the specified name, the specified Config, the specified ClassLoader, and the specified ExecutionContext.
def create(name: String, config: Config, classLoader: ClassLoader): ActorSystem
	Creates a new ActorSystem with the specified name, the specified Config, and specified ClassLoader
def create(name: String, config: Config): ActorSystem
	Creates a new ActorSystem with the specified name, and the specified Config, then obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.
def create(name: String): ActorSystem
	Creates a new ActorSystem with the specified name, obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.
def create(): ActorSystem
	Creates a new ActorSystem with the name "default", obtains the current ClassLoader by first inspecting the current threads getContextClassLoader, then tries to walk the stack to find the callers class loader, then falls back to the ClassLoader associated with the ActorSystem class.

//instance methods  of ActorSelection 
def !(msg: Any)(implicit sender: ActorRef = Actor.noSender): Unit
def anchorPath: ActorPath
	The akka.actor.ActorPath of the anchor actor.
def equals(obj: Any): Boolean
def forward(message: Any)(implicit context: ActorContext): Unit
	Forwards the message and passes the original sender actor as the sender.
	lazy val hashCode: Int
def pathString: String
	String representation of the path elements, starting with "/" and separated with "/".
def resolveOne(timeout: FiniteDuration): Future[ActorRef]
	Resolve the ActorRef matching this selection.
def resolveOne()(implicit timeout: Timeout): Future[ActorRef]
	Resolve the ActorRef matching this selection.
def tell(msg: Any, sender: ActorRef): Unit
	Sends the specified message to this ActorSelection, i.e.
def toSerializationFormat: String
	String representation of the actor selection suitable for storage and recreation.
def toString(): String 

//object ActorSelection members 
def apply(anchorRef: ActorRef, elements: Iterable[String]): ActorSelection
	Construct an ActorSelection from the given string representing a path relative to the given target.
def apply(anchorRef: ActorRef, path: String): ActorSelection
	Construct an ActorSelection from the given string representing a path relative to the given target.

//instance methods  of ActorContext 
def actorOf(props: Props, name: String): ActorRef
	Create new actor as child of this context with the given name, which must not be null, empty or start with �$�.
def actorOf(props: Props): ActorRef
	Create new actor as child of this context and give it an automatically generated name (currently similar to base64-encoded integer count, reversed and with �$� prepended, may change in the future).
def become(behavior: Receive, discardOld: Boolean): Unit
	Changes the Actors behavior to become the new 'Receive' (PartialFunction[Any, Unit]) handler.
def child(name: String): Option[ActorRef]
	Get the child with the given name if it exists.
def children: Iterable[ActorRef]
	Returns all supervised children; this method returns a view (i.e.
implicit def dispatcher: ExecutionContextExecutor
	Returns the dispatcher (MessageDispatcher) that is used for this Actor.
def parent: ActorRef
	Returns the supervising parent ActorRef.
def props: Props
	Retrieve the Props which were used to create this actor.
def receiveTimeout: Duration
	Gets the current receive timeout.
def self: ActorRef
	The ActorRef representing this actor
def sender(): ActorRef
	Returns the sender 'ActorRef' of the current message.
def setReceiveTimeout(timeout: Duration): Unit
	Defines the inactivity timeout after which the sending of a akka.actor.ReceiveTimeout message is triggered.
def stop(actor: ActorRef): Unit
	Stop the actor pointed to by the given akka.actor.ActorRef; this is an asynchronous operation, i.e.
implicit def system: ActorSystem
	The system that the actor belongs to.
def unbecome(): Unit
	Reverts the Actor behavior to the previous one on the behavior stack.
def unwatch(subject: ActorRef): ActorRef
	Unregisters this actor as Monitor for the provided ActorRef.
def watch(subject: ActorRef): ActorRef
	Registers this actor as a Monitor for the provided ActorRef.
def watchWith(subject: ActorRef, msg: Any): ActorRef
	Registers this actor as a Monitor for the provided ActorRef.
def actorSelection(path: ActorPath): ActorSelection
		Construct an akka.actor.ActorSelection from the given path, which is parsed for wildcards (these are replaced by regular expressions internally).
def actorSelection(path: String): ActorSelection
		Construct an akka.actor.ActorSelection from the given path, which is parsed for wildcards (these are replaced by regular expressions internally).
def become(behavior: Receive): Unit
		Changes the Actor behavior to become the new 'Receive' (PartialFunction[Any, Unit]) handler.

//instance methods of akka.actor.ActorPath 
def /(child: String): ActorPath
    Create a new child actor path.
def address: Address
    The Address under which this path can be reached; walks up the tree to the RootActorPath.
def compareTo(arg0: ActorPath): Int
def elements: Iterable[String]
    Sequence of names for this path from root to this.
def name: String
    The name of the actor that this path refers to.
def parent: ActorPath
    The path for the parent actor.
def root: RootActorPath
    Walk up the tree to obtain and return the RootActorPath.
def toSerializationFormat: String
    Generate full String representation including the uid for the actor cell instance as URI fragment.
def toSerializationFormatWithAddress(address: Address): String
    Generate full String representation including the uid for the actor cell instance as URI fragment, replacing the Address in the RootActor Path with the given one unless this path�s address includes host and port information.
def toStringWithAddress(address: Address): String
    Generate String representation, replacing the Address in the RootActor Path with the given one unless this path�s address includes host and port information.
def /(child: Iterable[String]): ActorPath
    Recursively create a descendant�s path by appending all child names.
def toStringWithoutAddress: String
    String representation of the path elements, excluding the address information.
    
//object ActorPath members 
def fromString(s: String): ActorPath
    Parse string as actor path; throws java.net.MalformedURLException if unable to do so.
final def isValidPathElement(s: String): Boolean
    This method is used to validate a path element (Actor Name).
final def validatePathElement(element: String, fullPath: String): Unit
    Validates the given actor path element and throws an InvalidActorNameException if invalid.
final def validatePathElement(element: String): Unit
    Validates the given actor path element and throws an InvalidActorNameException if invalid.
    
		
    
    
    
///*** Actor - Routing
//router - which routes messages 
//routee - actors which recieve message (ie Worker)

//Messages can be sent via a router to efficiently route them to destination actors, known as its routees. 
//A Router can be used inside or outside of an actor, 

final case class Router(logic: RoutingLogic, routees: IndexedSeq[Routee] = Vector.empty)
    For each message that is sent through the router via the #route method the RoutingLogic decides to which Routee to send the message.

    
///Simple Router 
import akka.actor._
import akka.routing.{ ActorRefRoutee, RoundRobinRoutingLogic, Router }
 
case class Work(id:Int)       //some work

class Master extends Actor {
  var router = {
    val routees = Vector.fill(5) {
      val r = context.actorOf(Props[Worker])
      context watch r
      ActorRefRoutee(r)   //create the routees as ordinary child actors wrapped in ActorRefRoutee
    }
    Router(RoundRobinRoutingLogic(), routees)
  }
 
  def receive = {
    case w: Work =>
      router.route(w, sender())  //Sending messages via the router is done with the route method
    case Terminated(a) =>
      router = router.removeRoutee(a)
      val r = context.actorOf(Props[Worker])
      context watch r
      router = router.addRoutee(r)
  }
}

class Worker extends Actor with ActorLogging{
   
    def receive = {
        case Work(id) => 
            log.info("{} :processing {}" ,Thread.currentThread().getName(), id)
            sender() ! (id * id) 
        case _ => 
    }

}

import akka.actor.{ActorSystem, Props}
implicit val system = ActorSystem("testSystem")
val firstRef = system.actorOf(Props[Master], "master")

firstRef ! Work(12)

import scala.util._
val rand = new Random()
(1 to 10).toList.map(rand.nextInt ).foreach{id => firstRef ! Work(id) }

import ActorDSL._
import scala.concurrent.duration._

//with Actor-DSL , deprecated 
implicit val i = inbox()
(1 to 10).toList.map(rand.nextInt ).map{id => 
            firstRef ! Work(id) 
            i.receive().asInstanceOf[Int]
        }
        
system.terminate()

//The routing logic shipped with Akka are(akka.routing.) 
final class BroadcastRoutingLogic
    Broadcasts a message to all its routees.
final case class ConsistentHashingRoutingLogic(system: ActorSystem, virtualNodesFactor: Int = 0, hashMapping: ConsistentHashMapping = ...)
    Uses consistent hashing to select a routee based on the sent message.
final class RandomRoutingLogic
    Randomly selects one of the target routees to send a message to
final class RoundRobinRoutingLogic
    Uses round-robin to select a routee.
final case class ScatterGatherFirstCompletedRoutingLogic(within: FiniteDuration)
    Broadcasts the message to all routees, and replies with the first response.
final case class TailChoppingRoutingLogic(scheduler: Scheduler, within: FiniteDuration, interval: FiniteDuration, context: ExecutionContext)
    As each message is sent to the router, the routees are randomly ordered.
object BroadcastRoutingLogic
object ConsistentHashingRoutingLogic extends Serializable
class SmallestMailboxRoutingLogic
    Tries to send to the non-suspended routee with fewest messages in mailbox.
object RandomRoutingLogic

//any message sent to a router will be sent onwards to its routees, 
//but there is one exception. 
//The special Broadcast Messages will send to all of a router's routees

///* A Router Actor
//https://doc.akka.io/docs/akka/2.5/routing.html

//A router can also be created as a self contained actor 
//that manages the routees itself and loads routing logic and other settings from configuration.
//User only needs to create router actor, by giving Worker actor name as routees
//Router would forward all the messages to Worker 
Pool 
    The router creates routees as child actors 
    and removes them from the router if they terminate.
    Available pools are (each has .props(Props[T]) method )
    Note corresponding conf is - convert camelcase to '-' and lowercase the class name 
        final case class BalancingPool(nrOfInstances: Int, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId)
            A router pool that will try to redistribute work from busy routees to idle routees.
        final case class BroadcastPool(nrOfInstances: Int, resizer: Option[Resizer] = None, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool that broadcasts a message to all its routees.
        final case class ConsistentHashingPool(nrOfInstances: Int, resizer: Option[Resizer] = None, virtualNodesFactor: Int = 0, hashMapping: ConsistentHashMapping = ..., supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool that uses consistent hashing to select a routee based on the sent message.
        final case class RandomPool(nrOfInstances: Int, resizer: Option[Resizer] = None, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool that randomly selects one of the target routees to send a message to.
        final case class RoundRobinPool(nrOfInstances: Int, resizer: Option[Resizer] = None, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool that uses round-robin to select a routee.
        final case class ScatterGatherFirstCompletedPool(nrOfInstances: Int, resizer: Option[Resizer] = None, within: FiniteDuration, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool that broadcasts the message to all routees, and replies with the first response.
        final case class TailChoppingPool(nrOfInstances: Int, resizer: Option[Resizer] = None, within: FiniteDuration, interval: FiniteDuration, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool with retry logic, intended for cases where a return message is expected in response to a message sent to the routee.
        final case class SmallestMailboxPool(nrOfInstances: Int, resizer: Option[Resizer] = None, supervisorStrategy: SupervisorStrategy = Pool.defaultSupervisorStrategy, routerDispatcher: String = Dispatchers.DefaultDispatcherId, usePoolDispatcher: Boolean = false)
            A router pool that tries to send to the non-suspended routee with fewest messages in mailbox.
      
Group 
    The routee actors are created externally to the router 
    and the router sends messages to the specified path using actor selection, without watching for termination.
    Available pools are (each has .props(Props[T]) method )
    Note corresponding conf is - convert camelcase to '-' and lowercase the class name 
    final case class BroadcastGroup(paths: Iterable[String], routerDispatcher: String = Dispatchers.DefaultDispatcherId)
        A router group that broadcasts a message to all its routees.
    final case class ConsistentHashingGroup(paths: Iterable[String], virtualNodesFactor: Int = 0, hashMapping: ConsistentHashMapping = ..., routerDispatcher: String = Dispatchers.DefaultDispatcherId)
        A router group that uses consistent hashing to select a routee based on the sent message.
    final case class TailChoppingGroup(paths: Iterable[String], within: FiniteDuration, interval: FiniteDuration, routerDispatcher: String = Dispatchers.DefaultDispatcherId)
        A router group with retry logic, intended for cases where a return message is expected in response to a message sent to the routee.
    final case class ScatterGatherFirstCompletedGroup(paths: Iterable[String], within: FiniteDuration, routerDispatcher: String = Dispatchers.DefaultDispatcherId)
        A router group that broadcasts the message to all routees, and replies with the first response.
    final case class RoundRobinGroup(paths: Iterable[String], routerDispatcher: String = Dispatchers.DefaultDispatcherId)
        A router group that uses round-robin to select a routee.
    final case class RandomGroup(paths: Iterable[String], routerDispatcher: String = Dispatchers.DefaultDispatcherId)
        A router group that randomly selects one of the target routees to send a message to.

    

///Pool - Example 
// to create a round-robin router 
//that forwards messages to five Worker routees
//application.conf 
akka.actor.deployment {
  /parent/router1 {
    router = round-robin-pool
    nr-of-instances = 5
  }
}
//usage , inside a Actor, name= "parent"
import akk.actor._ 
import akka.routing._ 

//Create parent 
system.actorOf(Props[Parent], "parent")

//Inside Parent Actor 
val router1: ActorRef = context.actorOf(FromConfig.props(Props[Worker]), "router1")
//OR, with the router configuration provided programmatically instead of from configuration.
val router2: ActorRef = context.actorOf(RoundRobinPool(5).props(Props[Worker]), "router2")

///Remote Deployed Routees
import akka.actor.{ Address, AddressFromURIString }
import akka.remote.routing.RemoteRouterConfig
val addresses = Seq( Address("akka.tcp", "remotesys", "otherhost", 1234),
  AddressFromURIString("akka.tcp://othersys@anotherhost:1234"))
val routerRemote = system.actorOf( RemoteRouterConfig(RoundRobinPool(5), addresses).props(Props[Worker]))

//By default, when a routee(Worker) sends a message, 
//it will implicitly set itself as the sender.
sender() ! x // replies will go to Worker actor

//However, it is often useful for routees,Worker to set the router(parent) as a sender. 
//and Parent would forward the messages to routee/Worker as and when required
sender().tell("reply", context.parent) // replies will go back to parent
sender().!("reply")(context.parent) // alternative syntax 


///Group - Example 
//rather than having the router actor create its routees, 
//it is desirable to create routees separately and provide them to the router for its use. 
//Messages will be sent with ActorSelection to these paths.

akka.actor.deployment {
  /parent/router3 {
    router = round-robin-group
    routees.paths = ["/user/workers/w1", "/user/workers/w2", "/user/workers/w3"]
  }
}

//Create parent 
system.actorOf(Props[Parent], "parent")

//Inside Parent Actor 
val router3: ActorRef = context.actorOf(FromConfig.props(), "router3")

//OR  with the router configuration provided programmatically instead of from configuration.
val paths = List("/user/workers/w1", "/user/workers/w2", "/user/workers/w3")
val router4: ActorRef = context.actorOf(RoundRobinGroup(paths).props(), "router4")

///The routee actors are created externally from the router:
system.actorOf(Props[Workers], "workers")

class Workers extends Actor {
  context.actorOf(Props[Worker], name = "w1")
  context.actorOf(Props[Worker], name = "w2")
  context.actorOf(Props[Worker], name = "w3")
  // ...
}
//The paths may contain protocol and address information for actors running on remote hosts. 
//Remoting requires the akka-remote module to be included in the classpath.

akka.actor.deployment {
  /parent/remoteGroup {
    router = round-robin-group
    routees.paths = [
      "akka.tcp://app@10.0.0.1:2552/user/workers/w1",
      "akka.tcp://app@10.0.0.2:2552/user/workers/w1",
      "akka.tcp://app@10.0.0.3:2552/user/workers/w1"]
  }
}

///* Balancing Pool ,BalancingPool
//A Router that will try to redistribute work from busy routees to idle routees. 
//All routees share the same mailbox.
//Do not use Broadcast Messages when you use BalancingPool for routers
//conf 
akka.actor.deployment {
  /parent/router9 {
    router = balancing-pool
    nr-of-instances = 5
    pool-dispatcher {
      attempt-teamwork = off
    }
  }
}
val router9: ActorRef =  context.actorOf(FromConfig.props(Props[Worker]), "router9")
//OR 
val router10: ActorRef =
      context.actorOf(BalancingPool(5).props(Props[Worker]), "router10")

//By default the fork-join-dispatcher is used 
//OR 
akka.actor.deployment {
  /parent/router10b {
    router = balancing-pool
    nr-of-instances = 5
    pool-dispatcher {
      executor = "thread-pool-executor"

      # allocate exactly 5 threads for this pool
      thread-pool-executor {
        core-pool-size-min = 5
        core-pool-size-max = 5
      }
    }
  }
}



///*Specially Handled Messages - Broadcast Messages
//A Broadcast message can be used to send a message to all of a router's routees. 

//Do not use Broadcast Messages when you use BalancingPool for routers.


//When a router receives a Broadcast message, 
//it will broadcast that message's payload to all routees, 

import akka.routing.Broadcast
router ! Broadcast("Watch out for Davy Jones' locker") //router extracts its payload and send only payload to Worker



///*Specially Handled Messages - PoisonPill Messages(same treatment for Kill Messages)
//here router (only router) is getting PoisionPill or Kill 
//and when the router stops it also stops its children(routees)
import akka.actor.PoisonPill
router ! PoisonPill

//If you wish to stop a router and its routees explicitely 
import akka.actor.PoisonPill
import akka.routing.Broadcast
router ! Broadcast(PoisonPill)
//or for Kill 
import akka.actor.Kill
import akka.routing.Broadcast
router ! Broadcast(Kill)


///Management Messages
Sending akka.routing.GetRoutees to a router actor 
    will make it send back its currently used routees in a akka.routing.Routees message.
Sending akka.routing.AddRoutee to a router actor 
    will add that routee to its collection of routees.
Sending akka.routing.RemoveRoutee to a router actor 
    will remove that routee to its collection of routees.
Sending akka.routing.AdjustPoolSize to a pool router actor 
    will add or remove that number of routees to its collection of routees.

trait Routee
    Abstraction of a destination for messages routed via a Router.
    Use one of below for actial usage 
final case class ActorRefRoutee(ref: ActorRef)
    Routee that sends the messages to an akka.actor.ActorRef.
final case class ActorSelectionRoutee(selection: ActorSelection)
    Routee that sends the messages to an akka.actor.ActorSelection.
    
final case class AddRoutee(routee: Routee)
    Add a routee by sending this message to the router.
final case class AdjustPoolSize(change: Int)
    Increase or decrease the number of routees in a Pool.
final case class Broadcast(message: Any)
    Used to broadcast a message to all routees in a router; only the contained message will be forwarded, i.e.
final case class Deafen(listener: ActorRef)
object GetRoutees extends GetRoutees with Product with Serializable
    Sending this message to a router will make it send back its currently used routees.
final case class RemoveRoutee(routee: Routee)
    Remove a specific routee by sending this message to the router.
final case class Routees(routees: IndexedSeq[Routee])
    Message used to carry information about what routees the router is currently using.
    
    
    
    
    
///*** Actor - Circuit breaker 
//A circuit breaker is used to provide stability and prevent cascading failures in distributed systems. 
//These should be used in conjunction with judicious timeouts at the interfaces between remote systems to prevent the failure of a single component from bringing down all components.


//Operations 
�During normal operation, a circuit breaker is in the Closed state:
    �Exceptions or calls exceeding the configured callTimeout increment a failure counter
    �Successes reset the failure count to zero
    �When the failure counter reaches a maxFailures count, the breaker is tripped into Open state
�While in Open state:
    �All calls fail-fast with a CircuitBreakerOpenException
    �After the configured resetTimeout, the circuit breaker enters a Half-Open state
�In Half-Open state:
    �The first call attempted is allowed through without failing fast
    �All other calls fail-fast with an exception just as in Open state
    �If the first call succeeds, the breaker is reset back to Closed state and the resetTimeout is reset
    �If the first call fails, the breaker is tripped again into the Open state 
     (as for exponential backoff circuit breaker, the resetTimeout is multiplied by the exponential backoff factor)

//Callbacks can be provided for every state entry via onOpen, onClose, and onHalfOpen
     
//Examples
//a CircuitBreaker would be configured for:
//�5 maximum failures
//�a call timeout of 10 seconds
//�a reset timeout of 1 minute

import scala.concurrent.duration._
import akka.pattern.CircuitBreaker
import akka.pattern.pipe
import akka.actor.{ Actor, ActorLogging, ActorRef }

import scala.concurrent.Future
import scala.util.{ Failure, Success, Try }

class DangerousActor extends Actor with ActorLogging {
  import context.dispatcher

  val breaker =  new CircuitBreaker(
      context.system.scheduler,
      maxFailures = 5,
      callTimeout = 10.seconds,
      resetTimeout = 1.minute).onOpen(notifyMeOnOpen())

  def notifyMeOnOpen(): Unit =
    log.warning("My CircuitBreaker is now open, and will not close for one minute")

  def dangerousCall: String = "This really isn't that dangerous of a call after all"
  
  //withCircuitBreaker  : Asynchronous call through CircuitBreaker, accepts  Future 
  //withSyncCircuitBreaker: Synchronous callhrough CircuitBreaker, accepts a method 
  
  def receive = {
      case "is my middle name" =>
        breaker.withCircuitBreaker(Future(dangerousCall)) pipeTo sender()
      case "block for me" =>
        sender() ! breaker.withSyncCircuitBreaker(dangerousCall)
    }
    
} 
//By default, the circuit breaker treat Exception as failure in synchronized API, 
//or failed Future as failure in future based API.   
// OR configure with argument defineFailureFn ,defineFailureFn: Try[T] => Boolean
//of withCircuitBreaker, withSyncCircuitBreaker

//defineFailureFn function should return true if the call should increase failure count, else false.
    
def luckyNumber(): Future[Int] = {
  val evenNumberAsFailure: Try[Int] => Boolean = {
    case Success(n) => n % 2 == 0
    case Failure(_) => true
  }

  val breaker =
    new CircuitBreaker(
      context.system.scheduler,
      maxFailures = 5,
      callTimeout = 10.seconds,
      resetTimeout = 1.minute)

  // this call will return 8888 and increase failure count at the same time
  breaker.withCircuitBreaker(Future(8888), evenNumberAsFailure)
}   
    
    
    
    
    
    
///*** Actor - FSM
//The FSM (Finite State Machine) is available as a mixin for a class that implements an Akka Actor 
State(S) x Event(E) -> Actions (A), State(S�)
//means 
//If we are in state S and the event E occurs, perform the actions A and make a transition to state S�.

trait FSM[S, D] extends Actor with Listeners with ActorLogging 
trait LoggingFSM[S, D] extends FSM[S, D]
    Stackable trait for akka.actor.FSM which adds a rolling event log and debug logging capabilities

object A {
    trait State
    case class One extends State
    case class Two extends State
    case class Data(i : Int)
}

class A extends Actor with FSM[A.State, A.Data] {
    import A._

    startWith(One, Data(42))
    when(One) {
        case Event(SomeMsg, Data(x)) => ...
        case Event(SomeOtherMsg, _) => ... // when data not needed
    }
    when(Two, stateTimeout = 5 seconds) { ... }
    initialize()
}

//startWith defines the initial state and initial data
// when(<state>) { PartialFunction } declaration per state for handling that state 
//(could be multiple ones, the passed PartialFunction will be concatenated using orElse)
//starting FSM up using initialize, which performs the transition into the initial state and sets up timers (if required).

//Within PartialFunction, following values are returned for effecting state transitions:
1.stay for staying in the same state
2.stay using Data(...) for staying in the same state, but with different data
3.stay forMax 5.millis for staying with a state timeout; can be combined with 'using'
4.goto(...) for changing into a different state; also supports 'using' and 'forMax'
5.stop for terminating this FSM actor
6.Each of above also supports the method replying(AnyRef) for sending a reply(message) before changing state.

//Example 
when(SomeState) {
  case Event(msg, _) ?
    goto(Processing) using (newData) forMax (5 seconds) replying (WillDo)
}

//While changing state, custom handlers may be invoked which are registered using onTransition. 
//Multiple such blocks are supported and all of them will be called

//convenience extractor -> enables decomposition of the pair of states
onTransition {
  case Idle -> Active => setTimer("timeout", Tick, 1 second, repeat = true)
  case Active -> _    => cancelTimer("timeout")
  case x -> Idle      => log.info("entering Idle from " + x)
}
//or 
onTransition(handler _)

def handler(from: StateType, to: StateType) {
  // handle it here ...
}

//other actors may subscribe for transition events by sending a SubscribeTransitionCallback message to this actor. 
//Stopping a listener without unregistering will not remove the listener from the subscription list; 
//use UnsubscribeTransitionCallback before stopping the listener.

//State timeouts set an upper bound to the time which may pass before another message is received in the current state. 
//If no external message is available and with expiry of the timeout,  StateTimeout message is sent. 
//Note that this message will only be received in the state for which the timeout was set 
//and that any message received will cancel the timeout 
//(possibly to be started again by the next transition).

//User can install and cancel single-shot as well as repeated timers 
//which arrange for the sending of a user-specified message:
setTimer(name, msg, interval, repeat)
//exmaple 
setTimer("tock", TockMsg, 1 second, true) // repeating
setTimer("lifetime", TerminateMsg, 1 hour, false) // single-shot
cancelTimer("tock")
isTimerActive("tock")


//use onTermination(handler) to specify custom code that is executed when the FSM is stopped. 
//The handler is a partial function which takes a StopEvent(reason, stateName, stateData) as argument:
onTermination {
  case StopEvent(FSM.Normal, state, data)         ? // ...
  case StopEvent(FSM.Shutdown, state, data)       ? // ...
  case StopEvent(FSM.Failure(cause), state, data) ? // ...
}
    
  

//Example
//an actor which shall receive and queue messages while they arrive in a burst 
//and send them on after the burst ended or a flush request is received.


import akka.actor.{ ActorRef, FSM }
import scala.concurrent.duration._


//actor accepts or produces the following messages:

//SetTarget is needed for starting it up, setting the destination for the Batches to be passed on; 
//Queue will add to the internal queue while Flush will mark the end of a burst.

// received events
final case class SetTarget(ref: ActorRef)
final case class Queue(obj: Any)
case object Flush

// sent events
final case class Batch(obj: immutable.Seq[Any])

//The actor can be in two states: no message queued (aka Idle) or some message queued (aka Active). 
//It will stay in the Active state as long as messages keep arriving and no flush is requested. 
// states
sealed trait State
case object Idle extends State
case object Active extends State

//The internal state data of the actor is made up of the target actor reference to send the batches to 
//and the actual queue of messages.
sealed trait Data
case object Uninitialized extends Data
final case class Todo(target: ActorRef, queue: immutable.Seq[Any]) extends Data


//start out in the Idle state with Uninitialized data, 
//handle SetTarget() => 'stay' in that state, but update Data with ToDo

//The Active state has a state timeout declared, 
//if no message is received for 1 second, a FSM.StateTimeout message will be generated. 
//This has the same effect as receiving the Flush command , to transition back into the Idle state 
//and resetting the internal queue to the empty vector. 

//that any event which is not handled by the when() block is passed to the whenUnhandled() block
//We have used this to handle same code for both states 

//following members of FSM[S, D] are used 
final def stateName: S
    Return current state name
final def stateData: D
    Return current state data
final case class Event[D](event: Any, stateData: D)
    All messages sent to the akka.actor.FSM will be wrapped inside an Event, 
    which allows pattern matching to extract both state and data.

    
class Buncher extends FSM[State, Data] {

  startWith(Idle, Uninitialized)

  when(Idle) {
    case Event(SetTarget(ref), Uninitialized) =>
      stay using Todo(ref, Vector.empty)
  }

  onTransition {
    case Active -> Idle =>
      stateData match {                     
        case Todo(ref, queue) => ref ! Batch(queue)
        case _                => // nothing to do
      }
  }

  when(Active, stateTimeout = 1 second) {
    case Event(Flush | StateTimeout, t: Todo) =>
      goto(Idle) using t.copy(queue = Vector.empty)
  }

  whenUnhandled {
    // common code for both states
    case Event(Queue(obj), t @ Todo(_, v)) =>
      goto(Active) using t.copy(queue = v :+ obj)

    case Event(e, s) =>
      log.warning("received unhandled request {} in state {}/{}", e, stateName, s)
      stay
  }

  initialize()
}


//Test with ScalaTest traits into AkkaSpecTestKit, using JUnit 
//build.sbt 
libraryDependencies += "com.typesafe.akka" %% "akka-testkit" % "2.5.11" % Test
//https://doc.akka.io/docs/akka/2.5/testing.html
//message checking 
val hello: String = expectMsg("hello")
val any: String = expectMsgAnyOf("hello", "world")
val all: immutable.Seq[String] = expectMsgAllOf("hello", "world")
val i: Int = expectMsgType[Int]
expectNoMessage(200.millis)
val two: immutable.Seq[AnyRef] = receiveN(2)


//code 

import akka.actor._
import scala.collection.immutable


import akka.testkit.{ ImplicitSender, TestActors, TestKit }
import org.scalatest.{ BeforeAndAfterAll, Matchers, WordSpecLike }

object FSMDocSpec {
  // copy messages and data types
}

class FSMDocSpec extends TestKit(ActorSystem("MySpec"))  with WordSpecLike with Matchers with BeforeAndAfterAll {

  override def afterAll {
    TestKit.shutdownActorSystem(system)
  } 
  
  import FSMDocSpec._

  import akka.actor.{ ActorRef, FSM }
  import scala.concurrent.duration._
  class Buncher extends FSM[State, Data] {

    startWith(Idle, Uninitialized)

    when(Idle) {
      case Event(SetTarget(ref), Uninitialized) ?
        stay using Todo(ref, Vector.empty)
    }

    onTransition {
      case Active -> Idle =>
        stateData match {
          case Todo(ref, queue) => ref ! Batch(queue)
          case _                => // nothing to do
        }
    }

    when(Active, stateTimeout = 1 second) {
      case Event(Flush | StateTimeout, t: Todo) =>
        goto(Idle) using t.copy(queue = Vector.empty)
    }

    whenUnhandled {
      // common code for both states
      case Event(Queue(obj), t @ Todo(_, v)) =>
        goto(Active) using t.copy(queue = v :+ obj)

      case Event(e, s) =>
        log.warning("received unhandled request {} in state {}/{}", e, stateName, s)
        stay
    }

    initialize()
  }
  object DemoCode {
    trait StateType
    case object SomeState extends StateType
    case object Processing extends StateType
    case object Error extends StateType
    case object Idle extends StateType
    case object Active extends StateType

    class Dummy extends FSM[StateType, Int] {
      class X
      val newData = 42
      object WillDo
      object Tick

      when(SomeState) {
        case Event(msg, _) =>
          goto(Processing) using (newData) forMax (5 seconds) replying (WillDo)
      }

      onTransition {
        case Idle -> Active => setTimer("timeout", Tick, 1 second, repeat = true)
        case Active -> _    => cancelTimer("timeout")
        case x -> Idle      => log.info("entering Idle from " + x)
      }

      onTransition(handler _)

      def handler(from: StateType, to: StateType) {
        // handle it here ...
      }

      when(Error) {
        case Event("stop", _) =>
          // do cleanup ...
          stop()
      }
      //transform takes type StateFunction = PartialFunction[Event, State] , PartialFunction[-A,+B] extends (A) => B
      //Returns TransformHelper, which has  using(andThen: PartialFunction[State, State]): StateFunction 
      //'using' takes PF, pf takes a State and returns a State 
      //transform is used in case some common handling logic shall be applied to different clauses
      //below means in 'SomeState', process an Event by 'stay' ing in that State if not read < 1000 else go to 'Procesing' state 
      when(SomeState)(transform {
        case Event(bytes: ByteString, read) => stay using (read + bytes.length)
      } using {
        //state= SomeState, read=Data=Int
        case s @ FSM.State(state, read, timeout, stopReason, replies) if read > 1000 =>
          goto(Processing)
      })
      
      /* 
      final case class Event[D](event: Any, stateData: D)
        All messages sent to the akka.actor.FSM will be wrapped inside an Event, 
        which allows pattern matching to extract both state and data.
        
      case class State[S, D](stateName: S, stateData: D, timeout: Option[FiniteDuration] = None, stopReason: Option[Reason] = None, replies: List[Any] = Nil)
        This captures all of the managed state of the akka.actor.FSM: 
        the state name, the state data,
        possibly custom timeout, stop reason and replies accumulated 
        while processing the last message.
     */

      val processingTrigger: PartialFunction[State, State] = {
        case s @ FSM.State(state, read, timeout, stopReason, replies) if read > 1000 =>
          goto(Processing)
      }

      when(SomeState)(transform {
        case Event(bytes: ByteString, read) => stay using (read + bytes.length)
      } using processingTrigger)

      onTermination {
        case StopEvent(FSM.Normal, state, data)         => // ...
        case StopEvent(FSM.Shutdown, state, data)       => // ...
        case StopEvent(FSM.Failure(cause), state, data) => // ...
      }

      whenUnhandled {
        case Event(x: X, data) =>
          log.info("Received unhandled event: " + x)
          stay
        case Event(msg, _) =>
          log.warning("Received unknown event: " + msg)
          goto(Error)
      }

    }

    import akka.actor.LoggingFSM
    class MyFSM extends LoggingFSM[StateType, Data] {
      override def logDepth = 12
      onTermination {
        case StopEvent(FSM.Failure(_), state, data) ?
          val lastEvents = getLog.mkString("\n\t")
          log.warning("Failure in state " + state + " with data " + data + "\n" +
            "Events leading up to this point:\n\t" + lastEvents)
      }
      // ...
    }

  }

  "simple finite state machine" must {

    "demonstrate NullFunction" in {
      class A extends FSM[Int, Null] {
        val SomeState = 0
        when(SomeState)(FSM.NullFunction)
      }
    }

    "batch correctly" in {
      val buncher = system.actorOf(Props(classOf[Buncher], this))
      buncher ! SetTarget(testActor)
      buncher ! Queue(42)
      buncher ! Queue(43)
      expectMsg(Batch(immutable.Seq(42, 43)))
      buncher ! Queue(44)
      buncher ! Flush
      buncher ! Queue(45)
      expectMsg(Batch(immutable.Seq(44)))
      expectMsg(Batch(immutable.Seq(45)))
    }

    "not batch if uninitialized" in {
      val buncher = system.actorOf(Props(classOf[Buncher], this))
      buncher ! Queue(42)
      expectNoMsg
    }
  }
}

//*reference 
//instance member of FSM , trait FSM[S, D] extends Actor with Listeners with ActorLogging 
type Event = FSM.Event[D]
type Receive = PartialFunction[Any, Unit]
type State = FSM.State[S, D]
type StateFunction = PartialFunction[Event, State]
type StopEvent = FSM.StopEvent[S, D]
type Timeout = Option[FiniteDuration]
final class TransformHelper
    def using(andThen: PartialFunction[State, State]): StateFunction 
type TransitionHandler = PartialFunction[(S, S), Unit] 

val ->  : FSM.->.type
    This extractor is just convenience for matching a (S, S) pair, 
    including a reminder what the new state is.
val Event: FSM.Event.type
val StateTimeout: FSM.StateTimeout.type
    This case object is received in case of a state timeout.
val StopEvent: FSM.StopEvent.type
final def cancelTimer(name: String): Unit
    Cancel named timer, ensuring that the message is not subsequently delivered (no race).
implicit val context: ActorContext
    Stores the context for this actor, including self, and sender.
final def goto(nextStateName: S): State
    Produce transition to other state.
final def initialize(): Unit
    Verify existence of initial state and setup timers.
final def isTimerActive(name: String): Boolean
    Inquire whether the named timer is still active.
def log: LoggingAdapter

final def nextStateData: D
    Return next state data (available in onTransition handlers)
final def onTermination(terminationHandler: PartialFunction[StopEvent, Unit]): Unit
    Set handler which is called upon termination of this FSM actor.
final def onTransition(transitionHandler: TransitionHandler): Unit
    Set handler which is called upon each state transition, i.e.
def postRestart(reason: Throwable): Unit
    User overridable callback: By default it calls preStart().
def postStop(): Unit
    Call onTermination hook; if you want to retain this behavior when overriding make sure to call super.postStop().
def preRestart(reason: Throwable, message: Option[Any]): Unit
    User overridable callback: By default it disposes of all children and then calls postStop().
def preStart(): Unit
    User overridable callback.
def receive: Receive
    This defines the initial actor behavior, it must return a partial function with the actor logic.
implicit final val self: ActorRef
    The 'self' field holds the ActorRef for this actor.
final def sender(): ActorRef
    The reference sender Actor of the last received message.
final def setStateTimeout(state: S, timeout: Timeout): Unit
    Set state timeout explicitly.
final def setTimer(name: String, msg: Any, timeout: FiniteDuration, repeat: Boolean = false): Unit
    Schedule named timer to deliver message after given delay, possibly repeating.
final def startWith(stateName: S, stateData: D, timeout: Timeout = None): Unit
    Set initial state.
final def stateData: D
    Return current state data (i.e.
final def stateName: S
    Return current state name (i.e.
final def stay(): State
    Produce "empty" transition descriptor.
final def stop(reason: Reason, stateData: D): State
    Produce change descriptor to stop this FSM actor including specified reason.
final def stop(reason: Reason): State
    Produce change descriptor to stop this FSM actor including specified reason.
final def stop(): State
    Produce change descriptor to stop this FSM actor with reason "Normal".
def supervisorStrategy: SupervisorStrategy
    User overridable definition the strategy to use for supervising child actors.
implicit final def total2pf(transitionHandler: (S, S) ? Unit): TransitionHandler
    Convenience wrapper for using a total function instead of a partial function literal.
    
final def transform(func: StateFunction): TransformHelper
def unhandled(message: Any): Unit
    User overridable callback.
final def when(stateName: S, stateTimeout: FiniteDuration = null)(stateFunction: StateFunction): Unit
    Insert a new StateFunction at the end of the processing chain for the given state.
final def whenUnhandled(stateFunction: StateFunction): Unit
    Set handler which is called upon reception of unhandled messages.


//object FSM members 
final case class CurrentState[S](fsmRef: ActorRef, state: S)
    Message type which is sent directly to the subscribed actor in akka.actor.FSM.SubscribeTransitionCallBack before sending any akka.actor.FSM.Transition messages.
final case class Event[D](event: Any, stateData: D)
    All messages sent to the akka.actor.FSM will be wrapped inside an Event, 
    which allows pattern matching to extract both state and data.

final case class Failure(cause: Any)
    Signifies that the akka.actor.FSM is shutting itself down because of an error, e.g.
final case class LogEntry[S, D](stateName: S, stateData: D, event: Any)
    Log Entry of the akka.actor.LoggingFSM, can be obtained by calling getLog.
sealed trait Reason
    Reason why this akka.actor.FSM is shutting down.
    
case class State[S, D](stateName: S, stateData: D, timeout: Option[FiniteDuration] = None, stopReason: Option[Reason] = None, replies: List[Any] = Nil)
    This captures all of the managed state of the akka.actor.FSM: the state name, the state data,
    possibly custom timeout, stop reason and replies accumulated 
    while processing the last message.
final case class StopEvent[S, D](reason: Reason, currentState: S, stateData: D)
    Case class representing the state of the akka.actor.FSM within the onTermination block.
final case class Transition[S](fsmRef: ActorRef, from: S, to: S)
    Message type which is used to communicate transitions between states 
    to all subscribed listeners (use akka.actor.FSM.SubscribeTransitionCallBack).

final case class SubscribeTransitionCallBack(actorRef: ActorRef)
    Send this to an akka.actor.FSM to request first the FSM.CurrentState 
    and then a series of FSM.Transition updates.
final case class UnsubscribeTransitionCallBack(actorRef: ActorRef)
    Unsubscribe from akka.actor.FSM.Transition notifications which was effected 
    by sending the corresponding akka.actor.FSM.SubscribeTransitionCallBack.

val ->  : ->.type
object ->
    This extractor is just convenience for matching a (S, S) pair, 
    including a reminder what the new state is.
object Normal extends Reason with Product with Serializable
    Default reason if calling stop().
object NullFunction extends PartialFunction[Any, Nothing]
    A partial function value which does not match anything and can be used to �reset� whenUnhandled and onTermination handlers.
object Shutdown extends Reason with Product with Serializable
    Reason given when someone was calling system.stop(fsm) from outside; also applies to Stop supervision directive.
object StateTimeout extends Product with Serializable
    This case object is received in case of a state timeout.
    
    
    

///*** Actor - EventStream of ActorSystem 
akka.actor.ActorSystem
    def eventStream: EventStream
        Main event bus of this actor system, used for example for logging.
        
//EventBus Interface 
trait akka.event.EventBus extends AnyRef 
//Subclasses 
    trait ActorEventBus extends EventBus
        Represents an EventBus where the Subscriber type is ActorRef 
    class EventStream extends LoggingBus with SubchannelClassification 
        type Classifier = Class[_]
        type Event = AnyRef
        type Subscriber = ActorRef 
    trait LoggingBus extends ActorEventBus  
        def logLevel: LogLevel
            Query currently set log level.
        def setLogLevel(level: LogLevel): Unit
            Change log level: default loggers 
//Type Members
    abstract type Classifier
    abstract type Event
    abstract type Subscriber 
//Abstract Value Members
    abstract def publish(event: Event): Unit
        Publishes the specified Event to this bus
    abstract def subscribe(subscriber: Subscriber, to: Classifier): Boolean
        Attempts to register the subscriber to the specified Classifier
    abstract def unsubscribe(subscriber: Subscriber): Unit
        Attempts to deregister the subscriber from all Classifiers it may be subscribed to
    abstract def unsubscribe(subscriber: Subscriber, from: Classifier): Boolean
        Attempts to deregister the subscriber from the specified Classifier

//Concepts 
Event is the type of all events published on that bus
Subscriber is the type of subscribers allowed to register on that event bus
Classifier defines the classifier to be used in selecting subscribers for dispatching events

//Many classifiers exist
trait ActorClassifier
    Can be mixed into an EventBus to specify that the Classifier type is ActorRef 
    type Classifier = ActorRef 
trait LookupClassification
    Maps Subscribers to Classifiers using equality on Classifier 
    to store a Set of Subscribers (hence the need for compareSubscribers) 
    Maps Events to Classifiers through the classify-method (so it knows who to publish to)
    //have concrete implementations of below methods 
    //(LookupClassification.this)#Event , type comes from mixed in's type Event 
    def publish(event: (LookupClassification.this)#Event): Unit
    def subscribe(subscriber: (LookupClassification.this)#Subscriber, to: (LookupClassification.this)#Classifier): Boolean
    def unsubscribe(subscriber: (LookupClassification.this)#Subscriber): Unit
    def unsubscribe(subscriber: (LookupClassification.this)#Subscriber, from: (LookupClassification.this)#Classifier): Boolean 
trait ManagedActorClassification
    Maps ActorRefs to ActorRefs to form an EventBus 
    where ActorRefs can listen to other ActorRefs.
trait PredicateClassifier
    Can be mixed into an EventBus to specify that the Classifier type 
    is a Function from Event to Boolean (predicate)
    type Classifier = ((PredicateClassifier.this)#Event) => Boolean 
trait ScanningClassification
    Maps Classifiers to Subscribers 
    and selects which Subscriber should receive which publication 
    through scanning through all Subscribers through the matches(classifier, event) method
trait SubchannelClassification
    Classification which respects relationships between channels: 
    subscribing to one channel automatically and idempotently subscribes to all sub-channels.


//Many classifiers exist - https://doc.akka.io/docs/akka/2.5/event-bus.html
//Most of them similar construction mechanisms as given for LookupClassification
//check which methods needs to be implemented - https://github.com/akka/akka/blob/v2.5.11/akka-actor/src/main/scala/akka/event/EventBus.scala

//for example  LookupClassification extracts an arbitrary classifier from each event 
//and maintaining a set of subscribers for each possible classifier.

//Maps Subscribers to Classifiers using equality on Classifier to store a Set of Subscribers (hence the need for compareSubscribers)
//Maps Events to Classifiers through the classify method (so it knows who to publish to)
//The compareSubscribers need to provide a total ordering of the Subscribers
//must implement below 
protected def mapSize(): Int
    This is a size hint for the number of Classifiers you expect to have (use powers of 2)
protected def compareSubscribers(a: Subscriber, b: Subscriber): Int
    Provides a total ordering of Subscribers (think java.util.Comparator.compare)
protected def classify(event: Event): Classifier
    Returns the Classifier associated with the given Event
protected def publish(event: Event, subscriber: Subscriber): Unit
    Publishes the given Event to the given Subscriber

//example 
import akka.event.EventBus
import akka.event.LookupClassification

final case class MsgEnvelope(topic: String, payload: Any)

/**
 * Publishes the payload of the MsgEnvelope when the topic of the
 * MsgEnvelope equals the String specified when subscribing.
 */
class LookupBusImpl extends EventBus with LookupClassification {
  type Event = MsgEnvelope
  type Classifier = String
  type Subscriber = ActorRef

  // is used for extracting the classifier from the incoming events
  override protected def classify(event: Event): Classifier = event.topic

  // will be invoked for each event for all subscribers which registered themselves
  // for the event�s classifier
  override protected def publish(event: Event, subscriber: Subscriber): Unit = {
    subscriber ! event.payload
  }

  // must define a full order over the subscribers, expressed as expected from
  // `java.lang.Comparable.compare`
  override protected def compareSubscribers(a: Subscriber, b: Subscriber): Int = a.compareTo(b)

  // determines the initial size of the index data structure
  // used internally (i.e. the expected number of different classifiers)
  override protected def mapSize: Int = 128

}
//USage - testActor is default actor in Akka testkit when used with trait ImplicitSender
import akka.actor.ActorSystem
import akka.testkit.{ ImplicitSender, TestActors, TestKit }
import org.scalatest.{ BeforeAndAfterAll, Matchers, WordSpecLike }

class MySpec() extends TestKit(ActorSystem("MySpec")) with ImplicitSender
  with WordSpecLike with Matchers with BeforeAndAfterAll {

      override def afterAll {
        TestKit.shutdownActorSystem(system)
      }
      
    "An Echo actor" must {
        "send back messages unchanged" in {
          val echo = system.actorOf(TestActors.echoActorProps)
          echo ! "hello world"
          expectMsg("hello world")
        }

      }
      
      "An Lookup classification" must {
        "classify events based on topic " in {
            val lookupBus = new LookupBusImpl
            lookupBus.subscribe(testActor, "greetings")
            lookupBus.publish(MsgEnvelope("time", System.currentTimeMillis()))
            lookupBus.publish(MsgEnvelope("greetings", "hello"))
            expectMsg("hello")
        }
    }
}

    
        
//Reference of EventStream
class EventStream extends LoggingBus with SubchannelClassification
    An Akka EventStream is a pub-sub stream of events both system and user generated, 
    where subscribers are ActorRefs and the channels are Classes 
    and Events are any java.lang.Object. 
    EventStreams employ SubchannelClassification, which means 
    that if you listen to a Class, you will receive any message that is of that type or a subtype.
    //example 
    import akka.actor.{ Actor, DeadLetter, Props }

    class DeadLetterListener extends Actor {
      def receive = {
        case d: DeadLetter => println(d)
      }
    }

    val listener = system.actorOf(Props[DeadLetterListener])
    system.eventStream.subscribe(listener, classOf[DeadLetter])      
    //only suppressed deadletter 
    import akka.actor.SuppressedDeadLetter
    system.eventStream.subscribe(listener, classOf[SuppressedDeadLetter])
    //all dead letters (including the suppressed ones):
    import akka.actor.AllDeadLetters
    system.eventStream.subscribe(listener, classOf[AllDeadLetters])
    
    //methods 
    new EventStream(sys: ActorSystem)
    new EventStream(sys: ActorSystem, debug: Boolean) 

    //Type Members
    type Classifier = Class[_]
    type Event = AnyRef
    type Subscriber = ActorRef 

    //Value Members
    def logLevel: LogLevel
        Query currently set log level.
    def publish(event: Event): Unit
    def setLogLevel(level: LogLevel): Unit
        Change log level: default loggers (i.e.
    def startUnsubscriber(): Unit
        Must be called after actor system is "ready".
    def subscribe(subscriber: ActorRef, channel: Class[_]): Boolean
        Attempts to register the subscriber to the specified Classifier
    def unsubscribe(subscriber: ActorRef): Unit
        Attempts to deregister the subscriber from all Classifiers it may be subscribed to
    def unsubscribe(subscriber: ActorRef, channel: Class[_]): Boolean
        Attempts to deregister the subscriber from the specified Classifier

        
        
        
        
        
        
        
        
        
///*** Actor - Persistence
//Akka persistence enables stateful actors to persist their internal state 
//so that it can be recovered when an actor is started, restarted after a JVM crash or by a supervisor, or migrated in a cluster. 

//sbt
libraryDependencies += "com.typesafe.akka" %% "akka-persistence" % "2.5.11"
//LevelDB-based plugins will require the following additional dependency:
libraryDependencies += "org.fusesource.leveldbjni" % "leveldbjni-all" % "1.8"

//Architecture
�PersistentActor: Is a persistent, stateful actor. 
    It is able to persist events to a journal and can react to them in a thread-safe manner. 
�AtLeastOnceDelivery
    To send messages with at-least-once delivery semantics to destinations, 
    also in case of sender and receiver JVM crashes.
�AsyncWriteJournal
    A journal stores the sequence of messages sent to a persistent actor. 
    An application can control which messages are journaled 
    and which are received by the persistent actor without being journaled. 
�Snapshot store
    A snapshot store persists snapshots of a persistent actor�s internal state.
    Snapshots are used for optimizing recovery times. The storage backend of a snapshot store is pluggable. 
    The persistence extension comes with a �local� snapshot storage plugin, 
    which writes to the local filesystem.
�Event sourcing.
    Akka persistence provides abstractions for the development of event sourced applications 
    Replicated snapshot stores are available as Community plugins.
 
//Steps 
1.A persistent actor receives a (non-persistent) command which is first validated if it can be applied to the current state
2.If validation succeeds, events are generated from the command, 
  representing the effect of the command. 
3.These events are then persisted and, after successful persistence, 
  used to change the actor�s state.
4.When the persistent actor needs to be recovered, only the persisted events are replayed 
5.1.Akka persistence supports event sourcing with the PersistentActor trait. 
5.2.An actor extends this trait and uses the persist method to persist and handle events. 
5.3.The behavior of a PersistentActor is defined by receiveRecover and receiveCommand, type PartialFunction[Any, Unit]
5.4.receiveRecover method defines how state is updated during recovery by handling Event and SnapshotOffer messages
5.5.The persistent actor�s receiveCommand method is a command handler.
    A command is handled by generating an event which is then persisted and handled. 
5.6.The persist[A](event: A)(handler: (A) => Unit) persists events(type A) asynchronously 
    and the event handler(takes event,A as arg) is executed for successfully persisted events. 
5.7.An event handler may close over persistent actor state and mutate it. 
    The sender of a persisted event is the sender of the corresponding command. 
    This allows event handlers to reply to the sender of a command
5.8.The main responsibility of an event handler is changing persistent actor state using event data 
    and notifying others about successful state changes by publishing events.


//Reference 
trait AtLeastOnceDelivery
    Mix-in this trait with your PersistentActor to send messages 
    with at-least-once delivery semantics to destinations.
final case class SnapshotOffer(metadata: SnapshotMetadata, snapshot: Any) extends Product with Serializable
    Offers a PersistentActor a previously saved snapshot during recovery. 
    This offer is received before any further replayed messages. 
final case class SnapshotMetadata(persistenceId: String, sequenceNr: Long, timestamp: Long = 0L) extends Product with Serializable
    Snapshot metadata. 
    
//akka.persistence.PersistentActor instance methods 
trait PersistentActor extends Eventsourced with PersistenceIdentity
    type Receive = PartialFunction[Any, Unit] 
    //abstract methods 
    abstract def persistenceId: String
        Id of the persistent entity for which messages should be replayed.
    abstract def receiveCommand: Receive
        Command handler.
    abstract def receiveRecover: Receive
        Recovery handler that receives persisted events during recovery.
        
    //Concrete Value Members
    def deferAsync[A](event: A)(handler: (A) => Unit): Unit
        Defer the handler execution until all pending handlers have been executed.
        
    def internalStashOverflowStrategy: StashOverflowStrategy
        The returned StashOverflowStrategy object determines how to handle the message failed to stash when the internal Stash capacity exceeded.
    def journalPluginId: String
        Configuration id of the journal plugin servicing this persistent actor or view.
    implicit val context: ActorContext
        Stores the context for this actor, including self, and sender.
        
    def lastSequenceNr: Long
        Highest received sequence number so far or 0L if this actor hasnot replayed or stored any persistent events yet.
    def deleteMessages(toSequenceNr: Long): Unit
        Permanently deletes all persistent messages with sequence numbers less than or equal toSequenceNr.

    def snapshotPluginId: String
        Configuration id of the snapshot plugin servicing this persistent actor or view.
    def snapshotSequenceNr: Long
        Returns lastSequenceNr.
    def snapshotterId: String
        Returns persistenceId.
    def loadSnapshot(persistenceId: String, criteria: SnapshotSelectionCriteria, toSequenceNr: Long): Unit
        Instructs the snapshot store to load the specified snapshot and send it via an SnapshotOffer to the running PersistentActor.
    def deleteSnapshot(sequenceNr: Long): Unit
        Deletes the snapshot identified by sequenceNr.
    def deleteSnapshots(criteria: SnapshotSelectionCriteria): Unit
        Deletes all snapshots matching criteria.
    def saveSnapshot(snapshot: Any): Unit
        Saves a snapshot of this snapshotter state.
        
    def persist[A](event: A)(handler: (A) => Unit): Unit
        Asynchronously persists event.
    def persistAll[A](events: Seq[A])(handler: (A) => Unit): Unit
        Asynchronously persists events in specified order.
    def persistAllAsync[A](events: Seq[A])(handler: (A) => Unit): Unit
        Asynchronously persists events in specified order.
    def persistAsync[A](event: A)(handler: (A) => Unit): Unit
        Asynchronously persists event.
        
    def postRestart(reason: Throwable): Unit
        User overridable callback: By default it calls preStart().
    def postStop(): Unit
        Overridden callback.
    def preRestart(reason: Throwable, message: Option[Any]): Unit
        Overridden callback.
    def preStart(): Unit
        User overridable callback.    
    def receive: Receive
        default implemented, donot override this 
        
    def recovery: Recovery
        Called when the persistent actor is started for the first time.
    def recoveryFinished: Boolean
        Returns true if this persistent actor has successfully finished recovery.
    def recoveryRunning: Boolean
        Returns true if this persistent actor is currently recovering.

    implicit final val self: ActorRef
        The 'self' field holds the ActorRef for this actor.
    final def sender(): ActorRef
        The reference sender Actor of the last received message.
        
    def stash(): Unit
        Adds the current message (the message that the actor received last) to the actor stash.
    def supervisorStrategy: SupervisorStrategy
        User overridable definition the strategy to use for supervising child actors.
    def unhandled(message: Any): Unit
        User overridable callback.
    def unstashAll(): Unit
        Prepends all messages in the stash to the mailbox, and then clears the stash.
        

//Identifiers - must not change across different actor incarnations
override def persistenceId = "my-stable-persistence-id"

//Recovery
//By default, a persistent actor is automatically recovered on start and on restart by replaying journaled messages. 
//New messages sent to a persistent actor during recovery are stashed 
//and received by a persistent actor after recovery phase completes.

//The number of concurrent recoveries 
akka.persistence.max-concurrent-recoveries = 50



//Storage plugins
//Storage backends for journals and snapshot stores are pluggable in the Akka persistence extension.

//Local snapshot store
//writes snapshot files to the local filesystem.
//application.conf 
akka.persistence.snapshot-store.plugin = "akka.persistence.snapshot-store.local"
akka.persistence.snapshot-store.local.dir = "target/example/snapshots"



//Example - The example defines two data types, Cmd and Evt to represent commands and events, 
//The state of the ExamplePersistentActor is a list of persisted event data contained in ExampleState.


//Events are persisted by calling persist with an event (or a sequence of events) as first argument and an event handler as second argument.


//#persistent-actor-example
import akka.actor._
import akka.persistence._

case class Cmd(data: String)
case class Evt(data: String)

case class ExampleState(events: List[String] = Nil) {
  def updated(evt: Evt): ExampleState = copy(evt.data :: events)
  def size: Int = events.length
  override def toString: String = events.reverse.toString
}

class ExamplePersistentActor extends PersistentActor {
  override def persistenceId = "sample-id-1"

  //Some state, which would be mutated and captures Actor state 
  var state = ExampleState()

  def updateState(event: Evt): Unit =  state = state.updated(event)

  def numEvents =  state.size

  val receiveRecover: Receive = {
    case SnapshotOffer(_, snapshot: ExampleState) => state = snapshot  //if snapshot is saved, we get this first
    //get the same type as 1st arg of persist , goal is to mutate state variable 
    case evt: Evt                                 => updateState(evt)  //then we get each event persisted earlier, one by one 
  }

  //Command handler main job is to convert Command to Event 
  //and persist the event by persist[A](event: A)(handler: (A) => Unit): Unit
  val receiveCommand: Receive = {
    case Cmd(data) =>
      //note handler gets the same type as 1st arg of persist , goal is to mutate state variable
      persist(Evt(s"${data}-${numEvents}"))(updateState)  //updatestate takes same Event, 1st arg of persist
      persist(Evt(s"${data}-${numEvents + 1}")) { event =>
        updateState(event)
        context.system.eventStream.publish(event)
      }
    case "snap"  => saveSnapshot(state)
    case "print" => println(state)
  }

}

object PersistentActorExample extends App {

  val system = ActorSystem("example")
  val persistentActor = system.actorOf(Props[ExamplePersistentActor], "persistentActor-4-scala")

  persistentActor ! Cmd("foo")
  persistentActor ! Cmd("baz")
  persistentActor ! Cmd("bar")
  persistentActor ! "snap"
  persistentActor ! Cmd("buzz")
  persistentActor ! "print"

  Thread.sleep(10000)
  system.terminate()
}

//2nd example of handling snapshot message 
import akka.actor._
import akka.persistence._

object SnapshotExample extends App {
  final case class ExampleState(received: List[String] = Nil) {
    def updated(s: String): ExampleState = copy(s :: received)
    override def toString = received.reverse.toString
  }

  class ExamplePersistentActor extends PersistentActor {
    def persistenceId: String = "sample-id-3"

    var state = ExampleState()

    def receiveCommand: Receive = {
      case "print"                               => println("current state = " + state)
      case "snap"                                => saveSnapshot(state)
      case SaveSnapshotSuccess(metadata)         => // ...
      case SaveSnapshotFailure(metadata, reason) => // ...
      case s: String =>
        persist(s) { evt => state = state.updated(evt) } //note handler gets the same type as 1st arg of persist , goal is to mutate state variable
    }

    def receiveRecover: Receive = {
      case SnapshotOffer(_, s: ExampleState) =>
        println("offered state = " + s)
        state = s
      case evt: String =>     //get the same type as 1st arg of persist , goal is to mutate state variable 
        state = state.updated(evt)
    }

  }

  val system = ActorSystem("example")
  val persistentActor = system.actorOf(Props(classOf[ExamplePersistentActor]), "persistentActor-3-scala")

  persistentActor ! "a"
  persistentActor ! "b"
  persistentActor ! "snap"
  persistentActor ! "c"
  persistentActor ! "d"
  persistentActor ! "print"

  Thread.sleep(10000)
  system.terminate()
}

//Failure exmple 
package sample.persistence

import akka.actor._
import akka.persistence._

object PersistentActorFailureExample extends App {
  class ExamplePersistentActor extends PersistentActor {
    override def persistenceId = "sample-id-2"

    var received: List[String] = Nil // state

    def receiveCommand: Receive = {
      case "print" => println(s"received ${received.reverse}")
      case "boom"  => throw new Exception("boom")
      case payload: String =>
        persist(payload) { p => received = p :: received }  //note handler gets the same type as 1st arg of persist , goal is to mutate state variable

    }

    def receiveRecover: Receive = {
      case s: String => received = s :: received  //get the same type as 1st arg of persist , goal is to mutate state variable 
    }
  }

  val system = ActorSystem("example")
  val persistentActor = system.actorOf(Props(classOf[ExamplePersistentActor]), "persistentActor-2")

  persistentActor ! "a"
  persistentActor ! "print"
  persistentActor ! "boom" // restart and recovery
  persistentActor ! "print"
  persistentActor ! "b"
  persistentActor ! "print"
  persistentActor ! "c"
  persistentActor ! "print"

  // Will print in a first run (i.e. with empty journal):

  // received List(a)
  // received List(a, b)
  // received List(a, b, c)

  // Will print in a second run:

  // received List(a, b, c, a)
  // received List(a, b, c, a, b)
  // received List(a, b, c, a, b, c)

  // etc ...

  Thread.sleep(10000)
  system.terminate()
}

//persistAsync is used for implementing high-throughput persistent actors. 
//It will not stash incoming Commands while the Journal is still working on persisting 
//and/or user code is executing event callbacks.

//In the below example, the event callbacks may be called �at any time�, 
//even after the next Command has been processed. 
//The ordering between events is still guaranteed (�evt-b-1� will be sent after �evt-a-2�, which will be sent after �evt-a-1� etc.).

class MyPersistentActor extends PersistentActor {

  override def persistenceId = "my-stable-persistence-id"

  override def receiveRecover: Receive = {
    case _ => // handle recovery here
  }

  override def receiveCommand: Receive = {
    case c: String => {
      sender() ! c
      persistAsync(s"evt-$c-1") { e => sender() ! e }
      persistAsync(s"evt-$c-2") { e => sender() ! e }
    }
  }
}

// usage
persistentActor ! "a"
persistentActor ! "b"

// possible order of received messages:
// a
// b
// evt-a-1
// evt-a-2
// evt-b-1
// evt-b-2


//Deferring actions until preceding persist handlers have executed - deferAsync
// to define some actions in terms of ��happens-after the previous persistAsync/persist handlers have been invoked��

//It is recommended to use it for read operations, 
//and actions which do not have corresponding events in your domain model.
//it does not persist the passed in event. 
//It will be kept in memory and used when invoking the handler

class MyPersistentActor extends PersistentActor {

  override def persistenceId = "my-stable-persistence-id"

  override def receiveRecover: Receive = {
    case _ => // handle recovery here
  }

  override def receiveCommand: Receive = {
    case c: String => {
      sender() ! c
      persistAsync(s"evt-$c-1") { e => sender() ! e }
      persistAsync(s"evt-$c-2") { e => sender() ! e }
      deferAsync(s"evt-$c-3") { e => sender() ! e }
    }
  }
  //call deferAsync with persist.
  override def receiveCommand: Receive = {
    case c: String => {
      sender() ! c
      persist(s"evt-$c-1") { e => sender() ! e }
      persist(s"evt-$c-2") { e => sender() ! e }
      deferAsync(s"evt-$c-3") { e => sender() ! e }
    }
}

//Usage 
persistentActor ! "a"
persistentActor ! "b"

// order of received messages:
// a
// b
// evt-a-1
// evt-a-2
// evt-a-3
// evt-b-1
// evt-b-2
// evt-b-3

//Nested persist 
override def receiveCommand: Receive = {
  case c: String =>
    sender() ! c

    persist(s"$c-1-outer") { outer1 =>
      sender() ! outer1
      persist(s"$c-1-inner") { inner1 =>
        sender() ! inner1
      }
    }

    persist(s"$c-2-outer") { outer2 =>
      sender() ! outer2
      persist(s"$c-2-inner") { inner2 =>
        sender() ! inner2
      }
    }
}

//Usage 
persistentActor ! "a"
persistentActor ! "b"

// order of received messages:
// a
// a-outer-1
// a-outer-2
// a-inner-1
// a-inner-2
// and only then process "b"
// b
// b-outer-1
// b-outer-2
// b-inner-1
// b-inner-2   



//to nest persistAsync calls, using the same pattern:
override def receiveCommand: Receive = {
  case c: String ?
    sender() ! c
    persistAsync(c + "-outer-1") { outer =>
      sender() ! outer
      persistAsync(c + "-inner-1") { inner => sender() ! inner }
    }
    persistAsync(c + "-outer-2") { outer =>
      sender() ! outer
      persistAsync(c + "-inner-2") { inner => sender() ! inner }
    }
}
//In this case no stashing is happening, 
//yet events are still persisted and callbacks are executed in the expected order:
persistentActor ! "a"
persistentActor ! "b"

// order of received messages:
// a
// b
// a-outer-1
// a-outer-2
// b-outer-1
// b-outer-2
// a-inner-1
// a-inner-2
// b-inner-1
// b-inner-2

// which can be seen as the following causal relationship:
// a -> a-outer-1 -> a-outer-2 -> a-inner-1 -> a-inner-2
// b -> b-outer-1 -> b-outer-2 -> b-inner-1 -> b-inner-2







//Check other informations eg persistance FSM, shared Local DB etc 
//https://doc.akka.io/docs/akka/2.5/persistence.htm

 



///*** Actor - Cluster 
//Akka Cluster provides a fault-tolerant decentralized peer-to-peer 
//based cluster membership service with no single point of failure or single point of bottleneck. 
//It does this using gossip protocols and an automatic failure detector.

node
    A logical member of a cluster. 
    There could be multiple nodes on a physical machine. 
    Defined by a hostname:port:uid tuple.
cluster
    A set of nodes joined together through the membership service.
leader
    A single node in the cluster that acts as the leader. 
    Managing cluster convergence and membership state transitions. 
Gossip Protocol(based on Amazon�s Dynamo system)
    where the current state of the cluster is gossiped randomly through the cluster, 
    with preference to members that have not seen the latest version.
Seed Nodes
    The seed nodes are configured contact points for new nodes joining the cluster. 
    When a new node is started it sends a message to all seed nodes 
    and then sends a join command to the seed node that answers first.

    
//build.sbt 
libraryDependencies += "com.typesafe.akka" %% "akka-cluster" % "2.5.11"

//*Reference 
class akk.cluster.Member extends Serializable
    def address: Address
    def copy(status: MemberStatus): Member
    def copyUp(upNumber: Int): Member
    lazy val dataCenter: DataCenter
    def hasRole(role: String): Boolean
    def hashCode(): Int
    def isOlderThan(other: Member): Boolean
    Is this member older, has been part of cluster longer, than another member.
    val roles: Set[String]
    val status: MemberStatus
    def toString(): String
    val uniqueAddress: UniqueAddress 
final case class Address extends Product with Serializable 
    new Address(protocol: String, system: String, host: String, port: Int)
    new Address(protocol: String, system: String) 
sealed abstract class MemberStatus extends AnyRef
    Defines the current status of a cluster member node
    Can be one of(subclasses): Joining, WeaklyUp, Up, Leaving, Exiting and Down and Removed. 
class Cluster extends Extension
    This module is responsible cluster membership information. 
    Changes to the cluster information is retrieved through #subscribe. 
    Commands to operate the cluster is available through methods in this class, 
    such as #join, #down and #leave.
    Each cluster Member is identified by its akka.actor.Address, 
    and the cluster address of this actor system is #selfAddress. 
    A member also has a status; initially MemberStatus Joining followed by MemberStatus Up. 
    //methods 
    new Cluster(system: ExtendedActorSystem) 
    val crossDcFailureDetector: FailureDetectorRegistry[Address]
    def down(address: Address): Unit
        Send command to DOWN the node specified by 'address'.
    lazy val downingProvider: DowningProvider
    val failureDetector: FailureDetectorRegistry[Address]
    def isTerminated: Boolean
        Returns true if this cluster instance has be shutdown.
    def join(address: Address): Unit
        Try to join this cluster node with the node specified by 'address'.
    def joinSeedNodes(seedNodes: Seq[Address]): Unit
        Join the specified seed nodes without defining them in config.
    def leave(address: Address): Unit
        Send command to issue state transition to LEAVING for the node specified by 'address'.
    def registerOnMemberRemoved[T](code: => T): Unit
        The supplied thunk will be run, once, when current cluster member is Removed.
    def registerOnMemberUp[T](code: => T): Unit
        The supplied thunk will be run, once, when current cluster member is Up.
    def remotePathOf(actorRef: ActorRef): ActorPath
        Generate the remote actor path by replacing the Address in the RootActor Path for the given ActorRef with the cluster's selfAddress, unless address' host is already defined
    def selfAddress: Address
        The address of this cluster member.
    def selfDataCenter: DataCenter
        Data center to which this node belongs to (defaults to "default" if not configured explicitly)
    def selfMember: Member
        Current snapshot of the member itself
    def selfRoles: Set[String]
        roles that this member has
    val selfUniqueAddress: UniqueAddress
        The address including a uid of this cluster member.
    def sendCurrentClusterState(receiver: ActorRef): Unit
        Send current (full) state of the cluster to the specified receiver.
    val settings: ClusterSettings
        def state: CurrentClusterState
    Current snapshot state of the cluster.
    def subscribe(subscriber: ActorRef, initialStateMode: SubscriptionInitialStateMode, to: Class[_]*): Unit
        Subscribe to one or more cluster domain events.
    def subscribe(subscriber: ActorRef, to: Class[_]*): Unit
        Subscribe to one or more cluster domain events.
    val system: ExtendedActorSystem
    def unsubscribe(subscriber: ActorRef, to: Class[_]): Unit
        Unsubscribe to a specific type of cluster domain events, matching previous subscribe registration.
    def unsubscribe(subscriber: ActorRef): Unit
        Unsubscribe to all cluster domain events.
object akka.cluster.ClusterEvent
    Domain events published to the event bus. Subscribe with:
    Cluster(system).subscribe(actorRef, classOf[ClusterDomainEvent])
    //Type Members
    trait ClusterDomainEvent
        Marker interface for cluster domain events.
    final class CurrentClusterState
        Current snapshot state of the cluster.
    sealed trait DataCenterReachabilityEvent
        Marker interface to facilitate subscription of both UnreachableDataCenter and ReachableDataCenter.
    final case class LeaderChanged(leader: Option[Address])
        Leader of the cluster data center of this node changed.
    sealed trait MemberEvent
        Marker interface for all membership events.
    final case class MemberExited(member: Member)
        Member status changed to MemberStatus.Exiting and will be removed when all members have seen the Exiting status.
    final case class MemberJoined(member: Member)
        Member status changed to Joining.
    final case class MemberLeft(member: Member)
        Member status changed to Leaving.
    final case class MemberRemoved(member: Member, previousStatus: MemberStatus)
        Member completely removed from the cluster.
    final case class MemberUp(member: Member)
        Member status changed to Up.
    final case class MemberWeaklyUp(member: Member)
        Member status changed to WeaklyUp.
    sealed trait ReachabilityEvent
        Marker interface to facilitate subscription of both UnreachableMember and ReachableMember.
    final case class ReachableDataCenter(dataCenter: DataCenter)
        A data center is considered reachable when all members from the data center are reachable
    final case class ReachableMember(member: Member)
        A member is considered as reachable by the failure detector after having been unreachable.
    final case class RoleLeaderChanged(role: String, leader: Option[Address])
        First member (leader) of the members within a role set 
        (in the same data center as this node, if data centers are used) changed.
    sealed abstract class SubscriptionInitialStateMode
    final case class UnreachableDataCenter(dataCenter: DataCenter)
        A data center is considered as unreachable when any members 
        from the data center are unreachable
    final case class UnreachableMember(member: Member)
        A member is considered as unreachable by the failure detector.
    object ClusterShuttingDown extends ClusterDomainEvent with Product with Serializable
        This event is published when the cluster node is shutting down, 
        before the final MemberRemoved events are published.
    object CurrentClusterState extends AbstractFunction5[SortedSet[Member], Set[Member], Set[Address], Option[Address], Map[String, Option[Address]], CurrentClusterState] with Serializable
    object InitialStateAsEvents extends SubscriptionInitialStateMode with Product with Serializable
        When using this subscription mode the events corresponding 
        to the current state will be sent to the subscriber to mimic 
        what you would have seen if you were listening to the events 
        when they occurred in the past.
    object InitialStateAsSnapshot extends SubscriptionInitialStateMode with Product with Serializable
        When using this subscription mode a snapshot of akka.cluster.ClusterEvent.CurrentClusterState 
        will be sent to the subscriber as the first message.
    

//A Simple Cluster Example
//The following configuration enables the Cluster extension to be used. 
//It joins the cluster and an actor subscribes to cluster membership events and logs them.

//application.conf 
akka {
  actor {
    provider = cluster
  }
  remote {
    netty.tcp {
      hostname = "127.0.0.1"
      port = 0
    }
    artery {
      enabled = on
      canonical.hostname = "127.0.0.1"
      canonical.port = 0
    }
  }

  cluster {
    seed-nodes = [
      "akka://ClusterSystem@127.0.0.1:2551",
      "akka://ClusterSystem@127.0.0.1:2552"]

    # auto downing is NOT safe for production deployments.
    # you may want to use it during development, read more about it in the docs.
    auto-down-unreachable-after = 10s
  }
}

# Enable metrics extension in akka-cluster-metrics.
akka.extensions=["akka.cluster.metrics.ClusterMetricsExtension"]

# Sigar native library extract location during tests.
# Note: use per-jvm-instance folder when running multiple jvm on one host.
akka.cluster.metrics.native-library-extract-folder=${user.dir}/target/native


//code for cluster mgmt event listeners 
//To run this sample, type 
sbt "runMain sample.cluster.simple.SimpleClusterApp" 
//`SimpleClusterApp` starts three actor systems (cluster members) in the same JVM process. 
//OR to run them in separate processes. 
//Stop the application and then open three terminal windows.
//In the first terminal window, start the first seed node with the following command:
    sbt "runMain sample.cluster.simple.SimpleClusterApp 2551"
//2551 corresponds to the port of the first seed-nodes element in the configuration. In the log output you see that the cluster node has been started and changed status to 'Up'.

//In the second terminal window, start the second seed node with the following command:
    sbt "runMain sample.cluster.simple.SimpleClusterApp 2552"
//2552 corresponds to the port of the second seed-nodes element in the configuration. In the log output you see that the cluster node has been started and joins the other seed node and becomes a member of the cluster. Its status changed to 'Up'.

//Switch over to the first terminal window and see in the log output that the member joined.

//Start another node in the third terminal window with the following command:
    sbt "runMain sample.cluster.simple.SimpleClusterApp 0"
//Now you don't need to specify the port number, 0 means that it will use a random available port. 
//It joins one of the configured seed nodes. 
//Look at the log output in the different terminal windows.

//code 
package scala.docs.cluster

import akka.cluster.Cluster
import akka.cluster.ClusterEvent._
import akka.actor.ActorLogging
import akka.actor.Actor

class SimpleClusterListener extends Actor with ActorLogging {

  val cluster = Cluster(context.system)

  // subscribe to cluster changes, re-subscribe when restart
  override def preStart(): Unit = {
    cluster.subscribe(self, initialStateMode = InitialStateAsEvents,
      classOf[MemberEvent], classOf[UnreachableMember])
  }
  override def postStop(): Unit = cluster.unsubscribe(self)

  def receive = {
    case MemberUp(member) =>
      log.info("Member is Up: {}", member.address)
    case UnreachableMember(member) =>
      log.info("Member detected as unreachable: {}", member)
    case MemberRemoved(member, previousStatus) =>
      log.info(
        "Member is Removed: {} after {}",
        member.address, previousStatus)
    case _: MemberEvent => // ignore
  }
}
//Usage 
import com.typesafe.config.ConfigFactory
import akka.actor.ActorSystem
import akka.actor.Props

object SimpleClusterApp {
  def main(args: Array[String]): Unit = {
    if (args.isEmpty)
      startup(Seq("2551", "2552", "0"))
    else
      startup(args)
  }

  def startup(ports: Seq[String]): Unit = {
    ports foreach { port =>
      // Override the configuration of the port
      val config = ConfigFactory.parseString(s"""
        akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """).withFallback(ConfigFactory.load())

      // Create an Akka system
      val system = ActorSystem("ClusterSystem", config)
      // Create an actor that handles cluster domain events
      system.actorOf(Props[SimpleClusterListener], name = "clusterListener")
    }
  }

}


//Node Roles
//Not all nodes of a cluster need to perform the same function
//The roles of a node is defined in the configuration property named akka.cluster.roles
//The roles of the nodes is part of the membership information in MemberEvent 


//Cluster Aware Routers
//All routers can be made aware of member nodes in the cluster, 
//i.e. deploying new routees or looking up routees on nodes in the cluster

//To run this sample, type 
sbt "runMain sample.cluster.stats.StatsSample"
//StatsSample starts 4 actor systems (cluster members) in the same JVM process. 
//OR to run them in separate processes. Stop the application 
//and run the following commands in separate terminal windows.
sbt "runMain sample.cluster.stats.StatsSample 2551"
sbt "runMain sample.cluster.stats.StatsSample 2552"
sbt "runMain sample.cluster.stats.StatsSampleClient"
sbt "runMain sample.cluster.stats.StatsSample 0"
    

//stats1/conf 
include "application"

akka.actor.deployment {
  /statsService/workerRouter {
    router = consistent-hashing-group
    routees.paths = ["/user/statsWorker"]
    cluster {
      enabled = on
      allow-local-routees = on
      use-role = compute
    }
  }
}
//The same type of router could also have been defined in code
import akka.cluster.routing.{ ClusterRouterGroup, ClusterRouterGroupSettings }
import akka.routing.ConsistentHashingGroup

val workerRouter = context.actorOf(
  ClusterRouterGroup(ConsistentHashingGroup(Nil), ClusterRouterGroupSettings(
    totalInstances = 100, routeesPaths = List("/user/statsWorker"),
    allowLocalRoutees = true, useRoles = Set("compute"))).props(),
  name = "workerRouter2")


//Actor messages 
final case class StatsJob(text: String)
final case class StatsResult(meanWordLength: Double)
final case class JobFailed(reason: String)

//Worker Actor
//The worker that counts number of characters in each word:
import akka.actor.Actor

//#worker
class StatsWorker extends Actor {
  var cache = Map.empty[String, Int]
  def receive = {
    case word: String =>
      val length = cache.get(word) match {
        case Some(x) => x
        case None =>
          val x = word.length
          cache += (word -> x)
          x
      }

      sender() ! length
  }
}
//#worker

//The service that receives text from users and splits it up into words, 
//delegates to workers and aggregates:
import scala.concurrent.duration._
import akka.actor.Actor
import akka.actor.ActorRef
import akka.actor.Props
import akka.actor.ReceiveTimeout
import akka.routing.ConsistentHashingRouter.ConsistentHashableEnvelope
import akka.routing.FromConfig

//#service
class StatsService extends Actor {
  // This router is used both with lookup and deploy of routees. If you
  // have a router with only lookup of routees you can use Props.empty
  // instead of Props[StatsWorker.class].
  val workerRouter = context.actorOf(FromConfig.props(Props[StatsWorker]),
    name = "workerRouter")

  def receive = {
    case StatsJob(text) if text != "" =>
      val words = text.split(" ")
      val replyTo = sender() // important to not close over sender()
      // create actor that collects replies from workers
      val aggregator = context.actorOf(Props(
        classOf[StatsAggregator], words.size, replyTo))
      words foreach { word =>
        workerRouter.tell(
          ConsistentHashableEnvelope(word, word), aggregator)
      }
  }
}

class StatsAggregator(expectedResults: Int, replyTo: ActorRef) extends Actor {
  var results = IndexedSeq.empty[Int]
  context.setReceiveTimeout(3.seconds)

  def receive = {
    case wordCount: Int =>
      results = results :+ wordCount
      if (results.size == expectedResults) {
        val meanWordLength = results.sum.toDouble / results.size
        replyTo ! StatsResult(meanWordLength)
        context.stop(self)
      }
    case ReceiveTimeout =>
      replyTo ! JobFailed("Service unavailable, try again later")
      context.stop(self)
  }
}
//#service


//Usages 
//All nodes start StatsService and StatsWorker actors. 
//Remember, routees are the workers in this case. 
//The router is configured with routees.paths

import scala.concurrent.duration._
import java.util.concurrent.ThreadLocalRandom
import com.typesafe.config.ConfigFactory
import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Address
import akka.actor.PoisonPill
import akka.actor.Props
import akka.actor.RelativeActorPath
import akka.actor.RootActorPath
import akka.cluster.Cluster
import akka.cluster.ClusterEvent._
import akka.cluster.MemberStatus

object StatsSample {
  def main(args: Array[String]): Unit = {
    if (args.isEmpty) {
      startup(Seq("2551", "2552", "0"))
      StatsSampleClient.main(Array.empty)
    } else {
      startup(args)
    }
  }

  def startup(ports: Seq[String]): Unit = {
    ports foreach { port =>
      // Override the configuration of the port when specified as program argument
      val config = ConfigFactory.parseString(s"""
        akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
        .withFallback(
          ConfigFactory.parseString("akka.cluster.roles = [compute]")).
          withFallback(ConfigFactory.load("stats1"))

      val system = ActorSystem("ClusterSystem", config)

      system.actorOf(Props[StatsWorker], name = "statsWorker")
      system.actorOf(Props[StatsService], name = "statsService")
    }
  }
}

object StatsSampleClient {
  def main(args: Array[String]): Unit = {
    // note that client is not a compute node, role not defined
    val system = ActorSystem("ClusterSystem")
    system.actorOf(Props(classOf[StatsSampleClient], "/user/statsService"), "client")
  }
}

class StatsSampleClient(servicePath: String) extends Actor {
  val cluster = Cluster(context.system)
  val servicePathElements = servicePath match {
    case RelativeActorPath(elements) => elements
    case _ => throw new IllegalArgumentException(
      "servicePath [%s] is not a valid relative actor path" format servicePath)
  }
  import context.dispatcher
  val tickTask = context.system.scheduler.schedule(2.seconds, 2.seconds, self, "tick")

  var nodes = Set.empty[Address]

  override def preStart(): Unit = {
    cluster.subscribe(self, classOf[MemberEvent], classOf[ReachabilityEvent])
  }
  override def postStop(): Unit = {
    cluster.unsubscribe(self)
    tickTask.cancel()
  }

  def receive = {
    case "tick" if nodes.nonEmpty =>
      // just pick any one
      val address = nodes.toIndexedSeq(ThreadLocalRandom.current.nextInt(nodes.size))
      val service = context.actorSelection(RootActorPath(address) / servicePathElements)
      service ! StatsJob("this is the text that will be analyzed")
    case result: StatsResult =>
      println(result)
    case failed: JobFailed =>
      println(failed)
    case state: CurrentClusterState =>
      nodes = state.members.collect {
        case m if m.hasRole("compute") && m.status == MemberStatus.Up => m.address
      }
    case MemberUp(m) if m.hasRole("compute")        => nodes += m.address
    case other: MemberEvent                         => nodes -= other.member.address
    case UnreachableMember(m)                       => nodes -= m.address
    case ReachableMember(m) if m.hasRole("compute") => nodes += m.address
  }

}






///*** Actor - Cluster - akka.cluster.pubsub.DistributedPubSubMediator
//for communicating to an actor from within clusters
//Used for 
1. send a message to an actor without knowing which node it is running on
2.send messages to all actors in the cluster that have registered interest in a named topic

//Reference 
akka.cluster.pubsub.DistributedPubSub
    new DistributedPubSub(system: ExtendedActorSystem) 
    def isTerminated: Boolean
        Returns true if this member is not tagged with the role configured for the mediator.
    val mediator: ActorRef
        The DistributedPubSubMediator
class DistributedPubSubMediator extends Actor with ActorLogging with PerGroupingBuffer 
    type Receive = PartialFunction[Any, Unit] 
    def bufferOr(grouping: String, message: Any, originalSender: ActorRef)(action: ? Unit): Unit
    val cluster: Cluster
    def collectDelta(otherVersions: Map[Address, Long]): Iterable[Bucket]
    implicit val context: ActorContext
        Stores the context for this actor, including self, and sender.
    var deltaCount: Long
    def forwardMessages(grouping: String, recipient: ActorRef): Unit
    def getCurrentTopics(): Set[String]
    def gossip(): Unit
        Gossip to peer nodes.
    val gossipTask: Cancellable
    def gossipTo(address: Address): Unit
    def initializeGrouping(grouping: String): Unit
    def log: LoggingAdapter
    def matchingRole(m: Member): Boolean
    def mkKey(path: ActorPath): String
    def mkKey(ref: ActorRef): String
    def myVersions: Map[Address, Long]
    def newTopicActor(encTopic: String): ActorRef
    val nextVersion: () ? Long
    var nodes: Set[Address]
    def otherHasNewerVersions(otherVersions: Map[Address, Long]): Boolean
    def postRestart(reason: Throwable): Unit
    User overridable callback: By default it calls preStart().
    def postStop(): Unit
        User overridable callback.
    def preRestart(reason: Throwable, message: Option[Any]): Unit
        User overridable callback: By default it disposes of all children and then calls postStop().
    def preStart(): Unit
        User overridable callback.
    def prune(): Unit
    val pruneInterval: FiniteDuration
    val pruneTask: Cancellable
    def receive: PartialFunction[Any, Unit]
        This defines the initial actor behavior, it must return a partial function with the actor logic.
    val removedTimeToLiveMillis: Long
    def selectRandomNode(addresses: IndexedSeq[Address]): Option[Address]
    implicit final val self: ActorRef
        The 'self' field holds the ActorRef for this actor.
    final def sender(): ActorRef
        The reference sender Actor of the last received message.
    def supervisorStrategy: SupervisorStrategy
        User overridable definition the strategy to use for supervising child actors.
    def unhandled(message: Any): Unit
        User overridable callback.
     
    def recreateAndForwardMessagesIfNeeded(grouping: String, recipient: ? ActorRef): Unit
    def registerTopic(ref: ActorRef): Unit
    var registry: Map[Address, Bucket]
    def publish(path: String, msg: Any, allButSelf: Boolean = false): Unit
    def publishToEachGroup(path: String, msg: Any): Unit
    def put(key: String, valueOption: Option[ActorRef]): Unit

object akka.cluster.pubsub.DistributedPubSubMediator
    final case class CountSubscribers(topic: String)
    final case class CurrentTopics(topics: Set[String])
        Reply to GetTopics.
    sealed abstract class GetTopics
    final case class Publish(topic: String, msg: Any, sendOneMessageToEachGroup: Boolean)
    final case class Put(ref: ActorRef)
    final case class Remove(path: String)
    final case class Send(path: String, msg: Any, localAffinity: Boolean)
    final case class SendToAll(path: String, msg: Any, allButSelf: Boolean = false)
    final case class Subscribe(topic: String, group: Option[String], ref: ActorRef)
    final case class SubscribeAck(subscribe: Subscribe)
    final case class Unsubscribe(topic: String, group: Option[String], ref: ActorRef)
    final case class UnsubscribeAck(unsubscribe: Unsubscribe) 

    def props(settings: DistributedPubSubSettings): Props
        Factory method for DistributedPubSubMediator akka.actor.Props.
    object Count extends Product with Serializable
    object GetTopics extends GetTopics with Product with Serializable
        Send this message to the mediator and it will reply with 
        CurrentTopics containing the names of the (currently known) registered topic names.
    object Publish extends Serializable
    object Subscribe extends Serializable
    object Unsubscribe extends Serializable

//Publish proptocol 
//Actors are registered to a named topic. 
//This enables many subscribers on each node. 
//The message will be delivered to all subscribers of the topic.

//register actors to the local mediator with DistributedPubSubMediator.Subscribe. 
//Actors are automatically removed from the registry when they are terminated, 
//or explicitly remove entries with DistributedPubSubMediator.Unsubscribe.

//Successful Subscribe and Unsubscribe is acknowledged with 
//DistributedPubSubMediator.SubscribeAck and DistributedPubSubMediator.UnsubscribeAck replies. 

class Subscriber extends Actor with ActorLogging {
  import DistributedPubSubMediator.{ Subscribe, SubscribeAck }
  val mediator = DistributedPubSub(context.system).mediator
  // subscribe to the topic named "content"
  mediator ! Subscribe("content", self)

  def receive = {
    case s: String =>
      log.info("Got {}", s)
    case SubscribeAck(Subscribe("content", None, `self`)) =>
      log.info("subscribing")
  }
}

//Subscriber actors can be started on several nodes in the cluster, 
//and all will receive messages published to the �content� topic
//runOn(first) {
  system.actorOf(Props[Subscriber], "subscriber1")
//}
//runOn(second) {
  system.actorOf(Props[Subscriber], "subscriber2")
  system.actorOf(Props[Subscriber], "subscriber3")
//}

//publish messages by sending DistributedPubSubMediator.Publish message to the local mediator.
class Publisher extends Actor {
  import DistributedPubSubMediator.Publish
  // activate the extension
  val mediator = DistributedPubSub(context.system).mediator

  def receive = {
    case in: String =>
      val out = in.toUpperCase
      mediator ! Publish("content", out)
  }
}

//publish messages to the topic from anywhere in the cluster:
//runOn(third) {
val publisher = system.actorOf(Props[Publisher], "publisher")

// after a while the subscriptions are replicated
publisher ! "hello"
//}




//Send Proptocol 
//This is a point-to-point mode where each message is delivered to one destination,

//register actors to the local mediator with DistributedPubSubMediator.Put. 
//The ActorRef in Put must belong to the same local actor system as the mediator. 
//The path without address information is the key to which you send messages. 

//Actors are automatically removed from the registry when they are terminated, 
//or explicitly remove entries with DistributedPubSubMediator.Remove.

class Destination extends Actor with ActorLogging {
  import DistributedPubSubMediator.Put
  val mediator = DistributedPubSub(context.system).mediator
  // register to the path
  mediator ! Put(self)

  def receive = {
    case s: String ?
      log.info("Got {}", s)
  }
}

//Destination actors can be started on several nodes in the cluster, 
//and all will receive messages sent to the path (without address information).
//runOn(first) {
  system.actorOf(Props[Destination], "destination")
//}
//runOn(second) {
  system.actorOf(Props[Destination], "destination")
//}


//send messages by sending DistributedPubSubMediator.Send message to the local mediator 
//with the path (without address information) of the destination actors.

//OR, Send DistributedPubSubMediator.SendToAll message to the local mediator 
//and the wrapped message will then be delivered to all recipients with a matching path.
class Sender extends Actor {
  import DistributedPubSubMediator.Send
  // activate the extension
  val mediator = DistributedPubSub(context.system).mediator

  def receive = {
    case in: String ?
      val out = in.toUpperCase
      mediator ! Send(path = "/user/destination", msg = out, localAffinity = true)
  }
}

//Create Sender actor  from anywhere in the cluster:
//runOn(third) {
  val sender = system.actorOf(Props[Sender], "sender")
  // after a while the destinations are replicated
  sender ! "hello"
//}


//Publish - Topic Groups
//Actors may also be subscribed to a named topic with a group id by Subscribe , group: Option[String]
//each message published to a topic with Publish ,sendOneMessageToEachGroup=true is delivered to one actor within each subscribing group.

//If all the subscribed actors have the same group id, 
//then this works just like Send and each message is only delivered to one subscriber.

//If all the subscribed actors have different group id, 
//then this works like normal Publish and each message is broadcasted to all subscribers.

//Messages published with sendOneMessageToEachGroup=false will not be delivered 
//to subscribers that subscribed with a group id. 

//Messages published with sendOneMessageToEachGroup=true will not be delivered 
//to subscribers that subscribed without a group id.





///*** Actor - Cluster - ClusterClient
//To communicate with actors(destination actor) somewhere in the cluster from outside of cluster(called client)
//Note use akka.cluster.pubsub.DistributedPubSubMediator for communicating to an actor from within clusters

//Client needs to know the location of one (or more) nodes to use as initial contact points. 
//Client will establish a connection to a ClusterReceptionist somewhere in the cluster. 

//application.conf 
akka.actor.provider = "cluster"
akka.extensions = ["akka.cluster.client.ClusterClientReceptionist"]

//build.sbt
"com.typesafe.akka" %% "akka-cluster-tools" % "2.5.11"


//*Reference 
akka.cluster.client.ClusterClientReceptionist extends Extension
    new ClusterClientReceptionist(system: ExtendedActorSystem) 
    def isTerminated: Boolean
        Returns true if this member is not tagged with the role configured for the receptionist.
    def registerService(actor: ActorRef): Unit
        Register an actor that should be reachable for the clients.
    def registerSubscriber(topic: String, actor: ActorRef): Unit
        Register an actor that should be reachable for the clients to a named topic.
    def underlying: ActorRef
        Returns the underlying receptionist actor, 
        particularly so that its events can be observed via subscribe/unsubscribe.
    def unregisterService(actor: ActorRef): Unit
        A registered actor will be automatically unregistered when terminated, but it can also be explicitly unregistered before termination.
    def unregisterSubscriber(topic: String, actor: ActorRef): Unit
        A registered subscriber will be automatically unregistered when terminated, but it can also be explicitly unregistered before termination.

akka.cluster.client.ClusterClient extends Actor with ActorLogging 
    new ClusterClient(settings: ClusterClientSettings) 
    type Receive = PartialFunction[Any, Unit] 
    
    def active(receptionist: ActorRef): actor.Actor.Receive
    def buffer(msg: Any): Unit
    var buffer: MessageBuffer
    var contactPaths: HashSet[ActorPath]
    var contactPathsPublished: HashSet[ActorPath]
    def contactPointMessages: actor.Actor.Receive
    var contacts: HashSet[ActorSelection]
    implicit val context: ActorContext
        stores the context for this actor, including self, and sender.
    def establishing: actor.Actor.Receive
    val failureDetector: DeadlineFailureDetector
    val heartbeatTask: Cancellable
    val initialContactsSel: HashSet[ActorSelection]
    def log: LoggingAdapter
    
    def postRestart(reason: Throwable): Unit
        User overridable callback: By default it calls preStart().
    def postStop(): Unit
        User overridable callback.
    def preRestart(reason: Throwable, message: Option[Any]): Unit
        User overridable callback: By default it disposes of all children and then calls postStop().
    def preStart(): Unit
        User overridable callback.
    def publishContactPoints(): Unit
    def receive: PartialFunction[Any, Unit]
        This defines the initial actor behavior, it must return a partial function with the actor logic.
    
    def reestablish(): Unit
    var refreshContactsTask: Option[Cancellable]
    def scheduleRefreshContactsTick(interval: FiniteDuration): Unit
    implicit final val self: ActorRef
        The 'self' field holds the ActorRef for this actor.
    def sendBuffered(receptionist: ActorRef): Unit
    def sendGetContacts(): Unit
    final def sender(): ActorRef
        The reference sender Actor of the last received message.
    var subscribers: Vector[ActorRef]
    def supervisorStrategy: SupervisorStrategy
        User overridable definition the strategy to use for supervising child actors.
    def unhandled(message: Any): Unit
        User overridable callback.
object akka.cluster.client.ClusterClient
    final case class Publish(topic: String, msg: Any)
    final case class Send(path: String, msg: Any, localAffinity: Boolean)
    final case class SendToAll(path: String, msg: Any) 

    def props(settings: ClusterClientSettings): Props
        Factory method for ClusterClient akka.actor.Props.


//The receptionist is  started on all nodes, or all nodes with specified role, in the cluster.

//Register the actors(destination actors) that should be available for the client(outside cluster)
//runOn(host1) {
  val serviceA = system.actorOf(Props[Service], "serviceA")
  ClusterClientReceptionist(system).registerService(serviceA)
//}
//runOn(host2, host3) {
  val serviceB = system.actorOf(Props[Service], "serviceB")
  ClusterClientReceptionist(system).registerService(serviceB)
//}
    

//Client send messages via the ClusterClient to destination actors in the cluster ,that is registered to ClusterReceptionist
ClusterClient.Send
    The message will be delivered to one recipient with a matching path, if any such exists. 
    If several entries match the path the message will be delivered to one random destination. 
ClusterClient.SendToAll
    The message will be delivered to all recipients with a matching path.
ClusterClient.Publish
    The message will be delivered to all recipients Actors 
    that have been registered as subscribers to the named topic.
    
//code 
//note ../system/receptionist comes from configuration (check below)
//runOn(client) {
  val initialContacts = Set( ActorPath.fromString("akka.tcp://OtherSys@host1:2552/system/receptionist"),
  ActorPath.fromString("akka.tcp://OtherSys@host2:2552/system/receptionist"))
  val c = system.actorOf(ClusterClient.props(
    ClusterClientSettings(system).withInitialContacts(initialContacts)), "client")
  c ! ClusterClient.Send("/user/serviceA", "hello", localAffinity = true)
  c ! ClusterClient.SendToAll("/user/serviceB", "hi")
}


//Response messages from the destination actor are tunneled via the receptionist 
�sender() as seen by the destination actor, is not the client itself, but the receptionist
�sender() of the response messages, sent back from the destination and seen by the client, is deadLetters

//since the client should normally send subsequent messages via the ClusterClient 
//It is possible to pass the original sender inside the reply messages 
//if the client is supposed to communicate directly to the actor in the cluster.



 

//default Configuration for ClusterClientReceptionist and ClusterClient
# default Settings for the ClusterClientReceptionist extension
akka.cluster.client.receptionist {
  # Actor name of the ClusterReceptionist actor, /system/receptionist
  name = receptionist

  # Start the receptionist on members tagged with this role.
  # All members are used if undefined or empty.
  role = ""

  # The receptionist will send this number of contact points to the client
  number-of-contacts = 3

  # The actor that tunnel response messages to the client will be stopped
  # after this time of inactivity.
  response-tunnel-receive-timeout = 30s
  
  # The id of the dispatcher to use for ClusterReceptionist actors. 
  # If not specified default dispatcher is used.
  # If specified you need to define the settings of the actual dispatcher.
  use-dispatcher = ""

  # How often failure detection heartbeat messages should be received for
  # each ClusterClient
  heartbeat-interval = 2s

  # Number of potentially lost/delayed heartbeats that will be
  # accepted before considering it to be an anomaly.
  # The ClusterReceptionist is using the akka.remote.DeadlineFailureDetector, which
  # will trigger if there are no heartbeats within the duration
  # heartbeat-interval + acceptable-heartbeat-pause, i.e. 15 seconds with
  # the default settings.
  acceptable-heartbeat-pause = 13s

  # Failure detection checking interval for checking all ClusterClients
  failure-detection-interval = 2s
}

# default Settings for the ClusterClient
akka.cluster.client {
  # Actor paths of the ClusterReceptionist actors on the servers (cluster nodes)
  # that the client will try to contact initially. It is mandatory to specify
  # at least one initial contact. 
  # Comma separated full actor paths defined by a string on the form of
  # "akka.tcp://system@hostname:port/system/receptionist"
  initial-contacts = []
  
  # Interval at which the client retries to establish contact with one of 
  # ClusterReceptionist on the servers (cluster nodes)
  establishing-get-contacts-interval = 3s
  
  # Interval at which the client will ask the ClusterReceptionist for
  # new contact points to be used for next reconnect.
  refresh-contacts-interval = 60s
  
  # How often failure detection heartbeat messages should be sent
  heartbeat-interval = 2s
  
  # Number of potentially lost/delayed heartbeats that will be
  # accepted before considering it to be an anomaly.
  # The ClusterClient is using the akka.remote.DeadlineFailureDetector, which
  # will trigger if there are no heartbeats within the duration 
  # heartbeat-interval + acceptable-heartbeat-pause, i.e. 15 seconds with
  # the default settings.
  acceptable-heartbeat-pause = 13s
  
  # If connection to the receptionist is not established the client will buffer
  # this number of messages and deliver them the connection is established.
  # When the buffer is full old messages will be dropped when new messages are sent
  # via the client. Use 0 to disable buffering, i.e. messages will be dropped
  # immediately if the location of the singleton is unknown.
  # Maximum allowed buffer size is 10000.
  buffer-size = 1000

  # If connection to the receiptionist is lost and the client has not been
  # able to acquire a new connection for this long the client will stop itself.
  # This duration makes it possible to watch the cluster client and react on a more permanent
  # loss of connection with the cluster, for example by accessing some kind of
  # service registry for an updated set of initial contacts to start a new cluster client with.
  # If this is not wanted it can be set to "off" to disable the timeout and retry
  # forever.
  reconnect-timeout = off
}




///*** Using Akka HTTP
//build.sbt 
"com.typesafe.akka" %% "akka-http"   % "10.1.0" 
"com.typesafe.akka" %% "akka-stream" % "2.5.11" // or whatever the latest version is
"com.typesafe.akka" %% "akka-http-spray-json" % "10.1.0"
//with Giter8 template 
$ sbt -Dsbt.version=1.1.1 new https://github.com/akka/akka-http-scala-seed.g8


///* Http server based on Flow, Flow[HttpRequest, HttpResponse, Any]
//A Flow is a set of stream processing steps that has one open input and one open output. 
final class akka.stream.scaladsl.Flow[-In, +Out, +Mat] 
            extends FlowOpsMat[Out, Mat] with Graph[FlowShape[In, Out], Mat] 
    A Flow is a set of stream processing steps that has one open input and one open output. 
final class Source[+Out, +Mat] extends FlowOpsMat[Out, Mat] with Graph[SourceShape[Out], Mat]
    A Source is a set of stream processing steps that has one open output. 
    It can comprise any number of internal sources and transformations that are wired together, 
    or it can be an �atomic� source, e.g. from a collection or a file. 
    Materialization turns a Source into a Reactive Streams Publisher 
final class Sink[-In, +Mat] extends Graph[SinkShape[In], Mat]
    A Sink is a set of stream processing steps that has one open input. 
    Can be used as a reactive streams Subscriber 
sealed abstract class Done extends Serializable
    Typically used together with Future to signal completion but there is no actual value completed.  
sealed abstract class NotUsed extends AnyRef
    This type is used in generic type signatures wherever the actual value is of no importance.   
//Quick Source Creation 
object Source 
    def actorRef[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, ActorRef]
        Creates a Source that is materialized as an akka.actor.ActorRef.
    def apply[T](iterable: Iterable[T]): Source[T, NotUsed]
        Helper to create Source from Iterable.
    def cycle[T](f: () => Iterator[T]): Source[T, NotUsed]
        Creates Source that will continually produce given elements in specified order.
    def empty[T]: Source[T, NotUsed]
        A Source with no elements, 
    def fromFuture[T](future: Future[T]): Source[T, NotUsed]
        Starts a new Source from the given Future.
    def fromIterator[T](f: () => Iterator[T]): Source[T, NotUsed]
        Helper to create Source from Iterator.
    def maybe[T]: Source[T, Promise[Option[T]]]
        Create a Source which materializes a scala.concurrent.Promise which controls what element will be emitted by the Source.
    def repeat[T](element: T): Source[T, NotUsed]
        Create a Source that will continually emit the given element.
    def tick[T](initialDelay: FiniteDuration, interval: FiniteDuration, tick: T): Source[T, Cancellable]
        Elements are emitted periodically with the specified interval.
    def unfold[S, E](s: S)(f: (S) => Option[(S, E)]): Source[E, NotUsed]
        Create a Source that will unfold a value of type S into a pair of the next state S and output elements of type E.
    def unfoldAsync[S, E](s: S)(f: (S) => Future[Option[(S, E)]]): Source[E, NotUsed]
        Same as unfold, but uses an async function to generate the next state-element tuple.
    def unfoldResource[T, S](create: () => S, read: (S) ? Option[T], close: (S) ? Unit): Source[T, NotUsed]
        Start a new Source from some resource which can be opened, read and closed.
    def unfoldResourceAsync[T, S](create: () => Future[S], read: (S) => Future[Option[T]], close: (S) => Future[Done]): Source[T, NotUsed]
        Start a new Source from some resource which can be opened, read and closed.
    def zipN[T](sources: Seq[Source[T, _]]): Source[Seq[T], NotUsed]
        Combine the elements of multiple streams into a stream of sequences.
    def zipWithN[T, O](zipper: (Seq[T]) => O)(sources: Seq[Source[T, _]]): Source[O, NotUsed] 
    def combine[T, U](first: Source[T, _], second: Source[T, _], rest: Source[T, _]*)(strategy: (Int) => Graph[UniformFanInShape[T, U], NotUsed]): Source[U, NotUsed]
        Combines several sources with fan-in strategy like Merge or Concat and returns Source.


//Http elements 
HttpRequest(method: HttpMethod = HttpMethods.GET, uri: Uri = Uri./,
    headers: Seq[HttpHeader] = Nil, entity: RequestEntity = HttpEntity.Empty, 
    protocol: HttpProtocol = HttpProtocols.`HTTP/1.1`)
HttpResponse(status: StatusCode = StatusCodes.OK, headers: Seq[HttpHeader] = Nil, 
    entity: ResponseEntity = HttpEntity.Empty, 
    protocol: HttpProtocol = HttpProtocols.`HTTP/1.1`)
object akka.http.scaladsl.model.HttpEntity
    final case class Chunk(data: ByteString, extension: String = "")
        An intermediate entity chunk guaranteed to carry non-empty data.
    sealed abstract class ChunkStreamPart
        An element of the HttpEntity data stream.
    final case class Chunked(contentType: ContentType, chunks: Source[ChunkStreamPart, Any])
        The model for the entity of a chunked HTTP message (with Transfer-Encoding: chunked).
    final case class CloseDelimited(contentType: ContentType, data: Source[ByteString, Any])
        The model for the entity of an HTTP response that is terminated by the server closing the connection.
    final case class Default(contentType: ContentType, contentLength: Long, data: Source[ByteString, Any])
        The model for the entity of a "regular" unchunked HTTP message with a known non-zero length.
    final class DiscardedEntity
        Represents the currently being-drained HTTP Entity which triggers completion of the contained Future once the entity has been drained for the given HttpMessage completely.
    implicit final class HttpEntityScalaDSLSugar
        Adds Scala DSL idiomatic methods to HttpEntity, e.g.
    final case class IndefiniteLength(contentType: ContentType, data: Source[ByteString, Any])
        The model for the entity of a BodyPart with an indefinite length.
    case class LastChunk(extension: String = "", trailer: Seq[HttpHeader] = Nil)
        The final chunk of a chunk stream.
    final case class Strict(contentType: ContentType, data: ByteString)
        The model for the entity of a "regular" unchunked HTTP message with known, fixed data.

    val Empty: Strict
    def apply(contentType: ContentType, data: Source[ByteString, Any]): Chunked
    def apply(contentType: ContentType, contentLength: Long, data: Source[ByteString, Any]): UniversalEntity
    def apply(contentType: ContentType, data: ByteString): Strict
    def apply(contentType: ContentType, bytes: Array[Byte]): Strict
    def apply(contentType: NonBinary, string: String): Strict
    implicit def apply(data: ByteString): Strict
    implicit def apply(bytes: Array[Byte]): Strict
    implicit def apply(string: String): Strict
    def empty(contentType: ContentType): Strict
    def fromFile(contentType: ContentType, file: File, chunkSize: Int = -1): UniversalEntity
        Returns either the empty entity, if the given file is empty, or a HttpEntity.Default entity consisting of a stream of akka.util.ByteString instances each containing chunkSize bytes (except for the final ByteString, which simply contains the remaining bytes).
    def fromPath(contentType: ContentType, file: Path, chunkSize: Int = -1): UniversalEntity
        Returns either the empty entity, if the given file is empty, 
        or a HttpEntity.Default entity consisting of a stream of akka.util.ByteString instances 
        each containing chunkSize bytes (except for the final ByteString, 
        which simply contains the remaining bytes).

   

//The Akka HTTP Core Server API allows an application to respond 
//to incoming HTTP requests by writing requestHandler, a fn of  HttpRequest => HttpResponse
akka.http.scaladsl.Http
    def bindAndHandleAsync(
        handler:   HttpRequest => Future[HttpResponse],
        interface: String, port: Int = DefaultPortForProtocol,
        connectionContext: ConnectionContext = defaultServerHttpContext,
        settings:          ServerSettings    = ServerSettings(system),
        parallelism:       Int               = 1,
        log:               LoggingAdapter    = system.log)(implicit fm: Materializer): Future[ServerBinding] 
    def bindAndHandleSync(
        handler:   HttpRequest => HttpResponse,
        interface: String, port: Int = DefaultPortForProtocol,
        connectionContext: ConnectionContext = defaultServerHttpContext,
        settings:          ServerSettings    = ServerSettings(system),
        log:               LoggingAdapter    = system.log)(implicit fm: Materializer): Future[ServerBinding]
    Convenience method which starts a new HTTP server at the given endpoint 
    and uses the given handlerfor processing all incoming connections.
    The number of concurrently accepted connections can be configured by overriding
    the akka.http.server.max-connections setting.


//example 
import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.HttpMethods._
import akka.http.scaladsl.model._
import akka.stream.ActorMaterializer
import scala.io.StdIn

object WebServer {

  def main(args: Array[String]) {
    implicit val system = ActorSystem()
    implicit val materializer = ActorMaterializer()    //A ActorMaterializer takes the list of transformations comprising a Flow and materializes them actual values 
    implicit val executionContext = system.dispatcher // needed for the future map/flatmap in the end

    val requestHandler: HttpRequest => HttpResponse = {
      case HttpRequest(GET, Uri.Path("/"), _, _, _) =>
        HttpResponse(entity = HttpEntity(
          ContentTypes.`text/html(UTF-8)`,
          "<html><body>Hello world!</body></html>"))

      case HttpRequest(GET, Uri.Path("/ping"), _, _, _) =>
        HttpResponse(entity = "PONG!")

      case HttpRequest(GET, Uri.Path("/crash"), _, _, _) =>
        sys.error("BOOM!")

      case r: HttpRequest =>
        r.discardEntityBytes() // important to drain incoming HTTP Entity stream
        HttpResponse(404, entity = "Unknown resource!")
    }

    val bindingFuture = Http().bindAndHandleSync(requestHandler, "localhost", 8080)
    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done

  }
}

//Using high level DSL 

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.{ContentTypes, HttpEntity}
import akka.http.scaladsl.server.Directives._  //core of the Routing DSL
import akka.stream.ActorMaterializer
import scala.io.StdIn

object WebServer {
  def main(args: Array[String]) {
    implicit val system = ActorSystem()
    implicit val materializer = ActorMaterializer()   //A ActorMaterializer takes the list of transformations comprising a Flow and materializes them actual values 
    implicit val executionContext = system.dispatcher  // needed for the future flatMap/onComplete in the end

    val route =
      get {
        pathSingleSlash {
          complete(HttpEntity(ContentTypes.`text/html(UTF-8)`,"<html><body>Hello world!</body></html>"))
        } ~
          path("ping") {
            complete("PONG!")
          } ~
          path("crash") {
            sys.error("BOOM!")
          }
      }

    // `route` will be implicitly converted to `Flow` using `RouteResult.route2HandlerFlow`
    val bindingFuture = Http().bindAndHandle(route, "localhost", 8080)
    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done
  }
}

///HTTPS support 
//https://doc.akka.io/docs/akka-http/current/server-side/server-https-support.html


///Routing DSL for HTTP servers - Overview 
import akka.http.scaladsl.server.Directives._

//pre-defined support for Scala XML with:
import akka.http.scaladsl.marshallers.xml.ScalaXmlSupport._



//Each route is composed of one or more level of Directive s that narrows down to handling one specific type of request.

//Transforming request and response bodies between over-the-wire formats 
//and objects to be used in  application is done separately from the route declarations, 
//in marshallers, which are pulled in implicitly using the �magnet� pattern. 

//This means that you can complete a request with any kind of object 
//as long as there is an implicit marshaller available in scope.

//Default marshallers are provided for simple objects like String or ByteString, 

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.http.scaladsl.server.Directives._
import akka.stream.ActorMaterializer
import scala.io.StdIn

object WebServer {
  def main(args: Array[String]) {

    implicit val system = ActorSystem("my-system")
    implicit val materializer = ActorMaterializer()
    // needed for the future flatMap/onComplete in the end
    implicit val executionContext = system.dispatcher

    val route =
      path("hello") {
        get {
          complete(HttpEntity(ContentTypes.`text/html(UTF-8)`, "<h1>Say hello to akka-http</h1>"))
        }
      }

    val bindingFuture = Http().bindAndHandle(route, "localhost", 8080)

    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done
  }
}

//OR 
import akka.http.scaladsl.model.{ ContentTypes, HttpEntity }
import akka.http.scaladsl.server.HttpApp
import akka.http.scaladsl.server.Route

// Server definition
object WebServer extends HttpApp {
  override def routes: Route =
    path("hello") {
      get {
        complete(HttpEntity(ContentTypes.`text/html(UTF-8)`, "<h1>Say hello to akka-http</h1>"))
      }
    }
}

// Starting the server
WebServer.startServer("localhost", 8080)



//One of the strengths of Akka HTTP is that streaming data 
//both request and response bodies can be streamed through 
//the server achieving constant memory usage even for very large requests or responses. 

//Streaming responses will be backpressured by the remote client 
//so that the server will not push data faster than the client can handle, 

//Example that streams random numbers as long as the client accepts them:

import akka.actor.ActorSystem
import akka.stream.scaladsl._
import akka.util.ByteString
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.{HttpEntity, ContentTypes}
import akka.http.scaladsl.server.Directives._
import akka.stream.ActorMaterializer
import scala.util.Random
import scala.io.StdIn

object WebServer {

  def main(args: Array[String]) {

    implicit val system = ActorSystem()
    implicit val materializer = ActorMaterializer()
    // needed for the future flatMap/onComplete in the end
    implicit val executionContext = system.dispatcher

    // streams are re-usable so we can define it here
    // and use it for every request
    val numbers = Source.fromIterator(() =>  Iterator.continually(Random.nextInt()))

    val route =
      path("random") {
        get {
          complete(
            HttpEntity(
              ContentTypes.`text/plain(UTF-8)`,
              // transform each number to a chunk of bytes
              numbers.map(n => ByteString(s"$n\n"))
            )
          )
        }
      }

    val bindingFuture = Http().bindAndHandle(route, "localhost", 8080)
    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done
  }
}

//Test 
$ curl --limit-rate 50b 127.0.0.1:8080/random

///Interaction with  with actors. 
//In this example one route allows for placing bids in a fire-and-forget style 
//while the second route contains a request-response interaction with an actor. 
//The resulting response is rendered as json and returned when the response arrives from the actor.

import akka.actor.{Actor, ActorSystem, Props, ActorLogging}
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.StatusCodes
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.pattern.ask
import akka.stream.ActorMaterializer
import akka.util.Timeout
import spray.json.DefaultJsonProtocol._
import scala.concurrent.Future
import scala.concurrent.duration._
import scala.io.StdIn

object WebServer {

  case class Bid(userId: String, offer: Int)
  case object GetBids
  case class Bids(bids: List[Bid])

  class Auction extends Actor with ActorLogging {
    var bids = List.empty[Bid]
    def receive = {
      case bid @ Bid(userId, offer) =>
        bids = bids :+ bid
        log.info(s"Bid complete: $userId, $offer")
      case GetBids => sender() ! Bids(bids)
      case _ => log.info("Invalid message")
    }
  }

  // these are from spray-json
  implicit val bidFormat = jsonFormat2(Bid)
  implicit val bidsFormat = jsonFormat1(Bids)

  def main(args: Array[String]) {
    implicit val system = ActorSystem()
    implicit val materializer = ActorMaterializer()
    // needed for the future flatMap/onComplete in the end
    implicit val executionContext = system.dispatcher

    val auction = system.actorOf(Props[Auction], "auction")

    val route =
      path("auction") {
        put {
          parameter("bid".as[Int], "user") { (bid, user) =>
            // place a bid, fire-and-forget
            auction ! Bid(user, bid)
            complete((StatusCodes.Accepted, "bid placed"))
          }
        } ~
        get {
          implicit val timeout: Timeout = 5.seconds

          // query the actor for the current auction state
          val bids: Future[Bids] = (auction ? GetBids).mapTo[Bids]
          complete(bids)
        }
      }

    val bindingFuture = Http().bindAndHandle(route, "localhost", 8080)
    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done

  }
}


///*** Akka Http - Marshalling and Unmarshalling
//marshalling means the conversion of an object of type T into a lower-level target type, 
//e.g. a MessageEntity (which forms the �entity body� of an HTTP request or response) or a full HttpRequest or HttpResponse.

//Marshalling of instances of type A into instances of type B is performed by a Marshaller[A, B]
A => Future[List[Marshalling[B]]]
//Here List means many Marshalling format avaialbel simultaneousely 


//trait  Marshalling
akka.http.scaladsl.marshalling.Marshalling[+A] extends AnyRef 
    def map[B](f: (A) ? B): Marshalling[B]
    def toOpaque(charset: HttpCharset): Marshalling[A]
        Converts this marshalling to an opaque marshalling, i.e.

//object Marshalling
final case class Opaque[A](marshal: () => A)
    A Marshalling to an unknown MediaType and charset.
final case class WithFixedContentType[A](contentType: ContentType, marshal: () => A)
    A Marshalling to a specific akka.http.scaladsl.model.ContentType.
final case class WithOpenCharset[A](mediaType: model.MediaType.WithOpenCharset, marshal: (HttpCharset) => A)
    A Marshalling to a specific akka.http.scaladsl.model.MediaType with a flexible charset.

//Marshaller, (A) =>  Future[List[Marshalling[B]]]
akka.http.scaladsl.marshalling.Marshaller[-A, +B] extends AnyRef 
    abstract def apply(value: A)(implicit ec: ExecutionContext): Future[List[Marshalling[B]]]
    //concrete members     
    def compose[C](f: (C) => A): Marshaller[C, B]
    def composeWithEC[C](f: (ExecutionContext) => (C) => A): Marshaller[C, B]
    def map[C](f: (B) => C): Marshaller[A, C]
    def wrap[C, D >: B](newMediaType: MediaType)(f: (C) => A)(implicit mto: ContentTypeOverrider[D]): Marshaller[C, D]
        Reuses this Marshaller logic to produce a new Marshaller from another type C which overrides the akka.http.scaladsl.model.MediaType of the marshalling result with the given one.
    def wrapWithEC[C, D >: B](newMediaType: MediaType)(f: (ExecutionContext) => (C) => A)(implicit cto: ContentTypeOverrider[D]): Marshaller[C, D]
        Reuses this Marshaller logic to produce a new Marshaller from another type C which overrides the akka.http.scaladsl.model.MediaType of the marshalling result with the given one.
    
object Marshaller extends GenericMarshallers with PredefinedToEntityMarshallers with PredefinedToResponseMarshallers with PredefinedToRequestMarshallers
    //default Marshalling type 
    implicit val ByteArrayMarshaller: ToEntityMarshaller[Array[Byte]]
    implicit val ByteStringMarshaller: ToEntityMarshaller[ByteString]
    implicit val CharArrayMarshaller: ToEntityMarshaller[Array[Char]]
    implicit val DoneMarshaller: ToEntityMarshaller[Done]
    implicit val FormDataMarshaller: ToEntityMarshaller[FormData]
    implicit val MessageEntityMarshaller: ToEntityMarshaller[MessageEntity]
    implicit val StringMarshaller: ToEntityMarshaller[String]
    implicit def eitherMarshaller[A1, A2, B](implicit m1: Marshaller[A1, B], m2: Marshaller[A2, B]): Marshaller[Either[A1, A2], B]
    implicit def fromEntityStreamingSupportAndByteStringMarshaller[T, M](implicit s: EntityStreamingSupport, m: ToByteStringMarshaller[T]): ToResponseMarshaller[Source[T, M]]
    implicit def fromEntityStreamingSupportAndEntityMarshaller[T, M](implicit s: EntityStreamingSupport, m: ToEntityMarshaller[T], tag: ClassTag[T]): ToResponseMarshaller[Source[T, M]]
    implicit def fromMethodAndUriAndHeadersAndValue[T](implicit mt: ToEntityMarshaller[T]): TRM[(HttpMethod, Uri, Seq[HttpHeader], T)]
    implicit def fromMethodAndUriAndValue[S, T](implicit mt: ToEntityMarshaller[T]): TRM[(HttpMethod, Uri, T)]
    implicit val fromRequest: TRM[HttpRequest]
    implicit val fromResponse: TRM[HttpResponse]
    implicit val fromStatusCode: TRM[StatusCode]
        Creates a response for a status code.
    implicit val fromStatusCodeAndHeaders: TRM[(StatusCode, Seq[HttpHeader])]
        Creates a response from status code and headers.
    implicit def fromStatusCodeAndHeadersAndValue[T](implicit mt: ToEntityMarshaller[T]): TRM[(StatusCode, Seq[HttpHeader], T)]
    implicit def fromStatusCodeAndValue[S, T](implicit sConv: (S) => StatusCode, mt: ToEntityMarshaller[T]): TRM[(S, T)]
    implicit def fromStatusCodeConvertibleAndHeadersAndT[S, T](implicit sConv: (S) => StatusCode, mt: ToEntityMarshaller[T]): TRM[(S, Seq[HttpHeader], T)]
    implicit def fromUri: TRM[Uri]
    implicit def futureMarshaller[A, B](implicit m: Marshaller[A, B]): Marshaller[Future[A], B]
    implicit def liftMarshaller[T](implicit m: ToEntityMarshaller[T]): ToResponseMarshaller[T]
    implicit def liftMarshallerConversion[T](m: ToEntityMarshaller[T]): ToResponseMarshaller[T]
    implicit def multipartMarshaller[T <: Multipart](implicit log: LoggingAdapter = DefaultNoLogging): ToEntityMarshaller[T]
    implicit def throwableMarshaller[T]: Marshaller[Throwable, T]
    implicit def tryMarshaller[A, B](implicit m: Marshaller[A, B]): Marshaller[Try[A], B]
    implicit def optionMarshaller[A, B](implicit m: Marshaller[A, B], empty: EmptyValue[B]): Marshaller[Option[A], B]

    def oneOf[T, A, B](values: T*)(f: (T) => Marshaller[A, B]): Marshaller[A, B]
        Helper for creating a "super-marshaller" from a number of values and a function producing "sub-marshallers" from these values.
    def oneOf[A, B](marshallers: Marshaller[A, B]*): Marshaller[A, B]
        Helper for creating a "super-marshaller" from a number of "sub-marshallers".
    def opaque[A, B](marshal: (A) => B): Marshaller[A, B]
        Helper for creating a synchronous Marshaller to non-negotiable content from the given function.
    def strict[A, B](f: (A) => Marshalling[B]): Marshaller[A, B]
        Helper for creating a Marshaller using the given function.
        
    def stringMarshaller(mediaType: WithFixedCharset): ToEntityMarshaller[String]
    def stringMarshaller(mediaType: WithOpenCharset): ToEntityMarshaller[String]
    def apply[A, B](f: (ExecutionContext) => (A) => Future[List[Marshalling[B]]]): Marshaller[A, B]
        Creates a Marshaller from the given function.
    def byteArrayMarshaller(contentType: ContentType): ToEntityMarshaller[Array[Byte]]
    def byteStringMarshaller(contentType: ContentType): ToEntityMarshaller[ByteString]
    def charArrayMarshaller(mediaType: WithFixedCharset): ToEntityMarshaller[Array[Char]]
    def charArrayMarshaller(mediaType: WithOpenCharset): ToEntityMarshaller[Array[Char]]
    def fromToEntityMarshaller[T](status: StatusCode = StatusCodes.OK, headers: Seq[HttpHeader] = Nil)(implicit m: ToEntityMarshaller[T]): ToResponseMarshaller[T]

    def combined[A, B, C](marshal: (A) => B)(implicit m2: Marshaller[B, C]): Marshaller[A, C]
        Helper for creating a Marshaller combined of the provided marshal function and an implicit Marshaller which is able to produce the required final type.
    def withFixedContentType[A, B](contentType: ContentType)(marshal: (A) => B): Marshaller[A, B]
        Helper for creating a synchronous Marshaller to content with a fixed charset from the given function.
    def withOpenCharset[A, B](mediaType: WithOpenCharset)(marshal: (A, HttpCharset) => B): Marshaller[A, B]
        Helper for creating a synchronous Marshaller to content with a negotiable charset from the given function.

//Custom Marshalling 
//use of of below 
type MessageEntity = RequestEntity
    An entity that can be used for every HttpMessage, i.e. for requests and responses.
type ToByteStringMarshaller[T] = Marshaller[T, ByteString]
type ToEntityMarshaller[T] = Marshaller[T, MessageEntity]
    Given ToEntityMarshaller[T], both the client- as well as the server-side 
    since a ToReponseMarshaller[T] as well as a ToRequestMarshaller[T] can automatically be created 
type ToHeadersAndEntityMarshaller[T] = Marshaller[T, (Seq[HttpHeader], MessageEntity)]
type ToRequestMarshaller[T] = Marshaller[T, HttpRequest]
type ToResponseMarshaller[T] = Marshaller[T, HttpResponse] 



///Predefined Marshallers
//PredefinedToEntityMarshallers
    Array[Byte]
    ByteString
    Array[Char]
    String
    akka.http.scaladsl.model.FormData
    akka.http.scaladsl.model.MessageEntity
    T <: akka.http.scaladsl.model.Multipart
//PredefinedToResponseMarshallers
    T, if a ToEntityMarshaller[T] is available
    HttpResponse
    StatusCode
    (StatusCode, T), if a ToEntityMarshaller[T] is available
    (Int, T), if a ToEntityMarshaller[T] is available
    (StatusCode, immutable.Seq[HttpHeader], T), if a ToEntityMarshaller[T] is available
    (Int, immutable.Seq[HttpHeader], T), if a ToEntityMarshaller[T] is available
//PredefinedToRequestMarshallers
    HttpRequest
    Uri
    (HttpMethod, Uri, T), if a ToEntityMarshaller[T] is available
    (HttpMethod, Uri, immutable.Seq[HttpHeader], T), if a ToEntityMarshaller[T] is available
//GenericMarshallers
    Marshaller[Throwable, T]
    Marshaller[Option[A], B], if a Marshaller[A, B] and an EmptyValue[B] is available
    Marshaller[Either[A1, A2], B], if a Marshaller[A1, B] and a Marshaller[A2, B] is available
    Marshaller[Future[A], B], if a Marshaller[A, B] is available
    Marshaller[Try[A], B], if a Marshaller[A, B] is available
        
///Using Marshallers
//In Akka HTTP, marshallers are used implicitly, 
//e.g. when you use 'complete' a request using the Routing DSL.

//OR use explicitely
class  akka.http.scaladsl.marshalling.Marshal extends AnyRef
    new Marshal(value: A) 
    def to[B](implicit m: Marshaller[A, B], ec: ExecutionContext): Future[B]
        Marshals value using the first available Marshalling for A and B provided by the given Marshaller.
    def toResponseFor(request: HttpRequest)(implicit m: ToResponseMarshaller[A], ec: ExecutionContext): Future[HttpResponse]
        Marshals value to an HttpResponse for the given HttpRequest with full content-negotiation.
    val value: A 
object Marshal
    final case class UnacceptableResponseContentTypeException(supported: Set[Alternative]) 
    def apply[T](value: T): Marshal[T] 

//Example 
import scala.concurrent.Await
import scala.concurrent.duration._
import akka.http.scaladsl.marshalling.Marshal
import akka.http.scaladsl.model._

import system.dispatcher // ExecutionContext

val string = "Yeah"
val entityFuture = Marshal(string).to[MessageEntity]
val entity = Await.result(entityFuture, 1.second) // don't block in non-test code!
entity.contentType shouldEqual ContentTypes.`text/plain(UTF-8)`

val errorMsg = "Easy, pal!"
val responseFuture = Marshal(420 -> errorMsg).to[HttpResponse]
val response = Await.result(responseFuture, 1.second) // don't block in non-test code!
response.status shouldEqual StatusCodes.EnhanceYourCalm
response.entity.contentType shouldEqual ContentTypes.`text/plain(UTF-8)`

val request = HttpRequest(headers = List(headers.Accept(MediaTypes.`application/json`)))
val responseText = "Plaintext"
val respFuture = Marshal(responseText).toResponseFor(request) // with content negotiation!
a[Marshal.UnacceptableResponseContentTypeException] should be thrownBy {
  Await.result(respFuture, 1.second) // client requested JSON, we only have text/plain!
}     
///Unmarshalling 
//he conversion of a lower-level source object, e.g. a MessageEntity (which forms the �entity body� of an HTTP request or response) 
//or a full HttpRequest or HttpResponse, into an instance of type T

//Unmarshalling of instances of type A into instances of type B is performed by an Unmarshaller[A, B].
A => Future[B]

//Reference 
trait akka.http.scaladsl.unmarshalling.Unmarshaller[-A, B] extends javadsl.unmarshalling.Unmarshaller[A, B]
    abstract def apply(value: A)(implicit ec: ExecutionContext, materializer: Materializer): Future[B] 
    //Concrete Value Members
    def andThen[C](other: Unmarshaller[B, C]): Unmarshaller[A, C]
    implicit final def asScala: Unmarshaller[A, B]
    def flatMap[C](f: (ExecutionContext) => (Materializer) => (B) => Future[C]): Unmarshaller[A, C]
    def flatMap[C](u: javadsl.unmarshalling.Unmarshaller[_ >: B, C]): javadsl.unmarshalling.Unmarshaller[A, C]
    def flatMap[C](f: Function[B, CompletionStage[C]]): javadsl.unmarshalling.Unmarshaller[A, C]
    def flatMapWithInput[C](f: (A, B) => Future[C]): Unmarshaller[A, C]
    def forContentTypes(ranges: ContentTypeRange*): FromEntityUnmarshaller[B]
        Modifies the underlying Unmarshaller to only accept Content-Types matching one of the given ranges.
    def map[C](f: (B) => C): Unmarshaller[A, C]
    def mapWithCharset[B](f: (B, HttpCharset) => B): FromEntityUnmarshaller[B]
    def mapWithInput[C](f: (A, B) => C): Unmarshaller[A, C]
    def recover[C >: B](pf: (ExecutionContext) => (Materializer) => PartialFunction[Throwable, C]): Unmarshaller[A, C]
    def thenApply[C](f: Function[B, C]): javadsl.unmarshalling.Unmarshaller[A, C]
        Transform the result B of this unmarshaller to a C producing a marshaller that turns As into Cs
    def transform[C](f: (ExecutionContext) => (Materializer) => (Future[B]) => Future[C]): Unmarshaller[A, C]
    val um: Unmarshaller[A, B]
    val underlying: FromEntityUnmarshaller[B]
    def unmarshal(value: A, mat: Materializer): CompletionStage[B]
        Apply this Unmarshaller to the given value.
    def unmarshal(value: A, ec: ExecutionContext, mat: Materializer): CompletionStage[B]
        Apply this Unmarshaller to the given value.
    def withDefaultValue[BB >: B](defaultValue: BB): Unmarshaller[A, BB] 

object Unmarshaller extends GenericUnmarshallers with PredefinedFromEntityUnmarshallers with PredefinedFromStringUnmarshallers
    final case class EitherUnmarshallingException(rightClass: Class[_], right: Throwable, leftClass: Class[_], left: Throwable)
        Order of parameters (right first, left second) is intentional, since thatis the order we evaluate them in.
    final case class UnsupportedContentTypeException(supported: Set[ContentTypeRange])
        Signals that unmarshalling failed because the entity content-type did not match one of the supported ranges.
    def apply[A, B](f: (ExecutionContext) => (A) => Future[B]): Unmarshaller[A, B]
        Creates an Unmarshaller from the given function.
    def bestUnmarshallingCharsetFor(entity: HttpEntity): HttpCharset
        Returns the best charset for unmarshalling the given entity to a character-based representation.

    val HexByte: Unmarshaller[String, Byte]
    val HexInt: Unmarshaller[String, Int]
    val HexLong: Unmarshaller[String, Long]
    val HexShort: Unmarshaller[String, Short]
    
    implicit final class EnhancedFromEntityUnmarshaller[A]
    implicit final class EnhancedUnmarshaller[A, B] extends AnyVal
    implicit def CsvSeq[T](implicit unmarshaller: Unmarshaller[String, T]): Unmarshaller[String, Seq[T]]
    implicit def _fromStringUnmarshallerFromByteStringUnmarshaller[T](implicit bsum: FromByteStringUnmarshaller[T]): Unmarshaller[String, T]
    implicit val booleanFromStringUnmarshaller: Unmarshaller[String, Boolean]
    implicit def byteArrayUnmarshaller: FromEntityUnmarshaller[Array[Byte]]
    implicit val byteFromStringUnmarshaller: Unmarshaller[String, Byte]
    implicit def byteStringUnmarshaller: FromEntityUnmarshaller[ByteString]
    implicit def charArrayUnmarshaller: FromEntityUnmarshaller[Array[Char]]
    implicit def defaultMultipartByteRangesUnmarshaller(implicit log: LoggingAdapter = NoLogging, parserSettings: ParserSettings = null): FromEntityUnmarshaller[ByteRanges]
    implicit def defaultMultipartGeneralUnmarshaller(implicit log: LoggingAdapter = NoLogging, parserSettings: ParserSettings = null): FromEntityUnmarshaller[General]
    implicit def defaultUrlEncodedFormDataUnmarshaller: FromEntityUnmarshaller[FormData]
    implicit val doubleFromStringUnmarshaller: Unmarshaller[String, Double]
    implicit def eitherUnmarshaller[L, R](implicit ua: FromEntityUnmarshaller[L], rightTag: ClassTag[R], ub: FromEntityUnmarshaller[R], leftTag: ClassTag[L]): FromEntityUnmarshaller[Either[L, R]]
        Enables using Either to encode the following unmarshalling logic: Attempt unmarshalling the entity as as R first (yielding R), and if it fails attempt unmarshalling as L (yielding Left).
    implicit val floatFromStringUnmarshaller: Unmarshaller[String, Float]
    implicit def identityUnmarshaller[T]: Unmarshaller[T, T]
    implicit val intFromStringUnmarshaller: Unmarshaller[String, Int]
    implicit def liftToSourceOptionUnmarshaller[A, B](um: Unmarshaller[A, B]): Unmarshaller[Option[A], B]
    implicit def liftToTargetOptionUnmarshaller[A, B](um: Unmarshaller[A, B]): Unmarshaller[A, Option[B]]
    implicit val longFromStringUnmarshaller: Unmarshaller[String, Long]
    implicit def messageUnmarshallerFromEntityUnmarshaller[T](implicit um: FromEntityUnmarshaller[T]): FromMessageUnmarshaller[T]
    implicit def multipartFormDataUnmarshaller(implicit log: LoggingAdapter = NoLogging, parserSettings: ParserSettings = null): FromEntityUnmarshaller[FormData]
    implicit val shortFromStringUnmarshaller: Unmarshaller[String, Short]
    implicit def sourceOptionUnmarshaller[A, B](implicit um: Unmarshaller[A, B]): Unmarshaller[Option[A], B]
    implicit def stringUnmarshaller: FromEntityUnmarshaller[String]
    implicit def targetOptionUnmarshaller[A, B](implicit um: Unmarshaller[A, B]): Unmarshaller[A, Option[B]]
    
    def firstOf[A, B](unmarshallers: Unmarshaller[A, B]*): Unmarshaller[A, B]
        Helper for creating a "super-unmarshaller" from a sequence of "sub-unmarshallers", which are tried in the given order.
    def multipartByteRangesUnmarshaller(defaultCharset: HttpCharset)(implicit log: LoggingAdapter = NoLogging, parserSettings: ParserSettings = null): FromEntityUnmarshaller[ByteRanges]
    def multipartGeneralUnmarshaller(defaultCharset: HttpCharset)(implicit log: LoggingAdapter = NoLogging, parserSettings: ParserSettings = null): FromEntityUnmarshaller[General]
    def multipartUnmarshaller[T <: Multipart, BP <: BodyPart, BPS <: Strict](mediaRange: MediaRange, defaultContentType: ContentType, createBodyPart: (BodyPartEntity, List[HttpHeader]) => BP, createStreamed: (Multipart, Source[BP, Any]) => T, createStrictBodyPart: (Strict, List[HttpHeader]) => BPS, createStrict: (Multipart, Seq[BPS]) => T)(implicit log: LoggingAdapter = NoLogging, parserSettings: ParserSettings = null): FromEntityUnmarshaller[T]
    def strict[A, B](f: (A) => B): Unmarshaller[A, B]
        Helper for creating a synchronous Unmarshaller from the given function.
    def urlEncodedFormDataUnmarshaller(ranges: ContentTypeRange*): FromEntityUnmarshaller[FormData]
    def withMaterializer[A, B](f: (ExecutionContext) => (Materializer) => (A) => Future[B]): Unmarshaller[A, B]
    object NoContentException extends RuntimeException with NoStackTrace with Product with Serializable
        Signals that unmarshalling failed because the entity was unexpectedly empty.
    object UnsupportedContentTypeException extends Serializable
    
//a number of helpful aliases for the types of unmarshallers 
type FromEntityUnmarshaller[T] = Unmarshaller[HttpEntity, T]
type FromMessageUnmarshaller[T] = Unmarshaller[HttpMessage, T]
type FromResponseUnmarshaller[T] = Unmarshaller[HttpResponse, T]
type FromRequestUnmarshaller[T] = Unmarshaller[HttpRequest, T]
type FromByteStringUnmarshaller[T] = Unmarshaller[ByteString, T]
type FromStringUnmarshaller[T] = Unmarshaller[String, T]
type FromStrictFormFieldUnmarshaller[T] = Unmarshaller[StrictForm.Field, T]    
        
        
//Predefined Unmarshaller
//PredefinedFromStringUnmarshallers
    Byte
    Short
    Int
    Long
    Float
    Double
    Boolean
//PredefinedFromEntityUnmarshallers
    Array[Byte]
    ByteString
    Array[Char]
    String
    akka.http.scaladsl.model.FormData
//GenericUnmarshallers
    Unmarshaller[T, T]
    Unmarshaller[Option[A], B], if an Unmarshaller[A, B] is available
    Unmarshaller[A, Option[B]], if an Unmarshaller[A, B] is available
//Json (for spray json)
libraryDependencies += "com.typesafe.akka" %% "akka-http-spray-json" % "10.1.0"
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport      
//XML ( Scala XML right out of the box)
libraryDependencies += "com.typesafe.akka" %% "akka-http-xml" % "10.1.0"    
import akka.http.scaladsl.marshallers.xml.ScalaXmlSupport._ 
//or mixing in the akka.http.scaladsl.marshallers.xml.ScalaXmlSupport trait.  
        
//Using 
//Akka HTTP unmarshallers are used implicitly, 
//e.g. when you want to access the entity of a request using the Routing DSL.
class Unmarshal[A] extends AnyRef
    new Unmarshal(value: A) 
    def to[B](implicit um: Unmarshaller[A, B], ec: ExecutionContext = null, mat: Materializer): Future[B]
        Unmarshals the value to the given Type using the in-scope Unmarshaller.
    val value: A 
object Unmarshal
    def apply[T](value: T): Unmarshal[T] 

//code 
import akka.http.scaladsl.unmarshalling.Unmarshal
import system.dispatcher // Optional ExecutionContext (default from Materializer)
implicit val materializer: Materializer = ActorMaterializer()

import scala.concurrent.Await
import scala.concurrent.duration._

val intFuture = Unmarshal("42").to[Int]
val int = Await.result(intFuture, 1.second) // don't block in non-test code!
int shouldEqual 42

val boolFuture = Unmarshal("off").to[Boolean]
val bool = Await.result(boolFuture, 1.second) // don't block in non-test code!
bool shouldBe false
        
       

///*** akka HTTP - Spray JSON Support
//The SprayJsonSupport trait provides a FromEntityUnmarshaller[T] and ToEntityMarshaller[T] 
//for every type T with an implicit spray.json.RootJsonReader and/or spray.json.RootJsonWriter 


//provide a RootJsonFormat[T] for new type and bring it into scope
//import the FromEntityUnmarshaller[T] and ToEntityMarshaller[T] implicits directly from SprayJsonSupport 

import akka.http.scaladsl.server.Directives
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport
import spray.json._

// domain model
final case class Item(name: String, id: Long)
final case class Order(items: List[Item])

// collect your json format instances into a support trait:
trait JsonSupport extends SprayJsonSupport with DefaultJsonProtocol {
  implicit val itemFormat = jsonFormat2(Item)
  implicit val orderFormat = jsonFormat1(Order) // contains List[Item]
}

// use it wherever json (un)marshalling is needed
class MyJsonService extends Directives with JsonSupport {

  // format: OFF
  val route =
    get {
      pathSingleSlash {
        complete(Item("thing", 42)) // will render as JSON
      }
    } ~
    post {
      entity(as[Order]) { order => // will unmarshal JSON to Order
        val itemsCount = order.items.size
        val itemNames = order.items.map(_.name).mkString(", ")
        complete(s"Ordered $itemsCount items: $itemNames")
      }
    }
  // format: ON
}

//* JSON Support - A use case is to reply to a request using a model object 
//having the marshaller transform it into JSON. 

//SprayJson - types already taken care of by the DefaultJsonProtocol:
    Byte, Short, Int, Long, Float, Double, Char, Unit, Boolean
    String, Symbol
    BigInt, BigDecimal
    Option, Either, Tuple1 - Tuple7
    List, Array
    immutable.{Map, Iterable, Seq, IndexedSeq, LinearSeq, Set, Vector}
    collection.{Iterable, Seq, IndexedSeq, LinearSeq, Set}
    JsValue
//build.sbt 
libraryDependencies += "io.spray" %%  "spray-json" % "1.3.3"
//with akka 
libraryDependencies += "com.typesafe.akka" %% "akka-http-spray-json" % "10.1.0"
//Example 
import spray.json._
import DefaultJsonProtocol._
val source = """{ "some": "JSON source" }"""
val jsonAst = source.parseJson // or JsonParser(source)
val json = jsonAst.prettyPrint // or .compactPrint
val jsonAst = List(1, 2, 3).toJson

//jsonFormatX, X is number of constructor fields
//or use jsonFormat(CaseClassName, variable number of json fields name(string) in the same order of case class fields)
case class Color(name: String, red: Int, green: Int, blue: Int)
object MyJsonProtocol extends DefaultJsonProtocol {
  implicit val colorFormat = jsonFormat4(Color)
}

import MyJsonProtocol._
import spray.json._
val json = Color("CadetBlue", 95, 158, 160).toJson
val color = json.convertTo[Color]
//If you explicitly declare the companion object for your case class 
//use below 
case class Color(name: String, red: Int, green: Int, blue: Int)
object Color

object MyJsonProtocol extends DefaultJsonProtocol {
  implicit val colorFormat = jsonFormat4(Color.apply)
}
//If case class is generic
case class NamedList[A](name: String, items: List[A])

object MyJsonProtocol extends DefaultJsonProtocol {
  implicit def namedListFormat[A :JsonFormat] = jsonFormat2(NamedList.apply[A])
}
//Mix in trait NullOptions, enforce the rendering of undefined members as null
//by default , ignores None from rendering in output 

//for recursive type 
case class Foo(i: Int, foo: Foo)
//wrap your format constructor with lazyFormat and supply an explicit type annotation:
implicit val fooFormat: JsonFormat[Foo] = lazyFormat(jsonFormat(Foo, "i", "foo"))

//For normal class, use below 
class Color(val name: String, val red: Int, val green: Int, val blue: Int)

object MyJsonProtocol extends DefaultJsonProtocol {
  implicit object ColorJsonFormat extends RootJsonFormat[Color] {
    def write(c: Color) =
      JsArray(JsString(c.name), JsNumber(c.red), JsNumber(c.green), JsNumber(c.blue))

    def read(value: JsValue) = value match {
      case JsArray(Vector(JsString(name), JsNumber(red), JsNumber(green), JsNumber(blue))) =>
        new Color(name, red.toInt, green.toInt, blue.toInt)
      case _ => deserializationError("Color expected")
    }
  }
}

import MyJsonProtocol._

val json = Color("CadetBlue", 95, 158, 160).toJson
val color = json.convertTo[Color]
//OR Use below 
object MyJsonProtocol extends DefaultJsonProtocol {
  implicit object ColorJsonFormat extends RootJsonFormat[Color] {
    def write(c: Color) = JsObject(
      "name" -> JsString(c.name),
      "red" -> JsNumber(c.red),
      "green" -> JsNumber(c.green),
      "blue" -> JsNumber(c.blue)
    )
    def read(value: JsValue) = {
      value.asJsObject.getFields("name", "red", "green", "blue") match {
        case Seq(JsString(name), JsNumber(red), JsNumber(green), JsNumber(blue)) =>
          new Color(name, red.toInt, green.toInt, blue.toInt)
        case _ => throw new DeserializationException("Color expected")
      }
    }
  }
}



//Example - The first route queries an asynchronous database and marshalls the Future[Option[Item]] result into a JSON response. 
//The second unmarshalls an Order from the incoming request saves it to the database 
//and replies with an OK when done.

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.stream.ActorMaterializer
import akka.Done
import akka.http.scaladsl.server.Route
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.model.StatusCodes
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import spray.json.DefaultJsonProtocol._

import scala.io.StdIn

import scala.concurrent.Future

object WebServer {

  // needed to run the route
  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()
  // needed for the future map/flatmap in the end and future in fetchItem and saveOrder
  implicit val executionContext = system.dispatcher

  var orders: List[Item] = Nil

  // domain model
  final case class Item(name: String, id: Long)
  final case class Order(items: List[Item])

  // formats for unmarshalling and marshalling
  //jsonFormatX, X is number of constructor fields
  implicit val itemFormat = jsonFormat2(Item)
  implicit val orderFormat = jsonFormat1(Order)

  // (fake) async database query api
  def fetchItem(itemId: Long): Future[Option[Item]] = Future {
    orders.find(o => o.id == itemId)
  }
  def saveOrder(order: Order): Future[Done] = {
    orders = order match {
      case Order(items) => items ::: orders
      case _            => orders
    }
    Future { Done }
  }

  def main(args: Array[String]) {

    val route: Route =
      get {
        pathPrefix("item" / LongNumber) { id =>
          // there might be no item for a given id
          val maybeItem: Future[Option[Item]] = fetchItem(id)

          onSuccess(maybeItem) {
            case Some(item) => complete(item)
            case None       => complete(StatusCodes.NotFound)
          }
        }
      } ~
        post {
          path("create-order") {
            entity(as[Order]) { order =>
              val saved: Future[Done] = saveOrder(order)
              onComplete(saved) { done =>
                complete("order created")
              }
            }
          }
        }

    val bindingFuture = Http().bindAndHandle(route, "localhost", 8080)
    println(s"Server online at http://localhost:8080/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ ? system.terminate()) // and shutdown when done

  }
}





///Json - Pretty printing

//By default, spray-json marshals types to compact printed JSON by implicit conversion using CompactPrinter

//OR use that explicitely 
//by  bringing a PrettyPrinter in scope to perform implicit conversion.

import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import spray.json._

// domain model
final case class PrettyPrintedItem(name: String, id: Long)

object PrettyJsonFormatSupport {
  import DefaultJsonProtocol._
  implicit val printer = PrettyPrinter
  implicit val prettyPrintedItemFormat = jsonFormat2(PrettyPrintedItem)
}

// use it wherever json (un)marshalling is needed
class MyJsonService extends Directives {
  import PrettyJsonFormatSupport._

  // format: OFF
  val route =
    get {
      pathSingleSlash {
        complete {
          PrettyPrintedItem("akka", 42) // will render as JSON
        }
      }
    }
  // format: ON
}

val service = new MyJsonService

// verify the pretty printed JSON
Get("/") ~> service.route ~> check {
  responseAs[String] shouldEqual
    """{""" + "\n" +
    """  "name": "akka",""" + "\n" +
    """  "id": 42""" + "\n" +
    """}"""
}

///*** akka HTTP - Route TestKit
//https://doc.akka.io/docs/akka-http/current/routing-dsl/testkit.html
//build.sbt 
libraryDependencies += "com.typesafe.akka" %% "akka-http-testkit" % "10.1.0"
    
//The basic structure of a test 
REQUEST ~> ROUTE ~> check {
  ASSERTIONS
}

//Example 
import org.scalatest.{ Matchers, WordSpec }
import akka.http.scaladsl.model.StatusCodes
import akka.http.scaladsl.testkit.ScalatestRouteTest
import akka.http.scaladsl.server._
import Directives._

class FullTestKitExampleSpec extends WordSpec with Matchers with ScalatestRouteTest {

  val smallRoute =
    get {
      pathSingleSlash {
        complete {
          "Captain on the bridge!"
        }
      } ~
      path("ping") {
        complete("PONG!")
      }
    }

  "The service" should {

    "return a greeting for GET requests to the root path" in {
      // tests:
      Get() ~> smallRoute ~> check {
        responseAs[String] shouldEqual "Captain on the bridge!"
      }
    }

    "return a 'PONG!' response for GET requests to /ping" in {
      // tests:
      Get("/ping") ~> smallRoute ~> check {
        responseAs[String] shouldEqual "PONG!"
      }
    }

    "leave GET requests to other paths unhandled" in {
      // tests:
      Get("/kermit") ~> smallRoute ~> check {
        handled shouldBe false
      }
    }

    "return a MethodNotAllowed error for PUT requests to the root path" in {
      // tests:
      Put() ~> Route.seal(smallRoute) ~> check {
        status shouldEqual StatusCodes.MethodNotAllowed
        responseAs[String] shouldEqual "HTTP method not allowed, supported methods: GET"
      }
    }
  }
}
//Checking 
status shouldEqual 200

//The following inspectors are defined:
//Inspector 	                            Description
charset: HttpCharset 	                    Identical to contentType.charset
chunks: Seq[HttpEntity.ChunkStreamPart] 	Returns the entity chunks produced by the route. If the entity is not chunked returns Nil.
closingExtension: String 	                Returns chunk extensions the route produced with its last response chunk. If the response entity is unchunked returns the empty string.
contentType: ContentType 	                Identical to responseEntity.contentType
definedCharset: Option[HttpCharset] 	    Identical to contentType.definedCharset
entityAs[T :FromEntityUnmarshaller]: T 	    Unmarshals the response entity using the in-scope FromEntityUnmarshaller for the given type. Any errors in the process trigger a test failure.
handled: Boolean 	                        Indicates whether the route produced an HttpResponse for the request. If the route rejected the request handled evaluates to false.
header(name: String): Option[HttpHeader] 	Returns the response header with the given name or None if no such header is present in the response.
header[T <: HttpHeader]: Option[T] 	        Identical to response.header[T]
headers: Seq[HttpHeader] 	                Identical to response.headers
mediaType: MediaType 	                    Identical to contentType.mediaType
rejection: Rejection 	                    The rejection produced by the route. If the route did not produce exactly one rejection a test failure is triggered.
rejections: Seq[Rejection] 	                The rejections produced by the route. If the route did not reject the request a test failure is triggered.
response: HttpResponse 	                    The HttpResponse returned by the route. If the route did not return an HttpResponse instance (e.g. because it rejected the request) a test failure is triggered.
responseAs[T: FromResponseUnmarshaller]: T 	Unmarshals the response entity using the in-scope FromResponseUnmarshaller for the given type. Any errors in the process trigger a test failure.
responseEntity: HttpEntity 	                Returns the response entity.
status: StatusCode 	                        Identical to response.status
trailer: Seq[HttpHeader] 	                Returns the list of trailer headers the route produced with its last chunk. If the response entity is unchunked returns Nil. 


//Check many directives testcase 
//https://github.com/akka/akka-http/tree/v10.1.0/akka-http-tests/src/test/scala/akka/http/scaladsl/server/directives




@@@
///*** Akka Http - Routes

type Route = RequestContext => Future[RouteResult]

//Example 
val route: Route = { ctx => ctx.complete("yeah") }
//or shorter:
val route: Route = _.complete("yeah")
//or with directive 
val route = complete("yeah")


//Generally when a route receives a request, RequestContext , one of below can be done 
1.Complete the request by returning the value of requestContext.complete(...)
2.Reject the request by returning the value of requestContext.reject(...) 
3.Fail the request by returning the value of requestContext.fail(...) 
  or by just throwing an exception (see Exception Handling)
4.Do any kind of asynchronous processing and instantly return a Future[RouteResult] to be eventually completed later

//Using Route.handlerFlow or Route.asyncHandler 
//a Route can be lifted into a handler Flow or async handler function 
//to be used with a bindAndHandleXXX call from the Core Server API.

//There is also an implicit conversion from Route to Flow[HttpRequest, HttpResponse, Unit] 
//defined in the RouteResult companion, which relies on Route.handlerFlow.


///RequestContext
//The request context wraps an HttpRequest instance 
//contains the unmatchedPath, a value that describes how much of the request URI has not yet been matched by a Path Directive.

//methods 
def complete(obj: ToResponseMarshallable): Future[RouteResult]
	Completes the request with the given ToResponseMarshallable.
implicit def executionContext: ExecutionContextExecutor
	The default ExecutionContext to be used for scheduling asynchronous logic related to this request.
def fail(error: Throwable): Future[RouteResult]
	Bubbles the given error up the response chain where it is dealt with by the closest handleExceptions directive and its ExceptionHandler, unless the error is a RejectionError.
def log: LoggingAdapter
	The default LoggingAdapter to be used for logging messages related to this request.
def mapRequest(f: (HttpRequest) => HttpRequest): RequestContext
	Returns a copy of this context with the HttpRequest transformed by the given function.
def mapUnmatchedPath(f: (Path) => Path): RequestContext
	Returns a copy of this context with the unmatchedPath transformed by the given function.
implicit def materializer: Materializer
	The default Materializer.
def parserSettings: ParserSettings
	The default ParserSettings to be used for configuring directives.
def reconfigure(executionContext: ExecutionContextExecutor = executionContext, materializer: Materializer = materializer, log: LoggingAdapter = log, settings: RoutingSettings = settings): RequestContext
	Returns a copy of this context with the given fields updated.
def redirect(uri: Uri, redirectionType: Redirection): Future[RouteResult]
	Completes the request with redirection response of the given type to the given URI.
def reject(rejections: Rejection*): Future[RouteResult]
	Rejects the request with the given rejections.
val request: HttpRequest
	The request this context represents.
def settings: RoutingSettings
	The default RoutingSettings to be used for configuring directives.
val unmatchedPath: Path
	The unmatched path of this context.
def withAcceptAll: RequestContext
	Removes a potentially existing Accept header from the request headers.
def withExecutionContext(ec: ExecutionContextExecutor): RequestContext
	Returns a copy of this context with the new HttpRequest.
def withLog(log: LoggingAdapter): RequestContext
	Returns a copy of this context with the new LoggingAdapter.
def withMaterializer(materializer: Materializer): RequestContext
	Returns a copy of this context with the new HttpRequest.
def withParserSettings(settings: ParserSettings): RequestContext
	Returns a copy of this context with the new akka.http.scaladsl.settings.ParserSettings.
def withRequest(req: HttpRequest): RequestContext
	Returns a copy of this context with the new HttpRequest.
def withRoutingSettings(settings: RoutingSettings): RequestContext
	Returns a copy of this context with the new RoutingSettings.
def withUnmatchedPath(path: Path): RequestContext
	Returns a copy of this context with the unmatched path updated to the given one.

//RouteResult-abstract data type (ADT) 
//don�t create any RouteResult instances explicitely, 
//but use pre-defined RouteDirectives (like complete, reject or redirect) or the respective methods on the RequestContext instead.
sealed trait RouteResult

object RouteResult {
  final case class Complete(response: HttpResponse) extends RouteResult
  final case class Rejected(rejections: immutable.Seq[Rejection]) extends RouteResult
}

///Composing Routes
val route =
  a {
    b {
      c {
        ... // route 1
      } ~
      d {
        ... // route 2
      } ~
      ... // route 3
    } ~
    e {
      ... // route 4
    }
  }

//five directives form a routing tree.
1.Route 1 will only be reached if directives a, b and c all let the request pass through.
2.Route 2 will run if a and b pass, c rejects and d passes.
3.Route 3 will run if a and b pass, but c and d reject.

///Rejections
//~ operator :connects two or more routes in a way that allows the next specified route 
//to get a go at a request if the first route �rejected� it.

//The default RejectionHandler handles all rejections that reach it.
//Rejections are gathered up over the course of a Route evaluation 
//and finally converted to HttpResponse replies by the handleRejections directive

//OR Customizing Rejection Handling
import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.http.scaladsl.server._
import StatusCodes._
import Directives._

object MyApp extends App {
  implicit def myRejectionHandler =
    RejectionHandler.newBuilder()
      .handle { case MissingCookieRejection(cookieName) => //Handles the provided type of rejections with the given function
        complete(HttpResponse(BadRequest, entity = "No cookies, no service!!!"))
      }
      .handle { case AuthorizationFailedRejection =>
        complete((Forbidden, "You're out of your depth!"))
      }
      .handle { case ValidationRejection(msg, _) =>
        complete((InternalServerError, "That wasn't valid! " + msg))
      }
      .handleAll[MethodRejection] { methodRejections =>  //Handles all rejections of a certain type at the same time. 
        val names = methodRejections.map(_.supported.name)
        complete((MethodNotAllowed, s"Can't do that! Supported: ${names mkString " or "}!"))
      }
      .handleNotFound { complete((NotFound, "Not here!")) }  //Resource Not Found
      .result()

  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()

  val route: Route =
    // ... some route structure

  Http().bindAndHandle(route, "localhost", 8080)
}
//Usage is either by creating implicits 
implicit def myRejectionHandler =
  RejectionHandler.newBuilder()
    .handleNotFound { 
      extractUnmatchedPath { p =>
        complete((NotFound, s"The path you requested [${p}] does not exist."))
      }
    }
    .result()
    
//OR Usage of RejectionHandler via handleRejections directive 
val totallyMissingHandler = RejectionHandler.newBuilder()
  .handleNotFound { complete((StatusCodes.NotFound, "Oh man, what you are looking for is long gone.")) }
  .handle { case ValidationRejection(msg, _) => complete((StatusCodes.InternalServerError, msg)) }
  .result()
val route =
  pathPrefix("handled") {
    handleRejections(totallyMissingHandler) {
      path("existing")(complete("This path exists")) ~
        path("boom")(reject(new ValidationRejection("This didn't work.")))
    }
  }

// tests:
Get("/handled/existing") ~> route ~> check {
  responseAs[String] shouldEqual "This path exists"
}
Get("/missing") ~> Route.seal(route) /* applies default handler */ ~> check {
  status shouldEqual StatusCodes.NotFound
  responseAs[String] shouldEqual "The requested resource could not be found."
}
Get("/handled/missing") ~> route ~> check {
  status shouldEqual StatusCodes.NotFound
  responseAs[String] shouldEqual "Oh man, what you are looking for is long gone."
}
Get("/handled/boom") ~> route ~> check {
  status shouldEqual StatusCodes.InternalServerError
  responseAs[String] shouldEqual "This didn't work."
}
    
    
    
///Exception Handling
//Exceptions thrown during route execution bubble up through the route structure 
//to the next enclosing handleExceptions directive or the top of your route structure.
//By default, unhandled exception will be dealt with by the top-level handler 
//which handles every NonFatal throwable, write its stack trace and complete the request with InternalServerError (500) status code.

//OR use custom ExceptionHandler and for �activating� it:
1.Bring it into implicit scope at the top-level.
2.Supply it as argument to the handleExceptions directive.

//Here is an example for wiring up a custom handler via handleExceptions:
import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import StatusCodes._
import akka.http.scaladsl.server._
import Directives._
import akka.stream.ActorMaterializer

val myExceptionHandler = ExceptionHandler {
  case _: ArithmeticException =>
    extractUri { uri =>
      println(s"Request to $uri could not be handled normally")
      complete(HttpResponse(InternalServerError, entity = "Bad numbers, bad result!!!"))
    }
}

object MyApp extends App {

  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()

  val route: Route =
    handleExceptions(myExceptionHandler) {
      // ... some route structure
    }

  Http().bindAndHandle(route, "localhost", 8080)
}

//to do it implicitly:
import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import StatusCodes._
import akka.http.scaladsl.server._
import Directives._
import akka.stream.ActorMaterializer

implicit def myExceptionHandler: ExceptionHandler =
ExceptionHandler {
case _: ArithmeticException =>
  extractUri { uri =>
    println(s"Request to $uri could not be handled normally")
    complete(HttpResponse(InternalServerError, entity = "Bad numbers, bad result!!!"))
  }
}

object MyApp extends App {

implicit val system = ActorSystem()
implicit val materializer = ActorMaterializer()

val route: Route =
// ... some route structure

Http().bindAndHandle(route, "localhost", 8080)
}
    

///Sealing a Route
//there are generally two ways to handle rejections and exceptions.
1.Bring rejection/exception handlers into implicit scope at the top-level
  route handlers will be 'sealed', 
  (which means that it will receive the default handler as a fallback 
  for all cases your handler doesn�t handle itself) 
  and used for all rejections/exceptions that are not handled within the route structure itself.
2.Supply handlers as arguments to handleRejections and handleExceptions directives

//OR can use explicit Route.seal() to seal a route ie use the default rejection handler explicitely 
//Example - the special header is added to rejected responses which did not match the route, 
//as well as successful responses which matched the route.
val route = respondWithHeader(RawHeader("special-header", "you always have this even in 404")) {
  Route.seal(
    get {
      pathSingleSlash {
        complete {
          "Captain on the bridge!"
        }
      }
    }
  )
}
///*** Akka Http - Directives
//https://doc.akka.io/api/akka-http/10.1.0/akka/http/scaladsl/server/Directives.html  
//Directives create Routes.

//A directive can do one or more of the following:
1.Transform the incoming RequestContext before passing it on to its inner route (i.e. modify the request)
2.Filter the RequestContext according to some logic, i.e. only pass on certain requests and reject others
3.Extract values from the RequestContext and make them available to its inner route as �extractions�
4.Chain some logic into the RouteResult future transformation chain (i.e. modify the response or rejection)
5.Complete the request

//Structures 

name(arguments) { extractions =>
  ... // inner route
}

//argument to the complete RouteDirectives,is evaluated by-name, 
//i.e. it is re-evaluated every time the produced route is run.
//old style 
val route: Route = { ctx =>
  if (ctx.request.method == HttpMethods.GET)
    ctx.complete("Received GET")
  else
    ctx.complete("Received something else")
}
//with directive 
val route =
  get {
    complete("Received GET")
  } ~
  complete("Received something else")
//Both style can be mixed 
val route =
  get { ctx =>
    ctx.complete("Received GET")
  } ~
  complete("Received something else")


///Composing Directives
//Use concat or ~, both are same 

//Using concat
def innerRoute(id: Int): Route =
  concat(get {
    complete {
      "Received GET request for order " + id
    }
  },
  put {
    complete {
      "Received PUT request for order " + id
    }
  })

val route: Route = path("order" / IntNumber) { id => innerRoute(id) }
//Using ~ 
def innerRoute(id: Int): Route =
  get {
    complete {
      "Received GET request for order " + id
    }
  } ~
  put {
    complete {
      "Received PUT request for order " + id
    }
  }

val route: Route = path("order" / IntNumber) { id => innerRoute(id) }

//OR 
val route: Route =
  path("order" / IntNumber) { id =>
    get {
      complete {
        "Received GET request for order " + id
      }
    } ~
    put {
      complete {
        "Received PUT request for order " + id
      }
    }
}
//OR 
val route =
  path("order" / IntNumber) { id =>
    (get | put) { ctx =>
      ctx.complete(s"Received ${ctx.request.method.name} request for order $id")
    }
  }
//OR using extractMethod directive 
val route =
  path("order" / IntNumber) { id =>
    (get | put) {
      extractMethod { m =>
        complete(s"Received ${m.name} request for order $id")
      }
    }
  }
//OR 
val getOrPut = get | put
val route =
  path("order" / IntNumber) { id =>
    getOrPut {
      extractMethod { m =>
        complete(s"Received ${m.name} request for order $id")
      }
    }
  } 
//OR alternative to nesting you can also use the & operator:
val getOrPut = get | put
val route =
  (path("order" / IntNumber) & getOrPut & extractMethod) { (id, m) =>
    complete(s"Received ${m.name} request for order $id")
  }  
//or 
val orderGetOrPutWithMethod =
  path("order" / IntNumber) & (get | put) & extractMethod
val route =
  orderGetOrPutWithMethod { (id, m) =>
    complete(s"Received ${m.name} request for order $id")
  } 

//When you combine directives with the | and & operators 
//the routing DSL makes sure that all extractions work as expected and logical constraints are enforced at compile-time.
val route = path("order" / IntNumber) | get // doesn't compile
val route = path("order" / IntNumber) | path("order" / DoubleNumber)   // doesn't compile
val route = path("order" / IntNumber) | parameter('order.as[Int])      // ok  '

//When you combine directives producing extractions with the & operator 
//all extractions will be properly gathered up:
val order = path("order" / IntNumber) & parameters('oem, 'expired ?)
val route =
  order { (orderId, oem, expired) =>
        ...
  }
      
///Automatic Tuple extraction (flattening)
val futureOfInt: Future[Int] = Future.successful(1)
val route =
  path("success") {
    onSuccess(futureOfInt) { //: Directive[Tuple1[Int]]
      i => complete("Future was completed.")
    }
  }

val futureOfTuple2: Future[Tuple2[Int,Int]] = Future.successful( (1,2) )
val route =
  path("success") {
    onSuccess(futureOfTuple2) { //: Directive[Tuple2[Int,Int]]
      (i, j) => complete("Future was completed.")
    }
  }

val futureOfUnit: Future[Unit] = Future.successful( () )
val route =
  path("success") {
    onSuccess(futureOfUnit) { //: Directive0
        complete("Future was completed.")
    }
  }

  
///*** akka HTTP - List of Directives 
//https://doc.akka.io/docs/akka-http/current/routing-dsl/directives/by-trait.html
 
//Usage patterns , check in test code 
//https://github.com/akka/akka-http/tree/v10.1.0/akka-http-tests/src/test/scala/akka/http/scaladsl/server/directives

//Directives filtering or extracting from the request
MethodDirectives
    Filter and extract based on the request method.
    delete, extractMethod, get, head, method, options, overrideMethodWithParameter, patch, post, put, 
HeaderDirectives
    Filter and extract based on request headers.
    headerValue, headerValueByName, headerValueByType, headerValuePF, optionalHeaderValue, 
    optionalHeaderValueByName, optionalHeaderValueByType, optionalHeaderValuePF, 
    checkSameOrigin, 
PathDirectives
    Filter and extract from the request URI path.
    path, pathEnd, pathEndOrSingleSlash, pathPrefix, pathPrefixTest, pathSingleSlash, 
    pathSuffix, pathSuffixTest, rawPathPrefix, rawPathPrefixTest, 
    redirectToNoTrailingSlashIfPresent, redirectToTrailingSlashIfMissing, ignoreTrailingSlash
HostDirectives
    Filter and extract based on the target host.
    host, extractHost
ParameterDirectives, FormFieldDirectives
    Filter and extract based on query parameters or form fields 
    (of Content-Type application/x-www-form-urlencoded or multipart/form-data).
    parameter, parameters, parameterMap, parameterMultiMap, parameterSeq
    formField, formFields, formFieldSeq, formFieldMap, formFieldMultiMap
CodingDirectives
    Filter and decode compressed request content.
    decodeRequest, decodeRequestWith, encodeResponse, encodeResponseWith, requestEncodedWith, 
    responseEncodingAccepted, withPrecompressedMediaTypeSupport, 
Marshalling Directives
    Extract the request entity.
    completeWith, entity, handleWith
SchemeDirectives
    Filter and extract based on the request scheme.
    extractScheme, scheme
SecurityDirectives
    Handle authentication data from the request.
    authenticateBasic, authenticateBasicAsync, authenticateBasicPF, authenticateBasicPFAsync, authenticateOrRejectWithChallenge, authenticateOAuth2, authenticateOAuth2Async, authenticateOAuth2PF, 
    authenticateOAuth2PFAsync, authorize, authorizeAsync, extractCredentials
CookieDirectives
    Filter and extract cookies.
    cookie, deleteCookie, optionalCookie, setCookie, 
BasicDirectives and MiscDirectives
    Directives handling request properties.
    Providing Values to Inner Routes
        extract, extractActorSystem, extractDataBytes, extractExecutionContext, extractLog, 
        extractMatchedPath, extractMaterializer, extractParserSettings, extractRequestContext, 
        extractRequestEntity, extractRequest, extractSettings, extractStrictEntity, 
        extractUnmatchedPath, extractUri, textract, provide, tprovide, 
    Transforming the Request(Context)
        mapRequest, mapRequestContext, mapSettings, mapUnmatchedPath, withExecutionContext, 
        withLog, withMaterializer, withSettings, toStrictEntity, 
    Transforming the Response
        mapResponse, mapResponseEntity, mapResponseHeaders, 
    Transforming the RouteResult, 
        cancelRejection, cancelRejections, mapRejections, mapRouteResult, mapRouteResultFuture, 
        mapRouteResultPF, mapRouteResultWith, mapRouteResultWithPF, 
        recoverRejections, recoverRejectionsWith, 
    Other
        mapInnerRoute, pass, 
    MiscDirectives
        extractClientIP, rejectEmptyResponse, requestEntityEmpty, requestEntityPresent, 
        selectPreferredLanguage, validate, withoutSizeLimit, withSizeLimit, 
FileUploadDirectives
    Handle file uploads.
    fileUpload, fileUploadAll, storeUploadedFile, storeUploadedFiles, uploadedFile,

//Directives creating or transforming the response
BasicDirectives and MiscDirectives
    Directives handling or transforming response properties.
CookieDirectives
    Set, modify, or delete cookies.
    cookie, deleteCookie, optionalCookie, setCookie, 
CodingDirectives
    Compress responses.
    decodeRequest, decodeRequestWith, encodeResponse, encodeResponseWith, requestEncodedWith, 
    responseEncodingAccepted, withPrecompressedMediaTypeSupport, 
CacheConditionDirectives
    Support for conditional requests (304 Not Modified responses).
    conditional
CachingDirectives
    Support for caching expensive operations.
    //sbt 
    libraryDependencies += "com.typesafe.akka" %% "akka-http-caching" % "10.1.0"
    //include
    import akka.http.scaladsl.server.directives.CachingDirectives._
    //directives
    cache, alwaysCache, cachingProhibited
FileAndResourceDirectives
    Deliver responses from files and resources.
    getFromBrowseableDirectories, getFromBrowseableDirectory, getFromDirectory, getFromFile, 
    getFromResource, getFromResourceDirectory, listDirectoryContents, 
RangeDirectives
    Support for range requests (206 Partial Content responses).
    withRangeSupport
RespondWithDirectives
    Change response properties.
    respondWithDefaultHeader, respondWithDefaultHeaders, respondWithHeader, respondWithHeaders, 
RouteDirectives
    Complete or reject a request with a response.
    complete, failWith, redirect, reject, 
TimeoutDirectives
    Configure request timeouts and automatic timeout responses. 
    withRequestTimeout, withoutRequestTimeout, withRequestTimeoutResponse, 
    
    
  
///*** akka Http - Directives - parameters directives 
//synatxes of parameters 
"color"
    extract value of parameter �color� as String
"color".?
    extract optional value of parameter �color� as Option[String]
"color" ? "red"
    extract optional value of parameter �color� as String with default value "red"
"color" ! "blue"
    require value of parameter �color� to be "blue" and extract nothing
"amount".as[Int]
    extract value of parameter �amount� as Int, 
    you need a matching Unmarshaller in scope for that to work 
"amount".as(deserializer)
    extract value of parameter �amount� with an explicit Unmarshaller 
"distance".*
    extract multiple occurrences of parameter �distance� as Iterable[String]
"distance".as[Int].*
    extract multiple occurrences of parameter �distance� as Iterable[Int], 
    you need a matching Unmarshaller in scope for that to work (see also Unmarshalling)
"distance".as(deserializer).*
    extract multiple occurrences of parameter �distance� with an explicit Unmarshaller 

//Example 
val route =
  parameters('color, 'backgroundColor) { (color, backgroundColor) =>
    complete(s"The color is '$color' and the background is '$backgroundColor'")
  }

// tests:
Get("/?color=blue&backgroundColor=red") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the background is 'red'"
}
Get("/?color=blue") ~> Route.seal(route) ~> check {
  status shouldEqual StatusCodes.NotFound
  responseAs[String] shouldEqual "Request is missing required query parameter 'backgroundColor'"
}
//Optional parameter
val route =
  parameters('color, 'backgroundColor.?) { (color, backgroundColor) =>
    val backgroundStr = backgroundColor.getOrElse("<undefined>")
    complete(s"The color is '$color' and the background is '$backgroundStr'")
  }

// tests:
Get("/?color=blue&backgroundColor=red") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the background is 'red'"
}
Get("/?color=blue") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the background is '<undefined>'"
}



//Optional parameter with default value
val route =
  parameters('color, 'backgroundColor ? "white") { (color, backgroundColor) =>
    complete(s"The color is '$color' and the background is '$backgroundColor'")
  }

// tests:
Get("/?color=blue&backgroundColor=red") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the background is 'red'"
}
Get("/?color=blue") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the background is 'white'"
}

//Parameter with required value
val route =
  parameters('color, 'action ! "true") { (color) =>
    complete(s"The color is '$color'.")
  }

// tests:
Get("/?color=blue&action=true") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue'."
}

Get("/?color=blue&action=false") ~> Route.seal(route) ~> check {
  status shouldEqual StatusCodes.NotFound
  responseAs[String] shouldEqual "The requested resource could not be found."
}

//Deserialized parameter
val route =
  parameters('color, 'count.as[Int]) { (color, count) =>
    complete(s"The color is '$color' and you have $count of it.")
  }

// tests:
Get("/?color=blue&count=42") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and you have 42 of it."
}

Get("/?color=blue&count=blub") ~> Route.seal(route) ~> check {
  status shouldEqual StatusCodes.BadRequest
  responseAs[String] shouldEqual "The query parameter 'count' was malformed:\n'blub'" +
    " is not a valid 32-bit signed integer value"
}


//Repeated parameter

val route =
  parameters('color, 'city.*) { (color, cities) =>
    cities.toList match {
      case Nil         => complete(s"The color is '$color' and there are no cities.")
      case city :: Nil => complete(s"The color is '$color' and the city is $city.")
      case multiple    => complete(s"The color is '$color' and the cities are ${multiple.mkString(", ")}.")
    }
  }

// tests:
Get("/?color=blue") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and there are no cities."
}

Get("/?color=blue&city=Chicago") ~> Route.seal(route) ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the city is Chicago."
}

Get("/?color=blue&city=Chicago&city=Boston") ~> Route.seal(route) ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the cities are Boston, Chicago."
}

//CSV parameter

val route =
  parameter("names".as(CsvSeq[String])) { names =>
    complete(s"The parameters are ${names.mkString(", ")}")
  }

// tests:
Get("/?names=") ~> route ~> check {
  responseAs[String] shouldEqual "The parameters are "
}
Get("/?names=Caplin") ~> route ~> check {
  responseAs[String] shouldEqual "The parameters are Caplin"
}
Get("/?names=Caplin,John") ~> route ~> check {
  responseAs[String] shouldEqual "The parameters are Caplin, John"
}

//Repeated, deserialized parameter
val route =
  parameters('color, 'distance.as[Int].*) { (color, distances) =>
    distances.toList match {
      case Nil             => complete(s"The color is '$color' and there are no distances.")
      case distance :: Nil => complete(s"The color is '$color' and the distance is $distance.")
      case multiple        => complete(s"The color is '$color' and the distances are ${multiple.mkString(", ")}.")
    }
  }

// tests:
Get("/?color=blue") ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and there are no distances."
}

Get("/?color=blue&distance=5") ~> Route.seal(route) ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the distance is 5."
}

Get("/?color=blue&distance=5&distance=14") ~> Route.seal(route) ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the distances are 14, 5."
}



///*** akka Http - Directives - Case Class Extraction

//for path color/red=..&green=...&blue=...
case class Color(red: Int, green: Int, blue: Int)

val route =
  path("color") {
    parameters('red.as[Int], 'green.as[Int], 'blue.as[Int]) { (red, green, blue) =>  //'
      val color = Color(red, green, blue)
      // ... route working with the `color` instance
    }
  }

//OR for case classes, shortcut syntax 
//can postfix any directive with extractions with an as(...)
case class Color(red: Int, green: Int, blue: Int)

val route =
  path("color") {
    parameters('red.as[Int], 'green.as[Int], 'blue.as[Int]).as(Color) { color =>   //'
      // ... route working with the `color` instance
    }
  }

//to construct a case class instance from extractions produced by several directives 
//you can first join the directives with the & operator before using the as call:

case class Color(name: String, red: Int, green: Int, blue: Int)

val route =
  (path("color" / Segment) & parameters('r.as[Int], 'g.as[Int], 'b.as[Int])).as(Color) { color =>  //'
      // ... route working with the `color` instance
    }

    
///Case Class Validation
//put the verification logic into the constructor of case class

case class Color(name: String, red: Int, green: Int, blue: Int) {
  require(!name.isEmpty, "color name must not be empty")
  require(0 <= red && red <= 255, "red color component must be between 0 and 255")
  require(0 <= green && green <= 255, "green color component must be between 0 and 255")
  require(0 <= blue && blue <= 255, "blue color component must be between 0 and 255")
}


///*** akka http - directive - method 
def method(httpMethod: HttpMethod): Directive0

//Example 
val route = method(HttpMethods.PUT) { complete("This is a PUT request.") }

// tests:
Put("/", "put content") ~> route ~> check {
  responseAs[String] shouldEqual "This is a PUT request."
}

Get("/") ~> Route.seal(route) ~> check {
  status shouldEqual StatusCodes.MethodNotAllowed
  responseAs[String] shouldEqual "HTTP method not allowed, supported methods: PUT"
}

///*** akka http - directive - onSuccess
def onSuccess(magnet: OnSuccessMagnet): Directive[magnet.Out]
//Example 
val route =
  path("success") {
    onSuccess(Future { "Ok" }) { extraction =>
      complete(extraction)
    }
  } ~
  path("failure") {
    onSuccess(Future.failed[String](TestException)) { extraction =>
      complete(extraction)
    }
  }

// tests:
Get("/success") ~> route ~> check {
  responseAs[String] shouldEqual "Ok"
}

Get("/failure") ~> Route.seal(route) ~> check {
  status shouldEqual InternalServerError
  responseAs[String] shouldEqual "Unsuccessful future!"
}

///*** akka http - directive - onComplete
def onComplete[T](future: => Future[T]): Directive1[Try[T]]

//Example 
def divide(a: Int, b: Int): Future[Int] = Future {
  a / b
}

val route =
  path("divide" / IntNumber / IntNumber) { (a, b) =>
    onComplete(divide(a, b)) {
      case Success(value) => complete(s"The result was $value")
      case Failure(ex)    => complete((InternalServerError, s"An error occurred: ${ex.getMessage}"))
    }
  }

// tests:
Get("/divide/10/2") ~> route ~> check {
  responseAs[String] shouldEqual "The result was 5"
}

Get("/divide/10/0") ~> Route.seal(route) ~> check {
  status shouldEqual InternalServerError
  responseAs[String] shouldEqual "An error occurred: / by zero"
}

///*** akka Http - Directives - Marshalling Directives
completeWith 	
    Uses a marshaller for a given type to produce a completion function for an inner route. 
    Used in conjunction with instanceOf to format responses.
entity 	
    Unmarshalls the request entity to the given type and passes it to its inner route. 
    Used in conjunction with as to convert requests to objects.
handleWith 	
    Completes a request with a given function, using an in-scope unmarshaller for an input 
    and in-scope marshaller for the output. 

    
///completeWith
def completeWith[T](marshaller: ToResponseMarshaller[T])(inner: (T => Unit) => Unit): Route
def handleWith[A, B](f: A => B)(implicit um: FromRequestUnmarshaller[A], m: ToResponseMarshaller[B]): Route

//completeWith is similar to handleWith. 
//The main difference is with completeWith you must eventually call the completion function generated by completeWith. 
//handleWith will automatically call complete when the handleWith function returns.


//The PersonJsonSupport object handles both marshalling 
//and unmarshalling of the Person case class.

case class Person(name: String, favoriteNumber: Int)

object PersonJsonSupport extends DefaultJsonProtocol with SprayJsonSupport {
  implicit val PortofolioFormats = jsonFormat2(Person)
}


//The findPerson takes an argument of type Person => Unit 
//which is generated by the completeWith call. 

import PersonJsonSupport._

val findPerson = (f: Person => Unit) => {

  //... some processing logic...

  //complete the request
  f(Person("Jane", 42))
}

val route = get {
  completeWith(instanceOf[Person]) { completionFunction => findPerson(completionFunction) }
}

// tests:
Get("/") ~> route ~> check {
  mediaType shouldEqual `application/json`
  responseAs[String] should include(""""name":"Jane"""")
  responseAs[String] should include(""""favoriteNumber":42""")
}
//Example 
import PersonJsonSupport._

val updatePerson = (person: Person) => {

  //... some processing logic...

  //return the person
  person
}

val route = post {
  handleWith(updatePerson)
}

// tests:
Post("/", HttpEntity(`application/json`, """{ "name": "Jane", "favoriteNumber" : 42 }""")) ~>
  route ~> check {
    mediaType shouldEqual `application/json`
    responseAs[String] should include(""""name":"Jane"""")
    responseAs[String] should include(""""favoriteNumber":42""")
  }

  
  
///entity
def entity[T](um: FromRequestUnmarshaller[T]): Directive1[T]
//Unmarshalls the request entity to the given type and passes it to its inner Route

//example 
case class Person(name: String, favoriteNumber: Int)
object PersonJsonSupport extends DefaultJsonProtocol with SprayJsonSupport {
  implicit val PortofolioFormats = jsonFormat2(Person)
}

import PersonJsonSupport._

val route = post {
  entity(as[Person]) { person =>
    complete(s"Person: ${person.name} - favorite number: ${person.favoriteNumber}")
  }
}

// tests:
Post("/", HttpEntity(`application/json`, """{ "name": "Jane", "favoriteNumber" : 42 }""")) ~>
  route ~> check {
    responseAs[String] shouldEqual "Person: Jane - favorite number: 42"
  }

  
//It is also possible to use the entity directive to obtain raw JsValue ( spray-json ) objects,
//by simply using as[JsValue]

import PersonJsonSupport._

val route = post {
  entity(as[JsValue]) { json =>
    complete(s"Person: ${json.asJsObject.fields("name")} - favorite number: ${json.asJsObject.fields("favoriteNumber")}")
  }
}

// tests:
Post("/", HttpEntity(`application/json`, """{ "name": "Jane", "favoriteNumber" : 42 }""")) ~>
  route ~> check {
    responseAs[String] shouldEqual """Person: "Jane" - favorite number: 42"""
  }


  
///*** akka Http - Directives - PathDirectives 
//Filter and extract from the request URI path.
    path, pathEnd, pathEndOrSingleSlash, pathPrefix, pathPrefixTest, pathSingleSlash, 
    pathSuffix, pathSuffixTest, rawPathPrefix, rawPathPrefixTest, 
    redirectToNoTrailingSlashIfPresent, redirectToTrailingSlashIfMissing, ignoreTrailingSlash

//usage 
rawPathPrefix(x)
    it matches x and leaves a suffix (if any) unmatched.
pathPrefix(x)
    is equivalent to rawPathPrefix(Slash ~ x). 
    It matches a leading slash followed by x and then leaves a suffix unmatched.
path(x)
    is equivalent to rawPathPrefix(Slash ~ x ~ PathEnd). 
    It matches a leading slash followed by x and then the end.
pathEnd
    is equivalent to just rawPathPrefix(PathEnd). 
    It is matched only when there is nothing left to match from the path. 
    This directive should not be used at the root as the minimal path is the single slash.
pathSingleSlash
    is equivalent to rawPathPrefix(Slash ~ PathEnd). 
    It matches when the remaining path is just a single slash.
pathEndOrSingleSlash
    is equivalent to rawPathPrefix(PathEnd) or rawPathPrefix(Slash ~ PathEnd). It matches either when there is no remaining path or is just a single slash.


//Example 
val route =
  path("foo") {
    complete("/foo")
  } ~
    path("foo" / "bar") {
      complete("/foo/bar")
    } ~
    pathPrefix("ball") {
      pathEnd {
        complete("/ball")
      } ~
        path(IntNumber) { int =>
          complete(if (int % 2 == 0) "even ball" else "odd ball")
        }
    }

// tests:
Get("/") ~> route ~> check {
  handled shouldEqual false
}

Get("/foo") ~> route ~> check {
  responseAs[String] shouldEqual "/foo"
}

Get("/foo/bar") ~> route ~> check {
  responseAs[String] shouldEqual "/foo/bar"
}

Get("/ball/1337") ~> route ~> check {
  responseAs[String] shouldEqual "odd ball"
}

///Path DSL 
//https://doc.akka.io/docs/akka-http/current/routing-dsl/path-matchers.html

//built with below 
trait PathMatcher[L: Tuple]
type PathMatcher0 = PathMatcher[Unit]
type PathMatcher1[T] = PathMatcher[Tuple1[T]]
type PathMatcher2[T,U] = PathMatcher[Tuple2[T,U]]
// .. etc

//Example - match paths like foo/bar/X42/edit or foo/bar/X/create.
val matcher: PathMatcher1[Option[Int]] =
  "foo" / "bar" / "X" ~ IntNumber.? / ("edit" | "create")

//The path matching DSL describes what paths to accept after URL decoding. 

// matches /foo/
path("foo"./)

// matches e.g. /foo/123 and extracts "123" as a String
path("foo" / """\d+""".r)

// matches e.g. /foo/bar123 and extracts "123" as a String
path("foo" / """bar(\d+)""".r)

// similar to `path(Segments)`
path(Segment.repeat(10, separator = Slash))

// matches e.g. /i42 or /hCAFE and extracts an Int
path("i" ~ IntNumber | "h" ~ HexIntNumber)

// identical to path("foo" ~ (PathEnd | Slash))
path("foo" ~ Slash.?)

// matches /red or /green or /blue and extracts 1, 2 or 3 respectively
path(Map("red" -> 1, "green" -> 2, "blue" -> 3))

// matches anything starting with "/foo" except for /foobar
pathPrefix("foo" ~ !"bar")    


///Basic PathMatchers
String instance
    You can use a String instance as a PathMatcher0. 
    Strings simply match themselves and extract no value. 
    Note that strings are interpreted as the decoded representation of the path, 
    so if they include a �/� character this character will match �%2F� in the encoded raw URI!
Regex instance 
    You can use a Regex instance as a PathMatcher1[String], 
    which matches whatever the regex matches and extracts one String value. 
    A PathMatcher created from a regular expression extracts either the complete match 
    (if the regex doesn�t contain a capture group) 
    or the capture group (if the regex contains exactly one capture group). 
    If the regex contains more than one capture group an IllegalArgumentException will be thrown.
Map[String, T] instance 
    You can use a Map[String, T] instance as a PathMatcher1[T], 
    which matches any of the keys and extracts the respective map value for it.
Slash: PathMatcher0
    Matches exactly one path-separating slash (/) character and extracts nothing.
Segment: PathMatcher1[String]
    Matches if the unmatched path starts with a path segment (i.e. not a slash). 
    If so the path segment is extracted as a String instance.
PathEnd: PathMatcher0
    Matches the very end of the path, similar to $ in regular expressions and extracts nothing.
Remaining: PathMatcher1[String]
    Matches and extracts the complete remaining unmatched part of the request�s URI path 
    as an (encoded!) String. 
    If you need access to the remaining decoded elements of the path use RemainingPath instead.
RemainingPath: PathMatcher1[Path]
    Matches and extracts the complete remaining, unmatched part of the request�s URI path.
IntNumber: PathMatcher1[Int]
    Efficiently matches a number of decimal digits (unsigned) and extracts their (non-negative) Int value. 
    The matcher will not match zero digits or a sequence of digits that would represent an Int value 
    larger than Int.MaxValue.
LongNumber: PathMatcher1[Long]
    Efficiently matches a number of decimal digits (unsigned) and extracts their (non-negative) Long value. 
    The matcher will not match zero digits or a sequence of digits that would represent an Long value 
    larger than Long.MaxValue.
HexIntNumber: PathMatcher1[Int]
    Efficiently matches a number of hex digits and extracts their (non-negative) Int value. 
    The matcher will not match zero digits or a sequence of digits that would represent an Int value 
    larger than Int.MaxValue.
HexLongNumber: PathMatcher1[Long]
    Efficiently matches a number of hex digits and extracts their (non-negative) Long value. 
    The matcher will not match zero digits or a sequence of digits that would represent an Long value 
    larger than Long.MaxValue.
DoubleNumber: PathMatcher1[Double]
    Matches and extracts a Double value. The matched string representation is the pure decimal, 
    optionally signed form of a double value, i.e. without exponent.
JavaUUID: PathMatcher1[UUID]
    Matches and extracts a java.util.UUID instance.
Neutral: PathMatcher0
    A matcher that always matches, doesn�t consume anything and extracts nothing. 
    Serves mainly as a neutral element in PathMatcher composition.
Segments: PathMatcher1[List[String]]
    Matches all remaining segments as a list of strings. 
    Note that this can also be �no segments� resulting in the empty list. 
    If the path has a trailing slash this slash will not be matched, 
    i.e. remain unmatched and to be consumed by potentially nested directives.
separateOnSlashes(string: String): PathMatcher0
    Converts a path string containing slashes into a PathMatcher0 that interprets slashes 
    as path segment separators. 
    This means that a matcher matching �%2F� cannot be constructed with this helper.
provide[L: Tuple](extractions: L): PathMatcher[L]
    Always matches, consumes nothing and extracts the given TupleX of values.
PathMatcher[L: Tuple](prefix: Path, extractions: L): PathMatcher[L]
    Matches and consumes the given path prefix and extracts the given list of extractions. 
    If the given prefix is empty the returned matcher matches always and consumes nothing.

//Path matchers can be combined with these combinators to form higher-level constructs:
Tilde Operator (~)
    It simply concatenates two matchers into one, 
    i.e if the first one matched (and consumed) the second one is tried. 
    The extractions of both matchers are combined type-safely. 
    For example: "foo" ~ "bar" yields a matcher that is identical to "foobar".
Slash Operator (/)
    This operator concatenates two matchers and inserts a Slash matcher in between them. 
    For example: "foo" / "bar" is identical to "foo" ~ Slash ~ "bar".
Pipe Operator (|)
    This operator combines two matcher alternatives in that the second one is only tried 
    if the first one did not match. 
    The two sub-matchers must have compatible types.
    For example: "foo" | "bar" will match either �foo� or �bar�. 
    When combining an alternative expressed using this operator with an / operator,
    make sure to surround the alternative with parentheses, like so: ("foo" | "bar") / "bom". 
    Otherwise, the / operator takes precendence and would only apply to the right-hand side of the alternative.

//Path matcher instances can be transformed with these modifier methods:
/
    The slash operator cannot only be used as combinator for combining two matcher instances, 
    it can also be used as a postfix call. 
    matcher / is identical to matcher ~ Slash but shorter and easier to read.
? 
    By postfixing a matcher with ? you can turn any PathMatcher into one that always matches, 
    optionally consumes and potentially extracts an Option of the underlying matchers extraction. 
    The result type depends on the type of the underlying matcher:
    //If a matcher is of type 	then matcher.? is of type
    PathMatcher0 	            PathMatcher0
    PathMatcher1[T] 	        PathMatcher1[Option[T]
    PathMatcher[L: Tuple] 	    PathMatcher[Option[L]]
repeat(separator: PathMatcher0 = PathMatchers.Neutral)
    By postfixing a matcher with repeat(separator) you can turn any PathMatcher into one that always matches, 
    consumes zero or more times (with the given separator) 
    and potentially extracts a List of the underlying matcher�s extractions. 
    The result type depends on the type of the underlying matcher:
    //If a matcher is of type 	then matcher.repeat(...) is of type
    PathMatcher0 	            PathMatcher0
    PathMatcher1[T] 	        PathMatcher1[List[T]
    PathMatcher[L: Tuple] 	    PathMatcher[List[L]]
unary_!
    By prefixing a matcher with ! it can be turned into a PathMatcher0 
    that only matches if the underlying matcher does not match and vice versa.
transform / (h)flatMap / (h)map
    These modifiers allow you to append your own �post-application� logic to another matcher 
    in order to form a custom one. 
    You can map over the extraction(s), turn mismatches into matches or vice-versa 
    or do anything else with the results of the underlying matcher.
    Take a look at the method signatures and implementations for more guidance as to how to use them.




///*** akka Http - Directives - MethodDirectives
    delete
    extractMethod
    get
    head
    method
    options
    overrideMethodWithParameter
    patch
    post
    put

///extractMethod
def extractMethod: Directive1[HttpMethod]
//Extracts the HttpMethod from the request context and provides it for use for other directives explicitly.
val route =
  get {
    complete("This is a GET request.")
  } ~
    extractMethod { method =>
      complete(s"This ${method.name} request, clearly is not a GET!")
    }

// tests:
Get("/") ~> route ~> check {
  responseAs[String] shouldEqual "This is a GET request."
}

Put("/") ~> route ~> check {
  responseAs[String] shouldEqual "This PUT request, clearly is not a GET!"
}
Head("/") ~> route ~> check {
  responseAs[String] shouldEqual "This HEAD request, clearly is not a GET!"
}



///*** akka Http - Directives - HeaderDirectives
    headerValue
    headerValueByName
    headerValueByType
    headerValuePF
    optionalHeaderValue
    optionalHeaderValueByName
    optionalHeaderValueByType
    optionalHeaderValuePF
    checkSameOrigin


///headerValueByName
def headerValueByName(headerName: Symbol): Directive1[String]
def headerValueByName(headerName: String): Directive1[String]
//Extracts the value of the HTTP request header with the given name.

val route =
  headerValueByName("X-User-Id") { userId =>
    complete(s"The user is $userId")
  }

// tests:
Get("/") ~> RawHeader("X-User-Id", "Joe42") ~> route ~> check {
  responseAs[String] shouldEqual "The user is Joe42"
}

Get("/") ~> Route.seal(route) ~> check {
  status shouldEqual BadRequest
  responseAs[String] shouldEqual "Request is missing required HTTP header 'X-User-Id'"
}    
    
//////*** akka Http - Directives - FileUploadDirectives 

///fileUpload
def fileUpload(fieldName: String): Directive1[(FileInfo, Source[ByteString, Any])]

//Simple access to the stream of bytes for a file uploaded as a multipart form together with metadata about the upload.
//If there is no field with the given name the request will be rejected. If there are multiple file parts with the same name, the first one will be used and the subsequent ones ignored.

//Example 
// adding integers as a service
val route =
  extractRequestContext { ctx =>
    implicit val materializer = ctx.materializer

    fileUpload("csv") {
      case (metadata, byteSource) =>

        val sumF: Future[Int] =
          // sum the numbers as they arrive so that we can
          // accept any size of file
          byteSource.via(Framing.delimiter(ByteString("\n"), 1024))
            .mapConcat(_.utf8String.split(",").toVector)
            .map(_.toInt)
            .runFold(0) { (acc, n) => acc + n }

        onSuccess(sumF) { sum => complete(s"Sum: $sum") }
    }
  }

// tests:
val multipartForm =
  Multipart.FormData(Multipart.FormData.BodyPart.Strict(
    "csv",
    HttpEntity(ContentTypes.`text/plain(UTF-8)`, "2,3,5\n7,11,13,17,23\n29,31,37\n"),
    Map("filename" -> "primes.csv")))

Post("/", multipartForm) ~> route ~> check {
  status shouldEqual StatusCodes.OK
  responseAs[String] shouldEqual "Sum: 178"
}


//example -dumps the uploaded file into a temporary file on disk, 
//collects some form fields and saves an entry to a fictive database:
val uploadVideo =
  path("video") {
    entity(as[Multipart.FormData]) { formData =>

      // collect all parts of the multipart as it arrives into a map
      val allPartsF: Future[Map[String, Any]] = formData.parts.mapAsync[(String, Any)](1) {

        case b: BodyPart if b.name == "file" =>
          // stream into a file as the chunks of it arrives and return a future
          // file to where it got stored
          val file = File.createTempFile("upload", "tmp")
          b.entity.dataBytes.runWith(FileIO.toPath(file.toPath)).map(_ =>
            (b.name -> file))

        case b: BodyPart =>
          // collect form field values
          b.toStrict(2.seconds).map(strict =>
            (b.name -> strict.entity.data.utf8String))

      }.runFold(Map.empty[String, Any])((map, tuple) => map + tuple)

      val done = allPartsF.map { allParts =>
        // You would have some better validation/unmarshalling here
        db.create(Video(
          file = allParts("file").asInstanceOf[File],
          title = allParts("title").asInstanceOf[String],
          author = allParts("author").asInstanceOf[String]))
      }

      // when processing have finished create a response for the user
      onSuccess(allPartsF) { allParts =>
        complete {
          "ok!"
        }
      }
    }
  }

//example -we accept any number of .csv files, parse those into lines and split each line 
//before we send it to an actor for further processing:
val splitLines = Framing.delimiter(ByteString("\n"), 256)

val csvUploads =
  path("metadata" / LongNumber) { id =>
    entity(as[Multipart.FormData]) { formData =>
      val done: Future[Done] = formData.parts.mapAsync(1) {
        case b: BodyPart if b.filename.exists(_.endsWith(".csv")) =>
          b.entity.dataBytes
            .via(splitLines)
            .map(_.utf8String.split(",").toVector)
            .runForeach(csv =>
              metadataActor ! MetadataActor.Entry(id, csv))
        case _ => Future.successful(Done)
      }.runWith(Sink.ignore)

      // when processing have finished create a response for the user
      onSuccess(done) { _ =>
        complete {
          "ok!"
        }
      }
    }
  }
      
      
      
///storeUploadedFile
def storeUploadedFile(fieldName: String, destFn: FileInfo => File): Directive[(FileInfo, File)]
//Streams the contents of a file uploaded as a multipart form into a file on disk and provides the file and metadata about the upload.

def tempDestination(fileInfo: FileInfo): File =
  File.createTempFile(fileInfo.fileName, ".tmp")

val route =
  storeUploadedFile("csv", tempDestination) {
    case (metadata, file) =>
      // do something with the file and file metadata ...
      file.delete()
      complete(StatusCodes.OK)
  }

// tests:
val multipartForm =
  Multipart.FormData(
    Multipart.FormData.BodyPart.Strict(
      "csv",
      HttpEntity(ContentTypes.`text/plain(UTF-8)`, "2,3,5\n7,11,13,17,23\n29,31,37\n"),
      Map("filename" -> "primes.csv")))

Post("/", multipartForm) ~> route ~> check {
  status shouldEqual StatusCodes.OK
}


///uploadedFile
def uploadedFile(fieldName: String): Directive1[(FileInfo, File)]
//Streams the contents of a file uploaded as a multipart form into a temporary file on disk 
//and provides the file and metadata about the upload.

val route =
  uploadedFile("csv") {
    case (metadata, file) =>
      // do something with the file and file metadata ...
      file.delete()
      complete(StatusCodes.OK)
  }

// tests:
val multipartForm =
  Multipart.FormData(
    Multipart.FormData.BodyPart.Strict(
      "csv",
      HttpEntity(ContentTypes.`text/plain(UTF-8)`, "2,3,5\n7,11,13,17,23\n29,31,37\n"),
      Map("filename" -> "primes.csv")))

Post("/", multipartForm) ~> route ~> check {
  status shouldEqual StatusCodes.OK
}

///storeUploadedFiles
def storeUploadedFiles(fieldName: String, destFn: FileInfo ? File): Directive1[immutable.Seq[(FileInfo, File)]]
//Streams the contents of all files uploaded in a multipart form into files on disk 
//and provides a list of each file and metadata about the upload.


def tempDestination(fileInfo: FileInfo): File =
  File.createTempFile(fileInfo.fileName, ".tmp")

val route =
  storeUploadedFiles("csv", tempDestination) { files =>
    val finalStatus = files.foldLeft(StatusCodes.OK) {
      case (status, (metadata, file)) =>
        // do something with the file and file metadata ...
        file.delete()
        status
    }

    complete(finalStatus)
  }

// tests:
val multipartForm =
  Multipart.FormData(
    Multipart.FormData.BodyPart.Strict(
      "csv",
      HttpEntity(ContentTypes.`text/plain(UTF-8)`, "2,3,5\n7,11,13,17,23\n29,31,37\n"),
      Map("filename" -> "primesA.csv")),
    Multipart.FormData.BodyPart.Strict(
      "csv",
      HttpEntity(ContentTypes.`text/plain(UTF-8)`, "41,43,47\n53,59,6167,71\n73,79,83\n"),
      Map("filename" -> "primesB.csv")))

Post("/", multipartForm) ~> route ~> check {
  status shouldEqual StatusCodes.OK
}
    
///fileUploadAll
def fileUploadAll(fieldName: String): Directive1[immutable.Seq[(FileInfo, Source[ByteString, Any])]]
//Simple access to streams of bytes for all files uploaded in a multipart form together 
//with metadata about each upload.
//If there is no field with the given name the request will be rejected.


// adding integers as a service
val route =
  extractRequestContext { ctx =>
    implicit val materializer = ctx.materializer

    fileUploadAll("csv") {
      case byteSources =>
        // accumulate the sum of each file
        val sumF: Future[Int] = byteSources.foldLeft(Future.successful(0)) {
          case (accF, (metadata, byteSource)) =>
            // sum the numbers as they arrive
            val intF = byteSource.via(Framing.delimiter(ByteString("\n"), 1024))
              .mapConcat(_.utf8String.split(",").toVector)
              .map(_.toInt)
              .runFold(0) { (acc, n) => acc + n }

            accF.flatMap(acc ? intF.map(acc + _))
        }

        onSuccess(sumF) { sum => complete(s"Sum: $sum") }
    }
  }

// tests:
val multipartForm =
  Multipart.FormData(
    Multipart.FormData.BodyPart.Strict(
      "csv",
      HttpEntity(ContentTypes.`text/plain(UTF-8)`, "2,3,5\n7,11,13,17,23\n29,31,37\n"),
      Map("filename" -> "primesA.csv")),
    Multipart.FormData.BodyPart.Strict(
      "csv",
      HttpEntity(ContentTypes.`text/plain(UTF-8)`, "41,43,47\n53,59,61,67,71\n73,79,83\n"),
      Map("filename" -> "primesB.csv")))

Post("/", multipartForm) ~> route ~> check {
  status shouldEqual StatusCodes.OK
  responseAs[String] shouldEqual "Sum: 855"
}    
    
 
      
///*** akka Http - Directives - RouteDirectives
//The RouteDirectives have a special role in akka-http�s routing DSL. 
//Contrary to all other directives (except most FileAndResourceDirectives) 
//they do not produce instances of type Directive[L <: HList] but rather �plain� routes of type Route. 

//hence forms the leaves of the actual route structure leaves.
    complete
    failWith
    redirect
    reject

///complete
//The signature shown is simplified, the real signature uses magnets
//http://spray.io/blog/2012-12-13-the-magnet-pattern/
def complete[T :ToResponseMarshaller](value: T): StandardRoute
def complete(response: HttpResponse): StandardRoute
def complete(status: StatusCode): StandardRoute
def complete[T :Marshaller](status: StatusCode, value: T): StandardRoute
def complete[T :Marshaller](status: Int, value: T): StandardRoute
def complete[T :Marshaller](status: StatusCode, headers: Seq[HttpHeader], value: T): StandardRoute
def complete[T :Marshaller](status: Int, headers: Seq[HttpHeader], value: T): StandardRoute

//Completes the request using the given argument(s).
//complete uses the given arguments to construct a Route 
//which simply calls complete on the RequestContext with the respective HttpResponse instance. 

val route =
  path("a") {
    complete(HttpResponse(entity = "foo"))
  } ~
    path("b") {
      complete(StatusCodes.OK)
    } ~
    path("c") {
      complete(StatusCodes.Created -> "bar")
    } ~
    path("d") {
      complete(201 -> "bar")
    } ~
    path("e") {
      complete(StatusCodes.Created, List(`Content-Type`(`text/plain(UTF-8)`)), "bar")
    } ~
    path("f") {
      complete(201, List(`Content-Type`(`text/plain(UTF-8)`)), "bar")
    } ~
    (path("g") & complete("baz")) // `&` also works with `complete` as the 2nd argument

// tests:
Get("/a") ~> route ~> check {
  status shouldEqual StatusCodes.OK
  responseAs[String] shouldEqual "foo"
}

Get("/b") ~> route ~> check {
  status shouldEqual StatusCodes.OK
  responseAs[String] shouldEqual "OK"
}

Get("/c") ~> route ~> check {
  status shouldEqual StatusCodes.Created
  responseAs[String] shouldEqual "bar"
}

Get("/d") ~> route ~> check {
  status shouldEqual StatusCodes.Created
  responseAs[String] shouldEqual "bar"
}

Get("/e") ~> route ~> check {
  status shouldEqual StatusCodes.Created
  header[`Content-Type`] shouldEqual Some(`Content-Type`(`text/plain(UTF-8)`))
  responseAs[String] shouldEqual "bar"
}

Get("/f") ~> route ~> check {
  status shouldEqual StatusCodes.Created
  header[`Content-Type`] shouldEqual Some(`Content-Type`(`text/plain(UTF-8)`))
  responseAs[String] shouldEqual "bar"
}

Get("/g") ~> route ~> check {
  status shouldEqual StatusCodes.OK
  responseAs[String] shouldEqual "baz"
}
    
///*** akka Http - Directives - FileAndResourceDirectives
//These directives, instead, are indeed instance of Route, 
//i.e. leaves of the route tree that handle a request themselves without passing it on to an inner route.
    getFromBrowseableDirectories
    getFromBrowseableDirectory
    getFromDirectory
    getFromFile
    getFromResource
    getFromResourceDirectory
    listDirectoryContents

///listDirectoryContents
def listDirectoryContents(directories: String*)(implicit renderer: DirectoryRenderer): Route
def getFromDirectory(directoryName: String)(implicit resolver: ContentTypeResolver): Route
def getFromBrowseableDirectories(directories: String*)(implicit renderer: DirectoryRenderer, resolver: ContentTypeResolver): Route
def getFromBrowseableDirectory(directory: String)(implicit renderer: DirectoryRenderer, resolver: ContentTypeResolver): Route
def getFromFile(fileName: String)(implicit resolver: ContentTypeResolver): Route
def getFromFile(file: File)(implicit resolver: ContentTypeResolver): Route
def getFromFile(file: File, contentType: ContentType): Route
def getFromResource(resourceName: String)(implicit resolver: ContentTypeResolver): Route
def getFromResource(resourceName: String, contentType: ContentType, classLoader: ClassLoader = _defaultClassLoader): Route
def getFromResourceDirectory(directoryName: String, classLoader: ClassLoader = _defaultClassLoader)(implicit resolver: ContentTypeResolver): Route


//listDirectoryContents: Completes GET requests with a unified listing of the contents of all given directories. 
//The actual rendering of the directory contents is performed by the in-scope Marshaller[DirectoryListing].

//To just serve files use getFromDirectory.

//To serve files and provide a browseable directory listing use getFromBrowseableDirectories instead.

//To serve a single file use getFromFile. 

//To serve browsable directory listings use getFromBrowseableDirectories. 

//To serve files from a classpath directory use getFromResourceDirectory instead.

//Note that it�s not required to wrap this directive with get as this directive will only respond to GET requests.
val route =
  path("tmp") {
    listDirectoryContents("/tmp")
  } ~
    path("custom") {
      // implement your custom renderer here
      val renderer = new DirectoryRenderer {
        override def marshaller(renderVanityFooter: Boolean): ToEntityMarshaller[DirectoryListing] = ???
      }
      listDirectoryContents("/tmp")(renderer)
    }

// tests:
Get("/logs/example") ~> route ~> check {
  responseAs[String] shouldEqual "example file contents"
}
//Example 

import akka.http.scaladsl.server.directives._
import ContentTypeResolver.Default

val route =
  path("logs" / Segment) { name =>
    getFromFile(s"$name.log") // uses implicit ContentTypeResolver
  }

// tests:
Get("/logs/example") ~> route ~> check {
  responseAs[String] shouldEqual "example file contents"
}
    
///*** akka Http - Directives - formFields(similar to parameters)
def formFields(field: <FieldDef[T]>): Directive1[T]
def formFields(fields: <FieldDef[T_i]>*): Directive[T_0 :: ... T_i ... :: HNil]
def formFields(fields: <FieldDef[T_0]> :: ... <FieldDef[T_i]> ... :: HNil): Directive[T_0 :: ... T_i ... :: HNil]

//Extracts fields from requests generated by HTML forms (independently of HttpMethod used).
"color"
    extract value of field �color� as String
"color".?
    extract optional value of field �color� as Option[String]
"color" ? "red"
    extract optional value of field �color� as String with default value "red"
"color" ! "blue"
    require value of field �color� to be "blue" and extract nothing
"amount".as[Int]
    extract value of field �amount� as Int, you need a matching implicit Unmarshaller in scope for that to work (see also Unmarshalling)
"amount".as(unmarshaller)
    extract value of field �amount� with an explicit Unmarshaller
"distance".*
    extract multiple occurrences of field �distance� as Iterable[String]
"distance".as[Int].*
    extract multiple occurrences of field �distance� as Iterable[Int], you need a matching implicit Unmarshaller in scope for that to work (see also Unmarshalling)
"distance".as(unmarshaller).*
    extract multiple occurrences of field �distance� with an explicit Unmarshaller

//can use Case Class Extraction to group several extracted values together into a case-class instance.
//Requests missing a required field or field value will be rejected with an appropriate rejection.

val route =
  formFields('color, 'age.as[Int]) { (color, age) =>
    complete(s"The color is '$color' and the age ten years ago was ${age - 10}")
  }

// tests:
Post("/", FormData("color" -> "blue", "age" -> "68")) ~> route ~> check {
  responseAs[String] shouldEqual "The color is 'blue' and the age ten years ago was 58"
}

Get("/") ~> Route.seal(route) ~> check {
  status shouldEqual StatusCodes.BadRequest
  responseAs[String] shouldEqual "Request is missing required form field 'color'"
}   
     
     
 
        
        
        
        
     
///*** Akka Http - Source Streaming

//Akka HTTP supports completing a request with an Akka Source[T, _], 
//ie  consume streaming end-to-end APIs which apply back pressure throughout the entire stack.

//eg  Source[ByteString, _], or  stream on an element-by-element basis eg JSON array, or CSV stream (where each element is separated by a newline).


///JSON Streaming - an infinite stream of tweets
case class Tweet(uid: Int, txt: String)
case class Measurement(id: String, value: Int)


object MyJsonProtocol extends akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport
            with spray.json.DefaultJsonProtocol {
  implicit val tweetFormat = jsonFormat2(Tweet.apply)
  implicit val measurementFormat = jsonFormat2(Measurement.apply)
}

val getTweets: Source[Tweet, NotUsed] = Source(
    Tweet("rolandkuhn", "#akka rocks!") ::
    Tweet("patriknw", "#akka !") ::
    Tweet("bantonsson", "#akka !") ::
    Tweet("drewhk", "#akka !") ::
    Tweet("ktosopl""#akka on the rocks!") ::
    Tweet("mmartynas", "wow #akka !") ::
    Tweet("akkateam", "#akka rocks!") ::
    Tweet("bananaman", "#bananas rock!") ::
    Tweet("appleman", "#apples rock!") ::
    Tweet("drama", "we compared #apples to #oranges!") ::  Nil)

  

// [1] import "my protocol", for marshalling Tweet objects:
import MyJsonProtocol._

// [2] pick a Source rendering support trait:
// Note that the default support renders the Source as JSON Array
implicit val jsonStreamingSupport: JsonEntityStreamingSupport = EntityStreamingSupport.json()

val route =
  path("tweets") {
    // [3] simply complete a request with a source of tweets:
    val tweets: Source[Tweet, NotUsed] = getTweets
    complete(tweets)
  }

// tests ------------------------------------------------------------
val AcceptJson = Accept(MediaRange(MediaTypes.`application/json`))
val AcceptXml = Accept(MediaRange(MediaTypes.`text/xml`))

Get("/tweets").withHeaders(AcceptJson) ~> route ~> check {
  responseAs[String] shouldEqual
    """[""" +
    """{"uid":1,"txt":"#Akka rocks!"},""" +
    """{"uid":2,"txt":"Streaming is so hot right now!"},""" +
    """{"uid":3,"txt":"You cannot enter the same river twice."}""" +
    """]"""
}

// endpoint can only marshal Json, so it will *reject* requests for application/xml:
Get("/tweets").withHeaders(AcceptXml) ~> route ~> check {
  handled should ===(false)
  rejection should ===(UnacceptedResponseContentTypeRejection(Set(ContentTypes.`application/json`)))
}

///to reconfigure the support trait to render the JSON line-by-line.
    import MyJsonProtocol._

    // Configure the EntityStreamingSupport to render the elements as:
    // {"example":42}
    // {"example":43}
    // ...
    // {"example":1000}
    val start = ByteString.empty
    val sep = ByteString("\n")
    val end = ByteString.empty

    implicit val jsonStreamingSupport = EntityStreamingSupport.json()
      .withFramingRenderer(Flow[ByteString].intersperse(start, sep, end))

    val route =
      path("tweets") {
        // [3] simply complete a request with a source of tweets:
        val tweets: Source[Tweet, NotUsed] = getTweets
        complete(tweets)
      }

    // tests ------------------------------------------------------------
    val AcceptJson = Accept(MediaRange(MediaTypes.`application/json`))

    Get("/tweets").withHeaders(AcceptJson) ~> route ~> check {
      responseAs[String] shouldEqual
        """{"uid":1,"txt":"#Akka rocks!"}""" + "\n" +
        """{"uid":2,"txt":"Streaming is so hot right now!"}""" + "\n" +
        """{"uid":3,"txt":"You cannot enter the same river twice."}"""
    }

///parallel marshalling-to marshal multiple elements of the stream in parallel

import MyJsonProtocol._
implicit val jsonStreamingSupport: JsonEntityStreamingSupport =
  EntityStreamingSupport.json()
    .withParallelMarshalling(parallelism = 8, unordered = false)

path("tweets") {
  val tweets: Source[Tweet, NotUsed] = getTweets
  complete(tweets)
}

//The above shown mode preserves ordering of the Source�s elements
//unordered rendering can be enabled via a configuration option 
import MyJsonProtocol._
implicit val jsonStreamingSupport: JsonEntityStreamingSupport =
  EntityStreamingSupport.json()
    .withParallelMarshalling(parallelism = 8, unordered = true)

path("tweets" / "unordered") {
  val tweets: Source[Tweet, NotUsed] = getTweets
  complete(tweets)
}

///Consuming JSON Streaming uploads
//to consume this data in a streaming fashion from the request entity 
//and also apply back pressure to the underlying TCP connection should the server be unable to cope with the rate of incoming data. 
//Back pressure is automatically applied thanks to Akka Streams.

// [1] import "my protocol", for unmarshalling Measurement objects:
import MyJsonProtocol._

// [2] enable Json Streaming
implicit val jsonStreamingSupport = EntityStreamingSupport.json()

// prepare your persisting logic here
val persistMetrics = Flow[Measurement]

val route =
  path("metrics") {
    // [3] extract Source[Measurement, _]
    entity(asSourceOf[Measurement]) { measurements =>
      // alternative syntax:
      // entity(as[Source[Measurement, NotUsed]]) { measurements =>
      val measurementsSubmitted: Future[Int] =
        measurements
          .via(persistMetrics)
          .runFold(0) { (cnt, _) => cnt + 1 }

      complete {
        measurementsSubmitted.map(n => Map("msg" -> s"""Total metrics received: $n"""))
      }
    }
  }

// tests ------------------------------------------------------------
// uploading an array or newline separated values works out of the box
val data = HttpEntity(
  ContentTypes.`application/json`,
  """
    |{"id":"temp","value":32}
    |{"id":"temp","value":31}
    |
  """.stripMargin)

Post("/metrics", entity = data) ~> route ~> check {
  status should ===(StatusCodes.OK)
  responseAs[String] should ===("""{"msg":"Total metrics received: 2"}""")
}

// the FramingWithContentType will reject any content type that it does not understand:
val xmlData = HttpEntity(
  ContentTypes.`text/xml(UTF-8)`,
  """|<data id="temp" value="32"/>
     |<data id="temp" value="31"/>""".stripMargin)

Post("/metrics", entity = xmlData) ~> route ~> check {
  handled should ===(false)
  rejection should ===(UnsupportedRequestContentTypeRejection(Set(ContentTypes.`application/json`)))
}



///CSV streaming example

// make sure that an implicit Marshaller of the requested type is available 

// [1] provide a marshaller to ByteString
implicit val tweetAsCsv = Marshaller.strict[Tweet, ByteString] { t =>
  Marshalling.WithFixedContentType(ContentTypes.`text/csv(UTF-8)`, () => {
    val txt = t.txt.replaceAll(",", ".")
    val uid = t.uid
    ByteString(List(uid, txt).mkString(","))
  })
}

// [2] enable csv streaming:
implicit val csvStreaming = EntityStreamingSupport.csv()

val route =
  path("tweets") {
    val tweets: Source[Tweet, NotUsed] = getTweets
    complete(tweets)
  }

// tests ------------------------------------------------------------
val AcceptCsv = Accept(MediaRange(MediaTypes.`text/csv`))

Get("/tweets").withHeaders(AcceptCsv) ~> route ~> check {
  responseAs[String] shouldEqual
    "1,#Akka rocks!" + "\n" +
    "2,Streaming is so hot right now!" + "\n" +
    "3,You cannot enter the same river twice."
}






///*** akka HTTP - HTTP client API


import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.stream.ActorMaterializer

import scala.concurrent.Future
import scala.util.{ Failure, Success }

object Client {
  def main(args: Array[String]): Unit = {
    implicit val system = ActorSystem()
    implicit val materializer = ActorMaterializer()
    // needed for the future flatMap/onComplete in the end
    implicit val executionContext = system.dispatcher

    val responseFuture: Future[HttpResponse] = Http().singleRequest(HttpRequest(uri = "http://akka.io"))

    responseFuture
      .onComplete {
        case Success(res) => println(res)
        case Failure(_)   => sys.error("something wrong")
      }
  }
}
    
//When using the Future based API from inside an Actor, 
//you should not access the actor�s state from within the Future�s callbacks (such as map, onComplete, �) 
//and instead ,use the pipeTo pattern to pipe the result back to the actor as a message


import akka.actor.{ Actor, ActorLogging }
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.stream.{ ActorMaterializer, ActorMaterializerSettings }
import akka.util.ByteString

class Myself extends Actor with ActorLogging {

  import akka.pattern.pipe
  import context.dispatcher

  final implicit val materializer: ActorMaterializer = ActorMaterializer(ActorMaterializerSettings(context.system))

  val http = Http(context.system)

  override def preStart() = {
    http.singleRequest(HttpRequest(uri = "http://akka.io")).pipeTo(self)
  }

  def receive = {
    case HttpResponse(StatusCodes.OK, headers, entity, _) =>
      entity.dataBytes.runFold(ByteString(""))(_ ++ _).foreach { body =>
        log.info("Got response, body: " + body.utf8String)
      }
    case resp @ HttpResponse(code, _, _, _) =>
      log.info("Request failed, response code: " + code)
      resp.discardEntityBytes()
  }

}

//Collecting headers from a server response
//Akka HTTP API provides a type for each HTTP header. 
//example -for getting all cookies set by a server ('Set-Cookie' type for corresponding header):

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.headers.`Set-Cookie`
import akka.http.scaladsl.model._
import akka.stream.ActorMaterializer

import scala.concurrent.ExecutionContextExecutor
import scala.concurrent.Future

object Client {
  def main(args: Array[String]): Unit = {
    implicit val system: ActorSystem = ActorSystem()
    implicit val materializer: ActorMaterializer = ActorMaterializer()
    implicit val executionContext: ExecutionContextExecutor = system.dispatcher

    val responseFuture: Future[HttpResponse] = Http().singleRequest(HttpRequest(uri = "http://akka.io"))

    responseFuture.map {
      case response @ HttpResponse(StatusCodes.OK, _, _, _) =>
        val setCookies = response.headers[`Set-Cookie`]
        println(s"Cookies set by a server: $setCookies")
        response.discardEntityBytes()
      case _ => sys.error("something wrong")
    }
  }
}

    