"""
Installation 11/4
    hadoop and spark only (no hive, use spark local hive at first)
    standalone app
        WordCount
    Scaling-up
        spark-submit
        yarn
        master/worker
    spark-shell/pyspark
DenseVector and SparseVector (mlib data types) 12/4
RDD Basics  13/4
DataFrames and operations  14/4
DataSource - csv, json, paraquet and Hive 17/4
Stats 18/4
    MLIB - basic, chisquare test 
ML(not MLIB) 
    General Flow 19/4
    Pipeline     19/4
    Feature extraction /seletion - Tokenizer, StringIndex,.., PCA  19/4
    Evaluator    20/4
    Classifications - Random Forest and Gradient Boost 21/4
    Regression - Random Forest and Gradient Boost    21/4
    Regression - LM and GLM  21/4    
    Clustering - KMeans  24/4
    Streaming - Kmeans   24/4
    Streaming - Regression 
"""


///*** Stage and Stage display means 

//A stage is a physical unit of execution. 
//A stage is a set of parallel tasks 
    //- one task per partition (of an RDD that computes partial results of a function executed as part of a Spark job).

//stage is uniquely identified by  id . 
//When a stage is created, DAGScheduler increments internal counter  nextStageId  to track the number of stage submissions.

//stage can only work on the partitions of a single RDD (identified by  rdd ), 
//but can be associated with many other dependent parent stages (via internal field  parents ), 
//with the boundary of a stage marked by shuffle dependencies.       
        
//Submitting a stage can therefore trigger execution of a series of dependent parent stages   
  
        
//There are two types of stages:
�ShuffleMapStage is an intermediate stage (in the execution DAG) that produces data for other stage(s). 
 It writes map output files for a shuffle. 
�ResultStage is the final stage that executes a Spark action in a user program by running a function on an RDD.


//Display means 
[Stage7:===========>                              (14174 + 5) / 62500]        
        
//Stage 7: shows the stage you are in now, 
//(14174 + 5) / 62500] is (numCompletedTasks + numActiveTasks) / totalNumOfTasksInThisStage 

//The progress bar shows numCompletedTasks / totalNumOfTasksInThisStage.

//shown when both spark.ui.showConsoleProgress is true (by default) 
//and log level in conf/log4j.properties is ERROR or WARN (!log.isInfoEnabled is true).
       
        
///* partition (aka split) is a logical chunk of a large distributed data set, called RDD (can be imagined as rows of Data ie Vector)  
//Spark manages data using partitions that helps parallelize distributed data processing 
//with minimal network traffic for sending data between executors.


//By default, Spark tries to read data into an RDD from the nodes that are close to it.
//By default, a partition is created for each HDFS partition, which by default is 64MB 
      
def getPartitions: Array[Partition]  //use method on a RDD to know the set of partitions in this         
     
//For example 
scala> sc.parallelize(1 to 100).count
res0: Long = 100 
//shows 4/4
//ie 4 Tasks in Total because it is a  4core laptop 
//and by default the number of partitions is the number of all available cores.     
        
//Manually modifying 
scala> val ints = sc.parallelize(1 to 100, 2)
ints: org.apache.spark.rdd.RDD[Int] = ParallelCollectionRDD[1] at parallelize at <console>:24

scala> ints.partitions.size
res2: Int = 2


//smaller/more numerous partitions allow work to be distributed among more workers, 
//but larger/fewer partitions allow work to be done in larger chunks, which may result in the work getting done more quickly as long as all workers are kept busy, due to reduced overhead.
        

//Spark can only run 1 concurrent task for every partition of an RDD, 
//up to the number of cores in your cluster. 

// you generally want at least as many as the number of executors for parallelism. 
//You can get this computed value by calling  sc.defaultParallelism .

 
//Modify the # of partitions to 400 
rdd = sc.textFile("hdfs://�?/file.txt", 400) 


//For compressed file, # of partion is always 1 as .gz etc can not work in parallel
//After reading change the partition via repartition or coalesce

def repartition(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T]
//repartition  is coalesce with  numPartitions  and  shuffle  enabled.      

def coalesce(numPartitions: Int, shuffle: Boolean = false)(implicit ord: Ordering[T] = null): RDD[T]

scala> val rdd = sc.parallelize(0 to 10, 8)
rdd: org.apache.spark.rdd.RDD[Int] = ParallelCollectionRDD[0] at parallelize at <console>:24

scala> rdd.partitions.size
res0: Int = 8

scala> rdd.coalesce(numPartitions=8, shuffle=false)   (1)
res1: org.apache.spark.rdd.RDD[Int] = CoalescedRDD[1] at coalesce at <console>:27

scala> res1.toDebugString
res2: String =
(8) CoalescedRDD[1] at coalesce at <console>:27 []
 |  ParallelCollectionRDD[0] at parallelize at <console>:24 []

scala> rdd.coalesce(numPartitions=8, shuffle=true)
res3: org.apache.spark.rdd.RDD[Int] = MapPartitionsRDD[5] at coalesce at <console>:27

scala> res3.toDebugString
res4: String =
(8) MapPartitionsRDD[5] at coalesce at <console>:27 []
 |  CoalescedRDD[4] at coalesce at <console>:27 []
 |  ShuffledRDD[3] at coalesce at <console>:27 []
 +-(8) MapPartitionsRDD[2] at coalesce at <console>:27 []
    |  ParallelCollectionRDD[0] at parallelize at <console>:24 []
      
      
      
      
      
///***** Installation and StandAlone applications ****/

///*** Hadoop and spark installation 
//Linux: https://hadoop.apache.org/docs/r2.7.3/hadoop-project-dist/hadoop-common/SingleCluster.html
//Windows 
//REF: https://mariuszprzydatek.com/2015/05/10/installing_hadoop_on_windows_8_or_8_1/

1. download binary from below 
//Windows Binary: https://github.com/karthikj1/Hadoop-2.7.1-Windows-64-binaries/releases/download/v2.7.1/hadoop-2.7.1.tar.gz
//spark : http://d3kbcqa49mib13.cloudfront.net/spark-1.4.1-bin-hadoop2.6.tgz

2. unzip hadoop to c:\hadoop and spark to c:\spark 

3. ENV var , HADOOP_HOME=c:\hadoop and SPARK_HOME=c:\spark
And add to PATH , c:\hadoop\bin;c:\hadoop\sbin;c:\spark\bin;c:\spark\sbin

4. Copy JDK to c:\hadoop\java eg to c:\hadoop\java\jdk1.8.0_65

5. Update below files in c:\hadoop\etc\hadoop - for pseudo cluster mode 
//hadoop-env.cmd: begining add and replace if existing 
set HADOOP_PREFIX=%HADOOP_HOME%
set JAVA_HOME=%HADOOP_HOME%\java\jdk1.8.0_65
set HADOOP_CONF_DIR=%HADOOP_PREFIX%\etc\hadoop
set YARN_CONF_DIR=%HADOOP_CONF_DIR%
set PATH=%PATH%;%HADOOP_PREFIX%\bin

//https://hadoop.apache.org/docs/r2.7.1/hadoop-project-dist/hadoop-common/SingleCluster.html
//Standalone Operation
//By default, Hadoop is configured to run in a non-distributed mode, 
//as a single Java process. This is useful for debugging.


//Pseudo-Distributed Operation 
//change core-site.xml , hdfs-site.xml etc(note below xml changes to default to yarn, hence start yarn)
//Hadoop can also be run on a single-node in a pseudo-distributed mode 
//where each Hadoop daemon runs in a separate Java process.

//all are in admin console 
//1.Format the filesystem:
  $ hdfs namenode -format

//2.Start NameNode daemon and DataNode daemon:
  $ start-dfs & start-yarn
  //start history server if required to check logs 
  $ mapred --config c:/hadoop/etc/hadoop historyserver
  //linux
  $ sbin/mr-jobhistory-daemon.sh --config $HADOOP_CONFIG_DIR start historyserver

//check all process started 
  $ jps 
  
//The hadoop daemon log output is written to the $HADOOP_LOG_DIR directory 
//(defaults to $HADOOP_HOME/logs).


//3.Browse the web interface for the NameNode; by default it is available at:
//?NameNode - http://localhost:50070/

///* Example of running mapReduce Job 
//4.Make the HDFS directories required to execute MapReduce jobs:
  $ hdfs dfs -mkdir /user
  $ hdfs dfs -mkdir /user/<username>

//5.Copy the input files into the distributed filesystem:
  $ cd  c:\hadoop
  $ hdfs dfs -put etc/hadoop input   //input means /user/das/input 
  $ hdfs dfs -ls input 
  $ hdfs dfs -ls hdfs://localhost:19000/user/das/input  //as per core-site.xml

//6.Run some of the examples provided:
  $ hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-*.jar grep input output "dfs[a-z.]+"



//7.Examine the output files: Copy the output files from the distributed filesystem to the local filesystem and examine them:
  $ hdfs dfs -get output output
  $ cat output/*
//or   */
  $ hdfs dfs -cat output/*

//8.When you�re done, stop the daemons with: */
  $ sop-yarn & stop-dfs

///All configuration files 
//hdfs-site.xml
<configuration>
  <property>
    <name>dfs.replication</name>
    <value>1</value>
  </property>
</configuration>
//core-site.xml
<configuration>
  <property>
    <name>fs.default.name</name>
    <value>hdfs://0.0.0.0:19000</value>
  </property>
</configuration>
//slaves - list of slaves 
localhost
//mapred-site.xml
<configuration>
  <property>
    <name>mapreduce.job.user.name</name>
    <value>das</value>
  </property>
  <property>
    <name>mapreduce.framework.name</name>
    <value>yarn</value>
  </property>
  <property>
    <name>yarn.apps.stagingDir</name>
    <value>/user/das/staging</value>
  </property>
  <property>
    <name>mapreduce.jobtracker.address</name>
    <value>local</value>
  </property>
  <property>
      <name>mapreduce.jobhistory.address</name>
      <value>localhost:10020</value>
    </property>    
    <property>
        <name>mapreduce.jobhistory.webapp.address</name>
        <value>localhost:19888</value>
    </property>
</configuration>
//yarn-site.xml
<configuration>
  <property>
    <name>yarn.server.resourcemanager.address</name>
    <value>0.0.0.0:8020</value>
  </property>
  <property>
    <name>yarn.server.resourcemanager.application.expiry.interval</name>
    <value>60000</value>
  </property>
  <property>
    <name>yarn.server.nodemanager.address</name>
    <value>0.0.0.0:45454</value>
  </property>
  <property>
    <name>yarn.nodemanager.aux-services</name>
    <value>mapreduce_shuffle</value>
  </property>
  <property>
    <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
    <value>org.apache.hadoop.mapred.ShuffleHandler</value>
  </property>
  <property>
    <name>yarn.server.nodemanager.remote-app-log-dir</name>
    <value>/app-logs</value>
  </property>
  <property>
    <name>yarn.nodemanager.log-dirs</name>
    <value>/dep/logs/userlogs</value>
  </property>
  <property>
         <name>yarn.log.server.url</name>
         <value>http://localhost:19888/jobhistory/logs</value>
  </property>
  <property>
    <name>yarn.server.mapreduce-appmanager.attempt-listener.bindAddress</name>
    <value>0.0.0.0</value>
  </property>
  <property>
    <name>yarn.server.mapreduce-appmanager.client-service.bindAddress</name>
    <value>0.0.0.0</value>
  </property>
  <property>
    <name>yarn.log-aggregation-enable</name>
    <value>true</value>
  </property>
  <property>
    <name>yarn.log-aggregation.retain-seconds</name>
    <value>-1</value>
  </property>
  <property>
    <name>yarn.application.classpath</name>
    <value>%HADOOP_CONF_DIR%,%HADOOP_HOME%/share/hadoop/common/*,%HADOOP_HOME%/share/hadoop/common/lib/*,%HADOOP_HOME%/share/hadoop/hdfs/*,%HADOOP_HOME%/share/hadoop/hdfs/lib/*,%HADOOP_HOME%/share/hadoop/mapreduce/*,%HADOOP_HOME%/share/hadoop/mapreduce/lib/*,%HADOOP_HOME%/share/hadoop/yarn/*,%HADOOP_HOME%/share/hadoop/yarn/lib/*,%SPARK_HOME%/lib/*</value>   <!-- */ -->
  </property>
  <property> 
      <name>yarn.nodemanager.delete.debug-delay-sec</name> 
      <value>600</value> 
  </property>

//Run an example YARN job 
cd  c:\hadoop
hadoop fs -mkdir  example
hadoop fs -put license.txt  example/
hadoop fs -ls example/
 
//Run an example YARN job 
yarn jar share\hadoop\mapreduce\hadoop-mapreduce-examples-*.jar wordcount example/license.txt out
 
9. Check delete 
hadoop fs -ls out
hadoop fs -rm -r -f  out




//Check the following pages in your browser: 
Resource Manager:  http://localhost:8088
Web UI of the NameNode daemon:  http://localhost:50070
HDFS NameNode web interface:  http://localhost:8042

///* Debugging
//To review per-container launch environment, 
//increase yarn.nodemanager.delete.debug-delay-sec to a large value (e.g. 36000), 
//yarn-site.xml
<property> 
      <name>yarn.nodemanager.delete.debug-delay-sec</name> 
      <value>3600</value> 
</property>
//then access the application cache through 
//yarn.nodemanager.local-dirs on the nodes on which containers are launched

//By default - yarn.nodemanager.local-dirs is ${hadoop.tmp.dir}/nm-local-dir ie c:/tmp/nm-local-dir

//An applications localized file directory will be found in: 
//${yarn.nodemanager.local-dirs}/usercache/${user}/appcache/application_${appid}. 
//Individual containers work directories, called container_${contid}, will be subdirectories of this. 

///* To leave safe mode (maintenance mode)
hdfs dfsadmin -safemode get
hdfs dfsadmin -safemode leave

//* check yarn logs 
//find application id from yarn-resourcemanager windows 
$ yarn logs -applicationId application_1487592307594_0001 > log.txt

//check logs from yarn.nodemanager.log-dirs of yarn-site.xml
//as per above it is c:/deps/logs/userlogs/...

//Linux: Setup passphraseless ssh

///* for linux to start all nodes
//must ssh to the localhost without a passphrase:
  $ ssh localhost
//If you cannot ssh to localhost without a passphrase, execute the following commands:
  $ ssh-keygen -t dsa -P '' -f ~/.ssh/id_dsa
  $ cat ~/.ssh/id_dsa.pub >> ~/.ssh/authorized_keys
  $ export HADOOP\_PREFIX=/usr/local/hadoop


  
  
///* Download spark and unzip 
//Starting version 2.0, Spark is built with Scala 2.11 by default. 

//do below (after creating new tmp\hive), Note spak-shell requires /tmp/hive at root 
//hence if you are starting at c:, then do below for c:\tmp\hive 
hadoop\bin\winutils.exe chmod 777 c:\tmp\hive 
//check at c:(where /tmp/hive is created)
$ spark-shell 



//Spark standalone cluster  setup 
//Master and worker start in admin console 
//start master (not same as Driver - Driver contains 'main' program of user)
//master assigns job to Worker/Executor when deploy-mode=client 
spark-class2 org.apache.spark.deploy.master.Master 

//logs 
Master: Starting Spark master at spark://192.168.1.2:7077
Master: Running Spark version 1.4.1
Utils: Successfully started service 'MasterUI' on port 8080.
Started MasterWebUI at http://192.168.1.2:8080


//worker/executor start , in all machines 
spark-class2 org.apache.spark.deploy.worker.Worker spark://192.168.1.2:7077 
//Repeat above for all the slaves nodes 

///*Logging 
//Edit  conf/log4j.properties file and change the following line:
log4j.rootCategory=INFO, console
//to
log4j.rootCategory=ERROR, console
//programatically , use sparkContext 's method 
def  setLogLevel(logLevel: String): Unit 
//logLevel  The desired log level as a string. Valid log levels include: ALL, DEBUG, ERROR, FATAL, INFO, OFF, TRACE, WARN




///*** Self-Contained Applications

///*scala 
//build.sbt 
organization := "com.das"

name := "project1"

scalaVersion := "2.11.8"

val sparkVersion="2.1.0"

libraryDependencies  ++= Seq(
  "org.apache.spark" %% "spark-core" % sparkVersion % "provided",
  "org.apache.spark" %% "spark-sql" % sparkVersion % "provided",
  "org.apache.spark" %% "spark-mllib" % sparkVersion % "provided",
  "org.apache.spark" %% "spark-streaming" % sparkVersion % "provided",
  "org.apache.spark" %% "spark-hive" % sparkVersion % "provided",
  "org.apache.spark" %% "spark-graphx" % sparkVersion % "provided",
  "org.apache.hadoop" % "hadoop-client" % "2.7.3" % "provided" //for accesing hdfs    
)

fork := true

assemblyJarName in assembly := "learning-assembly.jar"

assemblyOption in assembly := (assemblyOption in assembly).value.copy(includeScala = false)

assemblyMergeStrategy in assembly := {
  case PathList("javax", "servlet", xs @ _*)         => MergeStrategy.first
  case PathList(ps @ _*) if ps.last endsWith ".html" => MergeStrategy.first
  case "application.conf"                            => MergeStrategy.concat
  case "unwanted.txt"                                => MergeStrategy.discard
  case m if m.toLowerCase.endsWith("manifest.mf")    => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".rsa") 			 => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".dsa") 			 => MergeStrategy.discard
  case m if m.toLowerCase.endsWith(".sf") 			 => MergeStrategy.discard
  case _ 											 => MergeStrategy.first
}

//project/plugins.sbt 
addSbtPlugin("com.eed3si9n" % "sbt-assembly" % "0.13.0")
//src/main/examples/wordcount.scala 
package examples

import org.apache.spark._
import org.apache.spark.SparkContext._

object WordCount {
    def main(args: Array[String]) {
      val inputFile = "README"
      
      val conf = new SparkConf().setAppName("wordCount").setMaster("local[2]")
      // Create a Scala Spark Context.
      val sc = new SparkContext(conf)
      // Load our input data.
      val input =  sc.textFile(inputFile)
      // Split up into words.
      val words = input.flatMap(line => line.split(" "))
      // Transform into word and count.
      val counts = words.map(word => (word, 1)).reduceByKey{case (v1, v2) => v1 + v2} //same key, func for values 
      
      //print
      counts.collect().foreach(println)
    }
}
//Put README under root 

//run 
$ sbt console 
scala> import examples._ 
scala> WordCount.main(Array(" "))

///*Using spark submit 
//Remove setMaster from wordcount.scala 
//and access the file throught hdfs 

object WordCountSubmit {
    def main(args: Array[String]) {
      val inputFile = "hdfs://localhost:19000/user/das/README"
      
      val conf = new SparkConf().setAppName("wordCount")
      // Create a Scala Spark Context.
      val sc = new SparkContext(conf)
      // Load our input data.
      val input =  sc.textFile(inputFile)
      // Split up into words.
      val words = input.flatMap(line => line.split(" "))
      // Transform into word and count.
      val counts = words.map(word => (word, 1)).reduceByKey{case (v1, v2) => v1 + v2} //same key, func for values 
      
      //print
      counts.collect().foreach(println)
    }
}

//usage (sometimes assembly requires lot of space)
$ set SBT_OPTS="-Xmx2G"
$ sbt clean assembly 

$ hdfs dfs -put README  /user/das/README

//using spark submit 
spark-submit \
  --class <main-class> \
  --master <master-url> \
  --deploy-mode <deploy-mode> \
  --conf <key>=<value> \
  ... # other options
  <application-jar> \
  [application-arguments]
  

//Master URL
local     Run Spark locally with one worker thread (i.e. no parallelism at all).  
local[K]  Run Spark locally with K worker threads (ideally, set this to the number of cores on your machine).  
local[*]  Run Spark locally with as many worker threads as logical cores on your machine. 
spark://HOST:PORT  Connect to the given Spark standalone cluster master. The port must be whichever one your master is configured to use, which is 7077 by default.  
mesos://HOST:PORT  Connect to the given Mesos cluster. The port must be whichever one your is configured to use, which is 5050 by default. Or, for a Mesos cluster using ZooKeeper, use mesos://zk://.... To submit with --deploy-mode cluster, the HOST:PORT should be configured to connect to the MesosClusterDispatcher.  
yarn      Connect to a  YARN  cluster in client or cluster mode depending on the value of --deploy-mode. 
          The cluster location will be found based on the HADOOP_CONF_DIR or YARN_CONF_DIR variable 

//when deploy-mode is client, 
//You could run spark-submit on laptop, and the Driver Program would run on that laptop. 

//when deploy-mode is cluster, 
//then cluster manager (YARN, MESOS) is used to find a slave of yarn/mesos-cluster
//having enough available resources to execute the Driver Program. 
//As a result, the Driver Program would run on one of the slave nodes of that yarn/mesos-cluster
//As its execution is delegated, you can not get the result from Driver Program, 
//it must store its results in a file, database, etc

          
          
//Usage - local mode 
$ spark-submit --class examples.WordCountSubmit --master local[4] target/scala-2.11/learning-assembly.jar

///* In Master/workers mode (admin console)
$ spark-class2 org.apache.spark.deploy.master.Master 
$ spark-class2 org.apache.spark.deploy.worker.Worker spark://192.168.1.2:7077 

//usage - master/workr mode (localhost/127.0.0.1 etc does not work)
$ spark-submit --class examples.WordCountSubmit --master spark://192.168.1.2:7077 target/scala-2.11/learning-assembly.jar

///* Yarn mode 
$ set HADOOP_CONF_DIR=c:\hadoop\etc\hadoop\conf
$ spark-submit --class examples.WordCountSubmit  --master yarn --deploy-mode client target/scala-2.11/learning-assembly.jar

//check logs 
http://home-e402:8088/cluster/app/application_1491884936563_0005/ 
//get Application_id from spark-submit log


///* cluster mode, no stdout
$ spark-submit --class examples.WordCountSubmit  --master yarn --deploy-mode cluster target/scala-2.11/learning-assembly.jar

//so check output from 
http://home-e402:8088/cluster/app/application_1491884936563_0005/ 
//get Application_id from spark-submit log





///*** Few  ERRORs 
//*Error - Task is not serializable- 
//RDD[T] T must be Serializable
//And or any transformation function on RDD must use Serializable objects inside function
//Refer to RDD basics doc 
//


//*Error - below for memory consumed, hence increase overhead 
17/02/20 17:02:52 INFO scheduler.DAGScheduler: ResultStage 71 (collect at BinaryClassificationMetrics.scala:19
2) failed in 15.100 s due to org.apache.spark.shuffle.FetchFailedException: Connection from /192.168.1.2:32790
 closed
 
//solution
--conf spark.yarn.executor.memoryOverhead=1G
 
//*Error - Caused by multiple netty versions on classpath 
Caused by: java.lang.NoSuchMethodError: io.netty.channel.DefaultFileRegion.<init>(Ljava/io/File;JJ)V
Exclude netty jar from assembly 

//Solution - copy latest ie spark one to hadoop 
//Hadoop has nettry jar at 
./common/lib/netty-3.6.2.Final.jar
./hdfs/lib/netty-3.6.2.Final.jar
./mapreduce/lib/netty-3.6.2.Final.jar
./tools/lib/netty-3.6.2.Final.jar
./yarn/lib/netty-3.6.2.Final.jar
./httpfs/tomcat/webapps/webhdfs/WEB-INF/lib/netty-3.6.2.Final.jar
./httpfs/tomcat/webapps/webhdfs/WEB-INF/lib/netty-all-4.0.23.Final.jar
./kms/tomcat/webapps/kms/WEB-INF/lib/netty-3.6.2.Final.jar

//important one is 
./hdfs/lib/netty-all-4.0.23.Final.jar


//copy 
$ cd c:\hadoop
$ rm ./hdfs/lib/netty-all-4.0.23.Final.jar
$ cp c:\spark\jars\netty-all-4.0.42.Final.jar ./hdfs/lib/





///*** How to add jars 
//CHeck spark cluster concepts 
http://spark.apache.org/docs/latest/cluster-overview.html

//Spark applications run as independent sets of processes on a cluster, 
//coordinated by the SparkContext object in main program (called the driver program).

//The system currently supports three cluster managers:
�Standalone � a simple cluster manager included with Spark that makes it easy to set up a cluster.
�Apache Mesos � a general cluster manager that can also run Hadoop MapReduce and service applications.
�Hadoop YARN � the resource manager in Hadoop 2.


//When using spark-submit, 
//the application jar along with any jars included with the --jars option will be automatically transferred to the cluster. 
//URLs supplied after --jars must be separated by commas. T
//this list is included on the driver and executor classpaths(new in 2.1.0, earlier - NO)
//Directory expansion does not work with --jars.

//Spark uses the following URL scheme 
�file: - Absolute paths and file:/ URIs are served by the driver�s HTTP file server, and every executor pulls the file from the driver HTTP server.
�hdfs:, http:, https:, ftp: - these pull down files and JARs from the URI as expected
�local: - a URI starting with local:/ is expected to exist as a local file on each worker node. This means that no network IO will be incurred, and works well for large files/JARs that are pushed to each worker, or shared via NFS, GlusterFS, etc.


//before spark 2.0 , add all these options to get jars to Driver(main program) and Executor(worker)
spark-submit --jars additional1.jar,additional2.jar \
  --driver-class-path additional1.jar:additional2.jar \
  --conf spark.executor.extraClassPath=additional1.jar:additional2.jar \
  --class MyClass main-application.jar

//after spark 2.0 , --jars are added to driver and executor 
spark-submit --jars additional1.jar,additional2.jar \  
  --class MyClass main-application.jar 
  
  
  
  
  
//Properties set directly on the SparkConf take highest precedence, 
//then flags passed to spark-submit or spark-shell, 
//then options in the spark-defaults.conf file

//SparkContext also has below methods 
def  addFile(path: String, recursive: Boolean): Unit 
Add a file to be downloaded with this Spark job on every node. 
The path passed can be either a local file, a file in HDFS (or other Hadoop-supported filesystems), or an HTTP, HTTPS or FTP URI. To access the file in Spark jobs, use SparkFiles.get(fileName) to find its download location.
A directory can be given if the recursive option is set to true. 
Currently directories are only supported for Hadoop-supported filesystems. 

  
def  addFile(path: String): Unit 
Add a file to be downloaded with this Spark job on every node. 
The path passed can be either a local file, a file in HDFS (or other Hadoop-supported filesystems), or an HTTP, HTTPS or FTP URI. To access the file in Spark jobs, use SparkFiles.get(fileName) to find its download location. 

def  addJar(path: String): Unit 
Adds a JAR dependency for all tasks to be executed on this SparkContext in the future. 
The path passed can be either a local file, a file in HDFS (or other Hadoop-supported filesystems), an HTTP, HTTPS or FTP URI, or local:/path for a file on every worker node. 
equivalent to --jars 


  

///***** RDD ****/
///*** Basic operations 
//every Spark application consists of a driver program that runs the user�s main function (driver)
//and executes various parallel operations on a cluster(called executors on workers)


///* Resilient distributed dataset (RDD), 
//collection of elements/objects (eg STring, Vector, Matrix) partitioned across the nodes of the cluster that can be operated on in parallel. 


///* shared variables(broadcast and accumulators) that can be used in parallel operations. 
//By default, when Spark runs a function in parallel as a set of tasks on different nodes, 
//it ships a copy of each variable used in the function to each task. Hence sharing requires extra steps

//broadcast variables -which can be used to cache a value in memory on all nodes, 
//accumulators, which are variables that are only �added� to, such as counters and sums.



///* Initializing Spark
//add dependency of spark_core and hadoop_client for hdfs access

//Only one SparkContext may be active per JVM. 
//You must stop() the active SparkContext before creating a new one.

///*scala 
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
val conf = new SparkConf().setAppName(appName).setMaster(master)
sc = new SparkContext(conf)


///* master is a Spark, Mesos or YARN cluster URL, 
//or a special �local� string to run in local mode. 
//Note, standalone code must call setMaster(master), but via spark-submit , one passes via command line 
//Note spark-shell, pyspark, sparkR, spark-submit all share same command line args 


///*scala 
//Either start below or do sbt console with all dependencies 

$ ./bin/spark-shell --master local[4]

//Or, to also add code.jar to its classpath, use:
$ ./bin/spark-shell --master local[4] --jars code.jar

//To include a dependency using maven coordinates:
$ ./bin/spark-shell --master local[4] --packages "org.example:example:0.1"




@@@ http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.SparkContext
///*** org.apache.spark.SparkContext
//Only one SparkContext may be active per JVM. You must stop() the active SparkContext before creating a new one.

//constructor
new  SparkContext(master: String, appName: String, sparkHome: String = null, jars: Seq[String] = Nil, environment: Map[String, String] = Map()) 
new  SparkContext(master: String, appName: String, conf: SparkConf) 
new  SparkContext() 
new  SparkContext(config: SparkConf) 

//RDD creation 
def emptyRDD[T](implicit arg0: ClassTag[T]): RDD[T] 
def textFile(path: String, minPartitions: Int =defaultMinPartitions): RDD[String] 
def objectFile[T](path: String, minPartitions: Int =defaultMinPartitions)(implicit arg0: ClassTag[T]): RDD[T] 
def parallelize[T](seq: Seq[T], numSlices: Int =defultParallelism)(implicit arg0: ClassTag[T]): RDD[T] 
def range(start: Long, end: Long, step: Long = 1, numSlices: Int =defaultParallelism): RDD[Long] 
def makeRDD[T](seq: Seq[(T, Seq[String])])(implicit arg0: ClassTag[T]): RDD[T] 
def makeRDD[T](seq: Seq[T], numSlices: Int =defaultParallelism)(implicit arg0: ClassTag[T]): RDD[T] 
def union[T](first: RDD[T], rest: RDD[T]*)(implicit arg0: ClassTag[T]): RDD[T] 
def union[T](rdds: Seq[RDD[T]])(implicit arg0: ClassTag[T]): RDD[T] 
def wholeTextFiles(path: String, minPartitions: Int =defaultMinPartitions): RDD[(String, String)] 
//sequence file is hadoop file 
def sequenceFile[K, V](path: String, minPartitions: Int =defaultMinPartitions)(implicit km: ClassTag[K], vm: ClassTag[V], kcf: () => WritableConverter[K], vcf: () => WritableConverter[V]): RDD[(K, V)] 
def sequenceFile[K, V](path: String, keyClass: Class[K], valueClass: Class[V]): RDD[(K, V)] 
def sequenceFile[K, V](path: String, keyClass: Class[K], valueClass: Class[V], minPartitions: Int): RDD[(K, V)] 
def binaryFiles(path: String, minPartitions: Int =def aultMinPartitions): RDD[(String, PortableDataStream)] 
def binaryRecords(path: String, recordLength: Int, conf: Configuration = hadoopConfiguration): RDD[Array[Byte]] 
//smarter version of hadoop file 
def hadoopFile[K, V, F <: InputFormat[K, V]](path: String)(implicit km: ClassTag[K], vm: ClassTag[V], fm: ClassTag[F]): RDD[(K, V)] 
def hadoopFile[K, V, F <: InputFormat[K, V]](path: String, minPartitions: Int)(implicit km: ClassTag[K], vm: ClassTag[V], fm: ClassTag[F]): RDD[(K, V)] 
def hadoopFile[K, V](path: String, inputFormatClass: Class[_ <: InputFormat[K, V]], keyClass: Class[K], valueClass: Class[V], minPartitions: Int =defaultMinPartitions): RDD[(K, V)] 
def hadoopRDD[K, V](conf: JobConf, inputFormatClass: Class[_ <: InputFormat[K, V]], keyClass: Class[K], valueClass: Class[V], minPartitions: Int =defaultMinPartitions): RDD[(K, V)] 
def newAPIHadoopFile[K, V, F <: InputFormat[K, V]](path: String)(implicit km: ClassTag[K], vm: ClassTag[V], fm: ClassTag[F]): RDD[(K, V)] 
def newAPIHadoopRDD[K, V, F <: InputFormat[K, V]](conf: Configuration = hadoopConfiguration, fClass: Class[F], kClass: Class[K], vClass: Class[V]): RDD[(K, V)] 


//Spark can create distributed datasets from any storage source supported by Hadoop, 
//including local file system, HDFS, Cassandra, HBase, Amazon S3, etc. 
//Spark supports text files, SequenceFiles, and any other Hadoop InputFormat.


//Some notes on reading files with Spark:
�If using a path on the local filesystem, the file must also be accessible at the same path on worker nodes. 
Either copy the file to all workers or use a network-mounted shared file system 

�All of Spark�s file-based input methods, including textFile, 
support running on directories, compressed files, and wildcards as well. 
textFile("/my/directory"), 
textFile("/my/directory/*.txt")
textFile("/my/directory/*.gz")


�SparkContext.wholeTextFiles lets you read a directory containing multiple small text files, 
and returns each of them as (filename, content) pairs.
This is in contrast with textFile, which would return one record per line in each file.

�For SequenceFiles, use SparkContext�s sequenceFile[K, V] method 
where K and V are the types of key and values in the file. 
These should be subclasses of Hadoop�s Writable interface, like IntWritable and Text. 
In addition, Spark allows you to specify native types for a few common Writables; 
for example, sequenceFile[Int, String] will automatically read IntWritables and Texts.


�For other Hadoop InputFormats, you can use the SparkContext.hadoopRDD method, 
which takes an arbitrary JobConf and input format class, key class and value class.
Set these the same way you would for a Hadoop job with your input source. 
You can also use SparkContext.newAPIHadoopRDD for InputFormats based on the �new� MapReduce API (org.apache.hadoop.mapreduce).


�RDD.saveAsObjectFile and SparkContext.objectFile support saving an RDD in a simple format consisting of serialized Java objects. 
While this is not as efficient as specialized formats like Avro, it offers an easy way to save any RDD.



//Other Members of SparkContext 
def addFile(path: String, recursive: Boolean): Unit //to be downloaded with this Spark job on every node.
def addFile(path: String): Unit 
def addJar(path: String): Unit    //Adds a JAR dependency for all tasks to be executed on this SparkContext in the future.
def appName: String 
def applicationAttemptId: Option[String] 
def applicationId: String 
def broadcast[T](value: T)(implicit arg0: ClassTag[T]): Broadcast[T] 
def cancelAllJobs(): Unit 
def cancelJob(jobId: Int): Unit 
def cancelJobGroup(groupId: String): Unit 
def cancelStage(stageId: Int): Unit 
def clearCallSite(): Unit 
def clearJobGroup(): Unit 
def collectionAccumulator[T](name: String): CollectionAccumulator[T] 
def collectionAccumulator[T]: CollectionAccumulator[T] 
def defaultMinPartitions: Int 
def defaultParallelism: Int 
def deployMode: String 
def doubleAccumulator(name: String): DoubleAccumulator 
def doubleAccumulator: DoubleAccumulator 
def files: Seq[String] 
def getCheckpointDir: Option[String] 
def getConf: SparkConf 
def getExecutorMemoryStatus: Map[String, (Long, Long)] 
def getLocalProperty(key: String): String 
def getPersistentRDDs: Map[Int, RDD[_]] 
def getSchedulingMode: SchedulingMode 
def hadoopConfiguration: Configuration 
def isLocal: Boolean 
def isStopped: Boolean 
def jars: Seq[String] 
def listFiles(): Seq[String] 
def listJars(): Seq[String] 
def longAccumulator(name: String): LongAccumulator 
def longAccumulator: LongAccumulator 
def master: String 
def newAPIHadoopFile[K, V, F <: InputFormat[K, V]](path: String, fClass: Class[F], kClass: Class[K], vClass: Class[V], conf: Configuration = hadoopConfiguration): RDD[(K, V)] 
def register(acc: AccumulatorV2[_, _], name: String): Unit 
def register(acc: AccumulatorV2[_, _]): Unit 
def runJob[T, U](rdd: RDD[T], processPartition: (Iterator[T]) ? U, resultHandler: (Int, U) ? Unit)(implicit arg0: ClassTag[U]): Unit 
def runJob[T, U](rdd: RDD[T], processPartition: (TaskContext, Iterator[T]) ? U, resultHandler: (Int, U) ? Unit)(implicit arg0: ClassTag[U]): Unit 
def runJob[T, U](rdd: RDD[T], func: (Iterator[T]) ? U)(implicit arg0: ClassTag[U]): Array[U] 
def runJob[T, U](rdd: RDD[T], func: (TaskContext, Iterator[T]) ? U)(implicit arg0: ClassTag[U]): Array[U] 
def runJob[T, U](rdd: RDD[T], func: (Iterator[T]) ? U, partitions: Seq[Int])(implicit arg0: ClassTag[U]): Array[U] 
def runJob[T, U](rdd: RDD[T], func: (TaskContext, Iterator[T]) ? U, partitions: Seq[Int])(implicit arg0: ClassTag[U]): Array[U] 
def runJob[T, U](rdd: RDD[T], func: (TaskContext, Iterator[T]) ? U, partitions: Seq[Int], resultHandler: (Int, U) ? Unit)(implicit arg0: ClassTag[U]): Unit 
def setCallSite(shortCallSite: String): Unit 
def setCheckpointDir(directory: String): Unit 
def setJobDescription(value: String): Unit 
def setJobGroup(groupId: String, description: String, interruptOnCancel: Boolean = false): Unit 
def setLocalProperty(key: String, value: String): Unit 
def setLogLevel(logLevel: String): Unit 
val  sparkUser: String 
val  startTime: Long 
def statusTracker: SparkStatusTracker 
def stop(): Unit 
def submitJob[T, U, R](rdd: RDD[T], processPartition: (Iterator[T]) => U, partitions: Seq[Int], resultHandler: (Int, U) ? Unit, resultFunc: ? R): SimpleFutureAction[R] 
def uiWebUrl: Option[String] 
def version: String 



///* Resilient Distributed Datasets (RDDs) - creation 
//Typically you want 2-4 partitions for each CPU in your cluster. 
//create via parallelize or methods of reading textfile, json string etc 
//or indirectly via ML's DF read operations 

//RDD can not be printed, must need to collect() at first... but may fail if data is large 

///*scala 
import org.apache.spark._ 
import org.apache.spark.rdd._

val data = Array(1, 2, 3, 4, 5)
val distData = sc.parallelize(data) //RDD[Int], default number of partitions 
distData.reduce((a, b) => a + b)  //parallel operations 

sc.parallelize(data, 10) //with paritions 

val distFile = sc.textFile("../data/README")  //RDD[String] where String is each line 
distFile.map(s => s.length).reduce((a, b) => a + b) //total # of lines 

//The key and value classes can be specified, but for standard Writables this is not required.
val rdd = sc.parallelize((1 to 4).toSeq).map{ x => x ->  ("a" * x) } //K,V
rdd.saveAsSequenceFile("../data/file")              //hadoop sequence file, hence hadoop must be running 
sc.sequenceFile[Int,String]("../data/file").collect().sortBy( _._1)






///*** RDD Operations
//transformations, which create a new dataset from an existing one, 
//actions, which return a value to the driver program after running a computation on the dataset. 


@@@https://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.rdd.RDD
///*** org.apache.spark.rdd.RDD[T]
//Represents an immutable, partitioned collection of elements that can be operated on in parallel

//via implicits operations 
//org.apache.spark.rdd.PairRDDFunctions contains operations available only on RDDs of key-value pairs, such as groupByKey and join
//org.apache.spark.rdd.DoubleRDDFunctions contains operations available only on RDDs of Doubles
//org.apache.spark.rdd.SequenceFileRDDFunctions contains operations available on RDDs that can be saved as SequenceFiles

//RDD[T] methods 
def  ++(other: RDD[T]): RDD[T] 
def aggregate[U](zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U]): U  //general  reduce 
def cache(): RDD.this.type 
def cartesian[U](other: RDD[U])(implicit arg0: ClassTag[U]): RDD[(T, U)] 
def checkpoint(): Unit 

def coalesce(numPartitions: Int, shuffle: Boolean = false, partitionCoalescer: Option[PartitionCoalescer] = Option.empty)(implicit ord: Ordering[T] = null): RDD[T] //Return a new RDD that is reduced into numPartitions 
def collect[U](f: PartialFunction[T, U])(implicit arg0: ClassTag[U]): RDD[U] 
def collect(): Array[T] 

def context: SparkContext 
def count(): Long 
def max()(implicit ord: Ordering[T]): T 
def min()(implicit ord: Ordering[T]): T 

def countApprox(timeout: Long, confidence: Double = 0.95): PartialResult[BoundedDouble] 
def countApproxDistinct(relativeSD: Double = 0.05): Long 
def countApproxDistinct(p: Int, sp: Int): Long 
def countByValue()(implicit ord: Ordering[T] = null): Map[T, Long] 
def countByValueApprox(timeout: Long, confidence: Double = 0.95)(implicit ord: Ordering[T] = null): PartialResult[Map[T, BoundedDouble]] 

def dependencies: Seq[Dependency[_]] 
def distinct(): RDD[T]    //Return a new RDD containing the distinct elements in this RDD.
def distinct(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T] 

def filter(f: (T) => Boolean): RDD[T] 
def first(): T 
def flatMap[U](f: (T) => TraversableOnce[U])(implicit arg0: ClassTag[U]): RDD[U] 
def fold(zeroValue: T)(op: (T, T) => T): T 
def foreach(f: (T) => Unit): Unit 
def foreachPartition(f: (Iterator[T]) => Unit): Unit 

def getCheckpointFile: Option[String] 
def getNumPartitions: Int 
def getStorageLevel: StorageLevel 

def glom(): RDD[Array[T]]   //Return an RDD created by coalescing all elements within each partition into an array.  
def groupBy[K](f: (T) => K, p: Partitioner)(implicit kt: ClassTag[K], ord: Ordering[K] = null): RDD[(K, Iterable[T])] 
def groupBy[K](f: (T) => K, numPartitions: Int)(implicit kt: ClassTag[K]): RDD[(K, Iterable[T])] 
def groupBy[K](f: (T) => K)(implicit kt: ClassTag[K]): RDD[(K, Iterable[T])] 

val  id: Int 

def intersection(other: RDD[T], numPartitions: Int): RDD[T] 
def intersection(other: RDD[T], partitioner: Partitioner)(implicit ord: Ordering[T] = null): RDD[T] 
def intersection(other: RDD[T]): RDD[T] 

def isCheckpointed: Boolean 
def isEmpty(): Boolean 
def keyBy[K](f: (T) => K): RDD[(K, T)]  //Creates tuples of the elements in this RDD by applying f.
def localCheckpoint(): RDD.this.type 

def map[U](f: (T) => U)(implicit arg0: ClassTag[U]): RDD[U] 
def mapPartitions[U](f: (Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U]): RDD[U] 
def mapPartitionsWithIndex[U](f: (Int, Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U]): RDD[U] 
def reduce(f: (T, T) => T): T 


var name: String 
val partitioner: Option[Partitioner] 
def partitions: Array[Partition] 

def persist(): RDD.this.type 
def persist(newLevel: StorageLevel): RDD.this.type
//Return an RDD created by piping elements to a forked external process. 
def pipe(command: Seq[String], env: Map[String, String] = Map(), printPipeContext: ((String) => Unit) => Unit = null, printRDDElement: (T, (String) => Unit) => Unit = null, separateWorkingDir: Boolean = false, bufferSize: Int = 8192, encoding: String = Codec.defaultCharsetCodec.name): RDD[String] 
def pipe(command: String, env: Map[String, String]): RDD[String] 
def pipe(command: String): RDD[String] 

def preferredLocations(split: Partition): Seq[String] 
def randomSplit(weights: Array[Double], seed: Long = Utils.random.nextLong): Array[RDD[T]] 

def repartition(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T] 
def sample(withReplacement: Boolean, fraction: Double, seed: Long = Utils.random.nextLong): RDD[T] 

def saveAsObjectFile(path: String): Unit 
def saveAsTextFile(path: String, codec: Class[_ <: CompressionCodec]): Unit 
def saveAsTextFile(path: String): Unit 

def setName(_name: String): RDD.this.type 
def sortBy[K](f: (T) => K, ascending: Boolean = true, numPartitions: Int = this.partitions.length)(implicit ord: Ordering[K], ctag: ClassTag[K]): RDD[T] 
def sparkContext: SparkContext 

def subtract(other: RDD[T], p: Partitioner)(implicit ord: Ordering[T] = null): RDD[T] 
def subtract(other: RDD[T], numPartitions: Int): RDD[T] 
def subtract(other: RDD[T]): RDD[T] 

def take(num: Int): Array[T] 
def takeOrdered(num: Int)(implicit ord: Ordering[T]): Array[T] 
def takeSample(withReplacement: Boolean, num: Int, seed: Long = Utils.random.nextLong): Array[T] 

def toDebugString: String 
def toJavaRDD(): JavaRDD[T] 
def toLocalIterator: Iterator[T] 
def toString(): String 
def top(num: Int)(implicit ord: Ordering[T]): Array[T] 

def treeAggregate[U](zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U, depth: Int = 2)(implicit arg0: ClassTag[U]): U 
def treeReduce(f: (T, T) => T, depth: Int = 2): T 

def union(other: RDD[T]): RDD[T] 
def unpersist(blocking: Boolean = true): RDD.this.type 

def zip[U](other: RDD[U])(implicit arg0: ClassTag[U]): RDD[(T, U)] 
def zipWithIndex(): RDD[(T, Long)] 
def zipWithUniqueId(): RDD[(T, Long)] 
//Zip this RDDs partitions with one (or more) RDD(s) and return a new RDD by applying a function to the zipped partitions.
def zipPartitions[B, C, D, V](rdd2: RDD[B], rdd3: RDD[C], rdd4: RDD[D])(f: (Iterator[T], Iterator[B], Iterator[C], Iterator[D]) => Iterator[V])(implicit arg0: ClassTag[B], arg1: ClassTag[C], arg2: ClassTag[D], arg3: ClassTag[V]): RDD[V] 
def zipPartitions[B, C, D, V](rdd2: RDD[B], rdd3: RDD[C], rdd4: RDD[D], preservesPartitioning: Boolean)(f: (Iterator[T], Iterator[B], Iterator[C], Iterator[D]) => Iterator[V])(implicit arg0: ClassTag[B], arg1: ClassTag[C], arg2: ClassTag[D], arg3: ClassTag[V]): RDD[V] 
def zipPartitions[B, C, V](rdd2: RDD[B], rdd3: RDD[C])(f: (Iterator[T], Iterator[B], Iterator[C]) => Iterator[V])(implicit arg0: ClassTag[B], arg1: ClassTag[C], arg2: ClassTag[V]): RDD[V] 
def zipPartitions[B, C, V](rdd2: RDD[B], rdd3: RDD[C], preservesPartitioning: Boolean)(f: (Iterator[T], Iterator[B], Iterator[C]) => Iterator[V])(implicit arg0: ClassTag[B], arg1: ClassTag[C], arg2: ClassTag[V]): RDD[V] 
def zipPartitions[B, V](rdd2: RDD[B])(f: (Iterator[T], Iterator[B]) => Iterator[V])(implicit arg0: ClassTag[B], arg1: ClassTag[V]): RDD[V] 
def zipPartitions[B, V](rdd2: RDD[B], preservesPartitioning: Boolean)(f: (Iterator[T], Iterator[B]) => Iterator[V])(implicit arg0: ClassTag[B], arg1: ClassTag[V]): RDD[V] 

  
///* DoubleRDDFunctions
def  histogram(buckets: Array[Double], evenBuckets: Boolean = false): Array[Long] 
def  histogram(bucketCount: Int): (Array[Double], Array[Long]) 
def  mean(): Double 
def  meanApprox(timeout: Long, confidence: Double = 0.95): PartialResult[BoundedDouble] 
def  popStdev(): Double 
def  popVariance(): Double 
def  sampleStdev(): Double 
def  sampleVariance(): Double 
def  stats(): StatCounter 
def  stdev(): Double 
def  sum(): Double 
def  sumApprox(timeout: Long, confidence: Double = 0.95): PartialResult[BoundedDouble] 
def  variance(): Double 


///*scala 
val lines = sc.textFile("../data/README") //RDD[String]
val lineLengths = lines.map(s => s.length)  //RDD[Long]
val totalLength = lineLengths.reduce((a, b) => a + b) //action 
//If we also wanted to use lineLengths again later, we could add
//before the reduce, which would cause lineLengths to be saved in memory 
lineLengths.persist()




///*** RDD - Passing Functions in the driver program to run on the cluster. 
//IMP*** as functions must be serialized/pickled - else ERROR 

///*scala 
�Anonymous function syntax, which can be used for short pieces of code.
�Static methods in a global singleton object. 

object MyFunctions {
  def func1(s: String): String = { ... }
}

myRdd.map(MyFunctions.func1)

//NOTE: it is also possible to pass a reference to a method in a class instance 
//this requires sending the object that contains that class along with the method.
//hence class must be serializable  

class MyClass extends Serializable  {
  def func1(s: String): String = { ... }
  def doStuff(rdd: RDD[String]): RDD[String] = { rdd.map(func1) } //rdd.map(x => this.func1(x))
}
//accessing fields of the outer object will reference the whole object:
//Must implement Serializable
class MyClass extends Serializable  {
  val field = "Hello"
  def doStuff(rdd: RDD[String]): RDD[String] = { rdd.map(x => field + x) } //rdd.map(x => this.field + x)
}

//Alternatively,  copy field into a local variable 
//instead of accessing it externally, then no need to pass whole class 

def doStuff(rdd: RDD[String]): RDD[String] = {
  val field_ = this.field
  rdd.map(x => field_ + x)
}


///*** RDD - Understanding closures 
//RDD operations that MODIFY variables outside of their scope - WRONG, Use accumulators


//Consider the naive RDD element sum below, 
//which may behave differently depending on local mode (--master = local[n]) 
//versus deploying a Spark application to a cluster (e.g. via spark-submit to YARN)
//because in cluster mode - closure is serialized and sent to each executor.
//The variables within the closure sent to each executor are now copies 

///*scala 
var counter = 0
val data = Array(1, 2, 3, 4, 5)
var rdd = sc.parallelize(data)

// Wrong: Don't do this!!
rdd.foreach(x => counter += x)
println("Counter value: " + counter)


///*** RDD - Printing elements of an RDD

//in local mode, OK 
//in cluster mode - stdout is executer/another machines stdout, hence NOT_OK 
rdd.foreach(println) 
rdd.map(println)

//solution -  use the collect() method to first bring the RDD to the driver node thus: 
rdd.collect().foreach(println). 

//This can cause the driver to run out of memory- hence safer is to use take 
rdd.take(100).foreach(println).





///*** RDD - Working with Key-Value Pairs

//when using custom objects as the key in key-value pair operations, 
//you must be sure that a custom equals() method is accompanied with a matching hashCode() method. 

///*class  PairRDDFunctions[K, V] extends Logging with Serializable  

def aggregateByKey[U](zeroValue: U)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U]): RDD[(K, U)] 
def aggregateByKey[U](zeroValue: U, numPartitions: Int)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U]): RDD[(K, U)] 
def aggregateByKey[U](zeroValue: U, partitioner: Partitioner)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U]): RDD[(K, U)] 
def foldByKey(zeroValue: V)(func: (V, V) => V): RDD[(K, V)] 
def foldByKey(zeroValue: V, numPartitions: Int)(func: (V, V) => V): RDD[(K, V)] 
def foldByKey(zeroValue: V, partitioner: Partitioner)(func: (V, V) => V): RDD[(K, V)] 
def reduceByKey(func: (V, V) => V): RDD[(K, V)] 
def reduceByKey(func: (V, V) => V, numPartitions: Int): RDD[(K, V)] 
def reduceByKey(partitioner: Partitioner, func: (V, V) => V): RDD[(K, V)] 
def reduceByKeyLocally(func: (V, V) => V): Map[K, V] 
def collectAsMap(): Map[K, V] 

//For each key k in this or other1 or other2 or other3, return a resulting RDD that contains a tuple with the list of values for that key in this, other1, other2 and other3.
def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3]))] 
def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2]))] 
def cogroup[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W]))] 
def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)]): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2]))] 
def cogroup[W](other: RDD[(K, W)]): RDD[(K, (Iterable[V], Iterable[W]))] 
def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)]): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3]))] 
def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2]))] 
def cogroup[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W]))] 
def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3]))] 
//Alias for cogroup.
def groupWith[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)]): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3]))] 
def groupWith[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)]): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2]))] 
def groupWith[W](other: RDD[(K, W)]): RDD[(K, (Iterable[V], Iterable[W]))] 

def groupByKey(): RDD[(K, Iterable[V])] 
def groupByKey(numPartitions: Int): RDD[(K, Iterable[V])] 
def groupByKey(partitioner: Partitioner): RDD[(K, Iterable[V])] 

//Simplified version of combineByKeyWithClassTag
def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C): RDD[(K, C)] 
def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, numPartitions: Int): RDD[(K, C)] 
def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, partitioner: Partitioner, mapSideCombine: Boolean = true, serializer: Serializer = null): RDD[(K, C)] 
  
def subtractByKey[W](other: RDD[(K, W)], p: Partitioner)(implicit arg0: ClassTag[W]): RDD[(K, V)] 
def subtractByKey[W](other: RDD[(K, W)], numPartitions: Int)(implicit arg0: ClassTag[W]): RDD[(K, V)] 
def subtractByKey[W](other: RDD[(K, W)])(implicit arg0: ClassTag[W]): RDD[(K, V)] 

def countApproxDistinctByKey(relativeSD: Double = 0.05): RDD[(K, Long)] 
def countApproxDistinctByKey(relativeSD: Double, numPartitions: Int): RDD[(K, Long)] 
def countApproxDistinctByKey(relativeSD: Double, partitioner: Partitioner): RDD[(K, Long)] 
def countApproxDistinctByKey(p: Int, sp: Int, partitioner: Partitioner): RDD[(K, Long)] 
  
def countByKey(): Map[K, Long] 
def countByKeyApprox(timeout: Long, confidence: Double = 0.95): PartialResult[Map[K, BoundedDouble]] 

def flatMapValues[U](f: (V) => TraversableOnce[U]): RDD[(K, U)] 
def mapValues[U](f: (V) => U): RDD[(K, U)] 
def keys: RDD[K] 
def values: RDD[V] 
def lookup(key: K): Seq[V] 
def partitionBy(partitioner: Partitioner): RDD[(K, V)] 

def join[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (V, W))] 
def join[W](other: RDD[(K, W)]): RDD[(K, (V, W))] 
def join[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (V, W))] 
def fullOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Option[V], Option[W]))] 
def fullOuterJoin[W](other: RDD[(K, W)]): RDD[(K, (Option[V], Option[W]))] 
def fullOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Option[V], Option[W]))] 
def leftOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (V, Option[W]))] 
def leftOuterJoin[W](other: RDD[(K, W)]): RDD[(K, (V, Option[W]))] 
def leftOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (V, Option[W]))] 
def rightOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Option[V], W))] 
def rightOuterJoin[W](other: RDD[(K, W)]): RDD[(K, (Option[V], W))] 
def rightOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Option[V], W))] 

//Return a subset of this RDD sampled by key (via stratified sampling)
def sampleByKey(withReplacement: Boolean, fractions: Map[K, Double], seed: Long = Utils.random.nextLong): RDD[(K, V)] 
def sampleByKeyExact(withReplacement: Boolean, fractions: Map[K, Double], seed: Long = Utils.random.nextLong): RDD[(K, V)] 
  
def saveAsHadoopDataset(conf: JobConf): Unit 
def saveAsHadoopFile(path: String, keyClass: Class[_], valueClass: Class[_], outputFormatClass: Class[_ <: OutputFormat[_, _]], conf: JobConf = ..., codec: Option[Class[_ <: CompressionCodec]] = None): Unit 
def saveAsHadoopFile(path: String, keyClass: Class[_], valueClass: Class[_], outputFormatClass: Class[_ <: OutputFormat[_, _]], codec: Class[_ <: CompressionCodec]): Unit 
def saveAsHadoopFile[F <: OutputFormat[K, V]](path: String, codec: Class[_ <: CompressionCodec])(implicit fm: ClassTag[F]): Unit 
def saveAsHadoopFile[F <: OutputFormat[K, V]](path: String)(implicit fm: ClassTag[F]): Unit 
def saveAsNewAPIHadoopDataset(conf: Configuration): Unit 
def saveAsNewAPIHadoopFile(path: String, keyClass: Class[_], valueClass: Class[_], outputFormatClass: Class[_ <: OutputFormat[_, _]], conf: Configuration = self.context.hadoopConfiguration): Unit 
def saveAsNewAPIHadoopFile[F <: OutputFormat[K, V]](path: String)(implicit fm: ClassTag[F]): Unit 





///*** RDD - Transformations

map(func)                   Return a new distributed dataset formed by passing each element of the source through a function func.  
filter(func)                Return a new dataset formed by selecting those elements of the source on which func returns true.  
flatMap(func)               Similar to map, but each input item can be mapped to 0 or more output items (so func should return a Seq rather than a single item).  
mapPartitions(func)         Similar to map, but runs separately on each partition (block) of the RDD, so func must be of type Iterator<T> => Iterator<U> when running on an RDD of type T.  
mapPartitionsWithIndex(func)    Similar to mapPartitions, but also provides func with an integer value representing the index of the partition, so func must be of type (Int, Iterator<T>) => Iterator<U> when running on an RDD of type T.  
sample(withReplacement, fraction, seed)     Sample a fraction fraction of the data, with or without replacement, using a given random number generator seed.  
union(otherDataset)         Return a new dataset that contains the union of the elements in the source dataset and the argument.  
intersection(otherDataset)  Return a new RDD that contains the intersection of elements in the source dataset and the argument.  
distinct([numTasks]))       Return a new dataset that contains the distinct elements of the source dataset. 
groupByKey([numTasks])      When called on a dataset of (K, V) pairs, returns a dataset of (K, Iterable<V>) pairs. 
                            Note: If you are grouping in order to perform an aggregation (such as a sum or average) over each key, using reduceByKey or aggregateByKey will yield much better performance. 
                            Note: By default, the level of parallelism in the output depends on the number of partitions of the parent RDD. You can pass an optional numTasks argument to set a different number of tasks.  

reduceByKey(func, [numTasks])       When called on a dataset of (K, V) pairs, returns a dataset of (K, V) pairs where the values for each key are aggregated using the given reduce function func, which must be of type (V,V) => V. Like in groupByKey, the number of reduce tasks is configurable through an optional second argument.  
aggregateByKey(zeroValue)(seqOp, combOp, [numTasks])   When called on a dataset of (K, V) pairs, returns a dataset of (K, U) pairs where the values for each key are aggregated using the given combine functions and a neutral "zero" value. Allows an aggregated value type that is different than the input value type, while avoiding unnecessary allocations. Like in groupByKey, the number of reduce tasks is configurable through an optional second argument.  
sortByKey([ascending], [numTasks])  When called on a dataset of (K, V) pairs where K implements Ordered, returns a dataset of (K, V) pairs sorted by keys in ascending or descending order, as specified in the boolean ascending argument. 
join(otherDataset, [numTasks])      When called on datasets of type (K, V) and (K, W), returns a dataset of (K, (V, W)) pairs with all pairs of elements for each key. Outer joins are supported through leftOuterJoin, rightOuterJoin, and fullOuterJoin.  
cogroup(otherDataset, [numTasks])   When called on datasets of type (K, V) and (K, W), returns a dataset of (K, (Iterable<V>, Iterable<W>)) tuples. This operation is also called groupWith.  
cartesian(otherDataset)             When called on datasets of types T and U, returns a dataset of (T, U) pairs (all pairs of elements).  
pipe(command, [envVars])            Pipe each partition of the RDD through a shell command, e.g. a Perl or bash script. RDD elements are written to the process stdin and lines output to its stdout are returned as an RDD of strings.  
coalesce(numPartitions)             Decrease the number of partitions in the RDD to numPartitions. Useful for running operations more efficiently after filtering down a large dataset.  
repartition(numPartitions)          Reshuffle the data in the RDD randomly to create either more or fewer partitions and balance it across them. This always shuffles all data over the network.  
repartitionAndSortWithinPartitions(partitioner)  Repartition the RDD according to the given partitioner and, within each resulting partition, sort records by their keys. This is more efficient than calling repartition and then sorting within each partition because it can push the sorting down into the shuffle machinery.  



///*** RDD - Actions
//The Spark RDD API also exposes asynchronous versions of some actions, 
//like foreachAsync for foreach, which immediately return a FutureAction to the caller 
//instead of blocking on completion of the action. 
//This can be used to manage or wait for the asynchronous execution of the action.

reduce(func)    Aggregate the elements of the dataset using a function func (which takes two arguments and returns one). The function should be commutative and associative so that it can be computed correctly in parallel.  
collect()       Return all the elements of the dataset as an array at the driver program. This is usually useful after a filter or other operation that returns a sufficiently small subset of the data.  
count()         Return the number of elements in the dataset.  
first()         Return the first element of the dataset (similar to take(1)).  
take(n)         Return an array with the first n elements of the dataset.  
takeSample(withReplacement, num, [seed])  Return an array with a random sample of num elements of the dataset, with or without replacement, optionally pre-specifying a random number generator seed. 
takeOrdered(n, [ordering])  Return the first n elements of the RDD using either their natural order or a custom comparator.  
saveAsTextFile(path)        Write the elements of the dataset as a text file (or set of text files) in a given directory in the local filesystem, HDFS or any other Hadoop-supported file system. Spark will call toString on each element to convert it to a line of text in the file.  
saveAsSequenceFile(path)    Write the elements of the dataset as a Hadoop SequenceFile in a given path in the local filesystem, HDFS or any other Hadoop-supported file system. This is available on RDDs of key-value pairs that implement Hadoop Writable interface. In Scala, it is also available on types that are implicitly convertible to Writable (Spark includes conversions for basic types like Int, Double, String, etc).  
saveAsObjectFile(path)      Write the elements of the dataset in a simple format using Java serialization, which can then be loaded using SparkContext.objectFile().  
countByKey()                Only available on RDDs of type (K, V). Returns a hashmap of (K, Int) pairs with the count of each key.  
foreach(func)               Run a function func on each element of the dataset. This is usually done for side effects such as updating an Accumulator or interacting with external storage systems. 
                            Note: modifying variables other than Accumulators outside of the foreach() may result in undefined behavior. See Understanding closures  for more details. 



///*scala 
val lines = sc.textFile("../data/README")
val pairs = lines.map(s => (s, 1))
val counts = pairs.reduceByKey((a, b) => a + b)  //for same K, function for values 
counts.collect() 





///*** RDD - Shuffle operations
//The shuffle is Spark�s mechanism for re-distributing data so that it�s grouped differently across partitions. 
//This typically involves copying data across executors and machines, making the shuffle a complex and costly operation.

//Operations which can cause a shuffle include repartition operations 
//repartition and coalesce, �ByKey operations (except for counting) 
//groupByKey and reduceByKey, and join operations like cogroup and join.



//Although the set of elements in each partition of newly shuffled data will be deterministic, 
//and so is the ordering of partitions themselves, 
//the ordering of these elements is not. 
//If one desires predictably ordered data following shuffle then it�s possible to use:
�mapPartitions to sort each partition using, for example, .sorted
�repartitionAndSortWithinPartitions to efficiently sort partitions while simultaneously repartitioning
�sortBy to make a globally ordered RDD

//Certain shuffle operations can consume significant amounts of heap memory 
//since they employ in-memory data structures to organize records before or after transferring them
//Shuffle also generates a large number of intermediate files on disk










///*** RDD - Persistence

//You can mark an RDD to be persisted using the persist() or cache() methods on it. 
//The first time it is computed in an action, it will be kept in memory on the nodes.

//The cache() method is a shorthand for using the default storage level, which is StorageLevel.MEMORY_ONLY 

//The full set of storage levels is:
MEMORY_ONLY         Store RDD as deserialized Java objects in the JVM. If the RDD does not fit in memory, some partitions will not be cached and will be recomputed on the fly each time they are needed. This is the default level.  
MEMORY_AND_DISK     Store RDD as deserialized Java objects in the JVM. If the RDD does not fit in memory, store the partitions that don't fit on disk, and read them from there when they're needed.  
MEMORY_ONLY_SER     (Java and Scala)  Store RDD as serialized Java objects (one byte array per partition). This is generally more space-efficient than deserialized objects, especially when using a fast serializer, but more CPU-intensive to read.  
MEMORY_AND_DISK_SER (Java and Scala)  Similar to MEMORY_ONLY_SER, but spill partitions that don't fit in memory to disk instead of recomputing them on the fly each time they're needed.  
DISK_ONLY           Store the RDD partitions only on disk.  
MEMORY_ONLY_2, MEMORY_AND_DISK_2, etc.  Same as the levels above, but replicate each partition on two cluster nodes.  
OFF_HEAP (experimental)     Similar to MEMORY_ONLY_SER, but store the data in off-heap memory. This requires off-heap memory to be enabled.  

///* Which Storage Level to Choose

�If your RDDs fit comfortably with the default storage level (MEMORY_ONLY), leave them that way. 
This is the most CPU-efficient option, allowing operations on the RDDs to run as fast as possible.

�If not, try using MEMORY_ONLY_SER and selecting a fast serialization library to make the objects much more space-efficient, 
but still reasonably fast to access. (Java and Scala)

�Don�t spill to disk unless the functions that computed your datasets are expensive, 
or they filter a large amount of the data. 
Otherwise, recomputing a partition may be as fast as reading it from disk.

�Use the replicated storage levels if you want fast fault recovery 
(e.g. if using Spark to serve requests from a web application). 
All the storage levels provide full fault tolerance by recomputing lost data, 
but the replicated ones let you continue running tasks on the RDD without waiting to recompute a lost partition.


//Spark automatically monitors cache usage on each node 
//and drops out old data partitions in a least-recently-used (LRU) fashion. 
//OR use the RDD.unpersist() method.



///*** Shared Variables - Broadcast Variables

//Broadcast variables allow the programmer to keep a read-only variable cached 
//on each machine rather than shipping a copy of it with tasks. 

//Once created by Driver, it should be used(.value) in any functions that run on the cluster 

///*scala 
import org.apache.spark.rdd._
val broadcastVar = sc.broadcast(Array(1, 2, 3))
broadcastVar.value




///*** Shared Variables - Accumulators
//Accumulators are variables that are only �added� to through an associative and commutative operation 

//Spark natively supports accumulators of numeric types, 
//and programmers can add support for new types.

//Tracking accumulators in the UI can be useful for understanding the progress of running stages 




///* Use SparkContext.longAccumulator(), SparkContext.doubleAccumulator() to create by Driver 
//Tasks/functions running on a cluster can then add to it using the add method. 
//However, they cannot read its value. 
//Only the driver program can read the accumulator�s value, using its value method.

///*scala 
val accum = sc.longAccumulator("My Accumulator") //Driver
sc.parallelize(Array(1, 2, 3, 4)).foreach(x => accum.add(x))//Executor
accum.value  //res2: Long = 10 //Driver



///*User defined accumulator 

///*scala 
//The AccumulatorV2 abstract class has several methods which one has to override: 
//reset for resetting the accumulator to zero, 
//add for adding another value into the accumulator, 
//merge for merging another same-type accumulator into this one

//abstract  class  AccumulatorV2[IN, OUT] extends Serializable 
//that can accumulate inputs of type IN, and produce output of type OUT.
import org.apache.spark.util._
class VectorAccumulatorV2 extends AccumulatorV2[MyVector, MyVector] {

  private val myVector: MyVector = MyVector.createZeroVector

  def reset(): Unit = {
    myVector.reset()
  }

  def add(v: MyVector): Unit = {
    myVector.add(v)
  }
  def  copy(): AccumulatorV2[MyVector, MyVector] = {
  
  }
  def  isZero: Boolean = {
  
  }
  def  merge(other: AccumulatorV2[MyVector, MyVector]): Unit = {
  
  }
  def  value: MyVector = {
  
  }
}

// Then, create an Accumulator of this type:
val myVectorAcc = new VectorAccumulatorV2
// Then, register it into spark context:
sc.register(myVectorAcc, "MyVectorAcc1")




///*** Few More RDD Operations 
@@@ http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.rdd.RDD
http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.rdd.PairRDDFunctions
///*scala 

///* aggregate(zeroValue, seqOp, combOp)
//SeqOp is of (zerovalue_type,rdd_type)=> zerovalue_type 
//combOp is of (zerovalue_type, zerovalue_type) => zerovalue_type 
//result is RDD[zerovalue_type]
//go for curried version such that type inference works 

import org.apache.spark.rdd._
sc.parallelize(Array(1, 2, 3, 4)).aggregate( (0, 0) )( (x,y) => (x._1 + y, x._2 + 1),
                                                       (x, y) => (x._1 + y._1, x._2 + y._2))



///* cogroup(other, numPartitions=None)
//For each key k in self or other, 
//return a resulting RDD that contains a tuple with the list of values for that key in self as well as other.

val x = sc.parallelize(Array(("a", 1), ("b", 4)))
val y = sc.parallelize(Array(("a", 2)))
scala> x.cogroup(y).collect
res23: Array[(String, (Iterable[Int], Iterable[Int]))] = Array((a,(CompactBuffer(1),CompactBuffer(2))), (b,(CompactBuffer(4),CompactBuffer())))

for {
   (x, y) <- x.cogroup(y).collect.sortBy( _._1)
} yield {
  x -> (y._1.toList ++ y._2.toList)
}



///* combineByKey or combineByKeyWithClassTag(createCombiner, mergeValue, mergeCombiners, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
//Turns an RDD[(K, V)] into a result of type RDD[(K, C)], for a �combined type� C.
�createCombiner, which turns a V into a C (e.g., creates a one-element list)
�mergeValue, to merge C, V to C (e.g., adds it to the end of a list)
�mergeCombiners, to combine two C�s into a single one.
//V and C can be different � for example, one might group an RDD of type (Int, Int) into an RDD of type (Int, List[Int]).
 

val x = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
x.combineByKey( (x:Int) => x.toString , (x:String,y:Int) => x+y.toString , (x:String,y:String) => x+y ).collect
//Array((a,11), (b,1))


///* countByKey()
//Count the number of elements for each key, and return the result to the master as a dictionary.
val x = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
x.countByKey().toList.sortBy( _._2) //List[(String, Long)] = List((b,1), (a,2))
x.countByValue().toList.sortBy( _._2) //List[((String, Int), Long)] = List(((b,1),1), ((a,1),2))


///* join(other, numPartitions=None)
//Return an RDD containing all pairs of elements with matching keys in self and other.
//Each pair of elements will be returned as a (k, (v1, v2)) tuple, 
//where (k, v1) is in self and (k, v2) is in other.

val x = sc.parallelize(Array(("a", 1), ("b", 4)))
val y = sc.parallelize(Array(("a", 2), ("a", 3)))
x.join(y).collect.sortBy(_._1)  //Array((a,(1,2)), (a,(1,3)))


///* fullOuterJoin(other, numPartitions=None)
//Perform a right outer join of self and other.
//For each element (k, v) in self, the resulting RDD will either contain all pairs (k, (v, w)) for w in other, 
//or the pair (k, (v, None)) if no elements in other have key k.

//Similarly, for each element (k, w) in other, 
//the resulting RDD will either contain all pairs (k, (v, w)) for v in self, or the pair (k, (None, w)) if no elements in self have key k.

val x = sc.parallelize(Array(("a", 1), ("b", 4)))
val y = sc.parallelize(Array(("a", 2), ("a", 3)))
x.fullOuterJoin(y).collect
//Array[(String, (Option[Int], Option[Int]))] = Array((a,(Some(1),Some(2))), (a,(Some(1),Some(3))), (b,(Some(4),None)))


///* glom()
//Return an RDD created by coalescing all elements within each partition into a list.

val rdd = sc.parallelize(Array(1, 2, 3, 4), 2)
rdd.glom().collect //Array(Array(1, 2), Array(3, 4))


///* groupBy(f, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
//Return an PairRDDFunctions of grouped items.

val rdd = sc.parallelize(Array(1, 1, 2, 3, 5, 8))
rdd.groupBy((x) => x % 2).collect.map{ t => t._1 -> t._2.toList.sorted }.sortBy( _._1)
//res69: Array[(Int, List[Int])] = Array((0,List(2, 8)), (1,List(1, 1, 3, 5)))


///* groupByKey(numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
//Group the values for each key in the RDD into a single sequence
 
val x = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
x.groupByKey().mapValues{ _.size }.collect  // Array((a,2), (b,1))
x.groupByKey().mapValues(_.toList).collect //Array((a,List(1, 1)), (b,List(1)))


//* subtract(other, numPartitions=None)
//Return each value in self that is not contained in other.
val x = sc.parallelize(Array(("a", 1), ("b", 4), ("b", 5), ("a", 3)))
val y = sc.parallelize(Array(("a", 3), ("c", 5)))
x.subtract(y).collect  //Array((b,5), (b,4), (a,1))
x.intersection(y).collect  // Array((a,3))
x.union(y).collect  // Array((a,1), (b,4), (b,5), (a,3), (a,3), (c,5))



///* filter(f) and map(f) and reduceBykey
val rdd = sc.parallelize(Array(1, 2, 3, 4, 5,2,3))
rdd.filter((x) => x%2 == 0 ).map( (x) => (x,1) ).reduceByKey( (x,y) => x+y) .collect()
//res81: Array[(Int, Int)] = Array((4,1), (2,2))


///* mapPartitions(f, preservesPartitioning=False)
//Return a new RDD by applying a function(taking Iterator) to each partition of this RDD.
//f: (Iterator[T]) => Iterator[U]
val rdd = sc.parallelize(Array(1, 2, 3, 4), 2)
rdd.mapPartitions((itr) => itr.toList.map(x => x*x).toIterator).collect



///* sortBy(keyfunc, ascending=True, numPartitions=None)
//Sorts this RDD by the given keyfunc
val tmp = Array(('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5))
sc.parallelize(tmp).sortBy( x => x._1).collect()  //Array((1,3), (2,5), (a,1), (b,2), (d,4))




//* zip(other)
//Zips this RDD with another one, returning key-value pairs with the first element in each RDD second element in each RDD, etc. Assumes that the two RDDs have the same number of partitions and the same number of elements in each partition (e.g. one was made through a map on the other).
val x = sc.parallelize(0 to 5 )
val y = sc.parallelize(1000 to 1005 )
//collect can take partial function as well 
x.zip(y).collect{ case (x,y) if x > 2 => (x,y) }.collect
//Array((3,1003), (4,1004), (5,1005))

//* zipWithIndex()
//Zips this RDD with its element indices.

sc.parallelize(Array("a", "b", "c", "d"), 3).zipWithIndex().collect()
//Array[(String, Long)] = Array((a,0), (b,1), (c,2), (d,3))




///* saveAsTextFile(path, compressionCodecClass=None)
//Save this RDD as a text file, using string representations of elements.
�compressionCodecClass � (None by default) string i.e. �org.apache.hadoop.io.compress.GzipCodec�
 
val tempFile = java.io.File.createTempFile("tmp", ".tmp")
val rdd = sc.parallelize(0 to 10)
rdd.saveAsTextFile(tempFile.getName)
sc.textFile(tempFile.getName).collect
//res95: Array[String] = Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
val tempFile = java.io.File.createTempFile("tmp", ".tmp")
tempFile.deleteOnExit()
rdd.saveAsObjectFile(tempFile.getName) 
val d2 = sc.objectFile[String](tempFile.getName)










///***** DataFrame (ML) ****/
@@@ sql-programming-guide.md
http://spark.apache.org/docs/latest/sql-programming-guide.html
///*** Datasets and DataFrames
//A Dataset is a distributed collection of data (not available in Python) built on RDD 
// Can be manipulated using functional transformations (map, flatMap, filter, etc.). 

//A DataFrame is a Dataset organized into named columns(available in python, like pandas.DataFrame)
//DataFrame is simply a type alias of Dataset[Row](in scala) 

///*  SparkSession
//As of Spark 2.0, SQLContext is replaced by SparkSession
//builder methods 
def  appName(name: String): Builder 
def  config(conf: SparkConf): Builder 
def  config(key: String, value: Boolean): Builder 
def  config(key: String, value: Double): Builder 
def  config(key: String, value: Long): Builder 
def  config(key: String, value: String): Builder 
def  enableHiveSupport(): Builder 
def  getOrCreate(): SparkSession 
def  master(master: String): Builder 

///*scala 
import org.apache.spark.sql.SparkSession

val spark = SparkSession
  .builder()
  .appName("Spark SQL basic example")
  .config("spark.some.config.option", "some-value")
  .getOrCreate()

// For implicit conversions like converting RDDs to DataFrames
import spark.implicits._


    
    
///*** sql types 
//All data types of Spark SQL are located in the package org.apache.spark.sql.types. 

import org.apache.spark.sql.types._




///***NaN Semantics
//There is specially handling for not-a-number (NaN) when dealing with float or double types that does not exactly match standard floating point semantics. 
�NaN = NaN returns true.
�In aggregations all NaN values are grouped together.
�NaN is treated as a normal value in join keys.
�NaN values go last when in ascending order, larger than any other numeric value.



///*** UDF registration - Userdefined function to operate on DF columns 
//Always use UDF to convert a COlumn into a new COumn 

///*scala 
sparkSession.udf.register("myUDF", (arg1: Int, arg2: String) => arg2 + arg1)


//OR to convert to DenseVector 
import org.apache.spark.sql.functions._
import org.apache.spark.ml.linalg._
val asDense = udf((v: SparseVector) => v.toDense)
val rescaledData = indexedData.withColumn("vd", asDense(col("indexed")))

///*** Getting a specefic row of DF 
//Not straight forward as DF are distributed 
//Getting a named column is df.select("colname")

df = spark.createDataFrame([("a", 1), ("b", 2), ("c", 3)], ["letter", "name"])
myIndex = 1
values = (df.rdd.zipWithIndex()
            .filter(lambda ((l, v), i): i == myIndex)
            .map(lambda ((l,v), i): (l, v))
            .collect())

print(values[0])
# (u'b', 2)

//Below selects all columns from dataframe df 
//which has the column name mentioned in the Array colNames:
df = df.select(colNames.head,colNames.tail: _*)

//for index ,  colNos array which has following index 
colNos = Array(10,20,25,45)

import org.apache.spark.sql.functions._

df.select(colNos map df.columns map col: _*)

//or:
df.select(colNos map (df.columns andThen col): _*)

//or:
df.select(colNos map (col _ compose df.columns): _*)

//basically for single column index 
df.select(col(df.columns(index)))


///*** Using Row 
//A row in DataFrame 

//object Row 
def apply(values: Any*): Row 
val  empty: Row 
def  fromSeq(values: Seq[Any]): Row 
def fromTuple(tuple: Product): Row 
def  merge(rows: Row*): Row 
def  unapplySeq(row: Row): Some[Seq[Any]] 

//Row 
def copy(): Row 
def  get(i: Int): Any 
def  length: Int 
def  apply(i: Int): Any 
def  equals(o: Any): Boolean 
def  fieldIndex(name: String): Int  //with schema 
def  getAs[T](fieldName: String): T 
def  getAs[T](i: Int): T 
def  getBoolean(i: Int): Boolean 
def  getByte(i: Int): Byte 
def  getDate(i: Int): Date 
def  getDecimal(i: Int): BigDecimal 
def  getDouble(i: Int): Double 
def  getFloat(i: Int): Float 
def  getInt(i: Int): Int 
def  getJavaMap[K, V](i: Int): java.util.Map[K, V] 
def  getList[T](i: Int): List[T] 
def  getLong(i: Int): Long 
def  getMap[K, V](i: Int): Map[K, V] 
def  getSeq[T](i: Int): Seq[T] 
def  getShort(i: Int): Short 
def  getString(i: Int): String 
def  getStruct(i: Int): Row 
def  getTimestamp(i: Int): Timestamp 
def  getValuesMap[T](fieldNames: Seq[String]): Map[String, T] 
def  hashCode(): Int 
def  isNullAt(i: Int): Boolean 
def  mkString(start: String, sep: String, end: String): String 
def  mkString(sep: String): String 
def  mkString: String 
def  schema: StructType 
def  size: Int 
def  toSeq: Seq[Any] 
def  toString(): String 

// The following is a mapping between Spark SQL types and return types: 
   BooleanType -> java.lang.Boolean
   ByteType -> java.lang.Byte
   ShortType -> java.lang.Short
   IntegerType -> java.lang.Integer
   FloatType -> java.lang.Float
   DoubleType -> java.lang.Double
   StringType -> String
   DecimalType -> java.math.BigDecimal

   DateType -> java.sql.Date
   TimestampType -> java.sql.Timestamp

   BinaryType -> byte array
   ArrayType -> scala.collection.Seq (use getList for java.util.List)
   MapType -> scala.collection.Map (use getJavaMap for java.util.Map)
   StructType -> org.apache.spark.sql.Row


   

///*scala 
// Create a Row from values.
Row(value1, value2, value3, ...)
// Create a Row from a Seq of values.
Row.fromSeq(Seq(value1, value2, ...))

//accesing 
import org.apache.spark.sql._

val row = Row(1, true, "a string", null)
// row: Row = [1,true,a string,null]
val firstValue = row(0)
// firstValue: Any = 1
val fourthValue = row(3)
// fourthValue: Any = null


val firstValue = row.getInt(0)
// firstValue: Int = 1
val isNull = row.isNullAt(3)
// isNull: Boolean = true

import org.apache.spark.sql._

val pairs = sql("SELECT key, value FROM src").rdd.map {
  case Row(key: Int, value: String) =>
    key -> value
}

///* StructType 
//A StructType object can be constructed by
StructType(fields: Seq[StructField])
//Note StructType Seq[StructField], so all Seq methods can be used 
//StructField 
name    The name of this field.
dataType    The data type of this field.
nullable    Indicates if values of this field can be null values.


//example 
import org.apache.spark.sql._
import org.apache.spark.sql.types._

val struct =  StructType(
    StructField("a", IntegerType, true) ::
    StructField("b", LongType, false) ::
    StructField("c", BooleanType, false) :: Nil)

// Extract a single StructField.
val singleField = struct("b")
// singleField: StructField = StructField(b,LongType,false)
val twoFields = struct(Set("b", "c"))
// twoFields: StructType =
//   StructType(List(StructField(b,LongType,false), StructField(c,BooleanType,false)))


//with Schema.. Note SChema is extensively used for DF, not for a Row 
//class GenericRowWithSchema(values: Array[Any], override val schema: StructType)

import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
val newRow = new GenericRowWithSchema(Array(1,2L,true), struct)
newRow.getAs[Long]("b")








///*** Creation of DF 
//With a SparkSession, applications can create DataFrames from an existing RDD, from a Hive table, or from Spark data sources

///*scala 
//using sparkSession.read methods 
val df = spark.read.json("../data/people.json")

// Displays the content of the DataFrame to stdout
df.show()

//debug, opening files 
val lines = scala.io.Source.fromFile(raw"D:\Desktop\PPT\spark\data\student-mat.csv").getLines.toList


//def  createDataFrame(rows: java.util.List[Row], schema: StructType): DataFrame
//def  createDataFrame(rowRDD: RDD[Row], schema: StructType): DataFrame 
//for case class 
//def  createDataFrame[A <: Product](data: Seq[A])(implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[A]): DataFrame
//def  createDataFrame[A <: Product](rdd: RDD[A])(implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[A]): DataFrame 
//Creates a DataFrame from an RDD/Seq of Product (e.g. case classes, tuples). 
//Note dataframe can not be created from Seq of Array,List etc as those do not extend Product
//Package under Tuple 


//Displaying DataFrame - Note various options of show 
def  show(numRows: Int, truncate: Int): Unit 
def  show(numRows: Int, truncate: Boolean): Unit 
def  show(truncate: Boolean): Unit 
def  show(): Unit   //Displays the top 20 rows of Dataset in a tabular form.
def  show(numRows: Int): Unit 

//to display all columns and all rows use 
show(Int.MaxValue, false)

//Note case class can only have 22 attributes, for more , create manually extending Product (checK examples )
case class Record(key: Int, value: String)
val recordsDF = spark.createDataFrame((1 to 100).map(i => Record(i, s"val_$i")))
recordsDF.show()

//Using Row 
import org.apache.spark.sql._
import org.apache.spark.sql.types._

val sparkSession = SparkSession.builder.appName("Dummy").getOrCreate()

val schema = StructType(
    StructField("name", StringType, false) ::
    StructField("age", IntegerType, true) :: Nil)

val people = sc.textFile("./data/people.txt").map(_.split(",")).map(p => Row(p(0), p(1).trim.toInt))
val dataFrame = sparkSession.createDataFrame(people, schema)
dataFrame.printSchema
dataFrame.show
// root
// |-- name: string (nullable = false)
// |-- age: integer (nullable = true)


///creation of DataSet 

case class Person(name: String, age: Long)
val data = Seq(Person("Michael", 29), Person("Andy", 30), Person("Justin", 19))
val ds = spark.createDataset(data)

ds.show()
// +-------+---+
// |   name|age|
// +-------+---+
// |Michael| 29|
// |   Andy| 30|
// | Justin| 19|
// +-------+---+

  



///*** DF - Convesion from RDDs
//Spark SQL supports two different methods for converting existing RDDs into Datasets
//METHOD-1 :Inferring the Schema Using Reflection

//RDD[T] and  Seq[T]) has below via sparkSession.implicits._
def  toDF(colNames: String*): DataFrame 
def  toDF(): DataFrame 
def  toDS(): Dataset[T] 

//Note T must be converted to Encoder[T] implictly 
//check which T has that, http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.SparkSession$implicits$
//eg primitives, Array, Seq and Case class (class extends Product)


///*scala 
// Create an RDD of Person objects from a text file, convert it to a Dataframe

//spark is sparkSession 

import spark.implicits._  //toDF()
import org.apache.spark.sql._
import org.apache.spark.sql.types._
case class Person(name: String, age: Long)
val peopleDF = spark.sparkContext
  .textFile("./data/people.txt")
  .map(_.split(","))
  .map(attributes => Person(attributes(0), attributes(1).trim.toInt))
  .toDF()




//METHOD-2: Programmatically Specifying the Schema

///*scala 
// Create an RDD

import spark.implicits._
val peopleRDD = spark.sparkContext.textFile("./data/people.txt")
// The schema is encoded in a string
val schemaString = "name age"
// Generate the schema based on the string of schema
val fields = schemaString.split(" ").map(fieldName => StructField(fieldName, StringType, nullable = true)).toList
val schema = StructType(fields)
// Convert records of the RDD (people) to Rows
val rowRDD = peopleRDD
  .map(_.split(","))
  .map(attributes => Row(attributes(0), attributes(1).trim))
// Apply the schema to the RDD
val peopleDF = spark.createDataFrame(rowRDD, schema)  //toDF does not work for Row as Row does not have implicit Encoder 



///***Usage of Column and DF operations 
//Column : A column in a DataFrame.

///*scala 
//org.apache.spark.sql.Column

//Columns have +, -, like, and many operations , check http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.Column
//Also column can take any functions defined in http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$


//A new column is constructed based on the input columns present in a dataframe:
import spark.implicits._   //for conversion from $"col" to Column
df("columnName")            // On a specific DataFrame.
col("columnName")           // A generic column no yet associated with a DataFrame.
col("columnName.field")     // Extracting a struct field
col("`a.column.with.dots`") // Escape `.` in column names.
$"columnName"               // Scala short hand for a named column.
expr("a + 1")               // A column that is constructed from a parsed SQL Expression.
lit("abc")                  // A column that produces a literal (constant) value.

//Column objects can be composed to form complex expressions:
$"a" + 1
$"a" === $"b"  //for equality 
// Example: encoding gender string column into integer.
//select(col: String,cols: String*)
//select(cols: org.apache.spark.sql.Column*)
//def  when(condition: Column, value: Any): Column 
//def  otherwise(value: Any): Column 
peopleDF.select(when(peopleDF("name") === "Michael", 0)
  .when(peopleDF("name") === "Andy", 1)
  .otherwise(2).alias("cond"), peopleDF("age")).show()




///* trait  Encoder[T] extends Serializable  
//Used to convert a JVM object of type T to and from the internal Spark SQL representation.

//Encoders are generally created automatically through implicits from a SparkSession, 
//or can be explicitly created by calling static methods on Encoders.
import spark.implicits._
val ds = Seq(1, 2, 3).toDS() // implicitly provided (spark.implicits.newIntEncoder)

//Encoders are specified by calling static methods on Encoders.
implicit val listEncoder = org.apache.spark.sql.Encoders.kryo[List[String]]
val data = List("abc", "abc", "xyz")
val ds = spark.createDataset(data)
val ds = spark.createDataFrame(data)

//Encoders can be composed into tuples:
import org.apache.spark.sql._

implicit val encoder2 = Encoders.tuple(Encoders.INT, Encoders.STRING)
val data2 = List( (1, "a") )
val ds2 = spark.createDataset(data2)
val ds2 = spark.createDataFrame(data2)

//Or constructed from Java Beans:
implicit val encoder3 =  Encoders.bean(MyClass.class)
//now List/Seq/RDD of MyClass can be converted to DataSet/DataFrame



//Encoders.
def  BINARY: Encoder[Array[Byte]] 
def  BOOLEAN: Encoder[Boolean] 
def  BYTE: Encoder[Byte] 
def  DATE: Encoder[Date] 
def  DECIMAL: Encoder[BigDecimal] 
def  DOUBLE: Encoder[Double] 
def  FLOAT: Encoder[Float] 
def  INT: Encoder[Integer] 
def  LONG: Encoder[Long] 
def  SHORT: Encoder[Short] 
def  STRING: Encoder[String] 
def  TIMESTAMP: Encoder[Timestamp] 
def bean[T](beanClass: Class[T]): Encoder[T] 
def  javaSerialization[T](clazz: Class[T]): Encoder[T] 
def  javaSerialization[T](implicit arg0: ClassTag[T]): Encoder[T] 
def  kryo[T](implicit arg0: ClassTag[T]): Encoder[T] //Creates an encoder that serializes objects of type T using Kryo.
def  product[T <: Product](implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[T]): Encoder[T] 
def  scalaBoolean: Encoder[Boolean] 
def  scalaByte: Encoder[Byte] 
def  scalaDouble: Encoder[Double] 
def  scalaFloat: Encoder[Float] 
def  scalaInt: Encoder[Int] 
def  scalaLong: Encoder[Long] 
def  scalaShort: Encoder[Short] 
def  tuple[T1, T2, T3, T4, T5](e1: Encoder[T1], e2: Encoder[T2], e3: Encoder[T3], e4: Encoder[T4], e5: Encoder[T5]): Encoder[(T1, T2, T3, T4, T5)] 
def  tuple[T1, T2, T3, T4](e1: Encoder[T1], e2: Encoder[T2], e3: Encoder[T3], e4: Encoder[T4]): Encoder[(T1, T2, T3, T4)] 
def  tuple[T1, T2, T3](e1: Encoder[T1], e2: Encoder[T2], e3: Encoder[T3]): Encoder[(T1, T2, T3)] 
def  tuple[T1, T2](e1: Encoder[T1], e2: Encoder[T2]): Encoder[(T1, T2)] 


///* DataFrame 
// type DataFrame = DataSet[Row]
//methods of DataSet 
def  collect(): Array[T] 
def  collectAsList(): List[T] 
def  count(): Long 
def  describe(cols: String*): DataFrame //Computes statistics for numeric and string columns, including count, mean, stddev, min, and max.
def  first(): T 
def  foreach(f: (T) => Unit): Unit 
def  foreachPartition(f: (Iterator[T]) => Unit): Unit 
def  head(): T 
def  head(n: Int): Array[T] 
def  reduce(func: (T, T) => T): T 
def  show(numRows: Int, truncate: Int): Unit 
def  show(numRows: Int, truncate: Boolean): Unit 
def  show(truncate: Boolean): Unit 
def  show(): Unit 
def show(numRows: Int): Unit 
def  take(n: Int): Array[T]  //Returns the first n rows in the Dataset.
def  takeAsList(n: Int): List[T] 
def  toLocalIterator(): Iterator[T] 
def  as[U](implicit arg0: Encoder[U]): Dataset[U] //a new Dataset where each record has been mapped on to the specified type.
def  cache(): Dataset.this.type 
def  checkpoint(eager: Boolean): Dataset[T] 
def  checkpoint(): Dataset[T] 
def  columns: Array[String] 
def  createGlobalTempView(viewName: String): Unit 
def createOrReplaceTempView(viewName: String): Unit 
def  createTempView(viewName: String): Unit 
def  dtypes: Array[(String, String)] 
def  explain(): Unit 
def  explain(extended: Boolean): Unit 
def  inputFiles: Array[String] 
def  isLocal: Boolean 
def  javaRDD: JavaRDD[T] 
def  persist(newLevel: StorageLevel): Dataset.this.type 
def  persist(): Dataset.this.type 
def  printSchema(): Unit 
lazy val  rdd: RDD[T]   //Represents the content of the Dataset as an RDD of T.
def  schema: StructType 
def  storageLevel: StorageLevel 
def  toDF(colNames: String*): DataFrame 
def  toDF(): DataFrame 
def  toJavaRDD: JavaRDD[T] 
def  unpersist(): Dataset.this.type 
def  unpersist(blocking: Boolean): Dataset.this.type 
def  write: DataFrameWriter[T] 
def  writeStream: DataStreamWriter[T] 
def  registerTempTable(tableName: String): Unit 
def  isStreaming: Boolean 
def  withWatermark(eventTime: String, delayThreshold: String): Dataset[T] 
def  alias(alias: Symbol): Dataset[T]  //Returns a new Dataset with an alias set.
def  alias(alias: String): Dataset[T] 
def  as(alias: Symbol): Dataset[T]  //same as alias 
def  as(alias: String): Dataset[T] 
def  coalesce(numPartitions: Int): Dataset[T] 
def distinct(): Dataset[T] 
def  dropDuplicates(col1: String, cols: String*): Dataset[T] 
def  dropDuplicates(colNames: Array[String]): Dataset[T] 
def  dropDuplicates(colNames: Seq[String]): Dataset[T] 
def  dropDuplicates(): Dataset[T] 
def  except(other: Dataset[T]): Dataset[T] 
def  filter(func: (T) => Boolean): Dataset[T] 
def  filter(conditionExpr: String): Dataset[T] //using the given SQL expression.
def  filter(condition: Column): Dataset[T] 
def  flatMap[U](func: (T) => TraversableOnce[U])(implicit arg0: Encoder[U]): Dataset[U] 
def  groupByKey[K](func: (T) => K)(implicit arg0: Encoder[K]): KeyValueGroupedDataset[K, T] 
def  intersect(other: Dataset[T]): Dataset[T] 
def  joinWith[U](other: Dataset[U], condition: Column): Dataset[(T, U)] 
def  joinWith[U](other: Dataset[U], condition: Column, joinType: String): Dataset[(T, U)] 
def  limit(n: Int): Dataset[T] 
def  map[U](func: (T) => U)(implicit arg0: Encoder[U]): Dataset[U] 
def  mapPartitions[U](func: (Iterator[T]) => Iterator[U])(implicit arg0: Encoder[U]): Dataset[U] 
def  orderBy(sortExprs: Column*): Dataset[T] 
def  orderBy(sortCol: String, sortCols: String*): Dataset[T] 
def  randomSplit(weights: Array[Double]): Array[Dataset[T]] 
def  randomSplit(weights: Array[Double], seed: Long): Array[Dataset[T]] 
def  randomSplitAsList(weights: Array[Double], seed: Long): List[Dataset[T]] 
def  repartition(partitionExprs: Column*): Dataset[T] 
def  repartition(numPartitions: Int, partitionExprs: Column*): Dataset[T] 
def  repartition(numPartitions: Int): Dataset[T] 
def  sample(withReplacement: Boolean, fraction: Double): Dataset[T] 
def  sample(withReplacement: Boolean, fraction: Double, seed: Long): Dataset[T] 
def  select[U1, U2, U3, U4, U5](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2], c3: TypedColumn[T, U3], c4: TypedColumn[T, U4], c5: TypedColumn[T, U5]): Dataset[(U1, U2, U3, U4, U5)] 
def  select[U1, U2, U3, U4](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2], c3: TypedColumn[T, U3], c4: TypedColumn[T, U4]): Dataset[(U1, U2, U3, U4)] 
def  select[U1, U2, U3](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2], c3: TypedColumn[T, U3]): Dataset[(U1, U2, U3)] 
def  select[U1, U2](c1: TypedColumn[T, U1], c2: TypedColumn[T, U2]): Dataset[(U1, U2)] 
def  select[U1](c1: TypedColumn[T, U1]): Dataset[U1] 
def  sort(sortExprs: Column*): Dataset[T] 
def  sort(sortCol: String, sortCols: String*): Dataset[T] 
def  sortWithinPartitions(sortExprs: Column*): Dataset[T] 
def  sortWithinPartitions(sortCol: String, sortCols: String*): Dataset[T] 
def  transform[U](t: (Dataset[T]) => Dataset[U]): Dataset[U] 
def  union(other: Dataset[T]): Dataset[T] 
def  where(conditionExpr: String): Dataset[T]  //Filters rows using the given SQL expression.
def  where(condition: Column): Dataset[T] 
def  unionAll(other: Dataset[T]): Dataset[T] 
def  agg(expr: Column, exprs: Column*): DataFrame 
def  agg(exprs: Map[String, String]): DataFrame 
def  agg(aggExpr: (String, String), aggExprs: (String, String)*): DataFrame 
def  apply(colName: String): Column //Selects column based on the column name and return it as a Column.
def col(colName: String): Column 
def  crossJoin(right: Dataset[_]): DataFrame 
def  cube(col1: String, cols: String*): RelationalGroupedDataset  //Create a multi-dimensional cube for the current Dataset using the specified columns
def  cube(cols: Column*): RelationalGroupedDataset 
def  drop(col: Column): DataFrame 
def  drop(colNames: String*): DataFrame 
def  drop(colName: String): DataFrame 
def  groupBy(col1: String, cols: String*): RelationalGroupedDataset 
def  groupBy(cols: Column*): RelationalGroupedDataset 
def  join(right: Dataset[_], joinExprs: Column, joinType: String): DataFrame 
def  join(right: Dataset[_], joinExprs: Column): DataFrame 
def  join(right: Dataset[_], usingColumns: Seq[String], joinType: String): DataFrame 
def  join(right: Dataset[_], usingColumns: Seq[String]): DataFrame 
def  join(right: Dataset[_], usingColumn: String): DataFrame 
def  join(right: Dataset[_]): DataFrame 
def  na: DataFrameNaFunctions 
def  rollup(col1: String, cols: String*): RelationalGroupedDataset 
def  rollup(cols: Column*): RelationalGroupedDataset 
def  select(col: String, cols: String*): DataFrame 
def  select(cols: Column*): DataFrame 
def  selectExpr(exprs: String*): DataFrame 
def  stat: DataFrameStatFunctions 
def  withColumn(colName: String, col: Column): DataFrame 
def  withColumnRenamed(existingName: String, newName: String): DataFrame 
val  queryExecution: QueryExecution 
val  sparkSession: SparkSession 
lazy val  sqlContext: SQLContext 
def  toJSON: Dataset[String] 
def  toString(): String 






///*Example -  Basic creation and Operations on DF and DataSet(scala) 

///*scala 
$ spark-submit --class examples.SparkSQLExample  --master local[4] target/scala-2.11/learning-assembly.jar
$ spark-submit --class examples.RDDRelation  --master local[4] target/scala-2.11/learning-assembly.jar

//code 
import org.apache.spark.sql.catalyst.encoders.ExpressionEncoder
import org.apache.spark.sql.Encoder

import org.apache.spark.sql.Row

import org.apache.spark.sql.SparkSession

import org.apache.spark.sql.types._


object SparkSQLExample {


  // Note: Case classes in Scala 2.10 can support only up to 22 fields. To work around this limit,
  // you can use custom classes that implement the Product interface
  case class Person(name: String, age: Long)


  def main(args: Array[String]) {

    val spark = SparkSession
      .builder()
      .appName("Spark SQL basic example")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()

    // For implicit conversions like converting RDDs to DataFrames
    import spark.implicits._


    runBasicDataFrameExample(spark)
    runDatasetCreationExample(spark)
    runInferSchemaExample(spark)
    runProgrammaticSchemaExample(spark)

    spark.stop()
  }

  private def runBasicDataFrameExample(spark: SparkSession): Unit = {

    val df = spark.read.json("examples/src/main/resources/people.json")

    // Displays the content of the DataFrame to stdout
    df.show()
    // +----+-------+
    // | age|   name|
    // +----+-------+
    // |null|Michael|
    // |  30|   Andy|
    // |  19| Justin|
    // +----+-------+

    // This import is needed to use the $-notation
    import spark.implicits._
    // Print the schema in a tree format
    df.printSchema()
    // root
    // |-- age: long (nullable = true)
    // |-- name: string (nullable = true)

    // Select only the "name" column
    df.select("name").show()
    // +-------+
    // |   name|
    // +-------+
    // |Michael|
    // |   Andy|
    // | Justin|
    // +-------+

    // Select everybody, but increment the age by 1
    df.select($"name", $"age" + 1).show()
    // +-------+---------+
    // |   name|(age + 1)|
    // +-------+---------+
    // |Michael|     null|
    // |   Andy|       31|
    // | Justin|       20|
    // +-------+---------+

    // Select people older than 21
    df.filter($"age" > 21).show()
    // +---+----+
    // |age|name|
    // +---+----+
    // | 30|Andy|
    // +---+----+

    // Count people by age
    df.groupBy("age").count().show()
    // +----+-----+
    // | age|count|
    // +----+-----+
    // |  19|    1|
    // |null|    1|
    // |  30|    1|
    // +----+-----+

    // Register the DataFrame as a SQL temporary view
    df.createOrReplaceTempView("people")

    val sqlDF = spark.sql("SELECT * FROM people")
    sqlDF.show()
    // +----+-------+
    // | age|   name|
    // +----+-------+
    // |null|Michael|
    // |  30|   Andy|
    // |  19| Justin|
    // +----+-------+

    // Register the DataFrame as a global temporary view
    df.createGlobalTempView("people")

    // Global temporary view is tied to a system preserved database `global_temp`
    spark.sql("SELECT * FROM global_temp.people").show()
    // +----+-------+
    // | age|   name|
    // +----+-------+
    // |null|Michael|
    // |  30|   Andy|
    // |  19| Justin|
    // +----+-------+

    // Global temporary view is cross-session
    spark.newSession().sql("SELECT * FROM global_temp.people").show()
    // +----+-------+
    // | age|   name|
    // +----+-------+
    // |null|Michael|
    // |  30|   Andy|
    // |  19| Justin|
    // +----+-------+
    // $example off:global_temp_view$
  }

  private def runDatasetCreationExample(spark: SparkSession): Unit = {
    import spark.implicits._

    // Encoders are created for case classes
    val caseClassDS = Seq(Person("Andy", 32)).toDS()
    caseClassDS.show()
    // +----+---+
    // |name|age|
    // +----+---+
    // |Andy| 32|
    // +----+---+

    // Encoders for most common types are automatically provided by importing spark.implicits._
    val primitiveDS = Seq(1, 2, 3).toDS()
    primitiveDS.map(_ + 1).collect() // Returns: Array(2, 3, 4)

    // DataFrames can be converted to a Dataset by providing a class. Mapping will be done by name
    val path = "examples/src/main/resources/people.json"
    val peopleDS = spark.read.json(path).as[Person]
    peopleDS.show()
    // +----+-------+
    // | age|   name|
    // +----+-------+
    // |null|Michael|
    // |  30|   Andy|
    // |  19| Justin|
    // +----+-------+

  }

  private def runInferSchemaExample(spark: SparkSession): Unit = {

    // For implicit conversions from RDDs to DataFrames
    import spark.implicits._

    // Create an RDD of Person objects from a text file, convert it to a Dataframe
    val peopleDF = spark.sparkContext
      .textFile("examples/src/main/resources/people.txt")
      .map(_.split(","))
      .map(attributes => Person(attributes(0), attributes(1).trim.toInt))
      .toDF()
    // Register the DataFrame as a temporary view
    peopleDF.createOrReplaceTempView("people")

    // SQL statements can be run by using the sql methods provided by Spark
    val teenagersDF = spark.sql("SELECT name, age FROM people WHERE age BETWEEN 13 AND 19")

    // The columns of a row in the result can be accessed by field index
    teenagersDF.map(teenager => "Name: " + teenager(0)).show()
    // +------------+
    // |       value|
    // +------------+
    // |Name: Justin|
    // +------------+

    // or by field name
    teenagersDF.map(teenager => "Name: " + teenager.getAs[String]("name")).show()
    // +------------+
    // |       value|
    // +------------+
    // |Name: Justin|
    // +------------+

    // No pre-defined encoders for Dataset[Map[K,V]], define explicitly
    implicit val mapEncoder = org.apache.spark.sql.Encoders.kryo[Map[String, Any]]
    // Primitive types and case classes can be also defined as
    // implicit val stringIntMapEncoder: Encoder[Map[String, Any]] = ExpressionEncoder()

    // row.getValuesMap[T] retrieves multiple columns at once into a Map[String, T]
    teenagersDF.map(teenager => teenager.getValuesMap[Any](List("name", "age"))).collect()
    // Array(Map("name" -> "Justin", "age" -> 19))

  }

  private def runProgrammaticSchemaExample(spark: SparkSession): Unit = {
    import spark.implicits._

    // Create an RDD
    val peopleRDD = spark.sparkContext.textFile("examples/src/main/resources/people.txt")

    // The schema is encoded in a string
    val schemaString = "name age"

    // Generate the schema based on the string of schema
    val fields = schemaString.split(" ")
      .map(fieldName => StructField(fieldName, StringType, nullable = true))
    val schema = StructType(fields)

    // Convert records of the RDD (people) to Rows
    val rowRDD = peopleRDD
      .map(_.split(","))
      .map(attributes => Row(attributes(0), attributes(1).trim))

    // Apply the schema to the RDD
    val peopleDF = spark.createDataFrame(rowRDD, schema)

    // Creates a temporary view using the DataFrame
    peopleDF.createOrReplaceTempView("people")

    // SQL can be run over a temporary view created using DataFrames
    val results = spark.sql("SELECT name FROM people")

    // The results of SQL queries are DataFrames and support all the normal RDD operations
    // The columns of a row in the result can be accessed by field index or by field name
    results.map(attributes => "Name: " + attributes(0)).show()
    // +-------------+
    // |        value|
    // +-------------+
    // |Name: Michael|
    // |   Name: Andy|
    // | Name: Justin|
    // +-------------+

  }
}




///*scala = RDD relation 
// scalastyle:off println

import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.SparkSession


// One method for defining the schema of an RDD is to make a case class with the desired column
// names and types.
case class Record(key: Int, value: String)

object RDDRelation {
  def main(args: Array[String]) {

    val spark = SparkSession
      .builder
      .appName("Spark Examples")
      .config("spark.some.config.option", "some-value")
      .getOrCreate()

    // Importing the SparkSession gives access to all the SQL functions and implicit conversions.
    import spark.implicits._


    val df = spark.createDataFrame((1 to 100).map(i => Record(i, s"val_$i")))
    // Any RDD containing case classes can be used to create a temporary view.  The schema of the
    // view is automatically inferred using scala reflection.
    df.createOrReplaceTempView("records")

    // Once tables have been registered, you can run SQL queries over them.
    println("Result of SELECT *:")
    spark.sql("SELECT * FROM records").collect().foreach(println)

    // Aggregation queries are also supported.
    val count = spark.sql("SELECT COUNT(*) FROM records").collect().head.getLong(0)
    println(s"COUNT(*): $count")

    // The results of SQL queries are themselves RDDs and support all normal RDD functions. The
    // items in the RDD are of type Row, which allows you to access each column by ordinal.
    val rddFromSql = spark.sql("SELECT key, value FROM records WHERE key < 10")

    println("Result of RDD.map:")
    rddFromSql.rdd.map(row => s"Key: ${row(0)}, Value: ${row(1)}").collect().foreach(println)

    // Queries can also be written using a LINQ-like Scala DSL.
    df.where($"key" === 1).orderBy($"value".asc).select($"key").collect().foreach(println)

    // Write out an RDD as a parquet file with overwrite mode.
    df.write.mode(SaveMode.Overwrite).parquet("pair.parquet")

    // Read in parquet file.  Parquet files are self-describing so the schema is preserved.
    val parquetFile = spark.read.parquet("pair.parquet")

    // Queries can be run using the DSL on parquet files just like the original RDD.
    parquetFile.where($"key" === 1).select($"value".as("a")).collect().foreach(println)

    // These files can also be used to create a temporary view.
    parquetFile.createOrReplaceTempView("parquetFile")
    spark.sql("SELECT * FROM parquetFile").collect().foreach(println)

    spark.stop()
  }
}










    
    
@@@   
    
///*** More Operations on DF 



//* Functions on Columns
//Note below functions are available to DF operations (check PY usage)
// http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$
//Note function operate on Column and returns a New Column 
//hence wherever Column is needed, you can use func(Column)

import org.apache.spark.sql.functions ._
import org.apache.spark.sql.types._ 

//*org.apache.spark.sql.functions.add_months(start, months) // Must be DateType which is java.sql.Date // Note TimestampType represents  java.sql.Timestamp values
//*org.apache.spark.sql.functions.date_format(date, format)

//Using java.sql.Date.valueOf(String date) where date = yyyy-MM-dd 
import spark.implicits._ 

val schema = StructType(List(StructField("d", DateType, true))) //A date type, supporting "0001-01-01" through "9999-12-31".
val rows = sc.parallelize( Seq(Row( java.sql.Date.valueOf("2004-04-08")  ) ) )
val df = spark.createDataFrame(rows , schema )
df.select(add_months(df("d"), 1).alias("added")).collect()
df.select(date_format($"d", "MM/dd/yyy").alias("formatedDate")).collect()


//*org.apache.spark.sql.functions.array_contains(col, value)
//case class  ArrayType(elementType: DataType, containsNull: Boolean
//case class  StructType(fields: Array[StructField]) 
//case class  StructField(name: String, dataType: DataType, nullable: Boolean = true)

val schema = StructType(Array(  StructField("data", ArrayType(StringType, false ), true)  )   )
val rows = sc.parallelize( Seq( Row(Array( "a", "b", "c")) , Row(Array.empty[String])  ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(array_contains(df("data"), "a").alias("DoesA") ).collect()
//Array([true], [false])


//*org.apache.spark.sql.functions.concat_ws(sep, *cols)
//Concatenates multiple input string columns together into a single string column, using the given separator.

val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )

val rows = sc.parallelize( Seq( Row("abcd","123")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(concat_ws("-", df("s"), df("d")).alias("sd") ).show() //or collect() to get whole dataframe 



//*org.apache.spark.sql.functions.corr(col1, col2)
//Returns a new Column for the Pearson Correlation Coefficient for col1 and col2.

val schema = StructType(Array(  StructField("a", IntegerType, true) ,StructField("b", IntegerType, true) )   )

val a = (1 to 20).toSeq
val b = (1 to 20).toList.map( _ * 2).toSeq
val rows = sc.parallelize( a.zip(b).map( t => Row(t._1,t._2) ).toSeq ) 

val df = spark.createDataFrame(rows , schema )
df.agg(corr("a", "b").alias("c")).collect()  //Array([1.0])


//*org.apache.spark.sql.functions.countDistinct(col, *cols)
//Returns a new Column for distinct count of col or cols.

df.agg(countDistinct(df("a"), df("b")).alias("c")).collect()  //Array([20])
df.agg(countDistinct("a", "b").alias("c")).collect()



//*org.apache.spark.sql.functions.expr(str)
//Parses the expression string into the column that it represents

val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )

val rows = sc.parallelize( Seq( Row("abcd","123")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(expr("length(s)")).collect() //Array([4])




//*org.apache.spark.sql.functions.format_string(format, *cols)
//Formats the arguments in printf-style and returns the result as a string column.
val schema = StructType(Array(  StructField("a", IntegerType, true) ,StructField("b", StringType, true) )   )

val rows = sc.parallelize( Seq( Row(5,"hello")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(format_string("%d %s", df("a"), df("b")).alias("v")).collect()



//*org.apache.spark.sql.functions.grouping(col)
//Aggregate function: indicates whether a specified column in a GROUP BY list is aggregated or not, 
//returns 1 for aggregated or 0 for not aggregated in the result set.
// cube() returns RelationalGroupedDataset 
val df = spark.read.json(raw"D:\Desktop\PPT\spark\data\peopledepart.json")
df.cube("name").agg(grouping("name"), sum("age")).orderBy("name").show()



//*org.apache.spark.sql.functions.instr(str, substr)
//Locate the position of the first occurrence of substr column in the given string. Returns null if either of the arguments are null.
//*org.apache.spark.sql.functions.substring(str, pos, len)

val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )

val rows = sc.parallelize( Seq( Row("abcd","123") ,Row("abcd","123")  ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(instr(df("s"), "b").alias("sd")).collect() // Array([2])
df.select(substring(df("s"), 1, 2).alias("sub")).collect() 
//res89: Array[org.apache.spark.sql.Row] = Array([ab], [ab])


//*org.apache.spark.sql.functions.length(col)
//Calculates the length of a string or binary expression.


val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )

val rows = sc.parallelize( Seq( Row("abcd","123")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(length(col("s")) ).collect() //Array([4])



//*org.apache.spark.sql.functions.nanvl(col1, col2)
//Returns col1 if it is not NaN, or col2 if col1 is NaN.
//Both inputs should be floating point columns (DoubleType or FloatType).

val schema = StructType(Array(  StructField("a", DoubleType, true) ,StructField("b", DoubleType, true) )   )

val rows = sc.parallelize( Seq( Row( 1.0, Double.NaN), Row(  Double.NaN, 2.0)   ) ) 
val df = spark.createDataFrame(rows , schema )

df.select(nanvl(df("a"), df("b")).alias("r2")).collect() // Array([1.0], [2.0])




//*org.apache.spark.sql.functions.regexp_extract(str, pattern, idx)
//Extract a specific group matched by a Java regex, from the specified string column. If the regex did not match, or the specified group did not match, an empty string is returned.
//*org.apache.spark.sql.functions.regexp_replace(str, pattern, replacement)
//*org.apache.spark.sql.functions.split(str, pattern)

val schema = StructType(Array(  StructField("str", StringType, true) ,StructField("dtr", StringType, true) )   )

val rows = sc.parallelize( Seq( Row("100-200","100-200")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(regexp_extract(col("str"), raw"(\d+)-(\d+)", 1).alias("d")).collect() //Array([100])
df.select(regexp_replace(col("str"), raw"(\d+)", "--").alias("d")).collect() // Array([-----])
df.select(split(col("str"), raw"[0-9]+").alias("s")).collect() //Array([WrappedArray(, -, )])



//*org.apache.spark.sql.functions.repeat(col, n)
//Repeats a string column n times, and returns it as a new string column.
df.select(repeat(df("str"), 3).alias("s")).collect() //Array([100-200100-200100-200])


//*org.apache.spark.sql.functions.size(col)
//Collection function: returns the length of the array or map stored in the column.
//*org.apache.spark.sql.functions.sort_array(col, asc=True)


val schema = StructType(Array(  StructField("data", ArrayType(StringType, false ), true)  )   )
val rows = sc.parallelize( Seq( Row(Array( "a", "b", "c")) , Row(Array.empty[String])  ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(size(df("data"))).collect()//Array([3], [0])
df.select(sort_array(df("data"), asc=false).alias("r")).collect() //Array([WrappedArray(c, b, a)]




//*org.apache.spark.sql.functions.window(timeColumn, windowDuration, slideDuration=None, startTime=None)
//Bucketize rows into one or more time windows given a timestamp specifying column. Window starts are inclusive but the window ends are exclusive, e.g. 12:05 will be in the window [12:05,12:10) but not in [12:00,12:05). Windows can support microsecond precision. Windows in the order of months are not supported.
//The time column must be of org.apache.spark.sql.types.TimestampType.

//Durations are provided as strings, e.g. �1 second�, �1 day 12 hours�, �2 minutes�. 
//Valid interval strings are �week�, �day�, �hour�, �minute�, �second�, �millisecond�, �microsecond�. 
//If the slideDuration is not provided, the windows will be tumbling windows.

//The startTime is the offset with respect to 1970-01-01 00:00:00 UTC with which to start window intervals. For example, in order to have hourly tumbling windows that start 15 minutes past the hour, e.g. 12:15-13:15, 13:15-14:15... provide startTime as 15 minutes.

//The output column will be a struct called �window� by default with the nested columns �start� and �end�, where �start� and �end� will be of pyspark.sql.types.TimestampType.

import spark.implicits._ 
import org.apache.spark.sql.functions ._
import org.apache.spark.sql.types._ 
import org.apache.spark.sql._

val schema = StructType(List(StructField("data", TimestampType, true),  //format yyyy-[m]m-[d]d hh:mm:ss[.f...]. 
                            StructField("val", IntegerType, true))) //A date type, supporting "0001-01-01" through "9999-12-31".

val rows = sc.parallelize( Seq(Row( java.sql.Timestamp.valueOf("2016-03-11 09:00:07"), 1  ),
                               Row( java.sql.Timestamp.valueOf("2016-03-11 09:00:14"), 2  )   ) )


val df = spark.createDataFrame(rows , schema )
val w = df.groupBy(window($"data", "5 seconds")).agg(sum($"val").alias("sum"))
w: org.apache.spark.sql.DataFrame = [window: struct<start: timestamp,end: timestamp>, sum: bigint]

w.select(w("window")("start").cast("string").alias("start"),
          w("window")("end").cast("string").alias("end"), w("sum")).collect()
          
res5: Array[org.apache.spark.sql.Row] = Array([2016-03-11 09:00:05,2016-03-11 09:00:10,1], [2016-03-11 09:00:10,2016-03-11 09:00:15,2])

w.select(w("window")("start").cast("string").alias("start"),
          w("window")("end").cast("string").alias("end"), w("sum")).show()
+-------------------+-------------------+---+
|              start|                end|sum|
+-------------------+-------------------+---+
|2016-03-11 09:00:05|2016-03-11 09:00:10|  1|
|2016-03-11 09:00:10|2016-03-11 09:00:15|  2|
+-------------------+-------------------+---+




///** Few FUnctions from DF operations 
//To select a column from the data frame, use the apply method:
///* scala 

//http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.Dataset

import spark.implicits._ 
import org.apache.spark.sql.functions ._
import org.apache.spark.sql.types._ 
import org.apache.spark.sql._

//json should contain all objects one by one , not with array syntax 
val people = spark.read.json(raw"D:\Desktop\PPT\spark\data\peopledepart.json")
val names = people.select("name") // in Scala; names is a Dataset[String]
names.show()
val ageCol = people("age")  
people("age") + 10  // in Scala


val department = spark.read.json(raw"D:\Desktop\PPT\spark\data\department.json")
//wheneever, list of columns needs to be mentioned,
//use 
//(col1: String,cols: String*) or (cols: org.apache.spark.sql.Column*) 
//dont mix it eg (STring, Column) etc 
people.filter("age > 30")
  .join(department, people("departId") === department("id"))
  .groupBy(department("name"), people("gender"))
  .agg(avg(people("salary")), max(people("age"))).orderBy(department("name")).show()
  
people.describe("age", "height").show()
// The following are equivalent:
people.filter($"age" > 75)
people.where($"age" > 75) 


//Example 
import spark.implicits._ 
import org.apache.spark.sql.functions ._
import org.apache.spark.sql.types._ 
import org.apache.spark.sql._

val l = Seq( Row("Alice", 1), Row("das", 2) )
val schema = StructType(List(StructField("name", StringType, true),  StructField("age", IntegerType, true)))
val rdd = sc.parallelize(l)
val df = spark.createDataFrame(rdd, schema)
val df2 = spark.createDataFrame(rdd, schema)



//* agg(*exprs)
//Aggregate on the entire DataFrame without groups (shorthand for df.groupBy.agg()).


df.agg( Map("age" -> "max") ).collect()
res8: Array[org.apache.spark.sql.Row] = Array([2])
df.agg(min($"age")).collect()
res10: Array[org.apache.spark.sql.Row] = Array([1])



//* alias(alias)
//Returns a new DataFrame with an alias set.
val df_as1 = df.alias("df_as1")
val df_as2 = df.alias("df_as2")
val joined_df = df_as1.join(df_as2, col("df_as1.name") === col("df_as2.name"), "inner") //note ===
joined_df.select("df_as1.name", "df_as2.name", "df_as2.age").collect()
res11: Array[org.apache.spark.sql.Row] = Array([Alice,Alice,1], [das,das,2])


//* collect()
//Returns all the records as a list of Row.
df.collect()
res12: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])


//* columns
//Returns all column names as a list.
df.columns
res13: Array[String] = Array(name, age)




//* count()
//Returns the number of rows in this DataFrame.
df.count()
res14: Long = 2


//* cube(*cols)
//Create a multi-dimensional cube for the current DataFrame using the specified columns, 
//so we can run aggregation on them.
// cube() returns RelationalGroupedDataset 
//note select/orderby args must be all Column or String, no mix-in 

scala> df.show()
+-----+---+
| name|age|
+-----+---+
|Alice|  1|
|  das|  2|
+-----+---+

>>> df.cube("name", "age").count().orderBy("name", "age").show()
+-----+----+-----+
| name| age|count|
+-----+----+-----+
| null|null|    2|
| null|   1|    1|
| null|   2|    1|
|Alice|null|    1|
|Alice|   1|    1|
|  das|null|    1|
|  das|   2|    1|
+-----+----+-----+



//* describe(*cols)
//Computes statistics for numeric and string columns.
//This include count, mean, stddev, min, and max. 

>>> df.describe("age").show()
+-------+------------------+
|summary|               age|
+-------+------------------+
|  count|                 2|
|   mean|               1.5|
| stddev|0.7071067811865476|
|    min|                 1|
|    max|                 2|
+-------+------------------+
>>> df.describe().show() //df.describe("age", "name").show()
+-------+-----+------------------+
|summary| name|               age|
+-------+-----+------------------+
|  count|    2|                 2|
|   mean| null|               1.5|
| stddev| null|0.7071067811865476|
|    min|Alice|                 1|
|    max|  das|                 2|
+-------+-----+------------------+



//* distinct()
//Returns a new DataFrame containing the distinct rows in this DataFrame.
df.distinct().count()
res20: Long = 2



//* drop(*cols)
//Returns a new DataFrame that drops the specified column. 
//This is a no-op if schema doesn�t contain the given column name(s).

>>> df.drop("age").collect()
res21: Array[org.apache.spark.sql.Row] = Array([Alice], [das])


>>> df.join(df2, df("name") === df2("name"), "inner").drop(df("name")).collect()
res22: Array[org.apache.spark.sql.Row] = Array([1,Alice,1], [2,das,2])



//* dropDuplicates(subset=None)
//Return a new DataFrame with duplicate rows removed, optionally only considering certain columns.
//drop_duplicates() is an alias for dropDuplicates().

//Row can not be toDF 
//product class can be 
case class Person( name:String, age:Int, height:Int)
val dfn = sc.parallelize(Seq( Person("Alice", 5, 80), Person("Alice", 5, 80))).toDF()
dfn.dropDuplicates().show()
+-----+---+------+
| name|age|height|
+-----+---+------+
|Alice|  5|    80|
+-----+---+------+


//* filter(condition)
//Filters rows using the given condition.
//where() is an alias for filter().
//condition � a Column of types.BooleanType or a string of SQL expression. 


>>> df.filter(df("age") > 1).collect()
res25: Array[org.apache.spark.sql.Row] = Array([das,2])
>>> df.where(df("age") === 2).collect()  //Note ===
res26: Array[org.apache.spark.sql.Row] = Array([das,2])



>>> df.filter("age > 1").collect()
res28: Array[org.apache.spark.sql.Row] = Array([das,2])
>>> df.where("age = 2").collect()
res29: Array[org.apache.spark.sql.Row] = Array([das,2])


//* first()
//Returns the first row as a Row.
>>> df.first()
res30: org.apache.spark.sql.Row = [Alice,1]


//* foreach(f)
//Applies the f function to all Row of this DataFrame.
//This is a shorthand for df.rdd.foreach().

scala> df.foreach(r => println(r))
[Alice,1]
[das,2]

df.foreach{r => r match {
                  case Row(name, age) => println(name) } }


//* foreachPartition(f)
//Applies the f function to each partition of this DataFrame.Note F takes Iterator 
//This a shorthand for df.rdd.foreachPartition().


scala> df.foreachPartition(Itr => println(Itr.toList))
List()
List()
List([das,2])
List([Alice,1])



//* groupBy(*cols)
//Groups the DataFrame using the specified columns, so we can run aggregation on them. 
//Returns RelationalGroupedDataset, groupby() is an alias for groupBy().
//cols � list of columns to group by. Each element should be a column name (string) or an expression (Column). 


df.groupBy().avg().collect()
res40: Array[org.apache.spark.sql.Row] = Array([1.5])
//for same name, what is mean age 
scala> df.groupBy("name").agg(Map("age" -> "mean")).collect.sortBy( row => row(0).asInstanceOf[String])
res43: Array[org.apache.spark.sql.Row] = Array([Alice,1.0], [das,2.0])

df.groupBy("name", "age").count().show()
+-----+---+-----+
| name|age|count|
+-----+---+-----+
|  das|  2|    1|
|Alice|  1|    1|
+-----+---+-----+



//* head(n=None)
//Returns the first n rows.

>>> df.head()
res45: org.apache.spark.sql.Row = [Alice,1]
>>> df.head(2)
res46: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])



//* join(other, on=None, how=None)
//Joins with another DataFrame, using the given join expression.
�other � Right side of the join
�on � a string for the join column name, a list of column names, a join expression (Column), or a list of Columns. If on is a string or a list of strings indicating the name of the join column(s), the column(s) must exist on both sides, and this performs an equi-join.
�how � str, default �inner�. One of inner, outer, left_outer, right_outer, leftsemi.
 

//full outer join between df1 and df2.(Note ===)
>>> df.join(df2, df("name") === df2("name"), "outer").select(df("name"), df2("age")).collect()
res47: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])



//* limit(num)
//Limits the result count to the number specified.

>>> df.limit(1).collect()
res48: Array[org.apache.spark.sql.Row] = Array([Alice,1])
>>> df.limit(0).collect()
[]


//* orderBy(*cols, **kwargs)
//Returns a new DataFrame sorted by the specified column(s).
//�ascending � boolean or list of boolean (default True). Sort ascending vs. descending. 
//Specify list for multiple sort orders. 
//If a list is specified, length of the list must equal length of the cols.
//* sort(*cols, **kwargs)
//Returns a new DataFrame sorted by the specified column(s).
//�ascending � boolean or list of boolean (default True). Sort ascending vs. descending. Specify list for multiple sort orders. If a list is specified, length of the list must equal length of the cols.


>>> df.sort($"age".desc).collect()
res52: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])

scala> df.sort(desc("age")).collect()  //desc, asc from functions 
res54: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])

>>> df.orderBy(df("age").desc).collect()
res57: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])

scala> df.orderBy(desc("age"), df("name")).collect()
res56: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])



//* randomSplit(weights, seed=None)
//Randomly splits this DataFrame with the provided weights.
�weights � list of doubles as weights with which to split the DataFrame. Weights will be normalized if they don�t sum up to 1.0.
�seed � The seed for sampling.
 
val splits = df.randomSplit(Array(1.0, 2.0), 24)   //1:2 splits 
scala> splits(0).show()
+-----+---+
| name|age|
+-----+---+
|Alice|  1|
+-----+---+


scala> splits(1).collect()
res59: Array[org.apache.spark.sql.Row] = Array([das,2])

//* rollup(*cols)
//Create a multi-dimensional rollup for the current DataFrame 
//using the specified columns, so we can run aggregation on them.
//returns RelationalGroupedDataset

>>> df.rollup("name", "age").count().orderBy("name", "age").show()
+-----+----+-----+
| name| age|count|
+-----+----+-----+
| null|null|    2|
|Alice|null|    1|
|Alice|   1|    1|
|  das|null|    1|
|  das|   2|    1|
+-----+----+-----+


//* select(*cols)
//cols � list of column names (string) or expressions (Column). 
//If one of the column names is �*�, that column is expanded to include all columns in the current DataFrame. 


>>> df.select("*").collect()
res60: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])
>>> df.select("name", "age").collect()
res61: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])
>>> df.select(df("name"), ($"age" + 10).alias("age_new")).collect()
res62: Array[org.apache.spark.sql.Row] = Array([Alice,11], [das,12])



//* selectExpr(*expr)
//This is a variant of select() that accepts SQL expressions.

>>> df.selectExpr("age * 2", "abs(age)").collect()
res63: Array[org.apache.spark.sql.Row] = Array([2,1], [4,2])



//* toJSON(use_unicode=True)
//Converts a DataFrame into a RDD of string.
//Each row is turned into a JSON document as one element in the returned RDD.

scala> df.toJSON.collect
res66: Array[String] = Array({"name":"Alice","age":1}, {"name":"das","age":2})


//* toLocalIterator()
//Returns an iterator that contains all of the rows in this DataFrame. The iterator will consume as much memory as the largest partition in this DataFrame.

import collection.JavaConversions._
println(List() ++ df.toLocalIterator())
List([Alice,1], [das,2])


//* withColumn(colName, col)
//Returns a new DataFrame by adding a column 
//or replacing the existing column that has the same name.
�colName � string, name of the new column.
�col � a Column expression for the new column.
 
scala> df.withColumn("age2", $"age" + 2).show()
+-----+---+----+
| name|age|age2|
+-----+---+----+
|Alice|  1|   3|
|  das|  2|   4|
+-----+---+----+


//* withColumnRenamed(existing, new)
//Returns a new DataFrame by renaming an existing column. 
�existing � string, name of the existing column to rename.
�col � string, new name of the column.
 
scala> df.withColumnRenamed("age", "age2").show()
+-----+----+
| name|age2|
+-----+----+
|Alice|   1|
|  das|   2|
+-----+----+










//*  DataFrameStatFunctions  
//http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.DataFrameStatFunctions
//returned from df.stat
approxQuantile(col, probabilities, relativeError)
corr(col1, col2, method=None)
cov(col1, col2)
crosstab(col1, col2)
freqItems(cols, support=None) //Finding frequent items for columns, possibly with false positives. Using the frequent element count algorithm described in �http://dx.doi.org/10.1145/762471.762473, proposed by Karp, Schenker, and Papadimitriou�. DataFrame.freqItems() and DataFrameStatFunctions.freqItems() are aliases.
sampleBy(col, fractions, seed=None)

//cols,col etc are string 
val peopleStat = people.stat 
peopleStat.crosstab("gender", "departId").show() //allretruns DF 



//* DataFrameNaFunctions  (check PY usage)
//http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.DataFrameNaFunctions

val df4 = spark.read.json(raw"D:\Desktop\PPT\spark\data\people1.json")
df4.na.drop().show()
df4.na.drop().dropDuplicates().show()
df4.na.fill(50).show()
df4.na.fill(Map("age"-> 50, "name" -> "unknown", "height" -> 60)).show()


///* org.apache.spark.sql.RelationalGroupedDataset  (equivalent to pyspark.sql.GroupedData)
//A set of methods for aggregations on a DataFrame, created by Dataset.groupBy.
//The main method is the agg function, which has multiple variants. 
//This class also contains convenience some first order statistics such as mean, sum for convenience.

//The available aggregate methods are avg, max, min, sum, count.
def  agg(exprs: Map[String, String]): DataFrame //Compute aggregates by specifying a map from column name to aggregate methods.
def  agg(aggExpr: (String, String), aggExprs: (String, String)*): DataFrame 

// Scala:
import org.apache.spark.sql._ 
import org.apache.spark.sql.functions._

val df = spark.read.json(raw"D:\Desktop\PPT\spark\data\peopledepart.json")

//all returns DF, hence put .show() to display 
df.groupBy("departId").agg(max("age"), sum("salary"))



// Selects the age of the oldest employee and the aggregate expense for each department
import com.google.common.collect.ImmutableMap;
df.groupBy("departId").agg(ImmutableMap.of("age", "max", "salary", "sum"))



// Selects the age of the oldest employee and the aggregate expense for each department
df.groupBy("departId").agg(Map(
  "age" -> "max",
  "salary" -> "sum"
))

df.groupBy().avg("age", "height")  //all rows avg for age and height 
df.groupBy("departId").avg("age", "height").orderBy("departId")

// Compute the sum of earnings for each year by course with each course as a separate column
import spark.implicits._
df.groupBy("departId").pivot("gender", Seq("Male", "Female")).avg("salary").where($"Female" > $"Male")
// Or without specifying column values (less efficient)
df.groupBy("departId").pivot("gender").sum("salary")
























    
///*****  DF - Data Sources  ****/

///* sql.DataFrameReader(returned from spark.read) and sql.DataFrameWriter(returned from spark.write)
//Note other that above , one can use RDD related methods()
//Note DF can be converted to RDD by df.rdd 
//and RDD can be converted to DF by sparkSession.createDataFrame(rdd)


///*scala 
//set optionsvia option/options method 


///Methods of DataFrameReader
csv(path, schema=None, sep=None, encoding=None, quote=None, escape=None, comment=None, 
  header=None, inferSchema=None, ignoreLeadingWhiteSpace=None, ignoreTrailingWhiteSpace=None, 
  nullValue=None, nanValue=None, positiveInf=None, negativeInf=None, dateFormat=None, 
  timestampFormat=None, maxColumns=None, maxCharsPerColumn=None, maxMalformedLogPerPartition=None, mode=None)

//for scala 
?sep (default ,): sets the single character as a separator for each field and value.
?encoding (default UTF-8): decodes the CSV files by the given encoding type.
?quote (default "): sets the single character(") used for escaping quoted values where the separator can be part of the value. If you would like to turn off quotations, you need to set not null but an empty string. This behaviour is different from com.databricks.spark.csv.
?escape (default \): sets the single character used for escaping quotes inside an already quoted value.
?comment (default empty string): sets the single character used for skipping lines beginning with this character. By default, it is disabled.
?header (default false): uses the first line as names of columns.
?inferSchema (default false): infers the input schema automatically from data. It requires one extra pass over the data.
?ignoreLeadingWhiteSpace (default false): defines whether or not leading whitespaces from values being read should be skipped.
?ignoreTrailingWhiteSpace (default false): defines whether or not trailing whitespaces from values being read should be skipped.
?nullValue (default empty string): sets the string representation of a null value. Since 2.0.1, this applies to all supported types including the string type.
?nanValue (default NaN): sets the string representation of a non-number" value.  "
?positiveInf (default Inf): sets the string representation of a positive infinity value.
?negativeInf (default -Inf): sets the string representation of a negative infinity value.
?dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
?timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type.
?maxColumns (default 20480): defines a hard limit of how many columns a record can have.
?maxCharsPerColumn (default -1): defines the maximum number of characters allowed for any given value being read. By default, it is -1 meaning unlimited length
?maxMalformedLogPerPartition (default 10): sets the maximum number of malformed rows Spark will log for each partition. Malformed records beyond this number will be ignored.
?mode (default PERMISSIVE): allows a mode for dealing with corrupt records during parsing.
    ?PERMISSIVE : sets other fields to null when it meets a corrupted record. When a schema is set by user, it sets null for extra fields.
    ?DROPMALFORMED : ignores the whole corrupted records.
    ?FAILFAST : throws an exception when it meets corrupted records.


json(path, schema=None, primitivesAsString=None, prefersDecimal=None, allowComments=None, 
    allowUnquotedFieldNames=None, allowSingleQuotes=None, allowNumericLeadingZero=None, 
    allowBackslashEscapingAnyCharacter=None, mode=None, columnNameOfCorruptRecord=None, 
    dateFormat=None, timestampFormat=None)

//for scala 
primitivesAsString (default false): infers all primitive values as a string type
?prefersDecimal (default false): infers all floating-point values as a decimal type. If the values do not fit in decimal, then it infers them as doubles.
?allowComments (default false): ignores Java/C++ style comment in JSON records
?allowUnquotedFieldNames (default false): allows unquoted JSON field names
?allowSingleQuotes (default true): allows single quotes in addition to double quotes
?allowNumericLeadingZeros (default false): allows leading zeros in numbers (e.g. 00012)
?allowBackslashEscapingAnyCharacter (default false): allows accepting quoting of all character using backslash quoting mechanism
?mode (default PERMISSIVE): allows a mode for dealing with corrupt records during parsing.
?PERMISSIVE : sets other fields to null when it meets a corrupted record, and puts the malformed string into a new field configured by columnNameOfCorruptRecord. When a schema is set by user, it sets null for extra fields.
?DROPMALFORMED : ignores the whole corrupted records.
?FAILFAST : throws an exception when it meets corrupted records.
?columnNameOfCorruptRecord (default is the value specified in spark.sql.columnNameOfCorruptRecord): allows renaming the new field having malformed string created by PERMISSIVE mode. This overrides spark.sql.columnNameOfCorruptRecord.
?dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
?timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type.

//other methods of DataFrameReader
def  csv(paths: String*): DataFrame 
def  csv(path: String): DataFrame 

def  format(source: String): DataFrameReader   // "jdbc", json, text, csv, libsvm

def  jdbc(url: String, table: String, predicates: Array[String], connectionProperties: Properties): DataFrame 
def  jdbc(url: String, table: String, columnName: String, lowerBound: Long, upperBound: Long, numPartitions: Int, connectionProperties: Properties): DataFrame 
def  jdbc(url: String, table: String, properties: Properties): DataFrame 

def  json(jsonRDD: RDD[String]): DataFrame 
def  json(jsonRDD: JavaRDD[String]): DataFrame 
def  json(paths: String*): DataFrame 
def  json(path: String): DataFrame 

def  load(paths: String*): DataFrame 
def  load(path: String): DataFrame 
def  load(): DataFrame 

def  option(key: String, value: Double): DataFrameReader 
def  option(key: String, value: Long): DataFrameReader 
def  option(key: String, value: Boolean): DataFrameReader 
def  option(key: String, value: String): DataFrameReader 
def  options(options: Map[String, String]): DataFrameReader 
def  options(options: Map[String, String]): DataFrameReader 

def  orc(paths: String*): DataFrame 
def  orc(path: String): DataFrame 

def  parquet(paths: String*): DataFrame 
def  parquet(path: String): DataFrame 

def  schema(schema: StructType): DataFrameReader 
def  table(tableName: String): DataFrame 

def  text(paths: String*): DataFrame 
def  text(path: String): DataFrame 

def  textFile(paths: String*): Dataset[String] 
def  textFile(path: String): Dataset[String] 

//methods of DataFrameWriter
def  bucketBy(numBuckets: Int, colName: String, colNames: String*): DataFrameWriter[T] 

def  csv(path: String): Unit 

def  format(source: String): DataFrameWriter[T] 
def  insertInto(tableName: String): Unit 
def  jdbc(url: String, table: String, connectionProperties: Properties): Unit 
def  json(path: String): Unit 

def  mode(saveMode: String): DataFrameWriter[T] 
def  mode(saveMode: SaveMode): DataFrameWriter[T] 

def  option(key: String, value: Double): DataFrameWriter[T] 
def  option(key: String, value: Long): DataFrameWriter[T] 
def  option(key: String, value: Boolean): DataFrameWriter[T] 
def  option(key: String, value: String): DataFrameWriter[T] 
def  options(options: Map[String, String]): DataFrameWriter[T] 
def  options(options: Map[String, String]): DataFrameWriter[T] 

def  orc(path: String): Unit 
def  parquet(path: String): Unit 
def  partitionBy(colNames: String*): DataFrameWriter[T] 

def  save(): Unit 
def  save(path: String): Unit 

def  saveAsTable(tableName: String): Unit 
def  sortBy(colName: String, colNames: String*): DataFrameWriter[T] 
def  text(path: String): Unit 

//csv options 
//py 
csv(path, mode=None, compression=None, sep=None, quote=None, escape=None, header=None, 
    nullValue=None, escapeQuotes=None, quoteAll=None, dateFormat=None, timestampFormat=None)
    
//scala - use with option/options 
sep (default ,): sets the single character as a separator for each field and value.
?quote (default "): sets" the single character used for escaping quoted values where the separator can be part of the value.
?escape (default \): sets the single character used for escaping quotes inside an already quoted value.
?escapeQuotes (default true): a flag indicating whether values containing quotes should always be enclosed in quotes. Default is to escape all values containing a quote character.
?quoteAll (default false): A flag indicating whether all values should always be enclosed in quotes. Default is to only escape values containing a quote character.
?header (default false): writes the names of columns as the first line.
?nullValue (default empty string): sets the string representation of a null value.
?compression (default null): compression codec to use when saving to file. This can be one of the known case-insensitive shorten names (none, bzip2, gzip, lz4, snappy and deflate).
?dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
?timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type


//json options 
//py 
json(path, mode=None, compression=None, dateFormat=None, timestampFormat=None)

//scala - use with option/options 
 compression (default null): compression codec to use when saving to file. This can be one of the known case-insensitive shorten names (none, bzip2, gzip, lz4, snappy and deflate).
?dateFormat (default yyyy-MM-dd): sets the string that indicates a date format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to date type.
?timestampFormat (default yyyy-MM-dd'T'HH:mm:ss.SSSZZ): sets the string that indicates a timestamp format. Custom date formats follow the formats at java.text.SimpleDateFormat. This applies to timestamp type


///* Save Modes    
  
//scala/Java                     PY                         Meaning
SaveMode.ErrorIfExists (default) "error" (default)          When saving a DataFrame to a data source, if data already exists, an exception is expected to be thrown.  
SaveMode.Append                  "append"                   When saving a DataFrame to a data source, if data/table already exists, contents of the DataFrame are expected to be appended to existing data.  
SaveMode.Overwrite               "overwrite"                Overwrite mode means that when saving a DataFrame to a data source, if data/table already exists, existing data is expected to be overwritten by the contents of the DataFrame.  
SaveMode.Ignore                  "ignore"                   Ignore mode means that when saving a DataFrame to a data source, if data already exists, the save operation is expected to not save the contents of the DataFrame and to not change the existing data. This is similar to a CREATE TABLE IF NOT EXISTS in SQL.  
 
//Example 
df.write.mode(org.apache.spark.sql.SaveMode.Ignore).parquet(path)
df.write.mode('append').parquet(path)

    
///* Saving to Persistent Tables
//DataFrames can also be saved as persistent tables into Hive metastore using the saveAsTable command.
//and loaded by 'table' methods 

//Notice existing Hive deployment is not necessary to use this feature. 
//Spark will create a default local Hive metastore (using Derby) for you
 
//By default saveAsTable will create a �managed table�, 
//meaning that the location of the data will be controlled by the metastore. Managed tables will also have their data deleted automatically when a table is dropped.
   
df.write..mode(org.apache.spark.sql.SaveMode.Overwrite).saveAsTable("tablename")
df = df.read.table("tablename")
   
   
///* Generic Load/Save Functions

///*scala    
val usersDF = spark.read.load(raw"D:\Desktop\PPT\spark\data/users.parquet")  //unicode escape because of backward-slash-and-u, so use /
usersDF.select("name", "favorite_color").write.save("namesAndFavColors.parquet")
    
  
    
    
///*Manually Specifying Options   
 
///*scala     
val peopleDF = spark.read.format("json").load("people.json")
peopleDF.select("name", "age").write.format("parquet").save("namesAndAges.parquet")


    
///* Run SQL on files directly  
  
///*scala      
val sqlDF = spark.sql("SELECT * FROM parquet.`examples/src/main/resources/users.parquet`")

   
    
    
///*** Parquet Files
//Parquet is a columnar format that is supported by many other data processing systems
  

///*scala        
import spark.implicits._

val peopleDF = spark.read.json("examples/src/main/resources/people.json")

// DataFrames can be saved as Parquet files, maintaining the schema information
peopleDF.write.parquet("people.parquet")

// Read in the parquet file created above
// Parquet files are self-describing so the schema is preserved
// The result of loading a Parquet file is also a DataFrame
val parquetFileDF = spark.read.parquet("people.parquet")


  
///* Schema Merging
//Like ProtocolBuffer, Avro, and Thrift, Parquet also supports schema evolution. 
//Users can start with a simple schema, and gradually add more columns to the schema as needed. 


///*scala    
// This is used to implicitly convert an RDD to a DataFrame.
import spark.implicits._

// Create a simple DataFrame, store into a partition directory
val squaresDF = spark.sparkContext.makeRDD(1 to 5).map(i => (i, i * i)).toDF("value", "square")
squaresDF.write.parquet("data/test_table/key=1")

// Create another DataFrame in a new partition directory,
// adding a new column and dropping an existing column
val cubesDF = spark.sparkContext.makeRDD(6 to 10).map(i => (i, i * i * i)).toDF("value", "cube")
cubesDF.write.parquet("data/test_table/key=2")

// Read the partitioned table
val mergedDF = spark.read.option("mergeSchema", "true").parquet("data/test_table")
mergedDF.printSchema()




///* Hive metastore Parquet table conversion
//When reading from and writing to Hive metastore Parquet tables, 
//Spark SQL will try to use its own Parquet support instead of Hive SerDe for better performance. 
//This behavior is controlled by the spark.sql.hive.convertMetastoreParquet configuration, and is turned on by default.


///* Metadata Refreshing
//Spark SQL caches Parquet metadata for better performance
///*scala    
// spark is an existing SparkSession
spark.catalog.refreshTable("my_table")




///*** Configuration
//Configuration of Parquet can be done using the setConf method on SparkSession 
//or by running SET key=value commands using SQL.
//http://spark.apache.org/docs/latest/sql-programming-guide.html#configuration







///*** JSON Datasets

///*scala    
//This conversion can be done using SparkSession.read.json() on either an RDD of String, or a JSON file.
// A JSON dataset is pointed to by path.
// The path can be either a single text file or a directory storing text files
val path = "examples/src/main/resources/people.json"
val peopleDF = spark.read.json(path)

// The inferred schema can be visualized using the printSchema() method
peopleDF.printSchema()

val otherPeopleRDD = spark.sparkContext.makeRDD(
  """{"name":"Yin","address":{"city":"Columbus","state":"Ohio"}}""" :: Nil)
val otherPeople = spark.read.json(otherPeopleRDD)
otherPeople.show()




///*** JDBC To Other Databases
//This functionality should be preferred over using JdbcRDD
// --conf spark.executor.extraClassPath=postgresql-9.4.1207.jar if required in executor  
$ spark-shell --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar
$ pyspark --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar
$ spark-submit --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar

$ spark-shell --driver-class-path mysql-connector-java-5.1.34.jar  --jars mysql-connector-java-5.1.34.jar
$ spark-submit --driver-class-path mysql-connector-java-5.1.34.jar  --jars mysql-connector-java-5.1.34.jar
$ pyspark --driver-class-path mysql-connector-java-5.1.34.jar --jars mysql-connector-java-5.1.34.jar
///*scala    
// Note: JDBC loading and saving can be achieved via either the load/save or jdbc methods
// Loading data from a JDBC source
val jdbcDF = spark.read
  .format("jdbc")
  .option("url", "jdbc:postgresql:dbserver")
  .option("dbtable", "schema.tablename")
  .option("user", "username")
  .option("password", "password")
  .load()
//or 
val connectionProperties = new Properties()
connectionProperties.put("user", "username")
connectionProperties.put("password", "password")
val jdbcDF2 = spark.read
  .jdbc("jdbc:postgresql:dbserver", "schema.tablename", connectionProperties)

// Saving data to a JDBC source
jdbcDF.write
  .format("jdbc")
  .option("url", "jdbc:postgresql:dbserver")
  .option("dbtable", "schema.tablename")
  .option("user", "username")
  .option("password", "password")
  .save()

jdbcDF2.write
  .jdbc("jdbc:postgresql:dbserver", "schema.tablename", connectionProperties)


  
   
    
    
///*** Hive Table 
//Spark SQL also supports reading and writing data stored in Apache Hive
//If Hive dependencies can be found on the classpath, Spark will load them automatically. 
//Note that these Hive dependencies must also be present on all of the worker nodes, as they will need access to the Hive serialization and deserialization libraries (SerDes) in order to access data stored in Hive.

//Configuration of Hive is done by placing your hive-site.xml
//Users who do not have an existing Hive deployment can still enable Hive support
//When not configured by the hive-site.xml, the context automatically creates metastore_db in the current directory and creates a directory configured by spark.sql.warehouse.dir, which defaults to the directory spark-warehouse in the current directory that the Spark application is started

///*scala    
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession

case class Record(key: Int, value: String)

// warehouseLocation points to the default location for managed databases and tables
val warehouseLocation = "spark-warehouse"

val spark = SparkSession
  .builder()
  .appName("Spark Hive Example")
  .config("spark.sql.warehouse.dir", warehouseLocation)
  .enableHiveSupport()
  .getOrCreate()

import spark.implicits._
import spark.sql

sql("CREATE TABLE IF NOT EXISTS src (key INT, value STRING)")
sql("LOAD DATA LOCAL INPATH 'examples/src/main/resources/kv1.txt' INTO TABLE src")



///* Interacting with Different Versions of Hive Metastore
//http://spark.apache.org/docs/latest/sql-programming-guide.html#interacting-with-different-versions-of-hive-metastore


///*ERROR - Caused by: java.lang.IllegalArgumentException: java.net.URISyntaxException: Relative path in absolute URI: file:spark-warehouse
//Solution*
//spark.sql.warehouse.dir to some properly-referenced directory, 
//say file:///tmp/spark-warehouse that uses /// (triple slashes), it creates under c:/tmp
 
 
 
///* Using Hadoop Hive 
///* Installing Hive 
//Download http://redrockdigimark.com/apachemirror/hive/hive-2.1.1/apache-hive-2.1.1-bin.tar.gz

//Untar to c:\hive 
//Set HIVE_HOME=c:\hive 
//Include PATH to c:\hive\bin 

//The Hive metastore service stores the metadata for Hive tables 
//and partitions in a relational database, and provides clients (including Hive) access 
//to this information using the metastore service API. Use MySql for storing metadata

//Download mysql-connector-java-5.0.5.jar file and copy the jar file to %HIVE_HOME%/lib 

//Go to MySQL command-line and execute the below commands 
// we launch the MySQL daemon via (CYGWIN)
$ /usr/bin/mysqld_safe &
//shutdown
mysqladmin.exe -h 127.0.0.1 -u root   --connect-timeout=5 shutdown

$ mysql -u root -p
Enter password:
mysql> CREATE DATABASE metastore_db;

#Create a User [hiveuser] in MySQL database using root user. 
# hiveuser as �userhive� and hivepassword as �hivepwd�

mysql> CREATE USER 'userhive'@'%' IDENTIFIED BY 'hivepwd';
mysql> GRANT all on *.* to 'userhive'@localhost identified by 'hivepwd';

mysql> flush privileges;


//Configure the Metastore Service to communicate with the MySQL Database.
//conf/hive-site.xml
<configuration>
    <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://localhost:3306/metastore_db?createDatabaseIfNotExist=true</value>
        <description>metadata is stored in a MySQL server</description>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
        <description>MySQL JDBC driver class</description>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>userhive</value>
        <description>user name for connecting to mysql server </description>
    </property>
    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>hivepwd</value>
        <description>password for connecting to mysql server </description>
    </property>
    <property>
        <name>datanucleus.schema.autoCreateAll</name>
        <value>true</value>
     </property>
     <property>
        <name>datanucleus.schema.autoCreateTables</name>
        <value>true</value>
     </property>
     <property>
        <name>hive.metastore.schema.verification</name>
        <value>false</value>
     </property>    
</configuration>

//start-dfs & start-yarn 
//hive needs both dfs and yarn


$ hive 
hive> create external table studentpq3 (id STRING, name STRING, phone STRING, email STRING) STORED AS PARQUET;

//Hive 0.10 - 0.12, 
//copy parquet-hadoop-1.8.1.jar, parquet-hive-bundle-1.6.0.jar to %HIVE_HOME%/lib 
 create external table studentpq2 (id STRING, name STRING, phone STRING, email STRING)
  ROW FORMAT SERDE 'parquet.hive.serde.ParquetHiveSerDe'
  STORED AS 
    INPUTFORMAT "parquet.hive.DeprecatedParquetInputFormat"
    OUTPUTFORMAT "parquet.hive.DeprecatedParquetOutputFormat";
//Hive 0.13 and later - native support  
create external table studentpq3 (id STRING, name STRING, phone STRING, email STRING)
STORED AS PARQUET;


//Verifying HIVE installation
hive> show tables;
OK
Time taken: 2.798 seconds
hive> select * from studentpq3;
hive> select count(*) from studentpq3;

//MySql console:
$ mysql -u userhive -phivepwd metastore_db
mysql> show tables;


///* Using spark-hadoop-hive 
//Start 
hadoop-dfs & hadoop-yarn 

//copy c:\hive\conf\hive-site.xml to c:\spark\conf  . Note rename it after use else spark-shell fails 

//after running below code, check in hive 
hive> select count(*) from studentpq3;
100 



///*scala 
// $ spark-submit --class examples.SparkHiveExample2  --master local[4] target/scala-2.11/learning-assembly.jar

import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession


object SparkHiveExample2 {


  case class Student (id:String, name:String, phone:String, email:String)


  def main(args: Array[String]) {
    // When working with Hive, one must instantiate `SparkSession` with Hive support, including
    // connectivity to a persistent Hive metastore, support for Hive serdes, and Hive user-defined
    // functions. Users who do not have an existing Hive deployment can still enable Hive support.
    // When not configured by the hive-site.xml, the context automatically creates `metastore_db`
    // in the current directory and creates a directory configured by `spark.sql.warehouse.dir`,
    // which defaults to the directory `spark-warehouse` in the current directory that the spark
    // application is started.

    
    // warehouseLocation points to the default location for managed databases and tables
    val warehouseLocation = "file:///tmp/spark-warehouse"

    val spark = SparkSession
      .builder()
      .appName("Spark Hive Example")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()

    import spark.implicits._
    import spark.sql
    
      
    val students = spark.read.format("csv")
                           .option("sep", "|")
                           .option("header", true)
                           .load(raw"D:\Desktop\PPT\spark\data\StudentDataHeader.csv").as[Student]
                           
    students.show()
    students.write.mode(org.apache.spark.sql.SaveMode.Overwrite).saveAsTable("studentpq3")
    
    
    

    // Queries are expressed in HiveQL
    sql("SELECT * FROM studentpq3").show()
    
    // Aggregation queries are also supported.
    sql("SELECT COUNT(*) FROM studentpq3").show()
    

    // The results of SQL queries are themselves DataFrames and support all normal functions.
    val sqlDF = sql("SELECT name, email FROM studentpq3 WHERE id < 10 ORDER BY name")

    sqlDF.show()
    
    
    // read
    val studentDFrame = spark.read.table("studentpq3").as[Student]
    
    studentDFrame.createOrReplaceTempView("studentsView")

    // Queries can then join DataFrame data with data stored in Hive.
    sql("SELECT * FROM studentsView r JOIN studentpq3 s ON r.id = s.id").show()
    

    spark.stop()
  }
}

 
 
///* Avro 
//Using SBT:
libraryDependencies += "com.databricks" %% "spark-avro" % "3.2.0"
//using command ine 
$ bin/spark-shell --driver-class-path spark-avro_2.11-3.2.0.jar --packages com.databricks:spark-avro_2.11:3.2.0
$ bin/spark-submit  --driver-class-path spark-avro_2.11-3.2.0.jar --packages com.databricks:spark-avro_2.11:3.2.0
 
//*  Avro -> Spark SQL conversion

//Avro type       Spark SQL type
boolean         BooleanType 
int             IntegerType 
long            LongType 
float           FloatType 
double          DoubleType 
bytes           BinaryType 
string          StringType 
record          StructType 
enum            StringType 
array           ArrayType 
map             MapType 
fixed           BinaryType 
union           
//Example of union 
1. union(int, long)  will be mapped to  LongType .
2. union(float, double)  will be mapped to  DoubleType .
3. union(something, null) , where  something  is any supported Avro type. This will be mapped to the same Spark SQL type as that of  something , with  nullable  set to  true .
//All other  union  types are considered complex. 
//They will be mapped to  StructType  where field names are  member0 ,  member1 , etc., in accordance with members of the  union . This is consistent with the behavior when converting between Avro and Parquet.

///* Spark SQL -> Avro conversion
Spark SQL type      Avro type
ByteType            int 
ShortType           int 
DecimalType         string 
BinaryType          bytes 
TimestampType       long 
StructType          record 



//Example schema - Json notation 
//user.avsc 
{"namespace": "example.avro",
 "type": "record",
 "name": "User",
 "fields": [
     {"name": "name", "type": "string"},
     {"name": "favorite_color", "type": ["string", "null"]},
     {"name": "favorite_numbers", "type": {"type": "array", "items": "int"}}
 ]
}



//reading & and writing
import com.databricks.spark.avro._

// The Avro records get converted to Spark types, filtered, and// then written back out as Avro records
val df = spark.read.avro(raw"D:/Desktop/PPT/spark/data/users.avro")
df.filter("name = 'Ben'").write.mode(org.apache.spark.sql.SaveMode.Overwrite).avro(raw"D:/Desktop/PPT/spark/data/output.avro")

//Alternatively you can specify the format to use instead:


val df = spark.read
    .format("com.databricks.spark.avro")
    .load(raw"D:/Desktop/PPT/spark/data/users.avro")

df.filter("name = 'Ben'").write.mode(org.apache.spark.sql.SaveMode.Overwrite).format("com.databricks.spark.avro").save(raw"D:/Desktop/PPT/spark/data/output.avro")

//You can specify a custom Avro schema: 
import org.apache.avro.Schema
import com.databricks.spark.avro._

//schema can contain subset of fields, only thos fields would be imported 
val schema = new Schema.Parser().parse(new java.io.File(raw"D:/Desktop/PPT/spark/data/user.avsc"))
val df = spark
  .read
  .format("com.databricks.spark.avro")
  .option("avroSchema", schema.toString)
  .load(raw"D:/Desktop/PPT/spark/data/users.avro")
  
df.show()

// Prepare a customized schema
val struct = StructType(StructField("name", StringType, true) :: Nil)

spark.read.format("com.databricks.spark.avro").schema(struct).load(raw"D:/Desktop/PPT/spark/data/users.avro").show()


// Save the schema to a Json string, you can later save this to a file.
val j = struct.json   //res6: String = {"type":"struct","fields":[{"name":"a","type":"integer","nullable":true,"metadata":{}}]}

// Load the Json string back
spark.read.format("com.databricks.spark.avro").schema(DataType.fromJson(j).asInstanceOf[StructType]).load(raw"D:/Desktop/PPT/spark/data/users.avro").show()


 
//You can also specify Avro compression options:

import com.databricks.spark.avro._

// configuration to use deflate compression
spark.conf.set("spark.sql.avro.compression.codec", "deflate")
spark.conf.set("spark.sql.avro.deflate.level", "5")

val df = spark.read.avro(raw"D:/Desktop/PPT/spark/data/user.avro")

// writes out compressed Avro records
df.write.avro("/tmp/output")

//You can write partitioned Avro records like this:

import com.databricks.spark.avro._
import org.apache.spark.sql.SparkSession

val spark = SparkSession.builder().master("local").getOrCreate()

val df = spark.createDataFrame(
  Seq(
    (2012, 8, "Batman", 9.8),
    (2012, 8, "Hero", 8.7),
    (2012, 7, "Robot", 5.5),
    (2011, 7, "Git", 2.0))
  ).toDF("year", "month", "title", "rating")

df.toDF.write.partitionBy("year", "month").avro(raw"D:/Desktop/PPT/spark/data/output")

//You can specify the record name and namespace like this:

import com.databricks.spark.avro._
import org.apache.spark.sql.SparkSession

val spark = SparkSession.builder().master("local").getOrCreate()
val df = spark.read.avro("src/test/resources/user.avro")

val name = "AvroTest"
val namespace = "com.databricks.spark.avro"
val parameters = Map("recordName" -> name, "recordNamespace" -> namespace)

df.write.options(parameters).avro(raw"D:/Desktop/PPT/spark/data/output")




///*** libsvm
//org.apache.spark.ml.source.libsvm.LibSVMDataSource


//The loaded DataFrame has two columns: label containing labels stored as doubles 
//and features containing feature vectors stored as Vectors.

val df = spark.read.format("libsvm")
  .option("numFeatures", "780")
  .load("data/mllib/sample_libsvm_data.txt")


//LIBSVM data source supports the following options:
?"numFeatures": number of features. If unspecified or nonpositive, the number of features will be determined automatically at the cost of one additional pass. This is also useful when the dataset is already split into multiple files and you want to load them separately, because some features may not present in certain files, which leads to inconsistent feature dimensions.
?"vectorType": feature vector type, "sparse" (default) or "dense". 








 
///*** Random data generation
//Generator methods for creating RDDs comprised of i.i.d. samples from some distribution. 
//import from 
import org.apache.spark.mllib.random.RandomRDDs
import pyspark.mllib.random.RandomRDDs

//has below methods (for full reference, check docs) 

def  exponentialRDD(sc: SparkContext, mean: Double, size: Long, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Double] 
def  exponentialVectorRDD(sc: SparkContext, mean: Double, numRows: Long, numCols: Int, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Vector] 
def  gammaRDD(sc: SparkContext, shape: Double, scale: Double, size: Long, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Double] 
def  gammaVectorRDD(sc: SparkContext, shape: Double, scale: Double, numRows: Long, numCols: Int, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Vector] 
def  logNormalRDD(sc: SparkContext, mean: Double, std: Double, size: Long, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Double] 
def  logNormalVectorRDD(sc: SparkContext, mean: Double, std: Double, numRows: Long, numCols: Int, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Vector] 

//To transform the distribution in the generated RDD from standard normal to some other normal N(mean, sigma2), 
//use RandomRDDs.normalRDD(sc, n, p, seed).map(v => mean + sigma * v). 
def  normalRDD(sc: SparkContext, size: Long, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Double] 
def  normalVectorRDD(sc: SparkContext, numRows: Long, numCols: Int, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Vector] 
def  poissonRDD(sc: SparkContext, mean: Double, size: Long, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Double] 
def  poissonVectorRDD(sc: SparkContext, mean: Double, numRows: Long, numCols: Int, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Vector] 

//To transform the distribution in the generated RDD from U(0.0, 1.0) to U(a, b), 
//use RandomRDDs.uniformRDD(sc, n, p, seed).map(v => a + (b - a) * v). 
def  uniformRDD(sc: SparkContext, size: Long, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Double] 
def  uniformVectorRDD(sc: SparkContext, numRows: Long, numCols: Int, numPartitions: Int = 0, seed: Long = Utils.random.nextLong()): RDD[Vector] 



///*scala 
import org.apache.spark.SparkContext
import org.apache.spark.mllib.random.RandomRDDs._

val sc: SparkContext = ...

// Generate a random double RDD that contains 1 million i.i.d. values drawn from the
// standard normal distribution `N(0, 1)`, evenly distributed in 10 partitions.
val u = normalRDD(sc, 1000000L, 10)
// Apply a transform to get a random double RDD following `N(1, 4)`.
val v = u.map(x => 1.0 + 2.0 * x)



///*** Difference between ML and Mlib 
//ML
�New
�Pipelines
�Dataframes
�Easier to construct a practical machine learning pipeline

//MLlib
�Old
�RDD
�More features


///******  ML/MLIB Genereal FLow ******/
///*** General flow of classification, regression 

//0. Create a Pipeline having (Optional)
//1. Feature Transformers to convert input data 
//    input data is DF for ML and LabeledPoint for mlib 
//    (containing label, features columns - could be dense or sparse Vector ) 
//    sparse vector is identified by [#of_features, [indices], [corresponding_values]]
//2. Classification or regression stage of transformed data 
//3. if required inverse transformation of step 1
//4. Random split input data into training and test 
//5. Pipline fit of training data to get 'model' 
//6. predictions = model.transform(testData) to get prediction 
//     Note in MLIB, call  predict
//7. Form ML, Use 'evaluate' of MulticlassClassificationEvaluator or BinaryClassificationEvaluator or RegressionEvaluator with above predictions 
//   MulticlassClassificationEvaluator supports metricName as "f1" (default), "weightedPrecision", "weightedRecall", "accuracy")
//   BinaryClassificationEvaluator (supports "areaUnderROC" (default), "areaUnderPR")
//   RegressionEvaluator supports "rmse" (default): root mean squared error,"mse": mean squared error,"r2": R2 metric,"mae": mean absolute error 
//7. For MLIB, similarly use many Metrics classes 
//8. Note for Binary class or regression of test or training data , 
//   can get Summary from BinaryLogisticRegressionSummary/LinearRegressionSummary/GeneralizedLinearRegressionSummary from model.summary 
//   check 'lazy val' variables which are importants for summary
//   BinaryLogisticRegressionSummary have predictions 
//   RegressionSummary have pValues, coefficientStandardErrors(form normal solver), residuals, aic (for GLM)



///* Input Columns - ML 
//Param name  Type(s)     Default     Description
labelCol    Double      "label"     Label to predict 
featuresCol Vector      "features"  Feature vector 

///* Output Columns- ML 
//Param name          Type(s)     Default         Description
predictionCol       Double      "prediction"    Predicted label  
rawPredictionCol    Vector      "rawPrediction" Vector of length # classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"   Vector of length # classes equal to rawPrediction normalized to a multinomial distribution Classification only 
varianceCol         Double                      The biased sample variance of prediction Regression only 


///*** netlib-java for x64
//sbt 
"com.github.fommil.netlib" % "all" % "1.1.2" pomOnly(),
//Via PATH below libs should be available 
libquadmath-0.dll //MINGW
libwinpthread-1.dll //MINGW
libgcc_s_seh-1.dll //MINGW
libgfortran-3.dll //MINGW
liblapack3.dll //OpenBLAS copy of libopenblas.dll
libblas3.dll //OpenBLAS copy of libopenblas.dll
netlib-native_system-win-x86_64.dll //netlib-java

//download from 
�MINGW64: file x64-4.8.0-release-posix-seh-rev2.7z 
https://sourceforge.net/projects/mingwbuilds/files/host-windows/releases/4.8.0/64-bit/threads-posix/seh/
�OpenBLAS: http://www.openblas.net/
�Netlib-java: http://search.maven.org/#search%7Cga%7C1%7Ca%3A%22netlib-native_system-win-x86_64%22 
(dll is inside the jar)




///******  Feature extraction /seletion - Tokenizer, StringIndex,.., PCA  ******/

///*** Extracting, transforming and selecting features
�Extraction: Extracting features from �raw� data
�Transformation: Scaling, converting, or modifying features
�Selection: Selecting a subset from a larger set of features

import org.apache.spark.ml.feature._ 

///*Note in ML 
//DataFrame column might be Array/Vector  ie each row is a  Vector where a element might be Iterable 
//eg Tokenizer converts one element of Row  to Array element 
//Some Transformation works on Column of Vector or convert Vector to Vector or simple element to Vector 

//At the end for ML algorithm, "label" should be Double and 
//"features" should be vector (dense or Sparse - eg (20,[0,5,9,17],[1.0,1.0,1.0,2.0])  )

//Note when ML speak of a feature, it is Column of DataFrame 
//ie ROw of DF is a on row of all features value 

///*Summary 
//�Feature Extractors 
?TF-IDF     
    Term frequency-inverse document frequency (TF-IDF) is multiplication of TF(HashingTF and CountVectorizer) and IDF 
    Reflects the importance of a term to a document 
    TF - generates the term frequency vectors
    IDF -  it down-weights columns which appear frequently in the corpus 
    ///*Result (in-sentence, tokenizer - words, TF-rawfeatures, out/TF-IDF- features)
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |label|sentence                           |words                                     |rawFeatures                              |features                                                                                                              |
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |0.0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |(20,[0,5,9,17],[1.0,1.0,1.0,2.0])        |(20,[0,5,9,17],[0.6931471805599453,0.6931471805599453,0.28768207245178085,1.3862943611198906])                        |
    |0.0  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|(20,[2,7,9,13,15],[1.0,1.0,3.0,1.0,1.0]) |(20,[2,7,9,13,15],[0.6931471805599453,0.6931471805599453,0.8630462173553426,0.28768207245178085,0.28768207245178085]) |
    |1.0  |Logistic regression models are neat|[logistic, regression, models, are, neat] |(20,[4,6,13,15,18],[1.0,1.0,1.0,1.0,1.0])|(20,[4,6,13,15,18],[0.6931471805599453,0.6931471805599453,0.28768207245178085,0.28768207245178085,0.6931471805599453])|
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+

?Word2Vec
    Transforms each column of Vector into a vector using the average of all words in the document
    ///*Result
    +------------------------------------------+----------------------------------------------------------------+
    |text                                      |result                                                          |
    +------------------------------------------+----------------------------------------------------------------+
    |[Hi, I, heard, about, Spark]              |[-0.008142343163490296,0.02051363289356232,0.03255096450448036] |
    |[I, wish, Java, could, use, case, classes]|[0.043090314205203734,0.035048123182994974,0.023512658663094044]|
    |[Logistic, regression, models, are, neat] |[0.038572299480438235,-0.03250147425569594,-0.01552378609776497]|
    +------------------------------------------+----------------------------------------------------------------+

    
?CountVectorizer
    Converts a collection of text documents to vectors of token counts.
    ///*Result 
    +---+---------------+-------------------------+
    |id |words          |features                 |
    +---+---------------+-------------------------+
    |0  |[a, b, c]      |(3,[0,1,2],[1.0,1.0,1.0])|
    |1  |[a, b, b, c, a]|(3,[0,1,2],[2.0,2.0,1.0])|
    +---+---------------+-------------------------+

//�Feature Transformers 
?Tokenizer    
    takes text (such as a sentence) and breakes it into individual terms (usually words). 
    ///*Result (RegexTokenizer - .setPattern("\\W"))
    +---+-----------------------------------+------------------------------------------+
    |id |sentence                           |words                                     |
    +---+-----------------------------------+------------------------------------------+
    |0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |
    |1  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|
    |2  |Logistic,regression,models,are,neat|[logistic, regression, models, are, neat] |
    +---+-----------------------------------+------------------------------------------+
    
?StopWordsRemover
    Removes Stop words are words which should be excluded from the input, 
    typically because the words appear frequently and don�t carry as much meaning.
    ///*Result 
    +---+----------------------------+--------------------+
    |id |raw                         |filtered            |
    +---+----------------------------+--------------------+
    |0  |[I, saw, the, red, balloon] |[saw, red, balloon] |
    |1  |[Mary, had, a, little, lamb]|[Mary, little, lamb]|
    +---+----------------------------+--------------------+
    
?n-gram
     transform input feature/a Column Vector into sequence of n tokens (typically words) for some integer n
     ///*Result - setN(2)
    +---+------------------------------------------+------------------------------------------------------------------+
    |id |words                                     |ngrams                                                            |
    +---+------------------------------------------+------------------------------------------------------------------+
    |0  |[Hi, I, heard, about, Spark]              |[Hi I, I heard, heard about, about Spark]                         |
    |1  |[I, wish, Java, could, use, case, classes]|[I wish, wish Java, Java could, could use, use case, case classes]|
    |2  |[Logistic, regression, models, are, neat] |[Logistic regression, regression models, models are, are neat]    |
    +---+------------------------------------------+------------------------------------------------------------------+

     

?Binarizer
    Converts numerical features to binary (0/1) features using a threashold
    ///*Result  - setThreshold(0.5)
    +---+-------+-----------------+
    |id |feature|binarized_feature|
    +---+-------+-----------------+
    |0  |0.1    |0.0              |
    |1  |0.8    |1.0              |
    |2  |0.2    |0.0              |
    +---+-------+-----------------+
    
?PCA
    Converts a set of observations of possibly correlated variables into a set of values 
    of linearly uncorrelated variables called principal components
    ///*Result   - setK(3)  
    +---------------------+-----------------------------------------------------------+
    |features             |pcaFeatures                                                |
    +---------------------+-----------------------------------------------------------+
    |(5,[1,3],[1.0,7.0])  |[1.6485728230883807,-4.013282700516296,-5.524543751369388] |
    |[2.0,0.0,3.0,4.0,5.0]|[-4.645104331781534,-1.1167972663619026,-5.524543751369387]|
    |[4.0,0.0,0.0,6.0,7.0]|[-6.428880535676489,-5.337951427775355,-5.524543751369389] |
    +---------------------+-----------------------------------------------------------+
    
?PolynomialExpansion
    expands your features into a polynomial space, 
    which is formulated by an n-degree combination of original dimensions.
    ///*Result - setDegree(3)
    +----------+------------------------------------------+
    |features  |polyFeatures                              |
    +----------+------------------------------------------+
    |[2.0,1.0] |[2.0,4.0,8.0,1.0,2.0,4.0,1.0,2.0,1.0]     |
    |[0.0,0.0] |[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]     |
    |[3.0,-1.0]|[3.0,9.0,27.0,-1.0,-3.0,-9.0,1.0,3.0,-1.0]|
    +----------+------------------------------------------+
    
?Discrete Cosine Transform (DCT)
    transforms a length N real-valued Vector COlumn in the time domain 
    into another length N real-valued Vector COlumn  in the frequency domain
    /// Result
   +--------------------+----------------------------------------------------------------+
    |features            |featuresDCT                                                     |
    +--------------------+----------------------------------------------------------------+
    |[0.0,1.0,-2.0,3.0]  |[1.0,-1.1480502970952693,2.0000000000000004,-2.7716385975338604]|
    |[-1.0,2.0,4.0,-7.0] |[-1.0,3.378492794482933,-7.000000000000001,2.9301512653149677]  |
    |[14.0,-2.0,-5.0,1.0]|[4.0,9.304453421915744,11.000000000000002,1.5579302036357163]   |
    +--------------------+----------------------------------------------------------------+
 
    
?StringIndexer
     Encodes a string column of labels to a column of label indices. 
     The indices are in [0, numLabels), ordered by label frequencies, so the most frequent label gets index 0
    ///* Result 
    +---+--------+-------------+
    |id |category|categoryIndex|
    +---+--------+-------------+
    |0  |a       |0.0          |
    |1  |b       |2.0          |
    |2  |c       |1.0          |
    |3  |a       |0.0          |
    |4  |a       |0.0          |
    |5  |c       |1.0          |
    +---+--------+-------------+
   
?IndexToString
     Converts column of label indices back to a column containing the original labels as strings
    ///* Result 
    +---+--------+-------------+----------------+
    |id |category|categoryIndex|originalCategory|
    +---+--------+-------------+----------------+
    |0  |a       |0.0          |a               |
    |1  |b       |2.0          |b               |
    |2  |c       |1.0          |c               |
    |3  |a       |0.0          |a               |
    |4  |a       |0.0          |a               |
    |5  |c       |1.0          |c               |
    +---+--------+-------------+----------------+
 
 
?OneHotEncoder
    maps a column of label indices to a column of binary vectors, with at most a single one-value
    This encoding allows algorithms which expect continuous features, such as Logistic Regression, to use categorical features
    eg Use StringIndexer and the OneHotEncoder to convert string category to column to be used for Logit 
    ///* Result - in:category, StringIndexer:categoryIndex, out:categoryVec
    +---+--------+-------------+-------------+
    |id |category|categoryIndex|categoryVec  |
    +---+--------+-------------+-------------+
    |0  |a       |0.0          |(2,[0],[1.0])|
    |1  |b       |2.0          |(2,[],[])    |
    |2  |c       |1.0          |(2,[1],[1.0])|
    |3  |a       |0.0          |(2,[0],[1.0])|
    |4  |a       |0.0          |(2,[0],[1.0])|
    |5  |c       |1.0          |(2,[1],[1.0])|
    +---+--------+-------------+-------------+
    
?VectorIndexer
    Takes an input columns of type Vector and a parameter maxCategories for knowing which column is to taken as categorical
    Computes 0-based category indices for each categorical feature/column.
    ///* Result - setMaxCategories(2)
    +---+--------------+--------------+
    |id |features      |indexed       |
    +---+--------------+--------------+
    |0  |[1.0,0.5,-1.0]|[0.0,0.0,-1.0]|
    |1  |[1.0,1.0,1.0] |[0.0,1.0,1.0] |
    |2  |[4.0,0.5,2.0] |[1.0,0.0,2.0] |
    +---+--------------+--------------+
    
    
?Interaction
    takes vector or double-valued columns, and generates a single vector column 
    that contains the product of all combinations of one value from each input column
    ///*Result, vec1<- VectorAssembler("id2", "id3", "id4"), vec2 <-VectorAssembler("id5", "id6", "id7")
    // output = interactedCol of vec1 and vec2
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |id1|id2|id3|id4|id5|id6|id7|vec1          |vec2          |interactedCol                                         |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |1  |1  |2  |3  |8  |4  |5  |[1.0,2.0,3.0] |[8.0,4.0,5.0] |[8.0,4.0,5.0,16.0,8.0,10.0,24.0,12.0,15.0]            |
    |2  |4  |3  |8  |7  |9  |8  |[4.0,3.0,8.0] |[7.0,9.0,8.0] |[56.0,72.0,64.0,42.0,54.0,48.0,112.0,144.0,128.0]     |
    |3  |6  |1  |9  |2  |3  |6  |[6.0,1.0,9.0] |[2.0,3.0,6.0] |[36.0,54.0,108.0,6.0,9.0,18.0,54.0,81.0,162.0]        |
    |4  |10 |8  |6  |9  |4  |5  |[10.0,8.0,6.0]|[9.0,4.0,5.0] |[360.0,160.0,200.0,288.0,128.0,160.0,216.0,96.0,120.0]|
    |5  |9  |2  |7  |10 |7  |3  |[9.0,2.0,7.0] |[10.0,7.0,3.0]|[450.0,315.0,135.0,100.0,70.0,30.0,350.0,245.0,105.0] |
    |6  |1  |1  |4  |2  |8  |4  |[1.0,1.0,4.0] |[2.0,8.0,4.0] |[12.0,48.0,24.0,12.0,48.0,24.0,48.0,192.0,96.0]       |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+

?Normalizer
    transforms a dataset of Vector rows, normalizing each Vector to have p-norm
    ///* Result - setP(1.0)
    +---+--------------+------------------+
    |id |features      |normFeatures      |
    +---+--------------+------------------+
    |0  |[1.0,0.5,-1.0]|[0.4,0.2,-0.4]    |
    |1  |[2.0,1.0,1.0] |[0.5,0.25,0.25]   |
    |2  |[4.0,10.0,2.0]|[0.25,0.625,0.125]|
    +---+--------------+------------------+
 
?StandardScaler
    transforms a dataset of rows, normalizing each feature(ie Column) 
    to have unit standard deviation and/or zero mean. 
    ///*Result - setWithStd(true),setWithMean(false)
    +---+--------------+------------------------------------------------------------+
    |id |features      |scaledFeatures                                              |
    +---+--------------+------------------------------------------------------------+
    |0  |[1.0,0.5,-1.0]|[0.6546536707079771,0.09352195295828246,-0.6546536707079771]|
    |1  |[2.0,1.0,1.0] |[1.3093073414159542,0.18704390591656492,0.6546536707079771] |
    |2  |[4.0,10.0,2.0]|[2.6186146828319083,1.8704390591656492,1.3093073414159542]  |
    +---+--------------+------------------------------------------------------------+

    
?MinMaxScaler
    MinMaxScaler transforms a dataset of rows, 
    rescaling each feature(ie Column) to a specific range (often [0, 1]). 
    ///* Result
    +---+--------------+--------------+
    |id |features      |scaledFeatures|
    +---+--------------+--------------+
    |0  |[1.0,0.1,-1.0]|[0.0,0.0,0.0] |
    |1  |[2.0,1.1,1.0] |[0.5,0.1,0.5] |
    |2  |[3.0,10.1,3.0]|[1.0,1.0,1.0] |
    +---+--------------+--------------+

 
?MaxAbsScaler
    transforms a dataset of rows, rescaling each feature(ie COlumn) to range [-1, 1]
    ///* Result
    +---+--------------+----------------+
    |id |features      |scaledFeatures  |
    +---+--------------+----------------+
    |0  |[1.0,0.1,-8.0]|[0.25,0.01,-1.0]|
    |1  |[2.0,1.0,-4.0]|[0.5,0.1,-0.5]  |
    |2  |[4.0,10.0,8.0]|[1.0,1.0,1.0]   |
    +---+--------------+----------------+
   
?Bucketizer
    transforms a column of continuous feature to a column of feature bucket index(after n splits)
    ///*Result - .setSplits(Array(Double.NegativeInfinity, -0.5, 0.0, 0.5, Double.PositiveInfinity))
    +--------+----------------+
    |features|bucketedFeatures|
    +--------+----------------+
    |-999.9  |0.0             |
    |-0.5    |1.0             |
    |-0.3    |1.0             |
    |0.0     |2.0             |
    |0.2     |2.0             |
    |999.9   |3.0             |
    +--------+----------------+



 
?ElementwiseProduct
    scales each column of the dataset by a scalar multiplier.
    ///*Result with Vectors.dense(0.0, 1.0, 2.0)
    +---+-------------+-----------------+
    |id |vector       |transformedVector|
    +---+-------------+-----------------+
    |a  |[1.0,2.0,3.0]|[0.0,2.0,6.0]    |
    |b  |[4.0,5.0,6.0]|[0.0,5.0,12.0]   |
    +---+-------------+-----------------+
    
?SQLTransformer
    transforms column via SQL statement 
    ///*Result "SELECT *, (v1 + v2) AS v3, (v1 * v2) AS v4 "
    +---+---+---+---+----+
    |id |v1 |v2 |v3 |v4  |
    +---+---+---+---+----+
    |0  |1.0|3.0|4.0|3.0 |
    |2  |2.0|5.0|7.0|10.0|
    +---+---+---+---+----+
    
?VectorAssembler
    combines a given list of columns into a single vector column
    ///*Result - features <- Array("hour", "mobile", "userFeatures")    
    +---+----+------+--------------+-------+-----------------------+
    |id |hour|mobile|userFeatures  |clicked|features               |
    +---+----+------+--------------+-------+-----------------------+
    |0  |18  |1.0   |[0.0,10.0,0.5]|1.0    |[18.0,1.0,0.0,10.0,0.5]|
    +---+----+------+--------------+-------+-----------------------+
?QuantileDiscretizer
    takes a column with continuous feature and outputs a column with binned categorical feature( eg n bin)
    ///*Result - setNumBuckets(3), in= hour, out=result     
    +---+----+------+
    |id |hour|result|
    +---+----+------+
    |0  |18.0|2.0   |
    |1  |19.0|2.0   |
    |2  |8.0 |1.0   |
    |3  |5.0 |1.0   |
    |4  |2.2 |0.0   |
    +---+----+------+

//�Feature Selectors 
?VectorSlicer
    extracts subfeatures from a vector column.
    ///*Result   - setIndices(Array(1)) or setIndices(Array(1, 2)), in=   userFeatures
    +--------------------+-------------+
    |userFeatures        |features     |
    +--------------------+-------------+
    |(3,[0,1],[-2.0,2.3])|(2,[0],[2.3])|
    |[-2.0,2.3,0.0]      |[2.3,0.0]    |
    +--------------------+-------------+
    
?RFormula
    selects columns specified by an R model formula
    ///*Result - .setFormula("clicked ~ country + hour").setFeaturesCol("features").setLabelCol("label")
    // hence label = clicked , features = country + hour
    +---+-------+----+-------+--------------+-----+
    |id |country|hour|clicked|features      |label|
    +---+-------+----+-------+--------------+-----+
    |7  |US     |18  |1.0    |[0.0,0.0,18.0]|1.0  |
    |8  |CA     |12  |0.0    |[1.0,0.0,12.0]|0.0  |
    |9  |NZ     |15  |0.0    |[0.0,1.0,15.0]|0.0  |
    +---+-------+----+-------+--------------+-----+

    
?ChiSqSelector
    uses the Chi-Squared test of independence to decide which features to choose(by numTopFeatures, percentile , fpr)
    ///*Result - .setNumTopFeatures(1)
    // top 1 features selected, out=    selectedFeatures, in=features
    +---+------------------+-------+----------------+
    |id |features          |clicked|selectedFeatures|
    +---+------------------+-------+----------------+
    |7  |[0.0,0.0,18.0,1.0]|1.0    |[18.0]          |
    |8  |[0.0,1.0,12.0,0.0]|0.0    |[12.0]          |
    |9  |[1.0,0.0,15.0,0.1]|0.0    |[15.0]          |
    +---+------------------+-------+----------------+
    
?Userdefined Transformer 
    eg Add a constant term to input via extending UnaryTransformer
    ///*Result - setShift(0.5)
    +-----+------+
    |input|output|
    +-----+------+
    |0.0  |0.5   |
    |1.0  |1.5   |
    |2.0  |2.5   |
    |3.0  |3.5   |
    |4.0  |4.5   |
    +-----+------+
    
?Locality Sensitive Hashing
    a class of hashing techniques
    Two algorithms - Bucketed Random Projection for Euclidean Distance(hash bucket based on Euclidian distance)
    MinHash for Jaccard Distance 
    Various operations possibles
    Example - Bucketed Random Projection for Euclidean Distance
    ///* Result - .setBucketLength(2.0).setNumHashTables(3), in=keys, out=values 
    +---+-----------+-----------------------+
    |id |keys       |values                 |
    +---+-----------+-----------------------+
    |0  |[1.0,1.0]  |[[0.0], [0.0], [-1.0]] |
    |1  |[1.0,-1.0] |[[-1.0], [-1.0], [0.0]]|
    |2  |[-1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    |3  |[-1.0,1.0] |[[0.0], [0.0], [-1.0]] |
    +---+-----------+-----------------------+

    +---+----------+-----------------------+
    |id |keys      |values                 |
    +---+----------+-----------------------+
    |4  |[1.0,0.0] |[[0.0], [-1.0], [-1.0]]|
    |5  |[-1.0,0.0]|[[-1.0], [0.0], [0.0]] |
    |6  |[0.0,1.0] |[[0.0], [0.0], [-1.0]] |
    |7  |[0.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    +---+----------+-----------------------+
    ///*Result - Approximate similarity join with threashold= 1.5 
    // in= datasetA,datasetB (from above), out= below full DF 
    //check each row, eg id 1 is joined with id 4 with distCol = 1.0 (min)
    +---------------------------------------------------+--------------------------------------------------+-------+
    |datasetA                                           |datasetB                                          |distCol|
    +---------------------------------------------------+--------------------------------------------------+-------+
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    +---------------------------------------------------+--------------------------------------------------+-------+
    ///*Result - Approximate nearest neighbor search, for Vectors.dense(1.0, 0.0)
    ///in= datsetA(from above), out= below DF showing which ids are nearer via distCol=1.0 min 
    +---+----------+-----------------------+-------+
    |id |keys      |values                 |distCol|
    +---+----------+-----------------------+-------+
    |1  |[1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|1.0    |
    |0  |[1.0,1.0] |[[0.0], [0.0], [-1.0]] |1.0    |
    +---+----------+-----------------------+-------+
    
    
    
    
    


///*** Feature Extractors - TF-IDF
//Term frequency-inverse document frequency (TF-IDF) is a feature vectorization method 
//widely used in text mining to reflect the importance of a term to a document 

///* TF-IDF - ML 
//The TF-IDF measure is the product of TF and IDF
//TF: Both HashingTF and CountVectorizer can be used to generate the term frequency vectors
//IDF: IDF is an Estimator which is fit on a dataset and produces an IDFModel. 
//The IDFModel takes feature vectors (generally created from HashingTF or CountVectorizer) and scales each column. 
//Intuitively, it down-weights columns which appear frequently in a corpus.

//CountVectorizer converts text documents to vectors of term counts
//HashingTF is a Transformer which takes sets of terms(words) and converts those sets into fixed-length feature vectors

//Tokenization is the process of taking text (such as a sentence) and breaking it into individual terms (usually words). 


///* Example -  For each sentence (bag of words), 
//we use HashingTF to hash the sentence into a feature vector. 
//We use IDF to rescale the feature vectors; this generally improves performance when using text as features. 
//Our feature vectors could then be passed to a learning algorithm

///*scala 

import org.apache.spark.ml.feature.{HashingTF, IDF, Tokenizer}
import org.apache.spark.sql.SparkSession
val sentenceData = spark.createDataFrame(Seq(
  (0.0, "Hi I heard about Spark"),
  (0.0, "I wish Java could use case classes"),
  (1.0, "Logistic regression models are neat")
)).toDF("label", "sentence")

val tokenizer = new Tokenizer().setInputCol("sentence").setOutputCol("words")
val wordsData = tokenizer.transform(sentenceData)

val hashingTF = new HashingTF()
  .setInputCol("words").setOutputCol("rawFeatures").setNumFeatures(20)

val featurizedData = hashingTF.transform(wordsData)
// alternatively, CountVectorizer can also be used to get term frequency vectors

val idf = new IDF().setInputCol("rawFeatures").setOutputCol("features")
val idfModel = idf.fit(featurizedData)

val rescaledData = idfModel.transform(featurizedData)
rescaledData.select("label", "features").show()
 

    
 

///*** Feature Extractors - Word2Vec
//Word2Vec is an Estimator which takes sequences of words representing documents 
//and trains a Word2VecModel. 
//The model maps each word to a unique fixed-size vector. 

//The Word2VecModel transforms each document into a vector using the average of all words in the document; 
//this vector can then be used as features for prediction, document similarity calculations, etc

//it takes parameters 
def  setMinCount(minCount: Int): 
def  setVectorSize(vectorSize: Int): 
def  setWindowSize(window: Int): 

///* Word2Vec - ML 
///*scala (ml/Word2VecExample.scala)
import org.apache.spark.ml.feature.Word2Vec
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.sql.Row

// Input data: Each row is a bag of words from a sentence or document.
val documentDF = spark.createDataFrame(Seq(
  "Hi I heard about Spark".split(" "),
  "I wish Java could use case classes".split(" "),
  "Logistic regression models are neat".split(" ")
).map(Tuple1.apply)).toDF("text")

// Learn a mapping from words to Vectors.
val word2Vec = new Word2Vec()
  .setInputCol("text")
  .setOutputCol("result")
  .setVectorSize(3)
  .setMinCount(0)
val model = word2Vec.fit(documentDF)

val result = model.transform(documentDF)
result.collect().foreach { case Row(text: Seq[_], features: Vector) =>
  println(s"Text: [${text.mkString(", ")}] => \nVector: $features\n") }






///*** Feature Extractors - CountVectorizer
//CountVectorizer and CountVectorizerModel aim to help convert a collection of text documents to vectors of token counts. 

//When an a-priori dictionary is not available, 
//CountVectorizer can be used as an Estimator to extract the vocabulary, 
//and generates a CountVectorizerModel. 

//The model produces sparse representations for the documents over the vocabulary, 
//which can then be passed to other algorithms like LDA

//It takes parameters: http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.ml.feature.CountVectorizer
val  binary: BooleanParam 
val  minDF: DoubleParam 
val  minTF: DoubleParam
val  vocabSize: IntParam 
//Use set/get to update/access these


///*COuntVectorizer - ML 
///*scala (ml/CountVectorizerExample.scala)

import org.apache.spark.ml.feature.{CountVectorizer, CountVectorizerModel}

val df = spark.createDataFrame(Seq(
  (0, Array("a", "b", "c")),
  (1, Array("a", "b", "b", "c", "a"))
)).toDF("id", "words")

// fit a CountVectorizerModel from the corpus
val cvModel: CountVectorizerModel = new CountVectorizer()
  .setInputCol("words")
  .setOutputCol("features")
  .setVocabSize(3)
  .setMinDF(2)
  .fit(df)

// alternatively, define CountVectorizerModel with a-priori vocabulary
val cvm = new CountVectorizerModel(Array("a", "b", "c"))
  .setInputCol("words")
  .setOutputCol("features")

cvModel.transform(df).show(false)





///*** Feature Transformers - StandardScalar 
//StandardScaler transforms a dataset of Vector rows, 
//normalizing each feature to have unit standard deviation and/or zero mean. 
//It takes parameters:
�withStd: True by default. Scales the data to unit standard deviation.
�withMean: False by default. Centers the data with mean before scaling. It will build a dense output, so take care when applying to sparse input.

//Libsvm data file  
//data is stored in a sparse array/matrix form, each line is one instance (measurment)
//for regression, label is y value, for classification, label is target multi/label 
<label> <index1>:<value1> <index2>:<value2> ...
//index1 is vector index where value1 occurs (ie feature index)
//In short, +1 1:0.7 2:1 3:1 translates to:
//Assign to class +1, the point (0.7,1,1).


///*StandardScalar - ML 
///*scala ml/StandardScalerExample.scala
import org.apache.spark.ml.feature.StandardScaler

val dataFrame = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

val scaler = new StandardScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")
  .setWithStd(true)
  .setWithMean(false)

// Compute summary statistics by fitting the StandardScaler.
val scalerModel = scaler.fit(dataFrame)

// Normalize each feature to have unit standard deviation.
val scaledData = scalerModel.transform(dataFrame)
scaledData.show()










///*** Feature Transformers - Normalizer 
//Normalizer is a Transformer which transforms a dataset of Vector rows, 
//normalizing each Vector to have unit norm. 
//It takes parameter p, which specifies the p-norm ( normed_data_p = power( Sum_of_pth_power_of_xi, 1/p) )
//used for normalization. (p=2  by default.) 
//This normalization can help standardize your input data and improve the behavior of learning algorithms.


///*Normalizer - ML 
///*scala ml/NormalizerExample.scala
import org.apache.spark.ml.feature.Normalizer
import org.apache.spark.ml.linalg.Vectors

val dataFrame = spark.createDataFrame(Seq(
  (0, Vectors.dense(1.0, 0.5, -1.0)),
  (1, Vectors.dense(2.0, 1.0, 1.0)),
  (2, Vectors.dense(4.0, 10.0, 2.0))
)).toDF("id", "features")

// Normalize each Vector using $L^1$ norm.
val normalizer = new Normalizer()
  .setInputCol("features")
  .setOutputCol("normFeatures")
  .setP(1.0)

val l1NormData = normalizer.transform(dataFrame)
println("Normalized using L^1 norm")
l1NormData.show()

// Normalize each Vector using $L^\infty$ norm.
val lInfNormData = normalizer.transform(dataFrame, normalizer.p -> Double.PositiveInfinity)
println("Normalized using L^inf norm")
lInfNormData.show()



















///*** Feature Transformers - ElementwiseProduct 
//ElementwiseProduct multiplies each input vector by a provided �weight� vector, 
//using element-wise multiplication. 
//In other words, it scales each column of the dataset by a scalar multiplier

///*ElementwiseProduct - ML 
///*scala ml/ElementwiseProductExample.scala
import org.apache.spark.ml.feature.ElementwiseProduct
import org.apache.spark.ml.linalg.Vectors

// Create some vector data; also works for sparse vectors
val dataFrame = spark.createDataFrame(Seq(
  ("a", Vectors.dense(1.0, 2.0, 3.0)),
  ("b", Vectors.dense(4.0, 5.0, 6.0)))).toDF("id", "vector")

val transformingVector = Vectors.dense(0.0, 1.0, 2.0)
val transformer = new ElementwiseProduct()
  .setScalingVec(transformingVector)
  .setInputCol("vector")
  .setOutputCol("transformedVector")

// Batch transform the vectors to create new column:
transformer.transform(dataFrame).show()




















///*** Feature Transformers - PCA 
//PCA is a statistical procedure that uses an orthogonal transformation to convert 
//a set of observations of possibly correlated variables into a set of values of linearly uncorrelated variables called principal components. 

//A PCA class trains a model to project vectors to a low-dimensional space using PCA. 

//The example below shows how to project 5-dimensional feature vectors into 3-dimensional principal components.


///*PCA - ML 
///*scala ml/PCAExample.scala
import org.apache.spark.ml.feature.PCA
import org.apache.spark.ml.linalg.Vectors

val data = Array(
  Vectors.sparse(5, Seq((1, 1.0), (3, 7.0))),
  Vectors.dense(2.0, 0.0, 3.0, 4.0, 5.0),
  Vectors.dense(4.0, 0.0, 0.0, 6.0, 7.0)
)
val df = spark.createDataFrame(data.map(Tuple1.apply)).toDF("features")

val pca = new PCA()
  .setInputCol("features")
  .setOutputCol("pcaFeatures")
  .setK(3)
  .fit(df)

val result = pca.transform(df).select("pcaFeatures")
result.show(false)











///*** Feature Selector  - ChiSqSelector 
//ChiSqSelector stands for Chi-Squared feature selection. 
//It operates on labeled data with categorical features. 
//ChiSqSelector uses the Chi-Squared test of independence to decide which features to choose. 
//It supports three selection methods: 
//�numTopFeatures chooses a fixed number of top features according to a chi-squared test. This is akin to yielding the features with the most predictive power.
//�percentile is similar to numTopFeatures but chooses a fraction of all features instead of a fixed number.
//�fpr chooses all features whose p-value is below a threshold, thus controlling the false positive rate of selection.


///*ChiSqSelector - ML 
/

///*scala ml/ChiSqSelectorExample.scala
import org.apache.spark.ml.feature.ChiSqSelector
import org.apache.spark.ml.linalg.Vectors

val data = Seq(
  (7, Vectors.dense(0.0, 0.0, 18.0, 1.0), 1.0),
  (8, Vectors.dense(0.0, 1.0, 12.0, 0.0), 0.0),
  (9, Vectors.dense(1.0, 0.0, 15.0, 0.1), 0.0)
)

val df = spark.createDataset(data).toDF("id", "features", "clicked")

val selector = new ChiSqSelector()
  .setNumTopFeatures(1)
  .setFeaturesCol("features")
  .setLabelCol("clicked")
  .setOutputCol("selectedFeatures")

val result = selector.fit(df).transform(df)

println(s"ChiSqSelector output with top ${selector.getNumTopFeatures} features selected")
result.show()
 

///*** Feature Transformation - ML    - Tokenization 

//Tokenization is the process of taking text (such as a sentence) and breaking it into individual terms (usually words). 
//RegexTokenizer allows more advanced tokenization based on regular expression (regex) matching

///*scala 
import org.apache.spark.ml.feature.{RegexTokenizer, Tokenizer}
import org.apache.spark.sql.functions._

val sentenceDataFrame = spark.createDataFrame(Seq(
  (0, "Hi I heard about Spark"),
  (1, "I wish Java could use case classes"),
  (2, "Logistic,regression,models,are,neat")
)).toDF("id", "sentence")

val tokenizer = new Tokenizer().setInputCol("sentence").setOutputCol("words")
val regexTokenizer = new RegexTokenizer()
  .setInputCol("sentence")
  .setOutputCol("words")
  .setPattern("\\W") // alternatively .setPattern("\\w+").setGaps(false)

val countTokens = udf { (words: Seq[String]) => words.length }

val tokenized = tokenizer.transform(sentenceDataFrame)
tokenized.select("sentence", "words")
    .withColumn("tokens", countTokens(col("words"))).show(false)

val regexTokenized = regexTokenizer.transform(sentenceDataFrame)
regexTokenized.select("sentence", "words")
    .withColumn("tokens", countTokens(col("words"))).show(false)




///*** Feature Transformation - ML    - StopWordsRemover
//Stop words are words which should be excluded from the input after Tokenizer 
//typically because the words appear frequently and don�t carry as much meaning.

///*scala 
import org.apache.spark.ml.feature.StopWordsRemover

val remover = new StopWordsRemover()
  .setInputCol("raw")
  .setOutputCol("filtered")

val dataSet = spark.createDataFrame(Seq(
  (0, Seq("I", "saw", "the", "red", "balloon")),
  (1, Seq("Mary", "had", "a", "little", "lamb"))
)).toDF("id", "raw")

remover.transform(dataSet).show(false)


///*** Feature Transformation - ML    -  n-gram
//NGram takes as input a sequence of strings (e.g. the output of a Tokenizer). 
//The parameter n is used to determine the number of terms in each n-gram. 
//The output will consist of a sequence of n-grams 
//where each n-gram is represented by a space-delimited string of n consecutive words. 
//If the input sequence contains fewer than n strings, no output is produced.

///*scala 
import org.apache.spark.ml.feature.NGram

val wordDataFrame = spark.createDataFrame(Seq(
  (0, Array("Hi", "I", "heard", "about", "Spark")),
  (1, Array("I", "wish", "Java", "could", "use", "case", "classes")),
  (2, Array("Logistic", "regression", "models", "are", "neat"))
)).toDF("id", "words")

val ngram = new NGram().setN(2).setInputCol("words").setOutputCol("ngrams")

val ngramDataFrame = ngram.transform(wordDataFrame)
ngramDataFrame.select("ngrams").show(false)




///*** Feature Transformation - ML    - Binarizer
//Binarization is the process of thresholding numerical features to binary (0/1) features

///*scala 
import org.apache.spark.ml.feature.Binarizer

val data = Array((0, 0.1), (1, 0.8), (2, 0.2))
val dataFrame = spark.createDataFrame(data).toDF("id", "feature")

val binarizer: Binarizer = new Binarizer()
  .setInputCol("feature")
  .setOutputCol("binarized_feature")
  .setThreshold(0.5)

val binarizedDataFrame = binarizer.transform(dataFrame)

println(s"Binarizer output with Threshold = ${binarizer.getThreshold}")
binarizedDataFrame.show()




///*** Feature Transformation - ML    -  PolynomialExpansion
//Polynomial expansion is the process of expanding your features into a polynomial space, 
//which is formulated by an n-degree combination of original dimensions. 
//The example below shows how to expand your features into a 3-degree polynomial space.

///*scala 
import org.apache.spark.ml.feature.PolynomialExpansion
import org.apache.spark.ml.linalg.Vectors

val data = Array(
  Vectors.dense(2.0, 1.0),
  Vectors.dense(0.0, 0.0),
  Vectors.dense(3.0, -1.0)
)
val df = spark.createDataFrame(data.map(Tuple1.apply)).toDF("features")

val polyExpansion = new PolynomialExpansion()
  .setInputCol("features")
  .setOutputCol("polyFeatures")
  .setDegree(3)

val polyDF = polyExpansion.transform(df)
polyDF.show(false)




///*** Feature Transformation - ML    -  Discrete Cosine Transform (DCT)?
//The Discrete Cosine Transform transforms a length N  real-valued sequence in the time domain into another length N 
//real-valued sequence in the frequency domain.

 
 ///*scala 
import org.apache.spark.ml.feature.DCT
import org.apache.spark.ml.linalg.Vectors

val data = Seq(
  Vectors.dense(0.0, 1.0, -2.0, 3.0),
  Vectors.dense(-1.0, 2.0, 4.0, -7.0),
  Vectors.dense(14.0, -2.0, -5.0, 1.0))

val df = spark.createDataFrame(data.map(Tuple1.apply)).toDF("features")

val dct = new DCT()
  .setInputCol("features")
  .setOutputCol("featuresDCT")
  .setInverse(false)

val dctDf = dct.transform(df)
dctDf.select("featuresDCT").show(false)



///*** Feature Transformation - ML    -  StringIndexer
//StringIndexer encodes a string column of labels to a column of label indices. 
//The indices are in [0, numLabels), ordered by label frequencies, 
//so the most frequent label gets index 0.

///*scala 
import org.apache.spark.ml.feature.StringIndexer

val df = spark.createDataFrame(
  Seq((0, "a"), (1, "b"), (2, "c"), (3, "a"), (4, "a"), (5, "c"))
).toDF("id", "category")

val indexer = new StringIndexer()
  .setInputCol("category")
  .setOutputCol("categoryIndex")

val indexed = indexer.fit(df).transform(df)
indexed.show()





///*** Feature Transformation - ML    -  IndexToString
//maps a column of label indices back to a column containing the original labels as strings
///*scala 
import org.apache.spark.ml.attribute.Attribute
import org.apache.spark.ml.feature.{IndexToString, StringIndexer}

val df = spark.createDataFrame(Seq(
  (0, "a"),
  (1, "b"),
  (2, "c"),
  (3, "a"),
  (4, "a"),
  (5, "c")
)).toDF("id", "category")

val indexer = new StringIndexer()
  .setInputCol("category")
  .setOutputCol("categoryIndex")
  .fit(df)
val indexed = indexer.transform(df)

println(s"Transformed string column '${indexer.getInputCol}' " +
    s"to indexed column '${indexer.getOutputCol}'")
indexed.show()

val inputColSchema = indexed.schema(indexer.getOutputCol)
println(s"StringIndexer will store labels in output column metadata: " +
    s"${Attribute.fromStructField(inputColSchema).toString}\n")

val converter = new IndexToString()
  .setInputCol("categoryIndex")
  .setOutputCol("originalCategory")

val converted = converter.transform(indexed)

println(s"Transformed indexed column '${converter.getInputCol}' back to original string " +
    s"column '${converter.getOutputCol}' using labels in metadata")
converted.select("id", "categoryIndex", "originalCategory").show()




///*** Feature Transformation - ML    -  OneHotEncoder
//maps a column of label indices to a column of binary vectors, 
//with at most a single one-value. 
//This encoding allows algorithms which expect continuous features, such as Logistic Regression, to use categorical features.
///*scala 
import org.apache.spark.ml.feature.{OneHotEncoder, StringIndexer}

val df = spark.createDataFrame(Seq(
  (0, "a"),
  (1, "b"),
  (2, "c"),
  (3, "a"),
  (4, "a"),
  (5, "c")
)).toDF("id", "category")

val indexer = new StringIndexer()
  .setInputCol("category")
  .setOutputCol("categoryIndex")
  .fit(df)
val indexed = indexer.transform(df)

val encoder = new OneHotEncoder()
  .setInputCol("categoryIndex")
  .setOutputCol("categoryVec")

val encoded = encoder.transform(indexed)
encoded.show()





///*** Feature Transformation - ML    -  VectorIndexer
//It can both automatically decide which features are categorical 
//and convert original values to category indices
1.Take an input column of type Vector and a parameter maxCategories.
2.Decide which features should be categorical based on the number of distinct values, where features with at most maxCategories are declared categorical.
3.Compute 0-based category indices for each categorical feature.
4.Index categorical features and transform original feature values to indices.
//This transformed data could then be passed to algorithms such as DecisionTreeRegressor that handle categorical features.

///*scala 
import org.apache.spark.ml.feature.VectorIndexer

val data = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

val indexer = new VectorIndexer()
  .setInputCol("features")
  .setOutputCol("indexed")
  .setMaxCategories(10)

val indexerModel = indexer.fit(data)

val categoricalFeatures: Set[Int] = indexerModel.categoryMaps.keys.toSet
println(s"Chose ${categoricalFeatures.size} categorical features: " +
  categoricalFeatures.mkString(", "))

// Create new column "indexed" with categorical values transformed to indices
val indexedData = indexerModel.transform(data)
indexedData.show()






///*** Feature Transformation - ML    -  Interaction
//Interaction is a Transformer which takes vector or double-valued columns, 
//and generates a single vector column that contains 
//the product of all combinations of one value from each input column.

//For example, if you have 2 vector type columns each of which has 3 dimensions as input columns, 
//then then you�ll get a 9-dimensional vector as the output column.



///*scala 
import org.apache.spark.ml.feature.Interaction
import org.apache.spark.ml.feature.VectorAssembler

val df = spark.createDataFrame(Seq(
  (1, 1, 2, 3, 8, 4, 5),
  (2, 4, 3, 8, 7, 9, 8),
  (3, 6, 1, 9, 2, 3, 6),
  (4, 10, 8, 6, 9, 4, 5),
  (5, 9, 2, 7, 10, 7, 3),
  (6, 1, 1, 4, 2, 8, 4)
)).toDF("id1", "id2", "id3", "id4", "id5", "id6", "id7")

val assembler1 = new VectorAssembler().
  setInputCols(Array("id2", "id3", "id4")).
  setOutputCol("vec1")

val assembled1 = assembler1.transform(df)

val assembler2 = new VectorAssembler().
  setInputCols(Array("id5", "id6", "id7")).
  setOutputCol("vec2")

val assembled2 = assembler2.transform(assembled1).select("id1", "vec1", "vec2")

val interaction = new Interaction()
  .setInputCols(Array("id1", "vec1", "vec2"))
  .setOutputCol("interactedCol")

val interacted = interaction.transform(assembled2)

interacted.show(truncate = false)







///*** Feature Transformation - ML    -  MinMaxScaler
//MinMaxScaler transforms a dataset of Vector rows, rescaling each feature to a specific range 
//It takes parameters:
�min: 0.0 by default. Lower bound after transformation, shared by all features.
�max: 1.0 by default. Upper bound after transformation, shared by all features.


///*scala 
import org.apache.spark.ml.feature.MinMaxScaler
import org.apache.spark.ml.linalg.Vectors

val dataFrame = spark.createDataFrame(Seq(
  (0, Vectors.dense(1.0, 0.1, -1.0)),
  (1, Vectors.dense(2.0, 1.1, 1.0)),
  (2, Vectors.dense(3.0, 10.1, 3.0))
)).toDF("id", "features")

val scaler = new MinMaxScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")

// Compute summary statistics and generate MinMaxScalerModel
val scalerModel = scaler.fit(dataFrame)

// rescale each feature to range [min, max].
val scaledData = scalerModel.transform(dataFrame)
println(s"Features scaled to range: [${scaler.getMin}, ${scaler.getMax}]")
scaledData.select("features", "scaledFeatures").show()



///*** Feature Transformation - ML    -  MaxAbsScaler
//MaxAbsScaler transforms a dataset of Vector rows, 
//rescaling each feature to range [-1, 1] by dividing through the maximum absolute value in each feature. It does not shift/center the data, and thus does not destroy any sparsity.

///*scala 
import org.apache.spark.ml.feature.MaxAbsScaler
import org.apache.spark.ml.linalg.Vectors

val dataFrame = spark.createDataFrame(Seq(
  (0, Vectors.dense(1.0, 0.1, -8.0)),
  (1, Vectors.dense(2.0, 1.0, -4.0)),
  (2, Vectors.dense(4.0, 10.0, 8.0))
)).toDF("id", "features")

val scaler = new MaxAbsScaler()
  .setInputCol("features")
  .setOutputCol("scaledFeatures")

// Compute summary statistics and generate MaxAbsScalerModel
val scalerModel = scaler.fit(dataFrame)

// rescale each feature to range [-1, 1]
val scaledData = scalerModel.transform(dataFrame)
scaledData.select("features", "scaledFeatures").show()



///*** Feature Transformation - ML    -  Bucketizer
//Bucketizer transforms a column of continuous features to a column of feature buckets,
//where the buckets are specified by users. It takes a parameter:
//�splits: Parameter for mapping continuous features into buckets. With n+1 splits, there are n buckets. A bucket defined by splits x,y holds values in the range [x,y) except the last bucket, which also includes 

///*scala 
import org.apache.spark.ml.feature.Bucketizer

val splits = Array(Double.NegativeInfinity, -0.5, 0.0, 0.5, Double.PositiveInfinity)

val data = Array(-999.9, -0.5, -0.3, 0.0, 0.2, 999.9)
val dataFrame = spark.createDataFrame(data.map(Tuple1.apply)).toDF("features")

val bucketizer = new Bucketizer()
  .setInputCol("features")
  .setOutputCol("bucketedFeatures")
  .setSplits(splits)

// Transform original data into its bucket index.
val bucketedData = bucketizer.transform(dataFrame)

println(s"Bucketizer output with ${bucketizer.getSplits.length-1} buckets")
bucketedData.show()




///*** Feature Transformation - ML    -  SQLTransformer
//SQLTransformer implements the transformations which are defined by SQL statement
//SQLTransformer supports statements like:
�SELECT a, a + b AS a_b FROM __THIS__
�SELECT a, SQRT(b) AS b_sqrt FROM __THIS__ where a > 5
�SELECT a, b, SUM(c) AS c_sum FROM __THIS__ GROUP BY a, b


///*scala 
import org.apache.spark.ml.feature.SQLTransformer

val df = spark.createDataFrame(
  Seq((0, 1.0, 3.0), (2, 2.0, 5.0))).toDF("id", "v1", "v2")

val sqlTrans = new SQLTransformer().setStatement(
  "SELECT *, (v1 + v2) AS v3, (v1 * v2) AS v4 FROM __THIS__")

sqlTrans.transform(df).show()



///*** Feature Transformation - ML    -  VectorAssembler
//VectorAssembler is a transformer that combines a given list of columns 
//into a single vector column. 
//It is useful for combining raw features and features generated by different feature transformers into a single feature vector, in order to train ML models like logistic regression and decision trees. VectorAssembler accepts the following input column types: all numeric types, boolean type, and vector type.


///*scala 
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.linalg.Vectors

val dataset = spark.createDataFrame(
  Seq((0, 18, 1.0, Vectors.dense(0.0, 10.0, 0.5), 1.0))
).toDF("id", "hour", "mobile", "userFeatures", "clicked")

val assembler = new VectorAssembler()
  .setInputCols(Array("hour", "mobile", "userFeatures"))
  .setOutputCol("features")

val output = assembler.transform(dataset)
println("Assembled columns 'hour', 'mobile', 'userFeatures' to vector column 'features'")
output.select("features", "clicked").show(false)



///*** Feature Transformation - ML    -  QuantileDiscretizer
//QuantileDiscretizer takes a column with continuous features 
//and outputs a column with binned categorical features.
// The number of bins is set by the numBuckets parameter
//The bin ranges are chosen using an approximate algorithm 
//The precision of the approximation can be controlled with the relativeError parameter. 
//When set to zero, exact quantiles are calculated
///*scala 
import org.apache.spark.ml.feature.QuantileDiscretizer

val data = Array((0, 18.0), (1, 19.0), (2, 8.0), (3, 5.0), (4, 2.2))
val df = spark.createDataFrame(data).toDF("id", "hour")

val discretizer = new QuantileDiscretizer()
  .setInputCol("hour")
  .setOutputCol("result")
  .setNumBuckets(3)

val result = discretizer.fit(df).transform(df)
result.show()






///*** Feature Selections - ML -  VectorSlicer
//VectorSlicer is a transformer that takes a feature vector 
//and outputs a new feature vector with a sub-array of the original features. 
//It is useful for extracting features from a vector column.

//VectorSlicer accepts a vector column with specified indices, 
//then outputs a new vector column whose values are selected via those indices. 
//There are two types of indices,
//1.Integer indices that represent the indices into the vector, setIndices().
//2.String indices that represent the names of features into the vector, setNames().


///*scala 
import java.util.Arrays

import org.apache.spark.ml.attribute.{Attribute, AttributeGroup, NumericAttribute}
import org.apache.spark.ml.feature.VectorSlicer
import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructType

val data = Arrays.asList(
  Row(Vectors.sparse(3, Seq((0, -2.0), (1, 2.3)))),
  Row(Vectors.dense(-2.0, 2.3, 0.0))
)

val defaultAttr = NumericAttribute.defaultAttr
val attrs = Array("f1", "f2", "f3").map(defaultAttr.withName)
val attrGroup = new AttributeGroup("userFeatures", attrs.asInstanceOf[Array[Attribute]])

val dataset = spark.createDataFrame(data, StructType(Array(attrGroup.toStructField())))

val slicer = new VectorSlicer().setInputCol("userFeatures").setOutputCol("features")

slicer.setIndices(Array(1)).setNames(Array("f3"))
// or slicer.setIndices(Array(1, 2)), or slicer.setNames(Array("f2", "f3"))

val output = slicer.transform(dataset)
output.show(false)



///*** Feature Selections - ML -  RFormula
//RFormula selects columns specified by an R model formula. 
//Currently supports �~�, �.�, �:�, �+�, and �-�. 
//The basic operators are:
�~ separate target and terms
�+ concat terms, �+ 0� means removing intercept
�- remove a term, �- 1� means removing intercept
�: interaction (multiplication for numeric values, or binarized categorical values)
�. all columns except target

//Suppose a and b are double columns, we use the following simple examples to illustrate the effect of RFormula:
�y ~ a + b means model y ~ w0 + w1 * a + w2 * b where w0 is the intercept and w1, w2 are coefficients.
�y ~ a + b + a:b - 1 means model y ~ w1 * a + w2 * b + w3 * a * b where w1, w2, w3 are coefficients.

///*scala 
import org.apache.spark.ml.feature.RFormula

import org.apache.spark.sql.SparkSession

object RFormulaExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("RFormulaExample")
      .getOrCreate()

    // $example on$
    val dataset = spark.createDataFrame(Seq(
      (7, "US", 18, 1.0),
      (8, "CA", 12, 0.0),
      (9, "NZ", 15, 0.0)
    )).toDF("id", "country", "hour", "clicked")

    val formula = new RFormula()
      .setFormula("clicked ~ country + hour")
      .setFeaturesCol("features")
      .setLabelCol("label")

    val output = formula.fit(dataset).transform(dataset)
    output.select("features", "label").show()
    // $example off$

    spark.stop()
  }
}

 



///*** Locality Sensitive Hashing -ML 
//Locality Sensitive Hashing (LSH) is an important class of hashing techniques, 
//which is commonly used in clustering, approximate nearest neighbor search 
//and outlier detection with large datasets.

//The general idea of LSH is to use a family of functions (�LSH families�) 
//to hash data points into buckets, so that the data points 
//which are close to each other are in the same buckets with high probability

///* LSH Operations
//major types of operations which LSH can be used for. 
//A fitted LSH model has methods for each of these operations.
///* Feature Transformation
//Feature transformation is the basic functionality to add hashed values 
//as a new column. This can be useful for dimensionality reduction

///* Approximate Similarity Join
//Approximate similarity join takes two datasets 
//and approximately returns pairs of rows in the datasets whose distance is smaller than a user-defined threshold

///* Approximate Nearest Neighbor Search?
//Approximate nearest neighbor search takes a dataset (of feature vectors) and a key (a single feature vector), 
//and it approximately returns a specified number of rows in the dataset that are closest to the vector.


///*Example - LSH alogorithms 
//Bucketed Random Projection accepts arbitrary vectors as input features, and supports both sparse and dense vectors.
///*Scala

import org.apache.spark.ml.feature.BucketedRandomProjectionLSH
import org.apache.spark.ml.linalg.Vectors

val dfA = spark.createDataFrame(Seq(
  (0, Vectors.dense(1.0, 1.0)),
  (1, Vectors.dense(1.0, -1.0)),
  (2, Vectors.dense(-1.0, -1.0)),
  (3, Vectors.dense(-1.0, 1.0))
)).toDF("id", "keys")

val dfB = spark.createDataFrame(Seq(
  (4, Vectors.dense(1.0, 0.0)),
  (5, Vectors.dense(-1.0, 0.0)),
  (6, Vectors.dense(0.0, 1.0)),
  (7, Vectors.dense(0.0, -1.0))
)).toDF("id", "keys")

val key = Vectors.dense(1.0, 0.0)

val brp = new BucketedRandomProjectionLSH()
  .setBucketLength(2.0)
  .setNumHashTables(3)
  .setInputCol("keys")
  .setOutputCol("values")

val model = brp.fit(dfA)

// Feature Transformation
model.transform(dfA).show()
// Cache the transformed columns
val transformedA = model.transform(dfA).cache()
val transformedB = model.transform(dfB).cache()

// Approximate similarity join
model.approxSimilarityJoin(dfA, dfB, 1.5).show()
model.approxSimilarityJoin(transformedA, transformedB, 1.5).show()
// Self Join
model.approxSimilarityJoin(dfA, dfA, 2.5).filter("datasetA.id < datasetB.id").show()

// Approximate nearest neighbor search
model.approxNearestNeighbors(dfA, key, 2).show()
model.approxNearestNeighbors(transformedA, key, 2).show()

///* Exampl - LSH algorithms - MinHash for Jaccard Distance
//MinHash is an LSH family for Jaccard distance where input features are sets of natural numbers

///*scala 
import org.apache.spark.ml.feature.MinHashLSH
import org.apache.spark.ml.linalg.Vectors

val dfA = spark.createDataFrame(Seq(
  (0, Vectors.sparse(6, Seq((0, 1.0), (1, 1.0), (2, 1.0)))),
  (1, Vectors.sparse(6, Seq((2, 1.0), (3, 1.0), (4, 1.0)))),
  (2, Vectors.sparse(6, Seq((0, 1.0), (2, 1.0), (4, 1.0))))
)).toDF("id", "keys")

val dfB = spark.createDataFrame(Seq(
  (3, Vectors.sparse(6, Seq((1, 1.0), (3, 1.0), (5, 1.0)))),
  (4, Vectors.sparse(6, Seq((2, 1.0), (3, 1.0), (5, 1.0)))),
  (5, Vectors.sparse(6, Seq((1, 1.0), (2, 1.0), (4, 1.0))))
)).toDF("id", "keys")

val key = Vectors.sparse(6, Seq((1, 1.0), (3, 1.0)))

val mh = new MinHashLSH()
  .setNumHashTables(3)
  .setInputCol("keys")
  .setOutputCol("values")

val model = mh.fit(dfA)

// Feature Transformation
model.transform(dfA).show()
// Cache the transformed columns
val transformedA = model.transform(dfA).cache()
val transformedB = model.transform(dfB).cache()

// Approximate similarity join
model.approxSimilarityJoin(dfA, dfB, 0.6).show()
model.approxSimilarityJoin(transformedA, transformedB, 0.6).show()
// Self Join
model.approxSimilarityJoin(dfA, dfA, 0.6).filter("datasetA.id < datasetB.id").show()

// Approximate nearest neighbor search
model.approxNearestNeighbors(dfA, key, 2).show()
model.approxNearestNeighbors(transformedA, key, 2).show()









///******  Evaluator and Metrics  ******/

///* ML - MulticlassClassificationEvaluator or BinaryClassificationEvaluator or RegressionEvaluator 
    MulticlassClassificationEvaluator supports metricName as "f1" (default), "weightedPrecision", "weightedRecall", "accuracy")
    BinaryClassificationEvaluator (supports "areaUnderROC" (default), "areaUnderPR")
    RegressionEvaluator supports "rmse" (default): root mean squared error,"mse": mean squared error,"r2": R2 metric,"mae": mean absolute error 



//confusion matrix used in finding accuracy in classification 
// T/F= True/False, P/N=Positive/Negative
//in best case , FP and FN  -> 0 
    True Positive (TP) - label is positive and prediction is also positive
    True Negative (TN) - label is negative and prediction is also negative
    False Positive (FP) - label is negative but prediction is positive
    False Negative (FN) - label is positive but prediction is negative

                actual +  actual - 
predicted +     TP          FP
predicted -     FN          TN

Recall = (TP)/(TP+FN)  -> 1(best)
Precision = TP/(TP+FP)  -> 1(best)


///* for binary class evaluation of classification 
areaUnderROC  -> 1 is the best 

///* A multiclass classification describes a classification problem 
//where there are M>2 possible labels for each data point 
//(the case where M=2 is the binary classification problem).

//For example, classifying handwriting samples to the digits 0 to 9, 
//having 10 possible classes. 
accuracy, f1 -> 1 is  the best 

Accuracy measures precision across all labels 
    - the number of times any class was predicted correctly (true positives) normalized by the number of data points. 
Precision by label considers only one class, 
    and measures the number of time a specific label was predicted correctly normalized by the number of times that label appears in the output.

///* A multilabel classification problem involves mapping each sample in a dataset to a set of class labels. 
//In this type of classification problem, the labels are not mutually exclusive. 

//For example, when classifying a set of news articles into topics, 
//a single article might be both science and politics.

//regression evaluation metrics 
r2  -> 1 is the best 
mean squared error -> 0 is the best 
pValues  -> 0 (<0.05) means coeffcients are significants 
aic   -> small  is the better model 

///* Input Columns - ML 
Param name  Type(s)     Default     Description
labelCol    Double      "label"     Label to predict 
featuresCol Vector      "features"  Feature vector 

///* Output Columns- ML 
Param name          Type(s)     Default         Description
predictionCol       Double      "prediction"    Predicted label  
rawPredictionCol    Vector      "rawPrediction" Vector of length # classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"   Vector of length # classes equal to rawPrediction normalized to a multinomial distribution Classification only 
varianceCol         Double                      The biased sample variance of prediction Regression only 



///*scala 
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
// train the model
val splits = data.randomSplit(Array(0.6, 0.4), seed = 1234L)
val train = splits(0)
val test = splits(1)
//create trainer  model 
val model = trainer.fit(train)
// compute accuracy on the test set
val result = model.transform(test)
val predictionAndLabels = result.select("prediction", "label")
val evaluator = new MulticlassClassificationEvaluator()
  .setMetricName("accuracy")

println("Test set accuracy = " + evaluator.evaluate(predictionAndLabels))








///******  ML Pipeline ******/
@@@ml-pipeline
http://spark.apache.org/docs/latest/ml-pipeline.html
///*** ML pipeline 
// ML Pipelines provide a uniform set of high-level APIs built on top of DataFrame for ML 
DataFrame: This ML API uses DataFrame from Spark SQL as an ML dataset, which can hold a variety of data types. 
           E.g., a DataFrame could have different columns storing text, feature vectors, true labels, and predictions.
Transformer: A Transformer is an algorithm which can transform one DataFrame into another DataFrame. 
            E.g., an ML model is a Transformer which transforms a DataFrame with features into a DataFrame with predictions.
Estimator: An Estimator is an algorithm which can be fit on a DataFrame to produce a Transformer. 
          E.g., a learning algorithm is an Estimator which trains on a DataFrame and produces a model.
Pipeline: A Pipeline chains multiple Transformers and Estimators together to specify an ML workflow.
Parameter: All Transformers and Estimators now share a common API for specifying parameters.


///* Input Columns - ML 
//Param name  Type(s)     Default     Description
labelCol    Double      "label"     Label to predict 
featuresCol Vector      "features"  Feature vector 

///* Output Columns- ML 
//Param name          Type(s)     Default         Description
predictionCol       Double      "prediction"    Predicted label  
rawPredictionCol    Vector      "rawPrediction" Vector of length # classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"   Vector of length # classes equal to rawPrediction normalized to a multinomial distribution Classification only 
                                                gives the probability of each class as a vector.
varianceCol         Double                      The biased sample variance of prediction Regression only 




///* Estimator, Transformer, and Param

//Example - Estimator - LogisticRegression()
//Transformer(called model) after .fit on 'labelCol' and 'featuresCol' of training data => estimator.fit(training)
//Tramsformed , after .transform on test DF => model.transform(test)
// outputs predictionCol, probabilityCol etc 

///Params 

// Print out the parameters, documentation, and any default values.
estimator.explainParams() 

//Set Params of the Estimator, 
//via setXYZ()(scala) , estimator.fit()
//or via ParamMap (scala-Map, py-Dict) and then use estimator.fit(training, paramMap)

//To display current paramMap 
model.parent.extractParamMap or lr.extractParamMap()






///*scala 
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.linalg.{Vector, Vectors}
import org.apache.spark.ml.param.ParamMap
import org.apache.spark.sql.Row

import org.apache.spark.sql.SparkSession

object EstimatorTransformerParamExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("EstimatorTransformerParamExample")
      .getOrCreate()

    // $example on$
    // Prepare training data from a list of (label, features) tuples.
    val training = spark.createDataFrame(Seq(
      (1.0, Vectors.dense(0.0, 1.1, 0.1)),
      (0.0, Vectors.dense(2.0, 1.0, -1.0)),
      (0.0, Vectors.dense(2.0, 1.3, 1.0)),
      (1.0, Vectors.dense(0.0, 1.2, -0.5))
    )).toDF("label", "features")

    // Create a LogisticRegression instance. This instance is an Estimator.
    val lr = new LogisticRegression()
    // Print out the parameters, documentation, and any default values.
    println("LogisticRegression parameters:\n" + lr.explainParams() + "\n")

    // We may set parameters using setter methods.
    lr.setMaxIter(10)
      .setRegParam(0.01)

    // Learn a LogisticRegression model. This uses the parameters stored in lr.
    val model1 = lr.fit(training)
    // Since model1 is a Model (i.e., a Transformer produced by an Estimator),
    // we can view the parameters it used during fit().
    // This prints the parameter (name: value) pairs, where names are unique IDs for this
    // LogisticRegression instance.
    println("Model 1 was fit using parameters: " + model1.parent.extractParamMap)

    // We may alternatively specify parameters using a ParamMap,
    // which supports several methods for specifying parameters.
    val paramMap = ParamMap(lr.maxIter -> 20)
      .put(lr.maxIter, 30)  // Specify 1 Param. This overwrites the original maxIter.
      .put(lr.regParam -> 0.1, lr.threshold -> 0.55)  // Specify multiple Params.

    // One can also combine ParamMaps.
    val paramMap2 = ParamMap(lr.probabilityCol -> "myProbability")  // Change output column name.
    val paramMapCombined = paramMap ++ paramMap2

    // Now learn a new model using the paramMapCombined parameters.
    // paramMapCombined overrides all parameters set earlier via lr.set* methods.
    val model2 = lr.fit(training, paramMapCombined)
    println("Model 2 was fit using parameters: " + model2.parent.extractParamMap)

    // Prepare test data.
    val test = spark.createDataFrame(Seq(
      (1.0, Vectors.dense(-1.0, 1.5, 1.3)),
      (0.0, Vectors.dense(3.0, 2.0, -0.1)),
      (1.0, Vectors.dense(0.0, 2.2, -1.5))
    )).toDF("label", "features")

    // Make predictions on test data using the Transformer.transform() method.
    // LogisticRegression.transform will only use the 'features' column.
    // Note that model2.transform() outputs a 'myProbability' column instead of the usual
    // 'probability' column since we renamed the lr.probabilityCol parameter previously.
    model2.transform(test)
      .select("features", "label", "myProbability", "prediction")
      .collect()
      .foreach { case Row(features: Vector, label: Double, prob: Vector, prediction: Double) =>
        println(s"($features, $label) -> prob=$prob, prediction=$prediction")
      }
    // $example off$

    spark.stop()
  }
}



///* Pipeline 
//Create all Estimators (ie feature, regeression,... which have .fit) 
//Create Pipleline via .setStages(array_of_estimators) (scala) or ctor arg, stages=[estimators])
//Create pipline model, model = pipeline.fit(training)
//Create prediction, df = model.transform(test)


///*scala 
// $example on$
import org.apache.spark.ml.{Pipeline, PipelineModel}
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.feature.{HashingTF, Tokenizer}
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.sql.Row
// $example off$
import org.apache.spark.sql.SparkSession

object PipelineExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("PipelineExample")
      .getOrCreate()

    // $example on$
    // Prepare training documents from a list of (id, text, label) tuples.
    val training = spark.createDataFrame(Seq(
      (0L, "a b c d e spark", 1.0),
      (1L, "b d", 0.0),
      (2L, "spark f g h", 1.0),
      (3L, "hadoop mapreduce", 0.0)
    )).toDF("id", "text", "label")

    // Configure an ML pipeline, which consists of three stages: tokenizer, hashingTF, and lr.
    val tokenizer = new Tokenizer()
      .setInputCol("text")
      .setOutputCol("words")
    val hashingTF = new HashingTF()
      .setNumFeatures(1000)
      .setInputCol(tokenizer.getOutputCol)
      .setOutputCol("features")
    val lr = new LogisticRegression()
      .setMaxIter(10)
      .setRegParam(0.001)
    val pipeline = new Pipeline()
      .setStages(Array(tokenizer, hashingTF, lr))

    // Fit the pipeline to training documents.
    val model = pipeline.fit(training)

    // Now we can optionally save the fitted pipeline to disk
    model.write.overwrite().save("/tmp/spark-logistic-regression-model")

    // We can also save this unfit pipeline to disk
    pipeline.write.overwrite().save("/tmp/unfit-lr-model")

    // And load it back in during production
    val sameModel = PipelineModel.load("/tmp/spark-logistic-regression-model")

    // Prepare test documents, which are unlabeled (id, text) tuples.
    val test = spark.createDataFrame(Seq(
      (4L, "spark i j k"),
      (5L, "l m n"),
      (6L, "spark hadoop spark"),
      (7L, "apache hadoop")
    )).toDF("id", "text")

    // Make predictions on test documents.
    model.transform(test)
      .select("id", "text", "probability", "prediction")
      .collect()
      .foreach { case Row(id: Long, text: String, prob: Vector, prediction: Double) =>
        println(s"($id, $text) --> prob=$prob, prediction=$prediction")
      }
    // $example off$

    spark.stop()
  }
}



///****** ML: Tuning ******/

@@@ml-tuning
https://spark.apache.org/docs/2.1.0/ml-tuning.html
///*** Model Selection 
//An important task in ML is model selection, or using data to find the best model or parameters for a given task. 
//This is also called tuning. 
//Tuning may be done for individual Estimators such as LogisticRegression or Users can tune an entire Pipeline at once


//Supports CrossValidator and TrainValidationSplit. 
//These tools require the following items:
�Estimator: An estimator or a Pipeline to tune

�Set of ParamMaps: parameters to choose from using ParamGridBuilder 
                   Use estimator.PARAMETER_VAR and Array of values to choose from
                    paramGrid = ParamGridBuilder()
                      .addGrid(hashingTF.numFeatures, Array(10, 100, 1000))
                      .addGrid(lr.regParam, Array(0.1, 0.01))
                      .build()
                      
�Evaluator: metric to measure how well a fitted Model does on held-out test data
            RegressionEvaluator for regression problems, 
            BinaryClassificationEvaluator for binary data, 
            MulticlassClassificationEvaluator for multiclass problems. 
            The default metric used to choose the best ParamMap can be overridden by the setMetricName method in each of these evaluators.

�Get Best model via CrossValidator/TrainValidationSplit.setEstimator(pipeline)
                              .setEvaluator(evaluator_instance)
                              .setEstimatorParamMaps(paramGrid)
                              .setANY_OTHER_TUNING_PARAMETER

//Algorithm of the tool 
�They split the input data into separate training and test datasets.
�For each (training, test) pair, they iterate through the set of ParamMaps: 
   For each ParamMap, they fit the Estimator using those parameters, 
   get the fitted Model, and evaluate the Model�s performance using the Evaluator.
�They select the Model produced by the best-performing set of parameters.

///* CrossValidator
//with k=3 folds, CrossValidator will generate 3 (training, test) dataset pairs, 
//each of which uses 2/3 of the data for training and 1/3 for testing. 

///*scala 
//Note that cross-validation over a grid of parameters is expensive. 
//E.g., in the example below, the parameter grid has 3 values for hashingTF.numFeatures 
//and 2 values for lr.regParam, and CrossValidator uses 2 folds. 
//This multiplies out to (3�2)�2=12 different models being trained
 
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.feature.{HashingTF, Tokenizer}
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.ml.tuning.{CrossValidator, ParamGridBuilder}
import org.apache.spark.sql.Row

// Prepare training data from a list of (id, text, label) tuples.
val training = spark.createDataFrame(Seq(
  (0L, "a b c d e spark", 1.0),
  (1L, "b d", 0.0),
  (2L, "spark f g h", 1.0),
  (3L, "hadoop mapreduce", 0.0),
  (4L, "b spark who", 1.0),
  (5L, "g d a y", 0.0),
  (6L, "spark fly", 1.0),
  (7L, "was mapreduce", 0.0),
  (8L, "e spark program", 1.0),
  (9L, "a e c l", 0.0),
  (10L, "spark compile", 1.0),
  (11L, "hadoop software", 0.0)
)).toDF("id", "text", "label")

// Configure an ML pipeline, which consists of three stages: tokenizer, hashingTF, and lr.
val tokenizer = new Tokenizer()
  .setInputCol("text")
  .setOutputCol("words")
val hashingTF = new HashingTF()
  .setInputCol(tokenizer.getOutputCol)
  .setOutputCol("features")
val lr = new LogisticRegression()
  .setMaxIter(10)
val pipeline = new Pipeline()
  .setStages(Array(tokenizer, hashingTF, lr))

// We use a ParamGridBuilder to construct a grid of parameters to search over.
// With 3 values for hashingTF.numFeatures and 2 values for lr.regParam,
// this grid will have 3 x 2 = 6 parameter settings for CrossValidator to choose from.
val paramGrid = new ParamGridBuilder()
  .addGrid(hashingTF.numFeatures, Array(10, 100, 1000))
  .addGrid(lr.regParam, Array(0.1, 0.01))
  .build()

// We now treat the Pipeline as an Estimator, wrapping it in a CrossValidator instance.
// This will allow us to jointly choose parameters for all Pipeline stages.
// A CrossValidator requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
// Note that the evaluator here is a BinaryClassificationEvaluator and its default metric
// is areaUnderROC.
val cv = new CrossValidator()
  .setEstimator(pipeline)
  .setEvaluator(new BinaryClassificationEvaluator)
  .setEstimatorParamMaps(paramGrid)
  .setNumFolds(2)  // Use 3+ in practice

// Run cross-validation, and choose the best set of parameters.
val cvModel = cv.fit(training)

// Prepare test documents, which are unlabeled (id, text) tuples.
val test = spark.createDataFrame(Seq(
  (4L, "spark i j k"),
  (5L, "l m n"),
  (6L, "mapreduce spark"),
  (7L, "apache hadoop")
)).toDF("id", "text")

// Make predictions on test documents. cvModel uses the best model found (lrModel).
cvModel.transform(test)
  .select("id", "text", "probability", "prediction")
  .collect()
  .foreach { case Row(id: Long, text: String, prob: Vector, prediction: Double) =>
    println(s"($id, $text) --> prob=$prob, prediction=$prediction")
  }


    
    
///* Train-Validation Split
//TrainValidationSplit only evaluates each combination of parameters once, as opposed to k times in the case of CrossValidator. 
//It is therefore less expensive, but will not produce as reliable results when the training dataset is not sufficiently large.

//with trainRatio=0.75 
//TrainValidationSplit will generate a training and test dataset pair where 75% of the data is used for training and 25% for validation

///*scala 
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit}

// Prepare training and test data.
val data = spark.read.format("libsvm").load("data/mllib/sample_linear_regression_data.txt")
val Array(training, test) = data.randomSplit(Array(0.9, 0.1), seed = 12345)

val lr = new LinearRegression()
    .setMaxIter(10)

// We use a ParamGridBuilder to construct a grid of parameters to search over.
// TrainValidationSplit will try all combinations of values and determine best model using
// the evaluator.
val paramGrid = new ParamGridBuilder()
  .addGrid(lr.regParam, Array(0.1, 0.01))
  .addGrid(lr.fitIntercept)
  .addGrid(lr.elasticNetParam, Array(0.0, 0.5, 1.0))
  .build()

// In this case the estimator is simply the linear regression.
// A TrainValidationSplit requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
val trainValidationSplit = new TrainValidationSplit()
  .setEstimator(lr)
  .setEvaluator(new RegressionEvaluator)
  .setEstimatorParamMaps(paramGrid)
  // 80% of the data will be used for training and the remaining 20% for validation.
  .setTrainRatio(0.8)

// Run train validation split, and choose the best set of parameters.
val model = trainValidationSplit.fit(training)

// Make predictions on test data. model is the model with combination of parameters
// that performed best.
model.transform(test)
  .select("features", "label", "prediction")
  .show()




/******  ML: Classifications - Logistic regression ******/
///*** Classification and Regression 
//Problem Type                Supported Methods
Binary Classification       linear SVMs, logistic regression, decision trees, random forests, gradient-boosted trees, naive Bayes 
Multiclass Classification   logistic regression, decision trees, random forests, naive Bayes 
Regression                  linear least squares, Lasso, ridge regression, decision trees, random forests, gradient-boosted trees, isotonic regression 



///*** Classification -  logistic regression (binary and multiclass classification )

//Many standard machine learning methods can be formulated as a convex optimization problem, 
//i.e. the task of finding a minimizer of a convex function f 
//that depends on a variable vector w  (called weights in the code), which has d  entries. 
 
//Classification aims to divide items into categories. 
//The most common classification type is binary classification, 
//where there are two categories, usually named positive and negative. 
//If there are more than two categories, it is called multiclass classification(multinomial logistic regression)

//a binary label y is denoted as either +1  (positive) or -1  (negative), 
//which is convenient for the formulation. 
//However, the negative label is represented by 0  in spark instead of -1 , to be consistent with multiclass labeling.


//The purpose of the regularizer is to encourage simple models and avoid overfitting
//SUpoorted regularizer is L1, L2 and ElasticNet 
//L2-regularized problems are generally easier to solve than L1-regularized due to smoothness. 
//However, L1 regularization can help promote sparsity in weights leading to smaller and more interpretable models, the latter of which can be useful for feature selection. 
//Elastic net is a combination of L1 and L2 regularization. 
//It is not recommended to train models without any regularization, especially when the number of training examples is small.


///* logistic regression - ml
//few othr imp mthods 
def  explainParams(): String 
Explains all params of this instance. 

def  evaluate(dataset: Dataset[_]): LogisticRegressionSummary 
Evaluates the model on a test dataset. 

def  transform(dataset: Dataset[_]): DataFrame 
Transforms dataset by reading from featuresCol, and appending new columns as specified by parameters:
predicted labels as predictionCol of type Double
raw predictions (confidences) as rawPredictionCol of type Vector
probability of each class as probabilityCol of type Vector
 

final  val  predictionCol: Param[String] 
Param for prediction column name.
 
final  val probabilityCol: Param[String] 
Param for Column name for predicted class conditional probabilities.
 
final  val  rawPredictionCol: Param[String] 
Param for raw prediction (a.k.a. confidence) column name.



///*scala 
//binary classification  
// $example on$
import org.apache.spark.ml.classification.LogisticRegression
// $example off$
import org.apache.spark.sql.SparkSession

object LogisticRegressionWithElasticNetExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("LogisticRegressionWithElasticNetExample")
      .getOrCreate()

    // $example on$
    // Load training data
    val training = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    val lr = new LogisticRegression()
      .setMaxIter(10)
      .setRegParam(0.3)
      .setElasticNetParam(0.8)

    // Fit the model
    val lrModel = lr.fit(training)

    // Print the coefficients and intercept for logistic regression
    println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")

    // We can also use the multinomial family for binary classification
    val mlr = new LogisticRegression()
      .setMaxIter(10)
      .setRegParam(0.3)
      .setElasticNetParam(0.8)
      .setFamily("multinomial")

    val mlrModel = mlr.fit(training)
    
    

    // Print the coefficients and intercepts for logistic regression with multinomial family
    println(s"Multinomial coefficients: ${mlrModel.coefficientMatrix}")
    println(s"Multinomial intercepts: ${mlrModel.interceptVector}")
    // $example off$

    spark.stop()
  }
}

//Summary- only binary classification is supported and the summary must be explicitly cast to BinaryLogisticRegressionTrainingSummary.
// $example on$
import org.apache.spark.ml.classification.{BinaryLogisticRegressionSummary, LogisticRegression}
// $example off$
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.max

object LogisticRegressionSummaryExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("LogisticRegressionSummaryExample")
      .getOrCreate()
    import spark.implicits._

    // Load training data
    val training = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    val lr = new LogisticRegression()
      .setMaxIter(10)
      .setRegParam(0.3)
      .setElasticNetParam(0.8)

    // Fit the model
    val lrModel = lr.fit(training)

    // $example on$
    // Extract the summary from the returned LogisticRegressionModel instance trained in the earlier
    // example
    val trainingSummary = lrModel.summary

    // Obtain the objective per iteration.
    val objectiveHistory = trainingSummary.objectiveHistory
    println("objectiveHistory:")
    objectiveHistory.foreach(loss => println(loss))

    // Obtain the metrics useful to judge performance on test data.
    // We cast the summary to a BinaryLogisticRegressionSummary since the problem is a
    // binary classification problem.
    val binarySummary = trainingSummary.asInstanceOf[BinaryLogisticRegressionSummary]

    // Obtain the receiver-operating characteristic as a dataframe and areaUnderROC.
    val roc = binarySummary.roc
    roc.show()
    println(s"areaUnderROC: ${binarySummary.areaUnderROC}")

    // Set the model threshold to maximize F-Measure
    val fMeasure = binarySummary.fMeasureByThreshold
    val maxFMeasure = fMeasure.select(max("F-Measure")).head().getDouble(0)
    val bestThreshold = fMeasure.where($"F-Measure" === maxFMeasure)
      .select("threshold").head().getDouble(0)
    lrModel.setThreshold(bestThreshold)
    // $example off$

    spark.stop()
  }
}

//multiclass 
// $example on$
import org.apache.spark.ml.classification.LogisticRegression
// $example off$
import org.apache.spark.sql.SparkSession

object MulticlassLogisticRegressionWithElasticNetExample {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("MulticlassLogisticRegressionWithElasticNetExample")
      .getOrCreate()

    // $example on$
    // Load training data
    val training = spark
      .read
      .format("libsvm")
      .load("data/mllib/sample_multiclass_classification_data.txt")

    val lr = new LogisticRegression()
      .setMaxIter(10)
      .setRegParam(0.3)
      .setElasticNetParam(0.8)

    // Fit the model
    val lrModel = lr.fit(training)

    // Print the coefficients and intercept for multinomial logistic regression
    println(s"Coefficients: \n${lrModel.coefficientMatrix}")
    println(s"Intercepts: ${lrModel.interceptVector}")
    // $example off$

    spark.stop()
  }
}






/******  ML: Classifications - Random Forest and Gradient Boost ******/

///*** Classification & Regression - Decision trees and Tree Ensembles - ML and MLIB 

//Decision trees are widely used since they are easy to interpret, handle categorical features, extend to the multiclass classification setting, do not require feature scaling, and are able to capture non-linearities and feature interactions. 

//Tree ensemble algorithms such as random forests and boosting are among the top performers for classification and regression tasks.

//The spark.ml implementation supports decision trees for binary and multiclass classification 
//and for regression, using both continuous and categorical features



///* Input Columns - ML 
Param name  Type(s)     Default     Description
labelCol    Double      "label"     Label to predict 
featuresCol Vector      "features"  Feature vector 

///* Output Columns- ML 
Param name          Type(s)     Default         Description
predictionCol       Double      "prediction"    Predicted label  
rawPredictionCol    Vector      "rawPrediction" Vector of length # classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"   Vector of length # classes equal to rawPrediction normalized to a multinomial distribution Classification only 
varianceCol         Double                      The biased sample variance of prediction Regression only 


///* ML  - Ensemble Decision trees - Random Forests
//Random forests combine many decision trees in order to reduce the risk of overfitting. 
//The spark.ml implementation supports random forests for binary and multiclass classification and for regression, using both continuous and categorical features.

///*scala - classifier 
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.{RandomForestClassificationModel, RandomForestClassifier}
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorIndexer}
// $example off$
import org.apache.spark.sql.SparkSession

object RandomForestClassifierExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("RandomForestClassifierExample")
      .getOrCreate()

    // $example on$
    // Load and parse the data file, converting it to a DataFrame.
    val data = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    // Index labels, adding metadata to the label column.
    // Fit on whole dataset to include all labels in index.
    val labelIndexer = new StringIndexer()
      .setInputCol("label")
      .setOutputCol("indexedLabel")
      .fit(data)
    // Automatically identify categorical features, and index them.
    // Set maxCategories so features with > 4 distinct values are treated as continuous.
    val featureIndexer = new VectorIndexer()
      .setInputCol("features")
      .setOutputCol("indexedFeatures")
      .setMaxCategories(4)
      .fit(data)

    // Split the data into training and test sets (30% held out for testing).
    val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3))

    // Train a RandomForest model.
    val rf = new RandomForestClassifier()
      .setLabelCol("indexedLabel")
      .setFeaturesCol("indexedFeatures")
      .setNumTrees(10)

    // Convert indexed labels back to original labels.
    val labelConverter = new IndexToString()
      .setInputCol("prediction")
      .setOutputCol("predictedLabel")
      .setLabels(labelIndexer.labels)

    // Chain indexers and forest in a Pipeline.
    val pipeline = new Pipeline()
      .setStages(Array(labelIndexer, featureIndexer, rf, labelConverter))

    // Train model. This also runs the indexers.
    val model = pipeline.fit(trainingData)

    // Make predictions.
    val predictions = model.transform(testData)

    // Select example rows to display.
    predictions.select("predictedLabel", "label", "features").show(5)

    // Select (prediction, true label) and compute test error.
    val evaluator = new MulticlassClassificationEvaluator()
      .setLabelCol("indexedLabel")
      .setPredictionCol("prediction")
      .setMetricName("accuracy")
    val accuracy = evaluator.evaluate(predictions)
    println("Test Error = " + (1.0 - accuracy))

    val rfModel = model.stages(2).asInstanceOf[RandomForestClassificationModel]
    println("Learned classification forest model:\n" + rfModel.toDebugString)
    // $example off$

    spark.stop()
  }
}


///* ML  - Ensemble Decision trees - Gradient-Boosted Trees
//GBTs iteratively train decision trees in order to minimize a loss function. 
//The spark.ml implementation supports GBTs for binary classification and for regression, using both continuous and categorical features.

///*scala - classifier 
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.{GBTClassificationModel, GBTClassifier}
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorIndexer}
// $example off$
import org.apache.spark.sql.SparkSession

object GradientBoostedTreeClassifierExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("GradientBoostedTreeClassifierExample")
      .getOrCreate()

    // $example on$
    // Load and parse the data file, converting it to a DataFrame.
    val data = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    // Index labels, adding metadata to the label column.
    // Fit on whole dataset to include all labels in index.
    val labelIndexer = new StringIndexer()
      .setInputCol("label")
      .setOutputCol("indexedLabel")
      .fit(data)
    // Automatically identify categorical features, and index them.
    // Set maxCategories so features with > 4 distinct values are treated as continuous.
    val featureIndexer = new VectorIndexer()
      .setInputCol("features")
      .setOutputCol("indexedFeatures")
      .setMaxCategories(4)
      .fit(data)

    // Split the data into training and test sets (30% held out for testing).
    val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3))

    // Train a GBT model.
    val gbt = new GBTClassifier()
      .setLabelCol("indexedLabel")
      .setFeaturesCol("indexedFeatures")
      .setMaxIter(10)

    // Convert indexed labels back to original labels.
    val labelConverter = new IndexToString()
      .setInputCol("prediction")
      .setOutputCol("predictedLabel")
      .setLabels(labelIndexer.labels)

    // Chain indexers and GBT in a Pipeline.
    val pipeline = new Pipeline()
      .setStages(Array(labelIndexer, featureIndexer, gbt, labelConverter))

    // Train model. This also runs the indexers.
    val model = pipeline.fit(trainingData)

    // Make predictions.
    val predictions = model.transform(testData)

    // Select example rows to display.
    predictions.select("predictedLabel", "label", "features").show(5)

    // Select (prediction, true label) and compute test error.
    val evaluator = new MulticlassClassificationEvaluator()
      .setLabelCol("indexedLabel")
      .setPredictionCol("prediction")
      .setMetricName("accuracy")
    val accuracy = evaluator.evaluate(predictions)
    println("Test Error = " + (1.0 - accuracy))

    val gbtModel = model.stages(2).asInstanceOf[GBTClassificationModel]
    println("Learned classification GBT model:\n" + gbtModel.toDebugString)
    // $example off$

    spark.stop()
  }
}



/******  ML: Classifications - Naive Bayes  ******/
///***Classifications -  Naive Bayes 

//Naive Bayes is a simple multiclass classification algorithm with the assumption of independence between every pair of features. 
//Naive Bayes can be trained very efficiently. 
//Within a single pass to the training data, it computes the conditional probability distribution of each feature given label, 
//and then it applies Bayes� theorem to compute the conditional probability distribution of label given an observation and use it for prediction


//spark.mllib supports multinomial naive Bayes and Bernoulli naive Bayes. 
//These models are typically used for document classification. 
//Within that context, each observation is a document 
//and each feature represents a term whose value is the frequency of the term (in multinomial naive Bayes) 
//or a zero or one indicating whether the term was found in the document (in Bernoulli naive Bayes)

//The model type is selected with an optional parameter �multinomial� or �bernoulli� with �multinomial� as the default
//Additive smoothing can be used by setting the parameter lambda (default to 1.0 )

///* Naive Bayes  - ML 
///*scala 
import org.apache.spark.ml.classification.NaiveBayes
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator

// Load the data stored in LIBSVM format as a DataFrame.
val data = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

// Split the data into training and test sets (30% held out for testing)
val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3), seed = 1234L)

// Train a NaiveBayes model.
val model = new NaiveBayes()
  .fit(trainingData)

// Select example rows to display.
val predictions = model.transform(testData)
predictions.show()

// Select (prediction, true label) and compute test error
val evaluator = new MulticlassClassificationEvaluator()
  .setLabelCol("label")
  .setPredictionCol("prediction")
  .setMetricName("accuracy")
val accuracy = evaluator.evaluate(predictions)
println("Test set accuracy = " + accuracy)




/******  ML: Regression - Random Forest and Gradient Boost ******/
///*scala - regression 
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.feature.VectorIndexer
import org.apache.spark.ml.regression.{RandomForestRegressionModel, RandomForestRegressor}
// $example off$
import org.apache.spark.sql.SparkSession

object RandomForestRegressorExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("RandomForestRegressorExample")
      .getOrCreate()

    // $example on$
    // Load and parse the data file, converting it to a DataFrame.
    val data = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    // Automatically identify categorical features, and index them.
    // Set maxCategories so features with > 4 distinct values are treated as continuous.
    val featureIndexer = new VectorIndexer()
      .setInputCol("features")
      .setOutputCol("indexedFeatures")
      .setMaxCategories(4)
      .fit(data)

    // Split the data into training and test sets (30% held out for testing).
    val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3))

    // Train a RandomForest model.
    val rf = new RandomForestRegressor()
      .setLabelCol("label")
      .setFeaturesCol("indexedFeatures")

    // Chain indexer and forest in a Pipeline.
    val pipeline = new Pipeline()
      .setStages(Array(featureIndexer, rf))

    // Train model. This also runs the indexer.
    val model = pipeline.fit(trainingData)

    // Make predictions.
    val predictions = model.transform(testData)

    // Select example rows to display.
    predictions.select("prediction", "label", "features").show(5)

    // Select (prediction, true label) and compute test error.
    val evaluator = new RegressionEvaluator()
      .setLabelCol("label")
      .setPredictionCol("prediction")
      .setMetricName("rmse")
    val rmse = evaluator.evaluate(predictions)
    println("Root Mean Squared Error (RMSE) on test data = " + rmse)

    val rfModel = model.stages(1).asInstanceOf[RandomForestRegressionModel]
    println("Learned regression forest model:\n" + rfModel.toDebugString)
    // $example off$

    spark.stop()
  }
}


 ///*scala - regression 
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.evaluation.RegressionEvaluator
import org.apache.spark.ml.feature.VectorIndexer
import org.apache.spark.ml.regression.{GBTRegressionModel, GBTRegressor}
// $example off$
import org.apache.spark.sql.SparkSession

object GradientBoostedTreeRegressorExample {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("GradientBoostedTreeRegressorExample")
      .getOrCreate()

    // $example on$
    // Load and parse the data file, converting it to a DataFrame.
    val data = spark.read.format("libsvm").load("data/mllib/sample_libsvm_data.txt")

    // Automatically identify categorical features, and index them.
    // Set maxCategories so features with > 4 distinct values are treated as continuous.
    val featureIndexer = new VectorIndexer()
      .setInputCol("features")
      .setOutputCol("indexedFeatures")
      .setMaxCategories(4)
      .fit(data)

    // Split the data into training and test sets (30% held out for testing).
    val Array(trainingData, testData) = data.randomSplit(Array(0.7, 0.3))

    // Train a GBT model.
    val gbt = new GBTRegressor()
      .setLabelCol("label")
      .setFeaturesCol("indexedFeatures")
      .setMaxIter(10)

    // Chain indexer and GBT in a Pipeline.
    val pipeline = new Pipeline()
      .setStages(Array(featureIndexer, gbt))

    // Train model. This also runs the indexer.
    val model = pipeline.fit(trainingData)

    // Make predictions.
    val predictions = model.transform(testData)

    // Select example rows to display.
    predictions.select("prediction", "label", "features").show(5)

    // Select (prediction, true label) and compute test error.
    val evaluator = new RegressionEvaluator()
      .setLabelCol("label")
      .setPredictionCol("prediction")
      .setMetricName("rmse")
    val rmse = evaluator.evaluate(predictions)
    println("Root Mean Squared Error (RMSE) on test data = " + rmse)

    val gbtModel = model.stages(1).asInstanceOf[GBTRegressionModel]
    println("Learned regression GBT model:\n" + gbtModel.toDebugString)
    // $example off$

    spark.stop()
  }
}



/******  ML: Regression - LM and GLM  ******/
///*** Regression - ML and MLIB 
//ordinary least squares or linear least squares uses no regularization; 
//ridge regression uses L2 regularization; 
//and Lasso uses L1 regularization
//L2 + L1 (elastic net) for ML 

///* Regression - ML  - https://web.stanford.edu/~hastie/glmnet/glmnet_alpha.html
LinearRegression
    elasticNetParam corresponds to L1/L2 ratio, alpha 
    regParam corresponds to regularization parameter (called lambda),  controls the overall strength of the penalty
    elasticParam in range [0, 1]. For elasticParam = 0, the penalty is an L2 penalty(ridge). For elasticParam = 1, it is an L1 penalty(lasso)
    the larger the value of lambda, alpha , the greater the amount of shrinkage and thus the coefficients become more robust to collinearity
GeneralizedLinearRegression
    //Family    Response Type       Links(* default/canonical)
    Gaussian    Continuous          Identity*, Log, Inverse 
    Binomial    Binary              Logit*, Probit, CLogLog 
    Poisson     Count               Log*, Identity, Sqrt 
    Gamma       Continuous          Inverse*, Idenity, Log 

///*scala 
//training an elastic net regularized linear regression model and extracting model summary statistics.
import org.apache.spark.ml.regression.LinearRegression

// Load training data
val training = spark.read.format("libsvm")
  .load("data/mllib/sample_linear_regression_data.txt")

val lr = new LinearRegression()
  .setMaxIter(10)
  .setRegParam(0.3)
  .setElasticNetParam(0.8)

// Fit the model
val lrModel = lr.fit(training)

// Print the coefficients and intercept for linear regression
println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")

// Summarize the model over the training set and print out some metrics
val trainingSummary = lrModel.summary
println(s"numIterations: ${trainingSummary.totalIterations}")
println(s"objectiveHistory: [${trainingSummary.objectiveHistory.mkString(",")}]")
trainingSummary.residuals.show()
println(s"RMSE: ${trainingSummary.rootMeanSquaredError}")
println(s"r2: ${trainingSummary.r2}")



//training a GLM with a Gaussian response and identity link function and extracting model summary statistics.
import org.apache.spark.ml.regression.GeneralizedLinearRegression

// Load training data
val dataset = spark.read.format("libsvm")
  .load("data/mllib/sample_linear_regression_data.txt")

val glr = new GeneralizedLinearRegression()
  .setFamily("gaussian")
  .setLink("identity")
  .setMaxIter(10)
  .setRegParam(0.3)

// Fit the model
val model = glr.fit(dataset)

// Print the coefficients and intercept for generalized linear regression model
println(s"Coefficients: ${model.coefficients}")
println(s"Intercept: ${model.intercept}")

// Summarize the model over the training set and print out some metrics
val summary = model.summary
println(s"Coefficient Standard Errors: ${summary.coefficientStandardErrors.mkString(",")}")
println(s"T Values: ${summary.tValues.mkString(",")}")
println(s"P Values: ${summary.pValues.mkString(",")}")
println(s"Dispersion: ${summary.dispersion}")
println(s"Null Deviance: ${summary.nullDeviance}")
println(s"Residual Degree Of Freedom Null: ${summary.residualDegreeOfFreedomNull}")
println(s"Deviance: ${summary.deviance}")
println(s"Residual Degree Of Freedom: ${summary.residualDegreeOfFreedom}")
println(s"AIC: ${summary.aic}")
println("Deviance Residuals: ")
summary.residuals().show()



/******  ML: Regression - Survival regression ******/
///*** Regression - Survival regression - ML 
//Accelerated failure time (AFT) model which is a parametric survival regression model for censored data. 
//It describes a model for the log of survival time

///*scala 
import org.apache.spark.ml.linalg.Vectors
import org.apache.spark.ml.regression.AFTSurvivalRegression

val training = spark.createDataFrame(Seq(
  (1.218, 1.0, Vectors.dense(1.560, -0.605)),
  (2.949, 0.0, Vectors.dense(0.346, 2.158)),
  (3.627, 0.0, Vectors.dense(1.380, 0.231)),
  (0.273, 1.0, Vectors.dense(0.520, 1.151)),
  (4.199, 0.0, Vectors.dense(0.795, -0.226))
)).toDF("label", "censor", "features")
val quantileProbabilities = Array(0.3, 0.6)
val aft = new AFTSurvivalRegression()
  .setQuantileProbabilities(quantileProbabilities)
  .setQuantilesCol("quantiles")

val model = aft.fit(training)

// Print the coefficients, intercept and scale parameter for AFT survival regression
println(s"Coefficients: ${model.coefficients}")
println(s"Intercept: ${model.intercept}")
println(s"Scale: ${model.scale}")
model.transform(training).show(false)




/******  ML: Clustering - KMeans  ******/
///*** Clustering 
//Clustering is an unsupervised learning problem 
//whereby we aim to group subsets of entities with one another based on some notion of similarity

///*ML  - Kmeans 
//Input Columns
//Param name      Type(s)     Default         Description
featuresCol       Vector      "features"      Feature vector 
//Output Columns
predictionCol     Int         "prediction"    Predicted cluster center 


///*scala 
import org.apache.spark.ml.clustering.KMeans

// Loads data.
val dataset = spark.read.format("libsvm").load("data/mllib/sample_kmeans_data.txt")

// Trains a k-means model.
val kmeans = new KMeans().setK(2).setSeed(1L)
val model = kmeans.fit(dataset)

// Evaluate clustering by computing Within Set Sum of Squared Errors.
val WSSSE = model.computeCost(dataset)
println(s"Within Set Sum of Squared Errors = $WSSSE")

// Shows the result.
println("Cluster Centers: ")
model.clusterCenters.foreach(println)




///* Bisecting k-means
//Bisecting k-means is a kind of hierarchical clustering 
//for example - using a divisive (or �top-down�)
//approach: all observations start in one cluster, 
//and splits are performed recursively as one moves down the hierarchy.

//Bisecting K-means can often be much faster than regular K-means, but it will generally produce a different clustering
 
//Strategies for hierarchical clustering generally fall into two types:
�Agglomerative: This is a �bottom up� approach: each observation starts in its own cluster, and pairs of clusters are merged as one moves up the hierarchy.
�Divisive: This is a �top down� approach: all observations start in one cluster, and splits are performed recursively as one moves down the hierarchy.
 ///*ML  - Bisecting k-means 
//Only top-down approach 
///*scala 
import org.apache.spark.ml.clustering.BisectingKMeans

// Loads data.
val dataset = spark.read.format("libsvm").load("data/mllib/sample_kmeans_data.txt")

// Trains a bisecting k-means model.
val bkm = new BisectingKMeans().setK(2).setSeed(1)
val model = bkm.fit(dataset)

// Evaluate clustering.
val cost = model.computeCost(dataset)
println(s"Within Set Sum of Squared Errors = $cost")

// Shows the result.
println("Cluster Centers: ")
val centers = model.clusterCenters
centers.foreach(println)



    
/******  Streaming - Kmeans  ******/
///*MLIB  - Streaming k-means
///*scala 
import org.apache.spark.SparkConf
// $example on$
import org.apache.spark.mllib.clustering.StreamingKMeans
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.streaming.{Seconds, StreamingContext}
// $example off$

/**
 * Estimate clusters on one stream of data and make predictions
 * on another stream, where the data streams arrive as text files
 * into two different directories.
 *
 * The rows of the training text files must be vector data in the form
 * `[x1,x2,x3,...,xn]`
 * Where n is the number of dimensions.
 *
 * The rows of the test text files must be labeled data in the form
 * `(y,[x1,x2,x3,...,xn])`
 * Where y is some identifier. n must be the same for train and test.
 *
 * Usage:
 *   StreamingKMeansExample <trainingDir> <testDir> <batchDuration> <numClusters> <numDimensions>
 *
 * To run on your local machine using the two directories `trainingDir` and `testDir`,
 * with updates every 5 seconds, 2 dimensions per data point, and 3 clusters, call:
 *    $ bin/run-example mllib.StreamingKMeansExample trainingDir testDir 5 3 2
 *
 * As you add text files to `trainingDir` the clusters will continuously update.
 * Anytime you add text files to `testDir`, you'll see predicted labels using the current model.
 *
 */
object StreamingKMeansExample {

  def main(args: Array[String]) {
    if (args.length != 5) {
      System.err.println(
        "Usage: StreamingKMeansExample " +
          "<trainingDir> <testDir> <batchDuration> <numClusters> <numDimensions>")
      System.exit(1)
    }

    // $example on$
    val conf = new SparkConf().setAppName("StreamingKMeansExample")
    val ssc = new StreamingContext(conf, Seconds(args(2).toLong))

    val trainingData = ssc.textFileStream(args(0)).map(Vectors.parse)
    val testData = ssc.textFileStream(args(1)).map(LabeledPoint.parse)

    val model = new StreamingKMeans()
      .setK(args(3).toInt)
      .setDecayFactor(1.0)
      .setRandomCenters(args(4).toInt, 0.0)

    model.trainOn(trainingData)
    model.predictOnValues(testData.map(lp => (lp.label, lp.features))).print()

    ssc.start()
    ssc.awaitTermination()
    // $example off$
  }
}




/****** Streaming - Regression  ******/

///StreamingLinearRegresion 
import org.apache.spark.SparkConf
// $example on$
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.regression.StreamingLinearRegressionWithSGD
// $example off$
import org.apache.spark.streaming._

/**
 * Train a linear regression model on one stream of data and make predictions
 * on another stream, where the data streams arrive as text files
 * into two different directories.
 *
 * The rows of the text files must be labeled data points in the form
 * `(y,[x1,x2,x3,...,xn])`
 * Where n is the number of features. n must be the same for train and test.
 *
 * Usage: StreamingLinearRegressionExample <trainingDir> <testDir>
 *
 * To run on your local machine using the two directories `trainingDir` and `testDir`,
 * with updates every 5 seconds, and 2 features per data point, call:
 *    $ bin/run-example mllib.StreamingLinearRegressionExample trainingDir testDir
 *
 * As you add text files to `trainingDir` the model will continuously update.
 * Anytime you add text files to `testDir`, you'll see predictions from the current model.
 *
 */
object StreamingLinearRegressionExample {

  def main(args: Array[String]): Unit = {
    if (args.length != 2) {
      System.err.println("Usage: StreamingLinearRegressionExample <trainingDir> <testDir>")
      System.exit(1)
    }

    val conf = new SparkConf().setAppName("StreamingLinearRegressionExample")
    val ssc = new StreamingContext(conf, Seconds(1))

    // $example on$
    val trainingData = ssc.textFileStream(args(0)).map(LabeledPoint.parse).cache()
    val testData = ssc.textFileStream(args(1)).map(LabeledPoint.parse)

    val numFeatures = 3
    val model = new StreamingLinearRegressionWithSGD()
      .setInitialWeights(Vectors.zeros(numFeatures))

    model.trainOn(trainingData)
    model.predictOnValues(testData.map(lp => (lp.label, lp.features))).print()

    ssc.start()
    ssc.awaitTermination()
    // $example off$

    ssc.stop()
  }
}
