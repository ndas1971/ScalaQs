"""
DAY-3
    Generics and Type class and implicits 
    variances and bounds
    Scala Concurrent (future,akka)
    scala jdbc 
    scala xml,json
    Introduction to scala kafka avro 
"""
//////////////////////////////////////

///*** Generics 

//note 'object' can not take any constructor or parameter. 
//object's method can be parametric
//trait can take parameter but not constructor
//class/abstract class  can take parameter and constructor


//Generic/parametric class[T] and Abstract Type ie { type T}

//Note there is no concept of raw type in scala even though scala uses JVM type erasure at runtime
//Hence parametric class/trait must be used with parameter always

//Note that parametric type T is a UNIQUE new type inside class, 
//not same with another parametric type U or V used inside that class(even if usage denotes that)
//also not even same with any concrete type (rank 1 polymorphism)

//hence if any method inside Class needs to be applicable for all types including T, 
//make that method generic/parametric with another type U

//Note C++ template is instantiation based, means based on type inference, instantiate the template code 
//and then compiler checks method applicability

//But in java, scala - compiler checks applicability of the methods based on Type T, 
//Without any bound, T means Any (in java , T is Object). Use Bound on T to use methods from Bounds
//hence generic Numeric method etc is difficult to write (in scala, use Numeric context)

class Holder[T](x:T) {
  val element: T  = x
}
new Holder(1)     //note the type is Holder[Int]

//With abstract Type, note we can not use T in constructor, hence type T is hidden
//also not possible to get default value of T for 'val' , for var, we can use _
abstract class Holder {
  type T
  val element: T 
}
trait Holder {
  type T
  val element: T 
}
new Holder { type T = Int; val element: T = 2 }  //Anon class 


//type is Holder{ type T = Int }, which is not same as Int or Holder[Int]
//type element is Int inside Holder, 
//but outside , it is Holder#T 
//or specifically holder_instance.T  (if instance exists) which is not same as Int (but can be casted to Int)

//Example: Generic Type and Abstract Type - Mostly same
//but Parameteric class usage might bloat code compared to abstract type


class Stack[T] {
  var elems: List[T] = Nil
  def push(x: T) { elems = x :: elems }
  def top: T = elems.head
  def pop()={ val s = top; elems = elems.tail; s }
}

val stack = new Stack[Int]
s.push(1)
s.pop

//Abstract Type
abstract class Stack {
  type T
  var elems: List[T] = Nil
  def push(x: T) { elems = x :: elems }
  def top: T = elems.head
  def pop()={ val s = top; elems = elems.tail; s }
}
val s= new Stack { type T = Int }
s.push(1)
s.pop  //res49: s.T = 1   Note that Type is s.T  - path dependent type, which is not Int and not same as other_instance.T
s.push(1)
s.pop.asInstanceOf[Int]  //Int = 1



///*** Abstract Types  - Creates path dependent type
trait C2 {
   type A
   def get : A
}
//there are three different types Int, C2#A and c.A
var c : C2 = new C2 {   // c :C2 is must else c becomes C2{type x = Int} and can not be reassigned
      type A = Int
      def get = 3
      }

var result = c.get   //result: C2#A = 3 , Note the it is C2#A type , not Int
                     // but is auto converted to Int when required
					 //but Int is not auto converted to  C2#A or c.A, use casting

var b = 2   //b: Int = 2
b = a.get  //b: Int = 3

def f(x:C2#A) = 2  //f: (x: C2#A)Int  //takes C2#A
f(2)     			//<console>:11: error: type mismatch;
f(a.get) 			//res11: Int = 2
f(2.asInstanceOf[C2#A])  //res15: Int = 2
f(2.asInstanceOf[c.A]) //res16: Int = 2

def h(x:c.A) = 44  //takes instance.A  which is Int and is autoconverted to each other
h(2) //res17: Int = 44
h(c.get) //res18: Int = 44

def g(x:Int) = 333 //g: (x: Int)Int
g(c.get)  //res12: Int = 333


c = new C2 {      
         type A = String
         def get = "hi"
      }

result = c.get  //result: C2#A = hi
result.isInstanceOf[String]  //res0: Boolean = true
result = "4"     // NOk, as result is of type C2#A and is not same as String




///*** implicit and type class 

//used when either a value that can be passed "automatically", 
//or a conversion from one type to another that is made automatically.

///* Implicit Conversion
//if one calls a method m on an object o of a class C, 
//and that class does not support method m, 
//then Scala will look for an implicit conversion from C to something that does support m. 
"abc".map(_.toInt)  //String does not support the method map, but StringOps does, 
//example 
implicit class StringToInt(s: String) {
      @throws(classOf[NumberFormatException])
      def toInt(radix: Int) = Integer.parseInt(s, radix)
    }
"1".toInt(2)
//Or equivalent to if class exists 
class StringToInt(s: String) {
      @throws(classOf[NumberFormatException])
      def toInt(radix: Int) = Integer.parseInt(s, radix)
    }
    
implicit def xyz__(s:String) = new StringToInt(s)
"1".toInt(2)
//OR 
implicit class StringToInt(s: String) {
      @throws(classOf[NumberFormatException])
      def toInt(radix: Int) = Integer.parseInt(s, radix)
    }
"1".toInt(2)


///* Implicit Parameters
//These are passed to method calls like any other parameter, 
//but the compiler tries to fill them in automatically. 
//If it can't, it will complain. 
//One can pass these parameters explicitly as well 
def foo[T](t: T)(implicit integral: Integral[T]) {println(integral)}

//implicits are used to pass configuration items and (IMP****)
//magically function behaves accordingly 


//implicit has to be last curried parameter and only one group of args exists
//where all are implicits 
def fun()(implicit x:XYZ, y:Int) = ???  //XYZ, Int are implicits , in your scope only one instance of XYZ and Int must exist

//You can pass explicit args in place of implicits 
//OR in your scope(and only in your scope), 
//only one implicit val  with that type(eg XYZ and Int) can exist
//(more gives error), which would be used by default
implicit val abcd :XYZ = ...
implicit val xy :Int = ...
fun() 

//Note Class construtors are also methods, 
//hence you can pass curried implicits as last args 
class MY()(implicit x:XYZ,...)



///* View Bounds
def getIndex[T, CC](seq: CC, value: T)(implicit conv: CC => Seq[T]) = seq.indexOf(value)
//or with view bound syntax , similar to to an upper bound (CC <: Seq[Int]) or a lower bound (T >: Null).
def getIndex[T, CC <% Seq[T]](seq: CC, value: T) = seq.indexOf(value)

//The method getIndex can receive any object, 
//as long as there is an implicit conversion available from its class to Seq[T]. 
//Behind the scenes, the compiler changes seq.IndexOf(value) 
//to conv(seq).indexOf(value).
getIndex("abc", 'a')


///* Context Bounds, type class pattern. 
//There's a library that makes heavy use of this pattern, called Scalaz.

//Note Double as Integral implicits not available by default 
def sum[T](list: List[T])(implicit integral: Integral[T]): T = {
    import integral._   // get the implicits in question into scope
    list.foldLeft(integral.zero)(_ + _) //now + works 
}

//or with  context bound, 
def sum[T : Integral](list: List[T]): T = {
    val integral = implicitly[Integral[T]]
    import integral._   // get the implicits in question into scope
    list.foldLeft(integral.zero)(_ + _)
}

//Context bounds are more useful when you just need to pass them to other methods that use them. 
//For example, the method sorted on Seq needs an implicit Ordering. 
//To create a method reverseSort
//Because Ordering[T] was implicitly passed to reverseSort, 
//it can then pass it implicitly to sorted.
def reverseSort[T : Ordering](seq: Seq[T]) = seq.sorted.reverse


//Another Example 
trait  NumberLike[T] {   //define a container class
    def plus(x: T, y: T): T
}

//note for actual Type T is not defined 
//both below are equivalent 
def method[T: NumberLike](x1: T, x2:T): T =  implicitly[NumberLike[T]].plus(x1,x2)
def method[T](x1: T, x2: T)(implicit ev: NumberLike[T]) = ev.plus(x1, x2) 

//but calling fails as Int is not NumberLike 
method(1,2)

//but define a implicit( now You can define as many implicits for many different T)
implicit val xyzw = new NumberLike[Int]{ def plus(x:Int, y:Int) = x+y } //annon 
//OR 
implicit object XYZW extends NumberLike[Int] { def plus(x:Int, y:Int) = x+y}

method(1,2) //works 


///* Implicits Scope
//The implicits available under number 1 below has precedence over the ones under number 2. 
//Other than that, if there are several eligible arguments which match the implicit parameter’s type, 
//a most specific one will be chosen using the rules of static overloading resolution (see Scala Specification §6.26.3). 
1.First look in current scope 
    •Implicits defined in current scope
    •Explicit imports
    •wildcard imports
    •Same scope in other files(package objects)
2.Now look at associated types in 
    •Companion objects of a type
    •Implicit scope of an argument type 
    •Implicit scope of type arguments 
    •Outer objects for nested types

//For example to use Implicits without any import from  library 
//Use below 
    1.Types companion object 
    2.library package object 
    3.Outer objects 
    4.users package objects 

    
///** Implicits Defined in Current Scope
implicit val n: Int = 5
def add(x: Int)(implicit y: Int) = x + y
add(5) // takes n from the current scope

///** Explicit Imports
import scala.collection.JavaConversions._  // for mapAsScalaMap
def env = System.getenv() // Java map
val term = env("APPDATA")    // implicit conversion from Java Map to Scala Map

///** Wildcard Imports
def sum[T : Integral](list: List[T]): T = {
    val integral = implicitly[Integral[T]]
    import integral._   // get the implicits in question into scope
    list.foldLeft(integral.zero)(_ + _)
}

///** Same Scope in Other Files eg package objects 
//The implicit value members defined in a package object 'test' are available to:
1. Any class in the test (or a sub-package there-of)
2. Anyone outside who issues import test._
3. Implicit search for type T,where T is in that 'test' or a sub-package

//This is like the first example, but the implicit definition is in a different file(ie package objects) 
//dir structure 
test
  --foo
    --Foo.scala
  --bar
    --Bar.scala
  package.scala

//package 
//these implicits will only work for a type prefixed by that package. 
//ie A == test.Foo
package object test {
    implicit class Pipe[A](a: A) {
      def |>[B](f: A => B): B = f(a)
    }
}

//Foo.scala (in the package test.foo) :
package test.foo

case class Foo(i: Int)

object Foo {
    import test._ //ERROR if not  used 
    
    2.0 |> math.floor    //2.0 is outside of test package, hence use explicit import 
}

//Bar.scala
package test.bar

import test.foo.Foo

object Bar extends App {

    def plus2(i: Int) = i + 2
    def plus2(f: Foo) = f.i + 2
    def plus2(o: Option[Foo]) = o.map(f => Foo(f.i + 2))
    println(Foo(2) |> plus2)    //OK ,from package object 
    println(Option(Foo(2)) |> plus2) //OK , from package objects 
    import test._
    println(2 |> plus2)   //For other types, use explicit 'import     

}



///** Companion Objects of a Type
///** Case-1:the object companion of the "source" type is looked into. 
//For instance, inside the object Option there is an implicit conversion to Iterable, 
//so one can call Iterable methods on Option, or pass Option to something expecting an Iterable.

//List.flatMap expects a TraversableOnce, which Option is not. 
//The compiler then looks inside Option's object companion and finds the conversion to Iterable, 
//which is a TraversableOnce, making this expression correct. 
for {
    x <- List(1, 2, 3)
    y <- Some('x')
} yield (x, y)

//OR 
List(1, 2, 3).flatMap(x => Some('x').map(y => (x, y)))

///** Case-2:the companion object of the expected type
//The method sorted takes an implicit Ordering. 
//In this case, it looks inside the object Ordering, companion to the class Ordering, 
//and finds an implicit Ordering[Int] there.
List(1, 2, 3).sorted

//Note that companion objects of super classes are also looked into. 
class A(val n: Int)
object A { 
    implicit def str(a: A) = "A: %d" format a.n
}
class B(val x: Int, y: Int) extends A(y)
val b = new B(5, 2)
val s: String = b  // s == "A: 2"



///** Implicit Scope of an Argument's Type ( fn(x:A) , inside A or it's companion)
//If you have a method with an argument type A, 
//then the implicit scope of type A will also be considered. 
//By "implicit scope" , all above rules will be applied recursively 
//-- for example, the companion object of A will be searched for implicits

class A(val n: Int) {
  def +(other: A) = new A(n + other.n)
}
object A {
  implicit def fromInt(n: Int) = new A(n)
}

// This becomes possible:
1 + new A(1)
// because it is converted into this:
A.fromInt(1) + new A(1)



///** Implicit Scope of Type Arguments(type class)(ie fn[B[_],A](x:B[A]), inside A or it's companion))
//Consider Ordering, for instance: It comes with some implicits in its companion object, 
//but you can't add stuff to it. 
//So how can you make an Ordering for your own class that is automatically found?

class A(val n: Int)
object A {
    implicit val ord = new Ordering[A] {
        def compare(x: A, y: A) = implicitly[Ordering[Int]].compare(x.n, y.n)
    }
}

//the method sorted expects an Ordering[A] 
//(actually, it expects an Ordering[B], where B >: A). 
List[A](new A(5), new A(2)).sorted

//This is also how various collection methods expecting CanBuildFrom work: 
//the implicits are found inside companion objects to the type parameters of CanBuildFrom.



///** Outer Objects for Nested Types
class A(val n: Int) {
  class B(val m: Int) { require(m < n) }
}
object A {
  implicit def bToString(b: A#B) = "B: %d" format b.m
}
val a = new A(5)
val b = new a.B(3)
val s: String = b  // s == "B: 3"


 
///*** Ordering and Numeric  Implicits 

//Ordering is for orderable generic T, 
//implement it's abstract def compare(x:T, y:T):Int to give a class Ordering traits 
//below operators are defined 
class scala.math.Ordering.Ops extends AnyRef
    This inner class defines comparison operators available for T.
        def <(rhs: T): Boolean
        def <=(rhs: T): Boolean
        def >(rhs: T): Boolean
        def >=(rhs: T): Boolean
        def equiv(rhs: T): Boolean
        def max(rhs: T): T
        def min(rhs: T): T 


//For Example, To compare Tuple, list etc , use Ordering Implicits
scala> List(1,2) < List(1,2)
<console>:8: error: value < is not a member of List[Int]
              List(1,2) < List(1,2)
                        ^

scala> import scala.math.Ordering.Implicits._
import scala.math.Ordering.Implicits._

scala> List(1,2) < List(1,2)
res1: Boolean = false

scala> (1,2) <= (1,2)
res3: Boolean = true

//To use compare
scala> implicitly[Ordering[Tuple2[Int, Int]]].compare((1,2), (2,3))
res10: Int = -1

//To sort instances by one or more member variables, 
//use Ordering.by and Ordering.on:
//Example 
import scala.util.Sorting //only for Array and Inplace sorting 
val pairs = Array(("a", 5, 2), ("c", 3, 1), ("b", 1, 3))
// Given Tuple(String, Int, Int), sort by 2nd element,Int 
Sorting.quickSort(pairs)(Ordering.by[(String, Int, Int), Int](_._2))
// sort by the 3rd element,Int, then 1st,String
Sorting.quickSort(pairs)(Ordering[(Int, String)].on(x => (x._3, x._1)))
//Custom
import scala.util.Sorting
case class Person(name:String, age:Int)
val people = Array(Person("bob", 30), Person("ann", 32), Person("carl", 19))
// sort by age
object AgeOrdering extends Ordering[Person] {
  def compare(a:Person, b:Person) = a.age compare b.age
}
Sorting.quickSort(people)(AgeOrdering)


//Numeric(base)/Integral(derived)/Fractional(derived)(Integral and Fractional are siblings)
//for generic T of number type , extends Ordering 
//Implement it's many abstract method for Custom class to behave like Numeric type 


//Note object Numeric has many implicit definition to convert number type to Integral 
//eg Long, Int, Char, Byte , BigInt etc 

//Note Float, Double, BigDecimal  are Fractional type, hence have implicits on them
//But they don't have for Integral implicit eventhough those are defined in Numeric
//Use below in your scope if required 
implicit val db = DoubleAsIfIntegral
//To check which is implicit object , check like below 
//Note Definition of Integral (derived class of Numeric, handles numeric as well)
scala> implicitly[Numeric[Int]]
res8: Numeric[Int] = scala.math.Numeric$IntIsIntegral$@38e57a4b

scala> implicitly[Integral[Int]]
res9: Integral[Int] = scala.math.Numeric$IntIsIntegral$@38e57a4b

scala> implicitly[Fractional[Int]]
<console>:16: error: could not find implicit value for parameter e: Fractional[Int]
       implicitly[Fractional[Int]]
//Reference 
object Numeric extends Serializable
        object BigDecimalAsIfIntegral extends BigDecimalAsIfIntegral with BigDecimalOrdering
        implicit object BigDecimalIsFractional extends BigDecimalIsFractional with BigDecimalOrdering
        implicit object BigIntIsIntegral extends BigIntIsIntegral with BigIntOrdering
        implicit object ByteIsIntegral extends ByteIsIntegral with ByteOrdering
        implicit object CharIsIntegral extends CharIsIntegral with CharOrdering
        object DoubleAsIfIntegral extends DoubleAsIfIntegral with DoubleOrdering
        implicit object DoubleIsFractional extends DoubleIsFractional with DoubleOrdering
        object FloatAsIfIntegral extends FloatAsIfIntegral with FloatOrdering
        implicit object FloatIsFractional extends FloatIsFractional with FloatOrdering
        object Implicits extends ExtraImplicits
        implicit object IntIsIntegral extends IntIsIntegral with IntOrdering
        implicit object LongIsIntegral extends LongIsIntegral with LongOrdering
        implicit object ShortIsIntegral extends ShortIsIntegral with ShortOrdering 
        
//Numeric is base type, has below operators 
class scala.math.Numeric.Ops extends AnyRef
    def *(rhs: T): T
    def +(rhs: T): T
    def -(rhs: T): T
    def abs(): T
    def signum(): Int
    def toDouble(): Double
    def toFloat(): Float
    def toInt(): Int
    def toLong(): Long
    def unary_-(): T 
    
//Integral is for Long, Int, Char, Byte , BigInt etc , has below orderings  
class IntegralOps extends Ops
    def %(rhs: T): T
    def *(rhs: T): T
    def +(rhs: T): T
    def -(rhs: T): T
    def /(rhs: T): T
    def /%(rhs: T): (T, T)
    def abs(): T
    def signum(): Int
    def toDouble(): Double
    def toFloat(): Float
    def toInt(): Int
    def toLong(): Long
    def unary_-(): T 

//Fractional is for BigDecimal, Float, Double, has below methods 
class FractionalOps extends Ops
    def *(rhs: T): T
    def +(rhs: T): T
    def -(rhs: T): T
    def /(rhs: T): T
    def abs(): T
    def signum(): Int
    def toDouble(): Double
    def toFloat(): Float
    def toInt(): Int
    def toLong(): Long
    def unary_-(): T   
    
///*** Example  of Numeric 
class MyInt(val x:Int) extends Ordered[MyInt] {

    def this() { this(0) }

    override def hashCode = x.hashCode
    override def toString =  s"MyInt($x)"
    override def equals(o :Any) = o match {
        case _:MyInt =>  o.hashCode == this.hashCode
        case _ => false
    }
    //http://www.scala-lang.org/api/2.11.7/#scala.math.Numeric
    //Numeric has .toXX, .zero and all comparison operators
    //+, -, *, but not % / (for that use Integral, a class derived from Numeric)
    //Note Numeric implements Ordering methods 
    //RHS is T 
    def +[T:Numeric]( o:T ) = {
        val num = implicitly[Numeric[T]]
        import num._
        MyInt(this.x + o.toInt)  //now + works 
    }
    //different way 
    //LHS is T , RHS is MyInt 
    def +:[T]( o:T )(implicit ev:Numeric[T]) = {
        import ev._
        MyInt(this.x + o.toInt)
    }
    def +( o:MyInt ) = MyInt(this.x + o.x)
    def compare(o:MyInt)  =  this.x compare o.x
}
object MyInt {
    def apply(x:Int) = new MyInt(x)
    implicit def intToMyInt(x:Int) = new MyInt(x)  //Automatically used 
}

//Test 
import org.scalatest.{FunSuite, BeforeAndAfter}

class MyIntTest extends FunSuite with BeforeAndAfter {     

  // these first two instance should be equal  
  // Fixtures as reassignable variables and mutable objects
  var a:MyInt = _ 
  var c:MyInt = _ 
  var d:MyInt = _ 
  before {
      a = MyInt(1)
      c = MyInt(2)
      d = MyInt(1)
  }

  test("same == same ") { assert(a == d) }
  test("same != different") { assert(a != c ) }
  test(" + ") { assert(a + d == c) }
  test("+ Int ")  { assert(a + 1 == c ) }
  test("Int + ")  { assert(1 +: a == c) }
  test("Int +  2nd case")  { assert(1 + a == c) }
}







///*** Reference of Ordering, Numeric, Integral, Fractional 
trait scala.math.Ordering[T] extends Comparator[T] with PartialOrdering[T] with Serializable
    This trait and scala.math.Ordered both provide this same functionality
    
    A type T can be given a single way to order itself by extending Ordered. 
    Using Ordering, this same type may be sorted in many other ways. 
    Ordered and Ordering both provide implicits allowing them to be used interchangeably.
    Use import scala.math.Ordering.Implicits to gain access to other implicit orderings.

    For new class,T, use T:Ordering and define 
    implicit val x = or implicit def x = or implicit object X extends Ordering[T]
    then implement its abstract methods 
    New class T can be used for anyplace where Ordering is required 
    Orderings companion object defines many implicit objects to deal 
    with subtypes of AnyVal (e.g. Int, Double), String, and others.
    
    Once Ordering instance is available Ordering.Ops methods are available    

    
    //Abstract Value Members
        abstract def compare(x: T, y: T): Int
        Returns an integer whose sign communicates how x compares to y.
    //Concrete Value Members
        def equiv(x: T, y: T): Boolean
            Return true if x == y in the ordering.
        def gt(x: T, y: T): Boolean
            Return true if x > y in the ordering.
        def gteq(x: T, y: T): Boolean
            Return true if x >= y in the ordering.
        def lt(x: T, y: T): Boolean
            Return true if x < y in the ordering.
        def lteq(x: T, y: T): Boolean
            Return true if x <= y in the ordering.
        def max(x: T, y: T): T
            Return x if x >= y, otherwise y.
        def min(x: T, y: T): T
            Return x if x <= y, otherwise y.
        implicit def mkOrderingOps(lhs: T): Ops
            This implicit method augments T with the comparison operators defined in scala.math.Ordering.Ops.
        def on[U](f: (U) => T): Ordering[U]
            Given f, a function from U into T, creates an Ordering[U] whose compare function is equivalent to:
        def reverse: Ordering[T]
            Return the opposite ordering of this one.
        def tryCompare(x: T, y: T): Some[Int]
            Returns whether a comparison between x and y is defined, and if so the result of compare(x, y).
object Ordering extends LowPriorityOrderingImplicits with Serializable
    Type Members
        trait BigDecimalOrdering extends Ordering[BigDecimal]
        trait BigIntOrdering extends Ordering[BigInt]
        trait BooleanOrdering extends Ordering[Boolean]
        trait ByteOrdering extends Ordering[Byte]
        trait CharOrdering extends Ordering[Char]
        trait DoubleOrdering extends Ordering[Double]
        trait ExtraImplicits extends AnyRef
        trait FloatOrdering extends Ordering[Float]
        trait IntOrdering extends Ordering[Int]
        trait LongOrdering extends Ordering[Long]
        trait OptionOrdering[T] extends Ordering[Option[T]]
        trait ShortOrdering extends Ordering[Short]
        trait StringOrdering extends Ordering[String]
        trait UnitOrdering extends Ordering[Unit]
    Value Members
        implicit object BigDecimal extends BigDecimalOrdering
        implicit object BigInt extends BigIntOrdering
        implicit object Boolean extends BooleanOrdering
        implicit object Byte extends ByteOrdering
        implicit object Char extends CharOrdering
        implicit object Double extends DoubleOrdering
        implicit object Float extends FloatOrdering
        object Implicits extends ExtraImplicits
            An object containing implicits which are not in the default scope.
        implicit object Int extends IntOrdering
        implicit def Iterable[T](implicit ord: Ordering[T]): Ordering[Iterable[T]]
        implicit object Long extends LongOrdering
        implicit def Option[T](implicit ord: Ordering[T]): Ordering[Option[T]]
        implicit object Short extends ShortOrdering
        implicit object String extends StringOrdering
        implicit def Tuple2[T1, T2](implicit ord1: Ordering[T1], ord2: Ordering[T2]): Ordering[(T1, T2)]
        implicit def Tuple3[T1, T2, T3](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3]): Ordering[(T1, T2, T3)]
        implicit def Tuple4[T1, T2, T3, T4](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3], ord4: Ordering[T4]): Ordering[(T1, T2, T3, T4)]
        implicit def Tuple5[T1, T2, T3, T4, T5](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3], ord4: Ordering[T4], ord5: Ordering[T5]): Ordering[(T1, T2, T3, T4, T5)]
        implicit def Tuple6[T1, T2, T3, T4, T5, T6](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3], ord4: Ordering[T4], ord5: Ordering[T5], ord6: Ordering[T6]): Ordering[(T1, T2, T3, T4, T5, T6)]
        implicit def Tuple7[T1, T2, T3, T4, T5, T6, T7](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3], ord4: Ordering[T4], ord5: Ordering[T5], ord6: Ordering[T6], ord7: Ordering[T7]): Ordering[(T1, T2, T3, T4, T5, T6, T7)]
        implicit def Tuple8[T1, T2, T3, T4, T5, T6, T7, T8](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3], ord4: Ordering[T4], ord5: Ordering[T5], ord6: Ordering[T6], ord7: Ordering[T7], ord8: Ordering[T8]): Ordering[(T1, T2, T3, T4, T5, T6, T7, T8)]
        implicit def Tuple9[T1, T2, T3, T4, T5, T6, T7, T8, T9](implicit ord1: Ordering[T1], ord2: Ordering[T2], ord3: Ordering[T3], ord4: Ordering[T4], ord5: Ordering[T5], ord6: Ordering[T6], ord7: Ordering[T7], ord8: Ordering[T8], ord9: Ordering[T9]): Ordering[(T1, T2, T3, T4, T5, T6, T7, T8, T9)]
        implicit object Unit extends UnitOrdering
        def apply[T](implicit ord: Ordering[T]): Ordering[T]
        def by[T, S](f: (T) => S)(implicit ord: Ordering[S]): Ordering[T]
            Given f, a function from T into S, creates an Ordering[T] 
            whose compare function is equivalent to:
        implicit def comparatorToOrdering[A](implicit cmp: Comparator[A]): Ordering[A]
        def fromLessThan[T](cmp: (T, T) => Boolean): Ordering[T]
            Construct an Ordering[T] given a function lt.
        implicit def ordered[A](implicit arg0: (A) => Comparable[A]): Ordering[A]
            This would conflict with all the nice implicit Orderings available, 
            but thanks to the magic of prioritized implicits via subclassing 
            we can make Ordered[A] => Ordering[A] only turn up if nothing else works.

        
        
trait scala.math.Numeric[T] extends Ordering[T]
    For new class,T, use T:Numeric and define 
    implicit val x = or implicit def x = or implicit object X extends Numeric[T]
    then implement its abstract methods 
    New class T can be used for anyplace where Numeric is required 
    Once Numeric instance is available Numeric.Ops methods are available 
    Note Numeric extends from Orering, hence Ordering.Ops are also available 
    
    //Example 
    def meth1[T : Numeric, C[X]  <: Seq[X]  ](x:C[T]):T = {   //on x we can use any Seq method and on inside value, can use +,-,* < etc (not / and %)
           val num = implicitly[Numeric[T]]
           import num._
           xs.sum.toDouble / xs.size    //can use Any Seq methods   
       }
    //Abstract Value Members
        abstract def compare(x: T, y: T): Int
            Returns an integer whose sign communicates how x compares to y.
        abstract def fromInt(x: Int): T
        abstract def minus(x: T, y: T): T
        abstract def negate(x: T): T
        abstract def plus(x: T, y: T): T
        abstract def times(x: T, y: T): T
        abstract def toDouble(x: T): Double
        abstract def toFloat(x: T): Float
        abstract def toInt(x: T): Int
        abstract def toLong(x: T): Long
    //Concrete Value Members
        def abs(x: T): T
        def equiv(x: T, y: T): Boolean
            Return true if x == y in the ordering.
        def gt(x: T, y: T): Boolean
            Return true if x > y in the ordering.
        def gteq(x: T, y: T): Boolean
            Return true if x >= y in the ordering.
        def lt(x: T, y: T): Boolean
            Return true if x < y in the ordering.
        def lteq(x: T, y: T): Boolean
            Return true if x <= y in the ordering.
        def max(x: T, y: T): T
            Return x if x >= y, otherwise y.
        def min(x: T, y: T): T
            Return x if x <= y, otherwise y.
        implicit def mkNumericOps(lhs: T): Ops
        implicit def mkOrderingOps(lhs: T): Numeric.Ops
            This implicit method augments T with the comparison operators defined in scala.math.Ordering.Ops.
        def on[U](f: (U) => T): Ordering[U]
            Given f, a function from U into T, creates an Ordering[U] whose compare function is equivalent to:
        def one: T
            def reverse: Ordering[T]
        Return the opposite ordering of this one.
            def signum(x: T): Int
        def tryCompare(x: T, y: T): Some[Int]
            Returns whether a comparison between x and y is defined, and if so the result of compare(x, y).
        def zero: T 


    
    
trait scala.math.Integral[T] extends Numeric[T]
    For new class,T, use T:Integral and define 
    implicit val x = or implicit def x = or implicit object X extends Integral[T]
    then implement its abstract methods 
    New class T can be used for anyplace where Integral is required 
    Once Integral instance is available IntegralOps methods are available 
    Note Integral extends from Orering and Numeric, hence Ordering.Ops and Numeric.Ops are also available 
    //Abstract Value Members
        abstract def compare(x: T, y: T): Int
            Returns an integer whose sign communicates how x compares to y.
        abstract def fromInt(x: Int): T
        abstract def minus(x: T, y: T): T
        abstract def negate(x: T): T
        abstract def plus(x: T, y: T): T
        abstract def quot(x: T, y: T): T
        abstract def rem(x: T, y: T): T
        abstract def times(x: T, y: T): T
        abstract def toDouble(x: T): Double
        abstract def toFloat(x: T): Float
        abstract def toInt(x: T): Int
        abstract def toLong(x: T): Long
    //Concrete Value Members
        def abs(x: T): T
        def equiv(x: T, y: T): Boolean
            Return true if x == y in the ordering.
        def gt(x: T, y: T): Boolean
            Return true if x > y in the ordering.
        def gteq(x: T, y: T): Boolean
            Return true if x >= y in the ordering.
        def lt(x: T, y: T): Boolean
            Return true if x < y in the ordering.
        def lteq(x: T, y: T): Boolean
            Return true if x <= y in the ordering.
        def max(x: T, y: T): T
            Return x if x >= y, otherwise y.
        def min(x: T, y: T): T
            Return x if x <= y, otherwise y.
        implicit def mkNumericOps(lhs: T): IntegralOps
        implicit def mkOrderingOps(lhs: T): Integral.Ops
            This implicit method augments T with the comparison operators defined in scala.math.Ordering.Ops.
        def on[U](f: (U) => T): Ordering[U]
            Given f, a function from U into T, creates an Ordering[U] whose compare function is equivalent to:
        def one: T
        def reverse: Ordering[T]
            Return the opposite ordering of this one.
        def signum(x: T): Int
        def tryCompare(x: T, y: T): Some[Int]
            Returns whether a comparison between x and y is defined, and if so the result of compare(x, y).
        def zero: T 


trait scala.math.Fractional[T] extends Numeric[T]
    For new class,T, use T:Fractional and define 
    implicit val x = or implicit def x = or implicit object X extends Fractional[T]
    then implement it s abstract methods 
    New class T can be used for anyplace where Fractional is required 
    Once Fractional instance is available FractionalOps methods are available 
    Note Fractional extends from Orering and Numeric, hence Ordering.Ops and Numeric.Ops are also available 
    //Abstract Value Members
        abstract def compare(x: T, y: T): Int
            Returns an integer whose sign communicates how x compares to y.
        abstract def div(x: T, y: T): T
        abstract def fromInt(x: Int): T
        abstract def minus(x: T, y: T): T
        abstract def negate(x: T): T
        abstract def plus(x: T, y: T): T
        abstract def times(x: T, y: T): T
        abstract def toDouble(x: T): Double
        abstract def toFloat(x: T): Float
        abstract def toInt(x: T): Int
        abstract def toLong(x: T): Long
    //Concrete Value Members
        def abs(x: T): T
        def equiv(x: T, y: T): Boolean
            Return true if x == y in the ordering.
        def gt(x: T, y: T): Boolean
            Return true if x > y in the ordering.
        def gteq(x: T, y: T): Boolean
            Return true if x >= y in the ordering.
        def lt(x: T, y: T): Boolean
            Return true if x < y in the ordering.
        def lteq(x: T, y: T): Boolean
            Return true if x <= y in the ordering.
        def max(x: T, y: T): T
            Return x if x >= y, otherwise y.
        def min(x: T, y: T): T
            Return x if x <= y, otherwise y.
        implicit def mkNumericOps(lhs: T): FractionalOps
        implicit def mkOrderingOps(lhs: T): Fractional.Ops
            This implicit method augments T with the comparison operators defined in scala.math.Ordering.Ops.
        def on[U](f: (U) => T): Ordering[U]
            Given f, a function from U into T, creates an Ordering[U] whose compare function is equivalent to:
        def one: T
        def reverse: Ordering[T]
            Return the opposite ordering of this one.
        def signum(x: T): Int
        def tryCompare(x: T, y: T): Some[Int]
            Returns whether a comparison between x and y is defined, and if so the result of compare(x, y).
        def zero: T 
















///*** Subtype relation in inhertitances 
//Note subtype relation preserves if same Parametric type 
//eg T is used in inheritance definition

class A[T]  //defined class A
class B[T] extends A[T] //defined class B

def f[T](x: A[T]) = ???  //f: [T](x: A[T])Nothing

val b = new B[Int]  //b: B[Int] = B@51fc862e

f(b)  //B[Int] can be used for A[Int] - wide auto conversion //scala.NotImplementedError: an implementation is missing

//Example
trait MyList[E]
trait PayloadList[E,P] extends MyList[E] //same E

//The following parameterizations of PayloadList are subtypes of MyList[String]:
PayloadList[String,String]
PayloadList[String,Integer]
PayloadList[String,Exception]
	
	
///*** Variance
//Type Inference - Picks the max subtype which intersects all types

trait A2
trait A3 extends A2

def f[T](x:T, y:T):T = x  //f: [T](x: T, y: T)T
f(new A2{}, new A3{})  // picks A2 , res14: A2 = $anon$2@191a0351

//Container class C[T] can be always created with subtype, A <: T
//and any overridden method/val of T can be dynamically bound
//Note below only A's method names are visible

trait A
class B extends A
class C extends A
val l:List[A] = List( new B, new C, new B)
val l:Seq[A] = List( new B, new C, new B)
val l:Array[A] = Array( new B, new C, new B)
//variance case 
val l:Array[A] = Array[B]( new B, new B)  //Error as Array is invariant
val l:List[A] = List[B]( new B, new B)  //OK as List is covariant


//Variances  is for the case 
//how C[T] and C[T'] are related if T is related to T' 
// T , only same type can be used, mutable
// +T, derived type can be used , immutable , this class produces T (ie returns)
// -T , super type can be used , immutable, this class consumes T (ie arg)

//if generic type only acts as parameter: using contravariance. 
//if generic type only acts as retrun value: using covariance. 
//as in Function1[-T,+R]

//Examples
val l3: List[Any] = List[Int](1,2,3)   //ok
val a: Array[Any] = Array[Int](1, 2, 3)  //NOK as Array is mutable, hence Invariant (in java- OK)
val a:Array[Any] = Array(1,2,3)  //Ok as number is Any type, a: Array[Any] = Array(1, 2, 3) 




"""
Note  If C[T] and  C'[T] are always related if C' <: C or vice versa
(ie List[Int] is subtype of Seq[Int] as List <: Seq) 

Variance is only applicable of container/parametric class/trait (C[T]) 
and defines rules for C[T] relational with C[T'] 
ie what can be passed in method taking C[T] or any assignments of C[T] by C[T']


Array[T]        Invariant   Used when elements in the container are mutable.
                            Example: Can only pass Array[String] to a method expecting  only Array[String].

Seq[+A]         Covariant   Used when elements in the container are immutable. 
                            if B <: A, then C[B] <: C[A] and C[B] can be passed to any method expecting  C[A]
                            Example: Can pass a Seq[String] to a method expected Seq[Any].
							We can pass Seq[Any] as well as  List[String], List[Any] as List <:Seq

Foo[-A]     Contra variant Contra-variance is opposite of covariance 
                           if B >: A, then C[B] <: C[A] and C[B] can be passed to any method expecting  C[A]
                           Example: Can pass a Foo[Any] to a method expected Foo[String].

1. because of List[+T] , List is immutable

"""

//Variances explained
class A[+T] 

val a:A[Any] = new A[AnyVal]  //  OK a: A[Any] = A@46612f2d

val a:A[AnyVal] = new A[Any]   //NOK
 
class A1[-T] 
val a:A1[AnyVal] = new A1[Any]  //OK
val a:A1[Any] = new A1[AnyVal]  //NOK


///Meaning of -A, +A 
//Note that following is anyway possible 
//( ie putting derived class in Argument and return result of derived class then assigning to super class)
//called widening 

class A; class B extends A; class C extends B

def f(x:B):B = x  			//f: (x: B)B

val a:A = f(new C)      	//a: A = C@532b3afd  , 

"""
Function1[-T,+R] means that a function that takes super classes of T(arg) 
and returns subclass of R(return) is subclass of Function1[-T,+R]
"""

class A
class B extends A
class C extends B

val printOriginal: B => B = { b => new B } 
val printNew: A => C = { a => new C } // takes A, means uses A's functionality and return C
val printBad: C => A = { c => new A }

def needsB(f: B => B, b: B):B = f(b)

needsB(printOriginal, new B) //OK
needsB(printNew, new B)  	//ALSO OK
needsB(printBad, new B)   	//NOK

//Note if used with private[this] and protected[this], then variances do not matter 
//also if used in arg of a fn which is used as arg of any method 
//But matters when used as another type C'[T] which is used as arg 
trait TraversableLike[+A, +Repr] 
{
  self =>
      private[this] type Self = Repr
      def repr: Repr = this.asInstanceOf[Repr]
      protected[this] def toCollection(repr: Repr): Traversable[A] 
      def foreach[U](f: A => U): Unit
      def ++[B >: A, That](that: collection.GenTraversableOnce[B])(implicit bf: collection.generic.CanBuildFrom[Repr, B, That]): That
  }

//Covariance and contravariance are like the signs of numbers in arithmetic, 
+(+a) = +a
-(+a) = -a
+(-a) = -a
-(-a) = +a

//in terms of variance 
trait +[+A] { def make(): A } // Produces an A, return type is OK 
trait -[-A] { def break(a: A) } // Consumes an A, arg type is OK 

// Produces an A after one indirection: x.makeMake().make()
  trait ++[+A] { def makeMake(): +[A] }
  +[+[A]] = +[A]
  
// Consumes an A through one indirection: x.breakMake(new +[A] { override def make() = a })
  trait -+[-A] { def breakMake(m: +[A]) }
  -[+[A]] = -[A]
  
// Consumes an A after one indirection: x.makeBreak().break(a)
  trait +-[-A] { def makeBreak(): -[A] }
  +[-[A]] = -[A]

// Produces an A through one indirection
// Slightly harder to see than the others
// x.breakBreak(new -[A] { override def break(a: A) = {
//   you have access to an A here, so it's like it produced an A for you
// }})
  trait --[+A] { def breakBreak(b: -[A]) }
  -[-[A]] = +[A]

//Example , given trait Iterator[+A] 
def method(iter: Iterator[A])
//the method parameter as a whole is in a contravariant position, 
//and the A is in a covariant position inside the Iterator, 
//but -[+[A]] = -[A], 
//so A is actually in a contravariant position inside class signature 

//Given Comparator[-A]
def method(comp: Comparator[A])
//the whole method parameter is in a contravariant position, 
//and A is in a contravariant position inside the Comparator, 
//So -[-[A]] = +[A] 
// A is really in a covariant position. 



///Scala and Java variances

"""
Scala 	Java at call site 
+T 		? extends T 
-T 		? super T 
T 		T 

In Java , Array is co-variant - an array of B is a subtype of an array of A, if B <: A
Hence in java ,String[] is subtype Object[]

In Scala, Array is Invariant , but can be made co-variant at call site
val l:Array[ Number] = Array[Integer](1,3,5) //Error Array is invariant
val l:Array[_ <: Number] = Array[Integer](1,3,5)


In Java List is invariant, in Scala, List is co-variant
But, at call site, Java List can be made co-variant eg 
List<? extends Integer> intList = new ArrayList<Integer>();
List<? extends Number>  numList = intList;  // OK. List<? extends Integer> is a subtype of List<? extends Number>

"""

//Scala and Java inheritances hierarchy for invariant 
//Using  java wildcard ? and scala existential _ 

"""
In Java, Number<: Integer 

List<?>
	List<? extends Number>
		List<? extends Integer> 	//sibling with List<Number>
			List<Integer>	
		List<Number>	

List<?>
	List<? super Integer> 		
		List<? super Number>       //sibling with List<Integer>
			List<Number>
		List<Integer>

In Scala

Array[_]
	Array[_ <: Number]
		Array[_ <: Integer] 
		     Array[Integer]	
		Array[Number]	

Array[_]
	Array[_ >: Integer] 		
		Array[_ >: Number]
			Array[Number]
		Array[Integer]


"""

val l:Array[Integer] = Array[Integer](1,2)
val l1:Array[_ <: Integer] = l
val l2:Array[_ <: Number] = l
val l3:Array[_] = l
val l4:Array[_ <: Number] = l1
val l4:Array[_ <: Number] = Array[Number](null,null)

val l = Array[Number](null,null)
val l1:Array[_ >: Number] = l
val l2:Array[_ >: Integer] = l
val l3:Array[_] = l
val l4:Array[_ >: Integer] = l1
val l4:Array[_ >: Integer] = Array[Integer](1,2)



"""
Given Function1[-T,+R], 
    ie arg is contravariant and return is covariant 
val name:T , creates   def name:T  ie returns T
    means T has to be covariant or Invariant
var name:T, creates def name:T and def name_=(x:T), ie both arg and return type
    means T can be only Invariant

1. one side effect of +T is that, T can only be used as val (not var) inside class(hence immutable)
(not practical because val with generics can not be initialized)
and in return type of function(not argument type) as arguments of functions are contra-variant ,
hence use like below to have a arguments of T when T is covariant
def meth[U >: T](x:U):T
(Note U <: T is not possible for +T)

2. one side effect of -T is that, T can not used as return type of method(but can be used as argument type)
as return type of method is covariant . 
Hence can not be used for val, var declaration(as get method returns T)
class A[-T]( val x:T) //Not OK as get method
class A[-T]( x:T) //OK, no get method
To use as return type , use 
def meth[U <: T](x:T):U
(Note U >: T is not possible for -T)

"""


//covariant type T occurs in contra-variant position - Error
class A[T] {
      var x:T = _  //OK
      }
 
class A[+T] {
      var x:T = _  //NOK
      }
class A[+T]{
      def f[B >:T](x:B) = ???   //OK
      }
class A1[+T]{    
      def f[B>:T](x:B):B = x  //OK 
     }
class A[-T]{
       def f[B<:T](x:B):B = x //OK 
      }
      
class A[-T<: AnyVal]{  //OK 
    }
    
class A[+T <: AnyRef]{
    val x:T = null.asInstanceOf[T]  //OK
    }
(new A[String]).x 

class A[+T] {
      def f(x:T):Int = 2   //error: covariant type T occurs in contravariant position in t
      }

class A[-T]{
      def f(x:Int):T = ???  //error: contravariant type T occurs in covariant position in t
      }

class A[-T]{
        def f[B>:T](x:B):B = x //error: contravariant type T occurs in covariant position in type  >: T of type B
  }
class A[+T]{
     def f[B<:T](x:B):B = x //error: covariant type T occurs in contravariant position in type  <: T of type B
   }
class A[-T]{
    def f[B<:T](x:T):B = x //error: type mismatch; found   : x.type (with underlying type T),  required: B
}

// Covariant return type
//Covariant return, means that when one overrides a method, 
//the return type of the overriding method is allowed to be a subtype of the overridden method's return type.
 class A[T] { def m(x:T):Traversable[T] = ??? }
class B[T] extends A[T] { override def m(x:T): Traversable[T] = ???}
class B[T] extends A[T] { override def m(x:T): List[T] = ???}  //List <: Traversable, hence Ok









///*** Bounds 
//is A subtype or supertype of B and what methods can be used on A

"""

                                 Name                     Description
A <: B                           Upper bound              A must be a subtype of B. , java- A extends B
A >: B                           Lower bound              A must be a supertype of B. , java- none
A >: Lower  <: Upper             Both Bound               Lower must come first, Java - none
A <% B                           View bound 		      A can be converted to B via implicit method or class                                
A : M                            Context Bound            A can be converted to M[A] via implicit class/object. Applicable for parametric/container type M
A >: Lower  <: Upper : M         Both Bound + context     context bound comes last

Eg:
def f[T >: Int <: AnyVal  : Numeric](x:List[T]) = x :+ Nil

Note traits cannot have type parameters with context bounds nor view bounds 

Note object can not have Type parameter


Multiple Bounds
A <: B with C with D     - B,C,D are traits or class, order does not matter(unlike java -class must be first)

Structural type
A <: AnyRef with B {def method }
OR
A <: A1{def method: Unit}     means Derived from A1 with a new method 'method'

Type can refere other type 
class A[U,T<:U]

Existential type C[_]  -  C[T] forSome { type T; } means 'any C[X]'
C[X] <: Seq[X]      X is just placeholder , but must be given. Note C[_] <: Seq [_] is wrong..




Existential type with bound
def f(x:List[_]) = x.length            //OK
def f(x:List[_ <: AnyVal]) = x.length  //OK
def f(x:List[_ : Numeric]) = x.length   //Not ok as _ does not take context bound
def f[T >: Int <: AnyVal  : Numeric, C[_ >: Int <: AnyVal] ](x:C[T]) = ???
def f[T >: Int <: AnyVal  : Numeric, C[X] <: Seq[X] ](x:C[T]) = x.size

Type Constraints
    A =:= B // A must be equal to B
    A <:< B // A must be a subtype of B
    A <%< B // A must be viewable as B
	
	

"""
//Scala and Java bounds

"""
Scala 		Java 
A<:B 		A extends B 
A>:B 		None
A 			A 

The type signature A <: B says that A must be a subtype of B. 
In Java, this would be expressed as A extends B in a type declaration. 

This is different from instantiating a type at a call site, 
where the syntax ? extends B is used in Java, indicating the variance behaviour.

The type signature B >: A says that B must be a supertype of A. 
There is no analog in Java; B super A is not supported
"""


// Class - Type bound Explained
class A2[T <: AnyVal] 
val b = new A2[Int]  //OK
val b = new A2[Any]   //NOK

class A3[T >: AnyVal] 
val b = new A2[Int]   //NOK
val b = new A3[Any]   //OK




///abstract Type – lower bound and upper bound
trait TN { type T >:AnyRef }  //T must be super type of AnyRef
class B extends TN { type T = Any }   //Ok
class B extends TN { type T = Int }    //NOK

trait TN { type T <:AnyRef }  //T must be subtype of AnyRef

class B extends TN { type T = Any }   //NOK
class B extends TN { type T = List[_] } //OK


trait TS2[ T >: List[T] <:Any ]  // Must be super type of List and subtype Any

class B extends TS2[AnyRef] {}  //OK
class B extends TS2[AnyVal] {}   //NOK



//Example multiple context bounds
import scala.reflect.ClassTag

class MyClass[T : Ordered : ClassTag](size: Int) {
  val arr: Array[T] = new Array[T](size)
}

object MyClass {
  final val maxSize: Int = 40
  def apply[T : Ordered : ClassTag]() = new MyClass[T](maxSize)
}

val clz = MyClass[Int]()

//Example of complex type checking
//Restricting onle two types 
object Types {
  trait inv[-A] {}
  type Or[A, B] = {
    type check[X] = (inv[A] with inv[B]) <:< inv[X]
  }
}

import Types._
case class Vector[U : (Double Or Int)#check](list: List[U]) {
  def first(): U = list.head
}

println(Vector(List(1.0, 2.0, 3.0)).first()) // prints a Double
println(Vector(List(1, 2, 3)).first()) // prints an Int
//Vector(List("String")).first() // won't compile

//Example of type Lambda and type project by # 
trait HList{
  type Hd  
}
 
class IntList extends HList {
  type Hd = Int
}
implicitly[ Int =:= IntList#Hd ]   // # is type projection , 

val x: IntList#Hd = 10
 
//Type Lambda is often regarded as Type-Level Lambda. 
//ie accessing inner type without creating type
type L[A] = Map[Int,A]
val x:L[String] = Map(1->"Ok") //x: L[String] = Map(1 -> Ok)
implicitly[ L[String] =:= Map[Int,String] ] //OK

//or Directly accessing by ({type L[X] = Map[Int,X]})#L
val x:({type L[X] = Map[Int,X]})#L[String]  = Map(1->"Ok") //x: Map[Int,String] = Map(1 -> Ok)



///How to alias  parameter type 's type 
trait Item[K] {
  type Key = K
  var x:Key = _
}

def get[T <: Item[_]](k: T#Key) = k


class IntItem extends Item[Int]
class StringItem extends Item[String]

scala> get[IntItem](0)  //eventhough both are It, but Trait creates nested type path 
<console>:67: error: type mismatch;
 found   : Int(0)
 required: _$1
              get[IntItem](0)
                           ^

scala> get[IntItem](0.asInstanceOf[IntItem#Key])
<console>:67: error: type mismatch;
 found   : Int
 required: _$1
              get[IntItem](0.asInstanceOf[IntItem#Key])
                                         ^

//Solution is to bound type						   
trait Item[K] { 
  type Key >: K <: K 
  var x:Key = _
  }

def get[T <: Item[_]](k: T#Key) = k


class IntItem extends Item[Int]
class StringItem extends Item[String]

get[IntItem](0) //IntItem#Key = 0


















   
   
   
   
   
   
 
   
   
   
   




///*** Duration
import scala.concurrent.duration._
//usage patterns 
    1.Conversion to different time units (toNanos, toMicros, toMillis, toSeconds, toMinutes, toHours, toDays and toUnit(unit: TimeUnit)).
    2.Comparison of durations (<, <=, > and >=).
    3.Arithmetic operations (+, -, *, / and unary_-).
    4.Minimum and maximum between this duration and the one supplied in the argument (min, max).
    5.Check if the duration is finite (isFinite).

//Duration can be instantiated in the following ways:
    1.Implicitly from types Int and Long. For example val d = 100 millis.
    2.By passing a Long length and a java.util.concurrent.TimeUnit. For example val d = Duration(100, MILLISECONDS).
    3.By parsing a string that represent a time period. For example val d = Duration("120 ms").

//Example 
import scala.concurrent.duration._
import java.util.concurrent.TimeUnit._
 
// instantiation
val duration = Duration(100, MILLISECONDS) // from Long and TimeUnit
val d2 = Duration(100, "millis") // from Long and String
val d3 = 100 millis // implicitly from Long, Int or Double
val d4 = Duration("1.2 ms") // from String

duration.toNanos
duration < 1.second
duration <= Duration.Inf

val d = Duration("1.2 µs")
val Duration(length, unit) = 5 millis
val d2 = d * 2.5
val d3 = d2 + 1.millisecond

//Reference 
object Duration extends Serializable 
    implicit object DurationIsOrdered extends Ordering[Duration]
        The natural ordering of durations matches the natural ordering for Double, including non-finite values.
    val Inf: Infinite
        Infinite duration: greater than any other (apart from Undefined) and not equal to any other but itself.
    val MinusInf: Infinite
        Infinite duration: less than any other and not equal to any other but itself.
    val Undefined: Infinite
        The Undefined value corresponds closely to Double.NaN:
    val Zero: FiniteDuration
        Preconstructed value of 0.days.
    def apply(s: String): Duration
        Parse String into Duration.
    def apply(length: Long, unit: String): FiniteDuration
        Construct a finite duration from the given length and time unit, where the latter is looked up in a list of string representation.
    def apply(length: Long, unit: TimeUnit): FiniteDuration
        Construct a finite duration from the given length and time unit.
    def apply(length: Double, unit: TimeUnit): Duration
        Construct a Duration from the given length and unit.
    def create(s: String): Duration
        Parse String into Duration.
    def create(length: Long, unit: String): FiniteDuration
        Construct a finite duration from the given length and time unit, where the latter is looked up in a list of string representation.
    def create(length: Double, unit: TimeUnit): Duration
        Construct a Duration from the given length and unit.
    def create(length: Long, unit: TimeUnit): FiniteDuration
        Construct a finite duration from the given length and time unit.
    def fromNanos(nanos: Long): FiniteDuration
        Construct a finite duration from the given number of nanoseconds.
    def fromNanos(nanos: Double): Duration
        Construct a possibly infinite or undefined Duration from the given number of nanoseconds.
    def unapply(d: Duration): Option[(Long, TimeUnit)]
        Extract length and time unit out of a duration, if it is finite.
    def unapply(s: String): Option[(Long, TimeUnit)]
        Extract length and time unit out of a string, where the format must match the description for apply(String)
        

///*** Quick Thread 
val hello = new Thread( new Runnable {
  def run() {
    Thread.sleep(2000)	
	println("hello world " + Thread.currentThread)
  }
})

hello.start
hello.join  

//volatile for volatile keyword as in java
// Java Memory Model ensures   that all threads see a consistent value for the variable 
//even without use of 'synchronized' block . This is finer controlled
class Person(@volatile var name: String) {
  def set(changedName: String) {
    name = changedName
  }
}

//AtomicReference , getAndSet(V newValue), 
//compareAndSet(V expect, V update) ,  set(V newValue)  

import java.util.concurrent.atomic.AtomicReference

class Person(val name: AtomicReference[String]) {
  def set(changedName: String) {
    name.set(changedName)
  }
}

//Synchronized 
object Foo {
 private var ctr = 0L
 def getCtr = this.synchronized {
   ctr = ctr + 1
   ctr
 }
 def bar = {
    val currCtr = getCtr
    // do something with currCtr
  }
}




///Scala - Concurrent Map

//Concurrent Map - All operations are atomic, hence can be accessed by multiple threads
scala> val s = scala.collection.concurrent.TrieMap[Int,Int]()
s: scala.collection.concurrent.TrieMap[Int,Int] = TrieMap()

//All Map operations are possible(but atomic) and  below new methods
m.putIfAbsent(k, v) 	
    Adds key/value binding k -> v unless k is already defined in m 
m.remove (k, v) 		
    Removes entry for k if it is currently mapped to v. 
m.replace (k, old, new) 
    Replaces value associated with key k to new, if it was previously bound to old. 
m.replace (k, v) 		
    Replaces value associated with key k to v, if it was previously bound to some value. 

//Note below operations of Map are atomic
def  getOrElse(key: K, default: => V): V 
    Returns the value associated with a key, or a default value 
    if the key is not contained in the map. 
def  getOrElseUpdate(key: K, op: => V): V 
    If given key is already in this map, returns associated value.
    Otherwise, computes value from given expression op, 
    stores with key in map and returns that value.


  
//OR USE java.util.concurrent.ConcurrentHashMap
scala> val d =  new java.util.concurrent.ConcurrentHashMap[Int,String]()
d: java.util.concurrent.ConcurrentHashMap[Int,String] = {}

d.put(1, "OK")
d.get(1)
Option(d.get(1))
Option(d.get(0))
d containsKey 1
d containsKey 0
 


        
///*** Concurrent Programming - Future 
//By default the ExecutionContext.global sets the parallelism level 
//of its underlying fork-join pool to the amount of available processors (Runtime.availableProcessors).



//*Reference -Future is monad, and have map, filter etc method which takes underlyung T
trait Future[+T] extends Awaitable[T] 
    def isCompleted: Boolean
        Returns whether the future has already been completed with a value or an exception.
    def onComplete[U](f: (Try[T]) => U)(implicit executor: ExecutionContext): Unit
        When this future is completed, either through an exception, or a value, apply the provided function.
    def value: Option[Try[T]]
        The value of this Future.
    //Below two methods are not to be called directlt, use Await object 
    def ready(atMost: Duration)(implicit permit: CanAwait): Future.this.type
        Await the "completed" state of this Awaitable.
    def result(atMost: Duration)(implicit permit: CanAwait): T
        Await and return the result (of type T) of this Awaitable.
        
    def andThen[U](pf: PartialFunction[Try[T], U])(implicit executor: ExecutionContext): Future[T]
        Applies the side-effecting function to the result of this future, 
        and returns a new future with the result of this future.
    def collect[S](pf: PartialFunction[T, S])(implicit executor: ExecutionContext): Future[S]
        Creates a new future by mapping the value of the current future, 
        if the given partial function is defined at that value.
    def failed: Future[Throwable]
        Returns a failed projection of this future.
    def fallbackTo[U >: T](that: Future[U]): Future[U]
        Creates a new future which holds the result of this future 
        if it was completed successfully, 
        or, if not, the result of the that future if that is completed successfully.
    def filter(p: (T) => Boolean)(implicit executor: ExecutionContext): Future[T]
        Creates a new future by filtering the value of the current future 
        with a predicate.
    def flatMap[S](f: (T) => Future[S])(implicit executor: ExecutionContext): Future[S]
        Creates a new future by applying a function to the successful result 
        of this future, and returns the result of the function as the new future.
    def foreach[U](f: (T) => U)(implicit executor: ExecutionContext): Unit
        Asynchronously processes the value in the future once the value 
        becomes available.
    def map[S](f: (T) => S)(implicit executor: ExecutionContext): Future[S]
        Creates a new future by applying a function to the successful 
        result of this future.
    def mapTo[S](implicit tag: ClassTag[S]): Future[S]
        Creates a new Future[S] which is completed with this Future's result 
        if that conforms to S's erased type or a ClassCastException otherwise.
    def onFailure[U](pf: PartialFunction[Throwable, U])(implicit executor: ExecutionContext): Unit
        When this future is completed with a failure (i.e., with a throwable), 
        apply the provided callback to the throwable.
    def onSuccess[U](pf: PartialFunction[T, U])(implicit executor: ExecutionContext): Unit
        When this future is completed successfully (i.e., with a value), 
        apply the provided partial function to the value if the partial function is defined at that value.
    def recover[U >: T](pf: PartialFunction[Throwable, U])(implicit executor: ExecutionContext): Future[U]
        Creates a new future that will handle any matching throwable 
        that this future might contain.
    def recoverWith[U >: T](pf: PartialFunction[Throwable, Future[U]])(implicit executor: ExecutionContext): Future[U]
        Creates a new future that will handle any matching throwable 
        that this future might contain by assigning it a value of another future.
    def transform[S](s: (T) => S, f: (Throwable) => Throwable)(implicit executor: ExecutionContext): Future[S]
        Creates a new future by applying the 's' function to the successful result 
        of this future, or the 'f' function to the failed result.
    final def withFilter(p: (T) => Boolean)(implicit executor: ExecutionContext): Future[T]
        Used by for-comprehensions.
    def zip[U](that: Future[U]): Future[(T, U)]
        Zips the values of this and that future, and creates a new future 
        holding the tuple of their results.
object Await 
    def ready[T](awaitable: Awaitable[T], atMost: Duration): awaitable.type
        Await the "completed" state of an Awaitable.
    def result[T](awaitable: Awaitable[T], atMost: Duration): T
        Await and return the result (of type T) of an Awaitable.
        
object Future 
    def apply[T](body: => T)(implicit executor: ExecutionContext): Future[T]
        Starts an asynchronous computation and returns a Future object 
        with the result of that computation.
    def successful[T](result: T): Future[T]
        Creates an already completed Future with the specified result.
    def failed[T](exception: Throwable): Future[T]
        Creates an already completed Future with the specified exception.
    def find[T](futures: TraversableOnce[Future[T]])(p: (T) => Boolean)(implicit executor: ExecutionContext): Future[Option[T]]
        Returns a Future that will hold the optional result of the first Future 
        with a result that matches the predicate.
    def firstCompletedOf[T](futures: TraversableOnce[Future[T]])(implicit executor: ExecutionContext): Future[T]
        Returns a new Future to the result of the first future in the list 
        that is completed.
    def fromTry[T](result: Try[T]): Future[T]
        Creates an already completed Future with the specified result 
        or exception.
        
    def fold[T, R](futures: TraversableOnce[Future[T]])(zero: R)(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R]
        A non-blocking fold over the specified futures, 
        with the start value of the given zero.

    def reduce[T, R >: T](futures: TraversableOnce[Future[T]])(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R]
        Initiates a fold over the supplied futures 
        where the fold-zero is the result value of the Future 
        that is  completed first.
        
    def sequence[A, M[X] <: TraversableOnce[X]](in: M[Future[A]])(implicit cbf: CanBuildFrom[M[Future[A]], A, M[A]], executor: ExecutionContext): Future[M[A]]
        Simple version of Future.traverse.
        eg Conversion from List[Future[T]] to Future[List[T]]
    def traverse[A, B, M[X] <: TraversableOnce[X]](in: M[A])(fn: (A) => Future[B])(implicit cbf: CanBuildFrom[M[A], B, M[B]], executor: ExecutionContext): Future[M[B]]
        Transforms a TraversableOnce[A] into a Future[TraversableOnce[B]] 
        using the provided function A => Future[B].
        eg Convert List[A] , with A => Future[B] to Future[List[B]]
	
        
//A custom ExecutionContext may be appropriate to execute code 
//which blocks on IO or performs long-running computations. 
//ExecutionContext.fromExecutorService and ExecutionContext.fromExecutor are good ways to create a custom ExecutionContext.

import java.util.concurrent.Executors
import scala.concurrent.ExecutionContext
implicit val ec = ExecutionContext.fromExecutorService(Executors.newSingleThreadExecutor()) //or newFixedThreadPool(int nThreads) 
//https://docs.oracle.com/javase/8/docs/api/java/util/concurrent/Executors.html

//Future Example 
import scala.concurrent.{Future, Await}
//many Future functions take 'implicit executor: ExecutionContext)', below provides default implecits or create your own implicit ExecutionContext
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration


val future: Future[String] = Future{ 
        Thread.sleep(10)
        " Result "
    }  
//Future is monad : all get executed only if name is completed 
val upper = future map { _.trim } filter { _.length != 0 } map { _.toUpperCase }
val result = Await.result(upper, Duration.Inf)
//OR 
upper onSuccess {
  case msg => println(msg)
}

//Or 
future foreach println //blocking

//To get value 
//use Await
import scala.concurrent.duration._
val v = Await.result(future, Duration.Zero)   //It can fail,  for infinitely, Duration.Inf and Duration.MinusInf
//v: String = HelloWorld

//or convert to Option
future.value  //gives Option[Try[U]] 
future.value.get.getOrElse(" ") //for Option[Try[U]]

val res = future.value match { case Some(Success(x)) => x }


//Clubbing multiple futures- Use flatMap , for, map etc 
import scala.util._

val future:Future[Int] = for {a <- Future{10 / 2} 
                              b <- Future{ 5+1} 	   //<- unwraps inside, flatMap
                              c <- Future{a - 1} if c > 3  
							  } yield b * c 	         //yield again wraps to Future or do println 

							  
							  
				 
//Registering callbacks , return value of onComplete is Unit
//def  onComplete[U](f: (Try[T]) => U)(implicit executor: ExecutionContext): Unit
future onComplete {
  case Success(result) => println(result)
  case Failure(failure) => println(failure)
}

//With onSucess and onFailure, Return value is Unit, hence can be used only like foreach
//def  onSuccess[U](pf: PartialFunction[T, U])(implicit executor: ExecutionContext): Unit
future onSuccess {
    case x: String => println(x)
}

//def  onFailure[U](pf: PartialFunction[Throwable, U])(implicit executor: ExecutionContext): Unit
future onFailure {  
  case e: Exception => println(e)
}

"""
1.In the event that multiple callbacks are registered on the future, 
the order in which they are executed is not defined. 
In fact, the callbacks may be executed concurrently with one another. 

2.In the event that some of the callbacks throw an exception, 
the other callbacks are executed regardless.

3.In the event that some of the callbacks never complete (e.g. the callback contains an infinite loop),
 the other callbacks may not be executed at all. 
 In these cases, a potentially blocking callback must use the 'blocking' construct 

4.Once executed, the callbacks are removed from the future object, thus being eligible for GC.

"""
//blocking construct
//Used to designate a piece of code which potentially blocks, 
//allowing the current BlockContext to adjust the runtime's behavior. 
//Properly marking blocking code may improve performance or avoid deadlocks.

//Usage - download
import scala.concurrent.blocking

def get(url: String) = scala.io.Source.fromURL(url).getLines.toList.mkString

Future {
    blocking { get("http://www.example.com") }
} onComplete {
    case Success(html) => println("Result: " + html.length)
    case Failure(ex) => println(ex)
}


//Recovering failed one , Result is Future
//'recover' - recover's PartiatialFunction returns simple value
// 'recoverWith'  - recoverWith's PartiatialFunction returns another Future
//'fallbackTo'  - fallbackTo simply takes another future 

val f = Future { 1/0 } recover { case e:Exception => 25 }

val f = Future { 1/0 } recoverWith { case e:Exception => Future { 200} }

val f = Future { 1/0 }.fallbackTo(Future { 200} )



//def  andThen[U](pf: PartialFunction[Try[T], U]): Future[T] 
//Applies Partial function(with Success or Failure) to the result of this future
//and returns a new future with final result 
 
val allposts = collection.mutable.Set[String]()

Future {
  List("Hello", "world")  
} andThen {
  case Success(posts) => allposts ++= posts
} andThen {
  case Success(posts) =>  for (post <- allposts) println(post)
}


//Future is a monad, 
//can call map, filter , these result into another future
//note these function ignores Failure and only works with Success
//can call collect as well

val f = Future { -5 }
val g = f collect {
  case x if x < 0 => -x
}
val h = f collect {
  case x if x > 0 => x * 2
}
Await.result(g, Duration.Zero) // evaluates to 5
Await.result(h, Duration.Zero) // throw a NoSuchElementException

//Projections
//def  failed: Future[Throwable] 
//Returns a failed projection of this future. ie if only Future is failed, returns throwable

val f = Future {
  2 / 0
}
for (exc <- f.failed) println(exc)


//The following example does not print anything to the screen:
val f = Future {
  4 / 2
}
for (exc <- f.failed) println(exc)


// Parallel download
import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global //must for execution context
import scala.util._  //Success,Failure 
import scala.concurrent.duration._

def get(url: String) = scala.io.Source.fromURL(url, "ISO-8859-1").getLines.toList.mkString

// Retrieve URLs from somewhere
val urls = List(  "http://www.google.com",
                  "http://www.scala-lang.org/",
                  "http://jskdlsycds.com", //invalid url-1
                  "http://rediff.com",
                  "http://wowslskdleodd.com") //invalid url-2


// Download image (blocking operation)
val htmls: List[Future[Int]] = urls.map {
  url => Future {   
           println(Thread.currentThread.getName)
           blocking { get(url) }    
    }.map(_.size) //to get size of the string 
}
//Check , .result would rethrow exception, hence put inside Try block 
val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Zero)};res} } //List[scala.util.Try[Int]]
t1.collect{ case Success(n) => n }
List[Int] = List(12934, 8, 103168, 165, 0, 0, 190158)

//Use sequence(simpler version of traverse)
//def sequence[A, M[X] <: TraversableOnce[X]](in: M[Future[A]])(implicit cbf: CanBuildFrom[M[Future[A]], A, M[A]], executor: ExecutionContext): Future[M[A]] 
// to convert imagesFuts from List[Future[...]] to a Future[List[...]].
//But one exception would result into full failure , hence only wait for this 
//but iterate original htmls 
val fhtmls: Future[List[Int]] = Future.sequence(htmls)

//Or durectly using traverse
//def traverse[A, B, M[X] <: TraversableOnce[X]](in: M[A])(fn: (A) => Future[B])(implicit cbf: CanBuildFrom[M[A], B, M[B]], executor: ExecutionContext): Future[M[B]] 
//But one exception would result into full failure , hence only wait for this 
val fhtmls: Future[List[String]]  = Future.traverse(urls){url => Future { blocking { get(url) } } }


// Await.ready simply forces the current thread to wait 
//until the future that it is passed is completed
val  t = Try { Await.ready(fhtmls, 10.seconds) }  //packaging inside Try because of TimeOutException in any one  of them 

//iterate originals ones 
val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Zero)};res} } //List[scala.util.Try[Int]]



///To handle HTML file, use 
def scala.xml.XML.loadXML(source: InputSource, parser: SAXParser): Elem 
//Where parser is tagsoup parser 
libraryDependencies += "org.ccil.cowan.tagsoup" % "tagsoup" % "1.2.1"

//Creation of InputSource  
//myString is a decoded string 
val source  = new InputSource( new StringReader( myString ) )
//For providing encoding in file , use new InputStreamReader(new FileInputStream(new File("/path/to/xml/file.xml")), "UTF-8"));
val source  = new InputSource(new FileInputStream(new File("/path/to/xml/file.xml")))
//Input is a URL, it must be fully resolved (it may not be a relative URL).
val source = new org.xml.sax.InputSource("http://www.scala-lang.org") 

//check available charsetstring by 
import collection.JavaConversions._ 
java.nio.charset.Charset.availableCharsets.keys

//Example 
import org.xml.sax._ 
import java.io._ 
import java.net._ 


def get(url: String) = scala.io.Source.fromURL(url, "ISO-8859-1").getLines.toList.mkString

def downloadURLAndGetAllHref(base:String):Seq[String] = {
    val parserFactory = new org.ccil.cowan.tagsoup.jaxp.SAXFactoryImpl
    val parser = parserFactory.newSAXParser()
    val source = new InputSource( new StringReader( get(base) ) )
    val adapter = new scala.xml.parsing.NoBindingFactoryAdapter
    val xml = adapter.loadXML(source, parser)
    (xml \\ "a" ).map { n => n \@ "href"}.map{ url => if(url.startsWith("http")) url else (new URL(new URL(base),url)).toString}
}
//download 
import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global //must for execution context
import scala.util._  //Success,Failure 
import scala.concurrent.duration._

// Retrieve URLs from somewhere
val urls = List(  "http://www.google.com",
                  "http://www.scala-lang.org/",
                  "http://jskdlsycds.com", //invalid url-1
                  "http://rediff.com",
                  "http://wowslskdleodd.com") //invalid url-2
    


// Download image (blocking operation)
val htmls = urls.map {
  url => Future {   
           println(Thread.currentThread.getName)
           blocking { downloadURLAndGetAllHref(url) }    
    }.map(_.size)
}
val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Inf)};res} }


//Updating  a global variables and keeping tap of URL 
val gMap = scala.collection.concurrent.TrieMap[String,List[String]]()

val htmls = urls.map {
  url => Future {   
           println(Thread.currentThread.getName)
           blocking { downloadURLAndGetAllHref(url) }    
    }.andThen{case Success(seq) => 
                    val old = gMap.getOrElse(url, List.empty[String])
                    //Update only diff 
                    val newS = seq.asInstanceOf[Seq[String]].toSet &~ old.toSet 
                    gMap.getOrElseUpdate(url,newS.toList)
                    seq
                }
}
val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Inf)};res} }.collect{case Success(lst) => lst.size}.reduce(_ + _)







///*** Akka Actor

"""
For a mutable state under concurrent  
wrap that mutable state inside an Actor 
and make the clients communicate with the Actor via message
 
 
To avoid the queue getting full, Make message processing (react, receive, etc.) 
be as short as possible. 

Long-running tasks should be handed off to an other actor:
1.  Actor A receives a message M from sender S
2.  A spawns a new actor C
3.  A sends (S, M) to C
4.  In parallel:
4a. A starts processing the next message.
4b. C does the long-running or dangerous (IO) task,
    When finished, sends the result to S,
    and C terminates.

Some alternatives in the process: 
•C sends (S, result) back to A who forwards to S
•A keeps a mapping ActorRef C => (Sender S, Message M) so in case it sees C fail, 
it can retry processing M with a new Actor.

it is guaranteed that the Actor will process all these messages serially 
Hence Actor's internal state  doesn't need synchronization, 
"""

//These are the rules for message sends by default 
//to change check akka Persistence
at-most-once delivery, i.e. no guaranteed delivery, 
    that message is delivered zero or one time
    For a given pair of actors, messages sent directly from the first to the second 
    will not be received out-of-order.


//Message sending 
! , tell
    send a message, 
    Note any message can be sent, eg, Int, String, any user defined Class/object(must be immutable and Serializable)
?,ask 
    Sends a message and wait on future
    
//An actor has a well-defined (non-cyclic) life-cycle.
1.RUNNING (created and started actor) - can receive messages
2.SHUTDOWN (when 'stop' is invoked) - canot do anything

//Important attributes of Actor 
1.The Actors own akka.actor.ActorRef is available as self, 
  ActorRef is a Actor, messages sent by ! , .path is for Actor path 
  .forward can forward any message 
2.the current message sender as sender() 
3.the akka.actor.ActorContext as context. 
  From context, goto ActorSystem by context.system 
  then ExecutionContext by context.system .dispatcher (for future) or director context.dispatcher
  Can get parent ActorRef as context.parent
  Note context can also create child Actor by 
  context.actorOf(Props[MyActor]),"name")
  context.actorOf(Props(classOf[MyActor], arg1, arg2), "name")
  or search for a Actor by 
  context.actorSelection(path)
4.abstract method ,receive returns the initial behavior of the actor as a partial function 
 (behavior can be changed using context.become and context.unbecome).

//the Akka Actor receive message loop is exhaustive
//Otherwise an 
akka.actor.UnhandledMessage(message, sender, recipient) 
//will be published to the ActorSystem's EventStream.

//Example 
//standard imports 
import akka.actor._
import akka.event.Logging
import scala.util._
import scala.concurrent._
import akka.util._ 
import scala.concurrent.duration._


class MyActor extends Actor with ActorLogging {
  //val log = Logging(context.system, this) //comes from ActorLogging 
  log.info(self.path.toString)
  val rand = new Random(1234)
  def receive = {
        case "test" => log.info("received test")
                       Thread.sleep(1000)
                       if ( sender() ne Actor.noSender ){
                            sender() ! rand.nextInt
                        }
        case _      => log.info("received unknown message")
      }
}

//Same process , sending messages to one Actor 
//(provider is local, for remote provider(even for other process in same host), check akka_remote_cliSrv code)

implicit val system = ActorSystem("testSystem")

val firstRef = system.actorOf(Props[MyActor], "first-actor") //or .actorOf(Props(classOf[MyActor], arg1, arg2), "name")
println(s"First: $firstRef")  //akka://testSystem/user/first-actor
firstRef ! "test"
//output 
[INFO] [03/30/2018 10:38:20.604] [testSystem-akka.actor.default-dispatcher-2] [akka.tcp://testSystem@127.0.0.1:2552/user/first-actor] received test
//Notbody recieves nextInt , hence goes to Deadletters,
//Only other actor can get that reply or use inbox() or use Ask pattern which returns a future 

//Via selection 
//val selection = system.actorSelection("akka.tcp://testSystem@127.0.0.1:2552/user/first-actor")
val selection = system.actorSelection("akka://testSystem/user/first-actor")
selection ! "test"

//with Actor-DSL , deprecated 
import akka.actor.ActorDSL._

implicit val i = inbox()
selection ! Identify(1) // replies will go to `i`

val reply:ActorIdentity = i.receive().asInstanceOf[ActorIdentity]
reply.ref.get ! "test"
i.receive().asInstanceOf[Int] // if there is no message it hangs 
//or 
val transformedReply = i.select(5 seconds) {
  case ActorIdentity(correlationId, actorRefOption) => 
                            println("" + correlationId + " " + actorRefOption)
                            actorRefOption.map{ actorRef => actorRef ! "test" }
                            
}
//or using resolve one 
val timeout:FiniteDuration = 1 second
val fut = selection.resolveOne(timeout)
val actorRef = Await.result(fut, Duration.Inf)
actorRef ! "test"  //returns goes to deadletter



///Ask pattern 
import akka.pattern.{ ask, pipe }

import system.dispatcher // The ExecutionContext(for futures) that will be used
 
implicit val timeout = Timeout(5 seconds) // needed for `?` below
//Gets Futures ? returns Future 
(firstRef ? "test") onSuccess { case f:Int => println(f) }


//Shutdown 
firstRef ! PoisonPill
system.terminate()


///*** Actor sending pattern - Tell, Ask returns Future 
//Messages can be any kind of object but have to be immutable.
// define as case class
final case class Result(x: Int, s: String, d: Double)
case object Request
 

class actorA extends Actor {
  def receive = {
    case Request => sender() ! 2
    case _      => 
  }
}
class actorB extends Actor {
  def receive = {
    case Request => sender() ! "2"
    case _      => 
  }
}
class actorC extends Actor {
  def receive = {
    case Request => sender() ! 2.0
    case _      => 
  }
}
class actorD extends Actor {
  def receive = {
    case Result(x,s,d) => println(s+x+d)
    case _      => 
  }
}
//Reply to messages, sender()
sender() ! result       // will have dead-letter actor as default

//To complete message with an exception ,send a Failure message to the sender. 
//This is not done automatically 
try {
  val result = operation()
  sender() ! result
} catch {
  case e: Exception =>
    sender() ! akka.actor.Status.Failure(e)
    throw e
}
//Create them 
val actorA = system.actorOf(Props[ActorA], "actorA")
val actorB = system.actorOf(Props[ActorB], "actorB")
val actorC = system.actorOf(Props[ActorC], "actorC")
val actorD = system.actorOf(Props[ActorD], "actorD")

///* Tell: Fire-forget
val message = Result(1,"OK",2.5)
actorD ! message

///* Ask: Send-And-Receive-Future
//onCompleteonComplete[U](f: (Try[T]) => U), onSuccess[U](pf: PartialFunction[T, U]), or onFailure[U](pf: PartialFunction[Throwable, U]) methods of the Future can be used to register 
//a callback to get a notification when the Future completes,

import akka.pattern._
import system.dispatcher // The ExecutionContext that will be used

//AskTimeoutException  :If the actor does not complete the future, raise this exception
import scala.concurrent.duration._
import akka.pattern.ask
val future = actorA.ask("hello")(5 seconds)

//OR with implicit argument of type akka.util.Timeout
implicit val timeout = Timeout(5 seconds) // needed for `?` below

 
//the receiving actor must reply with sender() ! reply
val f: Future[Result] =
  for {
    x <- ask(actorA, Request).mapTo[Int] // call pattern directly
    s <- (actorB ask Request).mapTo[String] // call by implicit conversion
    d <- (actorC ? Request).mapTo[Double] // call by symbolic name
  } yield Result(x, s, d)
 
//*pipeTo/pipe installs an onComplete-handler on the future
// and send Result to another Actor 
//must have implicit ExecutionContext in the context 
f pipeTo actorD // .. or ..
pipe(f) to actorD


///*forward a message from one actor to another. 
//the original sender reference is maintained in 'target' when sender() is used 
target forward message

///*** Actor - Stopping Actors
import akka.actor._

actorSystem.stop(anActor)
context.stop(childActor)
context.stop(self)
actor ! PoisonPill
actorSystem.terminate() //the system guardian actors will be stopped,

//Message                   Description
stop            method      The actor will continue to process its current message (if any), but no additional messages will be  processed. 
PoisonPill      message     A PoisonPill message will stop an actor when the message is processed. A PoisonPill message is queued just like an ordinary message and will be handled after other messages queued  ahead of it in its mailbox.
gracefulStop    method      terminate actors gracefully, waiting for them to timeout. The documentation   states that this is a good way to terminate actors in a specific order.
Kill            message     Kills the actor abruptly by raising Exception, but depends on exception handling strategy 


//PoisonPill
//stop the actor when the message is processed. 
//PoisonPill is enqueued as ordinary messages and will be handled after messages that were already queued in the mailbox.

victim ! PoisonPill

//Killing an Actor
//this will cause the actor to throw a ActorKilledException, triggering a failure. 
///The actor will suspend operation and its supervisor will be asked how to handle the failure, 
//which may mean resuming the actor, restarting it or terminating it completely. 

context.watch(victim) // watch the Actor to receive Terminated message once it dies
victim ! Kill

expectMsgPF(hint = "expecting victim to terminate") {
  case Terminated(v) if v == victim => v // the Actor has indeed terminated
}


//Graceful Stop
//gracefulStop is useful if you need to wait for termination 
//or compose ordered termination of several actors:

//When gracefulStop() returns successfully, 
//the actor’s postStop() hook will have been executed: there exists a happens-before edge between the end of postStop() and the return of gracefulStop().

import akka.pattern.gracefulStop
import scala.concurrent.Await
import akka.util.Timeout
import akk.actor._
import scala.concurrent.duration._

try {
  val stopped: Future[Boolean] = gracefulStop(actorRef, 5 seconds, Manager.Shutdown)
  Await.result(stopped, 6 seconds)
  // the actor has been stopped
} catch {
  // the actor wasn't stopped within 5 seconds
  case e: akka.pattern.AskTimeoutException =>
}

///* Stopping actors
//ActorContext  is used for stopping the actor itself or child actors 
//and the ActorSystem for stopping top level actors.
class MyActor extends Actor {
 
  val child: ActorRef = ???
 
  def receive = {
    case "interrupt-child" =>
      context stop child
 
    case "done" =>
      context stop self
  }
 
}


//The postStop hook is invoked after an actor is fully stopped. 
//This enables cleaning up of resources
override def postStop() {
  // clean up some resources ...
}


  
///*** Actor - Parallel Download 
import akka.actor._
import akka.event.Logging
import scala.util._
import scala.concurrent._
import akka.util._ 
import scala.concurrent.duration._
import akka.pattern._

case class xURL(url:String, sender:ActorRef)
case class rMap(url:String, urls:Seq[String], sender:ActorRef)
case object STOP

class Download extends Actor {
  import org.xml.sax._ 
  import java.io._ 
  import java.net._   
  
  def get(url: String) = scala.io.Source.fromURL(url, "ISO-8859-1").getLines.toList.mkString

  def downloadURLAndGetAllHref(base:String):Seq[String] = {
        val parserFactory = new org.ccil.cowan.tagsoup.jaxp.SAXFactoryImpl
        val parser = parserFactory.newSAXParser()
        val source = new InputSource( new StringReader( get(base) ) )
        val adapter = new scala.xml.parsing.NoBindingFactoryAdapter
        val xml = adapter.loadXML(source, parser)
        (xml \\ "a" ).map { n => n \@ "href"}.map{ url => if(url.startsWith("http")) url else (new URL(new URL(base),url)).toString}
    }
    def receive = {
        case  xURL(url,ori_sender) =>                            
                            val t = Try{downloadURLAndGetAllHref(url)}
                            t match {
                                case Failure(exe) => sender() ! rMap(url, Seq.empty[String],ori_sender)
                                case Success(urls) => sender() ! rMap(url, urls.asInstanceOf[Seq[String]],ori_sender)
                            }                          
        case STOP => context stop self
     }
}

class Service extends Actor with ActorLogging {
  import org.xml.sax._ 
  import java.io._ 
  import java.net._   
  val rnd = scala.util.Random
  
  def receive = {
        case  url:String => 
                log.info(""+ Thread.currentThread.getName+":"+url), //not multiargs 
                //start new actor                 
                val a = context.actorOf(Props[Download], "download-" + rnd.nextInt.abs)
                val currentSender = sender()
                a ! xURL(url,currentSender)  //Do it like this, to remove latest bug 
        case rMap(url:String, urls:Seq[String], ori_sender:ActorRef) =>  
                ori_sender ! Map( url -> urls.toList) 
                //kill child 
                sender ! STOP 
        case _      => log.info("received unknown message")
      } 
}

implicit val system = ActorSystem("testSystem")
val service = system.actorOf(Props[Service], "service") //or .actorOf(Props(classOf[MyActor], arg1, arg2), "name")

import system.dispatcher // The ExecutionContext(for futures) that will be used
implicit val timeout = Timeout(5 seconds) // needed for `?` below


val gMap = scala.collection.concurrent.TrieMap[String,List[String]]()
val urls = List(  "http://www.google.com",
                  "http://www.scala-lang.org/",
                  "http://jskdlsycds.com", //invalid url-1
                  "http://rediff.com",
                  "http://wowslskdleodd.com") //invalid url-2

                  
val htmls = urls.map {
  url => 
    val fut = (service ? url).mapTo[Map[String,List[String]]] 
    fut.onSuccess { case map:Map[_,_]  =>                         
                        val old = gMap.getOrElse(url, List.empty[String])
                        //Update only diff 
                        val newS = map.values.toList(0).asInstanceOf[List[String]].toSet &~ old.toSet 
                        gMap.getOrElseUpdate(map.keys.toList(0).asInstanceOf[String],newS.toList)
                }
    fut
}
val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Inf)};res} }.collect{case Success(map) => map.values.flatten.size}.reduce(_ + _)


  
  
  
///*** Actor - Ping-Pong Example 
import akka.actor._

class A extends Actor {
  def receive = {
    case "test" => println("From A - test")
        sender ! "stop"  //sender must be another actor 
    case "stop" => println (" From A - stopped")
        context.stop(self)
    case "Ping" => 
        Thread.sleep(1000)
        println("From A - Ping")
        sender ! "Pong"
    
    case x: String => println("From A -" + x)
    case _ =>
    }
}

class B(val a:ActorRef) extends Actor {    
   //actorFor is non existing in latest akka , there are other ways to get actor
  //val tmp = act getOrElse context.system.actorFor ("akka://mySystem/user/A") 
  
  def receive = { 
    case "stop" => a ! "stop"
          println ("From B- stopped")
          context.stop(self)
    case "doIt" => println("From B - Done")
            a ! "test"
    case "Pong" => 
        Thread.sleep(1000)
        println("From B - Pong")
        a ! "Ping"
    case _  => 
    }
}



val system = ActorSystem("mySystem")  //akka://mySystem
val a = system.actorOf(Props[A], "A")  //Actor[akka://mySystem/user/A#748617404]
a ! "OK"
val b = system.actorOf(Props(new B(a)), "B")
b ! "Pong"
Thread.sleep(10000); b ! "doIt"
system.shutdown()




///*** Actor - Props
import akka.actor.Props
 
val props1 = Props[MyActor]
val props3 = Props(classOf[ActorWithArgs], "arg", "arg2") // RECO , but not for value class arguments

val props2 = Props(new ActorWithArgs("arg")) // not RECO, especially within another actor 
val props7 = Props(new MyActor)  // not RECO, especially within another actor 

//via system 
system.actorOf(props1, "name")
system.actorOf(props2)
system.actorOf(Props[MyActor], "name")
system.actorOf(Props(classOf[MyActor], arg1, arg2), "name")

//via context 
context.actorOf(props1, "name")
context.actorOf(props2)
context.actorOf(Props[MyActor])
context.actorOf(Props(classOf[MyActor], arg1, arg2), "name")

///unsupported in above syntax 
1.An actor with AnyVal arguments.
2.An actor with default constructor values.

///How to handle value class 
class Argument(val value: String) extends AnyVal
class ValueClassActor(arg: Argument) extends Actor {
  def receive = { case _ => () }
}
 
object ValueClassActor {
  def props1(arg: Argument) = Props(classOf[ValueClassActor], arg) // fails at runtime
  def props2(arg: Argument) = Props(classOf[ValueClassActor], arg.value) // ok
  def props3(arg: Argument) = Props(new ValueClassActor(arg)) // ok
}

///*** Actor - Actors and shared mutable state
//Messages should be immutable, this is to avoid the shared mutable state trap.
//To update mutable state ,use below pattern 

class MyActor extends Actor {
 var state:TYPE = ...
 def receive = {
    case result:TYPE => state = newstate //for handling  self ! result
    case _ =>
             //Wrongs
             // Very bad, shared mutable state, will break your application in weird ways
              Future { state = NewState }
              anotherActor ? message onSuccess { r => state = r }
         
             // Very bad, "sender" changes for every message,
             // shared mutable state bug
              Future { expensiveCalculation(sender()) }
      
       
            //Rights         
            // Completely safe, "self" is OK to close over
            // and it's an ActorRef, which is thread-safe
              Future { expensiveCalculation() } onComplete {
                                          case Success(result) => self ! result
                                          case Failure(failure) => println(failure)
                                        } 
                                         
            // Completely safe, we close over a fixed value
            // and it's an ActorRef, which is thread-safe
              val currentSender = sender()
              Future { expensiveCalculation(currentSender) }
 }
}









///***scala jdbc  - sqllite 
//build.sbt 
libraryDependencies += "org.xerial" % "sqlite-jdbc" % "3.21.0.1"



//URL string 
jdbc:sqlite:sqlite_database_file_path
//Example 
jdbc:sqlite:sample.db
jdbc:sqlite:C:/sqlite/db/chinook.db

//To connect to an in-memory database
jdbc:sqlite::memory


//Example 

import java.sql._

object ScalaJdbcConnectSelect {

  def main(args: Array[String]) {
    var connection:Connection = null
    try
    {
      // make the connection
      Class.forName("org.sqlite.JDBC")
      // create a database connection
      connection = DriverManager.getConnection("jdbc:sqlite:sample.db");
      val statement = connection.createStatement();
      statement.setQueryTimeout(30);  // set timeout to 30 sec.

      statement.executeUpdate("drop table if exists person");
      statement.executeUpdate("create table person (id integer, name string)");
      statement.executeUpdate("insert into person values(1, 'leo')");
      statement.executeUpdate("insert into person values(2, 'yui')");
      //connection.commit()//database in auto commit mode //set it false by connection.setAutoCommit(false)
      val rs = statement.executeQuery("select * from person");
      while (rs.next())
      {
        //check other methods, how to update etc 
        //https://docs.oracle.com/javase/8/docs/api/java/sql/ResultSet.html
        val id = rs.getInt("id")
        val name = rs.getString("name")
        println("id, name = " + id + ", " + name)
      }
    }catch {
      case e => e.printStackTrace
    }
    connection.close()
  }
}

//Scala Way 
//Create Iterators 
val rs = statement.executeQuery("select * from person");
val it = new Iterator[String] {
  def hasNext = rs.next()
  def next() = rs.getInt(1)
}.toList

//Or functions 
implicit def results(resultSet: ResultSet) = new Iterator[ResultSet] {
    def hasNext = resultSet.next()
    def next() = resultSet
  }

val rs = statement.executeQuery("select * from person");
val m = results(rs).map{ rs => (rs.getInt("id"), rs.getString("name"))}.toMap
//or implicits 
val l = rs.map{ rs => rs.getInt("id")}.toList



///*** Example of iris group by 
import java.sql.{Array => SArray, _}

def print(x:(Double,Double,Double,Double,String)) = s"""(${x._1},${x._2},${x._3},${x._4},"${x._5}")"""

case class Row(sl:Double,sw:Double,pl:Double,pw:Double,Name:String){
     def toSql = s"""insert into iris values ${print(Row.unapply(this).get)}"""
}
val lines = scala.io.Source.fromFile(raw"..\data\iris.csv").getLines.map(_.split(",")).map{r =>r.map( _.trim)}.toList
//remove header row 
val rowts = lines.tail.map{r => (r.slice(0,4).map(_.toDouble),r.last)}.map { case ( Array(x,y,z,a),b) => (x,y,z,a,b) }

val rowcs = rowts.map{r => Function.tupled(Row.apply _)(r)}.map(_.toSql)

Class.forName("org.sqlite.JDBC")
var con  = DriverManager.getConnection("jdbc:sqlite:iris.db");
val stmt = con.createStatement();

stmt.executeUpdate("drop table if exists iris");
stmt.executeUpdate("create table iris (sl double, sw double, pl double, pw double, name string)");
rowcs.map(stmt.executeUpdate)

val rs = stmt.executeQuery("select count(*) from iris");
def it[T](rs:ResultSet)(f:ResultSet=>T) = new Iterator[T] {
  def hasNext = rs.next()
  def next() = f(rs)
}

it(rs){r => r.getInt(1)}.toList 
val rs = stmt.executeQuery("select name,max(sl) from iris group by name");
it(rs){r => (r.getString(1),r.getDouble(2))}.toList 




///*** REST client and  XML processing 
libraryDependencies += "com.typesafe.play" %% "play-ahc-ws-standalone" % "1.1.6"
//To add XML and JSON support using Play-JSON or Scala XML, add the following:
libraryDependencies += "com.typesafe.play" %% "play-ws-standalone-xml" % "1.1.6"
libraryDependencies += "com.typesafe.play" %% "play-ws-standalone-json" % "1.1.6"
//Example 
object Ws{
 def get(url:String, xml:Boolean = true ) = {
    import akka.actor._
    import akka.stream.ActorMaterializer
    import play.api.libs.ws._
    import play.api.libs.ws.ahc._
    import play.api.libs.json._

    import scala.concurrent._ 
    import scala.concurrent.duration._

    import play.api.libs.ws.DefaultBodyReadables._
    import play.api.libs.ws.XMLBodyReadables._
    import play.api.libs.ws.JsonBodyReadables._

    import scala.concurrent.ExecutionContext.Implicits._
    implicit val system = ActorSystem()
    //system.registerOnTermination {
    //  System.exit(0)
    //}
    implicit val materializer = ActorMaterializer()

    // Create the standalone WS client
    // no argument defaults to a AhcWSClientConfig created from
    // "AhcWSClientConfigFactory.forConfig(ConfigFactory.load, this.getClass.getClassLoader)"
    val ws = StandaloneAhcWSClient()

    def callXml(wsClient: StandaloneWSClient)(url:String): Future[scala.xml.Elem] = {
        wsClient.url(url).get().map { response =>
          val statusText: String = response.statusText
          response.body[scala.xml.Elem]      
        }
    }

    def callJson(wsClient: StandaloneWSClient)(url:String): Future[JsValue] = {
        wsClient.url(url).get().map { response =>
          val statusText: String = response.statusText
          response.body[JsValue]      
        }
    }
    if(xml) {
        callXml(ws)(url).andThen { case _ => ws.close() }
            .andThen { case _ => system.terminate() 
            } 
      }
    else {
        callJson(ws)(url).andThen { case _ => ws.close() }
            .andThen { case _ => system.terminate() }
         }
 }
}

val urlJson = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22nome%2C%20ak%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys"
val urlXml = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22nome%2C%20ak%22)&format=xml&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys"
val futXml = Ws.get(urlXml)
futXml map { e => e \\ "forecast"}.map{ ns => ns.map(_ \@ "high")} 
//Future(Success(List(27, 38,..)))

val futJson = Ws.get(urlJson, false)




///typed Body 
import play.api.libs.ws.DefaultBodyReadables._
import play.api.libs.ws.DefaultBodyWritables._
//XML and JSON support:
import play.api.libs.ws.XMLBodyReadables._
import play.api.libs.ws.XMLBodyWritables._

import play.api.libs.ws.JsonBodyReadables._
import play.api.libs.ws.JsonBodyWritables._

//To use a BodyReadable in a response, 
//type the response explicitly:

val responseBody: Future[scala.xml.Elem] = ws.url(...).get().map { response =>
  response.body[scala.xml.Elem]
  //now  parse response 
}

val jsonBody: Future[JsValue] = ws.url(...).get().map { response =>
  response.body[JsValue]
  //now parse response 
}




///*** XML 

val v = <a> OK </a>  //space matters!!! , usually a signle Elem, v: scala.xml.Elem = <a> OK </a>
val v = <a>OK</a><a>NOK</a> //multiple ele , v: scala.xml.NodeBuffer = ArrayBuffer(<a>OK</a>, <a>NOK</a>)

"""
Class Node is the abstract superclass of all XML node classes.
    abstract class NodeSeq extends AbstractSeq[Node] with collection.immutable.Seq[Node] with SeqLike[Node, NodeSeq] with Equality 
    abstract class Node extends NodeSeq  //Single Node 
    class  Elem extends Node with Serializable 
Hence class Node and Elem have all Seq methods(map, filter etc)
Elem is created as 
    new Elem(prefix: String, label: String, attributes1: MetaData, scope: NamespaceBinding, minimizeEmpty: Boolean, child: Node*) 

Class Text is a node holding text. 
For example, the "stuff" part of <a>stuff</a> is of class Text.

Any <, >, and & characters in the text will be escaped automatically by scala
Can put scala code inside {}, even nested XML

"""

<a> {"hello" + ", world"} </a>    //res1: scala.xml.Elem = <a> hello, world </a>
<a> {3 + 4} </a>  				//res3: scala.xml.Elem = <a> 7 </a>


val yearMade = 1955
<a>{ if (yearMade < 2000) <old>{yearMade}</old> else xml.NodeSeq.Empty }</a>

//Scala String would be escaped when used inside { }, to avoid 
import scala.xml._

scala> val bar=scala.xml.Unparsed(""""hello"""")
bar: scala.xml.Unparsed = "hello"

scala> val x = <script type="text/javascript">foo({bar});</script>
x: scala.xml.Elem = <script type="text/javascript">foo("hello");</script>

//Use text to get unescaped chars 
val amp = '&'

val e1 = <a>{amp}</a> //res0: String = <a>&amp;</a>
scala> el.child(0)
res4: scala.xml.Node = &amp;
scala> el.child(0).text
res5: String = &

//To  include a curly brace (‘{’ or ‘}’) as XML text, write two curly braces in a row:
<a> {{brace yourself!}} </a>  //res7: scala.xml.Elem = <a> {brace yourself!} </a>


//Methods of Elem and Node 
"""
x \ "div"     Searches the XML literal x for elements of type <div>. 
              Only searches immediate child nodes (no self or no grandchild or descendant nodes).
			  
x \@ "attr"	  Extracting attribute as string 

x \ "@attr"  Extracting attribute as NodeSeq 

x \\ "div"    Searches the XML literal x for elements of type <div>. 
              Returns matching  elements from child nodes at any depth of the XML tree.

x.attribute("name")   Returns the value of the given attribute in the current node.
                       <a x="10" y="20">foo</a>.attribute("x")   // returns Some(10).

x.attributes      Returns all attributes of the current node, prefixed and unprefixed, 
                  in no particular order.
                  val x = <a x="10" y="20">foo</a>.attributes  //scala.xml.MetaData =  x="10" y="20"
                   x("x")  //Seq[scala.xml.Node] = 10
                   
x.child           Returns the children of the current node.
                  <a><b>foo</b></a>.child   // returns <b>foo</b>.
					   
x.copy(...)       Returns a copy of the element, letting you replace data during the copy process.

x.label           The name of the current element. 
                  <a><b>foo</b></a>.label   // returns a.

x.text           Returns a concatenation of text(n) for each child n.

x.toString      Emits the XML literal as a String. 
                Use scala.xml.PrettyPrinter to format the output, if desired.
                
x(index)        Gives one Node at index position
x(pred)         pred: Node => Boolean , Gives NodeSeq when pred is true 


x.collect(fn)   Collects based on fn, a Partialfunction of Node => B,some type 
x.descendant    List[Node] 
x.namespace     String, same as getNamespace(this.prefix) 
x.prefix        String,namespace prefix (may be null, but not the empty string) 

**Seq like operations 
def drop(n: Int): NodeSeq
def dropRight(n: Int): NodeSeq
def dropWhile(p: (Node) => Boolean): NodeSeq
def endsWith[B](that: GenSeq[B]): Boolean
def equals(other: Any): Boolean
def exists(p: (Node) => Boolean): Boolean
def filter(p: (Node) => Boolean): NodeSeq
def filterNot(p: (Node) => Boolean): NodeSeq
def find(p: (Node) => Boolean): Option[Node]
def flatMap[B, That](f: (Node) => GenTraversableOnce[B])(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def flatten[B](implicit asTraversable: (Node) => GenTraversableOnce[B]): collection.immutable.Seq[B]
def fold[A1 >: Node](z: A1)(op: (A1, A1) => A1): A1
def foldLeft[B](z: B)(op: (B, Node) => B): B
def foldRight[B](z: B)(op: (Node, B) => B): B
def forall(p: (Node) => Boolean): Boolean
def foreach[U](f: (Node) => U): Unit
def getNamespace(pre: String): String
def groupBy[K](f: (Node) => K): Map[K, NodeSeq]
def grouped(size: Int): collection.Iterator[NodeSeq]
def head: Node
def headOption: Option[Node]
def indexOf[B >: Node](elem: B, from: Int): Int
def indexOf[B >: Node](elem: B): Int
def indexOfSlice[B >: Node](that: GenSeq[B], from: Int): Int
def indexOfSlice[B >: Node](that: GenSeq[B]): Int
def indexWhere(p: (Node) => Boolean, from: Int): Int
def indexWhere(p: (Node) => Boolean): Int
def indices: collection.immutable.Range
def init: NodeSeq
def inits: collection.Iterator[NodeSeq]
def intersect[B >: Node](that: GenSeq[B]): NodeSeq
def isDefinedAt(idx: Int): Boolean
def isEmpty: Boolean
final def isTraversableAgain: Boolean
def iterator: collection.Iterator[Node]
val label: String
def last: Node
def lastIndexOf[B >: Node](elem: B, end: Int): Int
def lastIndexOf[B >: Node](elem: B): Int
def lastIndexOfSlice[B >: Node](that: GenSeq[B], end: Int): Int
def lastIndexOfSlice[B >: Node](that: GenSeq[B]): Int
def lastIndexWhere(p: (Node) => Boolean, end: Int): Int
def lastIndexWhere(p: (Node) => Boolean): Int
def lastOption: Option[Node]
def length: Int
def lengthCompare(len: Int): Int
def lift: (Int) => Option[Node]
def map[B, That](f: (Node) => B)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def max[B >: Node](implicit cmp: Ordering[B]): Node
def maxBy[B](f: (Node) => B)(implicit cmp: Ordering[B]): Node
def min[B >: Node](implicit cmp: Ordering[B]): Node
def minBy[B](f: (Node) => B)(implicit cmp: Ordering[B]): Node
val minimizeEmpty: Boolean
def mkString: String
def mkString(sep: String): String
def mkString(start: String, sep: String, end: String): String
def nameToString(sb: StringBuilder): StringBuilder
def nonEmpty: Boolean
def nonEmptyChildren: Seq[Node]
def orElse[A1 <: Int, B1 >: Node](that: PartialFunction[A1, B1]): PartialFunction[A1, B1]
def padTo[B >: Node, That](len: Int, elem: B)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def par: ParSeq[Node]
def partition(p: (Node) => Boolean): (NodeSeq, NodeSeq)
def patch[B >: Node, That](from: Int, patch: GenSeq[B], replaced: Int)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def permutations: collection.Iterator[NodeSeq]
def prefixLength(p: (Node) => Boolean): Int
def product[B >: Node](implicit num: Numeric[B]): B
def reduce[A1 >: Node](op: (A1, A1) => A1): A1
def reduceLeft[B >: Node](op: (B, Node) => B): B
def reduceLeftOption[B >: Node](op: (B, Node) => B): Option[B]
def reduceOption[A1 >: Node](op: (A1, A1) => A1): Option[A1]
def reduceRight[B >: Node](op: (Node, B) => B): B
def reduceRightOption[B >: Node](op: (Node, B) => B): Option[B]
def repr: NodeSeq
def reverse: NodeSeq
def reverseIterator: collection.Iterator[Node]
def reverseMap[B, That](f: (Node) => B)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def runWith[U](action: (Node) => U): (Int) => Boolean
def sameElements[B >: Node](that: GenIterable[B]): Boolean
def scan[B >: Node, That](z: B)(op: (B, B) => B)(implicit cbf: CanBuildFrom[NodeSeq, B, That]): That
def scanLeft[B, That](z: B)(op: (B, Node) => B)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def scanRight[B, That](z: B)(op: (Node, B) => B)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
val scope: NamespaceBinding
def segmentLength(p: (Node) => Boolean, from: Int): Int
def seq: collection.immutable.Seq[Node]
def size: Int
def slice(from: Int, until: Int): NodeSeq
def sliding(size: Int, step: Int): collection.Iterator[NodeSeq]
def sliding(size: Int): collection.Iterator[NodeSeq]
def sortBy[B](f: (Node) => B)(implicit ord: math.Ordering[B]): NodeSeq
def sortWith(lt: (Node, Node) => Boolean): NodeSeq
def sorted[B >: Node](implicit ord: math.Ordering[B]): NodeSeq
def span(p: (Node) => Boolean): (NodeSeq, NodeSeq)
def splitAt(n: Int): (NodeSeq, NodeSeq)
def startsWith[B](that: GenSeq[B], offset: Int): Boolean
def startsWith[B](that: GenSeq[B]): Boolean
def strict_!=(other: Equality): Boolean
def strict_==(other: Equality): Boolean
def stringPrefix: String
def sum[B >: Node](implicit num: Numeric[B]): B
def tail: NodeSeq
def tails: collection.Iterator[NodeSeq]
def take(n: Int): NodeSeq
def takeRight(n: Int): NodeSeq
def takeWhile(p: (Node) => Boolean): NodeSeq
def theSeq: Seq[Node]
def to[Col[_]](implicit cbf: CanBuildFrom[Nothing, Node, Col[Node]]): Col[Node]
def toArray[B >: Node](implicit arg0: ClassTag[B]): Array[B]
def toBuffer[B >: Node]: Buffer[B]
def toIndexedSeq: collection.immutable.IndexedSeq[Node]
def toIterable: collection.Iterable[Node]
def toIterator: collection.Iterator[Node]
def toList: List[Node]
def toMap[T, U](implicit ev: <:<[Node, (T, U)]): Map[T, U]
def toSeq: collection.immutable.Seq[Node]
def toSet[B >: Node]: Set[B]
def toStream: collection.immutable.Stream[Node]
def toString(): String
def toTraversable: collection.Traversable[Node]
def toVector: Vector[Node]
def transpose[B](implicit asTraversable: (Node) => GenTraversableOnce[B]): collection.immutable.Seq[collection.immutable.Seq[B]]
def union[B >: Node, That](that: GenSeq[B])(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def unzip[A1, A2](implicit asPair: (Node) => (A1, A2)): (collection.immutable.Seq[A1], collection.immutable.Seq[A2])
def unzip3[A1, A2, A3](implicit asTriple: (Node) => (A1, A2, A3)): (collection.immutable.Seq[A1], collection.immutable.Seq[A2], collection.immutable.Seq[A3])
def updated[B >: Node, That](index: Int, elem: B)(implicit bf: CanBuildFrom[NodeSeq, B, That]): That
def view(from: Int, until: Int): SeqView[Node, NodeSeq]
def view: SeqView[Node, NodeSeq]
def withFilter(p: (Node) => Boolean): FilterMonadic[Node, NodeSeq]
def xmlType(): TypeSymbol
final def xml_!=(other: Any): Boolean
final def xml_==(other: Any): Boolean
def xml_sameElements[A](that: Iterable[A]): Boolean
def zip[A1 >: Node, B, That](that: GenIterable[B])(implicit bf: CanBuildFrom[NodeSeq, (A1, B), That]): That
def zipAll[B, A1 >: Node, That](that: GenIterable[B], thisElem: A1, thatElem: B)(implicit bf: CanBuildFrom[NodeSeq, (A1, B), That]): That
def zipWithIndex[A1 >: Node, That](implicit bf: CanBuildFrom[NodeSeq, (A1, Int), That]): That 
"""
//scala supports subset of XPath, only supports \ and \ "@" and \\
//Extracting text - call xml.Elem.text
<a>Sounds <tag/> good</a>.text  // String = Sounds good
<a> input ---&gt; output </a>.text // String = input --->output


//Extracting sub-elements

<a><b><c>hello</c></b></a> \ "b"    //< b><c>hello</c></b>
                                    // works only for sub-element, not first element or sub-sub element 

<a><b><c>hello</c></b></a> \ "c"   //scala.xml.NodeSeq =
<a><b><c>hello</c></b></a> \\ "c"  //scala.xml.NodeSeq = <c>hello</c>

<a><b><c>hello</c></b></a> \ "a"   //scala.xml.NodeSeq =
<a><b><c>hello</c></b></a> \\ "a"  / scala.xml.NodeSeq = <a><b><c>hello</c></b></a>

//Extracting attributes
val joe = <employee name="Joe" rank="code monkey" serial="123"/>
joe \@ "name"  	//String = Joe
joe \ "@serial" 	//scala.xml.NodeSeq = 123
joe \ "@serial" text //String 

//Saving and loading 
scala.xml.XML.save("therm1.xml", node)  // saving a node

val loadnode = xml.XML.loadFile("therm1.xml") 
val xml = xml.XML.loadString(content)     // from String


//pattern matching on XML

def proc(node: scala.xml.Node): String =
	node match {
		case <a>{contents}</a> => "It's an a: "+ contents  //can not contain any XML node
		case <b>{contents}</b> => "It's a b: "+ contents
		case _ => "It's something else."
}
proc(<a>apple</a>)  				//String = It's an a: apple
proc(<a>a <em>red</em> apple</a>)  // Fails , String = It's something else.

def proc(node: scala.xml.Node): String =   // binding to internal
	node match {
		case <a>{contents @ _*}</a> => "It's an a: "+ contents
		case <b>{contents @ _*}</b> => "It's a b: "+ contents
		case _ => "It's something else."
}

proc(<a>a <em>red</em> apple</a>)  //String = It's an a: ArrayBuffer(a ,<em>red</em>, apple)

//With Nampespace 
val str = """<a  xmlns="http://graphml.graphdrawing.org/xmlns" xmlns:x="urn:x">
   <b>b1</b>
   <x:b>b2</x:b>
   <b>b3</b>
</a>"""

val x = xml.XML.loadString(str)
x \\ "b" text  //b1b2b3
x \\ "b" filter ( z => z.namespace == "http://graphml.graphdrawing.org/xmlns") text //b1b3
val unprefixedTitle = (x \ "b").filter(_.prefix == null).text //b1b3
val dublinCoreTitle = (x \ "b").filter(_.prefix == "x").text  //b2

///Quick example 
val xml = scala.xml.XML.loadFile("../data/example.xml") 

scala> xml \ "country" \ "rank"
res3: scala.xml.NodeSeq = NodeSeq(<rank>1</rank>, <rank>4</rank>, <rank>68</rank>)

scala> xml \ "country" \ "rank"  map(_.text)
res4: scala.collection.immutable.Seq[String] = List(1, 4, 68)

scala> xml \ "country" map(_ \@ "name")
res6: scala.collection.immutable.Seq[String] = List(Liechtenstein, Singapore, Panama)

scala> xml \ "country" map{n => n \@ "name" -> (n \ "neighbor").map(_ \@ "name")}
res8: scala.collection.immutable.Seq[(String, scala.collection.immutable.Seq[String])] = L
ist((Liechtenstein,List(Austria, Switzerland)), (Singapore,List(Malaysia)), (Panama,List(C
osta Rica, Colombia)))

scala> xml \ "country" map{n => n \@ "name" -> (n \ "neighbor").map(_ \@ "name")} toMap
res9: scala.collection.immutable.Map[String,scala.collection.immutable.Seq[String]] = Map(
Liechtenstein -> List(Austria, Switzerland), Singapore -> List(Malaysia), Panama -> List(C
osta Rica, Colombia))






///*** Play JSON - Introduction
//https://github.com/playframework/play-json
libraryDependencies += "com.typesafe.play" %% "play-json" % "2.6.7"

//The base type in Play JSON is play.api.libs.json.JsValue, 
//and has several subtypes representing different JSON types
//To convert JsValue to scala type use.as[T]
//To convert scala type to Jsvalue, use JSVALUE_OBJECT(scala type)
JsObject
    a JSON object, represented as a Map. 
    Can be constructed from an ordered Seq or any kind of Map using JsObject.apply
JsArray
    a JSON array, consisting of a Seq[JsValue]
JsNumber
    a JSON number, represented as a BigDecimal.
JsString
    a JSON string.
JsBoolean
    a JSON boolean, either JsTrue or JsFalse.
JsNull
    the JSON null value.

///*** Play JSON - Basic reading and writing
import play.api.libs.json._ 

Json.parse(input: Array[Byte]): JsValue 
    Parses some bytes representing a JSON input, and returns it as a JsValue.
Json.parse(input: InputStream): JsValue 
    Parses a stream representing a JSON input, and returns it as a JsValue.
Json.parse(input: String): JsValue 
    Parses a String representing a JSON input, and returns it as a JsValue.
Json.prettyPrint(json: JsValue): String 
    Converts a JsValue to its pretty string representation using default pretty printer (line feeds after each fields and 2-spaces indentation).
Json.stringify(json: JsValue): String 
    Converts a JsValue to its string representation.



//Json.parse parses a JSON string or InputStream into a JSON tree:

val json: JsValue = Json.parse("""
{
  "name" : "Watership Down",
  "location" : {
    "lat" : 51.235685,
    "long" : -1.309197
  },
  "residents" : [ {
    "name" : "Fiver",
    "age" : 4,
    "role" : null
  }, {
    "name" : "Bigwig",
    "age" : 6,
    "role" : "Owsla"
  } ]
}
""")

//OR 
import play.api.libs.json._

val json: JsValue = JsObject(Seq(
  "name" -> JsString("Watership Down"),
  "location" -> JsObject(Seq("lat" -> JsNumber(51.235685), "long" -> JsNumber(-1.309197))),
  "residents" -> JsArray(IndexedSeq(
    JsObject(Seq(
      "name" -> JsString("Fiver"),
      "age" -> JsNumber(4),
      "role" -> JsNull
    )),
    JsObject(Seq(
      "name" -> JsString("Bigwig"),
      "age" -> JsNumber(6),
      "role" -> JsString("Owsla")
    ))
  ))
))


//or using shortcuts 
import play.api.libs.json.{ JsNull, Json, JsString, JsValue }

val json: JsValue = Json.obj(
  "name" -> "Watership Down",
  "location" -> Json.obj("lat" -> 51.235685, "long" -> -1.309197),
  "residents" -> Json.arr(
    Json.obj(
      "name" -> "Fiver",
      "age" -> 4,
      "role" -> JsNull
    ),
    Json.obj(
      "name" -> "Bigwig",
      "age" -> 6,
      "role" -> "Owsla"
    )
  )
)

//Json.stringify is used to convert a JsValue to a String of JSON:

val jsonString = Json.stringify(json)
// {"name":"Watership Down","location":{"lat":51.235685,"long":-1.309197},"residents":[{"name":"Fiver","age":4,"role":null},{"name":"Bigwig","age":6,"role":"Owsla"}]}


//Traversing a JsValue - Jpath \

//The (json \ "location" \ "lat") returns a JsLookupResult 
//which may or may not contain a value. 
val lat = (json \ "location" \ "lat").get   // returns JsValue(51.235685)

//use \ to look up indices within a JsArray:
val bigwig = (json \ "residents" \ 1).get   // returns {"name":"Bigwig","age":6,"role":"Owsla"}

//Recursive path \
//Applying the \\ operator will do a lookup for the field in the current object 
//and all descendants.

val names = json \\ "name"      // returns Seq(JsString("Watership Down"), JsString("Fiver"), JsString("Bigwig"))

//Index lookup
//retrieve a value in a JsObject or JsArray using an apply operator 
//with the index number or key.

val name = json("name")                 // returns JsString("Watership Down")

val bigwig = json("residents")(1)       // returns {"name":"Bigwig","age":6,"role":"Owsla"}


//using 'validate', 'as' and 'asOpt' methods. 
//use validate since it returns a JsResult which may contain an error if the JSON is malformed.
val unsafeName = (json \ "name").as[String]     // String: "Watership Down"
val unsafeBogusName = (json \ "bogus").as[String]   // throws exception
val nameOption = (json \ "name").asOpt[String]      // Some("Watership Down")
val bogusOption = (json \ "bogus").asOpt[String]        // None
val nameResult = (json \ "name").validate[String]       // JsSuccess("Watership Down")
val bogusResult = (json \ "bogus").validate[String]     // JsError
val unsafeName2 = json("name").as[String]               // "Watership Down"
val unsafeBogusName2 = json("bogus").as[String]         // throws exception

///Quick example 
import play.api.libs.json._ 
import java.io._


val jsonin = new FileInputStream("../data/example.json")
val json = Json.parse(jsonin) //JsValue, as base class of all Json object 
jsonin.close()

json(1)("empId")        // for array, index, for object use, key, res12: play.api.libs.json.JsValue = 20

//JsArray has map, filter etc 
val json:JsArray = Json.parse(jsonin).as[JsArray]
json.value          //res17: IndexedSeq[play.api.libs.json.JsValue]
json.value.map{_.as[JsObject]}.map{o => o \ "empId" as[Int]}

scala> json.value.map{_.as[JsObject]}.map{o => (o \ "empId").as[Int]}
res18: IndexedSeq[Int] = ArrayBuffer(1, 20)

scala> json.value.map{_.as[JsObject]}.map{o => (o \ "details" \ "firstName").as[String]}
res19: IndexedSeq[String] = ArrayBuffer(John, Johns)
//All office phone numbers 
val jsob = json.value.map{_.as[JsObject]}.map{o => (o \ "details" \ "phoneNumbers").as[JsArray]}.flatMap{phs => phs.value.map{ph => ph.as[JsObject] }}
jsob.filter{e => e("type") == JsString("office")}.map{e => e("number").as[String]}



//Reference 
case class play.api.libs.json.JsObject(underlying: Map[String, JsValue]) extends JsValue with Product with Serializable
	Represent a Json object(map) value.
    Instance Constructors
        new JsObject(underlying: Map[String, JsValue])
    Value Members
    def +(otherField: (String, JsValue)): JsObject
        Adds one field to the JsObject
    def ++(other: JsObject): JsObject
        Merge this object with another one.
    def -(otherField: String): JsObject
        Removes one field from the JsObject
    def as[T](implicit fjs: Reads[T]): T
        Tries to convert the node into a T, throwing an exception if it can't.
    def asOpt[T](implicit fjs: Reads[T]): Option[T]
        Tries to convert the node into a T.
    def canEqual(other: Any): Boolean
    def deepMerge(other: JsObject): JsObject
        merges everything in depth and doesn't stop at first level, as ++ does
    def equals(other: Any): Boolean
    def fieldSet: Set[(String, JsValue)]
        Return all fields as a set
    lazy val fields: Seq[(String, JsValue)]
        The fields of this JsObject in the order passed to to constructor
    def hashCode(): Int
    def keys: Set[String]
        Return all keys
    def toString(): String
    def transform[A <: JsValue](rds: Reads[A]): JsResult[A]
        Transforms this node into a JsResult using provided Json transformer Reads[JsValue]
    def validate[A](implicit rds: Reads[A]): JsResult[A]
        Tries to convert the node into a JsResult[T] (Success or Error).
    def validateOpt[A](implicit rds: Reads[A]): JsResult[Option[A]]
    lazy val value: Map[String, JsValue]
        The value of this JsObject as an immutable map.
    def values: Iterable[JsValue]
        Return all values
object JsObject extends (Seq[(String, JsValue)]) => JsObject with Serializable
    def andThen[A](g: (JsObject) => A): (Seq[(String, JsValue)]) => A
    def apply(fields: Seq[(String, JsValue)]): JsObject
        Construct a new JsObject, with the order of fields in the Seq.
    def compose[A](g: (A) => Seq[(String, JsValue)]): (A) => JsObject
    def empty: JsObject
    def toString(): String 

case class play.api.libs.json.JsArray(value: IndexedSeq[JsValue] = Array[JsValue]()) extends JsValue with Product with Serializable
	Represent a Json array value.
    Instance Constructors
        new JsArray(value: IndexedSeq[JsValue] = Array[JsValue]())
    Value Members
    def ++(other: JsArray): JsArray
        Concatenates this array with the elements of an other array.
    def +:(el: JsValue): JsArray
        Prepend an element to this array.
    def :+(el: JsValue): JsArray
        Append an element to this array.
    def append(el: JsValue): JsArray
    def as[T](implicit fjs: Reads[T]): T
        Tries to convert the node into a T, throwing an exception if it canot.
    def asOpt[T](implicit fjs: Reads[T]): Option[T]
        Tries to convert the node into a T.
    def prepend(el: JsValue): JsArray
    def toString(): String
    def transform[A <: JsValue](rds: Reads[A]): JsResult[A]
        Transforms this node into a JsResult using provided Json transformer Reads[JsValue]
    def validate[A](implicit rds: Reads[A]): JsResult[A]
        Tries to convert the node into a JsResult[T] (Success or Error).
    def validateOpt[A](implicit rds: Reads[A]): JsResult[Option[A]]
    val value: IndexedSeq[JsValue] 
object JsArray extends (IndexedSeq[JsValue]) => JsArray with Serializable
    def andThen[A](g: (JsArray) => A): (IndexedSeq[JsValue]) => A
    def apply(value: Seq[JsValue]): JsArray
    def compose[A](g: (A) => IndexedSeq[JsValue]): (A) => JsArray
    def empty: JsArray
    def toString(): String 

case class JsNumber(value: BigDecimal) extends JsValue with Product with Serializable
	Represent a Json number value.
    new JsNumber(value: BigDecimal)
    def as[T](implicit fjs: Reads[T]): T
        Tries to convert the node into a T, throwing an exception if it canot.
    def asOpt[T](implicit fjs: Reads[T]): Option[T]
        Tries to convert the node into a T.
    def toString(): String
    def transform[A <: JsValue](rds: Reads[A]): JsResult[A]
        Transforms this node into a JsResult using provided Json transformer Reads[JsValue]
    def validate[A](implicit rds: Reads[A]): JsResult[A]
        Tries to convert the node into a JsResult[T] (Success or Error).
    def validateOpt[A](implicit rds: Reads[A]): JsResult[Option[A]]
        val value: BigDecimal    
        
final case class JsLookup(result: JsLookupResult) extends AnyVal with Product with Serializable
	A value representing the value at a particular JSON path, either an actual JSON node or undefined.
    Instance Constructors
        new JsLookup(result: JsLookupResult)
    Value Members
    def \(fieldName: String): JsLookupResult
        Return the property corresponding to the fieldName, supposing we have a JsObject.
    def \(index: Int): JsLookupResult
        Access a value of this array.
    def \\(fieldName: String): Seq[JsValue]
        Look up fieldName in the current object and all descendants.
    def apply(fieldName: String): JsValue
        Access a value of this array.
    def apply(index: Int): JsValue
        Access a value of this array.
    def getClass(): Class[_ <: AnyVal]
    def head: JsLookupResult
        Access the head of this array.
    def last: JsLookupResult
        Access the last element of this array.
        val result: JsLookupResult
    def tail: JsLookupResult
        Access the tail of this array.
sealed trait JsLookupResult extends JsReadable
    def as[T](implicit fjs: Reads[T]): T
        Tries to convert the node into a T, throwing an exception if it canot.
    def asOpt[T](implicit fjs: Reads[T]): Option[T]
        Tries to convert the node into a T.
    def get: JsValue
    def getOrElse(v: => JsValue): JsValue
    def isDefined: Boolean
    def isEmpty: Boolean
    def orElse(alternative: => JsLookupResult): JsLookupResult
        If this result is defined return this.
    def toEither: Either[JsonValidationError, JsValue]
    def toOption: Option[JsValue]
        Tries to convert the node into a JsValue
    def transform[A <: JsValue](rds: Reads[A]): JsResult[A]
        Transforms this node into a JsResult using provided Json transformer Reads[JsValue]
    def validate[A](implicit rds: Reads[A]): JsResult[A]
        Tries to convert the node into a JsResult[T] (Success or Error).
    def validateOpt[A](implicit rds: Reads[A]): JsResult[Option[A]]
        If this result contains JsNull or is undefined, returns JsSuccess(None).


///*** Avro
//Apache Avro is a language neutral data serialization format. 
//Avro data is described in a language independent schema. 
//The schema is usually written in JSON format 
//and the serialization is usually to binary files 
//although serialization to JSON is also supported.

//build.sbt 
"org.apache.avro"  %  "avro"  %  "1.7.7"
"org.apache.kafka" % "kafka_2.11" % "0.10.0.0",

//ZooKeeper is a distributed, open-source coordination service for distributed applications. 
//Default is localhost:2181
//Download from https://archive.apache.org/dist/zookeeper/zookeeper-3.4.10/zookeeper-3.4.10.tar.gz
//And unzip and add to PATH bin dir 



//Kafka is distributed streaming platform
//Download from https://archive.apache.org/dist/kafka/0.11.0.0/kafka_2.11-0.11.0.0.tgz
//Update PATH with <<install>>\windows\bin and C:\windows\system32\wbem

//Start in Kafka-Avro directory
$ zookeeper-server-start.bat  conf/zookeeper.properties  //client binds to ..:2181
$ kafka-server-start.bat conf/server.properties   //server binds to localhost:9092, called broker-list 

//Start Producer 
$ sbt "runMain demoApp.ConsumerApp"
$ sbt "runMain demoApp.ProducerApp"

///*** Example using Avro and Kafka
//schema.avsc:
{
    "namespace": "kakfa-avro.test",
     "type": "record",
     "name": "user",
     "fields":[
         {
            "name": "id", "type": "int"
         },
         {
            "name": "name",  "type": "string"
         },
         {
            "name": "email", "type": ["string", "null"]
         }
     ]
}
//domanin.scala 
case class User(id: Int, name: String, email: Option[String])


//ProducerApp.scala 
import domain.User
import producer. KafkaProducer

object ProducerApp extends App {

  private val topic = "demo-topic"

  val producer = new KafkaProducer()

  val user1 = User(1, "Sushil Singh", None)
  val user2 = User(2, "Satendra Kumar Yadav", Some("satendra@knoldus.com"))

  producer.send(topic, List(user1, user2))

}

//ConsumerApp.scala 
import consumer.KafkaConsumer

object ConsumerApp extends App {

  val consumer = new KafkaConsumer()

  while (true) {
    consumer.read() match {
      case Some(message) =>
        println("Got message: " + message)

        Thread.sleep(100)
      case _ =>
        println("Queue is empty.......................  ")
        // wait for 2 second
        Thread.sleep(2 * 1000)
    }
  }

}


//Producer.scala 
import java.util.{Properties, UUID}

import org.apache.avro.Schema
import org.apache.avro.Schema.Parser
import domain.User
import org.apache.avro.generic.GenericData
import org.apache.avro.generic.GenericRecord
import org.apache.avro.specific.SpecificDatumWriter
import java.io.ByteArrayOutputStream

import org.apache.avro.io._
import kafka.producer.{KeyedMessage, Producer, ProducerConfig}

import scala.io.Source

class KafkaProducer() {

  private val props = new Properties()

  props.put("metadata.broker.list", "localhost:9092")
  props.put("message.send.max.retries", "5")
  props.put("request.required.acks", "-1")
  props.put("serializer.class", "kafka.serializer.DefaultEncoder")
  props.put("client.id", UUID.randomUUID().toString())

  private val producer = new Producer[String, Array[Byte]](new ProducerConfig(props))

  //Read avro schema file and
  val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/schema.avsc")).mkString)

  def send(topic: String, users: List[User]): Unit = {
    val genericUser: GenericRecord = new GenericData.Record(schema)
    try {
      val queueMessages = users.map { user =>
        // Create avro generic record object
        //Put data in that generic record object
        genericUser.put("id", user.id)
        genericUser.put("name", user.name)
        genericUser.put("email", user.email.orNull)

        // Serialize generic record object into byte array
        val writer = new SpecificDatumWriter[GenericRecord](schema)
        val out = new ByteArrayOutputStream()
        val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
        writer.write(genericUser, encoder)
        encoder.flush()
        out.close()

        val serializedBytes: Array[Byte] = out.toByteArray()

        new KeyedMessage[String, Array[Byte]](topic, serializedBytes)
      }
      producer.send(queueMessages: _*)
    } catch {
      case ex: Exception =>
        println(ex.printStackTrace().toString)
        ex.printStackTrace()
    }
  }

}


//Consumer.scala 
import java.util.Properties

import domain.User
import org.apache.avro.Schema
import org.apache.avro.io.DatumReader
import org.apache.avro.io.Decoder
import org.apache.avro.specific.SpecificDatumReader
import org.apache.avro.generic.GenericRecord
import org.apache.avro.io.DecoderFactory
import kafka.consumer.{Consumer, ConsumerConfig, ConsumerTimeoutException, Whitelist}
import kafka.serializer.DefaultDecoder

import scala.io.Source


class KafkaConsumer() {
  private val props = new Properties()

  val groupId = "demo-topic-consumer"
  val topic = "demo-topic"

  props.put("group.id", groupId)
  props.put("zookeeper.connect", "localhost:2181")
  props.put("auto.offset.reset", "smallest")
  props.put("consumer.timeout.ms", "120000")
  props.put("auto.commit.interval.ms", "10000")

  private val consumerConfig = new ConsumerConfig(props)
  private val consumerConnector = Consumer.create(consumerConfig)
  private val filterSpec = new Whitelist(topic)
  private val streams = consumerConnector.createMessageStreamsByFilter(filterSpec, 1, new DefaultDecoder(), new DefaultDecoder())(0)

  lazy val iterator = streams.iterator()

  val schemaString = Source.fromURL(getClass.getResource("/schema.avsc")).mkString
  // Initialize schema
  val schema: Schema = new Schema.Parser().parse(schemaString)

  private def getUser(message: Array[Byte]): Option[User] = {

    // Deserialize and create generic record
    val reader: DatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](schema)
    val decoder: Decoder = DecoderFactory.get().binaryDecoder(message, null)
    val userData: GenericRecord = reader.read(null, decoder)

    // Make user object
    val user = User(userData.get("id").toString.toInt, userData.get("name").toString, try {
      Some(userData.get("email").toString)
    } catch {
      case _ => None
    })
    Some(user)
  }

  /**
    * Read message from kafka queue
    *
    * @return Some of message if exist in kafka queue, otherwise None
    */
  def read() =
    try {
      if (hasNext) {
        println("Getting message from queue.............")
        val message: Array[Byte] = iterator.next().message()
        getUser(message)
      } else {
        None
      }
    } catch {
      case ex: Exception => ex.printStackTrace()
        None
    }

  private def hasNext: Boolean =
    try
      iterator.hasNext()
    catch {
      case timeOutEx: ConsumerTimeoutException =>
        false
      case ex: Exception => ex.printStackTrace()
        println("Got error when reading message ")
        false
    }

  def close(): Unit = consumerConnector.shutdown()

} 