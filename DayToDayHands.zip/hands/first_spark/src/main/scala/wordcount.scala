package examples

import org.apache.spark._
import org.apache.spark.rdd._ 

object RDDCount{
    def main(args:Array[String]){
        val inputFile = if (args.size >=1) args(0) else "README"
        val conf = new SparkConf().setAppName("wordcount")
        val sc = new SparkContext(conf) //main entry point 
        val input = sc.textFile(inputFile) //RDD[String]
        val words = input.flatMap(l => l.split(" ")) //RDD[String]
        val counts = words.map(w => (w,1)). //RDD[(String, Int)]
        //RDD[(K,V)].reduceByKey(func: (V, V) => V): RDD[(K, V)] 
        //        reduceByKey( (v1,v2) => v1+v2)
        //aggregateByKey[U](zeroValue: U)(seqOp: (U, V) => U, combOp: (U, U) => U)
          aggregateByKey(0L)( (u,v) => u+v, (u1,u2) => u1+u2)
        counts.collect.foreach(println) //action, on driver        
    }
}
//sbt assembly 
//spark-submit --class examples.RDDCount 
//  --master local[*] 
//  target\scala-2.11\learning-assembly.jar 
//  README

import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F} //alias 
object DFCount{
    def main(args:Array[String]){
        val inputFile = if (args.size >=1) args(0) else "README"
        val spark = SparkSession.builder.appName("dfwordcount").
                    getOrCreate()
        import spark.implicits._ 
        val input = spark.read.text(inputFile) //DF[value:String]
        val words = input.select(F.split($"value", " ").alias("words")) //DF[words:Array[String]]
        val counts = words.select(F.explode($"words").alias("word")) //DF[word:String]
        val grp = counts.groupBy("word")
        grp.count().collect().foreach(println) //Action 
        //sql
        counts.createOrReplaceTempView("words")
        val df = spark.sql("""select word, count(*) as count 
            from words group by word""")
        df.show       
    }
}
//sbt assembly 
//spark-submit --class examples.DFCount 
//  --master local[*] 
//  target\scala-2.11\learning-assembly.jar 
//  README