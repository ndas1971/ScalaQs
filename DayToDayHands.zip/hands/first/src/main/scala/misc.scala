package first3
//import java.io.File 
import java.io._ 

object Main{
    def main(args:Array[String]){
        val s = "Hello World Hello Earth"
        //freq(s.split(" "))
        val dir = "D:/hands"
        println(getMaxFileName(new File(dir)))
    }
    def getMaxFileName(dir:File)= {
        def getFiles(dirs:Array[File], 
        acc:Array[File]= Array.empty[File]):Array[File]={
           //listFiles, length are File's method 
            val files = dirs.flatMap{ f => f.listFiles.filter(_.isFile)}
            val subs = dirs.flatMap{ f => 
                f.listFiles.filter(_.isDirectory)}
            if (subs.isEmpty) acc ++ files else getFiles(subs, acc ++ files)
        }
        val allFiles = getFiles(Array(dir))
        val map = allFiles.map{ f => (f, f.length)}.toMap
        val smap = map.toList.sortBy{ case(f,s)=> s}
        smap.last  //last element
    }
    
    def freq(arr:Array[String]) = {
        for(wd1 <- arr){
            var counter = 0
            for (wd2 <- arr){
                if (wd1 == wd2){
                    counter = counter + 1
                }            
            } 
            println(s"$wd1 = $counter")
        }    
    }

}
//sbt "runMain first3.Main"
 