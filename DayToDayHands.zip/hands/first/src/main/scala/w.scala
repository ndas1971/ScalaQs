package first2

abstract class ScalaW(val location:String, 
    private val unit:String = "c"){
    override def toString = s"ScalaWeather(${this.location})"
    //def this(location:String){
    //    this(location, "c")
    //}
    //below is abstract 
    def getFormat:String
    //own component 
    private val url = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
    private def encode = s"select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='${location}') and u='${unit}'"
    def base_url = s"""${url}?q=${java.net.URLEncoder.encode(encode, "UTF-8")}"""
    def full_url = s"""${base_url}&format=${this.getFormat}"""
    //print(full_url)
    def get = scala.io.Source.fromURL(full_url).mkString
}
class ScalaWJson(location:String, unit:String)
    extends ScalaW(location, unit){
        def getFormat = "json"
}
class ScalaWXML(location:String, unit:String)
    extends ScalaW(location, unit){
        def getFormat = "xml"
}
object WeatherFactory{
    def apply(location:String, unit:String="c",
      json:Boolean = true) = {
            json match {
                case true => new ScalaWJson(location, unit)
                case false => new ScalaWXML(location, unit)
            }        
   }
}

object Main{
    def main(args: Array[String]){
        val location = args(0)
        val unit = if (args.size >=2) args(1) else "c"
        val json = if (args.size >=3) args(2).toBoolean else true
        val w = WeatherFactory(location, unit, json)
        println(w.get)
    }
}
//D:\hands\first>sbt compile
//Then 
//sbt "runMain first2.Main mumbai c false"
// sbt assembly 
//%JAVA_HOME%\bin\java -cp "target/scala-2.11/learning-assembly.jar;
//  C:/Training/scala/lib/*" first2.Main mumbai c false
