package examples 

import scala.concurrent._ 
import scala.concurrent.duration._ 
//import scala.concurrent.ExecutionContext.Implicits.global //default threadpool 
import java.io._ 

object Files{
    def time[R](block: => R): R = {
        val t0 = System.nanoTime()
        val result = block    // call-by-name, 
        val t1 = System.nanoTime()
        val diff = (t1 - t0)
        val div = if ( diff >= 1e9 ) (1e9, " secs") else (1e6, " ms")
        println("Elapsed time: " + (t1 - t0)/div._1 + div._2)
        result
    }
    
    def hE[R](default: => R)( code : => R):R =
        scala.util.Try(code).toOption.getOrElse(default)
    
    def hN[R](default: => R)( code : => R):R = 
        Option(code).getOrElse(default)

        
    def getSizeFiles(files:Array[File]) = 
        files.map{file => hE(0L)(file.length)}.sum

       
    def getAll(dirs: Array[File]) = {  
        //null comes because of permission problem             
        val alls = dirs.flatMap{ f => hN(Array.empty[File])(f.listFiles) }
        val subdirs = alls.filter( file =>  hE(false)(file.isDirectory)) 
        val files = alls.filter(file => hE(false)(file.isFile)) 
        (subdirs, files)
    }

    def getSizeDirs( dirs: Array[File]):Long = {
        def inner(dirs: Array[File], acc:Long = 0L):Long = {
            val (subdirs, files) = getAll(dirs)
            if (subdirs.isEmpty) acc + getSizeFiles(files)
            else inner(subdirs, acc + getSizeFiles(files))
        }
        inner(dirs.toArray)
    }

    def getSizeMaster(dirs: Array[File], ws:Int=4) :Long = {        
        def execute(dirs: Array[File])(implicit ex:ExecutionContext) = {
            //get root dir
            val (subdirs, files) = getAll(dirs)
            //for each subdir , fork one thread 
            val futDirs = subdirs.map { dir =>
                Future {                
                   getSizeDirs( Array(dir) )
                }.fallbackTo(Future(0L))
            }
            val fut = Future.foldLeft(futDirs.toList)(getSizeFiles(files))( _ + _ )
            fut 
        }
        val exec = java.util.concurrent.Executors.newFixedThreadPool(ws)
        implicit val ec = ExecutionContext.fromExecutor(exec) 
        try {            
            Await.result(execute(dirs), Duration.Inf)
        } finally {
            exec.shutdown()
        }
    }
}

object FutMain extends App {
    import Files._ 
    val path = new File(raw"C:\Windows\system32")
   
    println{
        time { 
            Files.getSizeDirs(Array(path))
        }
    }
    println {
        time {
            Files.getSizeMaster(Array(path))
        }
    }
    println {
        time {
            Files.getSizeMaster(Array(path), 8)
        }
    }
}