import akka.actor._
import scala.util._

object ActorHelper{
    import scala.concurrent._
    import scala.concurrent.duration._
    
    def process(system: ActorSystem)(createActors: ActorSystem=>Seq[ActorRef])
            (stopActors:(ActorSystem, Seq[ActorRef])=>Unit)
            (body: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        val actors = createActors(system)
        println(s"Created: ${actors.map(_.toString).mkString("(",",",")")}")
      
        import system.dispatcher //brings ExecutionContext 
        body(system, actors).andThen{
            case x => 
                println(s"Stopping, body returned $x")
                stopActors(system,actors)
                x
          }
    }   
    def processSeq( system: ActorSystem, propNames:Seq[(String, Props)], stopMessage:Iterator[Any] =Iterator.continually(PoisonPill) )(sendfn: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        process(system){system => 
            propNames.map{case (n,p) => system.actorOf(p, n)}
          }{ (system, seq) =>
            seq.zip(stopMessage).foreach{ case(a, m) => a ! m} 
          }{(system, seq) => 
            sendfn(system, seq)
        }
    }    
    
    def processOne( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system){system => 
            Seq(system.actorOf(props, "name"))}{ (system, seq) =>
                seq.head ! stopMessage }{  (system, seq) => 
                    sendfn(system, seq.head)
                }
    }    
    def processWithTestProb(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef, ActorRef) => Future[Any] ):Future[Any]  = {
      processSeq(system, Seq(("name", props)/*actor*/, ("testprob", Props(new TestProb))/*sender*/), 
        Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor, sender) = seqs 
            sendfn(system, actor, sender)/*Future*/.transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                    sender ! PoisonPill
                })
            }
        }
    }
    def processWithoutStop(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        processSeq(system, Seq(("name", props)), Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor) = seqs 
            sendfn(system, actor).transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                })
            }
        }
    }
    
    def processName( system: ActorSystem, props:Props, actorName: String, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system)(system => Seq(system.actorOf(props, actorName)))( (system, seq) =>seq.head ! stopMessage ){
            (system, seq) => sendfn(system, seq.head)
        }
    }

    
    def findActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds):Future[ActorRef] =     
        system.actorSelection(prefix+name).resolveOne(duration)
        
    def stopActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds, stopMessage:Any=PoisonPill)={
        import system.dispatcher //brings ExecutionContext 
        findActor(system, name, prefix, duration).onComplete{
            case util.Success(ref) => 
                println(s"$ref")
                ref ! stopMessage
            case _ =>
        }
    }
    
    trait ActorStop { thisActor : Actor =>
        import ActorStop._ 
        
        def receiveSTOP: Actor.Receive = {    
           case STOP =>
              context.children.foreach { ch =>
                ch ! PoisonPill
              }
              self ! PoisonPill 
              
           case IMMSTOP =>
                 context.children.foreach { ch =>
                    context.stop(ch)
                }
              context.stop(self)
           case FAKESTOP =>
                 
        }
    }
    object ActorStop{
        sealed trait STOPMARKER
        case object STOP extends STOPMARKER
        case object IMMSTOP extends STOPMARKER
        case object FAKESTOP extends STOPMARKER
    }
    
    class TestProb extends Actor with ActorLogging {
        def receive: Receive = {    
               case msg => log.info(s"${self.path.name} - New msg received: $msg")      
            }
    }
    object TestProb{
        def props:Props = Props(new TestProb)
    }
}
