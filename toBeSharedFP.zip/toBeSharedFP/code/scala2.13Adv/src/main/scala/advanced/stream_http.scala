//sbt "runMain akkahttp.basic.Client arg1 arg2" 
package akkahttp.basic 
import akka._
import akka.actor._
import akka.http.scaladsl._
import akka.http.scaladsl.model.headers._
import akka.http.scaladsl.model._
import akka.stream._
import akka.stream.scaladsl._
import scala.concurrent.duration._
import scala.concurrent._
import java.nio.file._
import scala.util._ 
import akka.util._ 
import com.typesafe.sslconfig.akka.AkkaSSLConfig

/* 
Note, Source,Flow 's Mat is not generally Used (check reference), But Sink's Mat is system output 

Once all In and Out are connected, It is called Runnable graph and can be run to get Sink's Mat 
Process of starting the evaluation engine by 'Materializer'(one example, ActorSystem)
(*Shape means Source/Sink/Flow without Mat, Graph means *Shape with Mat- is generale system )

//runWith results into argument Mat(for FLow, both argument) , run results to upstream Mat , 
//runForEach results to Future[Done]
Source[Int,Out].runWith[Mat2](sink: Graph[SinkShape[Out], Mat2]): Mat2
Source[Int,Out].runForeach(f: (Out) => Unit): Future[Done]
RunnableGraph[+Mat].run(): Mat 
Sink[In, Mat].runWith[Mat2](source: Graph[SourceShape[In], Mat2]): Mat2  
Flow[In, Out, Mat].runWith[Mat1, Mat2](source: Graph[SourceShape[In], Mat1], sink: Graph[SinkShape[Out], Mat2]): (Mat1, Mat2)  


FileIO.fromPath(f: Path, chunkSize: Int = 8192): Source[ByteString, Future[IOResult]]
FileIO.toPath(f: Path, options: Set[OpenOption] = ...): Sink[ByteString, Future[IOResult]] 

Framing.delimiter(delimiter: ByteString, maximumFrameLength: Int, allowTruncation: Boolean = false): Flow[ByteString, ByteString, NotUsed] 
JsonFraming.objectScanner(maximumObjectLength: Int): Flow[ByteString, ByteString, NotUsed]

ByteString.utf8String: String 
ByteString.apply(string: String): ByteString 

//Some Sink creation 
Sink.seq[T]: Sink[T, Future[Seq[T]]] 
Sink.foreach[T](f: (T) => Unit): Sink[T, Future[Done]] 
Sink.fold[U, T](zero: U)(f: (U, T) => U): Sink[T, Future[U]]
Sink.head[T]: Sink[T, Future[T]]
Sink.reduce[T](f: (T, T) => T): Sink[T, Future[T]]
Sink.ignore: Sink[Any, Future[Done]]

//Some creation 
Flow.apply[T]: Flow[T, T, NotUsed]   //identity fn of FLow 
Flow.fromFunction[A, B](f: (A) => B): Flow[A, B, NotUsed]
Source.apply[T](iterable: Iterable[T]): Source[T, NotUsed]
Source.empty[T]: Source[T, NotUsed]
Source.failed[T](cause: Throwable): Source[T, NotUsed]
Source.fromIterator[T](f: () => Iterator[T]): Source[T, NotUsed]
Source.future[T](futureElement: Future[T]): Source[T, NotUsed]
Source.repeat[T](element: T): Source[T, NotUsed]
Source.single[T](element: T): Source[T, NotUsed]

//take/drop ,works of Out , Repr[Out]= means Source[In,Out] or Flow[In,Out,Mat]
Repr[Out].take(n: Long): Repr[Out]
Repr[Out].limit(max: Long): Repr[Out]
Repr[Out].drop(n: Long): Repr[Out]

//map/filter always operate on Out 
Repr[Out].map[T](f: (Out) => T): Repr[T]
Repr[Out].filter(p: (Out) => Boolean): Repr[Out]

//flatmap , operates on Out =mapConcat and fold also operates on Out 
Repr[Out].mapConcat[T](f: (Out) => Iterable[T]): Repr[T]
Repr[Out].fold[T](zero: T)(f: (T, Out) => T): Repr[T]

//flatMap of Source/Flow  which concates all these sources , operates on Out and produces new Sources of Out 
Repr[Out].flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Repr[T]

//via attaches out from upstream to In of downstream, Via ignores arg mat, use viaMat 
//via always takes one Flow 
Repr[Out].via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Repr[T]
Repr[Out].via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Repr[T]
Repr[Out].viaMat[T, Mat2, Mat3](flow: Graph[FlowShape[Out, T], Mat2])(combine: (Mat, Mat2) => Mat3): Source[T, Mat3] 
Repr[Out].viaMat[T, Mat2, Mat3](flow: Graph[FlowShape[Out, T], Mat2])(combine: (Mat, Mat2) => Mat3): Flow[In, T, Mat3]


//to always attaches Out of upstream to a Sink   Note FLow becomes Sink, Source becomes Runable graph 
//to ignores arg Mat 
Source[Int,Out].to[Mat2](sink: Graph[SinkShape[Out], Mat2]): RunnableGraph[Mat]
Flow[In, Out, Mat].to[Mat2](sink: Graph[SinkShape[Out], Mat2]): Sink[In, Mat]

//toMat take fn for Mat selection 
//Keep.left for upstream, Keep.right for arg/downstream, Keep.both as tuple
Flow[In, Out, Mat].toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) => Mat3): Sink[In, Mat3]  
Source[Int,Out].toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]  

//Store of fasterupstream and then expand , operates on Out and into Out of new result type 
Source[Out, Mat].conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Source[S, Mat]
Source[Out, Mat].expand[U](extrapolate: (Out) => Iterator[U]): Source[U, Mat]
Flow[In, Out, Mat].conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Flow[In, S, Mat]
Flow[In, Out, Mat].expand[U](extrapolate: (Out) => Iterator[U]): Flow[In, U, Mat]
*/

import com.typesafe.config.ConfigFactory

object Client {
implicit val system = ActorSystem("test_system", ConfigFactory.load("advanced.conf"))
//implicit val materializer: ActorMaterializer = ActorMaterializer()
implicit val executionContext: ExecutionContextExecutor = system.dispatcher

    def main(args: Array[String]): Unit = {
      val uri = "https://www.google.com"
      val file = Paths.get("index.html")
      val file2 = Paths.get("index2.html")
      val csvFile = Paths.get("iris.csv")
      //ignore any certificate 
      val http = Http()
      val badSslConfig = AkkaSSLConfig().mapSettings(s =>
          s.withLoose(
            s.loose
              .withAcceptAnyCertificate(true)
              .withDisableHostnameVerification(true)
          )
        )
      val httpsConnectionContext = http.createClientHttpsContext(badSslConfig)
      
      val fut = 
        downloadViaSource(uri, file, http, httpsConnectionContext) ::
        //Anotherway 
        downloadViaFlow2(uri , file2, http, httpsConnectionContext) ::
       //with line by line 
        readCsv(csvFile) :: //Future[Done]
        //another way 
        readCsv2(csvFile) ::
        Nil  //List[Future[Done]]
      
      //shutdown 
      Future.sequence(fut).onComplete{res =>  //List[Done]
            println("Main:" + res)
            system.terminate()
           }  // and shutdown when done
    }
    
    def downloadViaSource(uri:Uri, file:Path, http:HttpExt, httpsConnectionContext:HttpsConnectionContext)  = {    

        val request = HttpRequest(HttpMethods.GET, uri=uri)

        val responseFuture: Future[HttpResponse] = http.singleRequest(request, 
                connectionContext = httpsConnectionContext)
      
        responseFuture.flatMap {
          case response @ HttpResponse(StatusCodes.OK, _, _, _) =>
            val setCookies = response.headers[`Set-Cookie`]
            println(s"Cookies set by a server: $setCookies")
            //response.discardEntityBytes()
            //def toPath(f: Path, options: Set[OpenOption] = ...): Sink[ByteString, Future[IOResult]]          
            response.entity.dataBytes.runWith(FileIO.toPath(file)). //Future[IOResult]
                             map{res => 
                                println("downloadViaSource:"+ res)
                                Done}  //make it Future[Done]
          case _ => sys.error("something wrong")
        }
    
    }
  
    def downloadViaFlow2(uri: Uri, file: Path, http:HttpExt, httpsConnectionContext:HttpsConnectionContext)  = {
      val request = HttpRequest(HttpMethods.GET, uri=uri)
      val source = Source.single((request, ()))
      // superPool[T]: Flow[(HttpRequest, T), (Try[HttpResponse], T), NotUsed] 
      val requestResponseFlow = http.superPool[Unit](connectionContext=httpsConnectionContext)

      source.   //Source[(HttpRequest, Tuple0), NotUsed]
            //Source[+Out, +Mat].via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Source[T, Mat]
            //ie sourceout to In to FlowIn and out T as SourceIn 
            via(requestResponseFlow).  //Source[(Try[HttpResponse], Tuple0)]
            //Source[In,Mat].collect[T](pf: PartialFunction[Out, T]): Source[T, Mat]
            collect{
                case (Success(response), x) => (response, x)
            }.
            //Source[In,Mat].map[T](f: (Out) => T): Source[T, Mat]
            map(_._1).
            //Sink.foreach[T](f: (T) => Unit): Sink[T, Future[Done]]
            runWith(Sink.foreach[HttpResponse]{ httpResponse =>
                httpResponse.entity.dataBytes.runWith(FileIO.toPath(file)) //Future[IOResult]
             }//Future[Done]
            )//Future[Done]
    }
    def readCsv(csvFile:Path)= {
        FileIO.fromPath(csvFile). //Source
          via(Framing.delimiter(ByteString("\n"), 1024, true).map(_.utf8String)). //Source
          take(2). 
          runForeach(println) //Future[Done] 
    }
    def readCsv2(csvFile:Path)= {
        val sink = Sink.foreach[String](x => println(x.split(",").size))
         FileIO.fromPath(csvFile).
              via(Framing.delimiter(ByteString("\n"), 256, true).map(_.utf8String)).
              take(2).
              to(sink). //sink Mat is ignored 
              run().  //Future[IOResult]              
              map{res => 
                println("readCsv2:"+ res)
                Done}  //make it Future[Done]
    }
}
