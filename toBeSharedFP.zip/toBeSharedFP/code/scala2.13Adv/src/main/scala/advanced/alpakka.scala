//sbt "runMain alpakka.basic.Client arg1 arg2" 
package alpakka.basic 
import akka._
import akka.actor._
import akka.stream._
import akka.stream.scaladsl._
import scala.concurrent.duration._
import scala.concurrent._
import java.nio.file._
import scala.util._ 
import akka.util._ 
import spray.{json => SprayJson} //import spray.json.{DefaultJsonProtocol, JsValue, JsonWriter}
import akka.stream.alpakka.json.scaladsl.JsonReader
import akka.stream.alpakka.csv.scaladsl.{CsvParsing, CsvToMap}
import akka.stream.alpakka.xml.scaladsl.XmlParsing
import akka.stream.alpakka.xml._ 

import akka.http.scaladsl._
import akka.http.scaladsl.model.headers._
import akka.http.scaladsl.model._
import akka.stream.alpakka.slick.scaladsl._
import slick.jdbc.GetResult
import com.typesafe.config.ConfigFactory

object Client extends ActorSystemAvailable with SprayJson.DefaultJsonProtocol {  //brings implicit JsonReader[T]/JsonWriter[T] for standard T {
    import session.profile.api._  
    
    
    def main(args: Array[String]): Unit = {
       /*
        //Operator 	                Description
        $ 	                        root
        @ 	                        current node
        * 	                        wildcard
        .. 	                        recursive descent
        .<name> 	                child
        ['<name>' (, '<name>')] 	child/children
        [<number> (, <number>)] 	index/indices
        [start:end] 	            array slice
        [?(<expression>)] 	        filter expression
                                        == 	equal
                                        < 	less than
                                        > 	greater than
                                        &&
                                        ||
        //Then check 
        $.store.book[*].author 	//Find the authors of all books
        $..author 	            //All authors
        $.store.* 	            //All things in store
        $.store..price 	        //The price of everything in the store
        $..book[2] 	            //The third book
        $..book[0,1] 	        //The first two books
        $.store.book[?(@.price==8.95)] 	            //Filter all books whose price equals to 8.95
        $.store.book[?(@.category=='fiction')]      //Filter all books which belong to fiction category        

        $..book[1,3]['author','title']
        $.store.book[0]
        $.store.book[?(@.price < 10 || @.category && @.isbn && @.price>10)]
       
       */
       val  fut1 = processJson("$.store.book[*].author") //Find the authors of all books
       
       //CSV Processing and groupBy 
       val file = "iris.csv"
       val orgS = processCsv(file).
                        //each key one Source
                        groupBy(3, data => data.name). //SubFlow[Data, Mat, Source[Data,..], RunnableGraph]
                        //each source mapped 
                        map(d => (d.name,d.sl)).  //Repr[Double]
                        fold( ("", Double.MinValue) )((t,e) => (e._1, t._2.max(e._2) ) ). 
                        //now merge 
                        mergeSubstreams.runWith(Sink.seq)
                        
        orgS.foreach(println)

        //Uniq Names and max 
        val splitter = GraphDSL.create(){ implicit b => 
            import GraphDSL.Implicits._
            val bc = b.add(Broadcast[Data](2))
            UniformFanOutShape(bc.in, bc.out(0), bc.out(1))
        }

        val (cS, mS) = (Sink.head[Set[String]], Sink.seq[Tuple2[String,Double]])
        val m1 = Flow[Data].fold( List[String]() )( (r,e) => r :+ e.name).map(_.toSet)
        val m2 = Flow[Data].groupBy(3, data => data.name).fold( ("", Double.MinValue) )((t,e) => (e.name, t._2.max(e.sl) ) ).mergeSubstreams

        //check with 
        //processCsv(file).via(m1).runWith(cS)
        //processCsv(file).via(m2).runWith(mS)

        val (cF, mF) = RunnableGraph.fromGraph(GraphDSL.create(processCsv(file),m1,m2,cS, mS)( (x,y,z,l,r) => (l,r) ) { implicit b => (s,f1,f2,ls,rs) =>
          import GraphDSL.Implicits._
          val sp = b.add(splitter)
          //any error means, below is not correct 
          s ~> sp ~>  f1 ~> ls
               sp ~> f2 ~> rs          
          ClosedShape
        }).run()
        cF foreach println 
        mF foreach println 
       
       ///XML 
       val xmlFile = "example.xml"
       processXml(xmlFile)
       //Any error, put log to check Exception 
       //processXml(xmlFile).log("user").runForeach(println)
       var fXml = processXml(xmlFile).collect{ case Some(x) => x}.runWith(Sink.seq)
       fXml.foreach(println)
       
       
       ///Http request to DB 
       val uri = "https://raw.githubusercontent.com/ndas1971/Misc/master/nasdaq_screener_data.csv"
       //Old link, now does not work "https://old.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nasdaq&render=download"  
       createTable()
       val stocks = TableQuery[Stocks]
       toDB(uri).run().foreach(println)  //Done 
       //select * , * is the table’s * projection we defined earlier
       resultFromDB(stocks.result).map{ seq => seq.size }.foreach{println} 

       
       
       wait(1.minutes)
       for {
            f1 <- fut1
            //f2 <- fut2
        } {
            //println(s"RESULT: ${f1}\n${f2}")
            terminateActorSystem()
        }
    }
    //HTTP to DB 
    def httpRequest(uri:Uri) = HttpRequest(uri = uri ).withHeaders(Accept(MediaRanges.`text/*`))  //*/

    def extractEntityData(response: HttpResponse): Source[ByteString, _] =
      response match {
        //HttpResponse(status: StatusCode = StatusCodes.OK, headers: Seq[HttpHeader] = Nil, entity: ResponseEntity = HttpEntity.Empty,  protocol: HttpProtocol = HttpProtocols.`HTTP/1.1`)
        case HttpResponse(StatusCodes.OK, _, entity, _) => entity.dataBytes
        case notOkResponse =>
          Source.failed(new RuntimeException(s"illegal response $notOkResponse"))
      }

    def cleanseCsvData(csvData: Map[String, ByteString]): Map[String, String] =
      csvData
        .filterNot { case (key, _) => key.isEmpty }
        .mapValues(_.utf8String).toMap

    def toJson(map: Map[String, String])(implicit jsWriter: SprayJson.JsonWriter[Map[String, String]]): SprayJson.JsValue = 
          jsWriter.write(map)
          
    def resultFromDB[T](streamingQuery: StreamingDBIO[Seq[T], T])(implicit session: SlickSession) = Slick.
        source(streamingQuery)(session).
        log("user").
        runWith(Sink.seq)      
          
    def toDB(uri:Uri, debug:Boolean=false) = {
       def convertD(text:String, default:Double=0.0):Double= Try(text.trim.toDouble).toOption.getOrElse(default)
       def convertL(text:String, default:Long=0L):Long= Try(text.trim.toLong).toOption.getOrElse(default)
       val stocks = TableQuery[Stocks]
       Source. 
         single(httpRequest(uri)).                      //Source[HttpRequest, _]
         //Source[+Out, +Mat].mapAsync[T](parallelism: Int)(f: (Out) => Future[T]): Source[T, Mat]
         mapAsync(1)(Http().singleRequest(_)).     //Source[HttpResponse, _]
         //Source[+Out, +Mat].flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Source[T,Mat]
         flatMapConcat(extractEntityData).         //Source[ByteString, _]
         //Source[+Out, +Mat].via[T, Mat2](flow: Graph[FlowShape[Out, T], Mat2]): Source[T, Mat]
         via(CsvParsing.lineScanner()).  //each line , Source[List[ByteString],_]                         
         via(CsvToMap.toMap()). // Header:Value , Source[Map[String,ByteString],_]
         //Source[+Out, +Mat].map[T](f: (Out) => T):Source[T, Mat]
         map(cleanseCsvData).    //Source[Map[String,String],_]
         map( m => (
                 m.getOrElse("Symbol"        ,"DEFAULT"),
                 m.getOrElse("Sector"        ,"DEFAULT"),
                 m.getOrElse("Name"          ,"DEFAULT"),
                 m.getOrElse("industry"      ,"DEFAULT"),
                 convertL(m.getOrElse("IPOyear"       ,"0")),
                 convertD(m.getOrElse("LastSale"      ,"0.0")),
                 m.getOrElse("Summary Quote" ,"DEFAULT"),
                 m.getOrElse("MarketCap"     ,"DEFAULT"))
           ).
           // grouped(n: Int): Repr[Seq[Out]] 
           grouped(100).log("user").
           toMat(Slick.sink{seq_stock_tuple => 
               if(debug) println(seq_stock_tuple)
               DBIO.seq(
                   stocks ++= seq_stock_tuple
               ).map(x=> 1)  //sink takes DBIO[Int] 
             })(Keep.right)
         }    

    class Stocks(tag: Tag) extends Table[(String,String,String,String,Long,Double,String,String)](tag, "STOCKS") {
        def symbol = column[String]("SYMBOL", O.PrimaryKey)
        def sector = column[String]("SECTOR")
        def name = column[String]("NAME")
        def industry = column[String]("INDUSTRY")
        def ipoYear = column[Long]("IPO_YEAR")
        def lastSale = column[Double]("LAST_SALE")
        def summaryQuote = column[String]("SUMMARY_QUOTE")
        def marketCap = column[String]("MARKET_CAP")
       // Every table needs a * projection with the same type as the table's type parameter
       //sql select would return below in order 
        def * = (symbol, sector, name, industry, ipoYear, lastSale, summaryQuote, marketCap)
    }
    def createTable() {    
        val stocks = TableQuery[Stocks]
        val setupAction: DBIO[Unit] = DBIO.seq(
              //for many (suppliers.schema ++ coffees.schema).create
              //for drop - dropIfExists, createIfNotExists, drop 
              stocks.schema.create //, 
              //insert one , for more ++=  Seq(..)
              //stocks += ("DEFAULT","DEFAULT","DEFAULT","DEFAULT",0L,0.0,"DEFAULT","DEFAULT")
            )
        val setupFuture: Future[Unit] = session.db.run(setupAction)
        setupFuture.foreach(println) 
    }
    
    
    //XML
    case class Nei(name:String, direction:String)
    case class Country(name:String="", rank:Long = -1L, year:Long = -1L, gdppc:Long = -1L, neighbor:List[Nei] = List[Nei]()) 

    def processXml(xmlFile:String, debug:Boolean = false) = {
        def convertAttrListToMap(a:List[Attribute]) =  a.map( e => (e.name, e.value)).toMap
        def convert(text:String):Long = Try(text.trim.toLong).toOption.getOrElse(0)
        FileIO.fromPath(Paths.get(xmlFile))  //note stream itself can be taken as List 
        .via(XmlParsing.parser)  //Flow[ByteString, ParseEvent, NotUsed]
        //statefulMapConcat[T](f: () => (Out) => Iterable[T]): Repr[T]
        .statefulMapConcat(() => {    //Source[ParseEvent]
        // create state here 
        var buf = Country()
        var curElem = "data"
        // below gets called multiple time , returns List[Option[Country]]
        parseEvent =>
          parseEvent match {
            case s: StartElement if s.localName == "country" =>   
                    if(debug) println(s"StartElement(country): ${s}")
                    buf = Country(name=convertAttrListToMap(s.attributesList).getOrElse("name", "NOTFOUND"))
                    curElem = "country"
                    None :: Nil
            case s: EndElement if s.localName == "country" =>
                    if(debug) println(s"EndElement(country): ${s}")
                    Some(buf) :: Nil
            case s: StartElement if s.localName == "rank" =>       
                    if(debug) println(s"StartElement(rank): ${s}")        
                    curElem = "rank"
                    None :: Nil
            case s: TextEvent if `curElem` == "rank" =>
                    if(debug) println(s"TextEvent(rank):${s.text}: ${s}")
                    //many spurious TextEvent might come if there are whitespaces in xml docs 
                    buf = if (s.text.trim.isEmpty) buf else buf.copy(rank=convert(s.text))
                    None :: Nil                     
            case s: StartElement if s.localName == "year" =>      
                    if(debug) println(s"StartElement(year): ${s}")
                    curElem = "year"
                    None :: Nil
            case s: TextEvent if `curElem` == "year" =>
                    if(debug) println(s"TextEvent(year):${s.text}: ${s}")
                    buf = if (s.text.trim.isEmpty) buf else buf.copy(year=convert(s.text))
                    None :: Nil   
            case s: StartElement if s.localName == "gdppc" => 
                    if(debug) println(s"StartElement(gdppc): ${s}")
                    curElem = "gdppc"
                    None :: Nil
            case s: TextEvent if `curElem` == "gdppc" =>
                    if(debug) println(s"TextEvent(gdppc):${s.text}: ${s}")
                    buf = if (s.text.trim.isEmpty) buf else buf.copy(gdppc=convert(s.text))
                    None :: Nil      
            case s: StartElement if s.localName == "neighbor" =>
                    if(debug) println(s"StartElement(neighbor): ${s}")
                    curElem = "neighbor"
                    val attrs = convertAttrListToMap(s.attributesList)
                    val neis = buf.neighbor :+ Nei(name=attrs.getOrElse("name", "NOTFOUND"), 
                                                   direction=attrs.getOrElse("direction", "NOTFOUND"))
                    buf = buf.copy(neighbor=neis)
                    None :: Nil                
            case s =>
                    if(debug) println(s"default: ${s}")
                    None :: Nil
          }
      }) //Source[Option[Country]]
     }    
    
    case class Data(sl:Double, sw:Double, pl:Double, pw:Double, name:String)
    
    def processCsv(file:String) = {
        FileIO.fromPath(Paths.get(file))  //note stream itself can be taken as List 
          //each line => List[ByteString]
          .via(CsvParsing.lineScanner(delimiter=CsvParsing.Comma)/*Flow[ByteString, List[ByteString], NotUsed] */)  //Source[List[ByteString],Future[IOResult]] 
          .drop(1)                    //remove Header 
          .map(_.map(_.utf8String))  //Source[List[String]]
          .map{
            case List(a,b,c,d,e) => Data(a.toDouble,b.toDouble,c.toDouble,d.toDouble,e)
            }  //Source[Data]                        
    }
    
    
    def processJson(pat:String, jsonStr:String=baseDocument) = {
        Source
          .single(ByteString.fromString(jsonStr))
          .via(JsonReader.select(pat)/*Flow[ByteString, ByteString, NotUsed] */)   //Source[FlowOut]
          //runWith results into argument Mat(for FLow, both argument) , run results to upstream Mat , 
          .map(_.utf8String)
          .runWith(Sink.seq) //Future[T] 
    }
    
    val baseDocument = """{
        "store": {
            "book": [
                {
                    "category": "reference",
                    "author": "Nigel Rees",
                    "title": "Sayings of the Century",
                    "price": 8.95
                },
                {
                    "category": "fiction",
                    "author": "Evelyn Waugh",
                    "title": "Sword of Honour",
                    "price": 12.99
                },
                {
                    "category": "fiction",
                    "author": "Herman Melville",
                    "title": "Moby Dick",
                    "isbn": "0-553-21311-3",
                    "price": 8.99
                },
                {
                    "category": "fiction",
                    "author": "J. R. R. Tolkien",
                    "title": "The Lord of the Rings",
                    "isbn": "0-395-19395-8",
                    "price": 22.99
                }
            ],
            "bicycle": {
                "color": "red",
                "price": 19.95
            }
        },
        "expensive": 10
    }
    """
}


class ActorSystemAvailable {
  implicit val actorSystem: ActorSystem = ActorSystem("test_system", ConfigFactory.load("advanced.conf"))
  //implicit val actorMaterializer: Materializer = ActorMaterializer()
  implicit val executionContext: ExecutionContext = actorSystem.dispatcher
  implicit val session = SlickSession.forConfig("slick-h2-disk")
  
  def wait(duration: FiniteDuration): Unit = Thread.sleep(duration.toMillis)

  def terminateActorSystem(): Unit = {
    actorSystem.registerOnTermination(() => session.close())
    Await.result(actorSystem.terminate(), 1.seconds)
  }
}