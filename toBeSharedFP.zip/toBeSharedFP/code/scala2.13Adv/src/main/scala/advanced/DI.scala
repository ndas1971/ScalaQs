package di

import com.google.inject.name._
import org.aopalliance.intercept._
import com.google.inject.name._
import com.google.inject._


trait A{
    def getName:String
}
class B extends A {
    def getName = "XYZ"
}

class C extends A {
    def getName = "New XYZ"
}

class D extends A {
    def getName = "Prov XYZ"
}

class AProvider extends Provider[D] {
  def get = new D
}

case class TwoStrings @Inject()(@Named("first") first: String, @Named("second") second: String)



trait Say {
  def hi(str: String): String
}
//this AOP annotation defined in src/main/java/support  
import support.AOP

class SayHi extends Say {
  @AOP
  def hi(str: String): String = str
}
class AOPI extends MethodInterceptor {
  def invoke(invocation: MethodInvocation): AnyRef = s"""Hi ${invocation.proceed().toString}"""
}

class AOPI2 extends MethodInterceptor {
  //signature must be same 
  //https://docs.spring.io/spring/docs/current/javadoc-api/org/aopalliance/intercept/MethodInterceptor.html
  def invoke(invocation: MethodInvocation): AnyRef = {
        //handle pre-invocation
        println("method "+ invocation.getMethod()+" is called on "+
                        invocation.getThis()+" with args "+ invocation.getArguments())
        val ret = s"""Hi ${invocation.proceed().toString}"""
        //handle post invocation
        ret
    }
}

//Usage 


import net.codingwell.scalaguice._

object Main extends App{

    val module = new AbstractModule with ScalaModule {
        import net.codingwell.scalaguice.BindingExtensions._
        override def configure() = {
          bind[A].to[B]
          bind[A].annotatedWith(Names.named("NEW_A")).to[C]
          bind[A].annotatedWith(Names.named("Provider")).toProvider[AProvider]
          
          bind[String].annotatedWithName("first").toInstance("first")
          bindConstant().annotatedWithName("second").to("second")
          
          bind[Say].to[SayHi]
          bindInterceptor[AOPI](methodMatcher = annotatedWith[AOP])
        }
    }
    //Then use 
    val injector = Guice.createInjector(module) 
    import net.codingwell.scalaguice.InjectorExtensions._
    val a = injector.instance[A]
    
    val new_a = injector.instance[A](Names.named("NEW_A"))
    
    val prov_a = injector.instance[A](Names.named("Provider"))
    

    val twoStrings = injector.instance[TwoStrings]


    val say = injector.instance[Say]        //"Hi Bob"
    
    printf("%s,%s,%s,%s,%s\n", a.getName, new_a.getName, prov_a.getName, twoStrings.toString, say.hi("Bob"))
    //XYZ,New XYZ,Prov XYZ,TwoStrings(first,second),Hi Bob
    
    //Binding to Set[T], here Set[String]
    val module2 = new AbstractModule with ScalaModule {
        override def configure() = {
          val multi = ScalaMultibinder.newSetBinder[String](binder)
          multi.addBinding.toInstance("A")
          multi.addBinding.toInstance("B")
        }
    }

    val injector2 = Guice.createInjector(module2)
    import net.codingwell.scalaguice.InjectorExtensions._
    val set = injector2.instance[collection.immutable.Set[String]]
    //set contains 
    println(s""" ${set("A")},  ${set("B")}""")    //true , true 


    //Binding to Map[K,V], here Map[String, Int]
    val module3 = new AbstractModule with ScalaModule {
        override def configure(): Unit = {
          val mBinder = ScalaMapBinder.newMapBinder[String, Int](binder)
          mBinder.addBinding("1").toInstance(1)
          mBinder.addBinding("2").toInstance(2)
        }
    }

    val injector3 = Guice.createInjector(module3)
    import net.codingwell.scalaguice.InjectorExtensions._
    val map = injector3.instance[collection.immutable.Map[String, Int]]
    map.foreach(println)
}