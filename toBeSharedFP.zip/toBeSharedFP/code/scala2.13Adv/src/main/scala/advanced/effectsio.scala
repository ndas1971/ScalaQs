import cats.effect._
import scala.concurrent.duration._

object EffectsMain extends IOApp {

  def run(args: List[String]): IO[ExitCode] =
    args.headOption match {
      case Some(name) =>
        IO.sleep(1.second) *> IO(println(s"Hello, $name.")).as(ExitCode.Success)
      case None =>
        IO(System.err.println("Usage: MyApp name")).as(ExitCode(2))
    }  
}


object EffectsMain2 extends IOApp.Simple {
  val run = IO.println("Hello, World!")
}

object EffectsExample extends IOApp.Simple {

  def loop(n: Int): IO[ExitCode] =
    IO.defer {
      if (n < 10)
        IO.sleep(1.second) >> IO(println(s"Tick: $n")) >> loop(n + 1)
      else
        IO.pure(ExitCode.Success)
    }

  def run: IO[Unit] =
    (IO(println("started")) >>  loop(1) >> IO(println("exiting"))).onCancel(IO(println("canceled")))
}