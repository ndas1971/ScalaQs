//sbt "runMain akkahttp.basic.WebServer arg1 arg2" 
package akkahttp.basic 
//READ- https://doc.akka.io/docs/akka-http/current/implications-of-streaming-http-entity.html#consuming-the-http-request-entity-server-

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.stream.ActorMaterializer
import scala.io.StdIn
import java.nio.file.Paths
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import org.apache.log4j.Logger
import scala.concurrent.duration._
import akka.event.Logging 
import akka._ 
import java.io.File

import akka.http.scaladsl.model._
import akka.http.scaladsl.server._   //Directive, RejectionHandler
import akka.http.scaladsl.server.Directives._  //core of the Routing DSL
import akka.http.scaladsl.model.headers._
import akka.http.scaladsl.server.directives._  // DebuggingDirectives etc
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import spray.json.DefaultJsonProtocol._
import com.typesafe.config.ConfigFactory


//session 
import com.softwaremill.session.SessionDirectives._
import com.softwaremill.session.SessionOptions._
import com.softwaremill.session.SessionResult._
import com.softwaremill.session._
import scala.util.Try
import com.softwaremill.session.CsrfDirectives._
import com.softwaremill.session.CsrfOptions._

/*
trait SessionSerializer[T, R] {
  def serialize(t: T): R
  def deserialize(r: R): Try[T]
}
*/
case class ComplexSession(username: String, role:String)
object ComplexSession{ 
  implicit def serializer: SessionSerializer[ComplexSession, String] = 
    //MultiValueSessionSerializer[T](toMap: T => Map[String, String], fromMap: Map[String, String] => Try[T])  extends SessionSerializer[T, String]
    new MultiValueSessionSerializer[ComplexSession] (
        (sco: ComplexSession) => Map("username" -> sco.username, "role"-> sco.role),
        (m: Map[String, String]) => Try(new ComplexSession(m("username"), m("role")))
    )
}
case class MyScalaSession(username: String)
object MyScalaSession {
  implicit def serializer: SessionSerializer[MyScalaSession, String] =
    //class SingleValueSessionSerializer[T, V](toValue: T => V, fromValue: V => Try[T])
    new SingleValueSessionSerializer(_.username,
                                     (un: String) =>
                                       Try {
                                         MyScalaSession(un)
                                     })
}

//custom handling 
import akka.http.scaladsl.marshalling._ 
import scala.util.control.NonFatal
import akka.http.scaladsl.model._
import akka.http.scaladsl.util.FastFuture
import akka.http.scaladsl.util.FastFuture._
import scala.concurrent.{ ExecutionContext, Future }

case class MyModel(name:String){
    def toHtml = s"""<h1>Hello ${name}</h1>"""
    def toJson = s"""{"name": "$name"}"""
    def toXml = s"""<data><name>$name</name></data>"""
}
object MyModel {

    val logger = Logger.getLogger("main application")
    def fromXml(s:String):MyModel = {
        val xmls = _root_.scala.xml.XML.loadString(s) 
        val name = (xmls \ "name").text
        new MyModel(name)
    }
    import play.api.libs.json._ 
    def fromJson(s:String):MyModel = {
        val jsons = Json.parse(s).as[JsObject]
        val name = (jsons \ "name").as[String] 
        new MyModel(name)
    }
    
    // Marshaller[A, B] does the content negotiation
    //when use def complete[T :ToResponseMarshaller](value: T): StandardRoute
    //check https://doc.akka.io/docs/akka-http/current/common/marshalling.html
    //Note content negotiation is nothing but parsing requests's Accept header and finding best match of 
    //accept's content-type with route produced(Marshalling) content-type   
    //Accept: text/html;charset=US-ASCII, text/html;charset=UTF-8, text/plain;charset=US-ASCII,text/plain;charset=UTF-8
    //Accept : text/html, application/xml;q=0.9, */*;q=0.8
    
    //Marshaller[-A, +B].apply(value: A)(implicit ec: ExecutionContext ): Future[List[Marshalling[B]]]
    //A:MyData, B:HttpEntity or  MessageEntity
    //type MessageEntity = RequestEntity //An entity that can be used for every HttpMessage,
    //trait RequestEntity extends HttpEntity with javadsl.model.RequestEntity with ResponseEntity 
    //type ToEntityMarshaller[A] = Marshaller[A, MessageEntity]
    //type ToResponseMarshaller[A] = Marshaller[A, HttpResponse]
    //complete(m: => ToResponseMarshallable): StandardRoute =
    //ToResponseMarshallable from implicit ToResponseMarshaller[A] from implicit ToEntityMarshaller[A]
    
    //For Single response , we could use below 
    //Marshaller[-A, +B].map[C](f: B => C): Marshaller[A, C] =...
    //Marshaller[-A, +B].wrap[C, D >: B](newMediaType: MediaType)(f: C => A)(implicit mto: ContentTypeOverrider[D]): Marshaller[C, D]
    //Marshaller[-A, +B].compose[C](f: C => A): Marshaller[C, B] 
    //Marshaller.strict[A, B](f: A => Marshalling[B]): Marshaller[A, B] 
    //Marshaller.oneOf[A, B](marshallers: Marshaller[A, B]*): Marshaller[A, B]
    //Marshaller.oneOf[T, A, B](values: T*)(f: T => Marshaller[A, B]): Marshaller[A, B] 
    //Marshaller.withFixedContentType[A, B](contentType: ContentType)(marshal: A => B): Marshaller[A, B]
    //Marshaller.withOpenCharset[A, B](mediaType: MediaType.WithOpenCharset)(marshal: (A, HttpCharset) => B): Marshaller[A, B] 
    //Marshaller. opaque[A, B](marshal: A => B): Marshaller[A, B] 
    //Marshaller.combined[A, B, C](marshal: A => B)(implicit m2: Marshaller[B, C]): Marshaller[A, C] 
    
    //Marshalling.WithFixedContentType[B](contentType: ContentType, marshal:() => B) extends Marshalling[A]
    //Marshalling.WithOpenCharset[B](mediaType: MediaType.WithOpenCharset,marshal:   HttpCharset => B) extends Marshalling[A] 
    //Marshalling.Opaque[B](marshal: () => B) extends Marshalling[A]               

    implicit val MyDataMarshaller: ToEntityMarshaller[MyModel]  = Marshaller.oneOf(
            Marshaller.withFixedContentType(ContentTypes.`application/json`)(myData => HttpEntity(ContentTypes.`application/json`, myData.toJson)),
            Marshaller.withOpenCharset(MediaTypes.`text/xml`) { (myData, cs) => HttpEntity(MediaTypes.`text/xml` withCharset cs, myData.toXml) },
            Marshaller.withOpenCharset(MediaTypes.`text/html`) { (myData, cs) => HttpEntity(MediaTypes.`text/html` withCharset cs, myData.toHtml) },
            Marshaller.withOpenCharset(MediaTypes.`application/xml`) { (myData, cs) => HttpEntity(MediaTypes.`text/xml` withCharset cs, myData.toXml) }
         )
    //another way 
    def handleBaseOnAccept(send:MyModel) = {
    (get & extract(_.request.header[Accept])) {  accept => //extract's closure is RequestContext
        logger.info(s"handleBaseOnAccept: $accept")
        accept match {
            case Some(x:Accept)  if x.mediaRanges.exists(_.matches(MediaTypes.`application/json`)) =>
                            logger.info(s"handleBaseOnAccept: json")
                            complete(HttpEntity(ContentTypes.`application/json`, send.toJson))
            case Some(x:Accept)  if x.mediaRanges.exists(_.matches(MediaTypes.`text/xml`)) =>
                            logger.info(s"handleBaseOnAccept: xml")
                            complete(HttpEntity(ContentTypes.`text/xml(UTF-8)`, send.toXml))
            case Some(x:Accept)  if x.mediaRanges.exists(_.matches(MediaTypes.`text/html`))   => 
                            logger.info(s"handleBaseOnAccept: html")                    
                            complete(HttpEntity(ContentTypes.`text/html(UTF-8)`, send.toHtml))
            case Some(x:Accept) => 
                            logger.info(s"handleBaseOnAccept: default case, fails with UnacceptedResponseContentTypeRejection")  
                            complete(HttpEntity(ContentTypes.`application/json`, send.toJson))
        }        
      }
    }    

    //UnMarshalling 
    import akka.http.scaladsl.unmarshalling._
    import akka.http.scaladsl.model.ContentTypeRange._
    val contentTypeRanges:Seq[ContentTypeRange] = Seq( MediaTypes.`application/json` ,
                            MediaTypes.`text/xml`,
                            MediaTypes.`application/xml`)
    implicit val myDataUnmarshaller: FromEntityUnmarshaller[MyModel] =
        PredefinedFromEntityUnmarshallers.stringUnmarshaller.forContentTypes( contentTypeRanges : _*) .mapWithInput { (entity, string) => 
                val httpCharset = Unmarshaller.bestUnmarshallingCharsetFor(entity)
                entity.contentType match {
                    case ContentTypes.`application/json` => 
                            MyModel.fromJson(string)              
                    case  ContentType.WithCharset(MediaTypes.`text/xml`, `httpCharset`) |
                          ContentType.WithCharset(MediaTypes.`application/xml`, `httpCharset`) |
                          //below not required, but just to showcase 
                          ContentType.WithMissingCharset(MediaTypes.`text/xml`) |
                          ContentType.WithMissingCharset(MediaTypes.`application/xml`) =>
                            MyModel.fromXml(string)
                    //ContentType.Binary(_) | ContentType.WithMissingCharset(_)
                    case x:ContentType.NonBinary =>  throw Unmarshaller.UnsupportedContentTypeException(contentTypeRanges : _*)
                }        
            }    
        
}    
    

object WebServer {
  final case class Data(name: String)
   // formats for unmarshalling and marshalling
  //jsonFormatX, X is number of constructor fields
  implicit val dataFormat = jsonFormat1(Data)

  def main(args: Array[String]) {
    implicit val system = ActorSystem("test_system", ConfigFactory.load("advanced.conf"))
    //implicit val materializer = ActorMaterializer()   //A ActorMaterializer takes the list of transformations comprising a Flow and materializes them actual values 
    implicit val executionContext = system.dispatcher  // needed for the future flatMap/onComplete in the end
    import ContentTypeResolver.Default
    
    val uploadDir = "uploads"
    (new java.io.File(uploadDir)).mkdirs()
    val logger = Logger.getLogger("main application")
    
    //session 
    val sessionConfig = SessionConfig.default("some_very_long_secret_and_random_string_some_very_long_secret_and_random_string")
    implicit val sessionManager = new SessionManager[MyScalaSession](sessionConfig)
    implicit val refreshTokenStorage = new InMemoryRefreshTokenStorage[MyScalaSession] {
      def log(msg: String) = logger.info(msg)
    }
    def mySetSession(v: MyScalaSession) = setSession(refreshable, usingCookies, v)
    val myRequiredSession = requiredSession(refreshable, usingCookies)
    val myInvalidateSession = invalidateSession(refreshable, usingCookies)
    
    //Custom directive 
    //inner is inner closure which takes T of Directive[T], ctx = HttpRequestContext 
    def hostnameAndPort: Directive[(String, Int)] = Directive[(String, Int)] { inner => ctx => 
      val authority = ctx.request.uri.authority  
      inner((authority.host.address(), authority.port))(ctx)
    }
    //Custom Rejectionhandler 
    implicit def myRejectionHandler =
        RejectionHandler.newBuilder()
         .handle {
             case ValidationRejection(msg, _) =>
               complete((StatusCodes.InternalServerError, "That wasn't valid! " + msg))
          }                     
          .handleAll[MethodRejection] { methodRejections =>
            val names = methodRejections.map(_.supported.name)
            complete((StatusCodes.MethodNotAllowed, s"Can't do that! Supported: ${names mkString " or "}!"))
          }
          .handleNotFound { complete((StatusCodes.NotFound, "Not here!")) }
          .result()
    
    
    implicit def myExceptionHandler: ExceptionHandler =
        ExceptionHandler {
          case _: ArithmeticException =>
            extractUri { uri =>
              println(s"Request to $uri could not be handled normally")
              complete(HttpResponse(StatusCodes.InternalServerError, entity = "Bad numbers, bad result!!!"))
            }
        }
        
    
   
    
    /*
    rawPathPrefix(x): it matches x and leaves a suffix (if any) unmatched.
    pathPrefix(x): is equivalent to rawPathPrefix(Slash ~ x). It matches a leading slash followed by x and then leaves a suffix unmatched.
    path(x): is equivalent to rawPathPrefix(Slash ~ x ~ PathEnd). It matches a leading slash followed by x and then the end.
    pathEnd: is equivalent to just rawPathPrefix(PathEnd). It is matched only when there is nothing left to match from the path. This directive should not be used at the root as the minimal path is the single slash.
    pathSingleSlash: is equivalent to rawPathPrefix(Slash ~ PathEnd). It matches when the remaining path is just a single slash.
    pathEndOrSingleSlash: is equivalent to rawPathPrefix(PathEnd) or rawPathPrefix(Slash ~ PathEnd). It matches either when there is no remaining path or is just a single slash.
    */
    //if we start with path , continue with path 
    // if we start with method, confitinue with method 
    val route =
      pathSingleSlash {
       get {
          // curl -v http://localhost:5050/
           complete(HttpEntity(ContentTypes.`text/html(UTF-8)`,"<html><body>Hello world!</body></html>"))
       } 
      } ~
      // curl -v http://localhost:5050/ping 
      path("ping") {
       get{
            val localhostname = java.net.InetAddress.getLocalHost.getHostName
            complete(s"You've hit ${localhostname}")
        }
      } ~
      // curl -v http://localhost:5050/crash 
      path("crash") {
        get{
            reject( ValidationRejection("crash", None) ) 
            //sys.error("BOOM!")
          }
      } ~
      // curl -v http://localhost:5050/divide
      path("divide") {
          complete((1 / 0).toString) //Will throw ArithmeticException
      } ~
       // this one takes `myExceptionHandler` implicitly
      //curl -s http://localhost:5050/foo?location=uk
      //() is must , Note instead path("foo")  http://localhost:5050/foo/?location=uk
      (pathPrefix("foo") & parameter("location" ? "uk")) { loc => //location is optional  
          //parameters('location, 'format ? "json") { (loc, format) =>   
          get {
              complete(s"foo: ${loc}")
          }
      } ~
      //curl -s http://localhost:5050/json/das
      //curl -s http://localhost:5050/json/
      path("json" / Segment.?) { opt =>         
        get {        
          val name = opt.getOrElse("world")
          val json_str = s"""{"hello" : "${name}"}"""
          complete(HttpEntity(ContentTypes.`application/json`, json_str))
       }
      } ~ 
      //curl -s -X POST -d "name=Das&key=value" -H "Content-Type: application/x-www-form-urlencoded" http://localhost:5050/submit
      path("submit"){
        post{
            formFieldMap { fields => //Map[String,String]
                val name = fields.getOrElse("name", "world")
                complete(s"Hello ${name}!")
            }
        }
      } ~
      //curl -s  -d '{"name":"value1"}' -H "Content-Type: application/json" -X POST http://localhost:5050/jsubmit
      path("jsubmit"){
        post{
            entity(as[Data]) { data =>
                val name = data.name
                complete(Data(s"Hello ${name}")) //json return 
            }
        }
      }~
     //curl -s -F 'file=@passwd' -X POST http://localhost:5050/upload
     //but redirect so 
     //curl -s -F 'file=@passwd' -L -o passwd.2 -X POST http://localhost:5050/upload
      path("upload") {        
        get {
          complete(HttpEntity(ContentTypes.`text/html(UTF-8)`,
                """<!doctype html>
                    <html><body>
                    <title>Upload new File</title>
                    <h1>Upload new File</h1>
                    <form method=post enctype=multipart/form-data>
                      <input type=file name=file>
                      <input type=text value="your name" name=username> 
                      <input type=submit value=Upload>
                    </form>
                    </body></html>
                    """))
        } ~
        toStrictEntity(3.seconds) { //load full into memory in 3 seconds 
         //withSizeLimit(8*1024*1024) {  //default 8M 
         //OR 
         //withoutSizeLimit {
            post {
              //for multiple files, check storeUploadedFiles
              //Error: Substream Source cannot be materialized more than once 
              //OK if only file form field or toStrictEntity   
              //uploadedFile("file")
              //             
              ( formField("username") & storeUploadedFile("file", _ => File.createTempFile("akka-http-upload", ".tmp")).tmap(Tuple1(_)) ){ (username, fileT) =>   //case (metadata, source)/
                    val (metadata, source) = fileT //(akka.FileInfo, File) 
                    logger.info(s"$username, $metadata, $source")
                    // store to uploads dir 
                    val dest = Paths.get(uploadDir, metadata.getFileName)
                    Files.copy(source.toPath(), dest, StandardCopyOption.REPLACE_EXISTING)
                    source.delete()
                    //Note ParmanentRedirect/Temporaryredirect are 309/308 which uses current METHOD 
                    redirect(s"/download/${metadata.getFileName}", StatusCodes.SeeOther)
                    //logger.info("Done redirect")
                    //complete(StatusCodes.OK)
               } 
            }
        }
      } ~
     //curl -s -o bill2.txt http://localhost:5050/download/bill.txt
     path("download" / Segment) { name =>
     get{
       respondWithHeader(`Content-Disposition`(ContentDispositionTypes.attachment, Map("filename"-> name))) { 
            val dest = Paths.get(uploadDir, name).toString()               
            getFromFile(dest) // uses implicit ContentTypeResolver
      }
     }
    } ~
    //https://github.com/softwaremill/akka-http-session/blob/master/example/src/main/scala/com/softwaremill/example/ScalaExample.scala
    //Session , this is via cookie so , -c for save, -b for read 
    //curl -v -c cookie.txt  http://localhost:5050/set/das
    path("set" / Segment ) { name =>
      get{
        mySetSession(MyScalaSession(name)) {  
            complete(s"Set: ${name}") 
        }  
      }
    } ~
    //curl -v -b cookie.txt  http://localhost:5050/get
    path("get") { 
      get{
       myRequiredSession { session => ctx =>
              logger.info("Current session: " + session)
              ctx.complete(s"GET: ${session.username}")
          }
      }
    } ~
    //curl -v -b cookie.txt http://localhost:5050/remove
    path("remove" ) { 
      get{
       myRequiredSession { session =>
              myInvalidateSession { ctx =>
                logger.info(s"removing $session")
                ctx.complete(s"Removed: ${session.username}")
              }
            }
      }
    } ~ 
    //curl -v  http://localhost:5050/custom
    path("custom"){
        hostnameAndPort {(hostname, port) => 
            complete(s"The hostname is $hostname and the port is $port")
        } 
    } ~
    //curl -v  -H "Accept: text/csv" http://localhost:5050/acceptv1/das
    //curl -v  -H "Accept: application/json" http://localhost:5050/acceptv1/das
    //curl -v  -H "Accept: text/xml" http://localhost:5050/acceptv1/das
    //curl -v  -H "Accept: text/html" http://localhost:5050/acceptv1/das
    path("acceptv1" / Segment){ name =>
        MyModel.handleBaseOnAccept(MyModel(name)) 
    } ~
    //curl -v  -H "Accept: text/csv" http://localhost:5050/acceptv2/das
    //curl -v  -H "Accept: application/json" http://localhost:5050/acceptv2/das
    //curl -v  -H "Accept: text/xml" http://localhost:5050/acceptv2/das
    //curl -v  -H "Accept: text/html" http://localhost:5050/acceptv2/das
    path("acceptv2" / Segment){ name =>
        complete(MyModel(name)) 
    } ~
    //curl -v  -d '{"name":"das"}' -H "Content-Type: application/json" -X POST http://localhost:5050/parsev2
    //curl -v  -d '<data><name>das</name></data>' -H "Content-Type: text/xml" -X POST http://localhost:5050/parsev2
    path("parsev2" ){ 
      post{
        entity(as[MyModel]){ myModel =>
            complete(s"parsev2: ${myModel.name}")
        }
      }
    }
    
    // `route` will be implicitly converted to `Flow` using `RouteResult.route2HandlerFlow`
    val clientRouteLogged = DebuggingDirectives.logRequestResult(("REQUEST", Logging.InfoLevel))(route)
    val bindingFuture = Http().bindAndHandle(clientRouteLogged, "localhost", 5050)
    println(s"Server online at http://localhost:5050/\nPress RETURN to stop...")
    StdIn.readLine() // let it run until user presses return
    bindingFuture
      .flatMap(_.unbind()) // trigger unbinding from the port
      .onComplete(_ => system.terminate()) // and shutdown when done
  }
}
