object CubeCalculator extends App {
  def cube(x: Int) = {
    x * x * x
  }
}