package remoting 
import akka.actor._
import com.typesafe.config.ConfigFactory
import scala.concurrent._

//Marker interface for messages, events and snapshots that are serialized with Jackson.
trait MyTraitSerializable

final case class Message(name: String) extends MyTraitSerializable
final case class Result(name: String) extends MyTraitSerializable

object Helper{
    val remoteWorkerConf = "remoteWorker.conf"
    val customerConf = "remoteApplication.conf"
    val actorSystemremoteWorker = "RemoteWorker"
    val actorSystemCustomer = "Customer"
    val workerName = "Worker"
    val customerName = "Asker"
    val dispatcherName = "blocking-dispatcher"
    val host = "127.0.0.1"
    val remoteHost = 25521
    val customerHost = 25520
    val ownName = s"akka://$actorSystemCustomer@$host:$customerHost/user/$customerName"
    val remoteWorkerName = s"akka://$actorSystemremoteWorker@$host:$remoteHost/user/$workerName"
    val remoteWorkerNameDeploy = s"akka://$actorSystemremoteWorker@$host:$remoteHost/remote/akka/$actorSystemCustomer@$host:$customerHost/user/Worker"
}

object Store extends App{
  val system = ActorSystem(Helper.actorSystemremoteWorker, ConfigFactory.load(Helper.remoteWorkerConf))
  println("Ready for next 10 minutes")
  import system.dispatcher 
  
  if (args.isEmpty){
    println("Got no args,  so starting")
    val actor = system.actorOf(Worker.props, Helper.workerName)
    println(s"started $actor")
  } else {
    println("Remote deploy mode, Start client with any args")
  }
  Thread.sleep(10*60*1000)
  system.terminate.foreach{ _ => "Terminated"}
}

object Worker {
  def props: Props = Props(new Worker).withDispatcher(Helper.dispatcherName)
}
class Worker extends Actor with ActorLogging{
  log.info(s"Got $self: Starting Worker")
  override def receive: Receive = {
    case Message(anyString) =>
      log.info(s"Got $self: $anyString")
      sender() ! Result(anyString.reverse)     
  }
}
object Asker {
  def props(name:String): Props = Props(new Asker(name)).withDispatcher(Helper.dispatcherName)
}
class Asker(val name:String) extends Actor with ActorLogging{
  import context.dispatcher //brings ExecutionContext 
  import akka.pattern._ 
  import scala.concurrent.duration._
  import scala.concurrent._
 
  
  override def receive: Receive = {
    case Message(anyString) => handle(anyString)
    case Result(anyString) =>handle(anyString)
  }
  def handle(anyString:String):Unit = {
      log.info(s"Got $self: $anyString")
      Thread.sleep(1000)          
      createRemoteWorker.foreach{ ar => ar ! Message(anyString)}
  }
  
  def getWorker: ActorSelection = {    
    println(s"Sending to $name")
    context.actorSelection(name) //default ownsystem, 
   }
  def createRemoteWorker: Future[ActorRef] = {
    //every time, it creates the actor, actors with same name gives error 
    //so old actor must be stopped 
    getWorker.resolveOne(1.seconds).recover{
        case _ => context.system.actorOf(Worker.props, Helper.workerName)
    }
   }
}

object Customer extends App{
    demo()
    
    def demo():Unit = {
        import Helper._ 
        println("Worker Remote must be running in another window")
        val system = ActorSystem(actorSystemCustomer, ConfigFactory.load(customerConf))
        val remoteModeOn =  if (args.isEmpty){
            println("Got no args,  so no remote deploy")            
            false
          } else {
            println("Remote deploy mode")
            true
          }
 
         val asker = system.actorOf(Asker.props(if(remoteModeOn) remoteWorkerNameDeploy else remoteWorkerName), customerName)
        //val worker = system.actorOf(Worker.props, Helper.workerName)
        
        import akka.pattern._ 
        import scala.concurrent.duration._
        import scala.concurrent._
        import system.dispatcher //brings ExecutionContext 

        //asker ! "IAMREMOTING"
        val fut = system.actorSelection(ownName).resolveOne(5.seconds).foreach{ ar => 
            ar ! Message("IAMREMOTING")
        }
        system.scheduler.scheduleOnce(60.seconds){
            asker ! PoisonPill
        } 
        
        Thread.sleep(3*30*1000)
        system.terminate.foreach{ _ => "Terminated"}
    }    

}