package typedclusteringrouting 

import akka.actor.typed.scaladsl._
import akka.cluster.ClusterEvent._
import akka.cluster.typed._
import akka.actor.typed._

import scala.concurrent.duration._ 
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import akka.util._
import akka._
import akka.actor.typed.receptionist._
import scala.util._ 

import typedclustering.CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "TypedClusterSystem"
    val clusterMainApp = "typedclusterMainApp.conf"      
    val sleeptime = 10*60*1000
    
    def killThisSystem[X](system:ActorSystem[X], sleeptime:Int=sleeptime):Unit = {    
        Thread.sleep(sleeptime)
        system.terminate()
    }

}

object ClusterRouter {
  
  val StatsServiceKey = ServiceKey[StatsService.ProcessText]("StatsService")

  private object RootBehavior {
    def apply(): Behavior[Nothing] = Behaviors.setup[Nothing] { ctx =>
      val cluster = Cluster(ctx.system)
      if (cluster.selfMember.hasRole("compute")) {
        // on every compute node there is one service instance that delegates to N local workers
        val numberOfWorkers = ctx.system.settings.config.getInt("stats-service.workers-per-node")
        val workers = ctx.spawn(Routers.pool(numberOfWorkers)(StatsWorker()), "WorkerRouter")
        
        val service = ctx.spawn(StatsService(workers),"StatsService")//frontend , delegates to one workers

        // published through the receptionist to the other nodes in the cluster
        ctx.system.receptionist ! Receptionist.Register(StatsServiceKey, service)
      }
      if (cluster.selfMember.hasRole(("client"))) {
        val serviceRouter = ctx.spawn(Routers.group(StatsServiceKey), "ServiceRouter")
        ctx.spawn(StatsClient(serviceRouter), "Client")
      }
      Behaviors.empty[Nothing]
    }
  }


  def main(args: Array[String]): Unit = {
    require(args.size == 2, "Usage: role port")
    startup(args(0), args(1).toInt)
  }

  private def startup(role: String, port: Int): Unit = {
    import Helper._ 
    // Override the configuration of the port when specified as program argument
    val config = ConfigFactory.parseString(s"""
      akka.remote.artery.canonical.port=$port
      akka.cluster.roles = [$role]
      """)
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem[Nothing](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }
}



object StatsService {

  sealed trait Command extends CborSerializable
  final case class ProcessText(text: String, replyTo: ActorRef[Response]) extends Command {
    require(text.nonEmpty)
  }
  case object Stop extends Command

  sealed trait Response extends CborSerializable
  final case class JobResult(meanWordLength: Double) extends Response
  final case class JobFailed(reason: String) extends Response

  def apply(workers: ActorRef[StatsWorker.Process]): Behavior[Command] =
    Behaviors.setup { ctx =>
      // if all workers would crash/stop we want to stop as well
      ctx.watch(workers)

      Behaviors.receiveMessage {
        case ProcessText(text, replyTo) =>
          ctx.log.info("Delegating request")
          val words = text.split(' ').toIndexedSeq
          // create per request actor that collects replies from workers
          ctx.spawnAnonymous(StatsAggregator(words, workers, replyTo))
          Behaviors.same
        case Stop =>
          Behaviors.stopped
      }
    }
}

object StatsAggregator {

  sealed trait Event
  private case object Timeout extends Event
  private case class CalculationComplete(length: Int) extends Event

  def apply(words: Seq[String], workers: ActorRef[StatsWorker.Process], replyTo: ActorRef[StatsService.Response]): Behavior[Event] =
    Behaviors.setup { ctx =>
      ctx.setReceiveTimeout(3.seconds, Timeout)
      val responseAdapter = ctx.messageAdapter[StatsWorker.Processed](processed =>
        CalculationComplete(processed.length)
      )

      words.foreach { word =>
        workers ! StatsWorker.Process(word, responseAdapter)
      }
      waiting(replyTo, words.size, Nil)
    }

  private def waiting(replyTo: ActorRef[StatsService.Response], expectedResponses: Int, results: List[Int]): Behavior[Event] =
    Behaviors.receiveMessage {
      case CalculationComplete(length) =>
        val newResults = results :+ length
        if (newResults.size == expectedResponses) {
          val meanWordLength = newResults.sum.toDouble / newResults.size
          replyTo ! StatsService.JobResult(meanWordLength)
          Behaviors.stopped
        } else {
          waiting(replyTo, expectedResponses, newResults)
        }
      case Timeout =>
        replyTo ! StatsService.JobFailed("Service unavailable, try again later")
        Behaviors.stopped
    }

}
object StatsWorker {

  trait Command
  final case class Process(word: String, replyTo: ActorRef[Processed]) extends Command with CborSerializable
  private case object EvictCache extends Command

  final case class Processed(word: String, length: Int) extends CborSerializable

  def apply(): Behavior[Command] = Behaviors.setup { ctx =>
    Behaviors.withTimers { timers =>
      ctx.log.info("Worker starting up")
      timers.startTimerWithFixedDelay(EvictCache, EvictCache, 30.seconds)

      withCache(ctx, Map.empty)
    }
  }

  private def withCache(ctx: ActorContext[Command], cache: Map[String, Int]): Behavior[Command] = Behaviors.receiveMessage {
    case Process(word, replyTo) =>
      ctx.log.info("Worker processing request")
      cache.get(word) match {
        case Some(length) =>
          replyTo ! Processed(word, length)
          Behaviors.same
        case None =>
          val length = word.length
          val updatedCache = cache + (word -> length)
          replyTo ! Processed(word, length)
          withCache(ctx, updatedCache)
      }
    case EvictCache =>
      withCache(ctx, Map.empty)
  }
}

object StatsClient {

  sealed trait Event
  private case object Tick extends Event
  private case class ServiceResponse(result: StatsService.Response) extends Event

  def apply(service: ActorRef[StatsService.ProcessText]): Behavior[Event] =
    Behaviors.setup { ctx =>
      Behaviors.withTimers { timers =>
        timers.startTimerWithFixedDelay(Tick, Tick, 2.seconds)
        val responseAdapter = ctx.messageAdapter(ServiceResponse)

        Behaviors.receiveMessage {
          case Tick =>
            ctx.log.info("Sending process request")
            service ! StatsService.ProcessText("this is the text that will be analyzed", responseAdapter)
            Behaviors.same
          case ServiceResponse(result) =>
            ctx.log.info("Service result: {}", result)
            Behaviors.same
        }
      }
    }

}

object ClusterRouterSingleton {

  val WorkerServiceKey = ServiceKey[StatsWorker.Process]("Worker")

  object RootBehavior {
    def apply(): Behavior[Nothing] = Behaviors.setup[Nothing] { ctx =>
      val cluster = Cluster(ctx.system)

      val singletonSettings = ClusterSingletonSettings(ctx.system).withRole("compute")
      
      //def apply[M](behavior: Behavior[M], name: String): SingletonActor[M] 
      val serviceSingleton = SingletonActor(
        Behaviors.setup[StatsService.Command] { ctx =>
          // the service singleton accesses available workers through a group router
          val workersRouter = ctx.spawn(Routers.group(WorkerServiceKey), "WorkersRouter")
          StatsService(workersRouter)
        },
        "StatsService"
      ).withStopMessage(StatsService.Stop)
        .withSettings(singletonSettings)
        
      val serviceProxy = ClusterSingleton(ctx.system).init(serviceSingleton)

      if (cluster.selfMember.hasRole("compute")) {
        // on every compute node N local workers, which a cluster singleton stats service delegates work to
        val numberOfWorkers = ctx.system.settings.config.getInt("stats-service.workers-per-node")
        ctx.log.warn("Starting {} workers", numberOfWorkers)
        (0 to numberOfWorkers).foreach { n =>
          val worker = ctx.spawn(StatsWorker(), s"StatsWorker$n")
          //Add to group router 
          ctx.system.receptionist ! Receptionist.Register(WorkerServiceKey, worker)
        }
      }
      if (cluster.selfMember.hasRole("client")) {
        ctx.spawn(StatsClient(serviceProxy), "Client")
      }
      Behaviors.empty
    }
  }

  def main(args: Array[String]): Unit = {
      require(args.size == 2, "Usage: role port")
      startup(args(0), args(1).toInt)
  }

  def startup(role: String, port: Int): Unit = {
    import Helper._ 
    // Override the configuration of the port when specified as program argument
    val config = ConfigFactory.parseString(s"""
      akka.remote.artery.canonical.port=$port
      akka.cluster.roles = [compute]
      """)
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem[Nothing](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }

}
