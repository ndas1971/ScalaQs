package typedcqrs

import akka.cluster.typed._
import akka.actor.typed._
import akka.actor.typed.scaladsl._
import akka.actor.typed.receptionist._
import akka.stream.Materializer
import akka.stream.scaladsl._
import akka.stream.typed.scaladsl._

import akka.cluster.sharding.typed._
import akka.cluster.sharding.typed.scaladsl._
import akka.persistence.typed._
import akka.persistence.typed.scaladsl._
import akka.persistence.query.{PersistenceQuery, EventEnvelope}
import akka.persistence.jdbc.query.scaladsl.JdbcReadJournal


import scala.concurrent.duration._ 
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import akka.util._
import akka._
import scala.util._ 


import typedclustering.CborSerializable  //To make serializations
import typedpersistence.HelloWorldService


object Helper {
    val clusterActorSystem = "TypedClusterSystem"
    val clusterMainApp = "typedcqrs.conf"      
    val sleeptime = 10*60*1000
    
    def killThisSystem[X](system:ActorSystem[X], sleeptime:Int=sleeptime):Unit = {    
        Thread.sleep(sleeptime)
        system.terminate()
    }

}

object ClusterShardingPersistanceCQRSExample {
  
  object RootBehavior {
    sealed trait Event extends CborSerializable
    private case object Query extends Event
    private final case class Result(value:List[(String, Int)]) extends Event
    private final case class QueryResultPerId(value:String) extends Event
    private final case class QueryResultEventEnvelope(value:EventEnvelope) extends Event
    private final case object Complete extends Event
    private final case class Fail(ex: Throwable) extends Event
    
    
    def apply(): Behavior[Event] = Behaviors.setup[Event] { ctx =>
      implicit val system = ctx.system 
      implicit val ec = system.executionContext
      implicit val mat: Materializer = Materializer(system)
      val cluster = Cluster(system)     
      val readJournal: JdbcReadJournal = 
         PersistenceQuery(system).readJournalFor[JdbcReadJournal](JdbcReadJournal.Identifier) //String("jdbc-read-journal")
      
      
      //ActorSink.actorRef[T](ref: ActorRef[T], onCompleteMessage: T, onFailureMessage: (Throwable) => T): Sink[T, NotUsed]
      val sink: Sink[Event, NotUsed] =
         ActorSink.actorRef[Event](ref = ctx.self, onCompleteMessage = Complete, onFailureMessage = Fail.apply)

      /*
      Source[+Out, +Mat].runWith[Mat2](sink: Graph[SinkShape[Out], Mat2])(implicit materializer: Materializer): Mat2
      
      Source[+Out, +Mat].to[Mat2](sink: Graph[SinkShape[Out], Mat2]): RunnableGraph[Mat]
      Source[+Out, +Mat].toMat[Mat2, Mat3](sink: Graph[SinkShape[Out], Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]
      RunnableGraph[+Mat].run()(implicit materializer: Materializer): Mat
      
      Source[+Out, +Mat].run()(implicit materializer: Materializer): Future[Done] //to Sink.ignore
      Source[+Out, +Mat].runForeach(f: (Out) => Unit)(implicit materializer: Materializer): Future[Done]
      Source[+Out, +Mat].runFold[U](zero: U)(f: (U, Out) => U)(implicit materializer: Materializer): Future[U]
       
       Sink.foreach[T](f: (T) => Unit): Sink[T, Future[Done]]
       Sink.seq[T]: Sink[T, Future[Seq[T]]]
       Sink.ignore: Sink[Any, Future[Done]]
       
       Source[+Out, +Mat].flatMapConcat[T, M](f: (Out) => Graph[SourceShape[T], M]): Source[T, +Mat] //fully consumes each Source
       Source[+Out, +Mat].flatMapMerge[T, M](breadth: Int, f: (Out) => Graph[SourceShape[T], M]): Source[T, +Mat] //full consumes breadth no of Source

      */      

        //will not complete Stream and keeps on pusing new PersistanceId 
        readJournal.persistenceIds()  //Source[String, NotUsed]
                   .map { id => QueryResultPerId(id)}
                   .runWith(sink)   
                   
       //val willCompleteTheStream2: Source[String, NotUsed] = readJournal.currentPersistenceIds()      
      val service = new HelloWorldService(system) //in persistence-sharding file      
      val all = for {
        a <- service.greet("hello-world-1", "Alice") 
        b <- service.greet("hello-world-1", "World")
        c <- service.greet("hello-world-2", "Bob")
        d <- service.greet("hello-world-2", "Goes")
        e <- service.greet("hello-world-3", "Office")      
      } yield {
          List(a,b,c,d,e)
      }
      
      all.map{ list =>
        ctx.self ! Result(list)
      }
      
      Behaviors.withTimers { timers =>
        timers.startSingleTimer(Query, Query, 5.seconds)
        Behaviors.receiveMessage {
          case Query =>
            ctx.log.warn("PersistanceQuery")
            readJournal.currentPersistenceIds()
              .flatMapConcat{id => 
                   readJournal.currentEventsByPersistenceId(id, 0L, Long.MaxValue) // Source[EventEnvelope, NotUsed]
               }
              .map { envelop => QueryResultEventEnvelope(envelop)}
              .runWith(sink)  
            Behaviors.same
          case Result(value) =>
            ctx.log.warn("result {}", value) 
            Behaviors.same
          case evt =>
            ctx.log.warn("Event {}", evt) 
            Behaviors.same
        }
      }
      
    }
  }

  def main(args: Array[String]): Unit = {
    require(args.size == 2, "Usage: role port")
    startup(args(0), args(1).toInt)
  }

  def startup(role: String, port: Int): Unit = {
    // Override the configuration of the port and role
    import Helper._ 
    val config = ConfigFactory.parseString(s"""
        akka.remote.artery.canonical.port=$port
        akka.cluster.roles = [$role]
        """)
      .withFallback(ConfigFactory.load(clusterMainApp))  //clusterMainApp.conf


    implicit val system = ActorSystem[RootBehavior.Event](RootBehavior(), clusterActorSystem, config)
    implicit val ec = system.executionContext
        
    import akka.persistence.jdbc.testkit.scaladsl.SchemaUtils

   //DropCreate.dropCreate()
    val done: Future[Done] = SchemaUtils.createIfNotExists()

    done.foreach{_ => println("SChema Created") }
    
    killThisSystem(system)

  }

}


//If schemaCreation is required 
import java.io.InputStream
import scala.io.{ Source => ScalaIOSource }
import com.typesafe.config.{ Config, ConfigFactory, ConfigValue }
import scala.concurrent.ExecutionContext.Implicits.global
import slick.jdbc.JdbcProfile
import slick.basic.DatabaseConfig

object ClasspathResources extends ClasspathResources

trait ClasspathResources {
  def streamToString(is: InputStream): String =
    ScalaIOSource.fromInputStream(is).mkString

  def fromClasspathAsString(fileName: String): String =
    streamToString(fromClasspathAsStream(fileName))

  def fromClasspathAsStream(fileName: String): InputStream =
    getClass.getClassLoader.getResourceAsStream(fileName)
}




object DropCreate extends ClasspathResources {
  def db = {
    val cfg = ConfigFactory.load("typedcqrs.conf")  
    //For profile, open the conf like below 
    //for old style conf, you can use Database.forConfig("h2mem", cfg)
    DatabaseConfig.forConfig[JdbcProfile]("slick", cfg).db
  }

  def dropCreate(schema: String = "h2-schema.sql"): Unit = create(schema)

  def create(schema: String, separator: String = ";"): Unit =
    for {
      schema <- Option(fromClasspathAsString(schema))
      ddl <- for {
        trimmedLine <- schema.split(separator).map(_.trim)
        if trimmedLine.nonEmpty
      } yield trimmedLine
    } withStatement { stmt =>
      try stmt.executeUpdate(ddl)
      catch {
        case t: java.sql.SQLSyntaxErrorException if t.getMessage contains "ORA-00942" => // suppress known error message in the test
      }
    }

  def withDatabase[A](f: slick.jdbc.JdbcProfile#Backend#Database => A): A =
    try f(db)
    finally db.close()

  def withSession[A](f: slick.jdbc.JdbcProfile#Backend#Session => A): A = {
    withDatabase { db =>
      val session = db.createSession()
      try f(session)
      finally session.close()
    }
  }

  def withStatement[A](f: java.sql.Statement => A): A =
    withSession(session => session.withStatement()(f))
    
  def withResultSet[A,B](sql:String)(f: java.sql.ResultSet => A)(res: Iterator[A] => B):B = 
    withStatement { stmt =>
        val rs = stmt.executeQuery(sql)
        val it = new Iterator[A] {
          def hasNext = rs.next()
          def next() = f(rs) //eg {r => (r.getString(1),r.getDouble(2))}
        }
        res(it)
    }
    
}