package typedpersistence

import akka.actor.typed.scaladsl._
import akka.cluster.ClusterEvent._
import akka.cluster.typed._
import akka.actor.typed._
import akka.cluster.sharding.typed._
import akka.cluster.sharding.typed.scaladsl._
import akka.persistence.typed._
import akka.persistence.typed.scaladsl._

import scala.concurrent.duration._ 
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import akka.util._
import akka._
import akka.actor.typed.receptionist._
import scala.util._ 

import typedclustering.CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "TypedClusterSystem"
    val clusterMainApp = "typedclusterMainApp.conf"      
    val sleeptime = 10*60*1000
    
    def killThisSystem[X](system:ActorSystem[X], sleeptime:Int=sleeptime):Unit = {    
        Thread.sleep(sleeptime)
        system.terminate()
    }

}

object ClusterShardingPersistanceExample { 
 
  
  object RootBehavior {
    
    def apply(): Behavior[List[(String, Int)]] = Behaviors.setup[List[(String, Int)]] { ctx =>
    
      val cluster = Cluster(ctx.system)     
      val service = new HelloWorldService(ctx.system)
      
      implicit val ec = ctx.system.executionContext
      
      val all = for {
        a <- service.greet("hello-world-1", "Alice") //1st Arg is used to create unique entityId
        b <- service.greet("hello-world-1", "World")
        c <- service.greet("hello-world-2", "Bob")
        d <- service.greet("hello-world-2", "Goes")
        e <- service.greet("hello-world-3", "Office")      
      } yield {
          List(a,b,c,d,e)
      }
      
      all.map{ list =>
        ctx.self ! list
      }
      
      Behaviors.receiveMessage{
        case sx @ List(_*) => 
            ctx.log.warn("Result: {}", sx )
            Behaviors.same       
      }
      
    }
  }

  def main(args: Array[String]): Unit = {
    require(args.size == 1, "Usage: role port")
    startup(args(0), args(1).toInt)
  }

  def startup(role: String, port: Int): Unit = {
    import Helper._ 
    // Override the configuration of the port and role
    val config = ConfigFactory.parseString(s"""
        akka.remote.artery.canonical.port=$port
        akka.cluster.roles = [$role]
        """)
      .withFallback(ConfigFactory.load(clusterMainApp)) 

    val system = ActorSystem[List[(String, Int)]](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)

  }

}



class HelloWorldService(system: ActorSystem[_]) {
  import system.executionContext

  private val sharding = ClusterSharding(system)

  // registration at startup - create persistenceId as well as get EntityId from entityContext
  sharding.init(Entity(typeKey = HelloWorld.TypeKey) { entityContext =>
    // PersistenceId(entityTypeHint: String, entityId: String): PersistenceId 
    HelloWorld(entityContext.entityId, PersistenceId(entityContext.entityTypeKey.name, entityContext.entityId))
  })

  private implicit val askTimeout: Timeout = Timeout(5.seconds)

  def greet(worldId: String, whom: String): Future[(String, Int)] = {
    //Create entityId, this is used for searching Actor 
    // entityRefFor[M](typeKey: EntityTypeKey[M], entityId: String): EntityRef[M] 
    val entityRef = sharding.entityRefFor(HelloWorld.TypeKey, worldId)
    
    //EntityRef[-M].?[Res](message: (ActorRef[Res]) => M)(implicit timeout: Timeout): Future[Res]
    //val greeting = entityRef ?[HelloWorld.Greeting](replyTo =>  HelloWorld.Greet(whom)(replyTo))
    val greeting = entityRef ? HelloWorld.Greet(whom) 
    greeting.map(greeting => (greeting.whom, greeting.numberOfPeople) )
  }
}


//#persistent-entity
object HelloWorld {

  //Part of EntityId 
  val TypeKey: EntityTypeKey[Command] = EntityTypeKey[Command]("HelloWorld")

  // Command
  trait Command extends CborSerializable
  final case class Greet(whom: String)(val replyTo: ActorRef[Greeting]) extends Command
  // Response - numberOfPeople is cummulated no of people 
  final case class Greeting(whom: String, numberOfPeople: Int) extends CborSerializable

  // Event- this would be persisted 
  final case class Greeted(whom: String) extends CborSerializable

  // State- this would be restored in case of restart from Greeted event 
  final case class KnownPeople(names: Set[String]) extends CborSerializable {
    def add(name: String): KnownPeople = copy(names = names + name)
    def numberOfPeople: Int = names.size
  }

  //(the current State , the incoming Command), Must Return Effect[+Event, State] 
  //Events are persisted , Greeted is Event , KnownPeople is State, Command is command 
  private val commandHandler: (KnownPeople, Command) => Effect[Greeted, KnownPeople] = { (state, cmd) =>
    cmd match {
      case cmd: Greet => greet(cmd)
    }
  }

  private def greet(cmd: Greet): Effect[Greeted, KnownPeople] =
    // Effect.persist[Event, State](event: Event): EffectBuilder[Event, State]
    //EffectBuilder[+Event, State].thenRun(callback: (State) => Unit): EffectBuilder[Event, State]
    Effect.persist(Greeted(cmd.whom))  //persist Greeted event 
          .thenRun{state => 
                cmd.replyTo ! Greeting(cmd.whom, state.numberOfPeople)}

  //(currentState, Event) => newState, 
  //eventhandler is used after persisting Event , also used while restoring  , all these Events would be played             
  private val eventHandler: (KnownPeople, Greeted) => KnownPeople = { (state, evt) =>
    state.add(evt.whom)
  }

  

  def apply(entityId: String, persistenceId: PersistenceId): Behavior[Command] = {
    Behaviors.setup { context =>
      context.log.info2("Starting HelloWorld entityId={}, PersistenceId={}", entityId, PersistenceId)
      //apply[Command, Event, State](persistenceId: PersistenceId, emptyState: State, commandHandler: (State, Command) => Effect[Event, State], eventHandler: (State, Event) => State): EventSourcedBehavior[Command, Event, State]
      EventSourcedBehavior(persistenceId, emptyState = KnownPeople(Set.empty), 
        commandHandler, eventHandler)
    }
  }

}