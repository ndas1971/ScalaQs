package typedclustering 

import akka.actor.typed.scaladsl._
import akka.cluster.ClusterEvent._
import akka.cluster.typed._
import akka.actor.typed._

import scala.concurrent.duration._ 
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import akka.util._
import akka._
import akka.actor.typed.receptionist._
import scala.util._ 

trait CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "TypedClusterSystem"
    val clusterMainApp = "typedclusterMainApp.conf"      
    val sleeptime = 10*60*1000
    
    def killThisSystem[X](system:ActorSystem[X], sleeptime:Int=sleeptime):Unit = {    
        Thread.sleep(sleeptime)
        system.terminate()
    }

}

object SimpleClusterApp {
  
  object RootBehavior {
    def apply(): Behavior[Nothing] = Behaviors.setup[Nothing] { context =>
      // Create an actor that handles cluster domain events
      context.spawn(SimpleClusterListener(), "ClusterListener")

      Behaviors.empty
    }
  }

  def main(args: Array[String]): Unit = {
    startup(args.head.toInt)
  }

  def startup(port: Int): Unit = {
     import Helper._ 
    // Override the configuration of the port
    val config = ConfigFactory.parseString(s"""
      akka.remote.artery.canonical.port=$port
      """).withFallback(ConfigFactory.load(clusterMainApp))

    // Create an Akka system- All System must have the same Name 
    val system = ActorSystem[Nothing](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }

}



object SimpleClusterListener {

  sealed trait Event
  // internal adapted cluster events only
  private final case class ReachabilityChange(reachabilityEvent: ReachabilityEvent) extends Event
  private final case class MemberChange(event: MemberEvent) extends Event

  def apply(): Behavior[Event] = Behaviors.setup { ctx =>
  
    val memberEventAdapter: ActorRef[MemberEvent] = ctx.messageAdapter(MemberChange)
    
    //case class Subscribe[A <: ClusterDomainEvent](subscriber: ActorRef[A], eventClass: Class[A]) 
    Cluster(ctx.system).subscriptions ! Subscribe(memberEventAdapter, classOf[MemberEvent])

    val reachabilityAdapter = ctx.messageAdapter(ReachabilityChange)
    Cluster(ctx.system).subscriptions ! Subscribe(reachabilityAdapter, classOf[ReachabilityEvent])

    Behaviors.receiveMessage { message =>
      message match {
        case ReachabilityChange(reachabilityEvent) =>
          reachabilityEvent match {
            case UnreachableMember(member) =>
              ctx.log.info("Member detected as unreachable: {}", member)
            case ReachableMember(member) =>
              ctx.log.info("Member back to reachable: {}", member)
          }

        case MemberChange(changeEvent) =>
          changeEvent match {
            case MemberUp(member) =>
              ctx.log.warn("Member is Up: {}", member.address)
            case MemberRemoved(member, previousStatus) =>
              ctx.log.warn("Member is Removed: {} after {}",  member.address, previousStatus)
            case _: MemberEvent => // ignore
          }
      }
      Behaviors.same
    }
  }
}

//Worker 
object ClusterWorker {
 
  object RootBehavior {
    def apply(): Behavior[Nothing] = Behaviors.setup[Nothing] { ctx =>
      val cluster = Cluster(ctx.system)

      if (cluster.selfMember.hasRole("backend")) {
        val workersPerNode = ctx.system.settings.config.getInt("transformation.workers-per-node")
        (1 to workersPerNode).foreach { n =>
          ctx.spawn(Worker(), s"Worker$n")
        }
      }
      if (cluster.selfMember.hasRole("frontend")) {
        ctx.spawn(Frontend(), "Frontend")
      }
      Behaviors.empty
    }
  }

  def main(args: Array[String]): Unit = {
    require(args.size == 2, "Usage: role port")
    startup(args(0), args(1).toInt)
  }

  def startup(role: String, port: Int): Unit = {
    import Helper._ 
    // Override the configuration of the port and role
    val config = ConfigFactory.parseString(s"""
        akka.remote.artery.canonical.port=$port
        akka.cluster.roles = [$role]
        """)
      .withFallback(ConfigFactory.load(clusterMainApp)) //"transformation"

    val system = ActorSystem[Nothing](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }
}




object Worker {

  val WorkerServiceKey = ServiceKey[Worker.TransformText]("Worker")

  sealed trait Command
  final case class TransformText(text: String, replyTo: ActorRef[TextTransformed]) extends Command with CborSerializable
  final case class TextTransformed(text: String) extends CborSerializable

  def apply(): Behavior[Command] =
    Behaviors.setup { ctx =>
      // each worker registers themselves with the receptionist
      ctx.log.info("Registering myself with receptionist")
      ctx.system.receptionist ! Receptionist.Register(WorkerServiceKey, ctx.self)

      Behaviors.receiveMessage {
        case TransformText(text, replyTo) =>
          replyTo ! TextTransformed(text.reverse)
          Behaviors.same
      }
    }
}


object Frontend {

  sealed trait Event
  private case object Tick extends Event
  private final case class WorkersUpdated(newWorkers: Set[ActorRef[Worker.TransformText]]) extends Event
  
  private final case class TransformCompleted(originalText: String, transformedText: String) extends Event
  private final case class JobFailed(why: String, text: String) extends Event


  def apply(): Behavior[Event] = Behaviors.setup { ctx =>
    Behaviors.withTimers { timers =>
      // subscribe to available workers
      val subscriptionAdapter = ctx.messageAdapter[Receptionist.Listing] {
        case Worker.WorkerServiceKey.Listing(workers) =>
          WorkersUpdated(workers)
      }
      ctx.system.receptionist ! Receptionist.Subscribe(Worker.WorkerServiceKey, subscriptionAdapter)

      //Simulate 
      //def startTimerWithFixedDelay(key: Any, msg: T, delay: FiniteDuration): Unit
      timers.startTimerWithFixedDelay(Tick, Tick, 2.seconds)

      running(ctx, IndexedSeq.empty, jobCounter = 0)
    }
  }

  private def running(ctx: ActorContext[Event], workers: IndexedSeq[ActorRef[Worker.TransformText]], jobCounter: Int): Behavior[Event] =
    Behaviors.receiveMessage {
      case WorkersUpdated(newWorkers) =>
        ctx.log.info("List of services registered with the receptionist changed: {}", newWorkers)
        running(ctx, newWorkers.toIndexedSeq, jobCounter)
      case Tick =>
        if (workers.isEmpty) {
          ctx.log.info("Got tick request but no workers available, not sending any work")
          Behaviors.same
        } else {
          // how much time can pass before we consider a request failed
          implicit val timeout: Timeout = 5.seconds
          val selectedWorker = workers(jobCounter % workers.size)
          ctx.log.info("Sending work for processing to {}", selectedWorker)
          val text = s"hello-$jobCounter"
          //def ask[Req, Res](target: RecipientRef[Req], createRequest: (ActorRef[Res]) => Req)(mapResponse: (Try[Res]) => T)(implicit responseTimeout: Timeout, classTag: ClassTag[Res]): Unit 
          //basically  selectedWorker !  Worker.TransformText(text, replyTo) producing Try[Worker.TextTransformed(text: String)]
          ctx.ask(selectedWorker, Worker.TransformText(text, _)) {
            case Success(transformedText) => TransformCompleted(text, transformedText.text)
            case Failure(ex) => JobFailed("Processing timed out", text)
          }
          running(ctx, workers, jobCounter + 1)
        }
      case TransformCompleted(originalText, transformedText) =>
        ctx.log.info("Got completed transform of {}: {}", originalText, transformedText)
        Behaviors.same

      case JobFailed(why, text) =>
        ctx.log.info("Transformation of text {} failed. Because: {}", text, why)
        Behaviors.same

    }
}