///Typed  Actor API - what's API functionality -- ADVANCED 
//Ref 
https://doc.akka.io/docs/akka/current/typed/index.html

//sbt 
libraryDependencies += "com.typesafe.akka" %% "akka-actor-typed" % "2.6.3"

//Quick API details 
Note ActorSystem[T] is typed, taking guardian Behavior[T] 
        ActorSystem[T](guardianBehavior: Behavior[T], name: String)
    
    Guardian Behavior[T] is in general Behaviors.empty[Nothing] or Behaviors.ignore[Any]
        where T = Nothing or Any ie does not handle anything or handle any messages 
    
    Create other actors, ActorRef[U] , under Guardian by 
        ActorSystem[-T].systemActorOf[U](behavior: Behavior[U], name: String, props: Props = Props.empty): ActorRef[U]  
        Props does not have any important meaning here 
    
    Create behavior by using Behaviors methods, most usefuls are 
    (Note Receive[T] extends Behavior[T])
    
        Behaviors.setup[T](factory: (ActorContext[T]) => Behavior[T]): Behavior[T]
            initial setup (only once) using ActorContext[T] 
            combine this with receiveMessage
        Behaviors.receiveMessage[T](onMessage: (T) => Behavior[T]): Receive[T]
        Behaviors.receiveMessagePartial[T](onMessage: PartialFunction[T, Behavior[T]]): Receive[T]
            partial version treats undefined messages as unhandled(only prints debug info)
            Note, without partial, eg receiveMessage,undefined message is compilation error  
            
    OR get ActorContext[T] directly in 
    (here ActorContext[T] available in message processing loop)
        Behaviors.receive[T](onMessage: (ActorContext[T], T) => Behavior[T]): Receive[T]
        Behaviors.receivePartial[T](onMessage: PartialFunction[(ActorContext[T], T), Behavior[T]]): Receive[T]
    
    OR some advanced functionality 
        Behaviors.withStash[T](capacity: Int)(factory: (StashBuffer[T]) => Behavior[T]): Behavior[T]
        Behaviors.withTimers[T](factory: (TimerScheduler[T]) => Behavior[T]): Behavior[T]
            Gets access to Stash/Timer 
      
      Note above functions must return Behavior[T] which is in general below 
      or can be any Behaviors.
        Behaviors.same[T]: Behavior[T]
            Repeats the same behavior
        Behaviors.stopped[T](postStop: () => Unit): Behavior[T]
        Behaviors.stopped[T]: Behavior[T]
            Stop the actor 
  
ActorRef[T] is typed, handles only message of T type 
  Send msg:T by below method on actorRef instance 
    ActorRef[-T].!/tell(msg: T): Unit
    
There is no sender() like untyped , so, message:T should contain replyTo:ActorRef[U] getting U message 

ActorContext[T]  can  spawn other Actor , stop child 
    ActorContext[T].spawn[U](behavior: Behavior[U], name: String, props: Props = Props.empty): ActorRef[U]
    ActorContext[T].spawnAnonymous[U](behavior: Behavior[U], props: Props = Props.empty): ActorRef[U]
    ActorContext[T].stop[U](child: ActorRef[U]): Unit

User can also send msg by ask pattern, 
  ActorContext[T].ask[Request, Response](target: RecipientRef[Request],  //RecipientRef is ActorRef
    createRequest: (ActorRef[Response]) => Request)
    (mapResponse: (Try[Response]) => T)(implicit responseTimeout: Timeout, classTag: ClassTag[Response]): Unit
        Given 'replyTo:ActorRef[Response]' by akka system, create 'Request' message by 'createRequest' , 
        API would send 'Request' to 'target'
        When target replys back 'Response', converts to this to own_message:T by 'mapResponse'

watch/unwatch child 
    ActorContext[T].unwatch[U](other: ActorRef[U]): Unit
    ActorContext[T].watch[U](other: ActorRef[U]): Unit
    
Sends Future[Value] result  to self as own_message:T after converting by 'mapResult'
    ActorContext[T].pipeToSelf[Value](future: Future[Value])(mapResult: (Try[Value]) => T): Unit

And few other utilities (eg get self, actorSystem, child and log)
    ActorContext[T].children: Iterable[ActorRef[Nothing]]
    ActorContext[T].child(name: String): Option[ActorRef[Nothing]]
    ActorContext[T].executionContext: ExecutionContextExecutor
    ActorContext[T].log: Logger
    ActorContext[T].self: ActorRef[T]    
    ActorContext[T].system: ActorSystem[Nothing]
    
And more utilities eg schedule msg:U to targetActorRef[U], sets timeout for Rx of own_msg:T 
    ActorContext[T].scheduleOnce[U](delay: FiniteDuration, target: ActorRef[U], msg: U): Cancellable
    ActorContext[T].setReceiveTimeout(timeout: FiniteDuration, msg: T): Unit
    
And message Adapter functionality 
    ActorContext[T].messageAdapter[U](f: (U) => T)(implicit arg0: ClassTag[U]): ActorRef[U]
        Maps any msg:U to own_msg:T , this method returns replyTo:ActorRef[U]
        which can be used as replyTo and when target replies, we get own_msg:T 
        
Logging 
    default , akka.loglevel = "INFO"
    https://doc.akka.io/docs/akka/current/typed/logging.html
    Disable in application.conf 
        https://doc.akka.io/docs/akka/current/typed/logging.html#log-level
    Note the level 
    Trace < Debug < Info < Warn < Error < Fatal
    ie akka.loglevel = "DEBUG" would print all logs including Debug, Info, Warn,...
    


///Typed  Actor API Example 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory

object TestProb {
    case object ECHOSTOP
    
    //Behaviors.receive[T](onMessage: (ActorContext[T], T) => Behavior[T]): Receive[T]
    //vs 
    //Behaviors.receiveMessagePartial[T](onMessage: PartialFunction[T, Behavior[T]]): Receive[T]
    //partial version treats undefined messages as unhandled(only prints debug info) 
    //whereas receive would give compilation error 
    def echo[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
        //ActorContext[T] is available always in message processing loop 
        //below is executed always creating a new actor in each message reciept 
        
        //Behaviors.ignore[T]: Behavior[T]  //ignore and returns Behaviors.same
        //Behaviors.logMessages[T](behavior: Behavior[T]): Behavior[T]
        //Behaviors.logMessages[T](logOptions: LogOptions, behavior: Behavior[T]): Behavior[T]
        //ActorContext[T].spawnAnonymous[U](behavior: Behavior[U], props: Props = Props.empty): ActorRef[U]

        //default LogOptions = (enabled = true, Level.DEBUG), but default akka.loglevel = "INFO"
        //so would not print... change to INFO  
        context.spawnAnonymous[Any]( Behaviors.logMessages[Any]( 
            LogOptions().withLevel(org.slf4j.event.Level.INFO), Behaviors.ignore[Any]))
        
        context.log.info(s"New msg received: $msg")  
        msg match{
            case ECHOSTOP => 
                println(s"${context.self} stopping")
                //Behaviors.stopped[T](postStop: () => Unit): Behavior[T]
                //Behaviors.stopped[T]: Behavior[T]
                //by default stop all childrean 
                Behaviors.stopped  
            case x => 
                //ActorContext[T].children: Iterable[ActorRef[Nothing]]
                println(s"size = ${context.children.size}")   
                //send one message to see logMessage 
                context.children.head.unsafeUpcast[Any]/*ActorRef[Any]*/    !    x         
                Behaviors.same    
        }
    }   
}


//Behaviors.empty[T]: Behavior[T]
val system = ActorSystem[Nothing](Behaviors.empty[Nothing] /*Guardian behavior*/, "testsystemraw")
val echo = system.systemActorOf(TestProb.echo[Any](), "sender")
echo ! "Hello"
//size=1
echo ! "Hello"
//size=2
echo ! TestProb.ECHOSTOP

import system.executionContext
Future{ Thread.sleep(1000)}.foreach{ _ =>
    system.terminate()
}


//Send Receive- Request must contain replyTo: ActorRef[T]
//Behaviors.receiveMessage[T](onMessage: (T) => Behavior[T]): Receive[T]
//Behaviors.setup[T](factory: (ActorContext[T]) => Behavior[T]): Behavior[T]
object TestProb2 {    
    //Many 
    sealed trait Command 
    case class Request(msg:Any, replyTo: ActorRef[Any]) extends Command 
    case object Stop extends Command 
    
    def sendRec(): Behavior[Command] = Behaviors.setup { context =>
        //Any initial setup , put here,   
        //below would be executed only once 
        val childActorRef = context.spawnAnonymous[Any]( Behaviors.logMessages[Any]( 
            LogOptions().withLevel(org.slf4j.event.Level.INFO), Behaviors.ignore[Any]))
        context.log.info(s"${context.self} - setup done ") 
        
        Behaviors.receiveMessage { msg =>
            context.log.info(s"${context.self} - New msg received: $msg")  
            msg match {
                case Stop => Behaviors.stopped
                case Request(msg, replyTo) =>
                    replyTo ! msg
                    //send to child to see logMessages
                    childActorRef ! msg                      
                    Behaviors.same 
            }                
    }
  }    
}
    
//Usage 
val system = ActorSystem[Nothing](Behaviors.empty[Nothing] /*Guardian behavior*/, "testsystemraw")
val sr = system.systemActorOf(TestProb2.sendRec(), "srx")
val echo = system.systemActorOf(TestProb.echo[Any](), "sender")
sr ! TestProb2.Request("Hello", echo)
//from logMessage as well 
sr ! TestProb2.Request("Hello", echo) //no setup message 
sr ! TestProb2.Stop
echo ! TestProb.ECHOSTOP

import system.executionContext
Future{ Thread.sleep(1000)}.foreach{ _ =>
    system.terminate()
}

///Typed Actor Testing 

import akka.actor.testkit.typed.scaladsl._

import akka.actor.typed._
import akka.actor.typed.scaladsl.AskPattern._
import akka.actor.typed.scaladsl._
import akka.util.Timeout

import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers
import org.scalatest.wordspec.AnyWordSpec
//https://www.scalatest.org/user_guide/selecting_a_style


import scala.concurrent.duration._
import scala.concurrent._
import scala.util._

//:paste
class AsyncTestingExampleSpec
    extends AnyWordSpec
    with BeforeAndAfterAll
    //with LogCapturing
    with Matchers {
    
  var testKit:ActorTestKit = _
  
  override def afterAll() {
    testKit.shutdownTestKit()
  }
  override def beforeAll() {
    testKit = ActorTestKit("TestSystem")
  }

  "A testkit" must {
    "support verifying a response" in {
      val actor = testKit.spawn(TestProb2.sendRec(), "Send")
      val probe = testKit.createTestProbe[Any]()
      actor ! TestProb2.Request("hello", probe.ref)
      probe.expectMessage("hello")
    }
  }
}

> org.scalatest.run(new AsyncTestingExampleSpec())

For other testprob methods , check 
https://doc.akka.io/api/akka/current/akka/actor/testkit/typed/scaladsl/TestProbe.html

///More on Testing -- ADVANCED 

import akka.actor.testkit.typed.scaladsl.*

import akka.actor.typed.*
import akka.actor.typed.scaladsl.AskPattern.*
import akka.actor.typed.scaladsl.*
import akka.util.Timeout

import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers
import org.scalatest.wordspec.AnyWordSpec


import scala.concurrent.duration.*
import scala.concurrent.*
import scala.util.*


object Echo {
  case class Ping(message: String, response: ActorRef[Pong])
  case class Pong(message: String)

  def apply(): Behavior[Ping] = Behaviors.receiveMessage {
    case Ping(m, replyTo) =>
      replyTo ! Pong(m)
      Behaviors.same
  }
}

case class Message(i: Int, replyTo: ActorRef[Try[Int]])

class Producer(publisher: ActorRef[Message])(using  scheduler: Scheduler) {

  def produce(messages: Int)(using  timeout: Timeout): Unit = {
    (0 until messages).foreach(publish)
  }

  private def publish(i: Int)(using  timeout: Timeout): Future[Try[Int]] = {
    publisher.ask(ref => Message(i, ref))//ref is ReplyTo 
  }

}

class AsyncTestingExampleSpec
    extends AnyWordSpec
    with BeforeAndAfterAll
    //with LogCapturing
    with Matchers {
  val testKit = ActorTestKit("TestSystem")


  "A testkit" must {
    "support verifying a response" in {
      val pinger = testKit.spawn(Echo(), "ping")
      val probe = testKit.createTestProbe[Echo.Pong]()
      pinger ! Echo.Ping("hello", probe.ref)
      probe.expectMessage(Echo.Pong("hello"))
    }

    "support verifying a response - anonymous" in {
      val pinger = testKit.spawn(Echo())

      val probe = testKit.createTestProbe[Echo.Pong]()
      pinger ! Echo.Ping("hello", probe.ref)
      probe.expectMessage(Echo.Pong("hello"))
    }

    "be able to stop actors under test" in {
      // Will fail with 'name not unique' exception if the first actor is not fully stopped
      val probe = testKit.createTestProbe[Echo.Pong]()

      val pinger1 = testKit.spawn(Echo(), "pinger")
      pinger1 ! Echo.Ping("hello", probe.ref)
      probe.expectMessage(Echo.Pong("hello"))
      testKit.stop(pinger1) // Uses default timeout

      // Immediately creating an actor with the same name
      val pinger2 = testKit.spawn(Echo(), "pinger")
      pinger2 ! Echo.Ping("hello", probe.ref)
      probe.expectMessage(Echo.Pong("hello"))
      testKit.stop(pinger2, 10.seconds) // Custom timeout
    }

    "support observing mocked behavior" in {

      import testKit.*

      // simulate the happy path
      val mockedBehavior = Behaviors.receiveMessage[Message] { msg =>
        msg.replyTo ! Success(msg.i)
        Behaviors.same
      }
      val probe = testKit.createTestProbe[Message]()
      val mockedPublisher = testKit.spawn(Behaviors.monitor(probe.ref, mockedBehavior))

      // test our component
      val producer = new Producer(mockedPublisher)
      val messages = 3
      producer.produce(messages)

      // verify expected behavior
      for (i <- 0 until messages) {
        val msg = probe.expectMessageType[Message]
        msg.i shouldBe i
      }
    }
  }

  override def afterAll(): Unit = testKit.shutdownTestKit()

}

org.scalatest.run(new AsyncTestingExampleSpec())


///Actorcontext Functionality - ask , adapter, spawn , handle Future(RECCO for mutable state handling) -- ADVANCED *

ActorContext[T]
    def ask[Req, Res](target: RecipientRef[Req], createRequest: (ActorRef[Res]) => Req)(mapResponse: (Try[Res]) => T)(implicit responseTimeout: Timeout, classTag: ClassTag[Res]): Unit
        Send Req message to target  which responds with Res 
        Create Req by createRequest =( respActor => targetActor.Msg(..., replyTo:respActor))
        Process Res  by  mapResponse = ( case Success(..) => T)
        this Actor auto-recieves T
    def messageAdapter[U](f: (U) => T)(implicit arg0: ClassTag[U]): ActorRef[U]
        If anybody Sends Msg to ActorRef[U], this  Actor auto-recieves T 
    def pipeToSelf[Value](future: Future[Value])(mapResult: (Try[Value]) => T): Unit
        When Future is completed, convert Value to T and this Actor auto-recieves T
    def spawn[U](behavior: Behavior[U], name: String, props: Props = Props.empty): ActorRef[U]
        with Name 
    def spawnAnonymous[U](behavior: Behavior[U], props: Props = Props.empty): ActorRef[U]
        Name is autogenerated 
    
//Example 
import scala.concurrent.duration._
import  scala.util._

object TestProb3{   
    sealed trait Msg 
    case class MsgC( msg:Any ) extends  Msg 
    case object Stop extends Msg 
    
    def testAsk() = Behaviors.setup[Msg] { context =>
        val target = context.spawnAnonymous( TestProb2.sendRec()) //ActorRef[Any]
        //create Timeout 
        implicit val timeout = akka.util.Timeout(5.seconds)

        def createRequest(msg:Any) = {  (replyTo:ActorRef[Any]) => 
            TestProb2.Request(msg, replyTo)
        }
        //ask[Req, Res](target: RecipientRef[Req], createRequest: (ActorRef[Res]) => Req)(mapResponse: (Try[Res]) => T)
        //auto-sends T to self 
        context.ask[TestProb2.Command, Any](target, createRequest("Hello") ){  /*Resp=Any*/
            case Success(res) => MsgC(res)
            case Failure(ex)  =>  MsgC(s"$ex")
        }

        //def receiveMessagePartial[T](onMessage: PartialFunction[T, Behavior[T]]): Receive[T]
        //without partial, eg receiveMessage,undefined message is compilation error 
        //here it is unhandled message (prints in log)        
        Behaviors.receiveMessagePartial {
            case MsgC(msg) =>
                context.log.info(s"New msg received: $msg") 
                Behaviors.stopped
            case _ =>
                Behaviors.stopped    
        }
    }
    
    def testAdaptor() = Behaviors.setup[Msg] { context =>
        val target = context.spawnAnonymous( TestProb2.sendRec())
        
        //messageAdapter[U](f: (U) => T): ActorRef[U]
        //auto-sends T to self 
        val replyTo = context.messageAdapter[Any]{ /* Resp from target */
                (msg:Any) => MsgC(msg)
            }
        def createRequest(msg:Any) = TestProb2.Request(msg, replyTo)
        
        target.tell(createRequest("Hello") )       
        Behaviors.receiveMessage {  (msg:Msg) =>
             context.log.info(s"New msg received: $msg") 
             Behaviors.stopped               
        }
    }
    
    //RECO : Mutable State handling 
    def testFuture[T](system:ActorSystem[T]) = Behaviors.setup[Msg] { context =>        
        import system.executionContext  //brings ExecutionContext 
        
        val fut = Future {
            Thread.sleep(100)
            "Hello"
        }
        //pipeToSelf[Value](future: Future[Value])(mapResult: (Try[Value]) => T): Unit
        //auto-sends T to self 
        context.pipeToSelf(fut) {  /*Value=String*/
            case Success(res) => MsgC(res)
            case Failure(ex)  =>  MsgC(s"$ex")
        }
 
        //def receiveMessagePartial[T](onMessage: PartialFunction[T, Behavior[T]]): Receive[T]
        //without partial, eg receiveMessage,undefined message is compilation error 
        //here it is unhandled message (prints in log)
        Behaviors.receiveMessagePartial {
            case MsgC(msg) =>
                context.log.info(s"New msg received: $msg") 
                Behaviors.stopped
            case _ =>
                Behaviors.stopped    
        }
    }
    
    //Another way of ask pattern - returns fut 
    import akka.actor.typed.scaladsl.AskPattern._
    def testAskPattern[T](system:ActorSystem[T]) = Behaviors.setup[Msg] { context =>
        val target = context.spawnAnonymous( TestProb2.sendRec())        
        //create Timeout 
        implicit val timeout = akka.util.Timeout(5.seconds)
        implicit val scheduler = system.scheduler

        def createRequest(msg:Any) = {  (replyTo:ActorRef[Any]) => TestProb2.Request(msg, replyTo)}
        
        //ask[Res](replyTo: (ActorRef[Res]) => Req): Future[Res]
        val fut = target.ask[Any](createRequest("Hello") )
        
        //pipeToSelf[Value](future: Future[Value])(mapResult: (Try[Value]) => T): Unit
        //auto-sends T to self 
        context.pipeToSelf(fut) {  /*Value=Any*/
            case Success(res) => MsgC(res)
            case Failure(ex)  =>  MsgC(s"$ex")
        }

        //def receiveMessagePartial[T](onMessage: PartialFunction[T, Behavior[T]]): Receive[T]
        Behaviors.receiveMessagePartial {
            case MsgC(msg) =>
                context.log.info(s"New msg received: $msg") 
                Behaviors.stopped
            case _ =>
                Behaviors.stopped    
        }
    }
}

system.systemActorOf(TestProb3.testAsk(), "srx")
//New msg received: Request(Hello,Actor[akka://testsystemraw/temp/$a$a#0])
//New msg received: Hello

system.systemActorOf(TestProb3.testAdaptor(), "srx2")
//New msg received: Request(Hello,Actor[akka://testsystemraw/system/srx2/$$b-adapter#411898891])
//New msg received: MsgC(Hello)

system.systemActorOf(TestProb3.testFuture(system), "srx3")
//New msg received: Request(Hello,Actor[akka://testsystemraw/temp/$a$b#0])
//New msg received: Hello

system.systemActorOf(TestProb3.testAskPattern(system), "srx4")
//New msg received: Request(Hello,Actor[akka://testsystemraw/temp/$a$b#0])
//New msg received: Hello

system.terminate() 



///Typed Actor helpers -- copy src/main/scala/typedactorhelper.scala -- ADVANCED
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory

object TypedActorHelper{

    def process[T,X]( system: ActorSystem[X], props:Behavior[T], actorName: String = "name", stopMessage:Seq[T]=Seq.empty[T])
            (sendfn: (ActorSystem[X], ActorRef[T]) => Any):Function0[Unit]  = {
        processSeq[T,X](system, Seq( (actorName, props) ), stopMessage){
            (system, seq) => sendfn(system, seq.head)
        }
    }
    def testGuardianSystem[T]( guardian:Behavior[T], name: String = "guardiansystem_under_test")
            (sendfn: ActorSystem[T]=> Any):Function0[Unit]  = {
        val system = ActorSystem(guardian, name)
        val x= sendfn(system)
        ( () => {
              println(s"Stopping, body returned $x")
              system.terminate()
           }
        )
    }
    def testGuardianSystemWithConfig[T](guardian:Behavior[T], configFilename: String, name: String = "guardiansystem_under_test")
            (sendfn: ActorSystem[T]=> Any):Function0[Unit]  = {
        val system = ActorSystem(guardian, name, ConfigFactory.load(configFilename))
        val x= sendfn(system)
        ( () => {
              println(s"Stopping, body returned $x")
              system.terminate()
           }
        )
    } 
    def testActor[T](props:Behavior[T], actorName: String = "name", stopMessage:Seq[T]=Seq.empty[T])
            (sendfn: (ActorSystem[Any], ActorRef[T]) => Any):Function0[Unit]  = {
            
        val system = ActorSystem(Behaviors.empty[Any], "testsystem_TypedActorHelper")
        val close = processSeq[T,Any](system, Seq( (actorName, props) ), stopMessage){
            (system, seq) => sendfn(system, seq.head)
        }
        ( () => {
            close()
            system.terminate()
          }
        )
    }
    def processSeq[T,X]( system: ActorSystem[X], propNames:Seq[(String, Behavior[T])], stopMessage:Seq[T]=Seq.empty[T] )
            (sendfn: (ActorSystem[X], Seq[ActorRef[T]]) => Any ):Function0[Unit]  = {
        process(system){system => 
            propNames.map{case (n,p) => system.systemActorOf(p, n)}
          }{ (system, seq) =>
            if (seq.nonEmpty)
                seq.zip(stopMessage).foreach{ case(a, m) => a ! m} 
                else 
                    ()
          }{(system, seq) => 
            sendfn(system, seq)
        }
    } 
    def process[T, X](system: ActorSystem[X])(createActors: ActorSystem[X]=>Seq[ActorRef[T]]) 
            (stopActors:((ActorSystem[X], Seq[ActorRef[T]])=>Unit)  )
            (body: (ActorSystem[X], Seq[ActorRef[T]]) => Any ):Function0[Unit]  = {
        val actors = createActors(system)
        println(s"Created: ${actors.map(_.toString).mkString("(",",",")")}")
        val x = body(system, actors)
        ( () => {
              println(s"Stopping, body returned $x")
              stopActors(system,actors)
           }
        )
    }   

   
    def ask[T,U:scala.reflect.ClassTag,X, R](system:ActorSystem[X], target: RecipientRef[T], reciever:Option[ActorRef[R]]=None)(createRequest:ActorRef[U]=>T):Unit=
        system.systemActorOf(TestProb.askM[T,U,R](target, createRequest, reciever), "asrx")


    object TestProb {
        case object ECHOSTOP
        def echo[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
            context.log.info(s"New msg received: $msg")  
            msg match{
                case ECHOSTOP => 
                    println(s"${context.self} stopping")
                    Behaviors.stopped  
                case _ => Behaviors.same    
            }
        }
        def echoOnce[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
            context.log.info(s"New msg received: $msg")  
            Behaviors.stopped 
        }
        //(ActorRef[PingService.Ping], ActorRef[PingService.Pong.type] => PingService.Ping) => Behavior[PingService.Pong.type]
        //echoOnceAfterSendOnce[PingService.Ping, PingService.Pong.type](ps, PingService.Ping(_))
        def echoOnceAfterSendOnce[T, U:scala.reflect.ClassTag](target: RecipientRef[T], reqFn:ActorRef[U]=>T):Behavior[U] = Behaviors.setup { context =>
            val receiver = context.spawnAnonymous( echoOnce[U]())
            askM[T,U,U](target, reqFn, Option(receiver))
        }     
        //Many 
        sealed trait Command 
        case class Request(msg:Any, replyTo: ActorRef[Any]) extends Command 
        case object Stop extends Command 
        
        def sendRec(): Behavior[Command] = Behaviors.receive { (context, msg) =>
            context.log.info(s"${context.self} - New msg received: $msg")  
            msg match {
                case Stop => Behaviors.stopped
                case Request(msg, replyTo) =>
                    replyTo ! msg
                    Behaviors.same 
            }                
        } 
        
        //ask 
        def askM[T, U:scala.reflect.ClassTag,R](target: RecipientRef[T], reqFn:(ActorRef[U]=>T), rx:Option[ActorRef[R]]=None): Behavior[R] = Behaviors.setup{ context =>
            import scala.concurrent.duration._
            implicit val timeout = akka.util.Timeout(5.seconds)
            import  scala.util._
            context.ask(target, reqFn ){  //target would get T and return Res 
                case Success(res) => res.asInstanceOf[R]  //res:U, res goes to receiveMessage.msg 
                case Failure(ex)  =>  s"ex".asInstanceOf[R]
            }
            var echoCreated = false         
            val echo = rx.getOrElse{
                    echoCreated = true 
                    context.spawnAnonymous(TestProb.echo[R]())
                }
            
            Behaviors.receiveMessage {  msg:R =>
                echo ! msg 
                if(echoCreated){                
                    //children are autoclosed, so not needed 
                    Behaviors.stopped( () => context.stop(echo) )
                } else 
                 Behaviors.stopped               
            }
        }
    }
}


//Usage 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


//Using 
//creates system automatically 
val close = TypedActorHelper.testActor(TestProb.echo[Any]()){ (system, actor) =>
    actor ! "Hello"
}
close()  //Teminate 

//OR 
val system = ActorSystem[Nothing](Behaviors.empty[Nothing], "testsystemraw")
val close = TypedActorHelper.process[Any,Nothing](system, TypedActorHelper.TestProb.echo[Any](), stopMessage=Seq(TypedActorHelper.TestProb.ECHOSTOP)){ (system, actor) =>
    actor ! "Hello"
}
close()
system.terminate() 

///transformMessages - similar to messageAdapter(used in replyTo) -- ADVANCED
class akka.actor.typed.Behavior[T] extends AnyRef
    val behavior: Behavior[T]
    final def narrow[U <: T]: Behavior[U]
        Narrow the type of this Behavior, which is always a safe operation.
    def transformMessages[Outer](matcher: PartialFunction[Outer, T])(implicit arg0: ClassTag[Outer]): Behavior[Outer]
        This Behaviour accepts Outer(ie user API) and but internally implemented by T 
        Convert Outer to T by PartialFunction[Outer, T]

//Example 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._
  
object CookieFabric {
  //this Atcor understands below request 
  sealed trait Command {}
  case class GiveMeCookies(count: Int, replyTo: ActorRef[Reply]) extends Command
  //This actor replies with below
  sealed trait Reply
  case class Cookies(count: Int) extends Reply
  case class InvalidRequest(reason: String) extends Reply
  
  //this actor's external interface understand below , so communicate with below 
  sealed trait RemoteCommand
  case class RemoteRequest(count:Int, replyTo:ActorRef[Reply]) extends RemoteCommand

  def apply(): Behavior[RemoteCommand] = Behaviors.setup[Command] { context =>  
      Behaviors.receiveMessage { 
        case GiveMeCookies(count, replyTo) =>            
            if (count < 5) {
                replyTo ! Cookies(count)
            } else {
                replyTo ! InvalidRequest("Too High")
            }
            Behaviors.same        
        }
    }.transformMessages[RemoteCommand] {  //RemoteCommand => Command 
              case RemoteRequest(count, replyTo) => GiveMeCookies(count, replyTo)
              
    }   
}

val close = TypedActorHelper.testGuardianSystem(CookieFabric()){ system =>
    import scala.concurrent.duration._ 
    import CookieFabric._     
    
    import akka.actor.typed.scaladsl.AskPattern._
    implicit val scheduler = system.scheduler 
    implicit val timeout: akka.util.Timeout = 3.seconds  
    implicit val ec = system.executionContext
    
    // the response callback will be executed on this execution context    
    def p(result:Future[Reply])(implicit ec: ExecutionContext) = result.onComplete {
      case Success(Cookies(count)) => println(s"Yay, $count cookies!")
      case Success(InvalidRequest(reason)) => println(s"No cookies for me. $reason")
      case Failure(ex)         => println(s"Boo! didn't get cookies: ${ex.getMessage}")
    }
    //ask[Res](replyTo: (ActorRef[Res]) => Req)(implicit timeout: Timeout, scheduler: Scheduler): Future[Res]
    p(system.ask( RemoteRequest(3,_) )) 
    p(system.ask( RemoteRequest(10,_) ))    
}
close()





///ActorSystem with non empty Behavior - called root/Guardian Actor  --ADVANCED

import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


object GuardianActor {

    final case class SayHello(name: String)
    
    def apply(): Behavior[SayHello] = Behaviors.setup { context =>
          val greeter = context.spawn(HelloWorld(), "greeter")
          Behaviors.receiveMessage { message => //message is of type SayHello
            val replyTo = context.spawn(GuardianActor.max(3), message.name)
             greeter ! HelloWorld.Greet(message.name, replyTo)
             Behaviors.same
          }
        }
    def max(count:Int):Behavior[HelloWorld.Greeted] = Behaviors.setup{ context =>
        var next = 0 
        Behaviors.receiveMessagePartial { 
            case message if next >= count => Behaviors.stopped 
            case HelloWorld.Greeted(whom, ref) =>
                next += 1 
                ref ! HelloWorld.Greet(whom, context.self)
                Behaviors.same 
        }
    }
}


object HelloWorld {
  final case class Greet(whom: String, replyTo: ActorRef[Greeted])
  final case class Greeted(whom: String, from: ActorRef[Greet])   

  def apply(): Behavior[Greet] = Behaviors.receive { (context, message) =>
    context.log.info("Hello {}!", message.whom)
    message.replyTo ! Greeted(message.whom, context.self)
    Behaviors.same
  }
}


//Usage 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


val close = TypedActorHelper.testGuardianSystem(GuardianActor()){ system =>
    implicit val timeOut:akka.util.Timeout = 1.minutes 
    import system._  //bring ExecutionContext 
    
    system ! GuardianActor.SayHello("World")
    system ! GuardianActor.SayHello("Akka")
    
    system.whenTerminated.map{ done =>
        system.log.warn("Terminated")
    }
        
}
close()


///Timers  -- ADVANCED
object  Behaviors
    def withTimers[T](factory: (TimerScheduler[T]) => Behavior[T]): Behavior[T]
TimerScheduler[T]  //msg=T    
    def cancel(key: Any): Unit
        Cancel a timer with a given key.
    def cancelAll(): Unit
        Cancel all timers.
    def isTimerActive(key: Any): Boolean
        Check if a timer with a given key is active.
    def startSingleTimer(key: Any, msg: T, delay: FiniteDuration): Unit
        Start a timer that will send msg once to the self actor after the given delay.
    def startTimerAtFixedRate(key: Any, msg: T, initialDelay: FiniteDuration, interval: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a given frequency.
    def startTimerAtFixedRate(key: Any, msg: T, interval: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a given frequency.
    def startTimerWithFixedDelay(key: Any, msg: T, initialDelay: FiniteDuration, delay: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a fixed delay between messages after the initialDelay.
    def startTimerWithFixedDelay(key: Any, msg: T, delay: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a fixed delay between messages.
    //without key , key autogenerated 
    def startSingleTimer(msg: T, delay: FiniteDuration): Unit
        Start a timer that will send msg once to the self actor after the given delay.
    def startTimerAtFixedRate(msg: T, initialDelay: FiniteDuration, interval: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a given frequency.
    def startTimerAtFixedRate(msg: T, interval: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a given frequency.
    def startTimerWithFixedDelay(msg: T, initialDelay: FiniteDuration, delay: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a fixed delay between messages after the initialDelay.
    def startTimerWithFixedDelay(msg: T, delay: FiniteDuration): Unit
        Schedules a message to be sent repeatedly to the self actor with a fixed delay between messages.
    
ActorSystem.scheduler 
    def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
        Schedules a Runnable to be run repeatedly with an initial delay and a frequency.
    def scheduleOnce(delay: FiniteDuration, runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
        Schedules a Runnable to be run once with a delay, i.e.
    def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
        Schedules a Runnable to be run repeatedly with an initial delay and a fixed delay between subsequent executions.
        
//Example 
object TestProb4 {
    sealed trait Msg
    case object Tick extends Msg 
    case object BTick extends Msg 
    case object TimerStop extends Msg 
    import scala.concurrent.duration._ 
    
    def apply(): Behavior[Msg] = Behaviors.withTimers[Msg] { timers =>
        Behaviors.setup { context =>
            timers.startSingleTimer("tick", Tick, 1.second)  //once // key, Msg, when 
            timers.startTimerAtFixedRate("btick", BTick, 5.second)
            timers.startSingleTimer("timerstop", TimerStop, 20.second)
            Behaviors.receiveMessage {  (msg:Msg) =>
                 context.log.info(s"New msg received: $msg") 
                 msg match{
                    case TimerStop => 
                        println(s"${context.self} stopping")
                        Behaviors.stopped  
                    case _ => Behaviors.same    
                }
            } 
     }
  }     
}

ActorSystem(TestProb4(), "TestProb4") //auto stops 

///Receive timeout  --ADVANCED
//The ActorContext setReceiveTimeout defines the inactivity timeout 
//after which the sending of a ReceiveTimeout message is triggered

def ActorContext[T].setReceiveTimeout(timeout: FiniteDuration, msg: T): Unit
    Schedule the sending of a notification in case no other message is received during the given period of time.
def ActorContext[T].cancelReceiveTimeout(): Unit
    Cancel the sending of receive timeout notifications.

//Once set, the receive timeout stays in effect 
//(i.e. continues firing repeatedly after inactivity periods). 
//Pass in Duration.Undefined to switch off this feature.


import scala.concurrent.duration._

object TestProb5 {
    sealed trait Msg
    case object Stop extends Msg 
    case object Start extends Msg 
    case object BTick extends Msg 
    case object TimeOut extends Msg 
    import scala.concurrent.duration._ 
    
    def apply(): Behavior[Msg] = Behaviors.withTimers[Msg] { timers =>
        Behaviors.setup { context =>
            timers.startSingleTimer("start", Start, 0.second)
            timers.startTimerAtFixedRate("btick", BTick, 5.second)
            timers.startSingleTimer("timerstop", Stop, 10.second)
            context.setReceiveTimeout(2.seconds, TimeOut)
            Behaviors.receiveMessage {  (msg:Msg) =>
                 context.log.info(s"New msg received: $msg") 
                 msg match{
                    case Stop => 
                        println(s"${context.self} stopping")
                        context.cancelReceiveTimeout()
                        Behaviors.stopped  
                    case _ =>                         
                        Behaviors.same    
                }
            } 
     }
  }     
}

//USage 
ActorSystem(TestProb5(), "TestProb5") //auto stops 

///Finite State Machine and become/unbecome  --ADVANCED
An actor can be used to model a Finite State Machine (FSM).
To demonstrate this, consider an actor which shall receive and queue messages 
while they arrive in a burst and send them on after the burst ended or a flush request is received.

This example demonstrates how to:
    Model states using different behaviors
    Model storing data at each state by representing the behavior as a method
    Implement state timeouts

//Example 
object BuncherData {
  
  sealed trait Event
  final case class SetTarget(ref: ActorRef[Batch]) extends Event
  final case class Queue(obj: Any) extends Event
  case object Flush extends Event
  case object Timeout extends Event
  
  case object Debug extends Event
  case object Stop extends Event
  
  final case class Batch(obj: Seq[Any])
  
  //State Data 
  sealed trait Data
  case object Uninitialized extends Data
  final case class Initialized(target: ActorRef[Batch], queue: Seq[Any]) extends Data
  
  /*
    (State, data)
    
    start -> (Idle, _) --SetTarget(ref) -> (idle, Initialized(ref, q=empty))
    (idle, Initialized) --Queue(e)  ->  (active, Initialized(ref, q+e))
     
     (active, Initialized(ref,q)) and set Timer 
                        --TimeOut|Flush->  send, cancelTimer , (idle,  Initialized(ref, empty))
                        --Queue(e)->   (active, Initialized(ref, q+e))    
                        --SetTarget(ref)-> (active, Initialized(ref, old_q))
  */
}


object Buncher {
  import BuncherData._ 
  //Each state becomes a distinct behavior and after processing a message the next state 
  //in the form of a Behavior is returned.
  
  //Idle and Active state 
  //Active state flushes if Flush event or Timeout 
  
  // initial state, idle Behaviour taking data Uninitialized
  def apply(): Behavior[Event] = idle(Uninitialized)

  //can be recursive 
  private def idle(data: Data): Behavior[Event] = Behaviors.receiveMessage[Event] { message: Event =>
    (message, data) match {
      case (SetTarget(ref), _) =>
        idle(Initialized(ref, Vector.empty))
      case (Queue(obj), t @ Initialized(_, v)) =>
        active(t.copy(queue = v :+ obj))
      case (Stop, _) =>
          Behaviors.stopped
      case _ =>
        Behaviors.unhandled
    }
  }
  val timerkey = s"time{new java.util.Date()}"  
  //Every Queue(obj) would reset the timer 
  private def active(data: Initialized): Behavior[Event] = Behaviors.setup{ context =>
    Behaviors.withTimers[Event] { timers =>
      //timers.cancel(timerkey) //noop if not started or canceled 
      timers.startSingleTimer(timerkey, Timeout, 1.second) //same key, so previous is autocancelled 
      Behaviors.receiveMessagePartial {
        case Flush | Timeout =>
          data.target ! Batch(data.queue)
          timers.cancel(timerkey)
          idle(data.copy(queue = Vector.empty))
        case Queue(obj) =>
          active(data.copy(queue = data.queue :+ obj))
        case SetTarget(newref) =>
          active(data.copy(target=newref))
        case Debug =>
          context.log.info(s"target=${data.target} queue=${data.queue}") 
          Behaviors.same
        case Stop =>
          Behaviors.stopped
        case _ =>
            Behaviors.unhandled
      }
    } 
  }
}
//usage 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


val close = TypedActorHelper.testGuardianSystem(Buncher()){ system =>
    implicit val timeOut:akka.util.Timeout = 1.minutes 
    import system._  //bring ExecutionContext 
    import BuncherData._ 
    
    val echo1 = system.systemActorOf(TypedActorHelper.TestProb.echo[Batch](), "echo1")    
    val echo2 = system.systemActorOf(TypedActorHelper.TestProb.echo[Batch](), "echo2")
    
    system ! SetTarget(echo1)
    system ! SetTarget(echo2)
    system ! SetTarget(echo1)
    (0 to 4).toList.foreach{ i => system ! Queue(i) }
    system ! Debug 
    system ! Flush 
    
    (0 to 4).toList.foreach{ i => system ! Queue(i) }     
    system ! Debug 
    //system.scheduler.scheduleOnce(delay: FiniteDuration, runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    system.scheduler.scheduleOnce(2.seconds, { () =>  system ! Stop })
    
    system.whenTerminated.map{ done =>
        system.log.warn("Terminated")
    }
    //All would be autoterminated     
}
close()


    
/// Actor discovery and watch/unwatch  --ADVANCED

//ActorContext.children
ActorContext[T]
    def children: Iterable[ActorRef[Nothing]]
    def child(name: String): Option[ActorRef[Nothing]]

The type of the returned ActorRef is unknown
Therefore, this is not a useful if  to send messag to them.
So Use bookkeeping of childrenin parent, such as a Map[String, ActorRef[Child.Command]] 
And Then emove entries from the Map when the children are terminated. 
So use watchWith

//ref 
ActorContext[T]
    def unwatch[U](other: ActorRef[U]): Unit
    def watch[U](other: ActorRef[U]): Unit
    def watchWith[U](other: ActorRef[U], msg: T): Unit
        Register for termination notification with a custom message, msg to self 
        when ActorRef terminates. 
    def spawn[U](behavior: Behavior[U], name: String, props: Props = Props.empty): ActorRef[U]
    def spawnAnonymous[U](behavior: Behavior[U], props: Props = Props.empty): ActorRef[U]
ActorRef[-T]
    def narrow[U <: T]: ActorRef[U]

//Example 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._

object Parent { 
  sealed trait Command
  case class DelegateToChild(name: String, message: Child.Command) extends Command
  private case class ChildTerminated(name: String) extends Command

  def apply(): Behavior[Command] = {
    def updated(children: Map[String, ActorRef[Child.Command]]): Behavior[Command] = {
      Behaviors.receive { (context, command) =>
        command match {
          case DelegateToChild(name, childCommand) =>
            children.get(name) match {
              case Some(ref) =>
                ref ! childCommand
                Behaviors.same
              case None =>
                context.log.info(s"Creating child: $name")  
                val ref = context.spawn(Child(), name)
                context.watchWith(ref, ChildTerminated(name))
                ref ! childCommand
                updated(children + (name -> ref))
            }

          case ChildTerminated(name) =>
            context.log.info(s"Removing child: $name")  
            updated(children - name)
        }
      }
    }

    updated(Map.empty)
  }
  
  object Child{
    sealed trait Command 
    case class Request(msg:Any) extends Command 
    case object Stop extends Command 
    
    def apply(): Behavior[Command] = Behaviors.receive { (context, msg) =>
        context.log.info(s"New msg received: $msg")  
        msg match{
            case Stop => 
                println(s"${context.self} stopping")
                Behaviors.stopped  
            case Request(msg) => Behaviors.same    
        }
    }  
  }
}
//Usage 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


val close = TypedActorHelper.testGuardianSystem(Parent()){ system =>
    implicit val timeOut:akka.util.Timeout = 1.minutes 
    import system._  //bring ExecutionContext 
    import Parent._     
    
    system ! DelegateToChild("echo1", Child.Request("hello echo1"))
    system ! DelegateToChild("echo2", Child.Request("hello echo2"))
    system ! DelegateToChild("echo1", Child.Stop)
    
    system.whenTerminated.map{ done =>
        system.log.warn("Terminated")
    }
    //All would be autoterminated     
}
close()

///Example - Obtaining Actor references by Receptionist -- ADVANCED *
The registry is dynamic. New actors can be registered during the lifecycle of the system. 
Entries are removed when registered actors are stopped, manually deregistered or the node 
they live on is removed from the Cluster. 

//Example 
import akka.actor.typed.receptionist._
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._

//First we create a PingService actor and register it with the Receptionist 
//against a ServiceKey that will later be used to lookup the reference
object PingService {
  val PingServiceKey = ServiceKey[Ping]("pingService")
  //it has PingServiceKey.Listing(reachable:Set[ActorRef[T]]) to simplify searching

  sealed trait PingServiceCommand 
  final case class Ping(replyTo: ActorRef[Pong.type]) extends PingServiceCommand
  final case object Pong
  case object Deregister  extends PingServiceCommand

  def apply(): Behavior[PingServiceCommand] = {
    Behaviors.setup { context =>
      //Register[T](key: ServiceKey[T], service: ActorRef[T])
      //service: Who is serving 
      context.system.receptionist ! Receptionist.Register(PingServiceKey, context.self)

      Behaviors.receiveMessage {
        case Ping(replyTo) =>
          context.log.info("Pinged by {}", replyTo)
          replyTo ! Pong
          Behaviors.same
        case Deregister =>
            //deregister  
            context.system.receptionist ! Receptionist.Deregister(PingServiceKey, context.self)
            Behaviors.stopped
      }
    }
  }
}
//Subscribing means that the guardian actor will be informed of any new registrations 
//via a Listing message:

//but it’s also possible to request 
//a single Listing of the current state without receiving further updates 
//by sending the Receptionist.Find[T](key: ServiceKey[T], replyTo: ActorRef[Listing]) message to the receptionist. 

//Returns Listing[T](key: ServiceKey[T], serviceInstances: Set[ActorRef[T]]): Listing
object Guardian {
  sealed trait Command
  case object PingAll extends Command
  case object Stop extends Command 
  case object SpawnPing extends Command 
  private case class ListingResponse(listing: Receptionist.Listing) extends Command
  
  import PingService._ 
  
  //messageAdapter is used to convert the Receptionist.Listing to a message type 
  //that the Guardian understands ie <: Guardian.Command and auto-sends to Self 
  
  def apply(): Behavior[Command] = {
    Behaviors.setup[Command] { context =>
      
      //ActorContext[T].messageAdapter[U](f: (U) => T): ActorRef[U]
      val listingResponseAdapter = context.messageAdapter[Receptionist.Listing](ListingResponse(_))
      
      // Subscribe[T](key: ServiceKey[T], subscriber: ActorRef[Listing])
      context.system.receptionist ! Receptionist.Subscribe(PingServiceKey, listingResponseAdapter)

      Behaviors.receiveMessage {
        case SpawnPing  =>
            //spawnAnonymous[U](behavior: Behavior[U], props: Props = Props.empty): ActorRef[U]
            context.spawnAnonymous(PingService())  //PingService registers to Receptionist, so goes to istingResponse(..) case after this
            Behaviors.same
        
        case PingAll =>
          //Find[T](key: ServiceKey[T], replyTo: ActorRef[Listing]): Command
          context.system.receptionist ! Receptionist.Find(PingServiceKey, listingResponseAdapter)
          Behaviors.same
        
        case ListingResponse(PingServiceKey.Listing(listings)) =>
          listings/*Set[ActorRef[T]]*/.foreach{ ps => {
                context.log.info(s"Found $ps")
                //ps ! Ping(_) and then echo the result and die 
                //echoOnceAfterSendOnce[T, U](target: RecipientRef[T], reqFn:ActorRef[U]=>T):Behavior[U]
                val beh = TypedActorHelper.TestProb.echoOnceAfterSendOnce[Ping, Pong.type](ps, Ping(_))                
                context.spawnAnonymous(beh)
               }
            }
          Behaviors.same
        case Stop =>
            Behaviors.stopped
        case _ =>
            Behaviors.unhandled
      }
    }
  }
}

val close = TypedActorHelper.testGuardianSystem(Guardian()){ system =>
    implicit val timeOut:akka.util.Timeout = 1.minutes 
    import system._  //bring ExecutionContext 
    import Guardian._     
    
    system ! SpawnPing
    system ! SpawnPing
    system ! PingAll
    
    system.whenTerminated.map{ done =>
        system.log.warn("Terminated")
    }
    //All would be autoterminated     
}
close()


    
    

///Example Classic and Typed --ADVANCED *

//Classic Actor  spawning Typed Actor 
import akka.actor.typed.scaladsl.adapter._
import akka.{ actor => classic }
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


//typed Actor 
object Typed {
  sealed trait Command
  final case class Ping(replyTo: ActorRef[Pong.type]) extends Command
  case object Pong

  def apply(): Behavior[Command] =
    Behaviors.receive { (context, message) =>
      message match {
        case Ping(replyTo) =>
          context.log.warn(s"${context.self} got Ping from $replyTo")
          // replyTo is a classic actor that has been converted for coexistence
          replyTo ! Pong
          Behaviors.same
      }
    }
}

//Classic 
object Classic {
  def props = classic.Props(new Classic)
}
class Classic extends classic.Actor with classic.ActorLogging {
  // context.spawn is an implicit extension method
  //can be used to start Typed 
  val second: ActorRef[Typed.Command] =
    context.spawn(Typed(), "second")

  // context.watch is an implicit extension method
  context.watch(second)

  // self can be used as the `replyTo` parameter here because
  // there is an implicit conversion from akka.actor.ActorRef to
  // akka.actor.typed.ActorRef
  // An alternative would be `self.toTyped`
  second ! Typed.Ping(self)

  override def receive = {
    case Typed.Pong =>
      log.info(s"$self got Pong from ${sender()}")
      // context.stop is an implicit extension method
      context.stop(second)
    case classic.Terminated(ref) =>
      log.info(s"$self observed termination of $ref")
      context.stop(self)
  }
}

val system = classic.ActorSystem("ClassicToTypedSystem")
val typedSystem: ActorSystem[Nothing] = system.toTyped
val classicActor = system.actorOf(Classic.props)

system.terminate()



//Typed Actor spawning classic Actor 
object Classic {
  def props(): classic.Props = classic.Props(new Classic)
}
class Classic extends classic.Actor {
  override def receive = {
    case Typed.Ping(replyTo) =>
      println("Classic Ping")
      replyTo ! Typed.Pong
  }
}

//Then the typed actor creates the classic actor, watches it and sends and receives a response:
object Typed {
  final case class Ping(replyTo: akka.actor.typed.ActorRef[Pong.type])
  sealed trait Command
  case object Pong extends Command

  val behavior: Behavior[Command] =
    Behaviors.setup { context =>
      // context.actorOf is an implicit extension method
      val classic = context.actorOf(Classic.props(), "second")

      // context.watch is an implicit extension method
      context.watch(classic)

      // illustrating how to pass sender, toClassic is an implicit extension method
      classic.tell(Typed.Ping(context.self), context.self.toClassic)

      Behaviors.receivePartial[Command] {
          case (context, Pong) =>
            // it's not possible to get the sender, that must be sent in message
            // context.stop is an implicit extension method
            println("Typed Pong")
            context.stop(classic)
            Behaviors.same
        }.receiveSignal {
          case (_, akka.actor.typed.Terminated(_)) =>
            Behaviors.stopped
        }
    }
}

//Creating the actor system and the typed actor:
val system = classic.ActorSystem("TypedWatchingClassic")
val typed = system.spawn(Typed.behavior, "Typed")
//after sometime 
system.terminate()
    

///Supervision Strategy -- ADVANCED * 
import akka.actor.typed.receptionist._
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


object Counter {
  sealed trait Command
  case class Increment(nr: Int) extends Command
  case class GetCount(replyTo: ActorRef[Int]) extends Command
  case class Raise(t: Throwable) extends Command

  //restart, resume, stop 
  def apply(strategy: SupervisorStrategy = SupervisorStrategy.restart): Behavior[Command] =
    //supervision only needs to be added to the top level
    //Each returned behavior will be re-wrapped automatically with the supervisor.    
    //Behaviors.supervise[T](wrapped: Behavior[T]): Supervise[T]   
    //onFailure[Thr <: Throwable](strategy: SupervisorStrategy): Behavior[T]    
    Behaviors.supervise(counter(1)).onFailure(strategy)

  //With the functional style it is very common to store state by changing behavior recursively 
  private def counter(count: Int): Behavior[Command] =
    Behaviors.receiveMessage[Command] {
      case Increment(nr: Int) =>
        counter(count + nr)
      case GetCount(replyTo) =>
        replyTo ! count
        Behaviors.same
      case Raise(t) =>
        throw  t 
        Behaviors.same
    }
}

//with restart, counter state resets 
val close = TypedActorHelper.testGuardianSystem(Counter()){ system =>
    import scala.concurrent.duration._ 
    import Counter._     
    
    import akka.actor.typed.scaladsl.AskPattern._
    implicit val scheduler = system.scheduler 
    implicit val timeout: akka.util.Timeout = 3.seconds    
    implicit val ec = system.executionContext
    
    val echo = system.systemActorOf(TypedActorHelper.TestProb.echo[Any](), "sender")
    
    0 to 10 foreach { i => system ! Increment(i) }
    system ! GetCount(echo)
    system ! Raise(new IllegalStateException("Boom"))
    
    0 to 10 foreach { i => system ! Increment(i) }
    system ! GetCount(echo)
}
close()  //both times count =56 as initial state = 1 + 0to10

//with resume, counter state does not reset 
val close = TypedActorHelper.testGuardianSystem(Counter(SupervisorStrategy.resume)){ system =>
    import scala.concurrent.duration._ 
    import Counter._     
    
    import akka.actor.typed.scaladsl.AskPattern._
    implicit val scheduler = system.scheduler 
    implicit val timeout: akka.util.Timeout = 3.seconds    
    implicit val ec = system.executionContext
    
    val echo = system.systemActorOf(TypedActorHelper.TestProb.echo[Any](), "sender")
    
    0 to 10 foreach { i => system ! Increment(i) }
    system ! GetCount(echo)
    system ! Raise(new IllegalStateException("Boom"))
    0 to 10 foreach { i => system ! Increment(i) }
    system ! GetCount(echo)
}
close() //Now count is 56+55 = 111



///More on Fault Tolerance --ADVANCED
//SupervisorStrategy.restart without children stopping 
Child actors are stopped when parent is restarting, 
Note Behaviors.setup is inside Behaviors.supervise and SupervisorStrategy.restart is used 
So, Behaviors.setup is again executed during restart so child actors are created 
//Example 
def child(size: Long): Behavior[String] =
  Behaviors.receiveMessage(msg => child(size + msg.length))

def parent: Behavior[String] = {
  Behaviors
    .supervise[String] {
      Behaviors.setup { ctx =>
        val child1 = ctx.spawn(child(0), "child1")
        val child2 = ctx.spawn(child(0), "child2")

        Behaviors.receiveMessage[String] { msg =>
          // message handling that might throw an exception
          val parts = msg.split(" ")
          child1 ! parts(0)
          child2 ! parts(1)
          Behaviors.same
        }
      }
    }.onFailure(SupervisorStrategy.restart)
}

It is possible to override this so that child actors are not influenced 
The restarted parent instance will then have the same children as before the failure.

Note Behaviors.setup is outside Behaviors.supervise 
and SupervisorStrategy.restart.withStopChildren(false) is used 
//Example 
def parent2: Behavior[String] = {
  Behaviors.setup { ctx =>
    val child1 = ctx.spawn(child(0), "child1")
    val child2 = ctx.spawn(child(0), "child2")

    // supervision strategy inside the setup to not recreate children on restart
    Behaviors
      .supervise {
        Behaviors.receiveMessage[String] { msg =>
          // message handling that might throw an exception
          val parts = msg.split(" ")
          child1 ! parts(0)
          child2 ! parts(1)
          Behaviors.same
        }
      }.onFailure(SupervisorStrategy.restart.withStopChildren(false))
  }
}

//The PreRestart and PostStop signal
When an actor is stopped(but not restarted), 
it receives the PostStop signal that can be used for cleaning up resources. 

Before a supervised actor is restarted it is sent the PreRestart signal giving it a chance 
to clean up resources it has created, much like the PostStop signal when the actor stops. 

The returned behavior from the PreRestart signal is ignored.
Note that PostStop is not emitted for a restart, so typically you need to handle both PreRestart 
and PostStop to cleanup resources.

Signal is handled by 
    Behaviors.receiveSignal[T](handler: PartialFunction[(ActorContext[T], Signal), Behavior[T]]): Behavior[T] 
    Behavior[T].receiveSignal(onSignal: PartialFunction[(ActorContext[T], Signal), Behavior[T]]): Behavior[T] 
        Signals are 
        ChildFailed, MessageAdaptionFailure, PostStop, 
        PreRestart,  Terminated, DeleteEventsCompleted, DeleteEventsFailed, 
        DeleteSnapshotsCompleted, DeleteSnapshotsFailed, EventSourcedSignal, 
        RecoveryCompleted, RecoveryCompleted, RecoveryFailed, SnapshotCompleted, SnapshotFailed

//Example 
def claimResource() = new {
    println(s"claimResource")
    def process(parts: Array[String]) = println(s"resource.process")
    def close() = println(s"resource.close")
}

def withPreRestart: Behavior[String] = {
  Behaviors
    .supervise[String] {
      Behaviors.setup { ctx =>
        val resource = claimResource()

        Behaviors
          .receiveMessage[String] { msg =>
            // message handling that might throw an exception
            val parts = msg.split(" ")
            resource.process(parts)
            Behaviors.same
          }
          .receiveSignal {
            case (context, signal) if signal == PreRestart || signal == PostStop =>
              resource.close()
              Behaviors.same
          }
          /* or Could be written as 
          .receiveSignal{
              case (context, PostStop) =>
                context.log.info("Worker {} stopped", name)
                resource.close()
                Behaviors.same
              case (context, PreRestart) =>
                context.log.info("Worker {} starting", name)
                resource.close()
                Behaviors.same
            }
         */ 
      }
    }.onFailure[Exception](SupervisorStrategy.restart)
}

//Bubble failures up through the hierarchy
To push the decision about what to do on a failure upwards in the Actor hierarchy 
and let the parent actor handle what should happen on failures 
(in classic Akka Actors this is how it works by default).

final case class DeathPactException(ref: ActorRef[Nothing]) extends RuntimeException 
    Exception that an actor fails with if it does not handle a Terminated message. 

//Example 
import akka.actor.typed.receptionist._
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._

object Protocol {
  sealed trait Command
  case class Fail(text: String) extends Command
  case class Hello(text: String, replyTo: ActorRef[String]) extends Command
}

object Worker {
  import Protocol._
  
  def apply(): Behavior[Command] =
    Behaviors.receiveMessage {
      case Fail(text) =>
        throw new RuntimeException(text)
      case Hello(text, replyTo) =>
        replyTo ! text
        Behaviors.same
    }
}

object MiddleManagement {
  import Protocol._
  
  def apply(): Behavior[Command] =
    Behaviors.setup[Command] { context =>
      context.log.warn("Middle management starting up")
      // default supervision of child, meaning that it will stop on failure
      val child = context.spawn(Worker(), "child")
      context.watch(child) //Parent would get Terminated Signal if Child stops

      // here we don't handle Terminated at all which means that
      // when the child fails or stops gracefully this actor will
      // fail with a DeathPactException as there is no supervisionStrategy on this Behavior
      Behaviors.receiveMessage { message =>
        child ! message
        Behaviors.same
      }
      /*
      //we don't handle Terminated
      .receiveSignal {
        case (context, Terminated(ref)) =>
          context.log.info("child stopped: {}", ref.path.name)
          Behaviors.same
      }
      */
    }
}

object Boss {
  def apply(): Behavior[Command] =
    Behaviors
      .supervise(Behaviors.setup[Command] { context =>
        context.log.warn("Boss starting up") 
        // default supervision of child, meaning that it will stop on failure
        val middleManagement = context.spawn(MiddleManagement(), "middle-management")
        context.watch(middleManagement) //Parent would get Terminated Signal if Child stops

        // here we don't handle Terminated at all which means that
        // when middle management fails with a DeathPactException
        // this actor will also fail and then supervisionStrategy would restart this actor ...
        Behaviors.receiveMessage[Command] { message =>
          middleManagement ! message
          Behaviors.same
        }
      })
      .onFailure[DeathPactException](SupervisorStrategy.restart)
}

val close = TypedActorHelper.testGuardianSystem(Boss()){ system =>
    import Protocol._     
    
    system ! Hello("Hello", system.ignoreRef[Any])
    system ! Fail("failed")
    
}
close()
//Output 
Boss starting up
Middle management starting up
failed
java.lang.RuntimeException: failed
Boss - death pact with Actor[akka://guardiansystem_under_test/user/middle-management/child#-1031481938] was triggered
Boss - Supervisor RestartSupervisor saw failure: death pact with Actor[akka://guardiansystem_under_test/user/middle-management#1383833299] was triggered
Boss starting up
Middle management starting up


///Few other methods of Behaviours -- ADVANCED  
Behaviors
    def empty[T]: Behavior[T]
        A behavior that treats every incoming message as unhandled.
    def ignore[T]: Behavior[T]
        A behavior that ignores every incoming message and returns "same".
    def logMessages[T](logOptions: LogOptions, behavior: Behavior[T]): Behavior[T]
        Behavior decorator that logs all messages to the akka.actor.typed.Behavior 
        using the provided akka.actor.typed.LogOptions configuration 
        before invoking the wrapped behavior.
        LogOptions()
            def withEnabled(enabled: Boolean): LogOptions
                User control whether messages are logged or not.
            def withLevel(level: Level): LogOptions
                The akka.event.Logging.LogLevel to use when logging messages.
            def withLogger(logger: Logger): LogOptions
                A org.slf4j.Logger to use when logging messages.  
    def logMessages[T](behavior: Behavior[T]): Behavior[T]
        Behavior decorator that logs all messages to the akka.actor.typed.Behavior 
        using the provided akka.actor.typed.LogOptions default configuration 
        before invoking the wrapped behavior.
    def monitor[T](monitor: ActorRef[T], behavior: Behavior[T])(implicit arg0: ClassTag[T]): Behavior[T]
        Behavior decorator that copies all received message to the designated 'monitor' 
        akka.actor.typed.ActorRef before invoking the wrapped behavior.
        
//Example 
import akka.actor.typed.receptionist._
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._

def close(enabled:Boolean) = TypedActorHelper.testGuardianSystem(Behaviors.ignore[Any]){ system =>
    import scala.concurrent.duration._ 
    val echoActor = system.systemActorOf(TypedActorHelper.TestProb.echo[Any](), "echo")
    
    val logactor  =  system.systemActorOf( 
        Behaviors.logMessages[Any]( 
            LogOptions().withLevel(org.slf4j.event.Level.WARN).withEnabled(enabled),
        TypedActorHelper.TestProb.echo[Any]() ), "logecho")
        
    val monactor  =  system.systemActorOf(     
        Behaviors.monitor[Any](echoActor,  TypedActorHelper.TestProb.echo[Any]() ), "monecho")        
        
    logactor ! "Hello1"  
    monactor ! "Hello2" //two times , one from eachActor, other from nested to monactor 
}
close(true)()  
//logecho logs with WARN , so two times(one from LogInterceptor and other from Actor) prining Hello1 
close(false)()  
//log from LogInterceptor disabled and only one from Actor  prining Hello1 

///BehaviorInterceptor -- ADVANCED  
class BehaviorInterceptor[Outer, Inner] extends AnyRef
    Outer
        The outer message type – the type of messages the intercepting behavior will accept
    Inner
        The inner message type - the type of message the wrapped behavior accepts
    
    abstract def aroundReceive(ctx: TypedActorContext[Outer], msg: Outer, target: ReceiveTarget[Inner]): Behavior[Inner]
        Implement this 
    def aroundSignal(ctx: TypedActorContext[Outer], signal: Signal, target: SignalTarget[Inner]): Behavior[Inner]
        Override to intercept a signal sent to the running actor.
    def aroundStart(ctx: TypedActorContext[Outer], target: PreStartTarget[Inner]): Behavior[Inner]
        Override to intercept actor startup.
    val interceptMessageClass: Class[Outer]
    def isSame(other: BehaviorInterceptor[Any, Any]): Boolean

TypedActorContext[T]
    asScala: scaladsl.ActorContext[T]
    
trait ReceiveTarget[T]
    def apply(ctx: TypedActorContext[_], msg: T): Behavior[T]
     
trait PreStartTarget[T]
    def start(ctx: TypedActorContext[_]): Behavior[T]
trait SignalTarget[T]
    def apply(ctx: TypedActorContext[_], signal: Signal): Behavior[T]

Behaviors
    def empty[T]: Behavior[T]
        A behavior that treats every incoming message as unhandled.
    def ignore[T]: Behavior[T]
        A behavior that ignores every incoming message and returns "same".
    def intercept[Outer, Inner](behaviorInterceptor: () => BehaviorInterceptor[Outer, Inner])(behavior: Behavior[Inner]): Behavior[Outer]
        Intercept messages and signals for a behavior by first passing them 
        to a akka.actor.typed.BehaviorInterceptor
        inner behaviour accepts Inner 
        Interceptor is external world centric , which accepts Outer 
class Behavior[T]
    def narrow[U <: T]: Behavior[U]
    
//Example 
import akka.actor.typed.receptionist._
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._


object MultiProtocol {
 //User sees these 
  final case class ExternalResponse(s: String)
  final case class Command(s: String)

  //internal Actor gets these 
  sealed trait InternalProtocol
  object InternalProtocol {
    final case class WrappedCommand(c: Command) extends InternalProtocol
    final case class WrappedExternalResponse(r: ExternalResponse) extends InternalProtocol
  }
  import BehaviorInterceptor._ 
  
  //Accepts Any and converts to InternalProtocol, BehaviorInterceptor[Outer, Inner]
  private class ProtocolTransformer extends BehaviorInterceptor[Any, InternalProtocol] {
    
    //def aroundReceive(ctx: TypedActorContext[Outer], msg: Outer, target: ReceiveTarget[Inner]): Behavior[Inner]
    override def aroundReceive(
        ctx: TypedActorContext[Any],
        msg: Any,
        target: ReceiveTarget[InternalProtocol]): Behavior[InternalProtocol] = {
      ctx.log.info(s"Intercepted, $msg")
      val wrapped = msg match {
        case c: Command          => InternalProtocol.WrappedCommand(c)
        case r: ExternalResponse => InternalProtocol.WrappedExternalResponse(r)
      }
      //ReceiveTarget(ctx: TypedActorContext[_], msg: T): Behavior[T]
      target(ctx, wrapped)
    }
  }
  
  //Accepts Command , but internally handles InternalProtocol
  def apply(probe: ActorRef[String]): Behavior[Command] = {
    Behaviors
      .intercept(() => new ProtocolTransformer)(Behaviors.receiveMessage[InternalProtocol] {
        case InternalProtocol.WrappedCommand(cmd) =>
          probe ! cmd.s
          Behaviors.same
        case InternalProtocol.WrappedExternalResponse(rsp) =>
          probe ! rsp.s
          Behaviors.same
      }).narrow
  }
  //Another one, Takes String and output Strings 
  private def snitchingInterceptor(probe: ActorRef[String]) = new BehaviorInterceptor[String, String] {
    override def aroundReceive(
        context: TypedActorContext[String],
        message: String,
        target: ReceiveTarget[String]): Behavior[String] = {
      probe ! ("before " + message)
      val b = target(context, message)
      probe ! ("after " + message)
      b
    }
    // keeping the instance equality as "isSame" for these
  }
  
  def snitch(probe: ActorRef[String]): Behavior[String] = {
    Behaviors
      .intercept(() => snitchingInterceptor(probe) )(Behaviors.receiveMessage[String] {
        case msg =>
          probe ! msg
          Behaviors.same
      }).narrow
  }
}

  
val close = TypedActorHelper.testGuardianSystem(Behaviors.ignore[Any]){ system =>
    import scala.concurrent.duration._ 
    import MultiProtocol._ 
    
    val echoActor = system.systemActorOf(TypedActorHelper.TestProb.echo[Any](), "echo")
    
    val transformA  =  system.systemActorOf(MultiProtocol(echoActor) , "logecho")
        
    val snitchA  =  system.systemActorOf( snitch(echoActor)  , "monecho")        
        
    snitchA ! "Hello012"  
    transformA ! Command("Hello23456")   
}
close()


///Using a customised dispatcher --ADVANCED
If not specified, the actor will use the default dispatcher

//Types of dispatchers
There are 2 different types of message dispatchers:

Dispatcher
    This is an event-based dispatcher that binds a set of Actors to a thread pool. 
    The default dispatcher is used if no other is specified.
        Shareability: Unlimited
        Mailboxes: Any, creates one per Actor
        Use cases: Default dispatcher, Bulkheading
        Driven by: java.util.concurrent.ExecutorService. 
        Specify using 'executor' using 'fork-join-executor', 'thread-pool-executor' 
        or the fully-qualified class name of an akka.dispatcher.ExecutorServiceConfigurator implementation.
    //Example - Here is an example configuration of a Fork Join Pool dispatcher:
    my-dispatcher {
      # Dispatcher is the name of the event-based dispatcher
      type = Dispatcher
      # What kind of ExecutionService to use
      executor = "fork-join-executor"
      # Configuration for the fork join pool
      fork-join-executor {
        # Min number of threads to cap factor-based parallelism number to
        parallelism-min = 2
        # Parallelism (threads) ... ceil(available processors * factor)
        parallelism-factor = 2.0
        # Max number of threads to cap factor-based parallelism number to
        parallelism-max = 10
      }
      # Throughput defines the maximum number of messages to be
      # processed per actor before the thread jumps to the next actor.
      # Set to 1 for as fair as possible.
      throughput = 100
    }

PinnedDispatcher (use for blocking ops)
    This dispatcher dedicates a unique thread for each actor using it; 
    i.e. each actor will have its own thread pool with only one thread in the pool.
        Shareability: None
        Mailboxes: Any, creates one per Actor
        Use cases: Bulkheading
        Driven by: Any akka.dispatch.ThreadPoolExecutorConfigurator. 
        By default a 'thread-pool-executor'.
    A separate thread is dedicated for each actor that is configured to use the pinned dispatcher.
    //Example 
    my-pinned-dispatcher {
      executor = "thread-pool-executor"
      type = PinnedDispatcher
    }
    

//Using 
ActorContext[T] 
    def spawn[U](behavior: Behavior[U], name: String, props: Props = Props.empty): ActorRef[U]
        Create a child Actor from the given akka.actor.typed.Behavior and with the given name.
    def spawnAnonymous[U](behavior: Behavior[U], props: Props = Props.empty): ActorRef[U]
        Create a child Actor from the given akka.actor.typed.Behavior under a randomly chosen name.

object DispatcherSelector
    def blocking(): DispatcherSelector
        Run the actor on the default blocking dispatcher that is configured 
        under default-blocking-io-dispatcher
    def default(): DispatcherSelector
        Run the actor on the default ActorSystem executor.
    def fromConfig(path: String): DispatcherSelector
        Look up an executor definition in the ActorSystem configuration.
    def sameAsParent(): DispatcherSelector
        Run the actor on the same executor as the parent actor.
object Props 
    val empty: Props
class Props 
    def withDispatcherDefault: Props
    def withDispatcherFromConfig(path: String): Props
    def withDispatcherSameAsParent: Props
        
//Various ways to select dispatchers 
import akka.actor.typed.DispatcherSelector

context.spawn(Behavior[U], "actor-name")

//to look up the default dispatcher
context.spawn(Behavior[U], "actor-name", DispatcherSelector.default())

//blocking can be used to execute actors that block e.g. a legacy database API that does not support Futures
context.spawn(Behavior[U], "actor-name", DispatcherSelector.blocking())

// to use the same dispatcher as the parent actor
context.spawn(Behavior[U], "actor-name", DispatcherSelector.sameAsParent())

//or from config file 
context.spawn(Behavior[U], "actor-name", DispatcherSelector.fromConfig("my-dispatcher"))

// for use with Futures, Scheduler, etc.
import akka.actor.typed.DispatcherSelector
implicit val executionContext = context.system.dispatchers.lookup(DispatcherSelector.fromConfig("my-dispatcher"))   
    

       
//Quick conf setup: Note default config file is application.conf or set via 
//https://doc.akka.io/docs/akka/current/general/configuration-reference.html

object ActorSystem
    def apply[T](guardianBehavior: Behavior[T], name: String, config: Config, guardianProps: Props): ActorSystem[T]
    def apply[T](guardianBehavior: Behavior[T], name: String, config: Config): ActorSystem[T]
    def apply[T](guardianBehavior: Behavior[T], name: String): ActorSystem[T]
        Using default applicaton.conf 

//example 
import com.typesafe.config.ConfigFactory
val customConf = ConfigFactory.parseString("""
  akka.log-config-on-start = on
""")
// ConfigFactory.load sandwiches customConfig between default reference
// config and default overrides, and then resolves it.
val system = ActorSystem(rootBehavior, "MySystem", ConfigFactory.load(customConf))
//OR from config file 
val system = ActorSystem(rootBehavior, "MySystem", ConfigFactory.load(configFilename))


//Example 
//dispatcherExample.conf 
blockactor-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}

my-dispatcher {
  type = Dispatcher
  executor = "thread-pool-executor"
  thread-pool-executor {
    fixed-pool-size = 32
  }
  throughput = 1
}   

//Example 
import akka.actor.typed.receptionist._
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._

def helloWorld(): Behavior[String] =
  Behaviors.setup { context =>
    Behaviors.receiveMessage { message =>
      Thread.sleep(1000)
      context.log.info("Did a long computation")
      Behaviors.same
    }
}

def guardian(): Behavior[String] =
  Behaviors.setup { context =>

    val props = DispatcherSelector.fromConfig("blockactor-dispatcher")
    val greeter = context.spawn(helloWorld(), "greeter", props)

    Behaviors.receiveMessage { message =>
      greeter ! message
      Behaviors.same
    }
}

//Using 
//ActorSystem[T](guardianBehavior: Behavior[T], name: String, config: Config): ActorSystem[T]
val close = TypedActorHelper.testGuardianSystemWithConfig(guardian(), "dispatcherExample.conf"){ system =>
    system ! "Hello012"  
}
close()

      

//Blocking Needs Careful Management 
//In application.conf, the dispatcher dedicated to blocking behavior 
//should be configured as seperate from default dispatchers 
my-blocking-dispatcher {
  type = Dispatcher
  executor = "thread-pool-executor"
  thread-pool-executor {
    fixed-pool-size = 8
  }
  throughput = 1
}
//or create a PinnedDispatcher 
blockactor-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}

//Whenever blocking has to be done, use the above configured dispatcher instead of the default one:
object BlockingActor {
 import scala.concurrent._ 
 
 def apply(): Behavior[Int] =
   Behaviors.setup { context =>
     val blockEC: ExecutionContext =
       context.system.dispatchers.lookup(DispatcherSelector.fromConfig("blockactor-dispatcher"))

     Behaviors.receiveMessage { i =>
       triggerFutureBlockingOperation(i)(blockEC) //could define blockEC as implicit 
       Behaviors.same
     }
   }

 def triggerFutureBlockingOperation(i: Int)(implicit ec: ExecutionContext): Future[Unit] = {
   println(s"Calling blocking Future: $i")
   Future {
     Thread.sleep(5000) //block for 5 seconds
     println(s"Blocking future finished $i")
   }
 }
}

//Using 
//ActorSystem[T](guardianBehavior: Behavior[T], name: String, config: Config): ActorSystem[T]
val close = TypedActorHelper.testGuardianSystemWithConfig(BlockingActor(), "dispatcherExample.conf"){ system =>
    system ! "Hello012"  
}
close()

    
///MailBox  --ADVANCED
MailboxSelector
    def bounded(capacity: Int): MailboxSelector
        A mailbox with a max capacity after which new messages are dropped (passed to deadletters).
    def default(): MailboxSelector
        The default mailbox is SingleConsumerOnlyUnboundedMailbox
    def fromConfig(path: String): MailboxSelector
        Select a mailbox from the config file using an absolute config path.


//Selecting a Mailbox Type for an Actor
To select a specific mailbox for an actor use MailboxSelector to create a Props instance 
for spawning your actor:

//Example 
context.spawn(childBehavior, "actor_name", MailboxSelector.bounded(100))
//OR 
val props = MailboxSelector.fromConfig("my-app.my-special-mailbox")
context.spawn(childBehavior, "actor_name", props)

//fromConfig takes an absolute config path in application.conf :
my-app {
  my-special-mailbox {
    mailbox-type = "akka.dispatch.SingleConsumerOnlyUnboundedMailbox"
  }
}
blockactor-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}
//Note To use dispatcher as well , use 
val props = MailboxSelector.fromConfig("my-app.my-special-mailbox")
    .withDispatcherFromConfig("blockactor-dispatcher")
context.spawn(childBehavior, "actor_name", props)


//Mailbox Implementations
The default mailbox is used when the mailbox is not specified 
and is the SingleConsumerOnlyUnboundedMailbox

SingleConsumerOnlyUnboundedMailbox (default)
    This is the default
    Backed by a Multiple-Producer Single-Consumer queue, cannot be used with BalancingDispatcher
    Blocking: No
    Bounded: No
    Configuration name: "akka.dispatch.SingleConsumerOnlyUnboundedMailbox"
    
UnboundedMailbox
    Backed by a java.util.concurrent.ConcurrentLinkedQueue
    Blocking: No
    Bounded: No
    Configuration name: "unbounded" or "akka.dispatch.UnboundedMailbox"
NonBlockingBoundedMailbox
    Backed by a very efficient Multiple-Producer Single-Consumer queue
    Blocking: No (discards overflowing messages into deadLetters)
    Bounded: Yes
    Configuration name: "akka.dispatch.NonBlockingBoundedMailbox"
UnboundedControlAwareMailbox
    Delivers messages that extend akka.dispatch.ControlMessage with higher priority
    Backed by two java.util.concurrent.ConcurrentLinkedQueue
    Blocking: No
    Bounded: No
    Configuration name: "akka.dispatch.UnboundedControlAwareMailbox"
UnboundedPriorityMailbox
    Backed by a java.util.concurrent.PriorityBlockingQueue
    Delivery order for messages of equal priority is undefined - contrast with the UnboundedStablePriorityMailbox
    Blocking: No
    Bounded: No
    Configuration name: "akka.dispatch.UnboundedPriorityMailbox"
UnboundedStablePriorityMailbox
    Backed by a java.util.concurrent.PriorityBlockingQueue wrapped in an akka.util.PriorityQueueStabilizer
    FIFO order is preserved for messages of equal priority - contrast with the UnboundedPriorityMailbox
    Blocking: No
    Bounded: No
    Configuration name: "akka.dispatch.UnboundedStablePriorityMailbox"

Other bounded mailbox implementations which will block the sender if the capacity is reached 
and configured with non-zero mailbox-push-timeout-time.
The following mailboxes should only be used with zero mailbox-push-timeout-time.
    BoundedMailbox
        Backed by a java.util.concurrent.LinkedBlockingQueue
        Blocking: Yes if used with non-zero mailbox-push-timeout-time, otherwise No
        Bounded: Yes
        Configuration name: "bounded" or "akka.dispatch.BoundedMailbox"
    BoundedPriorityMailbox
        Backed by a java.util.PriorityQueue wrapped in an akka.util.BoundedBlockingQueue
        Delivery order for messages of equal priority is undefined - contrast with the BoundedStablePriorityMailbox
        Blocking: Yes if used with non-zero mailbox-push-timeout-time, otherwise No
        Bounded: Yes
        Configuration name: "akka.dispatch.BoundedPriorityMailbox"
    BoundedStablePriorityMailbox
        Backed by a java.util.PriorityQueue wrapped in an akka.util.PriorityQueueStabilizer and an akka.util.BoundedBlockingQueue
        FIFO order is preserved for messages of equal priority - contrast with the BoundedPriorityMailbox
        Blocking: Yes if used with non-zero mailbox-push-timeout-time, otherwise No
        Bounded: Yes
        Configuration name: "akka.dispatch.BoundedStablePriorityMailbox"
    BoundedControlAwareMailbox
        Delivers messages that extend akka.dispatch.ControlMessage with higher priority
        Backed by two java.util.concurrent.ConcurrentLinkedQueue and blocking on enqueue if capacity has been reached
        Blocking: Yes if used with non-zero mailbox-push-timeout-time, otherwise No
        Bounded: Yes
        Configuration name: "akka.dispatch.BoundedControlAwareMailbox"
        
    



///Stash --ADVANCED
Stashing enables an actor to temporarily buffer all or some messages that cannot or 
should not be handled using the actors current behavior.
When Unstashed, all those buffered messages are handled one by one 

One important thing to be aware of is that the StashBuffer is a buffer 
and stashed messages will be kept in memory until they are unstashed 
(or the actor is stopped and garbage collected). 

Its recommended to avoid stashing too many messages to avoid too much memory usage 
and even risking OutOfMemoryError if many actors are stashing many messages. 
Therefore the StashBuffer is bounded and the capacity of how many messages 
it can hold must be specified when it’s created.

//Uses 
def Behaviors.receiveMessagePartial[T](onMessage: PartialFunction[T, Behavior[T]]): Receive[T]
    Construct an actor Behavior from a partial message handler which treats undefined messages as unhandled.
def Behaviors.receivePartial[T](onMessage: PartialFunction[(ActorContext[T], T), Behavior[T]]): Receive[T]
    Construct an actor Behavior from a partial message handler which treats undefined messages as unhandled.
def Behaviors.withStash[T](capacity: Int)(factory: (StashBuffer[T]) => Behavior[T]): Behavior[T]
        Support for stashing messages to unstash at a later time.
        
StashBuffer[T]
    Many methods like ListBuffer 
    def foreach(f: (T) => Unit): Unit
    def head: T
    def isEmpty: Boolean
    def isFull: Boolean
    def nonEmpty: Boolean
    def size: Int
    def stash(message: T): StashBuffer[T]
        Add one element to the end of the message buffer.
    def unstash(behavior: Behavior[T], numberOfMessages: Int, wrap: (T) => T): Behavior[T]
        Transition to the given behavior and process numberOfMessages of the stashed messages
        That means that other new messages may arrive in-between 
        and those must be stashed to keep the original order of messages. 
        To differentiate between unstashed and new incoming messages the unstashed messages 
        can be wrapped in another message with the wrap.
    def unstashAll(behavior: Behavior[T]): Behavior[T]
        Transition to the given behavior and process all stashed messages.
        Messages will be processed in the same order they arrived. 
        It is allowed to stash messages while unstashing. 
        Those newly added messages will not be processed by this call 
        and have to be unstashed in another call.
        The behavior passed to unstashAll must not be unhandled. 
//Simple Example 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._


object Actor {

    def one(): Behavior[String] = {
        Behaviors.withStash[String](100) { buffer =>  //Size 
          Behaviors.setup[String] { context =>
            Behaviors.receiveMessage {
              case "open" =>
                println("b1: open")
                buffer.unstashAll(two(buffer, context)) //all stashed message are handled in behaviour two  
                //returns two behaviour 
              case msg => 
                println(s"b1: stash-$msg")
                buffer.stash(msg)  //stash this message 
                Behaviors.same
            }
          }
        }
      }

    def two(buffer:StashBuffer[String], context:ActorContext[String]): Behavior[String] = {
            //must not be unhandled, so dont use *Partial 
            Behaviors.receiveMessage {
              case "write" => 
                println("b2: write")
                Behaviors.same
              case "close" =>
                println("b2: close")
                buffer.unstashAll(one()) //all stashed message are handled in behaviour one  
                //returns one behaviour 
              case msg => 
                println(s"b2: stash-$msg")
                buffer.stash(msg)  //stash this message 
                Behaviors.same
            }
      }
}

val close = TypedActorHelper.testGuardianSystem(Actor.one()){ system =>
    val seqs=Seq("some", "some", "open", "some", "some", "write", "some", "some", "close", "some", "open", "write", "close")
    seqs.foreach { m => system ! m}
}
close()
//output 
b1: stash-some
b1: open
b2: stash-some
b2: stash-some
b2: stash-some
b2: stash-some
b2: write
b2: stash-some
b2: stash-some
b2: close
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: open
b2: stash-some
b2: stash-some
b2: stash-some
b2: stash-some
b2: stash-some
b2: stash-some
b2: stash-some
b2: write
b2: close
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
b1: stash-some
    
    
//Complex example - Example 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._
import akka.Done 

class DB {
  var state:String = "oldState"
  def save(id: String, value: String): Future[Done] = {
        Thread.sleep(5000) //slow method 
        state = value 
        Future.successful(Done)
    }
  def load(id: String): Future[String]        = {
        Thread.sleep(5000) //slow method 
        Future.successful(s"$state")
    }
}

object DataAccess {
  sealed trait Command
  final case class Save(newstate: String, replyTo: ActorRef[Done]) extends Command
  final case class Get(replyTo: ActorRef[String]) extends Command  
  final case object OtherCommands extends Command
  
  private final case class InitialState(value: String) extends Command
  private final case object SaveSuccess extends Command
  private final case class DBError(cause: Throwable) extends Command

  def apply(id: String, db: DB): Behavior[Command] = {
    Behaviors.withStash(100) { buffer =>  //Size 
      Behaviors.setup[Command] { context =>
        new DataAccess(context, buffer, id, db).start()
      }
    }
  }
}

class DataAccess(
    context: ActorContext[DataAccess.Command],
    buffer: StashBuffer[DataAccess.Command],
    id: String,
    db: DB) {
  import DataAccess._

  def start(): Behavior[Command] = {
    context.pipeToSelf(db.load(id)) {  //Wrap it to Try of the output of load 
      case Success(value) => InitialState(value)
      case Failure(cause) => DBError(cause)
    }

    Behaviors.receiveMessage {
      case InitialState(value) =>
        // now we are ready to handle stashed messages if any by behavior  active 
        buffer.unstashAll(active(value)) 
      case DBError(cause) =>
        throw cause
      case other =>
        // stash all other messages for later processing
        buffer.stash(other)
        Behaviors.same
    }
  }

  private def active(state: String): Behavior[Command] = {
    Behaviors.receiveMessagePartial { //All unhandled messages are like Behaviors.unhandled
      case Get(replyTo) =>
        replyTo ! state
        Behaviors.same
      case Save(value, replyTo) =>
        context.pipeToSelf(db.save(id, value)) {
          case Success(_)     => SaveSuccess
          case Failure(cause) => DBError(cause)
        }
        saving(value, replyTo)
      case other =>
        println(s"$other")
        Behaviors.same
    }
  }

  private def saving(state: String, replyTo: ActorRef[Done]): Behavior[Command] = {
    Behaviors.receiveMessage {
      case SaveSuccess =>
        replyTo ! Done
        buffer.unstashAll(active(state))
      case DBError(cause) =>
        throw cause
      case other =>
        buffer.stash(other)
        Behaviors.same
    }
  }

}




  
val close = TypedActorHelper.testGuardianSystemWithConfig(Behaviors.ignore[Any], "dispatcherExample.conf"){ system =>
    import DataAccess._ 
    val actor = system.systemActorOf(DataAccess("ID", new DB), "DataAccess", DispatcherSelector.fromConfig("blockactor-dispatcher"))
    
    val echo = system.systemActorOf(TypedActorHelper.TestProb.echo[Any], "echo")
    Seq(OtherCommands, Get(echo), OtherCommands, Save("newState", echo), 
        OtherCommands, OtherCommands, Get(echo)).foreach { m => actor ! m }
}
close()
//Output 
OtherCommands
OtherCommands
New msg received: oldState
New msg received: Done
OtherCommands
New msg received: newState

    

///Routers    -- ADVANCED 
The router itself is a behavior that is spawned into a running actor that will then forward 
any message sent to it to one final recipient out of the set of routees.

Used for distribute messages of the same type over a set of actors, 
so that messages can be processed in parallel - 
a single actor will only process one message at a time. 

There are two kinds of routers included in Akka Typed - the pool router and the group router.
//Reference 
object Routers
    def group[T](key: ServiceKey[T]): GroupRouter[T]
        A router that will keep track of the available routees registered 
        to the akka.actor.typed.receptionist.Receptionist and route over those by random selection.
        Actor should register context.system.receptionist with that ServiceKey 
    def pool[T](poolSize: Int)(behavior: Behavior[T]): PoolRouter[T] 
    
trait PoolRouter[T] extends Behavior[T]
    def withConsistentHashingRouting(virtualNodesFactor: Int, mapping: (T) => String): PoolRouter[T]
    def withPoolSize(poolSize: Int): PoolRouter[T]
    def withRandomRouting(): PoolRouter[T]
    def withRoundRobinRouting(): PoolRouter[T]
    def withRouteeProps(routeeProps: Props): PoolRouter[T]
    val behavior: Behavior[T]
    def narrow[U <: T]: Behavior[U]
    def transformMessages[Outer](matcher: PartialFunction[Outer, T])(implicit arg0: ClassTag[Outer]): Behavior[Outer]
       
trait GroupRouter[T] extends Behavior[T]     
    def withConsistentHashingRouting(virtualNodesFactor: Int, mapping: (T) ⇒ String): GroupRouter[T]
    def withRandomRouting(preferLocalRoutees: Boolean): GroupRouter[T]
    def withRandomRouting(): GroupRouter[T]
    def withRoundRobinRouting(preferLocalRoutees: Boolean): GroupRouter[T]
    def withRoundRobinRouting(): GroupRouter[T]
    val behavior: Behavior[T]
    def narrow[U <: T]: Behavior[U]
    def transformMessages[Outer](matcher: PartialFunction[Outer, T])(implicit arg0: ClassTag[Outer]): Behavior[Outer]

    
//Pool Router 
The pool router is created with a routee Behavior and spawns a number of children 
with that behavior which it will then forward messages to.

If a child is stopped the pool router removes it from its set of routees. 
When the last child stops the router itself stops. 

To make a resilient router that deals with failures the routee Behavior must be supervised.

The PoolRouter has a property to configure the Props of its routees:

// make sure workers use the default blocking IO dispatcher
val blockingPool = pool.withRouteeProps(routeeProps = DispatcherSelector.blocking())
// spawn head router using the same executor as the parent
val blockingRouter = context.spawn(blockingPool, "blocking-pool", DispatcherSelector.sameAsParent())

There are two different strategies for selecting what routee a message is forwarded 
to that can be selected from the router before spawning it:
//Exmaple 
val alternativePool = pool.withPoolSize(2).withRoundRobinRouting()


//Group Router
The group router is created with a ServiceKey 
and uses the receptionist  to discover available actors 
for that key and routes messages to one of the currently known registered actors for a key.


//Example 

import akka.actor.typed.receptionist._ 
import akka.actor.typed.scaladsl._
import akka.actor.typed._
import scala.util._
import scala.concurrent._
import scala.concurrent.duration._
import akka.NotUsed 


object RouterExample {

    object Worker {
      sealed trait Command
      case class DoLog(text: String) extends Command

      def apply(): Behavior[Command] = Behaviors.setup { context =>
        context.log.warn("Starting worker")

        Behaviors.receiveMessage {
          case DoLog(text) =>
            context.log.info(s"${context.self.path} Got message {}", text)
            Behaviors.same
        }
      }
    }
    
    //Pool - creates all workers 
    object GuardianPool {
      def apply(): Behavior[Worker.Command] = {
        Behaviors
          .setup{ context =>
            //pool[T](poolSize: Int)(behavior: Behavior[T]): PoolRouter[T] 
            val pool = Routers.pool(poolSize = 4)(
                  // make sure the workers are restarted if they fail
                  Behaviors.supervise(Worker()).onFailure[Exception](SupervisorStrategy.restart)
                )
            val router = context.spawn(pool, "worker-pool")
            Behaviors.receiveMessage{
                case msg => 
                    router ! msg 
                    Behaviors.same 
            }
          }         
      }      
    }
    //Group - somebody else creates worker and register to receptionist
    object GuardianGroup {
      val serviceKey = ServiceKey[Worker.Command]("log-worker")
      //group[T](key: ServiceKey[T]): GroupRouter[T]
      val group = Routers.group(serviceKey)
    
      def apply(): Behavior[Worker.Command] = {
        Behaviors
          .setup { context =>               
            // this would likely happen elsewhere - if we create it locally we
            // can just as well use a pool
            (0 to 4).toList.foreach{i =>
                val worker = context.spawn(Worker(), s"worker$i")
                context.system.receptionist ! Receptionist.Register(serviceKey, worker)
            }            
            val router = context.spawn(group, "worker-group")            
            // (DOES NOT STASH!!)
            //the group router will stash messages until it sees the first listing of registered
            // services from the receptionist, so it is safe to send messages right away     
            Behaviors.receiveMessage{
                case msg => 
                    router ! msg 
                    Behaviors.same 
            }
          }    
      }      
    }
}

val close = TypedActorHelper.testGuardianSystem(RouterExample.GuardianGroup()){ system =>
    import RouterExample._ 
    (0 to 10).foreach { n =>
      system ! Worker.DoLog(s"msg $n")
    }
}
close()
val close = TypedActorHelper.testGuardianSystem(RouterExample.GuardianPool()){ system =>
    import RouterExample._ 
    (0 to 10).foreach { n =>
      system ! Worker.DoLog(s"msg $n")
    }
}
close()




 


///Cluster(Inplace of remoting) --ADVANCED
Many workers(stateless) in Cluster - communication by Receptionist 
https://doc.akka.io/docs/akka/current/typed/cluster.html

You have to enable serialization to send messages between ActorSystems (nodes) in the Cluster.

//Reference 
case class  akka.actor.Address extends Product with Serializable 
    def apply(protocol: String, system: String, host: String, port: Int): Address
        Constructs a new Address with the specified protocol, system name, host and port
    def apply(protocol: String, system: String): Address
        Constructs a new Address with the specified protocol and system name
class akka.cluster.typed.Cluster extends Extension 
    def isTerminated: Boolean
        Returns true if this cluster instance has be shutdown.
    def manager: ActorRef[ClusterCommand]
        case class Down(address: Address) extends ClusterCommand with Product with Serializable 
        case class Join(address: Address) extends ClusterCommand with Product with Serializable 
        case class JoinSeedNodes(seedNodes: Seq[Address]) extends ClusterCommand with Product with Serializable 
        case class Leave(address: Address) extends ClusterCommand with Product with Serializable 
    def selfMember: Member
        Details about this cluster node itself
            def address: Address
            def copy(status: MemberStatus): Member
            def copyUp(upNumber: Int): Member
            lazy val dataCenter: DataCenter
            def equals(other: Any): Boolean            
            def hasRole(role: String): Boolean
            def hashCode(): Int
            def isOlderThan(other: Member): Boolean
                Is this member older, has been part of cluster longer, than another member.
            val roles: Set[String]
            val status: MemberStatus
            def toString(): String
            val uniqueAddress: UniqueAddress 
    def state: CurrentClusterState
        Current snapshot state of the cluster.
        CurrentClusterState(members: SortedSet[Member] = immutable.SortedSet.empty, unreachable: Set[Member] = Set.empty, seenBy: Set[Address] = Set.empty, leader: Option[Address] = None, roleLeaderMap: Map[String, Option[Address]] = Map.empty)
    def subscriptions: ActorRef[ClusterStateSubscription] 
        case class GetCurrentState(recipient: ActorRef[CurrentClusterState]) extends ClusterStateSubscription with Product with Serializable 
        case class Subscribe[A <: ClusterDomainEvent](subscriber: ActorRef[A], eventClass: Class[A]) extends ClusterStateSubscription with Product with Serializable 
        case class Unsubscribe[T](subscriber: ActorRef[T]) extends ClusterStateSubscription with Product with Serializable 


//Example-Simple Cluster Listener
//in three cmd prompt  
$ sbt "runMain typedclustering.SimpleClusterApp 25251"
//$ sbt "runMain typedclustering.SimpleClusterApp 25252"
$ sbt "runMain typedclustering.SimpleClusterApp 0"
//Check the log output , then do crtl+c in one window to check Leaving 


//Quick Examples 
//build.sbt 
  "com.typesafe.akka" %% "akka-cluster-typed" % AkkaVersion,
  "com.typesafe.akka" %% "akka-serialization-jackson" % AkkaVersion,
  
//typedclusterMainApp.conf
akka {
  actor {
    provider = cluster

    serialization-bindings {
      "typedclustering.CborSerializable" = jackson-cbor
    }
  }
  remote {
    artery {
      canonical.hostname = "127.0.0.1"
      canonical.port = 0  
    }
  }
  cluster {
    seed-nodes = [
      #Two Node system - default 25250 and next one is 25251
      #ActorSystem must be TypedClusterSystem
      "akka://TypedClusterSystem@127.0.0.1:25251" #, "akka://TypedClusterSystem@127.0.0.1:25252"
      ]
  }
}

transformation {
  workers-per-node = 4
}


//Add Serialization - src/main/CborSerializable.scala 
package typedclustering 

import akka.actor.typed.scaladsl._
import akka.cluster.ClusterEvent._
import akka.cluster.typed._
import akka.actor.typed._

import scala.concurrent.duration._ 
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import akka.util._
import akka._
import akka.actor.typed.receptionist._
import scala.util._ 

trait CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "TypedClusterSystem"
    val clusterMainApp = "typedclusterMainApp.conf"      
    val sleeptime = 10*60*1000
    
    def killThisSystem[X](system:ActorSystem[X], sleeptime:Int=sleeptime):Unit = {    
        Thread.sleep(sleeptime)
        system.terminate()
    }

}

object SimpleClusterApp {
  
  object RootBehavior {
    def apply(): Behavior[Nothing] = Behaviors.setup[Nothing] { context =>
      // Create an actor that handles cluster domain events
      context.spawn(SimpleClusterListener(), "ClusterListener")

      Behaviors.empty
    }
  }

  def main(args: Array[String]): Unit = {
    startup(args.head.toInt)
  }

  def startup(port: Int): Unit = {
     import Helper._ 
    // Override the configuration of the port
    val config = ConfigFactory.parseString(s"""
      akka.remote.artery.canonical.port=$port
      """).withFallback(ConfigFactory.load(clusterMainApp))

    // Create an Akka system- All System must have the same Name 
    val system = ActorSystem[Nothing](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }

}


object SimpleClusterListener {

  sealed trait Event
  // internal adapted cluster events only
  private final case class ReachabilityChange(reachabilityEvent: ReachabilityEvent) extends Event
  private final case class MemberChange(event: MemberEvent) extends Event

  def apply(): Behavior[Event] = Behaviors.setup { ctx =>
    val cluster = Cluster(ctx.system)
    // messageAdapter[U](f: (U) => T)(implicit arg0: ClassTag[U]): ActorRef[U]
    val memberEventAdapter: ActorRef[MemberEvent] = ctx.messageAdapter(MemberChange)
    val reachabilityAdapter = ctx.messageAdapter(ReachabilityChange)
    
    //case class Subscribe[A <: ClusterDomainEvent](subscriber: ActorRef[A], eventClass: Class[A]) 
    cluster.subscriptions ! Subscribe(memberEventAdapter, classOf[MemberEvent])  
    cluster.subscriptions ! Subscribe(reachabilityAdapter, classOf[ReachabilityEvent])

    Behaviors.receiveMessage { message =>
      message match {
        case ReachabilityChange(reachabilityEvent) =>
          reachabilityEvent match {
            case UnreachableMember(member) =>
              ctx.log.info("Member detected as unreachable: {}", member)
            case ReachableMember(member) =>
              ctx.log.info("Member back to reachable: {}", member)
          }

        case MemberChange(changeEvent) =>
          changeEvent match {
            case MemberUp(member) =>
              ctx.log.warn("Member is Up: {}", member.address)
            case MemberRemoved(member, previousStatus) =>
              ctx.log.warn("Member is Removed: {} after {}",  member.address, previousStatus)
            case _: MemberEvent => // ignore
          }
      }
      Behaviors.same
    }
  }
}

//Example - Transformation service, Backend and Frontend 
//in Five cmd prompt 
$ sbt "runMain typedclustering.ClusterWorker backend 25251"
//$ sbt "runMain typedclustering.ClusterWorker backend 25252"
$ sbt "runMain typedclustering.ClusterWorker backend 0"
$ sbt "runMain typedclustering.ClusterWorker frontend 0"
//$ sbt "runMain typedclustering.ClusterWorker frontend 0"
    

//Worker 
object ClusterWorker {
 
  object RootBehavior {
    def apply(): Behavior[Nothing] = Behaviors.setup[Nothing] { ctx =>
      val cluster = Cluster(ctx.system)

      if (cluster.selfMember.hasRole("backend")) {
        val workersPerNode = ctx.system.settings.config.getInt("transformation.workers-per-node")
        (1 to workersPerNode).foreach { n =>
          ctx.spawn(Worker(), s"Worker$n")
        }
      }
      if (cluster.selfMember.hasRole("frontend")) {
        ctx.spawn(Frontend(), "Frontend")
      }
      Behaviors.empty
    }
  }

  def main(args: Array[String]): Unit = {
    require(args.size == 2, "Usage: role port")
    startup(args(0), args(1).toInt)
  }

  def startup(role: String, port: Int): Unit = {
    import Helper._ 
    // Override the configuration of the port and role
    val config = ConfigFactory.parseString(s"""
        akka.remote.artery.canonical.port=$port
        akka.cluster.roles = [$role]
        """)
      .withFallback(ConfigFactory.load(clusterMainApp)) //"transformation"

    val system = ActorSystem[Nothing](RootBehavior(), clusterActorSystem, config)
    killThisSystem(system)
  }
}


object Worker {

  val WorkerServiceKey = ServiceKey[Worker.TransformText]("Worker")

  sealed trait Command
  final case class TransformText(text: String, replyTo: ActorRef[TextTransformed]) extends Command with CborSerializable
  final case class TextTransformed(text: String) extends CborSerializable

  def apply(): Behavior[Command] =
    Behaviors.setup { ctx =>
      // each worker registers themselves with the receptionist
      ctx.log.info("Registering myself with receptionist")
      ctx.system.receptionist ! Receptionist.Register(WorkerServiceKey, ctx.self)

      Behaviors.receiveMessage {
        case TransformText(text, replyTo) =>
          replyTo ! TextTransformed(text.reverse)
          Behaviors.same
      }
    }
}


object Frontend {

  sealed trait Event
  private case object Tick extends Event
  private final case class WorkersUpdated(newWorkers: Set[ActorRef[Worker.TransformText]]) extends Event
  
  private final case class TransformCompleted(originalText: String, transformedText: String) extends Event
  private final case class JobFailed(why: String, text: String) extends Event


  def apply(): Behavior[Event] = Behaviors.setup { ctx =>
    Behaviors.withTimers { timers =>
      // subscribe to available workers
      val subscriptionAdapter = ctx.messageAdapter[Receptionist.Listing] {
        case Worker.WorkerServiceKey.Listing(workers) =>
          WorkersUpdated(workers)
      }
      ctx.system.receptionist ! Receptionist.Subscribe(Worker.WorkerServiceKey, subscriptionAdapter)

      //Simulate 
      //def startTimerWithFixedDelay(key: Any, msg: T, delay: FiniteDuration): Unit
      timers.startTimerWithFixedDelay(Tick, Tick, 2.seconds)

      running(ctx, IndexedSeq.empty, jobCounter = 0)
    }
  }

  private def running(ctx: ActorContext[Event], workers: IndexedSeq[ActorRef[Worker.TransformText]], jobCounter: Int): Behavior[Event] =
    Behaviors.receiveMessage {
      case WorkersUpdated(newWorkers) =>
        ctx.log.info("List of services registered with the receptionist changed: {}", newWorkers)
        running(ctx, newWorkers.toIndexedSeq, jobCounter)
      case Tick =>
        if (workers.isEmpty) {
          ctx.log.info("Got tick request but no workers available, not sending any work")
          Behaviors.same
        } else {
          // how much time can pass before we consider a request failed
          implicit val timeout: Timeout = 5.seconds
          val selectedWorker = workers(jobCounter % workers.size)
          ctx.log.info("Sending work for processing to {}", selectedWorker)
          val text = s"hello-$jobCounter"
          //def ask[Req, Res](target: RecipientRef[Req], createRequest: (ActorRef[Res]) => Req)(mapResponse: (Try[Res]) => T)(implicit responseTimeout: Timeout, classTag: ClassTag[Res]): Unit 
          //basically  selectedWorker !  Worker.TransformText(text, replyTo) producing Try[Worker.TextTransformed(text: String)]
          ctx.ask(selectedWorker, Worker.TransformText(text, _)) {
            case Success(transformedText) => TransformCompleted(text, transformedText.text)
            case Failure(ex) => JobFailed("Processing timed out", text)
          }
          running(ctx, workers, jobCounter + 1)
        }
      case TransformCompleted(originalText, transformedText) =>
        ctx.log.info("Got completed transform of {}: {}", originalText, transformedText)
        Behaviors.same

      case JobFailed(why, text) =>
        ctx.log.info("Transformation of text {} failed. Because: {}", text, why)
        Behaviors.same

    }
}


///Introduction to  Stream 

//required imports 
import akka.stream._
import akka.stream.scaladsl._

//Other imports 
import akka.{ Done, NotUsed }
import akka.actor._
import akka.util.ByteString
import scala.concurrent._
import scala.concurrent.duration._


import com.typesafe.config.ConfigFactory

implicit val system = ActorSystem("TestSystem")  //Loads application.conf 
//implicit val system = ActorSystem("TestSystem", ConfigFactory.load("nonapplication.conf"))
//Not needed as ActrSystem would be autoconverted to Materializer
//val mat: Materializer = Materializer(system)


//Source[+Out, +Mat]
//Out: this source emits and Mat: the 'materialized value', produce some auxiliary value when 'run'
//Source[T](iterable: Iterable[T]): Source[T, NotUsed]

val source: Source[Int, NotUsed] = Source(1 to 100)  

//Source[+Out, +Mat].runForeach(f: (Out) => Unit)(implicit materializer: Materializer): Future[Done]
//ActorSystem is converted to Materializer, which runs the system(in akka using Actors)

val done: Future[Done] = source.runForeach(i => println(i))

//This never terminates if we remove .take(10)
//fromIterator[O](f: () => Iterator[O]): Source[O, NotUsed]
Source.fromIterator(()=>Iterator.from(1)).take(10).runForeach(i => println(i))

implicit val ec = system.dispatcher
//done.onComplete(_ => system.terminate())

//Lets Understand few Creation methods 
Source[+Out, +Mat]  
    creation 
    https://doc.akka.io/api/akka/current/akka/stream/javadsl/Source$.html
    Few are  
    Source[T](iterable: Iterable[T]): Source[T, NotUsed]
    Source.cycle[T](f: () => Iterator[T]): Source[T, NotUsed]
    Source.empty[T]: Source[T, NotUsed]
    Source.failed[T](cause: Throwable): Source[T, NotUsed]
    Source.future[T](futureElement: Future[T]): Source[T, NotUsed]
    Source.never[T]: Source[T, NotUsed]  //Never emits any elements, never completes and never fails. 
    Source.repeat[T](element: T): Source[T, NotUsed]
    Source.single[T](element: T): Source[T, NotUsed]
    Source.tick[T](initialDelay: FiniteDuration, interval: FiniteDuration, tick: T): Source[T, Cancellable]

Sink[-In, +Mat]
    Creation 
    https://doc.akka.io/api/akka/current/akka/stream/scaladsl/Sink$.html
    Few Are 
    Sink.fold[U, T](zero: U)(f: (U, T) => U): Sink[T, Future[U]]
    Sink.foreach[T](f: (T) => Unit): Sink[T, Future[Done]]
    Sink.head[T]: Sink[T, Future[T]]
    Sink.ignore: Sink[Any, Future[Done]]
    Sink.last[T]: Sink[T, Future[T]]
    Sink.reduce[T](f: (T, T) => T): Sink[T, Future[T]]
    Sink.seq[T]: Sink[T, Future[Seq[T]]]
    
Flow[-In, +Out, +Mat]
    Creation 
    https://doc.akka.io/api/akka/current/akka/stream/scaladsl/Flow$.html
    Few Are 
    Flow[T]: Flow[T, T, NotUsed]
    Flow.fromFunction[A, B](f: (A) => B): Flow[A, B, NotUsed]   // Transforms A to B by f 

//Few Basic concepts 
1) Source connected to Sink OR Source via Flow to Sink are examples of RunnableGraph

2) Process of starting the evaluation of RunnableGraph by 'Materializer'
   (one example, ActorSystem) called Materialization

3) Source, Flow, Sink have one +Mat type, which denotes what it produces(materializes) when evaluated 
   Sink +Mat is the final output (generally Future[T]) from the graph 

4) Various ways to get RunnableGraph and then getting materialized Value 
    1. RunnableGraph.run() returns  'this' Mat  
       Source has few shortcut methods eg    
            source.run() runs with Sink.ignore 
            source.runFold(z,(r,e)=>..):rtype
            source.runForeach(o => Unit):Unit
            source.runReduce((e,e)=>..):etype 
    
    2. source.runWith(sink)/sink.runWith(source) returns Mat of the arg and ignores 'this' Mat     
    
    3. source.to(sink) ignores Mat of arg but returns a RunnableGraph with 'this' Mat 
       so 'run' it     
       flow.to(sink) returns a new Sink with 'this' Mat 
       
    4. For many methods, we have two versions - 'method' and 'methodMat' 
       former returns 'this' mat while later (eg toMat, viaMat compared to to, via etc ) 
       has combiner (Mat, Mat2) => Mat3 to get  Mat3 in output 
       (builtin combiners are Keep.left, Keep.right, Keep.both) 
       eg 
       source.toMat(sink)(combiner):RunnableGraph, 
       flow.toMat(sink)(combiner) returns a new Sink 
       
    5. source.via(flow):source / flow.via(flow):flow ignores arg Mat, 
       source.viaMat(flow)(combiner):source /flow.viaMat(flow)(combiner):flow returns combiner Mat 
    
//Example 
implicit val system = ActorSystem("TestSystem")
implicit val ec = system.dispatcher

val source = Source( 1 to 10)   // Source[Int,akka.NotUsed]
val sink = Sink.seq[Int]        //Sink[Int,Future[Seq[Int]]]

val result1 = source.runWith(sink) //Future[Seq[Int]]
result1.foreach(println)

//source is not single pass, again evaluated 
val runnableGraph2 = source.to(sink) //RunnableGraph[akka.NotUsed] 
val result = runnableGraph2.run() //akka.NotUsed

//source is not single pass, again evaluated 
val runnableGraph = source.toMat(sink)(Keep.right)//RunnableGraph[Future[Seq[Int]]] 
val result = runnableGraph.run()  //Future[Seq[Int]]

import system.dispatcher
result.foreach(println)  //Vector(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)





///Few More Basic Examples

import akka.stream._
import akka.stream.scaladsl._
import akka._
import akka.actor._
import akka.util._
import scala.concurrent._
import scala.concurrent.duration._

//implicit val system = ActorSystem("TestSystem")

//A Source can be created in multiple ways
val s = Source.empty
val s = Source.single("single element")
val s1 = Source(1 to 3)
val s2 = Source.single(Future("single value from a Future"))

//Reactive Streams are lazy and asynchronous by default. 
//This means one explicitly has to request the evaluation of the stream, run* methods 

//def runForeach(f: (Out) => Unit)(implicit materializer: Materializer): Future[Done]
s1 runForeach println 
s2.runForeach{ f => f.onSuccess{ case x:String => println(x) } }

//A Sink can be created few ways 
Sink.head
    Sink that returns a Future as its materialized value,
    containing the first element of the stream

Sink.ignore
    A Sink that consumes a stream without doing anything with the elements

Sink.foreach[String](println(_))
    A Sink that executes a side-effecting call for every element of the stream


// Starting from a Source
val source = Source(1 to 6).map(_ * 2)
source.to(Sink.foreach(println(_))).run()  //Mat=Source Mat=NotUsed 

//Can be materialized many times 
source.to(Sink.foreach(println(_))).run()

import system.dispatcher
source.toMat(Sink.head[Int])(Keep.right).run()/*Future[Int]*/.foreach(println)

//Seq and Ignore 
source.toMat(Sink.ignore)(Keep.right).run()  //Future[akka.Done]
source.toMat(Sink.seq[Int])(Keep.right).run()/*Future[Seq[Int]]*/.foreach(println)


// Starting from a Sink
//def Source[Out,Mat].via[T, Mat2](flow: Flow[Out, T, Mat2]): Source[T, Mat]

Source(1 to 6).via(Flow[Int].map(_ * 2)).to(Sink.foreach(println(_)))

//OR 
val source = Source(1 to 3)
val sink = Sink.foreach[Int](println)

//object Flow[T]: Flow[T, T, NotUsed] 
val invert = Flow[Int].map(elem => elem * -1)
val doubler = Flow[Int].map(elem => elem * 2)

val runnable = source via invert via doubler to sink
runnable.run()

//s1 and s2 represent completely new streams 
//they do not share any data through their building blocks.
val s1 = Source(1 to 3) via invert to sink
val s2 = Source(-3 to -1) via invert to sink
s1.run()
s2.run()


//akka Streams do not allow null to be passed through the stream as an element. 
//Use scala.Option or scala.util.Either .
//Sink.fold[U, T](zero: U)(f: (U, T) => U): Sink[T, Future[U]]  
val sink = Sink.fold[Int, Option[Int]](0){ case (r, Some(e)) => r+e  case (r,_) => r} 
val runnable: RunnableGraph[Future[Int]] = Source(1 to 10).map(Some(_)).toMat(sink)(Keep.right)

// get the materialized value of the FoldSink
// sum1 and sum2 are different Futures!
val sum1: Future[Int] = runnable.run()
val sum2: Future[Int] = runnable.run()


//Complex Example -1
//source is like List, only can be infinite , similar list processing methods are available 
val source = Source( 1 to 10)
val factorials = source.scan(BigInt(1))((acc, next) => acc * next)

//FileIO.toPath creates a Sink , source.runWith dumps the source to Sink (result is FileIO.toPath's Mat)
// FileIO.toPath(f: Path): Sink[ByteString, Future[IOResult]]
// case class IOResult(count: Long, status: Try[Done])

import java.nio.file.Paths
val result: Future[IOResult] =
  factorials.map(num => ByteString(s"$num\n")).runWith(FileIO.toPath(Paths.get("factorials.txt")))
  
//Like Source, Sink can also be used as blueprint 
//Flow[String] == Flow[String,String,NotUsed] , Input = Output 
//Flow[T]: Flow[T, T, NotUsed]
//Flow[-In, +Out, +Mat].toMat[Mat2, Mat3](sink: Sink[Out, Mat2])(combine: (Mat, Mat2) => Mat3): Sink[In, Mat3]

def lineSink(filename: String): Sink[String, Future[IOResult]] =
  Flow[String].map(s => ByteString(s + "\n")).toMat(FileIO.toPath(Paths.get(filename)))(Keep.right)

//Then connect the Sink 
factorials.map(_.toString).runWith(lineSink("factorial2.txt"))

//Time-Based Processing
//use the throttle operator to slow down the stream to 1 element per second
//Source[+Out,+Mat].throttle(elements: Int, per: FiniteDuration): Source[+Out,+Mat]

factorials
  .zipWith(Source(0 to 100))((num, idx) => s"$idx! = $num")
  .throttle(1, 1.second)
  .runForeach(println)
  
//Complex Example -2
//example of Source.Queue  and Infinite Stream 
Source.queue[T](bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, SourceQueueWithComplete[T]]  
    Creates a Source that is materialized as SourceQueueWithComplete
    OverflowStrategy - what happens if more elements are offered, then can be processed by stream 
    dropHead, dropBuffer,dropTail, fail 
    
SourceQueueWithComplete<T>    
    void complete() 	
    void fail​(java.lang.Throwable ex) 	
    offer​(elem:T):Future[QueueOfferResult]
    
//example
//note 'future' never ends if Stream is not completed 
val (queue, future) = Source.queue[Int](5, OverflowStrategy.fail).  
  map(x => x + 10). 
  //Keep.left only left, source's(ie queue), Keep.right, only right,sink's(ie future)
  toMat(Sink.fold(0)((r,e)=> {println(s"Current $r Next $e"); r+e}))(Keep.both). 
  run()
  
val r = new scala.util.Random()
//Result 
import system.dispatcher
Future {
    Thread.sleep(10)
    (1 to 10).toList.foreach{ x => {
        queue.offer(r.nextInt(100))
        println(s"sent ${x}th")
        } 
    }
}
//Anytime queue has input, fold would be executed 
queue.offer(r.nextInt(100))

//but future can not be used directly as onComplete, foreach are blocking 
//and map, flatMap only get executed when Future is completed 
//and here future is '<not completed>'
future.map{ x => println(s"in Call Back $x"); x+1}.foreach(println)  //does not get executed 

//when user wants to stop the Stream, complete underlaying queue 
queue.complete()
//above Future gets executed 
in Call Back 618
619


//Example - mapAsync - map with return Future
val queue2 = Source
  .queue[Int](3, OverflowStrategy.backpressure)
  .map(x => x * x)
  .toMat(Sink.foreach(x => println(s"completed $x")))(Keep.left)
  .run()

//Source[+Out, +Mat].mapAsync[T](parallelism: Int)(f: (Out) => Future[T]): Source[T, Mat]
//map takes in a function that returns a type T while mapAsync takes in a function that returns a type Future[T]
Source(1 to 10).mapAsync(2)(x => {
  queue2.offer(x).map {
    case QueueOfferResult.Enqueued    => println(s"enqueued $x")
    case QueueOfferResult.Dropped     => println(s"dropped $x")
    case QueueOfferResult.Failure(ex) => println(s"Offer failed ${ex.getMessage}")
    case QueueOfferResult.QueueClosed => println("Source Queue closed")
  } /*Future[QueueOfferResult]*/
}).runWith(Sink.ignore)
  
//more inject 
import system.dispatcher
Future {
    Thread.sleep(10)
    (1 to 10).toList.foreach{x => {
        queue2.offer(r.nextInt(100))
        println(s"sent ${x}th")
       } 
   }
}
//when user wants to stop the Stream, complete underlaying queue 
queue.complete()

//Close Actorsystem 
system.terminate()


///Stream Testing 
libraryDependencies += "com.typesafe.akka" %% "akka-stream-testkit" % AkkaVersion % Test


//Example 
import scala.util._
import scala.concurrent.duration._
import scala.concurrent._

import akka.Done
import akka.stream._
import akka.stream.scaladsl._
import akka.stream.testkit.scaladsl._
import akka.testkit._
import akka.pattern
import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers
import org.scalatest.wordspec.AnyWordSpecLike

//Example 
class StreamTestKitDocSpec()
    extends TestKit(ActorSystem("Dummy"))
    with ImplicitSender //TestKit.testActor is sender 
    with AnyWordSpecLike //BDD like template 
    with Matchers
    with BeforeAndAfterAll //must be last trait
    {
 "My Stream test " must {
  "strict collection" in {
    val sinkUnderTest = Flow[Int].map(_ * 2).toMat(Sink.fold(0)(_ + _))(Keep.right)

    val future = Source(1 to 4).runWith(sinkUnderTest)
    val result = Await.result(future, 3.seconds)
    assert(result == 20)

  }
 "pipe to test probe" in {

    import system.dispatcher
    import akka.pattern.pipe

    val sourceUnderTest = Source(1 to 4).grouped(2)

    val probe = TestProbe()
    sourceUnderTest.runWith(Sink.seq).pipeTo(probe.ref)
    probe.expectMsg(3.seconds, Seq(Seq(1, 2), Seq(3, 4)))

  }
} 
}  

scala> org.scalatest.run(new StreamTestKitDocSpec())
//In sbt , this must be in src/test/scala folder 
$ sbt test 
//https://www.scalatest.org/user_guide/using_scalatest_with_sbt




///Few  Advanced operators - few examples  -- ADVANCED * 
https://doc.akka.io/docs/akka/current/stream/operators/index.html

Concat vs Merge 
    Concat concates streams into one Stream, 
    by completing one stream and then another stream (one after another)
    Whereas Merge would take N element from one stream and then pick N element 
    from another (how many elements to pick is configured by 'breadth'), then N from next (cyclic)
    So Concat is one completes + then another 
    Merge is like multiplexing 


Source[Out,Mat].flatMapConcat[T, M](f: (Out) => Source[T,M]): Source[T, Mat]
Flow[In, Out, Mat].flatMapConcat[T, M](f: (Out) =>  Source[T,M]): Flow[In, T, Mat]
    Transform each input element into a Source of output elements that is then flattened 
    into the output stream by concatenation, fully consuming one Source after the other.
    
Source[Out,Mat].flatMapMerge[T, M](breadth: Int, f: (Out) => Source[T,M]): Source[T, Mat]
Flow[In, Out, Mat].flatMapMerge[T, M](breadth: Int, f: (Out) => Source[T,M]): Flow[In, T, Mat]
    Transform each input element into a Source of output elements that is then flattened 
    into the output stream by merging, where at most breadth substreams are being consumed 
    at any given time.
    //Example 
    val source: Source[String, NotUsed] = Source(List("customer-1", "customer-2"))
    // e.g. could b a query to a database
    def lookupCustomerEvents(customerId: String): Source[String, NotUsed] = {
      Source(List(s"$customerId-event-1", s"$customerId-event-2"))
    }

    source.flatMapConcat(customerId => lookupCustomerEvents(customerId)).runForeach(println)
    // prints - events from each customer consecutively
    // customer-1-event-1
    // customer-1-event-2
    // customer-2-event-1
    // customer-2-event-2

    source.flatMapMerge(10, customerId => lookupCustomerEvents(customerId)).runForeach(println)
    // prints - events from different customers could interleave
    // customer-1-evt-1
    // customer-2-evt-1
    // customer-1-evt-2
    // customer-2-evt-2

Source[Out,Mat].mapConcat[T](f: (Out) => Iterable[T]): Source[T, Mat]
Flow[In, Out, Mat].mapConcat[T](f: (Out) => Iterable[T]): Flow[In, T, Mat]
    Transform each input element into an Iterable of output elements that is then flattened 
    into the output stream.
    //Example 
    def duplicate(i: Int): List[Int] = List(i, i)
    Source(1 to 3).mapConcat(i => duplicate(i)).runForeach(println)
    // prints:
    // 1
    // 1
    // 2
    // 2
    // 3
    // 3

Source[Out,Mat].statefulMapConcat[T](f: () => (Out) => IterableOnce[T]): Source[T, Mat]
Flow[In, Out, Mat].statefulMapConcat[T](f: () => (Out) => IterableOnce[T]): Flow[In, T, Mat]
    Transform each input element into an Iterable of output elements that is then flattened 
    into the output stream. Create State in body of first function at () => 
Source[Out,Mat].concat[U >: Out, Mat2](that: Source[U, Mat2]): Source[U, Mat]
Flow[In, Out, Mat].concat[U >: Out, Mat2](that: Source[U, Mat2]): Flow[In, U, Mat]
    Concatenate the given Source to this Flow,(exhausting this and then producing that)
    //Example 
    val words = Source("baboon" :: "crocodile" :: "bat" :: "flamingo" :: "hedgehog" :: "beaver" :: Nil)

    val bWordsLast = Flow[String].concat(Source.single("-end-")).statefulMapConcat { () =>
      //create state here 
      var stashedBWords: List[String] = Nil
      //(Out) => IterableOnce[T]
      { element =>
        if (element.startsWith("b")) {
          // prepend to stash and emit no element
          stashedBWords = element :: stashedBWords
          Nil
        } else if (element.equals("-end-")) {
          // return in the stashed words in the order they got stashed
          stashedBWords.reverse
        } else {
          // emit the element as is
          element :: Nil
        }
      }
    }
    words.via(bWordsLast).runForeach(println)
    // prints
    // crocodile
    // flamingo
    // hedgehog
    // baboon
    // bat
    // beaver
    
    //Example 
    val letterAndIndex = Source("a" :: "b" :: "c" :: "d" :: Nil).statefulMapConcat { () =>
      //state 
      var counter = 0L
      //(Out) => IterableOnce[T]
      { element =>
        counter += 1
        // we return an iterable with the single element
        (element, counter) :: Nil
      }
    }

    letterAndIndex.runForeach(println)
    // prints
    // (a,1)
    // (b,2)
    // (c,3)
    // (d,4)
    
    

//Repr[T] for Source, Source[Out, Mat]-> Source[T, Mat] 
//for Flow, Flow[In, Out, Mat] => Flow[In, T, Mat]
Source[Out, Mat]/Flow[In, Out, Mat].mapAsync[T](parallelism: Int)(f: (Out) => Future[T]): Repr[T]
    Transform this stream by applying the given function to each of the elements 
    The function returns a Future and the value of that future will be emitted downstream. 
Source[Out, Mat]/Flow[In, Out, Mat].mapAsyncUnordered[T](parallelism: Int)(f: (Out) => Future[T]): Repr[T]
    Like mapAsync but Future results are passed downstream as they arrive regardless of the order 
    of the elements that triggered them.
    If a Future completes with null, element is not passed downstream. 
    If a Future fails, the stream also fails (unless a different supervision strategy is applied)
    //Example 
    import system.dispatcher
    
    case class Event(id:Int)
    val events: Source[Event, NotUsed] = Source(0 to 10).map(Event(_))

    def eventHandler(event: Event)(implicit ec:ExecutionContext) : Future[Int] = {
      println(s"Processing event $event...")
      Future {event.id * event.id }
    }

    events.mapAsync/*mapAsyncUnordered*/(3) { in =>
        eventHandler(in)
      }.map { fut_result =>
        println(s"`mapAsync` emitted number: $fut_result")
      }


https://doc.akka.io/api/akka/current/akka/stream/scaladsl/FlowWithContextOps.html
trait FlowWithContextOps[+Out, +Ctx, +Mat]
    def via[Out2, Ctx2, Mat2](flow: Graph[FlowShape[(Out, Ctx), (Out2, Ctx2)], Mat2]): Repr[Out2, Ctx2]
        Transform this flow by the regular flow.
    def viaMat[Out2, Ctx2, Mat2, Mat3](flow: Graph[FlowShape[(Out, Ctx), (Out2, Ctx2)], Mat2])(combine: (Mat, Mat2) => Mat3): ReprMat[Out2, Ctx2, Mat3]
    def collect[Out2](f: PartialFunction[Out, Out2]): Repr[Out2, Ctx]
        Context-preserving variant of akka.stream.scaladsl.FlowOps.collect.
    def filter(pred: (Out) => Boolean): Repr[Out, Ctx]
    def filterNot(pred: (Out) => Boolean): Repr[Out, Ctx]
    def grouped(n: Int): Repr[Seq[Out], Seq[Ctx]]
    def log(name: String, extract: (Out) => Any = ConstantFun.scalaIdentityFunction)(implicit log: LoggingAdapter = null): Repr[Out, Ctx]
    def logWithMarker(name: String, marker: (Out, Ctx) => LogMarker, extract: (Out) => Any = ConstantFun.scalaIdentityFunction)(implicit log: MarkerLoggingAdapter = null): Repr[Out, Ctx]
    def map[Out2](f: (Out) => Out2): Repr[Out2, Ctx]
    def mapAsync[Out2](parallelism: Int)(f: (Out) => Future[Out2]): Repr[Out2, Ctx]
    def mapConcat[Out2](f: (Out) => IterableOnce[Out2]): Repr[Out2, Ctx]
    def mapContext[Ctx2](f: (Ctx) => Ctx2): Repr[Out, Ctx2]
    def mapError(pf: PartialFunction[Throwable, Throwable]): Repr[Out, Ctx]
    def sliding(n: Int, step: Int = 1): Repr[Seq[Out], Seq[Ctx]]
    def throttle(cost: Int, per: FiniteDuration, maximumBurst: Int, costCalculation: (Out) => Int, mode: ThrottleMode): Repr[Out, Ctx]
    def throttle(cost: Int, per: FiniteDuration, costCalculation: (Out) => Int): Repr[Out, Ctx]
    def throttle(elements: Int, per: FiniteDuration, maximumBurst: Int, mode: ThrottleMode): Repr[Out, Ctx]
   def throttle(elements: Int, per: FiniteDuration): Repr[Out, Ctx]


//Repr[T] for Source, Source[Out, Mat]-> Source[T, Mat] 
//for Flow, Flow[In, Out, Mat] => Flow[In, T, Mat]
Source[Out, Mat].asSourceWithContext[Ctx](f: (Out) => Ctx): SourceWithContext[Out, Ctx, Mat]
    Transform this source whose element is e into a source producing tuple (e, f(e))
    //ref 
    class SourceWithContext[+Out, +Ctx, +Mat] extends Source[(Out, Ctx), Mat] 
        with FlowWithContextOps[Out, Ctx, Mat]
    //Details    
    Extracts context data from the elements of a Source so that it can be turned 
    into a SourceWithContext which can propagate that context per element along a stream. 
    The function passed into asSourceWithContext must turn elements into contexts, 
    one context for every element.

    //Example 
    import akka._
    import akka.stream.scaladsl._

    // values with their contexts as tuples
    val values: Seq[(String, Int)] = Seq("eins" -> 1, "zwei" -> 2, "drei" -> 3)

    // a regular source with the tuples as elements
    val source: Source[(String, Int), NotUsed] = Source(values)

    // split the tuple into stream elements and their context
    val sourceWithContext: SourceWithContext[String, Int, NotUsed] =
      source
        .asSourceWithContext(_._2) // pick the second tuple element as context
        .map(_._1) // keep the first tuple element as stream element

    val mapped: SourceWithContext[String, Int, NotUsed] = sourceWithContext
        // regular operators apply to the element without seeing the context
       .map(s => s.reverse)

    // running the source and asserting the outcome
    val result = mapped.runWith(Sink.seq)
    import system.dispatcher
    result.foreach(println)
    //Vector((snie,1), (iewz,2), (ierd,3))




Flow[In, Out, Mat].asFlowWithContext[U, CtxU, CtxOut](collapseContext: (U, CtxU) => In)
    (extractContext: (Out) => CtxOut): FlowWithContext[U, CtxU, Out, CtxOut, Mat]
    //ref 
    FlowWithContext[-In, -CtxIn, +Out, +CtxOut, +Mat] 
        extends Flow[(In, CtxIn), (Out, CtxOut), Mat] with FlowWithContextOps[Out, CtxOut, Mat]
    //Details 
    Extracts context data from the elements of a Flow so that it can be turned 
    into a FlowWithContext which can propagate that context per element along a stream. 
    The first function passed into asFlowWithContext must turn each incoming pair of element 
    and context value into an element of this Flow. 
    The second function passed into asFlowWithContext must turn each outgoing element 
    of this Flow into an outgoing context value.

    //Example 
    import akka.NotUsed
    import akka.stream.scaladsl._
    // a regular flow with pairs as elements
    val flow: Flow[(String, Int), (String, Int), NotUsed] = Flow[(String, Int)]

    // Declare the "flow with context"
    // ingoing: String and Integer
    // outgoing: String and Integer
    val flowWithContext: FlowWithContext[String, Int, String, Int, NotUsed] =
      // convert the flow of pairs into a "flow with context"
      flow
        .asFlowWithContext[String, Int, Int](
          // at the end of this flow: put the elements and the context back into a tuple
          collapseContext = Tuple2.apply)(
          // pick the second element of the incoming pair as context
          extractContext = _._2)
        .map(_._1) // keep the first pair element as stream element

    val mapped = flowWithContext
        // regular operators apply to the element without seeing the context
        .map(_.reverse)

    // running the flow with some sample data and asserting the outcome
    val values: Seq[(String, Int)] = Seq("eins" -> 1, "zwei" -> 2, "drei" -> 3)
    val source = Source(values).asSourceWithContext(_._2).map(_._1)

    val result = source.via(mapped).runWith(Sink.seq)
    result.foreach(println)
    //Vector((snie,1), (iewz,2), (ierd,3))



//Repr[T] for Source, Source[Out, Mat]-> Source[T, Mat] 
//for Flow, Flow[In, Out, Mat] => Flow[In, T, Mat]
Source[Out, Mat]/Flow[In, Out, Mat].ask[ExpectedReply](parallelism: Int)(ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[ExpectedReply]): Repr[ExpectedReply]
Source[Out, Mat]/Flow[In, Out, Mat].ask[ExpectedReply](ref: ActorRef)(implicit timeout: Timeout, tag: ClassTag[ExpectedReply]): Repr[ExpectedReply]
    Use the ask pattern to send a request-reply message to the target ref actor. 
    If any of the asks times out it will fail the stream with a akka.pattern.AskTimeoutException.
    Defaults to parallelism of 2 messages in flight
    
    //Example 
    class MyActor extends Actor {
        def receive = {
            case "stop" =>
                context.stop(self)
            case msg:String =>
                println(msg)
                sender() ! msg.size 
        }
    }
    val actorRef = system.actorOf(Props(new MyActor))
    import scala.concurrent.duration._     
    implicit val timeout = akka.util.Timeout(5.seconds)
    Source( Seq("hello", "out", "world", "stop")).ask[Int](actorRef).runForeach(println)
    //output 
    hello
    out
    5
    3
    world
    5
    
Source.unfoldAsync[S, E](s: S)(f: (S) => Future[Option[(S, E)]]): Source[E, NotUsed]
Source.unfold[S, E](s: S)(f: (S) => Option[(S, E)]): Source[E, NotUsed]
    Create a Source that will unfold a value of type S into a pair of the next state S 
    and output elements of type E.
    Stream the result of a function as long as it returns a Some .
    The value inside the option consists of a tuple where the first value is a state 
    passed back into the next call to the function allowing to pass a state. 
    The first invocation of the provided fold function will receive the zero state. 
    //Example 
    This first sample starts at a user provided integer and counts down to zero using unfold :

    def countDown(from: Int): Source[Int, NotUsed] =
      Source.unfold(from) { current =>
        if (current == 0) None
        else Some((current - 1, current))
      }

    It is also possible to express unfolds that donot have an end, which will never return None 

    def fibonacci: Source[BigInt, akka.NotUsed] =
      Source.unfold((BigInt(0), BigInt(1))) {
        case (a, b) =>
          Some(((b, a + b), a))
      }
    fibonacci.take(10).runForeach(println)
    

Source.unfoldResource[T, S](create: () => S, read: (S) => Option[T], close: (S) => Unit): Source[T, NotUsed]
    Start a new Source from some resource which can be opened, read and closed.
Source.def unfoldResourceAsync[T, S](create: () => Future[S], read: (S) => Future[Option[T]], close: (S) => Future[Done]): Source[T, NotUsed]
    Note 
        create: Open or create the resource
        read: Fetch the next element or signal that we reached the end of the stream by returning a None
        close: Close the resource, invoked on end of stream or if the stream fails
    //Exmaple 

    trait Database {
      // blocking query
      def doQuery(): QueryResult
    }
    trait QueryResult {
      def hasMore: Boolean
      // potentially blocking retrieval of each element
      def nextEntry(): DatabaseEntry
      def close(): Unit
    }
    trait DatabaseEntry


    // we don't actually have one, it was just made up for the sample
    val database: Database = ???

    val queryResultSource: Source[DatabaseEntry, NotUsed] =
    Source.unfoldResource[DatabaseEntry, QueryResult](
    // open
    { () =>
      database.doQuery()
    },
    // read
    { query =>
      if (query.hasMore)
        Some(query.nextEntry())
      else
        // signals end of resource
        None
    },
    // close
    query => query.close())

    // process each element
    queryResultSource.runForeach(println)


//Repr[T] for Source, Source[Out, Mat]-> Source[T, Mat] 
//for Flow, Flow[In, Out, Mat] => Flow[In, T, Mat]
Source[In,Mat]/Flow[In,Out,Mat].merge[U >: Out, M](that: Source[U, M], eagerComplete: Boolean = false): Repr[U]
    Merge the given Source to this Flow, taking elements as they arrive 
    from input streams, picking randomly when several elements ready.
Source[In,Mat]/Flow[In,Out,Mat].mergeMat[U >: Out, Mat2, Mat3](that: Source[U, Mat2], eagerComplete: Boolean = false)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]

Source[In,Mat]/Flow[In,Out,Mat].mergeLatest[U >: Out, M](that: Source[U, M], eagerComplete: Boolean = false): Repr[Seq[U]]
    MergeLatest joins elements from N input streams into stream of lists of size N.
Source[In,Mat]/Flow[In,Out,Mat].mergeLatestMat[U >: Out, Mat2, Mat3](that: Source[U, Mat2], eagerClose: Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[Seq[U], Mat3]

Source[In,Mat]/Flow[In,Out,Mat].mergePreferred[U >: Out, M](that: Source[U, M], priority: Boolean, eagerComplete: Boolean = false): Repr[U]
Source[In,Mat]/Flow[In,Out,Mat].mergePreferredMat[U >: Out, Mat2, Mat3](that: Source[U, Mat2], preferred: Boolean, eagerClose: Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
    If all sources have elements ready, emit the preferred source first. 
    Then emit the preferred source again if another element is pushed. 
    Otherwise, emit all the secondary sources. R
    epeat until streams are empty. 
    For the case with two sources, when preferred is set to true then prefer the right source, 
    otherwise prefer the left source 
    
Source[In,Mat]/Flow[In,Out,Mat].mergePrioritized[U >: Out, M](that: Source[U, M], leftPriority: Int, rightPriority: Int, eagerComplete: Boolean = false): Repr[U]
Source[In,Mat]/Flow[In,Out,Mat].mergePrioritizedMat[U >: Out, Mat2, Mat3](that: Source[U, Mat2], leftPriority: Int, rightPriority: Int, eagerClose: Boolean)(matF: (Mat, Mat2) => Mat3): ReprMat[U, Mat3]
    Prefer sources depending on priorities if all sources have elements ready. 
    If a subset of all sources have elements ready the relative priorities 
    for those sources are used to prioritize. 
    For example, when used with only two sources, the left source has a probability of 
    (leftPriority) / (leftPriority + rightPriority) of being prioritized 
    and similarly for the right source. The priorities for each source must be positive integers.

Source[In,Mat]/Flow[In,Out,Mat].mergeSorted[U >: Out, M](that: Source[U, M])(implicit ord: Ordering[U]): Repr[U]
Source[In,Mat]/Flow[In,Out,Mat].mergeSortedMat[U >: Out, Mat2, Mat3](that: Source[U, Mat2])(matF: (Mat, Mat2) => Mat3)(implicit ord: Ordering[U]): ReprMat[U, Mat3]
    Merge the given Source to this Flow, taking elements as they arrive from input streams, 
    picking always the smallest of the available elements 
    (waiting for one element from each side to be available).

    //Example 
    import akka.stream.scaladsl._

    val sourceA = Source(List(1, 2, 3, 4))
    val sourceB = Source(List(10, 20, 30, 40))
    sourceA.merge(sourceB).runWith(Sink.foreach(println))
    // merging is not deterministic, can for example print 1, 2, 3, 4, 10, 20, 30, 40

    val prices = Source(List(100, 101, 99, 103))
    val quantity = Source(List(1, 3, 4, 2))
    prices
      .mergeLatest(quantity) //joins elements from N input streams into stream of lists of size N.
      .map {
        case price :: quantity :: Nil => price * quantity
      }
      .runForeach(println)
    // prints something like:
    // 100
    // 101
    // 303
    // 297
    // 396
    // 412
    // 206

    //false means , Left is prefered , emit preferred at first 
    val sourceA = Source(List(1, 2, 3, 4))
    val sourceB = Source(List(10, 20, 30, 40))
    sourceA.mergePreferred(sourceB, false).runWith(Sink.foreach(println))
    // prints 1, 10, ... since both sources have their first element ready and the left source is preferred
    sourceA.mergePreferred(sourceB, true).runWith(Sink.foreach(println))
    // prints 10, 1, ... since both sources have their first element ready and the right source is preferred

    val sourceA = Source(List(1, 2, 3, 4))
    val sourceB = Source(List(10, 20, 30, 40))
    sourceA.mergePrioritized(sourceB, 99, 1).runWith(Sink.foreach(println))
    // prints e.g. 1, 10, 2, 3, 4, 20, 30, 40 since both sources have their first element ready and the left source
    // has higher priority – if both sources have elements ready, sourceA has a 99% chance of being picked next
    // while sourceB has a 1% chance




//Repr[T] for Source, Source[Out, Mat]-> Source[T, Mat] 
//for Flow, Flow[In, Out, Mat] => Flow[In, T, Mat]
Source[In,Mat]/Flow[In,Out,Mat].zip[U](that: Source[U, _]): Repr[(Out, U)]
Source[In,Mat]/Flow[In,Out,Mat].zipAll[U, A >: Out](that: Source[U, _], thisElem: A, thatElem: U): Repr[(A, U)]
Source[In,Mat]/Flow[In,Out,Mat].zipAllMat[U, Mat2, Mat3, A >: Out](that: Source[U, Mat2], thisElem: A, thatElem: U)(matF: (Mat, Mat2) => Mat3): ReprMat[(A, U), Mat3]
Source[In,Mat]/Flow[In,Out,Mat].zipLatest[U](that: Source[U, _]): Repr[(Out, U)]
    Combine the elements of 2 streams into a stream of tuples, 
    picking always the latest element of each.
Source[In,Mat]/Flow[In,Out,Mat].zipLatestMat[U, Mat2, Mat3](that: Source[U, Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[(Out, U), Mat3]
Source[In,Mat]/Flow[In,Out,Mat].zipLatestWith[Out2, Out3](that: Graph[SourceShape[Out2], _])(combine: (Out, Out2) => Out3): Repr[Out3]
    Combine the elements of multiple streams into a stream of combined elements 
    using a combiner function, picking always 
    the latest of the elements of each source.
Source[In,Mat]/Flow[In,Out,Mat].zipLatestWithMat[Out2, Out3, Mat2, Mat3](that: Graph[SourceShape[Out2], Mat2])(combine: (Out, Out2) => Out3)(matF: (Mat, Mat2) => Mat3): ReprMat[Out3, Mat3]
Source[In,Mat]/Flow[In,Out,Mat].zipMat[U, Mat2, Mat3](that: Source[U, Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[(Out, U), Mat3]
    Combine the elements of current flow 
    and the given Source into a stream of tuples.
Source[In,Mat]/Flow[In,Out,Mat].zipWith[Out2, Out3](that: Source[Out2, _])(combine: (Out, Out2) => Out3): Repr[Out3]
    Put together the elements of current flow and the given Source 
    into a stream of combined elements using a combiner function.
Source[In,Mat]/Flow[In,Out,Mat].zipWithIndex: Repr[(Out, Long)]
Source[In,Mat]/Flow[In,Out,Mat].zipWithMat[Out2, Out3, Mat2, Mat3](that: Source[Out2, Mat2])(combine: (Out, Out2) => Out3)(matF: (Mat, Mat2) => Mat3): ReprMat[Out3, Mat3]

    //Example 
    import akka.stream.scaladsl._

    val sourceFruits = Source(List("apple", "orange", "banana"))
    val sourceFirstLetters = Source(List("A", "O", "B"))
    sourceFruits.zip(sourceFirstLetters).runWith(Sink.foreach(println))
    // this will print ('apple', 'A'), ('orange', 'O'), ('banana', 'B')


    val numbers = Source(1 :: 2 :: 3 :: 4 :: Nil)
    val letters = Source("a" :: "b" :: "c" :: Nil)
    numbers.zipAll(letters, -1, "default").runForeach(println)
    // prints:
    // (1,a)
    // (2,b)
    // (3,c)
    // (4,default)
    
    val sourceCount = Source(List("one", "two", "three"))
    val sourceFruits = Source(List("apple", "orange", "banana"))
    sourceCount
      .zipWith(sourceFruits) { (countStr, fruitName) =>
        s"$countStr $fruitName"
      }
      .runWith(Sink.foreach(println))
    // this will print 'one apple', 'two orange', 'three banana'

    Source(List("apple", "orange", "banana")).zipWithIndex.runWith(Sink.foreach(println))
    // this will print ('apple', 0), ('orange', 1), ('banana', 2)



Source[In,Mat]/Flow[In,Out,Mat].wireTap(that: Sink[Out, _]): Repr[Out]
Source[In,Mat]/Flow[In,Out,Mat].wireTap(f: (Out) => Unit): Repr[Out]
Source[In,Mat]/Flow[In,Out,Mat].wireTapMat[Mat2, Mat3](that: Sink[Out, Mat2])(matF: (Mat, Mat2) => Mat3): ReprMat[Out, Mat3]
    Attaches the given Sink to this Flow as a wire tap, meaning that elements 
    that pass through will also be sent to the wire-tap Sink, 
    without the latter affecting the mainline flow.

    //Example 
    import akka.stream.scaladsl._ 

    Source( 1 to 10).wireTap(Sink.foreach(println)).collect{ case x:Int if x%2 ==0 => s"Out-$x"}.runForeach(println)
    //output
    1
    Out-2
    2
    3
    Out-4
    4
    5
    Out-6
    6
    7
    Out-8
    8
    9
    Out-10
    10



    
///Another Bigger Example   
//synopsis 
Concat vs Merge 
    Concat concates streams into one Stream, 
    by completing one stream and then another stream (one after another)
    So if first stream is not completing, we have a problem of not reading second stream 
    Whereas Merge would take N element(breadth) from one stream and then pick N element 
    from another , then ... and then cycle back 
flatMap vs map 
    Inner function in flatMap must produce Source which would be flattened 
    whereas inner function in map produces Iterable which would be flattened 
    

//example 
case class Author(handle: String)
case class Hashtag(name: String)

case class Tweet(author: Author, timestamp: Long, body: String) {
  def hashtags: Set[Hashtag] =
    body
      .split(" ")
      .collect {
        case t if t.startsWith("#") => Hashtag(t.replaceAll("[^#\\w]", ""))
      }
      .toSet
}

val akkaTag = Hashtag("#akka")

val tweets: Source[Tweet, NotUsed] = Source(
  Tweet(Author("rolandkuhn"), System.currentTimeMillis, "#akka rocks!") ::
  Tweet(Author("patriknw"), System.currentTimeMillis, "#akka !") ::
  Tweet(Author("bantonsson"), System.currentTimeMillis, "#akka !") ::
  Tweet(Author("drewhk"), System.currentTimeMillis, "#akka !") ::
  Tweet(Author("ktosopl"), System.currentTimeMillis, "#akka on the rocks!") ::
  Tweet(Author("mmartynas"), System.currentTimeMillis, "wow #akka !") ::
  Tweet(Author("akkateam"), System.currentTimeMillis, "#akka rocks!") ::
  Tweet(Author("bananaman"), System.currentTimeMillis, "#bananas rock!") ::
  Tweet(Author("appleman"), System.currentTimeMillis, "#apples rock!") ::
  Tweet(Author("drama"), System.currentTimeMillis, "we compared #apples to #oranges!") ::
  Nil)

//
tweets
  .filterNot(_.hashtags.contains(akkaTag)) // Source[Tweet, NotUsed]: Remove all tweets containing #akka hashtag
  .map(_.hashtags) //Source[Set[Hashtag], NotUsed]: Get all sets of hashtags ...
  .reduce(_ ++ _) // Source[Set[Hashtag], NotUsed]: and reduce them to a single set, removing duplicates across all tweets
  //Source[+Out, +Mat].flatMapConcat[T, M](f: (Out) => Source[T,M]): Source[T, Mat]
  //Source[+Out, +Mat].mapConcat[T](f: (Out) => IterableOnce[T]): Source[T, Mat]
  //Transform each input element into an Iterable , then flattened 
  //basically flattening Set 
  .mapConcat(identity) // Source[Hashtag, NotUsed]:  Flatten the set of hashtags to a stream of hashtags
  .map(_.name.toUpperCase) //Source[Hashtag, NotUsed]:   Convert all hashtags to upper case
  .runWith(Sink.foreach(println)) // Attach the Flow to a Sink that will finally print the hashtags

//output 
#BANANAS
#APPLES
#ORANGES


//More Ops 
For example, Such tweets can be created from various Source 
eg Source acting as Actor (we get actorRef when materialized)

Source.actorRef[T](completionMatcher: PartialFunction[Any, CompletionStrategy], 
        failureMatcher: PartialFunction[Any, Throwable], 
        bufferSize: Int, 
        overflowStrategy: OverflowStrategy): Source[T, ActorRef]
    Buffers(or as per overflowStrategy) if no demand from downstream
    The stream can be completed successfully or failed by sending the actor reference a message 
    that is matched by completionMatcher or failureMatcher, then actor would be stopped 
    OverflowStrategy
        https://doc.akka.io/api/akka/current/akka/stream/OverflowStrategy$.html
        dropBuffer 
             drops all the buffered elements to make space for the new element.
        dropHead, dropTail, dropNew , backpressure, fail 
    CompletionStrategy
        def draining: CompletionStrategy
            Already buffered elements will be signaled before signaling completion.
        def immediately: CompletionStrategy
            The completion will be signaled immediately even if elements are still buffered.

//Example 
val completionMatcher: PartialFunction[Any, CompletionStrategy] =  
    { case x: String if x == "STOP" => CompletionStrategy.immediately}
val failureMatcher: PartialFunction[Any, Throwable] = 
    { case x: String if x == "RAISE" => throw new Exception("failure")}
    
val _tweets: Source[Tweet, ActorRef] = 
    Source.actorRef[Tweet]( completionMatcher,failureMatcher  , 200, OverflowStrategy.dropBuffer )

val actorRef = _tweets.to(Sink.foreach(println)).run() 
actorRef ! Tweet(Author("rolandkuhn"), System.currentTimeMillis, "#akka rocks!")
//actorRef ! "STOP" //to stop 

/*
//Does not work 
//Can check now - but fails in 2.6.13 version???
//Source[Out, Mat].preMaterialize()(implicit materializer: Materializer): (Mat, Source[Out, NotUsed])    
val (actorRef1, __tweets: Source[Tweet, NotUsed]) = _tweets.preMaterialize()
 
//Check 
//Source[Out,Mat],to[Mat2](sink: Graph[SinkShape[Out], Mat2]): RunnableGraph[Mat]
__tweets.runWith(Sink.foreach(println))

actorRef1 ! Tweet(Author("rolandkuhn"), System.currentTimeMillis, "#akka rocks!")
*/


//Broadcasting a stream
Now let’s say we want to persist all hashtags, 
as well as all author names from this one live stream. 

Elements that can be used to form such 'fan-out' (or 'fan-in') structures 
are referred to as 'junctions' in Akka Streams. 

//to send to an Actor , Note this actor must send back some ack (any message as ack message)
//Sink.actorRefWithBackpressure[T](ref: ActorRef, onInitMessage: Any, 
//    onCompleteMessage: Any, onFailureMessage: (Throwable) => Any): Sink[T, NotUsed]

class SinkActor extends Actor {
    def receive: Receive = {  
           case "END" => context.stop(self)    
           case msg => 
            println(s"$self - $msg")
            sender() ! "ack"            
        }
}

val writeAuthors: Sink[Author, NotUsed] = 
    Sink.actorRefWithBackpressure[Author](system.actorOf(Props(new SinkActor)), 
        "INIT", "END", onFailureMessage = ex => "FAILURE")

val writeHashtags: Sink[Hashtag, NotUsed] = Sink.foreach(println)

//Below materializes into NotUsed , so can not be used with _tweets as we want ActorRef
val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder => 
  import GraphDSL.Implicits._
  val bcast = builder.add(Broadcast[Tweet](2))
  tweets ~> bcast.in
  bcast.out(0) ~> Flow[Tweet].filter(_.hashtags.contains(akkaTag)).map(_.author) ~> writeAuthors
  bcast.out(1) ~> Flow[Tweet].mapConcat(_.hashtags.toList) ~> writeHashtags
  ClosedShape
})
g.run() //NotUsed 

//We need ActorRef ie the materialization of _tweets
//so Use below form , m1,m2,m3 are three args Mat values 
val actorRef = RunnableGraph.fromGraph(GraphDSL.create(_tweets, writeAuthors, writeHashtags)((m1,m2,m3) => m1) { implicit builder => 
  (source, sink1, sink2) => //those args are coming here 
  import GraphDSL.Implicits._
  
  val bcast = builder.add(Broadcast[Tweet](2))
  source ~> bcast.in
  bcast.out(0) ~> Flow[Tweet].filter(_.hashtags.contains(akkaTag)).map(_.author) ~> sink1
  bcast.out(1) ~> Flow[Tweet].mapConcat(_.hashtags.toList) ~> sink2
  ClosedShape
}).run()



val lt = Tweet(Author("rolandkuhn"), System.currentTimeMillis, "#akka rocks!") ::
  Tweet(Author("patriknw"), System.currentTimeMillis, "#akka !") ::
  Tweet(Author("bantonsson"), System.currentTimeMillis, "#akka !") ::
  Tweet(Author("drewhk"), System.currentTimeMillis, "#akka !") ::
  Tweet(Author("ktosopl"), System.currentTimeMillis, "#akka on the rocks!") ::
  Tweet(Author("mmartynas"), System.currentTimeMillis, "wow #akka !") ::
  Tweet(Author("akkateam"), System.currentTimeMillis, "#akka rocks!") ::
  Tweet(Author("bananaman"), System.currentTimeMillis, "#bananas rock!") ::
  Tweet(Author("appleman"), System.currentTimeMillis, "#apples rock!") ::
  Tweet(Author("drama"), System.currentTimeMillis, "we compared #apples to #oranges!") ::
  Nil
  
lt.foreach{ t => actorRef ! t }
lt.foreach{ t => actorRef ! t }


//Few other examples based on Tweets 

//Flow[-In, +Out, +Mat].map[T](f: (Out) => T): Flow[-In, T, +Mat]
val count: Flow[Tweet, Int, NotUsed] = Flow[Tweet].map(_ => 1)

//Sink.fold[U, T](zero: U)(f: (U, T) => U): Sink[T, Future[U]]
val sumSink: Sink[Int, Future[Int]] = Sink.fold[Int, Int](0)(_ + _)

//Source[Out,Mat].via[T, Mat2](flow: Flow[Out, T, Mat2]): Source[T, Mat]
//Source[Out,Mat].toMat[Mat2, Mat3](sink: Sink[Out, Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]
val counterGraph: RunnableGraph[Future[Int]] =
  _tweets.via(count).toMat(sumSink)(Keep.right)

val sum: Future[Int] = counterGraph.run()

sum.foreach(c => println(s"Total tweets processed: $c"))

//More Examples 
A RunnableGraph may be reused and materialized multiple times, 
because it is only the 'blueprint' of the stream. 
This means that if we materialize a stream, for example one that consumes 
a live stream of tweets within a minute, the materialized values for those 
two materializations will be different

//Example 
val sumSink = Sink.fold[Int, Int](0)(_ + _)
val counterRunnableGraph: RunnableGraph[Future[Int]] =
  _tweets.filter(_.hashtags contains akkaTag).map(t => 1).toMat(sumSink)(Keep.right)

// materialize the stream once in the morning
val morningTweetsCount: Future[Int] = counterRunnableGraph.run()
// and once in the evening, reusing the flow
val eveningTweetsCount: Future[Int] = counterRunnableGraph.run()



///FileIO 
//Streaming data from a file is as easy as creating a FileIO.fromPath given a target path, 
//and an optional chunkSize which determines the buffer size determined 
//as one 'element' in such stream:

import akka.stream.scaladsl._
import akka.util._
import java.nio.file._

val file = Paths.get("iris.csv")

//fromPath(f: Path, chunkSize: Int = 8192): Source[ByteString, Future[IOResult]]
//def toPath(f: Path, options: Set[OpenOption] = ...): Sink[ByteString, Future[IOResult]]
val foreach: Future[IOResult] = FileIO.fromPath(file)
  .to(Sink.ignore)
  .run()


//If you want to configure a custom dispatcher for file IO operations globally, 
FileIO.fromPath(file)
      .withAttributes(ActorAttributes.dispatcher("custom-blocking-io-dispatcher"))

//Example of CSV processing 
case class Row(SepalLength:Double, SepalWidth:Double, 
    PetalLength:Double, PetalWidth:Double, Name:String)
case class Data(name:String="", count:Int=0, allSL:List[Double]=List.empty, allRows:List[Row]=List.empty)

    
FileIO.fromPath(file).
  via(Framing.delimiter(ByteString("\n"), maximumFrameLength = 100, allowTruncation = true)).
  map(_.utf8String.trim).
  zipWithIndex.      //Source[(String, Long)], Future[IOResult]]
  collect{case (line, index) if index != 0 => line}. //Source[String, Future[IOResult]]
  map{ rr => 
        val arr = rr.split(",")
        val ( Array(a,b,c,d), e) = (arr.slice(0,4).map(_.toDouble), arr.last)
        Row(a,b,c,d,e) 
    }. //Source[Row, Future[IOResult]]
  groupBy[String](10, _.Name).
  //3 substreams based on Name key 
  //all Substreams , together 
  //fold[T](zero: T)(f: (T, Out) => T): Repr[T]
  fold[Data](Data()){ case ( Data(n,c,slrs,allrs), row ) => Data(row.Name, c+1, slrs :+ row.SepalLength, allrs :+ row)}.
  mergeSubstreams.
  toMat(Sink.seq[Data])(Keep.right).run().  //Future[Seq[Data]]
  map{ seqData => 
    seqData.map(data => (data.name, Map("count" -> data.count, "mean" -> Map("SepalLength" -> data.allSL.sum/data.count.toDouble) )))
  }.foreach(println)



///Backpressure in Actions -- ADVANCED * 
import java.io.File 

def lineSink(filename: String): Sink[String, Future[IOResult]] = {
 Flow[String]
  .alsoTo(Sink.foreach(s => println(s"$filename: $s")))
  .map(s => ByteString(s + "\n"))
  .toMat(FileIO.toFile(new File(filename)))(Keep.right)
}

val source: Source[Int, NotUsed] = Source(1 to 100)
val factorials: Source[BigInt, NotUsed] =
      source.scan(BigInt(1))((acc, next) => acc * next)
      
val sink1 = lineSink("factorial1.txt")
val sink2 = lineSink("factorial2.txt")

val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder =>
  import GraphDSL.Implicits._
  val bcast = builder.add(Broadcast[String](2))
  factorials.map(_.toString) ~> bcast.in
  bcast.out(0) ~> sink1
  bcast.out(1) ~> sink2
  ClosedShape
})
g.run()

Output rapidly alternate between factorial1.txt and factorial2.txt, seemingly at the same rate. 

Lets make one of the consumers slow. 
We can do this by forcing one of the sinks to only process one element per second. 
This is called throttling. Below is the line that creates such a sink:
	
val slowSink2 = Flow[String]
  .via(Flow[String]
  //throttle(elements: Int, per: FiniteDuration, maximumBurst: Int, mode: ThrottleMode): Repr[Out]
  //Shaping :Tells throttle to make pauses before emitting messages to meet throttle rate 
  .throttle(1, 1.second, 1, ThrottleMode.Shaping))
  .toMat(sink2)(Keep.right)


val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder =>
  import GraphDSL.Implicits._
  val bcast = builder.add(Broadcast[String](2))
  factorials.map(_.toString) ~> bcast.in
  bcast.out(0) ~> sink1
  bcast.out(1) ~> slowSink2
  ClosedShape
})
g.run()

Writes to both factorial1.txt and factorial2.txt are slowed down by the same amount.
whats happening is the source itself is being slowed down. 

The slow sink is (asynchronously) telling the source how much it can process — demand — one element 
in this case. It updates this demand when its ready to process again — 
after one second . Put succinctly, the slow sink is signaling backpressure up to the source

What happens if our slow sink can buffer a preconfigured number of elements 
	
val bufferedSink2 = Flow[String]
   .buffer(50, OverflowStrategy.dropNew) //If the buffer is full when a new element arrives, drops the new element.
   .via(Flow[String]
   .throttle(1, 1.second, 1, ThrottleMode.shaping))
   .toMat(sink2)(Keep.right)

val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder =>
  import GraphDSL.Implicits._
  val bcast = builder.add(Broadcast[String](2))
  factorials.map(_.toString) ~> bcast.in
  bcast.out(0) ~> sink1
  bcast.out(1) ~> bufferedSink2
  ClosedShape
})
g.run()

The writes to factorial1.txt are not slowed down at all. 
That can only mean the source continues producing as fast as it can —
 backpressure has not been signaled. 
 
That because the slow consumer immediately buffers ("absorbs") up to 50 elements, 
giving a chance for the source to continue chugging along. 

However, factorial2.txt ends up stopping at the factorial of 51, 
with a second delay between each element. 
With OverflowStrategy.dropNew, new elements are dropped while a buffer is full. 
In this example, since the producer is so much faster than the throttled consumer, 
it produces all the remaining elements while the buffer is still full — they get dropped. 

If we change our buffering strategy to Overflow.backpressure, what do you think will happen? 
	
val bufferedSink3 = Flow[String]
   .buffer(50, OverflowStrategy.backpressure)
   .via(Flow[String]
   .throttle(1, 1.second, 1, ThrottleMode.shaping))
   .toMat(sink2)(Keep.right)
   
val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder =>
  import GraphDSL.Implicits._
  val bcast = builder.add(Broadcast[String](2))
  factorials.map(_.toString) ~> bcast.in
  bcast.out(0) ~> sink1
  bcast.out(1) ~> bufferedSink3
  ClosedShape
})
g.run() 

Initially the writes to factorial1.txt are not slowed down (like the first example). 
However, after the buffer fills up, we see the same behavior we saw 
with a slow consumer and no buffering. 
With OverflowStrategy.backpressure, backpressure is signaled up to the source 
when the buffer becomes full. 
No data is dropped, but the overall throughput is reduced.

///Substreams eg created by  groupBy  -- ADVANCED * 
Substreams are represented SubFlow instances,
on which you can multiplex a single Source or Flow into a stream of streams.

SubFlow 
    https://doc.akka.io/api/akka/current/akka/stream/scaladsl/SubFlow.html
    trait SubFlow[+Out, +Mat, +F[+_], C] extends FlowOps[Out, Mat]
        All FlowOps are possible which work on individual substream, addl methods are 
        def mergeSubstreamsWithParallelism(parallelism: Int): F[Out]
            Flatten the sub-flows back into the super-flow by performing 
            a merge with the given parallelism limit.
        def mergeSubstreams: F[Out]
            equiv to mergeSubstreamsWithParallelism(Integer.MAX_VALUE). 
        def to[M](sink: Sink[Out, M]): C
            Attach a Sink to each sub-flow, closing the overall Graph that is being constructed.
        def concatSubstreams: F[Out]
            Flatten the sub-flows back into the super-flow by concatenating them.  
            This is usually a bad idea when combined with groupBy since it can easily lead 
            to deadlock—the concatenation does not consume from the second substream 
            until the first has finished and the groupBy operator 
            will get back-pressure from the second stream.

SubFlows cannot contribute to the super-flows materialized value 
since they are materialized later, during the runtime of the stream processing.

Operators that create substreams 
Source[+Out, +Mat]
    def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Repr, Closed]
    def groupBy[K](maxSubstreams: Int, f: (Out) => K, allowClosedSubstreamRecreation: Boolean): SubFlow[Out, Mat, Repr, Closed]
    def splitAfter(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements and emits them 
        to a stream of output streams. It *ends* the current substream when the predicate is true. 
    def splitAfter(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
    def splitWhen(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
        This operation applies the given predicate to all incoming elements 
        and emits them to a stream of output streams, always beginning a new one with the current element 
        if the given predicate returns true for it.
    def splitWhen(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
class Flow[-In, +Out, +Mat]
    def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Repr, Closed]
    def groupBy[K](maxSubstreams: Int, f: (Out) => K, allowClosedSubstreamRecreation: Boolean): SubFlow[Out, Mat, Repr, Closed]
    def splitAfter(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
    def splitAfter(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
    def splitWhen(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]
    def splitWhen(substreamCancelStrategy: SubstreamCancelStrategy)(p: (Out) => Boolean): SubFlow[Out, Mat, Repr, Closed]


//Nesting operators-groupBy
val source = Source(1 to 10).groupBy(3, _ % 3)  
//SubFlow[Int,NotUsed,[+O]Source[O,NotUsed], RunnableGraph[NotUsed]]
//SubFlow[+Out, +Mat, +F[+_], C], outputs =Int,NotUsed  with creation type = Source 
//So mergeSubstreams:F[_] would flatten to Source[O]

Each Stream corresponds to one key .
When a new key is encountered for the first time a new substream is opened 
and subsequently fed with all elements belonging to that key.

If allowClosedSubstreamRecreation is set to true a substream belonging 
to a specific key will be recreated 
if it was closed before, otherwise elements belonging to that key will be dropped(default)

If you add a Sink or Flow right after the groupBy operator, 
all transformations are applied to all substreams 

SubFlow[+Out, +Mat, +F[+_], C]
    def to[M](sink: Sink[Out, M]): C
    def via[T, Mat2](flow: Flow[Out, T, Mat2]): SubFlow[T, Mat, F[_], C]

source.to(Sink.ignore).run()
source.to(Sink.foreach(println)).run()

//Note there is no toMat/viaMat/runWith version , so there is no way to execute like below 
//source.toMat(Sink.Seq)(Keep.right).run()/*Future*/.foreach(println) //ERROR 

Use mergeSubstreams method merges an unbounded number of substreams back to the main stream.

source.mergeSubstreams.runWith(Sink.Seq)

You can limit the number of active substreams running and being merged at a time, 
with either the mergeSubstreamsWithParallelism 
But it creates deadlock if no of substreams are greater than 2 (which is true, 3 in our case)

source.mergeSubstreamsWithParallelism(2).runWith(Sink.foreach(println)) 
//prints 1 and 2 and deadlocks 

concatSubstreams is equivalent to mergeSubstreamsWithParallelism(1), but dont use concatSubstreams
with groupBy since it leads to deadlock—the concatenation does not consume from the second substream 
until the first has finished(which is never) 
and the groupBy operator will get back-pressure from the second stream.

source.concatSubstreams.runWith(Sink.foreach(println)) // Only prints 1 and the goes to deadlock 

//Some Examples 
//Repr[_] is either Source or Flow 
def groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Repr, Closed]
    This operation demultiplexes the incoming stream into separate output streams, 
    one for each element key. The key is computed for each element using the given function. 
    When a new key is encountered for the first time a new substream is opened and subsequently 
    fed with all elements belonging to that key.
    https://doc.akka.io/api/akka/2.6/akka/stream/scaladsl/SubFlow.html
    //Example 
    Source(1 to 10)
      .groupBy(maxSubstreams = 2, _ % 2 == 0) // create two sub-streams with odd and even numbers
      .reduce(_ + _) // for each sub-stream, sum its elements
      .mergeSubstreams // merge back into a stream
      .runForeach(println)
    //25
    //30  

//splitWhen and splitAfter
If the predicate for splitWhen and splitAfter returns true, 
a new substream is generated, 
and the succeeding elements after split will flow into the new substream.

splitWhen flows the element on which the predicate returned true to a new substream, 
whereas splitAfter flows the next element to the new substream after the element on 
which predicate returned true.

Source(1 to 10).splitWhen(SubstreamCancelStrategy.drain)(_ == 3)
Source(1 to 10).splitAfter(SubstreamCancelStrategy.drain)(_ == 3)


These are useful when you scanned over something and you don’t need to care about anything behind it. 
A typical example is counting the number of characters for each line like below.

val text =
  "This is the first line.\n" +
  "The second line.\n" +
  "There is also the 3rd line\n"

val charCount = Source(text.toList)  //creates list of chars 
  .splitAfter { _ == '\n' }  //SubFlow[Char,Notused, Source[_], RunnableGraph]
  .filter(_ != '\n')            //on each substream 
  .map(_ => 1)                  //on each substream 
  .reduce(_ + _)                //on each substream  
  //SubFlow[+Out, +Mat, +F[+_], C].to[M](sink: Sink[Out, M]): C
  .to(Sink.foreach(println))    //on each substream 
  .run()

//This prints out the following output.
23
16
26

    


///Constructing Graphs -- ADVANCED 
Junctions must always be created with defined type parameters, 
as otherwise the Nothing type will be inferred.

GraphDSL.Builder object is mutable
nce the GraphDSL has been constructed though, the GraphDSL instance is immutable, 
thread-safe, and freely shareable.

//Input and Output in Junctions 
Junctions have '.in' if single input, or '.in(index). for inputs 
and  '.out' for single output or '.out(index). for outputs 

For example Source , has '.out', Sink has '.in' and flow as '.out', '.in' 
and Boradcast,Balance has '.in' and '.out(index)', Balance, 
Merge has 'in(index)' and '.out'

However, Zip*, Unzip* are  zips N inputs to one  or unzips a N tuple, 
hence use inN, outN etc N=0,...maxnumber 
and single input/output is usual '.in/.out'   respectively

To put asunc boundary, use '.async'

//Below junctions are available
Fan-out
    Broadcast[T](outputPorts: Int, eagerCancel: Boolean = false)
        (1 input, N outputs) 
        given an input element emits to each output
    Balance[T](outputPorts: Int, waitForAllDownstreams: Boolean = false)
        (1 input, N outputs) 
        given an input element emits to one of its output ports
    Partition(outputPorts: Int, partitioner: (T) => Int, eagerCancel: Boolean)
        (1 input, N outputs)
        emitting an incoming upstream element to one downstream consumer 
        according to the partitioner function applied to the element
    UnzipWithN[In,A1,A2,...](unzipper: (In) => (A1, A2, ...))
        (1 input, N outputs) 
        takes a function of 1 input that given a value for each input emits N output elements 
        (where N <= 20) eg for 3, (In) => (A1, A2, A3)
    Unzip[A, B](): Unzip[A, B] 
        (1 input, 2 outputs) 
        splits a stream of (A,B) tuples into two streams, one of type A and one of type B
Fan-in
    Merge[T](inputPorts: Int, eagerComplete: Boolean = false): Merge[T] 
        (N inputs , 1 output) 
        picks randomly from inputs pushing them one by one to its output
    MergePreferred[T](secondaryPorts: Int, eagerComplete: Boolean = false) 
        (N inputs , 1 output) 
        like Merge but if elements are available on '.preferred' port, it picks from it, 
        otherwise randomly from others '.in(index)'
    MergePrioritized[T](priorities: Seq[Int], eagerComplete: Boolean = false) 
        (N inputs , 1 output) 
        like Merge but if elements are available on all input ports, 
        it picks from them randomly based on their priority
    MergeSorted[T]() 
        (2 inputs, 1 output)
        Merge two pre-sorted streams such that the resulting stream is sorted.
    MergeSequence(inputPorts: Int)(extractSequence: (T) => Long)
        (N inputs , 1 output) 
        Merge pre-sorted N streams 
        Merged stream must be sequential starting from 0 with increment N 
        Hence N inputs must be that kind of stream 
        Main Usecase is to merge a partitioned stream back together while maintaining order.
    ZipWith[A1,A2,...,Out](zipper: (A1, A2, ...) => O)   
        (N inputs, 1 output) 
        which takes a function of N inputs that given a value for each input emits 1 output element 
        eg for 3 (A1, A2, A3) => O, O could be tuple or any output 
    Zip[A, B](): Zip[A, B] 
        (2 inputs, 1 output) 
        is a ZipWith specialised to zipping input streams of A and B into a (A,B) tuple stream
    Concat[T](inputPorts: Int = 2)
        (2 inputs, 1 output) 
        concatenates two streams (first consume one, then the second one)
    Interleave[T](inputPorts: Int, segmentSize: Int, eagerClose: Boolean = false)
        (N inputs, 1 output)
        takes N/segmentSize elements per input stream, in-order of inputs, 
        emits them downstream and then cycles/"wraps-around" the inputs.
    ZipN[A](n: Int): ZipN[A]
        (N inputs, 1 output)
        Basically a specialized ZipWithN[A, Seq[A]], produces Seq[A] stream 
    ZipWithN[A, O](zipper: (Seq[A]) => O)(n: Int)
        (N inputs, 1 output)
        Zips N inputs to O by zipper fn 
        
 
//Shape 
Every Junction has associated Shape eg RunnableGraph has ClosedShape 
To get shape from Junction, use '.shape' ,

Shape important methods 
    def inlets: Seq[Inlet[_]]
        get a list of all input ports
    def outlets: Seq[Outlet[_]]
        get a list of all output ports

Other than above, inidiviual Shape derived class, Source, Sink, Flow has 
    val in: Inlet[I] for Flow, Sink 
        FlowShape(in: Inlet[I], out: Outlet[O]) 
        SinkShape(in: Inlet[T]) 
    val out: Outlet[O] for Flow, Source 
        SourceShape(out: Outlet[T]) 

FanIn has below with constructor
    FanInShapeN(in0,in1, ....,out)
and FanOut has below with constructor 
    FanOutShapeN(in, out0, ....)

UniformFanInShape has  ctor
    UniformFanInShape(n: Int) with in(index) and out 
    UniformFanInShape[I, O](outlet: Outlet[O], inlets: Inlet[I]*): UniformFanInShape[I, O]

UniformFanOutShape has ctor 
    UniformFanOutShape(n: Int) with out(index) and in  
    UniformFanOutShape[I, O](inlet: Inlet[I], outlets: Outlet[O]*): UniformFanOutShape[I, O] 
  
//Ref 
RunnableGraph
    fromGraph[Mat](g: Graph[ClosedShape, Mat]): RunnableGraph[Mat]
GraphDSL
    create[S <: Shape]()(buildBlock: (Builder[NotUsed]) => S): Graph[S, NotUsed]
        Mat is always NotUsed 
    create[S <: Shape, Mat](g1: Graph[Shape, Mat])(buildBlock: (Builder[Mat]) => (Graph.Shape) => S): Graph[S, Mat]
        Mat is always arg Mat 
    create[S <: Shape, Mat, M1, M2](g1: Graph[Shape, M1], g2: Graph[Shape, M2])(combineMat: (M1, M2) => Mat)(buildBlock: (Builder[Mat]) => (Graph.Shape, Graph.Shape) => S): Graph[S, Mat]
        We have till 22 args and Mat can be chosen by combineMat Fn 
        
    createGraph[S <: Shape, S1 <: Shape, Mat](g1: Graph[S1, Mat])(buildBlock: (Builder[Mat]) => (S1) => S): Graph[S, Mat]
    createGraph[S <: Shape, Mat, M1, M2, S1 <: Shape, S2 <: Shape](g1: Graph[S1, M1], g2: Graph[S2, M2])(combineMat: (M1, M2) => Mat)(buildBlock: (Builder[Mat]) => (S1, S2) => S): Graph[S, Mat]    
        New API in place of 'create', same functionality 
        We have till 22 args and Mat can be chosen by combineMat Fn 
       
//Two Ways to Create RunnableGraph (only when returns ClosedShape) 

//OPTION-1: Access outside params directly - But Mat can not be picked at-will 
val in = Source(1 to 10)
val out = Sink.ignore
  
val g = RunnableGraph.fromGraph(GraphDSL.create() { implicit builder =>
  import GraphDSL.Implicits._

  val bcast = builder.add(Broadcast[Int](2)) //2 outputs 
  val merge = builder.add(Merge[Int](2))  // 2 inputs 

  val f1, f2, f3, f4 = Flow[Int].map(_ + 10)  //Flow.apply[T]: Flow[T, T, NotUsed] 
  //Multiple assignments like val x,y =1 , each would get different instance of same Flow operations 
  //visually ~> should match input and output designed above 
  //in, out are from outside 
  in ~> f1 ~> bcast ~> f2 ~> merge ~> f3 ~> out  //input of bcastTO first output of bcast .... first input of merge 
              bcast ~> f4 ~> merge               //                 2nd output of bcast ....... 2nd input of merge  , merge outputs one which goes to f3 
  ClosedShape
})
g.run()

//OPTION-2 Creation of graphs with Mats - here like keep.both 
//Note till 22 params create methods are available 
val gMat = RunnableGraph.fromGraph(GraphDSL.create(in, out )((m1,m2) => (m1,m2) ) { implicit builder =>
  (inArg, outArg) =>
  import GraphDSL.Implicits._

  val bcast = builder.add(Broadcast[Int](2)) //2 outputs 
  val merge = builder.add(Merge[Int](2))  // 2 inputs 

  val f1, f2, f3, f4 = Flow[Int].map(_ + 10)  //Flow.apply[T]: Flow[T, T, NotUsed] //Multiple assignments like val x,y =1 , each would get different instance of same Flow operations 
  //visually ~> should match input and output designed above 
  inArg ~> f1 ~> bcast ~> f2 ~> merge ~> f3 ~> outArg  //input of bcastTO first output of bcast .... first input of merge 
                 bcast ~> f4 ~> merge               //                 2nd output of bcast ....... 2nd input of merge  , merge outputs one which goes to f3 
  ClosedShape
})
gMat.run() //Tuple of in, out Mat 


///Constructing and combining Partial Graphs --ADVANCED
By returning a different Shape than ClosedShape, for example FlowShape(in, out), 

Making a Graph a RunnableGraph requires all ports to be connected, 

A partial graph returns the Shape (constructed by  Shape constructor 
with  yet to be connected ports )

//Example - 3 inputs will pick the greatest int value of each zipped triple. 
//expose 3 input ports (unconnected sources) and one output port (unconnected sink).

val pickMaxOfThree = GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._
  
  //ZipWith[A1, A2, O](zipper: (A1, A2) => O): ZipWith2[A1, A2, O] 
  val zip1 = b.add(ZipWith[Int, Int, Int](math.max _))  //2 in 1 out , (A1,A2) => O, max takes two args 
  val zip2 = b.add(ZipWith[Int, Int, Int](math.max _))  //2 in 1 out 
  
  zip1.out ~> zip2.in0
  
  //mention all open in and outs 
  //UniformFanInShape[I, O](outlet: Outlet[O], inlets: Inlet[I]*): UniformFanInShape[I, O] 
  UniformFanInShape(zip2.out, zip1.in0, zip1.in1, zip2.in1)
}

val resultSink = Sink.head[Int]

//RunnableGraph as return ClosedShape 
val g = RunnableGraph.fromGraph(GraphDSL.create(resultSink) { implicit b => sink =>
  import GraphDSL.Implicits._

  // importing the partial graph will return its shape (inlets & outlets)
  val pm3 = b.add(pickMaxOfThree)
  
  //inlets are zip1.in0, zip1.in1, zip2.in1 from pickMaxOfThree
  //outlets are zip2.out
  Source.single(1) ~> pm3.in(0)
  Source.single(2) ~> pm3.in(1)
  Source.single(3) ~> pm3.in(2)
  pm3.out ~> sink.in
  ClosedShape
})

val max: Future[Int] = g.run()
max.foreach(println)


///Constructing Sources, Sinks and Flows from Partial Graphs -- ADVANCED 
1.Source is a partial graph with exactly one output, that is it returns a SourceShape.
  Create Source from  
    Source.fromGraph[T, M](g: Graph[SourceShape[T], M]): Source[T, M] 
  ie using GraphDSL.create and returning a  SourceShape(out: Outlet[T]) 
  
2.Sink is a partial graph with exactly one input, that is it returns a SinkShape.
  Create Sink from  
    Sink.fromGraph[T, M](g: Graph[SinkShape[T], M]): Sink[T, M] 
  ie using GraphDSL.create and returning a   SinkShape(in: Inlet[T])  
  
3.Flow is a partial graph with exactly one input and exactly one output, that is it returns a FlowShape.
  Create Flow from 
    Flow.fromGraph[I, O, M](g: Graph[FlowShape[I, O], M]): Flow[I, O, M] 
  ie using GraphDSL.create and returning a   FlowShape(in: Inlet[I], out: Outlet[O]) 

//Example of Source 
val pairs = Source.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  // prepare graph elements
  val zip = b.add(Zip[Int, Int]())
  def ints = Source.fromIterator(() => Iterator.from(1))

  // connect the graph
  ints.filter(_ % 2 != 0) ~> zip.in0
  ints.filter(_ % 2 == 0) ~> zip.in1

  // expose port
  SourceShape(zip.out)
})

val firstPair: Future[(Int, Int)] = pairs.runWith(Sink.head)

//Example of FLow 
val pairUpWithToString =
  Flow.fromGraph(GraphDSL.create() { implicit b =>
    import GraphDSL.Implicits._

    // prepare graph elements
    val broadcast = b.add(Broadcast[Int](2))
    val zip = b.add(Zip[Int, String]())

    // connect the graph
    broadcast.out(0).map(identity) ~> zip.in0
    broadcast.out(1).map(_.toString) ~> zip.in1

    // expose ports
    FlowShape(broadcast.in, zip.out)
  })

pairUpWithToString.runWith(Source(List(1)), Sink.head)


///WARNNING - Graph cycles, deadlocks-- ADVANCED  
Cycles in bounded stream topologies need special considerations to avoid potential deadlocks 

Since Akka Streams (and Reactive Streams in general) guarantee bounded(buffered) processing 
it means that only a bounded number(buffer size) of elements are buffered over any time span. 



// WARNING! The graph below deadlocks!
val source = Source(1 to 10)

RunnableGraph.fromGraph(GraphDSL.create() { implicit b =>
  import GraphDSL.Implicits._

  val merge = b.add(Merge[Int](2))          //2 In 1 Out 
  val bcast = b.add(Broadcast[Int](2))      //1 In 2 Out 

  source ~> merge ~> Flow[Int].map { s => println(s); s} ~> bcast ~> Sink.ignore
            merge                    <~                     bcast
  ClosedShape
}).run()
//prints few numbers and then stops 
//number is fed into loop, causing cycle to grow
//eventually all of its internal buffers become full, backpressuring source forever. 
1

//Try-1: 
To be able to process more elements from source elements would need to leave the cycle somehow.

MergePreferred consumes from a preferred input port if there are elements available 
before trying the other lower priority input ports. 



//Example 
val source = Source(1 to 10)

// WARNING! The graph below stops consuming from "source" after a few steps and prints infinite 1,2 
//Uses KillSwitches to kill the stream , get KillSwitch instance as Mat value 
val gr = RunnableGraph.fromGraph(GraphDSL.create(KillSwitches.single[Int]/*Flow[Int,Int]*/) { implicit b => 
 kill =>
  import GraphDSL.Implicits._

  //MergePreferred(secondaryPorts: Int)
  val merge = b.add(MergePreferred[Int](1)) //2 In 1 Out , 1 is prefered , 1 is secondaryPort
  val bcast = b.add(Broadcast[Int](2))

  source ~> merge ~> Flow[Int].map { s => println(s); s } ~> kill ~> bcast ~> Sink.ignore
            merge.preferred              <~                          bcast
  ClosedShape
})

val killSwitch = gr.run();Thread.sleep(1000);killSwitch.shutdown()
//output 
//Here we have avoided the deadlock as printing infinite , 
//but source is still back-pressured forever so no new source element is put into the cycle 
1
2
1
2
1
2
....same repeatation

//OR 
val sink = Sink.fromGraph(GraphDSL.create(KillSwitches.single[Int]/*Flow[Int,Int]*/) { implicit b => kill =>
  import GraphDSL.Implicits._

  //MergePreferred(secondaryPorts: Int)
  val merge = b.add(MergePreferred[Int](1)) //2 In 1 Out , 1 is prefered , 1 is secondaryPort
  val bcast = b.add(Broadcast[Int](2))

  merge ~> Flow[Int].map { s => println(s); s } ~> kill ~> bcast ~> Sink.ignore
  merge.preferred              <~                  bcast
  SinkShape(merge.in(0))
})

val killSwitch = source.runWith(sink);Thread.sleep(1000);killSwitch.shutdown()
 
//Try2: 
To make our cycle both live (not deadlocking) and fair 
we can introduce a dropping element on the feedback arc. 
In this case we chose the buffer() operation giving it a dropping strategy OverflowStrategy.dropHead.

This example highlights that one solution to avoid deadlocks 
in the presence of potentially unbalanced cycles 
(cycles where the number of circulating elements are unbounded) is to drop elements. 

//Example 
val gr = RunnableGraph.fromGraph(GraphDSL.create(KillSwitches.single[Int]/*Flow[Int,Int]*/) { implicit b => kill =>
  import GraphDSL.Implicits._

  val merge = b.add(Merge[Int](2))
  val bcast = b.add(Broadcast[Int](2))

  source ~> merge ~> Flow[Int].map { s => println(s); s } ~> kill ~> bcast ~> Sink.ignore
            merge <~ Flow[Int].buffer(5, OverflowStrategy.dropHead) <~ bcast
  ClosedShape
})

val killSwitch = gr.run();Thread.sleep(1000);killSwitch.shutdown()
//Output - last bufferSize+1 number would  be printed repeatedly as initial values are dropped 
10
7
8
5
9
6
--Repeats infinite 

//Try-4:
The core problem was the unbalanced nature of the feedback loop. 
(cycles where the number of circulating elements are unbounded)

To build a cycle that is balanced(bounded no of circulating elements) from the beginning,
Replace the Merge junction with a ZipWith. 
ZipWith takes one element from source and other from the feedback arc to inject 
one element into the cycle, we maintain the balance of elements.

//Example - But no Output as ZipWidth waits for both inputs available to out one output 
val gr = RunnableGraph.fromGraph(GraphDSL.create(KillSwitches.single[Int]/*Flow[Int,Int]*/) { implicit b => kill =>
  import GraphDSL.Implicits._

  val zip = b.add(ZipWith[Int, Int, Int]((left, right) => left))
  val bcast = b.add(Broadcast[Int](2))

  source ~> zip.in0
               zip.out.map { s => println(s); s } ~> kill ~> bcast ~> Sink.ignore
            zip.in1             <~                           bcast
  ClosedShape
})

val killSwitch = gr.run();Thread.sleep(1000);killSwitch.shutdown()

//Try-5: 
The solution is to inject an initial element into the cycle that is independent from source. 
Use Concat (consumes first one fully, then consume other) with single element 

The important takeaway is that balanced cycles often need an initial 'kick-off' element 
to be injected into the cycle.

//Example 
val gr = RunnableGraph.fromGraph(GraphDSL.create(KillSwitches.single[Int]/*Flow[Int,Int]*/) { implicit b => kill =>
  import GraphDSL.Implicits._

  val zip = b.add(ZipWith[Int, Int, Int]((left, right) => left)) //2 In , 1 out 
  val bcast = b.add(Broadcast[Int](2)) // 1 In , 2 Out 
  //concatenates two streams (first consume one, then the second one)
  val concat = b.add(Concat[Int]())    //2 In , 1 out 
  val start = Source.single(0)

  source ~> zip.in0
              zip.out.map { s => println(s); s } ~> kill ~> bcast ~> Sink.ignore
            zip.in1 <~ concat <~ start
                       concat         <~                    bcast
  ClosedShape
})

val killSwitch = gr.run();Thread.sleep(1000);killSwitch.shutdown()




///Accessing the materialized value inside the Graph --ADVANCED
To Get the materialized value of a Graph (partial, closed or backing a Source, Sink, Flow or BidiFlow). 
Use builder.materializedValue which gives an Outlet .
All ports ops can be done on that outlet and then call .outlet to convert to Outlet 
    Builder[+M].materializedValue: Outlet[M] 
    implicit def port2flow[T](from: Outlet[T])(implicit b: Builder[_]): PortOps[T] 
    PortOps[T].outlet: Outlet[T] 

If the materialized value is needed at more than one place, 
call materializedValue any number of times to acquire the necessary number of outlets.

//Sink.fold[Int, Int](0)(_ + _)  //Sink[Int,Future[Int]], Single arg Mat is arg Mat, = Future[Int]]
//builder.materializedValue:Outlet[M].portOps.outlet to get Outlet[M] 
val foldFlow: Flow[Int, Int, Future[Int]] = Flow.fromGraph(GraphDSL.create(Sink.fold[Int, Int](0)(_ + _)) { implicit builder => 
fold =>
  import GraphDSL.Implicits._
  //FlowShape(in: Inlet[I], out: Outlet[O])  
  FlowShape(fold.in, builder.materializedValue.mapAsync(4)(identity).outlet) //just experimentation 
}) 

Be careful not to introduce a cycle 
where the materialized value actually contributes to the materialized value.

//WRONG - Example : where the materialized Future of a fold is fed back to the fold itself.

// This cannot produce any value:
val cyclicFold: Source[Int, Future[Int]] = Source.fromGraph(GraphDSL.create(Sink.fold[Int, Int](0)(_ + _)) { implicit builder => fold =>
  import GraphDSL.Implicits._
  // - Fold cannot complete until its upstream mapAsync completes
  // - mapAsync cannot complete until the materialized Future produced by fold completes
  // As a result this Source will never emit anything, and its materialited
  // Future will never complete
  builder.materializedValue.mapAsync(4)(identity) ~> fold
  SourceShape(builder.materializedValue.mapAsync(4)(identity).outlet)
})


///Operator Fusion and Async boundary  -- ADVANCED * 
By default Akka Streams will fuse the stream operators. Means 
1. passing elements from one processing stage to the next is a lot faster between fused stages 
   due to avoiding the asynchronous messaging overhead
   
2. fused stream processing stages does not run in parallel to each other, 
   meaning that only up to one CPU core is used for each fused part

To allow for parallel processing , insert asynchronous boundaries explicitly
(by Attributes.asyncBoundary using the method .async on Source, Sink and Flow)

//This async can be applied successively, always having one such boundary enclose the previous ones 
//plus all processing stages that have been added since them

Source(List(1, 2, 3))
  .map( x => {println(s"$x-${Thread.currentThread.getName}") ; x + 10})
  .map(x => {println(s"$x-${Thread.currentThread.getName}") ; x * 1})
  .to(Sink.ignore).run()
  
//1-TestSystem-akka.actor.default-dispatcher-52
//11-TestSystem-akka.actor.default-dispatcher-52
//2-TestSystem-akka.actor.default-dispatcher-52
//12-TestSystem-akka.actor.default-dispatcher-52
//3-TestSystem-akka.actor.default-dispatcher-52
//13-TestSystem-akka.actor.default-dispatcher-52

Source(List(1, 2, 3))
  .map( x => {println(s"$x-${Thread.currentThread.getName}") ; x + 10}).async      //-> by 1st Actor 
  .map(x => {println(s"$x-${Thread.currentThread.getName}") ; x * 1})      // 2nd actor takes up 
  .to(Sink.ignore).run()

//1-TestSystem-akka.actor.default-dispatcher-56
//2-TestSystem-akka.actor.default-dispatcher-56
//3-TestSystem-akka.actor.default-dispatcher-56
//11-TestSystem-akka.actor.default-dispatcher-55
//12-TestSystem-akka.actor.default-dispatcher-55
//13-TestSystem-akka.actor.default-dispatcher-55



///Buffers for asynchronous stages--ADVANCED *
To run a stage asynchronously , must Use  .async method. 

//example 
Source(1 to 3)
  .map { i => println(s"A: $i"); i }.async
  .map { i => println(s"B: $i"); i }.async
  .map { i => println(s"C: $i"); i }.async
  .runWith(Sink.ignore)
//OUTPUT , order is not A:1, B:1, C:1, A:2, B:2, C:2,...
A: 1
A: 2
B: 1
A: 3
B: 2
C: 1
B: 3
C: 2
C: 3

While pipelining in general increases throughput, 
in practice there is a cost of passing an element through the asynchronous 
(and therefore thread crossing) boundary which is significant. 

//Solution - Akka Streams uses a buffer for every asynchronous processing stage 
//and passes this buffer across thread boundary 
akka.stream.materializer.max-input-buffer-size = 16

//OR 
//If the buffer size needs to be set for segments of a Flow only, 
//it is possible by defining a separate Flow with these attributes:

// the buffer size of this map is 1
val section = Flow[Int].map(_ * 2).async.addAttributes(Attributes.inputBuffer(initial = 1, max = 1)) 

val flow = section.via(Flow[Int].map(_ / 2)).async // the buffer size of this map is the default
val runnableGraph =
  Source(1 to 10).via(flow).to(Sink.foreach(elem => println(elem)))

//Also can be defined for  full graph 
val withOverriddenDefaults = runnableGraph.withAttributes(Attributes.inputBuffer(initial = 64, max = 64))


///Understanding conflate - Fast producer , slow consumer --ADVANCED
def conflate[O2 >: Out](aggregate: (O2, O2) => O2): Repr[O2]
def conflateWithSeed[S](seed: (Out) => S)(aggregate: (S, Out) => S): Repr[S]
    S is initial state  

When a fast producer can not be informed to slow down by backpressure 
conflate might be useful to combine elements from a producer 
until a demand signal comes from a consumer.

//Example - summarizes fast stream of elements to a standard deviation, mean and count of elements 
//that have arrived while the stats have been calculated.
//scala.collection.immutable.Seq(_) = (x$1) => scala.collection.immutable.Seq(x$1))

val statsFlow = Flow[Double]
  .conflateWithSeed(Seq(_))(_ :+ _) //Creates a Seq of Double 
  .map { s =>  //Seq 
    val mu = s.sum / s.size
    val se = s.map(x => Math.pow(x - mu, 2))
    val sd = Math.sqrt(se.sum / se.size)
    (sd, mu, s.size)
  } //Flow[Double,(Double, Double, Int),akka.Notused]

//Another possible use of conflate is to not consider all elements for summary 
//when the producer starts getting too fast. 
//Example - conflate can be used to randomly drop elements 
//when the consumer is not able to keep up with the producer.
val p = 0.01
val sampleFlow = Flow[Double]
  .conflateWithSeed(Seq(_)) {
    case (acc, elem) if util.Random.nextDouble < p => acc :+ elem
    case (acc, _)                             => acc
  } //Flow[Double,Seq[Double],akka.NotUsed]
  .mapConcat(identity) //flatten inner Seq , Flow[Double,Double,akka.NotUsed]



///Understanding expand - Slow producer , Fast consumer --ADVANCED
def expand[U](extrapolate: (Out) => Iterator[U]): Repr[U]

Expand helps to deal with slow producers which are unable to keep up 
with the demand coming from consumers. 
Expand allows to extrapolate a value to be sent as an element to a consumer.

//Example - Flow sends the same element to consumer when producer does not send any new elements.
val lastFlow = Flow[Double]
  .expand(Iterator.continually(_))


//Expand also allows to keep some state between demand requests from the downstream. 
//Example - a flow that tracks and reports a drift between fast consumer and slow producer.
val driftFlow = Flow[Double]
      .expand(i => Iterator.from(0).map(i -> _))


      
      
      

///Akka Stream -  KIllSwitch --ADVANCED

//Controlling graph completion with KillSwitch
//A KillSwitch allows the completion of graphs of FlowShape from the outside
trait KillSwitch extends AnyRef
    def abort(ex: Throwable): Unit
    def shutdown(): Unit
        For normal completion 
class SharedKillSwitch extends KillSwitch 
     flow[T]: FLow[T,T, SharedKillSwitch]
object KillSwitches
	Creates shared or single kill switches which can be used 
    to control completion of graphs from the outside.
    def shared(name: String): SharedKillSwitch
        Creates a new SharedKillSwitch with the given name that can be used to control the completion 
        of multiple streams from the outside simultaneously.
    def single[T]: FLow[T, T,  UniqueKillSwitch]
        Creates a new Graph of FlowShape that materializes to an external switch 
        that allows external completion of that unique materialization.
    def singleBidi[T1, T2]: BidiFlow[T1, T1, T2, T2, UniqueKillSwitch]
        Creates a new Graph of FlowShape that materializes to an external switch 
        that allows external completion of that unique materialization.


//UniqueKillSwitch - KillSwitches.single
//UniqueKillSwitch allows to control the completion of one materialized Graph of FlowShape. 

def doSomethingElse() = { Thread.sleep(1000); () }

//shutdown 
//Note delay would delay whole chunk, not add delay to each element generated , for that use Source.tick
//delay(of: FiniteDuration, strategy: DelayOverflowStrategy = DelayOverflowStrategy.dropTail): Source[Out, Mat]
val countingSrc = Source(LazyList.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int] //Future[Int]

val (killSwitch, last) = countingSrc
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(lastSnk)(Keep.both)
  .run()

doSomethingElse()

killSwitch.shutdown()

import system.dispatcher
last.foreach(println)  //last value 

//Abort
val countingSrc = Source(LazyList.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int]

val (killSwitch, last) = countingSrc
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(lastSnk)(Keep.both).run()

val error = new RuntimeException("boom!")
killSwitch.abort(error)

import system.dispatcher
last.failed.foreach(println)



//SharedKillSwitch - KillSwitches.shared
//A SharedKillSwitch allows to control the completion of an arbitrary number graphs of FlowShape. 
//It can be materialized multiple times via its flow method, 
//and all materialized graphs linked to it are controlled by the switch

//Shutdown
val countingSrc = Source(LazyList.from(1)).delay(1.second, DelayOverflowStrategy.backpressure)
val lastSnk = Sink.last[Int]
val sharedKillSwitch = KillSwitches.shared("my-kill-switch")

val last = countingSrc
  .via(sharedKillSwitch.flow)
  .runWith(lastSnk)

val delayedLast = countingSrc
  .delay(1.second, DelayOverflowStrategy.backpressure)
  .via(sharedKillSwitch.flow)
  .runWith(lastSnk)

doSomethingElse()

sharedKillSwitch.shutdown()

import system.dispatcher
last.foreach(println)
delayedLast.foreach(println)


//Abort
val countingSrc = Source(Stream.LazyList(1)).delay(1.second)
val lastSnk = Sink.last[Int]
val sharedKillSwitch = KillSwitches.shared("my-kill-switch")

val last1 = countingSrc.via(sharedKillSwitch.flow).runWith(lastSnk)
val last2 = countingSrc.via(sharedKillSwitch.flow).runWith(lastSnk)

val error = new RuntimeException("boom!")
sharedKillSwitch.abort(error)

import system.dispatcher
last1.failed.foreach(println)
last2.failed.foreach(println)


///Logging errors --ADVANCED
Log can log elements flowing through the stream as well as completion and erroring. 

Source[In,Mat]/Flow[In,Out,Mat]
    log(name: String, extract: (Out) => Any = ConstantFun.scalaIdentityFunction)(implicit log: LoggingAdapter = null): Repr[Out]
    

//Example 
Source(-5 to 5)
  .map(1 / _)               //throwing ArithmeticException: / by zero
  .log("error logging")     //logs only if there is an error 
  .runWith(Sink.ignore)
  
//output 
[TestSystem-akka.actor.default-dispatcher-67] ERROR akka.stream.Materiaizer - [error logging] Upstream failed.
java.lang.ArithmeticException: / by zero
       at $line81.$read$$iw.$anonfun$res45$1(<console>:1)
  
//details 
By default element and completion signals are logged on debug level, 
and errors are logged on Error level. (Note default akka.loglevel = "INFO" 
so debug would not be printed)

OR Use below 
Attributes.logLevels(onElement: LogLevel = Logging.DebugLevel, 
    onFinish: LogLevel = Logging.DebugLevel, 
    onFailure: LogLevel = Logging.ErrorLevel): Attributes
 
This can be changed by calling Attributes.logLevels(...) 
You can use any of below options 

akka.event.Logging
    val DebugLevel: LogLevel
    val ErrorLevel: LogLevel
    val InfoLevel: LogLevel
    val WarningLevel: LogLevel
OR 
akka.stream.Attributes.LogLevels
    val Debug: LogLevel  //debug would encompass all , given in hierarchy
    val Info: LogLevel   
    val Warning: LogLevel 
    val Error: LogLevel
    val Off: LogLevel

//example 
import akka.stream.Attributes

Source(-5 to 5)
  .map(x => x)
.log(name = "myStream")
.addAttributes(
  Attributes.logLevels(
    onElement = Attributes.LogLevels.Info,  
    onFinish = Attributes.LogLevels.Info,
    onFailure = Attributes.LogLevels.Error))
.runWith(Sink.ignore)
//output 
...
[TestSystem-akka.actor.default-dispatcher-75] INFO akka.stream.Materializer -[myStream] Element: 5
[TestSystem-akka.actor.default-dispatcher-75] INFO akka.stream.Materializer -[myStream] Upstream finished.


//Check default value of Config file 
import com.typesafe.config._

val config = ConfigFactory.load()  //or fileName 
config.getString("akka.loglevel")  //INFO 
//OR 
val akka = config.getConfig("akka")
akka.getString("loglevel")

  
///Error Handling in Streams - Recover/With Retries    -- ADVANCED  
To avoid complete stream failure, this can be done in a few different ways:

1. recover to emit a final element then complete the stream normally on upstream failure
    Source[In,Mat]/Flow[In,Out,Mat].recover[T >: Out](pf: PartialFunction[Throwable, T]): Repr[T]
   
2. recoverWithRetries to create a new upstream, Source[T,Mat] 
   and start consuming from that on failure
    Source[In,Mat]/Flow[In,Out,Mat].recoverWithRetries[T >: Out](attempts: Int, 
        pf: PartialFunction[Throwable, Source[T , NotUsed]]): Repr[T]
        
3. Restarting sections of the stream after a backoff
4. Using a supervision strategy for stages that support it
5. a common pattern is to wrap the stream inside an actor, 
   and have the actor restart the entire stream on failure.
  
//Recover Example 
//recover[T >: Out](pf: PartialFunction[Throwable, T]): Repr[T]
Source(0 to 6).map(n =>
  if (n < 5) n.toString
  else throw new RuntimeException("Boom!")  
).recover {
  case _: RuntimeException => "stream truncated"
}.runForeach(println)

//This will output:
0
1
2
3
4
stream truncated


//Example -Recover with retries
//recoverWithRetries[T >: Out](attempts: Int,  pf: PartialFunction[Throwable, Source[T , NotUsed]]): Repr[T]

val planB = Source(List("five", "six", "seven", "eight"))

Source(0 to 10).map(n =>
  if (n < 5) n.toString
  else throw new RuntimeException("Boom!")
).recoverWithRetries(attempts = 1, {
  case _: RuntimeException => planB
}).runForeach(println)

//This will output:
0
1
2
3
4
five
six
seven
eight



///Error Handling in Streams - Delayed restarts with a backoff stage --ADVANCED

object akka.stream.scaladsl.RestartSource
    def onFailuresWithBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(sourceFactory: () => Source[T, _]): Source[T, NotUsed]
    def onFailuresWithBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(sourceFactory: () => Source[T, _]): Source[T, NotUsed]
        Restart happens only when stream fails  
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(sourceFactory: () => Source[T, _]): Source[T, NotUsed]
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(sourceFactory: () => Source[T, _]): Source[T, NotUsed]
        Restarts happen for  both failure and completion 
        Restarts with  increasing intervals of minBackoff, 2*minBackoff, ... maxBackoff parameter
        (actually some jitter of randomFactor is added)
        maxRestarts
            the amount of restarts is capped to this amount within a time frame of maxBackoff. 
            Passing 0 will cause no restarts 
            and a negative number will not cap the amount of restarts(default when not given).
        The returned Source will not emit a complete or failure 
        as long as maxRestarts(default Infinite) is not reached, 
        since the completion or failure of the wrapped Source is handled by restarting it. 
        The wrapped Source can however be cancelled (without restarting) by cancelling the returned Source. 
        This can be triggered simply by the downstream cancelling, 
        or externally by introducing a KillSwitch right after the returned Source
        
object akka.stream.scaladsl.RestartSink 
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(sinkFactory: () => Sink[T, _]): Sink[T, NotUsed]
    def withBackoff[T](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(sinkFactory: () => Sink[T, _]): Sink[T, NotUsed]

object akka.stream.scaladsl.RestartFlow
    def onFailuresWithBackoff[In, Out](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(flowFactory: () => Flow[In, Out, _]): Flow[In, Out, NotUsed]
    def withBackoff[In, Out](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double, maxRestarts: Int)(flowFactory: () => Flow[In, Out, _]): Flow[In, Out, NotUsed]
    def withBackoff[In, Out](minBackoff: FiniteDuration, maxBackoff: FiniteDuration, randomFactor: Double)(flowFactory: () => Flow[In, Out, _]): Flow[In, Out, NotUsed]
         
//Example 
import system.dispatcher

// Mock akka-http interfaces
object Http {
    def apply() = this
    def singleRequest(req: HttpRequest) = Future.successful("Hello from Result")
}
case class HttpRequest(uri: String)
case class Unmarshal(b: Any) {
    def to[T]: Future[T] = Promise[T]().future
}
case class ServerSentEvent()

//withBackoff[T](...)(sourceFactory: () => Source[T, _]): Source[T, NotUsed]
val restartSource = RestartSource.withBackoff(
  minBackoff = 1.seconds,   //first restart 3 secs , then 6 secs ... till max 30 secs 
  maxBackoff = 30.seconds,
  randomFactor = 0.2,       // adds 20% "noise" to vary the intervals slightly
  maxRestarts = 20          // limits the amount of restarts to 20
) { () =>
  // Create a source from a future of a source
  //futureSource[T, M](futureSource: Future[Source[T, M]]): Source[T, Future[M]]
  Source.futureSource {
    // Make a single request with akka-http
    Http().singleRequest(HttpRequest(
      uri = "http://example.com/eventstream"
    )) /*Future[T]*/
      // Unmarshall it as a source of server sent events
      .flatMap(Unmarshal(_).to[Source[ServerSentEvent, NotUsed]])
  }
}

//The above RestartSource will never terminate unless the Sink it’s fed into cancels. 
// use it in combination with a KillSwitch, so that you can terminate it when needed:
val killSwitch = restartSource
  .viaMat(KillSwitches.single)(Keep.right)
  .toMat(Sink.foreach(event => println(s"Got event: $event")))(Keep.left)
  .run()

//doSomethingElse()

Thread.sleep(5*1000);killSwitch.shutdown()



///Error Handling in Streams - Supervision Strategies --ADVANCED
The stages that support supervision strategies are explicitly documented to do so,
if there is nothing in the documentation of a stage saying that it adheres to the supervision strategy 
it means it fails rather than applies supervision.

There are three ways to handle exceptions from application code:
    Stop 
        The stream is completed with failure.
    Resume 
        The element is dropped and the stream continues.
    Restart 
        The element is dropped and the stream continues after restarting the stage. 
        Restarting a stage means that any accumulated state is cleared. 
        This is typically performed by creating a new instance of the stage.

//By default the stopping strategy is used for all exceptions, 
//i.e. the stream will be completed with failure when an exception is thrown.

val source = Source(0 to 5).map(100 / _)
val result = source.runWith(Sink.fold(0)(_ + _))
// division by zero will fail the stream and the
// result here will be a Future completed with Failure(ArithmeticException)



//The default supervision strategy for a stream can be defined on the settings of the materializer.
val decider: Supervision.Decider = {
  case _: ArithmeticException => Supervision.Resume
  case _                      => Supervision.Stop
}
val source = Source(0 to 5).map(100 / _)
val runnableGraph =
  source.toMat(Sink.fold(0)(_ + _))(Keep.right)

val withCustomSupervision = runnableGraph.withAttributes(ActorAttributes.supervisionStrategy(decider))

val result = withCustomSupervision.run()
// the element causing division by zero will be dropped
// result here will be a Future completed with Success(228)



//The supervision strategy can also be defined for all operators of a flow.
val decider: Supervision.Decider = {
  case _: ArithmeticException => Supervision.Resume
  case _                      => Supervision.Stop
}
val flow = Flow[Int]
  .filter( x => (100 / x) < 50)
  .map(elem => 100 / (5 - elem))
  .withAttributes(ActorAttributes.supervisionStrategy(decider))
  
val source = Source(0 to 5).via(flow)

val result = source.runWith(Sink.fold(0)(_ + _))
// the elements causing division by zero will be dropped
// result here will be a Future completed with Success(150)

//Restart vs Resume 
Restart works in a similar way as Resume with the addition that accumulated state, 
if any, of the failing processing operator will be reset.

val decider: Supervision.Decider = {
  case _: IllegalArgumentException => Supervision.Restart
  case _                           => Supervision.Stop
}
val flow = Flow[Int]
  .scan(0) { (acc, elem) =>
    if (elem < 0) throw new IllegalArgumentException("negative not allowed")
    else acc + elem
  }
  .withAttributes(ActorAttributes.supervisionStrategy(decider))
val source = Source(List(1, 3, -1, 5, 7)).via(flow)
val result = source.limit(1000).runWith(Sink.seq)
// the negative element cause the scan stage to be restarted,
// i.e. start from 0 again
// result here will be a Future completed with Success(Vector(0, 1, 4, 0, 5, 12))


///Bidirectional Flows --ADVANCED
https://doc.akka.io/api/akka/current/akka/stream/scaladsl/BidiFlow$.html

A graph topology that is often useful is that of two flows going in opposite directions. 

Take for example a codec operator that serializes outgoing messages 
and deserializes incoming octet streams.

A bidirectional flow of elements that consequently has two inputs and two outputs, 
arranged like this:

       +------+
 In1 ~>|      |~> Out1
       | bidi |
Out2 <~|      |<~ In2
       +------+

final class BidiFlow[-I1, +O1, -I2, +O2, +Mat] extends Graph[BidiShape[I1, O1, I2, O2], Mat]
final case class BidiShape[-In1, +Out1, -In2, +Out2](in1: Inlet[In1], out1: Outlet[Out1], 
    in2: Inlet[In2], out2: Outlet[Out2]) extends Shape

//Few Methods BidiFlow[-I1, +O1, -I2, +O2, +Mat]
def atop[OO1, II2, Mat2](bidi: BidiFlow[O1, OO1, II2, I2, Mat2]): BidiFlow[I1, OO1, II2, O2, Mat]
def atopMat[OO1, II2, Mat2, M](bidi:  BidiFlow[O1, OO1, II2, I2, Mat2])(combine: (Mat, Mat2) => M): BidiFlow[I1, OO1, II2, O2, M]
    Add the given BidiFlow as the next step in a bidirectional transformation pipeline. 
    By convention protocol stacks are growing from left to right: the right most is the bottom layer
        +----------------------------+
        | Resulting BidiFlow         |
        |                            |
        |  +------+        +------+  |
    I1 ~~> |      |  ~O1~> |      | ~~> OO1
        |  | this |        | bidi |  |
    O2 <~~ |      | <~I2~  |      | <~~ II2
        |  +------+        +------+  |
        +----------------------------+

def join[Mat2](flow: Flow[O1, I2, Mat2]): Flow[I1, O2, Mat]
def joinMat[Mat2, M](flow: Flow[O1, I2, Mat2])(combine: (Mat, Mat2) => M): Flow[I1, O2, M]
    Add the given Flow as the final step in a bidirectional transformation pipeline. 
        +---------------------------+
        | Resulting Flow            |
        |                           |
        |  +------+        +------+ |
    I1 ~~> |      |  ~O1~> |      | |
        |  | this |        | flow | |
    O2 <~~ |      | <~I2~  |      | |
        |  +------+        +------+ |
        +---------------------------+

def reversed: BidiFlow[I2, O2, I1, O1, Mat]
    Turn this BidiFlow around by 180 degrees, 
    logically flipping it upside down in a protocol stack.
    ie bottom stream becomes top stream eg 
    instance = BidiFlow[-I1, +O1, -I2, +O2, +Mat]
    result   = BidiFlow[I2, O2, I1, O1, Mat]
    

//Flow[-In, +Out, +Mat] Methods 
def join[Mat2](flow: Flow[Out, In, Mat2]): RunnableGraph[Mat]
def joinMat[Mat2, Mat3](flow: Flow[Out, In, Mat2])(combine: (Mat, Mat2) => Mat3): RunnableGraph[Mat3]
    Join this Flow to another Flow, by cross connecting the inputs and outputs, creating a RunnableGraph.
    +------+        +-------+
    |      | ~Out~> |       |
    | this |        | other |
    |      | <~In~  |       |
    +------+        +-------+

def joinMat[I2, O1, Mat2, M](bidi: BidiFlow[Out, O1, I2, In, Mat2])(combine: (Mat, Mat2) => M): Flow[I2, O1, M]
    Join this Flow to a BidiFlow to close off the 'top' of the protocol stack:
    +---------------------------+
    | Resulting Flow            |
    |                           |
    | +------+        +------+  |
    | |      | ~Out~> |      | ~~> O1
    | | flow |        | bidi |  |
    | |      | <~In~  |      | <~~ I2
    | +------+        +------+  |
    +---------------------------+


//Example 
import java.nio.ByteOrder

trait Message
case class Ping(id: Int) extends Message
case class Pong(id: Int) extends Message

def toBytes(msg: Message): ByteString = {
  implicit val order = ByteOrder.LITTLE_ENDIAN
  msg match {
    case Ping(id) => ByteString.newBuilder.putByte(1).putInt(id).result() //1 for Ping 
    case Pong(id) => ByteString.newBuilder.putByte(2).putInt(id).result() // 2 for Pong 
  }
}

def fromBytes(bytes: ByteString): Message = {
  implicit val order = ByteOrder.LITTLE_ENDIAN
  val it = bytes.iterator
  it.getByte match {
    case 1     => Ping(it.getInt)
    case 2     => Pong(it.getInt)
    case other => throw new RuntimeException(s"parse error: expected 1|2 got $other")
  }
}

val codecVerbose = BidiFlow.fromGraph(GraphDSL.create() { b =>
  // construct and add the top flow, going outbound
  val outbound = b.add(Flow[Message].map(toBytes))
  // construct and add the bottom flow, going inbound
  val inbound = b.add(Flow[ByteString].map(fromBytes))
  // fuse them together into a BidiShape
  //fromFlows[I1, O1, I2, O2](top: FlowShape[I1, O1], bottom: FlowShape[I2, O2]): BidiShape[I1, O1, I2, O2]
  BidiShape.fromFlows(outbound, inbound)
})
//BidiFlow[Message,ByteString,ByteString,Message,akka.NotUsed] 

//OR 
//fromFlows[I1, O1, I2, O2, M1, M2](flow1: Flow[I1, O1, M1], flow2: Flow[I2, O2, M2]): BidiFlow[I1, O1, I2, O2, NotUsed]
//fromFlowsMat[I1, O1, I2, O2, M1, M2, M](flow1: Flow[I1, O1, M1], flow2: Flow[I2, O2, M2])(combine: (M1, M2) => M): BidiFlow[I1, O1, I2, O2, M]
BidiFlow.fromFlows(Flow[Message].map(toBytes), Flow[ByteString].map(fromBytes))
//BidiFlow[Message,ByteString,ByteString,Message,akka.NotUsed] 

// OR 
// fromFunctions[I1, O1, I2, O2](outbound: (I1) => O1, inbound: (I2) => O2): BidiFlow[I1, O1, I2, O2, NotUsed]
val codec = BidiFlow.fromFunctions(toBytes _, fromBytes _)
//BidiFlow[Message,ByteString,ByteString,Message,akka.NotUsed] 

//Results 
           +------+
 Message ~>|      |~> ByteString
           | bidi |
Message  <~|      |<~ ByteString
           +------+

//Then Add Frame 
trait Frame
case class Input(bytes: ByteString) extends Frame


val framing = BidiFlow.fromGraph(GraphDSL.create() { b =>
  implicit val order = ByteOrder.LITTLE_ENDIAN

  def createInput(bytes: ByteString) = {
    //do other processing 
    Input(bytes)
  }
  def fromInput(in:Input):ByteString = {
    //do other processing 
    in.bytes
  }

  val outbound = b.add(Flow[ByteString].map(createInput))
  val inbound = b.add(Flow[Input].map(fromInput))
  BidiShape.fromFlows(outbound, inbound)
})
//BidiFlow[ByteString,Input,Input,ByteString,akka.NotUsed] 


/* construct protocol stack
 *         +------------------------------------+
 *         | stack                              |
 *         |                                    |
 *         |  +-------+            +---------+  |
 *    ~>   O~~o       |     ~>     |         o~~O    ~>
 * Message |  | codec | ByteString | framing |  | Input
 *    <~   O~~o       |     <~     |         o~~O    <~
 *         |  +-------+            +---------+  |
 *         +------------------------------------+
 */
 
//BidiFlow[-I1, +O1, -I2, +O2, +Mat].atop[OO1, II2, Mat2](bidi: BidiFlow[O1, OO1, II2, I2, Mat2]): BidiFlow[I1, OO1, II2, O2, Mat]
val stack = codec.atop(framing)  
//BidiFlow[Message,Input,Input,Message,akka.NotUsed]

// test it by plugging it into its own inverse and closing the right end
//BidiFlow[-I1, +O1, -I2, +O2, +Mat].reversed: BidiFlow[I2, O2, I1, O1, Mat]
val stackr = stack.reversed
//BidiFlow[Input,Message,Message,Input,NotUsed

//Flow[-In, +Out, +Mat].collect[T](pf: PartialFunction[Out, T]): Flow[In, T, Mat]
val pingpong = Flow[Message].collect { case Ping(id) => Pong(id) : Message }
//Flow[Message,Message,akka.NotUsed]


//BidiFlow[-I1, +O1, -I2, +O2, +Mat].join[Mat2](flow: Flow[O1, I2, Mat2]): Flow[I1, O2, Mat]
val flow = stack.atop(stackr)/*BidiFlow[Message,Message,Message,Message,NotUsed]*/.join(pingpong)
//Flow[Message,Message,akka.NotUsed]

            <---------  Flow ----------->
              +------+             +------+ 
Message  ~~>  |      |  ~Message~> |      | 
              | bidi |             |  pp  | 
Message  <~~  |      | <~Message~  |      | 
              +------+             +------+ 

val result = Source((0 to 9).map(Ping)).via(flow).limit(20).runWith(Sink.seq)
//Future[Seq[Message]]
Await.result(result, 1.second) 
//((0 to 9).map(Pong))


///Dynamic fan-in and fan-out with MergeHub, BroadcastHub and PartitionHub --ADVANCED
There are many cases when consumers or producers of a certain service 
(represented as a Sink, Source, or possibly Flow) are dynamic and not known in advance. 

The Graph DSL does not allow to represent this, 
all connections of the graph must be known in advance and must be connected upfront. 

//Using the MergeHub -  dynamic fan-in -  N Source/inputs/producer, 1 Sink/output/consumer 
trait DrainingControl
    def drainAndComplete(): Unit
        Set the operation mode of the linked MergeHub to draining. 
        In this mode the Hub will cancel any new producer and will complete as soon as 
        all the currently connected producers complete.

object MergeHub
    Collect streamed elements  from a dynamic set of producers. 
    It consists of two parts, a Source and a Sink. 
        Connect External_consumer[T] <~ MergeHub.source[T]
        Materializes above to get Sink[T,NotUsed] or (Sink[T, NotUsed], DrainingControl)
        Connect N external_producers/source ~> above_sink 
    Create MergeHub_Source from below and them materialize to get BroadcastHub_Sink
        def source[T]: Source[T, Sink[T, NotUsed]]
        def source[T](perProducerBufferSize: Int): Source[T, Sink[T, NotUsed]]
        def sourceWithDraining[T](): Source[T, (Sink[T, NotUsed], DrainingControl)]
        def sourceWithDraining[T](perProducerBufferSize: Int): Source[T, (Sink[T, NotUsed], DrainingControl)]
  

//Example 
val consumer = Sink.foreach(println)

//Connect External_consumer[T] <~ MergeHub.source[T]
val runnableGraph: RunnableGraph[Sink[String, NotUsed]] =
  MergeHub.source[String](perProducerBufferSize = 16).to(consumer)

//Materializes above to get Sink[T,NotUsed]
val toConsumer: Sink[String, NotUsed] = runnableGraph.run()

//Connect N external_procucers/source ~> above_sink 
Source.single("Hello!").runWith(toConsumer)
Source.single("Hub!").runWith(toConsumer)

//Using the BroadcastHub -  dynamic fan-out -  1 Source/Input/producer , N Sink/outputs/consumer,
The rate of the producer will be automatically adapted to the slowest consumer. 

object BroadcastHub
    Broadcasts streamed elements to a dynamic set of consumers. 
    It consists of two parts, a Source and a Sink. 
        Connect External_producer[T] ~> MergeHub.sink[T]
        Materializes above to get Source[T,NotUsed] 
        Connect N external_consumer/sink <~ above_Source 
    Create BroadcastHub_Sink from below 
        def sink[T]: Sink[T, Source[T, NotUsed]]
        def sink[T](bufferSize: Int): Sink[T, Source[T, NotUsed]]
            If this buffer is full, the producer is backpressured. 
            Must be a power of two and less than 4096.

//Example 
val producer = Source.tick(1.second, 1.second, "New message")

//Connect External_producer[T] ~> MergeHub.sink[T]
val runnableGraph: RunnableGraph[Source[String, NotUsed]] =
  producer.toMat(BroadcastHub.sink(bufferSize = 256))(Keep.right)

//Materializes above to get Source[T,NotUsed] 
val fromProducer: Source[String, NotUsed] = runnableGraph.run()

//Connect N external_consumer/sink <~ above_Source 
fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.runForeach(msg => println("consumer2: " + msg))


//Using the PartitionHub  dynamic fan-out -  1 Source/Input/producer , N Sink/outputs/consumer,
PartitionHub
    Route streamed elements to a dynamic set of consumers. 
    The selection of consumer is done with a function and one consumer gets the element 
    The rate of the producer will be automatically adapted to the slowest consumer.
    It consists of two parts, a Source and a Sink. 
        Connect External_producer[T] ~> PartitionHub.sink[T]
        Materializes above to get Source[T,NotUsed] 
        Connect N external_consumer/sink <~ above_Source 
    //Create PartitionHub_Sink from below 
    def sink[T](partitioner: (Int, T) => Int, startAfterNrOfConsumers: Int, bufferSize: Int = defaultBufferSize): Sink[T, Source[T, NotUsed]]
            The function takes two parameters; 
            the first is the number of active consumers 
            and the second is the stream element. 
            The function should return the index of the selected consumer for the given element
    def statefulSink[T](partitioner: () => (ConsumerInfo, T) => Long, startAfterNrOfConsumers: Int, bufferSize: Int = defaultBufferSize): Sink[T, Source[T, NotUsed]]
        ConsumerInfo 
            def consumerIdByIdx(idx: Int): Long
                Obtain consumer identifier by index
            def consumerIds: IndexedSeq[Long]
                Sequence of all identifiers of current consumers.
            def getConsumerIds: List[Long]
                Sequence of all identifiers of current consumers.
            def queueSize(consumerId: Long): Int
                Approximate number of buffered elements for a consumer.
            def size: Int
                Number of attached consumers.



//Example 
val producer = Source.tick(1.second, 1.second, "message").zipWith(Source(1 to 100))((a, b) => s"$a-$b")

// Connect External_producer[T] ~> PartitionHub.sink[T]
val runnableGraph: RunnableGraph[Source[String, NotUsed]] =
  producer.toMat(
    PartitionHub.sink(
      (size, elem) => math.abs(elem.hashCode % size),
      startAfterNrOfConsumers = 2,
      bufferSize = 256))(Keep.right)

//Materializes above to get Source[T,NotUsed] 
val fromProducer: Source[String, NotUsed] = runnableGraph.run()

//Connect N external_consumer/sink <~ above_Source
fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.runForeach(msg => println("consumer2: " + msg))




//Another Example of PartitionHub using statefulSink

val producer = Source.tick(1.second, 1.second, "message").zipWith(Source(1 to 100))((a, b) => s"$a-$b")

// Connect External_producer[T] ~> PartitionHub.sink[T]
def roundRobin(): (PartitionHub.ConsumerInfo, String) => Long = {
  var i = -1L

  (info, elem) => {
    i += 1
    info.consumerIdByIdx((i % info.size).toInt)
  }
}

val runnableGraph: RunnableGraph[Source[String, NotUsed]] =
  producer.toMat(PartitionHub.statefulSink(() => roundRobin(), startAfterNrOfConsumers = 2, bufferSize = 256))(
    Keep.right)

//Materializes above to get Source[T,NotUsed] 
val fromProducer: Source[String, NotUsed] = runnableGraph.run()

//Connect N external_consumer/sink <~ above_Source
fromProducer.runForeach(msg => println("consumer1: " + msg))
fromProducer.runForeach(msg => println("consumer2: " + msg))


///Akka Stream: Custom processing with GraphStage --ADVANCED

Source[T]  , out:Outlet[T] ----> in:Inlet[T], Sink[T]

0) Sink installs InHandler by setHandler(in:Intlet[T], InHandler)
   Source installs OutHandler by setHandler(out:Outlet[T], OutHandler)

1) Sink side has in:Inlet[T]
    At first,  
    Sink[T] calls initial pull(in:Intlet[T]) to requests one T from in:Intlet[T]
    
2) Source[T] side has out:Outlet[T]
    OutHandler.onPull() of out:Outlet[T] is called in response to step 1)
    Inside onPull(), 
        user calls push(out, T) to push one T 
        
3) Sink side 
    InHandler.onPush() of in:Inlet[T] is called in response to Step 2)
    Inside onPush(), 
        user calls grab(in): to get element:T (optional)
        but must call pull(in:Intlet[T]) to request next element and to move to step 2

4) Source calls complete(out)/fail(out,ex) to complete/fail the Stream 
   Sink side, InHandler.onUpstreamFailure(ex)/InHandler.onUpstreamFinish()
   can be overridden to know when Source has called  fail(out,ex)/complete(out)
   
   OR Sink calls  cancel(in, ex)/cancel(in) to fail/cancel the Stream
   Source side , OutHandler.onDownstreamFinish can be overridden to know 
   when Sink has called    cancel(in, ex)/cancel(in)
   
5) Source/Sink can call isAvailable(out)/isAvailable(in) to 
   know whether push(out,e) or  grab(in,e) can be called or not 
        
6) Source/Sink can call isClosed(out)/isClosed(in) to 
   know whether out /in is closed 

7) Sink calls hasBeenPulled(in) to know whether pull(in) has been already called or not    

General Steps :
    Note all these logics are written inside constructor of GraphStageLogic(shape)
    ( pull/push/grab etc are available on GraphStageLogic)
    which is inside createLogic(inheritedAttributes) 
    of custom class extending from GraphStage[Shape[T]]
    Other few important methods of GraphStageLogic are
        cancelStage(ex)/completeStage()/failStage(ex)
            to cancel/complete/fail complete all ports of the operator 
        Also has few callbacks 
            def postStop(): Unit
                invoked when operator is about to stop or fail.
            def preStart(): Unit
                invoked at the startup of the operator.
   
   
//Output port for Custom Source
Output port ie SourceShape[Out] via out:Outlet[Out]

Following operations are available on an output port:
    push[T](out: Outlet[T], elem: T): Unit
        pushes an element to the output port. 
    complete[T](out: Outlet[T]): Unit 
        closes the output port normally.
    fail[T](out: Outlet[T], ex: Throwable): Unit
        closes the port with a failure signal.
    isAvailable[T](out: Outlet[T]): Boolean
        returns true if the port can be pushed
    isClosed[T](out: Outlet[T]): Boolean
        returns true if the port is closed. 

Install handler by  
    setHandler(out: Outlet[_], handler: OutHandler): Unit
    OutHandler has following methods 
        abstract def onPull(): Unit
            is called when the output port can emit the next element,
            call push(out, elem)  on this port.
        def onDownstreamFinish(cause: Throwable): Unit
            is called once the downstream has cancelled and 
            no longer allows messages to be pushed to it. 
            No more onPull() will arrive after this event. 
            If not overridden this will default to stopping the operator.
            
//State Machine 
https://doc.akka.io/docs/akka/current/images/outport_transitions.png

PULLED                  -- push(elem) -> PUSHED (initial_state)
(isAvailable == true)  <-  onPull() --

PULLED/PUSHED -- complete()/fail(ex)/onDownstreamFinish() --> CLOSED (isClosed == true)

(initial state , PUSHED -> Calls onPull() -> Moves to PULLED -> call now push(out, elem) ->PUSHED)
(or at any state, call complete()/fail(ex)/onDownstreamFinish() , then Outlet is closed)


//Example 
import akka.stream._
import akka.stream.stage._


class NumbersSource extends GraphStage[SourceShape[Int]] {
  val out: Outlet[Int] = Outlet("NumbersSource")
  
  override val shape: SourceShape[Int] = SourceShape(out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      // All state MUST be inside the GraphStageLogic,
      // never inside the enclosing GraphStage.
      private var counter = 1

      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          push(out, counter)
          counter += 1
        }
      })
    }
}

//Usage 
val mySource: Source[Int, NotUsed] = Source.fromGraph(new NumbersSource)

mySource.take(10).runForeach(println)  //1 to 10 
// Returns 55
val result1: Future[Int] = mySource.take(10).runFold(0)(_ + _)
// The source is reusable. This returns 5050
val result2: Future[Int] = mySource.take(100).runFold(0)(_ + _)

import system.dispatcher
Await.result(result2, Duration.Inf)


//Input port for Custom Sink 
Input port, SinkShap[In] from in:Inlet[In]

The following operations are available for input ports:
    def pull[T](in: Inlet[T]): Unit
        requests a new element from an input port. 
    def grab[T](in: Inlet[T]): T
        acquires the element that has been received during an onPush(). 
        It cannot be called again until the port is pushed again by the upstream.
    def cancel[T](in: Inlet[T], cause: Throwable): Unit
    def cancel[T](in: Inlet[T]): Unit 
        closes the input port.
    def isAvailable[T](in: Inlet[T]): Boolean
        returns true if the port can be grabbed.
    def hasBeenPulled[T](in: Inlet[T]): Boolean
        returns true if the port has been already pulled. 
    def isClosed[T](in: Inlet[T]): Boolean
        returns true if the port is closed. 

Set handler by  
    def setHandler(in: Inlet[_], handler: InHandler): Unit
    This InHandler has three callbacks
    abstract def onPush(): Unit
        is called when the input port has now a new element. 
        Get the element by grab(in) 
        and then call pull(in) on the port to request the next element. 
        It is not mandatory to grab the element, but then it drops the buffered element.
    def onUpstreamFailure(ex: Throwable): Unit
        is called if the upstream failed with an exception 
        and no longer can be pulled for new elements. 
        No more onPush() will arrive after this event. 
        If not overridden this will default to failing the operator.
    def onUpstreamFinish(): Unit
        is called once the upstream has completed 
        and no longer can be  pulled for new elements. 
        No more onPush() will arrive after this event. 
        If not overridden this will default to stopping the operator.

//State Machine 
https://doc.akka.io/docs/akka/current/images/inport_transitions.png
PUSHED              -- grab() -->   PUSHED_EMPTY(initial_state)
(isAvailable)                       |
                                    pull()
                                    |
                                    v
                    -- pull() --> PULLED 
                                 (hasBeenPulled)
                    <-- onPush() -- 
        
                    -- cancel()/onUpstreamFailure()/onUpstreamFinish() --> CLOSED

CLOSED      -- grab() -->  CLOSED_EMPTY

PUSHED_EMPTY/PULLED -- cancel()/onUpstreamFailure()/onUpstreamFinish() --> CLOSED_EMPTY (end_state)



//Example of stdout 
//(Usual path = preStart(call pull()), onPush( grab() and pull() for next element or cancel())
import akka.stream._
import akka.stream.stage._

class StdoutSink extends GraphStage[SinkShape[Int]] {
  val in: Inlet[Int] = Inlet("StdoutSink")
  override val shape: SinkShape[Int] = SinkShape(in)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      override def preStart(): Unit = pull(in)
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          println(grab(in))
          pull(in)
        }
      })
    }
}

Source.fromGraph(new NumbersSource).take(10).to(Sink.fromGraph(new StdoutSink)).run()


//Alternate API - Emit 
Never call setHandler while they are running emit or read

Source or out:Outlet Side 
    def emit[T](out: Outlet[T], elem: T): Unit
    def emit[T](out: Outlet[T], elem: T, andThen: () => Unit): Unit
    def emitMultiple[T](out: Outlet[T], elems: Iterator[T]): Unit
    def emitMultiple[T](out: Outlet[T], elems: Iterator[T], andThen: () => Unit): Unit
    def emitMultiple[T](out: Outlet[T], elems: Iterable[T]): Unit
    def emitMultiple[T](out: Outlet[T], elems: Iterable[T], andThen: () => Unit): Unit
        Replaces the OutHandler with a handler that emits one or more elements 
        when there is demand, and then reinstalls the original OutHandler
    def abortEmitting(out: Outlet[_]): Unit
        Abort outstanding (suspended) emissions for the given outlet, if there are any.
        
Sink or in:Inlet Side 
    def read[T](in: Inlet[T])(andThen: (T) => Unit, onClose: () => Unit): Unit
    def readN[T](in: Inlet[T], n: Int)(andThen: (Seq[T]) => Unit, onClose: (Seq[T]) => Unit): Unit
        replaces the InHandler with a handler that reads one or more elements 
        as they are pushed and allows the handler 
        to react once the requested number of elements has been read.
        and then reinstalls the original InHandler
    def abortReading(in: Inlet[_]): Unit
        Abort outstanding (suspended) reading for the given inlet, if there is any.

//Example 
import akka.stream.stage._

class NumbersSourceE extends GraphStage[SourceShape[Int]] {
  val out: Outlet[Int] = Outlet("NumbersSource")  
  override val shape: SourceShape[Int] = SourceShape(out)
  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      // All state MUST be inside the GraphStageLogic,
      // never inside the enclosing GraphStage.
      private var counter = 1    
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          emit(out, counter, () => {counter += 1})  
        }
      })          
    }
}
class StdoutSinkE extends GraphStage[SinkShape[Int]] {
  val in: Inlet[Int] = Inlet("StdoutSink")
  override val shape: SinkShape[Int] = SinkShape(in)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) { 
      override def preStart(): Unit = pull(in)
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          read(in)(x => println(x), () => ())
          pull(in)
        }
      })
    }
}


Source.fromGraph(new NumbersSourceE).take(10).to(Sink.fromGraph(new StdoutSinkE)).run()

//Generally the flow is given below 
    in:Inlet[T], Sink like for Upstream ->processing -> out:Outlet[T], Source like for Downstream 
    
Sink like 
    setHandler(in, InHandler)
        InHandler.onPush would be called when UpStream push(out=in, T) on this Inlet         
        grab(in):T or read(in)(andThen: (T) => Unit, onClose: () => Unit)
        Do processing on grabed element 
        and then push(Outlet, T)/emit/emitMultiple on out:Outlet[T]
        Might create extra demand by pull(in)
        
Source like 
    setHandler(out, OutHandler)
        OutHandler.onPull would be called when DownStream pull(in=out) on this Outlet         
        (In general, does  push(out,T) or emit(out,T) )
        here To integrate with InLet of Sink , 
        Create demand by pull(in)( which goes to Upstream Source onPull and it does push/emit)
        

//Example Flow[A,B] from  A => B
https://doc.akka.io/docs/akka/current/images/graph_stage_map.png   

//code 
class Map[A, B](f: A => B) extends GraphStage[FlowShape[A, B]] {

  val in = Inlet[A]("Map.in")   //
  val out = Outlet[B]("Map.out")//

  override val shape = FlowShape.of(in, out)

  override def createLogic(attr: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          push(out, f(grab(in)))
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })
    }
}

class StdoutSinkT[T] extends GraphStage[SinkShape[T]] {
  val in: Inlet[T] = Inlet("StdoutSink")
  override val shape: SinkShape[T] = SinkShape(in)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      override def preStart(): Unit = pull(in)
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          println(grab(in))
          pull(in)
        }
      })
    }
}
Source.fromGraph(new NumbersSource).take(10).via(Flow.fromGraph(new Map(_.toString))).to(Sink.fromGraph(new StdoutSinkT)).run()

          
//Example Filter      
https://doc.akka.io/docs/akka/current/images/graph_stage_filter.png

class Filter[A](p: A => Boolean) extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("Filter.in")
  val out = Outlet[A]("Filter.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          if (p(elem)) push(out, elem)
          else pull(in)
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })
    }
}
Source.fromGraph(new NumbersSource).take(10).via(Flow.fromGraph(new Map(_.toString))).
via(Flow.fromGraph(new Filter(!List("2","7").contains(_)))).to(Sink.fromGraph(new StdoutSinkT)).run()


//Example Duplicate 
https://doc.akka.io/docs/akka/current/images/graph_stage_duplicate.png

class Duplicator[A] extends GraphStage[FlowShape[A, A]] {

  val in = Inlet[A]("Duplicator.in")
  val out = Outlet[A]("Duplicator.out")

  val shape = FlowShape.of(in, out)

  override def createLogic(inheritedAttributes: Attributes): GraphStageLogic =
    new GraphStageLogic(shape) {
      
      setHandler(in, new InHandler {
        override def onPush(): Unit = {
          val elem = grab(in)
          emitMultiple(out, Seq(elem, elem))
        }
      })
      setHandler(out, new OutHandler {
        override def onPull(): Unit = {
          pull(in)
        }
      })
    }
      //  OR 
      // var lastElem: Option[A] = None
      // setHandler(in, new InHandler {
      //   override def onPush(): Unit = {
      //     val elem = grab(in)
      //     lastElem = Some(elem)
      //     push(out, elem)
      //   }
      // 
      //   override def onUpstreamFinish(): Unit = {
      //     if (lastElem.isDefined) emit(out, lastElem.get)
      //     complete(out)
      //   }
      // 
      // })
      // setHandler(out, new OutHandler {
      //   override def onPull(): Unit = {
      //     if (lastElem.isDefined) {
      //       push(out, lastElem.get)
      //       lastElem = None
      //     } else {
      //       pull(in)
      //     }
      //   }
      // })
}
Source.fromGraph(new NumbersSource).take(10).via(Flow.fromGraph(new Map(_.toString))).
via(Flow.fromGraph(new Filter(!List("2","7").contains(_)))).
via(Flow.fromGraph(new Duplicator)).to(Sink.fromGraph(new StdoutSinkT)).run()

//with extension 
implicit class SourceDuplicator[Out, Mat](s: Source[Out, Mat]) {
  def duplicateElements: Source[Out, Mat] = s.via(new Duplicator)
}

val s = Source(1 to 3).duplicateElements

s.runWith(Sink.seq)/*Future*/.foreach(println)

implicit class FlowDuplicator[In, Out, Mat](s: Flow[In, Out, Mat]) {
  def duplicateElements: Flow[In, Out, Mat] = s.via(new Duplicator)
}

val f = Flow[Int].duplicateElements

Source(1 to 3).via(f).runWith(Sink.seq)/*Future*/.foreach(println)
  
//Custom materialized values 
Custom operators can return materialized values instead of NotUsed 
by inheriting from GraphStageWithMaterializedValue instead of the simpler GraphStage.
(check https://doc.akka.io/docs/akka/current/stream/stream-customize.html)

//Logging inside GraphStages
Use akka.stream.operator.StageLogging to obtain log.*methods 
eg new GraphStageLogic(shape) with StageLogging {...}
(check https://doc.akka.io/docs/akka/current/stream/stream-customize.html)

  
///Streaming IO  --ADVANCED
class ByteString extends IndexedSeq[Byte]
    All Seq operation can be done 
    https://doc.akka.io/api/akka/current/akka/util/ByteString$.html
    Conversions 
        utf8String : String
            Decodes this ByteString as a UTF-8 encoded String.
        ByteString (string: String): ByteString
            Creates a new ByteString by encoding a String as UTF-8.
            
//WordCounts
val text = """Hello World 
Hello Earth 
Hello Everyone
"""

import akka._ 
import akka.stream._ 
import akka.stream.scaladsl._

// delimiter(delimiter: ByteString, maximumFrameLength: Int, allowTruncation: Boolean = false): Flow[ByteString, ByteString, NotUsed]
val linesStream = Source( Seq(text, text)).map(ByteString(_)).
  via(Framing.delimiter(ByteString("\n"), maximumFrameLength = 100, allowTruncation = true)).
  map(_.utf8String.trim).filter(_ != "") //Source[String, NotUsed]
  
//check 
linesStream.runWith(Sink.seq)

//Implement reduceByKey based on groupBy[K]
def reduceByKey[In, K, Out](maximumGroupSize: Int, 
  groupKey: (In) => K, 
  map: (In) => Out)(reduceFn: (Out, Out) => Out): Flow[In, (K, Out), NotUsed] = {

      Flow[In]
        //Flow[Int,Out,Mat].groupBy[K](maxSubstreams: Int, f: (Out) => K): SubFlow[Out, Mat, Flow, Sink[In, Mat]]
        .groupBy[K](maximumGroupSize, groupKey) //SubFlow[In, NoUsed, Flow[In,_,NoUsed],Sink[In,NoUsed]]
        //SubFlow[+Out, +Mat, +F[+_], C].map[T](f: (Out) => T): SubFlow[T, Mat, F[_], C]
        //on each substream , apply this Fn 
        .map(e => groupKey(e) -> map(e))
        //SubFlow[+Out, +Mat, +F[+_], C].reduce[T >: Out](f: (T, T) => T): SubFlow[T, Mat, F[_], C]
        //on each substream , reduce 
        .reduce((l, r) => l._1 -> reduceFn(l._2, r._2))
        //mergeSubstreams: F[Out]
        //merge all substreams 
        .mergeSubstreams
}

val MaximumDistinctWords = 100 
//Source[out,Mat].mapConcat[T](f: (Out) => Iterable[T]): Source[T, Mat]
//mapConcat flattens Iterable[T]
val wordCounts = linesStream.mapConcat(_.split("\\s+")).via(
  reduceByKey(MaximumDistinctWords, groupKey = (word: String) => word, map = (word: String) => 1)(
    (left: Int, right: Int) => left + right))

wordCounts.runForeach(println)


///Stream Refs  -- ADVANCED 
StreamRefs
    def sinkRef[T](): Source[T, SinkRef[T]]
        Materialize this to get  a SinkRef which is sent to remote one 
        to publish data (after attaching to Source) 
        Attach this Source with a local Sink to get the same data pushed by remote system 
    def sourceRef[T](): Sink[T, SourceRef[T]]
        Materialize this to get  a SourceRef which is sent to remote one 
        to consume data(after attaching to Sink) 
        Attach this Sink with a local Source to push local data which goes to remote system 
        
//Serialization of SourceRef and SinkRef
StreamRefs require serialization, since the whole point is to send them between nodes of a cluster. 
A built in serializer is provided when SourceRef and SinkRef are sent directly as messages 
however the recommended use is to wrap them into your own actor message classes.

When Akka Jackson is used, serialization of wrapped SourceRef and SinkRef will work out of the box.


//Source Refs - offering streaming data to a remote system
A SourceRef is by design ''single-shot''; i.e., it may only be materialized once. 

Multicast can be mimicked by starting a BroadcastHub operator once, 
then attaching multiple new streams to it, each emitting a new stream ref. 

//Example 
import akka.stream._
import akka.actor._ 

case class RequestLogs(streamId: Int)
case class LogsOffer(streamId: Int, sourceRef: SourceRef[String])

class DataSource extends Actor {

  def receive = {
    case RequestLogs(streamId) =>
        // obtain the source you want to offer:
        val source: Source[String, NotUsed] = streamLogs(streamId)
        // sourceRef[T](): Sink[T, SourceRef[T]]
        val ref: SourceRef[String] = source.runWith(StreamRefs.sourceRef())
        val reply = LogsOffer(streamId, ref)
        sender() ! reply   
    case "STOP" => context.stop(self)        
  }

  def streamLogs(streamId: Long): Source[String, NotUsed] = Source(Seq(1,2,3,4).map(_.toString))
}

class EchoSource(val sa:ActorRef) extends Actor with ActorLogging {

  def receive = {
    case RequestLogs(streamId) => sa ! RequestLogs(streamId)
    case LogsOffer(streamId, source) =>
             source.runForeach(log.info) //SourceRef has all Source methods 
             //OR SourceRef.source = Source 
    case "STOP" => context.stop(self)     
  } 
}

val sourceActor = system.actorOf(Props(new DataSource), "dataSource")
val echo = system.actorOf(Props(new EchoSource(sourceActor)), "echo")

echo ! RequestLogs(1337)

Seq(sourceActor, echo).foreach( _ ! "STOP")



//Sink Refs - offering to receive streaming data from a remote system
A SinkRef is by design 'single-shot'; i.e., it may only be materialized once. 

If you have a use case for building a fan-in operation that accepts writes from multiple remote nodes, 
you can build your Sink and prepend it with a MergeHub operator, 

//Example 
import akka.stream._
import akka.stream.scaladsl._
import akka._
import akka.actor._
import akka.util._
import scala.concurrent._
import scala.concurrent.duration._

implicit val system = ActorSystem("TestSystem")


case class PrepareUpload(id: String)
case class MeasurementsSinkReady(id: String, sinkRef: SinkRef[String])

class DataReceiver(implicit materializer: Materializer) extends Actor with ActorLogging{

  def receive = {
    case PrepareUpload(nodeId) =>
      val sink: Sink[String, NotUsed] = logsSinkFor(nodeId)
      //sinkRef[T](): Source[T, SinkRef[T]]
      val ref: SinkRef[String] = StreamRefs.sinkRef[String]().to(sink).run()
      val reply = MeasurementsSinkReady(nodeId, ref)
      sender() ! reply
     case "STOP" => context.stop(self)  
  }

  def logsSinkFor(nodeId: String)(implicit materializer: Materializer): Sink[String, NotUsed] = {
        /*
        val s:Sink[String, Future[Seq[String]]] = Sink.seq[String]
        val (fut, ss) = s.preMaterialize()  //2.5.13 works 
        fut.foreach( seq=> log.info( seq.toString) )
        ss
        */
        Sink.seq[String].mapMaterializedValue( x => NotUsed)
    }
}

class EchoSink(val sa:ActorRef) extends Actor with ActorLogging {

  def receive = {
    case PrepareUpload(id) => sa ! PrepareUpload(id)
    case MeasurementsSinkReady(id, sink) =>
             Source(1 to 3).map(_.toString).runWith(sink) //SinkRef has all Sink methods 
             //OR SinkRef.sink = Sink 
    case "STOP" => context.stop(self)     
  } 
}

val receiver = system.actorOf(Props(new DataReceiver), "receiver")
val echo = system.actorOf(Props(new EchoSink(receiver)), "echo")

echo ! PrepareUpload("1337")

Seq(receiver, echo).foreach( _ ! "STOP")








/// Typed Stream for connecting to typed Actor -- ADVANCED *
//Actor Source
A stream that is driven by messages sent to a particular actor 
can be started with ActorSource.actorRef. 

This source materializes to a typed ActorRef 
which only accepts messages that are of the same type as the stream.

//Example 

import akka.actor.typed._
import akka.actor.typed.scaladsl._
import akka.stream._
import akka.stream.scaladsl._
import akka.stream.typed.scaladsl._

trait Protocol
case class Message(msg: String) extends Protocol
case object Complete extends Protocol
case class Fail(ex: Throwable) extends Protocol
//Throwable (this includes Exception and Error),

//actorRef[T](completionMatcher: PartialFunction[T, Unit], failureMatcher: PartialFunction[T, Throwable], bufferSize: Int, overflowStrategy: OverflowStrategy): Source[T, ActorRef[T]]
val source: Source[Protocol, ActorRef[Protocol]] = 
    ActorSource.actorRef[Protocol](completionMatcher = {
      case Complete =>
    }, failureMatcher = {
      case Fail(ex) => ex
    }, bufferSize = 8, overflowStrategy = OverflowStrategy.fail)

val actorRef = source
  .collect {
    case Message(msg) => msg
  }
  .to(Sink.foreach(println))
  .run()

List( Message("msg1"),  Message("msg1"), Complete).foreach( actorRef ! _ )


//Actor Sink
There are two sinks available that accept typed ActorRefs. 
use ActorSink.actorRef for no backpressure 

//Example 

def echo[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
        context.log.info(s"New msg received: $msg")  
        msg match{
            case Complete => 
                println(s"${context.self} stopping")
                Behaviors.stopped  
            case _ => Behaviors.same    
        }
    }
//system is classical ActorSystem 
import akka.actor.typed.scaladsl.adapter._
val actor: ActorRef[Protocol] = system.toTyped.systemActorOf(echo[Protocol](), "sink-actor")

//actorRef[T](ref: ActorRef[T], onCompleteMessage: T, onFailureMessage: (Throwable) => T): Sink[T, NotUsed]
val sink: Sink[Protocol, NotUsed] =
  ActorSink.actorRef[Protocol](ref = actor, 
    onCompleteMessage = Complete, onFailureMessage = Fail.apply)

val actorRef = source.to(sink).run()
List( Message("msg1"),  Message("msg1"), Complete).foreach( actorRef ! _ )


/// More on typed Actor and Stream -- ADVANCED
//For an actor to be able to react to backpressure, 
//a protocol needs to be introduced  between the actor and the stream. 
//Use ActorSink.actorRefWithAck to be able to signal demand 
//when the actor is ready to receive more elements.

trait Ack
object Ack extends Ack

case class Init2(ackTo: ActorRef[Ack]) extends Protocol
case class Message2(ackTo: ActorRef[Ack], msg: String) extends Protocol


//this actor must send back Ack , else source is backpressured 
def echo2[T](): Behavior[T] = Behaviors.receive { (context, msg) =>
        context.log.info(s"New msg received: $msg")  
        msg match{
            case Complete => 
                println(s"${context.self} stopping")
                Behaviors.stopped  
            case Init2(ref) => 
                ref ! Ack 
                Behaviors.same   
            case Message2(ref, msg) => 
                ref ! Ack 
                Behaviors.same   
            case _ => 
                Behaviors.same    
        }
    }
val actor: ActorRef[Protocol] = system.toTyped.systemActorOf(echo2[Protocol](), "sink-actor2")

//Understand String message , converted to Protocol by Message2.apply == (ActorRef[Ack], String) => Protocol
val sink: Sink[String, NotUsed] = ActorSink.actorRefWithBackpressure(
  ref = actor,
  onCompleteMessage = Complete,
  onFailureMessage = Fail.apply,
  messageAdapter = Message2.apply,
  onInitMessage = Init2.apply,
  ackMessage = Ack)

Source.single("msg1").runWith(sink)



  

