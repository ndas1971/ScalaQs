///Example Monad implementations -- ADVANCED 
implicit def eitherMonad[L] = new Monad[Either[L, *]] {
 override def pure[A](a:  A): Either[L, A] = Right(a)

 override def flatMap[A, B](a: Either[L, A])(f: A => Either[L, B]):  Either[L, B] = a match {
   case Right(r) => f(r)
   case Left(l) => Left(l)
 }
}

implicit val listMonad = new Monad[List] {
  def pure[A](a: A) = List(a)

  def flatMapNonTailRec[A,B](as: List[A])(f: A => List[B]): List[B] = as match {
    case Nil => Nil
    case a :: as => f(a) ::: flatMap(as)(f)
  }

  def flatMapOkButSlow[A,B](as: List[A])(f: A => List[B]): List[B] = {
    @tailrec
    def fMap(as: List[A], acc: List[B])(f: A => List[B]): List[B] = as match {
      case Nil => acc
      case a :: aas => fMap(aas, acc ::: f(a))(f)
    }
    fMap(as, Nil)(f)
  }

  override def flatMap[A,B](as: List[A])(f: A => List[B]): List[B] = as.flatMap(f)
}

///Testing Monad Laws with ScalaCheck -- ADVANCED 
import org.scalacheck._
import Prop._


def associativity[A, B, C, M[_]](implicit M: Monad[M],
                                 arbMA: Arbitrary[M[A]],
                                 arbMB: Arbitrary[M[B]],
                                 arbMC: Arbitrary[M[C]],
                                 arbB: Arbitrary[B],
                                 arbC: Arbitrary[C],
                                 cogenA: Cogen[A],
                                 cogenB: Cogen[B]): Prop = {
  forAll((as: M[A], f: A => M[B], g: B => M[C]) => {
    val leftSide = M.flatMap(M.flatMap(as)(f))(g)
    val rightSide = M.flatMap(as)(a => M.flatMap(f(a))(g))
    leftSide == rightSide
  })
}

def id[A, B, M[_]](implicit M: Monad[M],
                   arbFA: Arbitrary[M[A]],
                   arbFB: Arbitrary[M[B]],
                   arbA: Arbitrary[A],
                   cogenA: Cogen[A]): Prop = {
  val leftIdentity = forAll { as: M[A] =>
    M.flatMap(as)(M.pure(_)) == as
  }
  val rightIdentity = forAll { (a: A, f: A => M[B]) =>
    M.flatMap(M.pure(a))(f) == f(a)
  }
  leftIdentity && rightIdentity
}

def monad[A, B, C, M[_]](implicit M: Monad[M],
                         arbMA: Arbitrary[M[A]],
                         arbMB: Arbitrary[M[B]],
                         arbMC: Arbitrary[M[C]],
                         arbA: Arbitrary[A],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],  //Cogen is only for arg, f: A => ... f:B=>...
                         cogenB: Cogen[B]): Prop = {
  id[A, B, M] && associativity[A, B, C, M]
}

//Monad[List] prop check 
monad[String, Int, Boolean, List].check 

///Monad -Props check with  cats-law  
Cats requires below 

Monad[F[_]].tailRecM[A, B](a: A)(f: A => F[Either[A, B]]): F[B]
    Keeps calling f until a b:Right[B] is returned
    and then lift b into F[_]
    
In cats, many derived methods are implemented using tailRecM and faltMap 
to make them stack safe,     
    
This can be implemented like (not TCO)

  def tailRecM[A, B](a: A)(f: A => F[Either[A, B]]): F[B] =
    flatMap(f(a)) {  //inside flatMap fn, one gets A of F[A], here Either[A, B]
      case Right(b) => pure(b)
      case Left(a) => tailRecM(a)(f)
  }

But, For many monadic types, 
recursively flatMap-ing in this way will quickly exhaust the stack

For example  Option[_] has this problem , but for Option it can be written like 

  @tailrec
  def tailRecM[A, B](a: A)(f: A => Option[Either[A, B]]): Option[B] = f(a) match {
    case None => None
    case Some(Left(a1)) => tailRecM(a1)(f)
    case Some(Right(b)) => Some(b)
  }

//One derived method using  tailRecM

//Apply a monadic function iteratively until its result fails
//to satisfy the given predicate and return that result.
def iterateWhileM[A](init: A)(f: A => F[A])(p: A => Boolean): F[A] =
  tailRecM(init) { a =>
    if (p(a))
      map(f(a))(Left(_))
    else
      pure(Right(a))
}


Cats Laws divides  into Unsafe version and Safe version 
    Unsafe version does not have TCO tailRecM 
    Safe version has TCO tailRecM
check cats doc, https://typelevel.org/cats/faq.html#tailrecm

For List 
   def tailRecM[A, B](a: A)(f: A => List[Either[A, B]]): List[B] = {
        val buf = List.newBuilder[B]
        @tailrec def go(lists: List[List[Either[A, B]]]): Unit =
          lists match {
            case (ab :: abs) :: tail =>
              ab match {
                case Right(b) => buf += b; go(abs :: tail)
                case Left(a)  => go(f(a) :: abs :: tail)
              }
            case Nil :: tail => go(tail)
            case Nil         => ()
          }
        go(f(a) :: Nil)
        buf.result()
    }
    
For Either 
    def tailRecM[B, C](b: B)(f: B => Either[A, Either[B, C]]): Either[A, C] =
        f(b) match {
          case left @ Left(_) =>
            left.rightCast[C]
          case Right(e) =>
            e match {
              case Left(b1)         => tailRecM(b1)(f)
              case right @ Right(_) => right.leftCast[A]
            }
        }   


//Example 
import cats.laws.discipline.MonadTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 //monad[A: Arbitrary: Eq, B: Arbitrary: Eq, C: Arbitrary: Eq]
  checkAll("List.MonadLaws", MonadTests[List].monad[Int, Int, String])
  checkAll("List.StackUnsafeMonadLaws", MonadTests[List].stackUnsafeMonad[Int, Int, String])
  
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
- List.MonadLaws.monad.ap consistent with product + map
- List.MonadLaws.monad.applicative homomorphism
- List.MonadLaws.monad.applicative identity
- List.MonadLaws.monad.applicative interchange
- List.MonadLaws.monad.applicative map
- List.MonadLaws.monad.applicative unit
- List.MonadLaws.monad.apply composition
- List.MonadLaws.monad.covariant composition
- List.MonadLaws.monad.covariant identity
- List.MonadLaws.monad.flatMap associativity
- List.MonadLaws.monad.flatMap consistent apply
- List.MonadLaws.monad.flatMap from tailRecM consistency
- List.MonadLaws.monad.invariant composition
- List.MonadLaws.monad.invariant identity
- List.MonadLaws.monad.map flatMap coherence
- List.MonadLaws.monad.map2/map2Eval consistency
- List.MonadLaws.monad.map2/product-map consistency
- List.MonadLaws.monad.monad left identity
- List.MonadLaws.monad.monad right identity
- List.MonadLaws.monad.monoidal left identity
- List.MonadLaws.monad.monoidal right identity
- List.MonadLaws.monad.mproduct consistent flatMap
- List.MonadLaws.monad.productL consistent map2
- List.MonadLaws.monad.productR consistent map2
- List.MonadLaws.monad.semigroupal associativity
- List.MonadLaws.monad.tailRecM consistent flatMap
- List.MonadLaws.monad.tailRecM stack safety

- List.StackUnsafeMonadLaws.monad (stack-unsafe).ap consistent with product +map
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative homomorphism
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative interchange
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative map
- List.StackUnsafeMonadLaws.monad (stack-unsafe).applicative unit
- List.StackUnsafeMonadLaws.monad (stack-unsafe).apply composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).covariant composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).covariant identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap associativity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap consistent apply
- List.StackUnsafeMonadLaws.monad (stack-unsafe).flatMap from tailRecM consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).invariant composition
- List.StackUnsafeMonadLaws.monad (stack-unsafe).invariant identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map flatMap coherence
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map2/map2Eval consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).map2/product-map consistency
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monad left identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monad right identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monoidal left identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).monoidal right identity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).mproduct consistent flatMap
- List.StackUnsafeMonadLaws.monad (stack-unsafe).productL consistent map2
- List.StackUnsafeMonadLaws.monad (stack-unsafe).productR consistent map2
- List.StackUnsafeMonadLaws.monad (stack-unsafe).semigroupal associativity
- List.StackUnsafeMonadLaws.monad (stack-unsafe).tailRecM consistent flatMap

///Monad-cats Example 
import cats.implicits._
import cats._

def mapFunc[A, B, F[_]](as: F[A])(f: A => B)(implicit monad: Monad[F]): F[B] = monad.map(as)(f)
def applyFunc[A, B, F[_]](as: F[A])(f: F[A => B])(implicit monad: Monad[F]): F[B] = monad.ap(f)(as)
def flatMapFunc[A, B, F[_]](as: F[A])(f: A => F[B])(implicit  monad: Monad[F]): F[B] =  monad.flatMap(as)(f)
    
mapFunc(List(1,2,3))(_ * 2)
//List(2, 4, 6)
applyFunc(List(1,2,3))(List( (_:Int) * 2, (_:Int) * 3, (e:Int) => e*e ))
//List(2, 4, 6, 3, 6, 9, 1, 4, 9)
flatMapFunc(List(1,2,3))(x => List(x, x*x, x*x*x))
// List[Int] = List(1, 1, 1, 2, 4, 8, 3, 9, 27)

//Note we can use for comprehension if we have map and flatMap
//Note, in Function[-T,+A], map is andThen  
//and flatmap's fn must return another Function[-T,+B] and end result is  Function[-T,+B]
val func1 = (a:Double) => a.toString 
val func2 = (in:String) => in.toDouble.toInt
val fn = func1.map( func2 ) 
//Double => Int ie   func2(func1(a)) or andThen 

//one section = map 
val fn = for {
    res <- func1   //result of func1 
} yield func2(res)
//fn: Double => Int

val fn2 = func1.flatMap( (x:String) =>  (y:Double) =>  x+y.toString )
//Double => String
fn2(3.0)  // fn2's input == func1's input  == y:Double == 3.0 

//two section=flatmap and then map 
val fn2 = for {
    x <- func1 
    res2 <- ( (y:Double) =>  x+y.toString )
} yield res2 
//Double => String

//Custom class - Monad    
import cats._ 
import cats.implicits._ 

case class MyBox[T](val value:T) {
   override def toString() = "MyBox("+value+")"
}

object MyBox {
    implicit val MyBoxMonad = new Monad[MyBox] {
        def flatMap[A,B](a: MyBox[A])(f:A => MyBox[B]): MyBox[B] = MyBox( f(a.value).value)
        def pure[A](a: A): MyBox[A]  = MyBox(a)
        //for cats 
        //non TCO 
        def tailRecM[A, B](a: A)(f: A => MyBox[Either[A,B]]): MyBox[B] = 
        flatMap(f(a)) {  //Either[A, B]
              case Right(b) => pure(b)
              case Left(a) => tailRecM(a)(f)
          }
    }
}
implicitly[Monad[MyBox]]
Monad[MyBox].flatMap(MyBox(2))((x:Int) => MyBox(x.toDouble))

val (a, b) = (MyBox(2), MyBox(3))
for {
     v1 <- a 
     v2 <- b 
  } yield v1 + v2 
  

//is it really Monad  
import cats.laws.discipline.MonadTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

object arbitraries {
  implicit def arbMyBox[A: Arbitrary]: Arbitrary[MyBox[A]] = {
    val gen = for { a  <- Arbitrary.arbitrary[A] } yield MyBox(a)
    Arbitrary(gen)
  }
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqMyBox[A: Eq]: Eq[MyBox[A]] = Eq.fromUniversalEquals
 //checkAll("List.MonadLaws", MonadTests[List].monad[Int, Int, String])
 checkAll("MyBox.StackUnsafeMonadLaws", MonadTests[MyBox].stackUnsafeMonad[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests())

//What about TCo tailRec 

case class MyBox[T](val value:T) {
   override def toString() = "MyBox("+value+")"
}

object MyBox {
    implicit val MyBoxMonad = new Monad[MyBox] {
        def flatMap[A,B](a: MyBox[A])(f:A => MyBox[B]): MyBox[B] = MyBox( f(a.value).value)
        def pure[A](a: A): MyBox[A]  = MyBox(a)
        //for cats 
        //TCO 
        @annotation.tailrec 
        def tailRecM[A, B](a: A)(f: A => MyBox[Either[A,B]]): MyBox[B] = f(a).value match {
            case Right(b) => pure(b)
            case Left(a) => tailRecM(a)(f)        
        }
        
    }
}

//Now test 
import cats.laws.discipline.MonadTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

object arbitraries {
  implicit def arbMyBox[A: Arbitrary]: Arbitrary[MyBox[A]] = {
    val gen = for { a  <- Arbitrary.arbitrary[A] } yield MyBox(a)
    Arbitrary(gen)
  }
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqMyBox[A: Eq]: Eq[MyBox[A]] = Eq.fromUniversalEquals
 checkAll("MyBox.MonadLaws", MonadTests[MyBox].monad[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests())
//OK 
 

    
///id Monad - Example from cats 
import cats._
import cats.implicits._ 
 
//flatMap means  , we can use for comprehension 
def sumSquare[F[_]: Monad](a: F[Int], b: F[Int]): F[Int] =
     for {
      x <- a
      y <- b
 } yield x*x + y*y


This method works well on Options and Lists (Option[+A], hence wide it )
//example 
sumSquare(Some(2):Option[Int], Some(3):Option[Int])

but we canot call it passing in plain values:
//example 
sumSquare(3, 4)

//There comes Id monad 
sumSquare(3 : Id[Int], 4 : Id[Int])


///Complex example of Id: Traversables are Functors -- ADVANCED 
Every Traverse is a lawful Functor. 
By carefully picking the G to use in traverse we can implement map.

//def 
import cats._

trait Traverse[F[_]] extends Functor[F] {
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]

  def map[A, B](fa: F[A])(f: A => B): F[B] = ???
}}

Both have an F[A] parameter and a similar f parameter. 
traverse expects the return type of f to be G[B] whereas map just wants B. 
return type of traverse is G[F[B]] whereas for map is F[B]. 

So if G is Identity , then we get map == traverse 

//Example 
type Id[A] = A

//Then 
implicit val applicativeForId: Applicative[Id] = new Applicative[Id] {
  def ap[A, B](ff: Id[A => B])(fa: Id[A]): Id[B] = ff(fa)
  def pure[A](a: A): Id[A] = a
}
//Then 
trait Traverse[F[_]] extends Functor[F] {
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]

  def map[A, B](fa: F[A])(f: A => B): F[B] =
    traverse(fa)(a => (f(a):Id[B]))
}

//Id can be implemented as case class as well 

final case class Id[A](value: A)

//Write Applicative 
implicit val applicativeForId: Applicative[Id] = new Applicative[Id] {
  def ap[A, B](ff: Id[A => B])(fa: Id[A]): Id[B] = Id(ff.value(fa.value))
  def pure[A](a: A): Id[A] = Id(a)
}

//Then 
trait Traverse[F[_]] extends Functor[F] {
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]

  def map[A, B](fa: F[A])(f: A => B): F[B] =
    traverse(fa)(a => Id(f(a))).value
}

///Traversables are Foldable -- ADVANCED 
Traverse is strictly more powerful than Foldable 
that is, foldLeft and foldRight can be implemented 
in terms of traverse by picking the right Applicative. 

//def 
trait Traverse[F[_]] extends Foldable[F] {
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]
  
  def foldLeft[A, B](fa: Tree[A], b: B)(f: (B, A) => B): B = ???
  def foldRight[A, B](fa: Tree[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B] = ??
}

Introducing Const[A,*] which contains A and disregard *
This works because Const[A, *] is an Applicative if A is a Monoid, 

//example 
final case class Const[A, B](const: A) {

  def retag[C]: Const[A, C] =
    this.asInstanceOf[Const[A, C]]  //simply change second type 

  def combine(that: Const[A, B])(implicit A: Semigroup[A]): Const[A, B] =
    Const(A.combine(this.const, that.const))
  
  //since we disregard B, no need to call f 
  def traverse[F[_], C](f: B => F[C])(implicit F: Applicative[F]): F[Const[A, C]] =
    F.pure(this.retag[C])  
}

object Const {
  def empty[A, B](implicit A: Monoid[A]): Const[A, B] =
    Const(A.empty)

  implicit def constMonoid[A: Monoid, B]: Monoid[Const[A, B]] =
      new Monoid[Const[A, B]] {
        def empty: Const[A, B] =  Const.empty
        def combine(x: Const[A, B], y: Const[A, B]): Const[A, B] =
          x.combine(y)
      }
      
  implicit def constApplicative[A](implicit A: Monoid[A]): Applicative[Const[A, *]] =
      new Applicative[Const[A, *]] { 
          def ap[B, C](f: Const[A, B => C])(fa: Const[A, B]): Const[A, C] =
              f.retag[C].combine(fa.retag[C])
          def pure[B](x: B): Const[A, B] = Const.empty
          }
    
}
//With above 
trait Traverse[F[_]] extends Foldable[F] {
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]

  override def foldMap[A, B: Monoid](fa: F[A])(f: A => B): B =
    traverse[Const[B, *], A, B](fa)(a => Const(f(a))).const

  private def andThenMonoid[A]: Monoid[A => A] = new Monoid[A => A] {
    def combine(f: A => A, g: A => A) = f andThen g
    def empty: A => A                 = (a: A) => a
  }

  private def composeMonoid[A]: Monoid[A => A] = new Monoid[A => A] {
    def combine(f: A => A, g: A => A) = f compose g
    def empty: A => A                 = (a: A) => a
  }

  private def defer[B](f: Eval[B] => Eval[B]): Eval[B] => Eval[B] = evalB => Eval.defer(f(evalB))

  override def foldRight[A, B](fa: F[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B] = {
    foldMap(fa)(f.curried andThen defer)(composeMonoid).apply(lb)
  }
  
  override def foldLeft[A, B](fa: F[A], b: B)(f: (B, A) => B): B =
    foldMap[A, B => B](fa){a => b => f(b, a)}(andThenMonoid[B]).apply(b)
    
}

///Exmaple of State from cats 

//synopsis 
With State[S, A](runF: S => (S,A)), flatMap and map, Fn both gets A , 
flatMap Fn must return State[S,B] eg via State[S,B] { S => (S,B) }
wherease map Fn returns B such that map and flatMap both returns State[S,B]
(so map can not modify current state , where as Flatmap can)

State[S,A]
    def flatMap[B](fas: A => State[S,B]): State[S,B]
    def map[B](f: A => B): State[S,B]
    def run(initial: S): Eval[(S, A)]
State[S, A]
    runF: S => (S,A)
State 
    apply[S, A](f: S => (S, A)): State[S, A]
    
    
//Example 
import cats.* 
import cats.implicits.* 
import cats.data.*

//State.apply[S, A](f: S => (S, A)): State[S, A]
val s = State[Double,Int] { (state:Double) =>
    println("Executed")
    //must return (Double, Int)
    (state+1, state.toInt)
    }
    
    
//must return new v:Int , map does not have access currentState , can only modify A 
val new_s = s.map { (v:Int) => v * 10.0 }

new_s.run(10.0/*current_state*/)/*Eval[(Double, Double)]*/.value 
//Executed 
//(Double, Double) = (11.0,100.0)

//must return S[Double,Int], flatMap has access to currentState 
val newss = new_s.flatMap{ (v:Double)/*100.0*/ =>  
  State[Double,Int] { (currentState:Double)/*11.0*/ =>
    println("Again Executed")
    //must return (Double, Int)
    (currentState+1, currentState.toInt+v.toInt)
    //11+1 , 11+100
    } 
}
newss.run(10.0/*current_state*/)/*Eval*/.value 
//Executed
//Again Executed
//val res20: (Double, Int) = (12.0,111)


//Using shortcut methods of object State from cats 
object State 
  def apply[S, A](f: S => (S, A)): State[S, A]
  def pure[S, A](a: A): State[S, A] 
  def empty[S, A](using  A: Monoid[A]): State[S, A] 
  def modify[S](f: S => S): State[S, Unit] 
    update State by fn f which gets current state and returns new state 
  def inspect[S, T](f: S => T): State[S, T] 
    Update A , by fn f which gets curentstate and returns new value  
  def get[S]: State[S, S] 
    get curentstate in value 
  def set[S](s: S): State[S, Unit] 
    Set state 
    
//State[S,A].run(initial: S): Eval[(S, A)]
State.get[Int].run(10/*initialstate*/).value    //S and A both = 10 
// res1: (Int, Int) = (10, 10)

//Set the state to `s` and return Unit
State.set[Int](30).run(10).value
// res2: (Int, Unit) = (30, ())


//Return `a` and maintain the input state
val pureDemo = State.pure[Int, String]("Result")  //S=Int, A=String 
pureDemo.run(10/*initialstate*/).value
// res3: (Int, String) = (10, "Result")

//inspect[S, T](f: S => T): State[S, T] = State(s => (s, f(s)))
val inspectDemo = State.inspect[Int, String](s => s"${s}!")  //S=Int, A =String , 
inspectDemo.run(10/*initialstate*/).value
// res4: (Int, String) = (10, "10!")

//modify[S](f: S => S): State[S, Unit] = State(s => (f(s), ()))
val modifyDemo = State.modify[Int](s => s + 1)  // S=Int, A=Unit 
modifyDemo.run(10/*initialstate*/).value
// res5: (Int, Unit) = (11, ())

//OR With for comprehension 
// as [S,A].flatMap/map's  fn takes A  , inside for comprehension , we write like 
//A <- State[S,A]  ie LHS is value of the State[S, A]

import cats.* 
import cats.implicits.* 
import cats.data.*

val program: State[Int, (Int, Int, Int)] = for {
    a <- State.get[Int]               //S[Int,Int], S=Int, A=Int  , a = currentState 
    _ <- State.set[Int](a + 1)        //S[Int, ()], set nextState as a+1
    b <- State.get[Int]               //S[Int,Int], b = currentState
    _ <- State.modify[Int](_ + 1)     //S[Int, ()], fn takes currentState , returns newstate 
    c <- State.inspect[Int, Int](_ * 1000) //S[Int, Int], fn takes current state returns newvalue 
} yield (a, b, c)
// program: State[Int, (Int, Int, Int)] 

val (state, result) = program.run(1/*initialstate*/).value  //current state = 1
// state: Int = 3
// result: (Int, Int, Int) = (1, 2, 3000)


//OR - flatMap gets value and must return State (which gets currentstate) , map gets only value 
State.get[Int]/*value=state, State[Int,Int]*/.
   flatMap{ (a:Int)/*value*/ => State[Int,Int]{ state => (state, a) }}

State.get[Int]/*value=state, State[Int,Int]*/.
  flatMap{ (a:Int) /*value*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/*()*/ => State[Int,Unit]{ state => (state, ()) }}
  }

val program = State.get[Int]/*value=state, State[Int,Int]*/.flatMap{ (a:Int) /*value*/=> 
    State.set[Int](a + 1)/*State[S,()]*/ .flatMap{ (v1:Unit)/* () */ => 
        State.get[Int]/*State[Int,Int]*/.flatMap{ (b:Int) /*state*/ => 
            State.modify[Int](_ + 1)/*State[S,()], state=state+1*/.flatMap{ (v2:Unit) /*()*/ =>  
                State.inspect[Int, Int](_ * 1000)/*State[Int, Int], v=state*1000*/.map { (c:Int)/*v*/ => 
                    (a,b,c) 
               }
            }
        }
    }
}

val (state, result) = program.run(1).value  //current state = 1
// state: Int = 3
// result: (Int, Int, Int) = (1, 2, 3000)
 
 
 
///Complex Example of State - postorder calculation -- ADVANCED 
Calculate value of List("1", "2", "+", "3", "*")

//code 
import cats._ 
import cats.implicits._ 
import cats.data._

//State[S,A] = S => (S,A) , where state=S, computation is A 
type CalcState[A] = State[List[Int], A] //S is List[A]
//Monad can take only one type, fix one if you have two types


  
/* All operations should be 
State[List[Int], Int] { oldState =>
     val newState = someTransformation(oldState)
     val result    = someCalculation
     (newState, result)
 }
*/
 
//Simply push the operands 
//apply[S, A](f: S => (S, A)): State[S, A] 
def operand(num: Int): CalcState[Int] =
    State[List[Int], Int] { stack => //state , List[Int]
        println(s"operand, state=$stack")
        (num :: stack, num)
}
    
def operator(func: (Int, Int) => Int): CalcState[Int] =
   State[List[Int], Int] { //state , List[Int]
       case b :: a :: tail =>
         println(s"operator, state=${b :: a :: tail}")
         val ans = func(a, b)
         (ans :: tail, ans)
       case _ =>
         sys.error("Fail!")
}  

def evalOne(sym: String): CalcState[Int] =
  sym match {
      case "+" => operator(_ + _)
      case "-" => operator(_ - _)
      case "*" => operator(_ * _)
      case "/" => operator(_ / _)
      case num => operand(num.toInt)
  }
  
//0.pure[CalcState] ie CalcState[Int].pure(0) = State[List[Int], 0)
def evalAll(input: List[String]): CalcState[Int] =
   input.foldLeft(0.pure[CalcState]) { (state, ele) => //a : State[List[Int], Int] , b:String 
       state.flatMap(_ => evalOne(ele)) 
       // _ is value, Int , evalOne returns CalcState 
       //a.flatMap() return CalcState which becomes input in next iteration 
   }
   
val program = evalAll(List("1", "2", "+", "3", "*"))
//program.runF
//cats.Eval[List[Int] => cats.Eval[(List[Int], Int)]]

//Takes initial State , List[Int]
//Run return Eval, so .value 
program.run(Nil).value 
/*
operand, state=List()
operand, state=List(1)
operator, state=List(2, 1)
operand, state=List(3)
operator, state=List(3, 3)
val res11: (List[Int], Int) = (List(9),9)
*/


// Get the state, ignore the result:
val justTheState = program.runS(Nil).value

// Get the result, ignore the state:
val justTheResult = program.runA(Nil).value

//OR 
val program = for {
    _    <- evalOne("1")
    _    <- evalOne("2")
    ans <- evalOne("+")
} yield ans

val (state, result) = program.run(Nil).value
//val state: List[Int] = List(3)
//val result: Int = 3


///Reader Example from cats 

//synopsis 
With Reader[R, A](runF: R => A), flatMap and map, Fn both gets A , 
flatMap Fn must return Reader[R,B] eg via Reader[R,B] { R => B }
wherease map Fn returns B such that map and flatMap both returns Reader[R,B]

So map does not have access to R, but modifies A to B 
whereas flatMap has access to R 

Reader[R, A]
    def flatMap[B](fas: A => Reader[R,B]): Reader[R,B] 
    def map[B](f: A => B): Reader[R,B]
    def run(config: R): Id[A]
Reader 
    def apply[R, A](f: R => A): Reader[R, A]
    
//Simple case 
import cats._ 
import cats.implicits._ 
import cats.data._


case class Configuration(v:String)

val s = Reader[Configuration, String] { (conf:Configuration) =>
    println("Executed")
    //must return String as A 
    "first"
    }
    
//must return new v:B  , map does not have access Configuration 
val new_s = s.map { (v:String)/*first*/ => s"map_$v" }

//Reader[R,B].run(config:R): Id[B]
new_s.run(Configuration("conf"))/*Id*/
//Executed
//cats.Id[String] = mapFirst

//flatMap has access to Configuration 
val newss = new_s.flatMap{ (v:String)/*map_first*/ =>  
    Reader[Configuration,String] { 
      (conf:Configuration) =>
        println("Again Executed")
        //must return String
        s"${v}_flatMap_${conf.v}"    
    } 
}
newss.run(Configuration("conf"))/*Id*/
//OR 
newss(Configuration("conf")) //apply 
//Executed
//Again Executed
//val res36: cats.Id[String] = map_first_flatMap_conf

///Complex Reader Example  -- ADVANCED 
The classic use of Readers is to build programs that accept a configuration as a parameter. 
Our configuration will consist of two databases: a list of valid users
and a list of their passwords

//code 
final case class Db(
     usernames: Map[Int, String],
     passwords: Map[String, String]
)

type DbReader[A] = Reader[Db, A]  //Reader[R,A] , R ie db is configuration 

def findUsername(userId: Int): DbReader[Option[String]] =
   Reader(db => db.usernames.get(userId))
   
def checkPassword(username: String, password: String): DbReader[Boolean] =
   Reader(db => db.passwords.get(username).contains(password))
   
//Finally create a checkLogin method to check the password for a given user ID. 

//Flatmap Fn takes always A ,  A <- Reader[R,A]
def checkLogin( userId: Int, password: String): DbReader[Boolean] =
   for {
      username /*Option[String]*/  <- findUsername(userId)  //flatMap 
      passwordOk /*Boolean*/ <- username.map { username /*String*/ =>
                         checkPassword(username, password) /*DbReader[Boolean]*/
                    }/*Option[DbReader[Boolean]]*/.getOrElse {
                         false.pure[DbReader]
                    }
   } yield passwordOk

val users = Map(
     1 -> "dade",
     2 -> "kate",
     3 -> "margo"
 )

val passwords = Map(
     "dade"   -> "zerocool",
     "kate"   -> "acidburn",
     "margo" -> "secret"
 )


val db = Db(users, passwords)

//run returns Id 
checkLogin(1, "zerocool").run(db)
// res7: cats.package.Id[Boolean] = true
checkLogin(4, "davinci").run(db)
// res8: cats.package.Id[Boolean] = false



///Examples from cats 

//synposis 
Note Writer[W,A], flatMap and map, Fn both gets A , flatMap Fn must return Writer[R,B] 
eg via Writer { returns (W,B) or via b.tell:Writer[A, Unit] or b.writer(w:W):Writer[W, A] }
wherease map Fn returns B such that map and flatMap both returns Writer[R,B] 

So map does not get any access to W whereas flatMap has access to W 

(a: A) , on any type 
  def tell: Writer[A, Unit] = Writer(a, ()) //converts a to W 
  def writer[W](w: W): Writer[W, A]  = Writer(w, a)  //converts a to A 
  
Writer[W, A]
    def flatMap[B](fas: A => Writer[W,B]): Writer[W,B] 
    def map[B](f: A => B): Writer[W,B]
    val run: (W, A) 
    val value: A 
    val written: W
Writer 
    apply[W: Monoid, A](w:W, a:A): Writer[W, A] 
  
//Example 
import cats._ 
import cats.implicits._ 
import cats.data._

//a goes to W 
Vector("msg1", "msg2", "msg3").tell
// res2: Writer[Vector[String], Unit] = WriterT( (Vector("msg1", "msg2", "msg3"), ()) )

//a goes to A 
val b = 123.writer(Vector("msg1", "msg2", "msg3"))
// b: Writer[Vector[String], Int] = WriterT((Vector("msg1", "msg2", "msg3"), 123) )

b.value  // Int = 123
b.written
// aLog: Vector[String] = Vector("msg1", "msg2", "msg3")

//We can extract both values at the same time using the run method:
val (log, result) = b.run   //(W,A)
// log: Vector[String] = Vector("msg1", "msg2", "msg3")
// result: Int = 123

b.flatMap{ (v:Int) =>
            Writer( Vector("msg4"), v+10 )
         }.flatMap { (v:Int) =>
            (v+20).writer( Vector("msg5") )
         }.flatMap{ (v:Int) =>
            Vector("msg6").tell.map{ (v1:Unit) => v+30}
         }.run 
//cats.Id[(Vector[String], Int)] = (Vector(msg1, msg2, msg3, msg4, msg5, msg6),183)      


type Logged[A] = Writer[Vector[String], A] //joins via Vector.combine 

// flatMap_arg <- Writer[L,V]
val writer1 = for {
   a <- 10.pure[Logged]   //Writer((Vector(),10))//10
   _ <- Vector("a", "b", "c").tell   //Unit
   b <- 32.writer(Vector("x", "y", "z")) //32
 } yield a + b
 // writer1: cats.data.WriterT[cats.package.Id, Vector[String], Int] = WriterT((Vector("a", "b", "c", "x", "y", "z"), 42) )
//OR 
10.pure[Logged].flatMap( a => Vector("a", "b", "c").tell.flatMap( _ => 
    32.writer(Vector("x", "y", "z")).map ( b => (a+b) )))

writer1.run
// res3: (Vector[String], Int) = (Vector("a", "b", "c", "x", "y", "z")        , 42)


///Complex Write Example -- ADVANCED 
Writers are useful for logging operations in multithreaded environments.

The factorial function below computes a factorial and prints out the inter
mediate steps as it runs. The slowly helper function ensures this takes a while
to run, even on the very small examples below:

import cats._ 
import cats.implicits._ 
import cats.data._

def slowly[A](body: => A) =
     try body finally Thread.sleep(100)


def factorial(n: Int): Int = {
     val ans = slowly(if(n == 0) 1 else n * factorial(n - 1))
     println(s"fact $n $ans")
     ans
 }

factorial(5)
// fact 0 1
// fact 1 1
// fact 2 2
// fact 3 6
// fact 4 24
// fact 5 120
// res9: Int = 120

If we start several factorials in parallel, the log messages can become inter
leaved on standard out. This makes it difficult to see which messages come
from which computation:

import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.duration._

//vector of Future => Future of Vector 
Await.result(Future.sequence(Vector(
    Future(factorial(5)),
    Future(factorial(5))
)), 5.seconds)


//Solution 

 
//In our case
type Logged[A] = Writer[Vector[String], A] //joins via Vector.combine 

def slowly[A](body: => A) =
     try body finally Thread.sleep(100)

def factorial(n: Int): Logged[Int] =
    for {
        ans <- if(n == 0) {
                1.pure[Logged]
            } else {
                slowly(factorial(n - 1).map(_ * n)) // map from Writer 
            }
        _  <- Vector(s"fact $n $ans").tell
    } yield ans


val (log, res) = factorial(5).run
 // log: Vector[String] = Vector(
 //     "fact 0 1",
 //     "fact 1 1",
 //     "fact 2 2",
 //     "fact 3 6",
 //     "fact 4 24",
 //     "fact 5 120"
 // )
 // res: Int = 120


Await.result(Future.sequence(Vector(
   Future(factorial(5)),
   Future(factorial(5))
 ))/* Future[Vector[Logged[Int]]] */
 .map(/*Vector[Logged[Int]]*/ _.map(/*Logged[Int]]*/_.written))  , 5.seconds)
// res: scala.collection.immutable.Vector[cats.Id[Vector[String]]] =
//     Vector(
//         Vector(fact 0 1, fact 1 1, fact 2 2, fact 3 6, fact 4 24, fact        5 120),
//         Vector(fact 0 1, fact 1 1, fact 2 2, fact 3 6, fact 4 24, fact        5 120)
//     )


///IO Monad  --- ADVANCED 
A data type for encoding side effects as pure values, capable of expressing both synchronous  
and asynchronous computations.

A value of type IO[A] is a computation which, when evaluated, 
can perform effects  before returning a value of type A.

//Example 
import cats.effect._
import cats.effect.unsafe.implicits.global

val ioa = IO { println("hey!") }

val program: IO[Unit] =
  for {
     _ <- ioa
     _ <- ioa
  } yield ()



program.unsafeRunSync()
//=> hey!
//=> hey!

//IO` is trampolined in its `flatMap` evaluation.
def fib(n: Int, a: Long = 0, b: Long = 1): IO[Long] =
   IO.pure(a + b).flatMap { b2 =>
     if (n > 0)
       fib(n - 1, b, b2)
     else
       IO.pure(a)
   }
fib(10).unsafeRunSync()

import scala.concurrent.duration._

//Defer  is trampolined , lazily evaluated 
def loop(n: Int): IO[ExitCode] =
    IO.defer {
      if (n < 10)
        //>> for the recursion-safe, lazily evaluated
        //IO[A].>>[B](that: => IO[B]): IO[B]
        IO.sleep(1.second) >> IO(println(s"Tick: $n")) >> loop(n + 1)
      else
        IO.pure(ExitCode.Success)
    }
loop(10).unsafeRunSync()

//On Referential Transparency and Lazy Evaluation
IO can suspend side effects and is thus a lazily evaluated data type, 
being many times compared 
with Future from the standard library 

                Eager 	                Lazy
Synchronous 	A 	                    () => A
                                        Eval[A]
                                        
Asynchronous 	(A => Unit) => Unit 	() => (A => Unit) => Unit
                Future[A] 	            IO[A]

In comparison with Scala Future, the IO data type preserves 
referential transparency 
even when dealing with side effects and is lazily evaluated. 


//Pure Values IO.pure & IO.unit
You can lift pure values into IO,

def pure[A](a: A): IO[A] = ???

//Example 
IO.pure(25).flatMap(n => IO(println(s"Number is: $n")))

IO.pure is eagerly evaluated, , so donot do this:

IO.pure(println("THIS IS WRONG!"))
Use 
IO.println("THIS IS RIGHT!")

IO.unit is simply an alias for IO.pure(())

val unit: IO[Unit] = IO.pure(())

//Synchronous Effects IO.apply
def apply[A](body: => A): IO[A] = ???

Note the given parameter is passed by name, 
its execution being suspended in the IO context.

import cats.effect._
def putStrLn(value: String) = IO.println(value)
val readLn = IO(scala.io.StdIn.readLine()) //dont use IO.readLine 

val res = for {
  _ <- putStrLn("What's your name?")
  n <- readLn
  _ <- putStrLn(s"Hello, $n!")
} yield ()

import cats.effect.unsafe.implicits.global
res.unsafeRunSync()

///Monad Composition is called Monad Transformer -- ADVANCED 
Functor and Applicative can be composed ie F[G[x]] is 
Functor/Applicative if each one is Functor/Applicative such that we can 
apply map and ap on FG instance instead of individual application 

//Quick revision 
Functor[F[_]].compose[G[_]: Functor]: Functor[({type f[x]=F[G[x]]})#f] =  {   
        val F = this
        val G = implicitly[Functor[G]]
        new Functor[({type f[x]=F[G[x]]})#f] {
            override def map[A, B](fga: F[G[A]])(f: A => B): F[G[B]] =
                F.map(fga)(ga => G.map(ga)(f))
        }
    }
    
Applicative[F[_]].compose[G[_]]( implicit  G: Applicative[G]): Applicative[({type f[x] = F[G[x]]})#f] = {
    val F = this
    def fab[A, B]: G[A => B] => G[A] => G[B] = (gf: G[A => B]) => (ga: G[A]) => G.ap(gf)(ga)
    def fg[B, A](f: F[G[A => B]]): F[G[A] => G[B]] = F.map(f)(gab => fab(gab) )

    new Applicative[({type f[x] = F[G[x]]})#f] {
      def pure[A](a: A) = F.pure(G.pure(a))
      override def ap[A, B](f: F[G[A => B]])(a: F[G[A]]): F[G[B]] =
        F.ap(fg(f) /*F[G[A] => G[B]]*/ )(a)
    }
  }
  
In General, Monads do not compose , but many common Monads  do - called monad transformer.

eg Cats has an OptionT[F[_], A]  monad transformer which is for 
F[Option[A]] (insideout) and also has a lot of useful functions 

//Example implementation from cats 
import cats._
import cats.implicits._

case class OptionT[F[_], A](value: F[Option[A]])

implicit def optionTMonad[F[_]](implicit F: Monad[F]): Monad[OptionT[F, *]] = {
  new Monad[OptionT[F, *]] {
    def pure[A](a: A): OptionT[F, A] = OptionT(F.pure(Some(a)))
    def flatMap[A, B](fa: OptionT[F, A])(f: A => OptionT[F, B]): OptionT[F, B] =
      OptionT {
        F.flatMap(fa.value) { /*Option[A]*/
          case None => F.pure(None)
          case Some(a) => f(a).value
        }
      }

    def tailRecM[A, B](a: A)(f: A => OptionT[F, Either[A, B]]): OptionT[F, B] =
      OptionT {
        F.tailRecM(a)(a0 => F.map(f(a0).value) {
          case None => Either.right[A, Option[B]](None)
          case Some(b0) => b0.map(Some(_))
        })
      }
  }
}

///Monad Transformers - Examples from Cats 

//Ref 
OptionT
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/OptionT.scala

EitherT 
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/EitherT.scala

//example 
import cats._ 
import cats.implicits._ 
import cats.data._ 

type ListOption[A] = OptionT[List, A]  //List[Option [A]]

val a = 10.pure[ListOption]
// ListOption[Int] = OptionT(List(Some(10)))

ErrorOrOption is a monad,
We can use pure, map, and flatMap as usual to create and transform instances:

OptionT[List,Int](List(Some(10), Some(11))).map{(x:Int) => x + 1 }
//OptionT(List(Some(11), Some(12)))

OptionT[List,Int](List(Some(10), Some(11))).flatMap{(x:Int) => (x + 1).pure[ListOption] }
//OptionT(List(Some(11), Some(12)))

//Another example 
type ErrorOr[A] = Either[String, A]
type ErrorOrOption[A] = OptionT[ErrorOr, A]     //Either[String, Option[A]]

ErrorOrOption is a monad
We can use pure, map, and flatMap as usual to create and transform instances:

val b = 32.pure[ErrorOrOption]
// b: ErrorOrOption[Int] = OptionT(Right(Some(32)))

val a = OptionT[ErrorOr, Int](Right(Some(10)))

//flatMap/map has access to inner value , here Int 
val c = a.flatMap( (x:Int) => b.map((y:Int) => x + y))
//OptionT(Right(Some(42)))

//OR Cuts accross all layers 
val c = for {
 x <- a 
 y <- b
 } yield x+y //OptionT[ErrorOr, Int]
 
//value: F[Option[A]], F=ErrorOr
c.value 
//Right(Some(42))

// Mapping over the Either in the stack:
c.value.map(_.getOrElse(-1))
// res5: Either[String, Int] =  Right(42)

//Some more examples 
import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.duration._


type ListOption[A] = OptionT[List, A]  //List[Option[A]]

//ListOption[Either[String,A]]   == List[Option[Either[String,A]]]
type ListOptionEither[A] = EitherT[ListOption, String, A] //-- insideOUT 

//using kind projector. Note first arg must be F[_] ie higher kind 
type ListOptionEither2[A] = EitherT[OptionT[List,*], String, A]  

//check 
implicitly[ListOptionEither[Int] =:= ListOptionEither2[Int]]  //OK 


val c = 10.pure[ListOptionEither]
//EitherT(OptionT(List(Some(Right(10)))))= List(Some(Right(10)))

c.map{ (x:Int) => println(x) }
//10 

//More - Note .lifF takes inner F[_] and then converts to outer MonadT
//whereas pure takes complete type parameter and operates on innermost Actual value
OptionT.liftF[List, Int](List(10, 11))
//OptionT(List(Some(10), Some(11)))

val d  = EitherT.liftF[OptionT[List,*], String, Int] ( OptionT.liftF[List, Int](List(10, 11)))
//EitherT(OptionT(List(Some(Right(10)), Some(Right(11)))))

d.map{ (x:Int) => { println(x); x}}
//10
//11 


//Some more examples 
//List[Either[String,Option[A]]]  -- insideOUT , but EitherT is another Monad Transformer 
type ListEitherOption[A] = OptionT[EitherT[List, String, *], A]
//OR 
type ListEitherOption2[A] = OptionT[({type F[X]=EitherT[List, String, X]})#F, A]


val d = 10.pure[ListEitherOption]
//OptionT(EitherT(List(Right(Some(10))))) = So really List(Right(Some(10)))

d.map{ (x:Int) => println(x); x }
//10 

//More 
OptionT.liftF[EitherT[List, String, *], Int]( EitherT.liftF[List, String, Int]( List(10,11)))
//OptionT(EitherT(List(Right(Some(10)), Right(Some(11)))))



//List[Option[Option[Either[String,A]]]]
type Some[A] = EitherT[OptionT[OptionT[List, *],*], String, A]

val f = 10.pure[Some]
//EitherT(OptionT(OptionT(List(Some(Some(Right(10))))))) = So really List(Some(Some(Right(10))))

f.map{ (x:Int) => println(x) }
//10 
EitherT.liftF[OptionT[OptionT[List, *],*], String, Int] ( 
    OptionT.liftF[OptionT[List, *], Int](
        OptionT.liftF[List, Int](List(10, 11))))
//EitherT(OptionT(OptionT(   List(Some(Some(Right(10))), Some(Some(Right(11))))   )))




//List[Option[Either[String,Option[A]]]]  <-- insideOUT , inner Option -> outer OPtionT , then Either 
type Some2[A] = OptionT[EitherT[OptionT[List, *],String, *],  A]

val f = 10.pure[Some2]
//OptionT(EitherT(OptionT(List(Some(Right(Some(10))))))) = So really List(Some(Right(Some(10))))

f.map{ (x:Int) => println(x);x }
//10 

OptionT.liftF[EitherT[OptionT[List, *],String, *],  Int](
    EitherT.liftF[OptionT[List, *],String, Int](
        OptionT.liftF[List, Int] ( List(10,11) )))
//OptionT(EitherT(OptionT(   List(Some(Right(Some(10))), Some(Right(Some(11))))   )))



//Note 
Note we dont have ListT or FutureT or TryT so these Monad can not be outer Transformer

So below are not possible 
List[Option[Either[String,List/*NOT OK*/[Option[A]]]]]

Requires (inside out)
OptionT[ListT/*NOT OK*/[EitherT[OptionT[List, *],String, *], *],  A]

///CustomClass for Monad  Transformer -- ADVANCED 

//Usage 
import cats._ 
import cats.implicits._ 
import cats.data._ 


type MyBoxOption[A] = OptionT[MyBox, A]  //MyBox[Option[A]]

MyBoxT[List,Int](List(MyBox(10), MyBox(11))).map{(x:Int) => x + 1 }
// MyBoxT(List(MyBox(11), MyBox(12)))

MyBoxT[List,Int](List(MyBox(10), MyBox(11))).flatMap{(x:Int) => (x + 1).pure[MyBoxT[List,*]] }
//MyBoxT(List(MyBox(11), MyBox(12)))


//ListOption[MyBox[String,A]]   == MyBox[Option[Either[String,A]]]
type MyBoxOptionEither[A] = EitherT[MyBoxOption, String, A] //-- insideOUT 

//using kind projector. Note first arg must be F[_] ie higher kind 
type MyBoxOptionEither2[A] = EitherT[OptionT[MyBox,*], String, A]  

//check 
implicitly[MyBoxOptionEither[Int] =:= MyBoxOptionEither2[Int]]  //OK 


val c = 10.pure[MyBoxOptionEither]
//EitherT(OptionT(MyBox(Some(Right(10)))))
c.map{ (x:Int) => println(x) }
//10

//Using MyBoxT[F[_], A]
type OptionMyBox[A] = MyBoxT[Option, A]  //Option[MyBox[A]]

val c = 10.pure[OptionMyBox]
//val c: OptionMyBox[Int] = MyBoxT(Some(MyBox(10)))

c.map{ (x:Int) => println(x) }

//using kind projector. Note first arg must be F[_] ie higher kind 
type OptionMyBoxTEither[A] = EitherT[MyBoxT[Option,*], String, A]  

val c = 10.pure[OptionMyBoxTEither]
//EitherT(MyBoxT(Some(MyBox(Right(10)))))

c.map{ (x:Int) => println(x) } //ambiguous, extending needs to be corrected 

c.map{ (x:Int) => println(x) }(MyBoxT.myDataMonadForMyBoxT)


//Custom Transformer - MyBoxT 

import cats._ 
import cats.implicits._ 

case class MyBox[T](val value:T) {
   override def toString() = "MyBox("+value+")"
}

object MyBox {
    implicit val MyBoxTraverse = new Traverse[MyBox] with Monad[MyBox] with Foldable[MyBox] {
        def traverse[G[_]: Applicative, A, B](fa: MyBox[A])(f: A => G[B]): G[MyBox[B]] = 
             //def map[A,B](in: G[A])(f: A => B): G[B]
             Applicative[G].map(f(fa.value))((b:B) => MyBox(b)) //MyBox(_)
        //requires Foldable - copy from old 
        def foldLeft[A, B](fa: MyBox[A], b: B)(f: (B, A) => B): B  = f(b, fa.value)            
        //note fn arg is reversed 
        def foldRight[A, B](fa: MyBox[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B] =  
                Eval.defer(f(fa.value, lb) )
                
        //Monad 
        def flatMap[A,B](a: MyBox[A])(f:A => MyBox[B]): MyBox[B] = MyBox( f(a.value).value)
        def pure[A](a: A): MyBox[A]  = MyBox(a)
        //for cats 
        //TCO 
        @annotation.tailrec 
        def tailRecM[A, B](a: A)(f: A => MyBox[Either[A,B]]): MyBox[B] = f(a).value match {
            case Right(b) => pure(b)
            case Left(a) => tailRecM(a)(f)        
        }
    }
}


object MyBoxT extends MyBoxTInstances1 {

  def pure[F[_], A](a: A)(implicit F: Applicative[F]): MyBoxT[F, A] =
    MyBoxT(F.pure(MyBox(a)))
    
  def liftF[F[_], A](fa: F[A])(implicit F: Applicative[F]): MyBoxT[F, A] = 
    MyBoxT(F.map(fa)(a => MyBox(a)))
}


case class MyBoxT[F[_], A](value: F[MyBox[A]]) {   

  def map[B](f: A => B)(implicit F: Functor[F]): MyBoxT[F, B] =
    //F[A].map[A, B](f: A => B): F[B]
    MyBoxT(F.map(value)(mybox => mybox.map(f)))
    
  def flatMap[B](f: A => MyBoxT[F, B])(implicit F: Monad[F]): MyBoxT[F, B] =
    //F[A].flatMap[A, B](f: A => F[B]): F[B]
    MyBoxT(F.flatMap(value)(mybox => f(mybox.value).value))  
    
  def ap[B](f: MyBoxT[F, A => B])(implicit F: Applicative[F]): MyBoxT[F, B] =
    //def F[A].ap[A, B](ff: F[A => B]): F[B]
    //F[A].map[A, B](f: A => B): F[B]
    MyBoxT.liftF(F.ap(F.map(f.value)(myboxFn => myboxFn.value))( F.map(value)(mybox => mybox.value)))
    
  def traverse[G[_], B](f: A => G[B])(implicit F: Traverse[F], G: Applicative[G]): G[MyBoxT[F, B]] =
    //F[A].traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]
    G.map(F.compose(Traverse[MyBox]).traverse(value)(f))(MyBoxT.apply)

  def foldLeft[B](b: B)(f: (B, A) => B)(implicit F: Foldable[F]): B =
    F.compose(Foldable[MyBox]).foldLeft(value, b)(f)

  def foldRight[B](lb: Eval[B])(f: (A, Eval[B]) => Eval[B])(implicit F: Foldable[F]): Eval[B] =
    F.compose(Foldable[MyBox]).foldRight(value, lb)(f)  
}

trait MyBoxTFunctor[F[_]] extends Functor[MyBoxT[F, *]] {
  implicit val F0: Functor[F]

  override def map[A, B](fa: MyBoxT[F, A])(f: A => B): MyBoxT[F, B] =
    fa.map(f)
}

trait MyBoxTApplicative[F[_]] extends Applicative[MyBoxT[F, *]]  {
  implicit val F0: Applicative[F]

  def pure[A](a: A): MyBoxT[F, A] = MyBoxT.pure(a)
  
  def ap[A, B](ff: MyBoxT[F, A => B])(fa: MyBoxT[F, A]): MyBoxT[F, B] = fa.ap(ff)
}

trait MyBoxTMonad[F[_]] extends Monad[MyBoxT[F, *]] {
  implicit val F0: Monad[F]
  
  def pure[A](a: A): MyBoxT[F, A] = MyBoxT.pure(a)
  
  def flatMap[A, B](fa: MyBoxT[F, A])(f: A => MyBoxT[F, B]): MyBoxT[F, B] =
    fa.flatMap(f)

  def tailRecM[A, B](a: A)(f: A => MyBoxT[F, Either[A, B]]): MyBoxT[F, B] =
    //F[A].tailRecM[A, B](a: A)(f: A => F[Either[A,B]]): F[B]
    MyBoxT.liftF(F0.tailRecM(a)(f(_).value.map(mybox => mybox.value)))
}


trait MyBoxTFoldable[F[_]] extends Foldable[MyBoxT[F, *]] {
  implicit val F0: Foldable[F]

  def foldLeft[A, B](fa: MyBoxT[F, A], b: B)(f: (B, A) => B): B =
    fa.foldLeft(b)(f)

  def foldRight[A, B](fa: MyBoxT[F, A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B] =
    fa.foldRight(lb)(f)
}

trait MyBoxTTraverse[F[_]] extends Traverse[MyBoxT[F, *]] with MyBoxTFoldable[F] with MyBoxTFunctor[F] {
  implicit val F0: Traverse[F]

  def traverse[G[_]: Applicative, A, B](fa: MyBoxT[F, A])(f: A => G[B]): G[MyBoxT[F, B]] =
    fa.traverse(f)
}



class MyBoxTInstances1 {
  
  implicit def myDataTraverseForMyBoxT[F[_]](implicit F: Traverse[F]): Traverse[MyBoxT[F, *]] =
    new MyBoxTTraverse[F] { implicit val F0: Traverse[F] = F }
    
  implicit def myDataMonadForMyBoxT[F[_]](implicit F: Monad[F]): Monad[MyBoxT[F, *]] =
    new MyBoxTMonad[F] { implicit val F0: Monad[F] = F }

  implicit def myDataFoldableForMyBoxT[F[_]](implicit F: Foldable[F]): Foldable[MyBoxT[F, *]] =
    new MyBoxTFoldable[F] { implicit val F0: Foldable[F] = F }    
   
  implicit def myDataApplicativeForMyBoxT[F[_]](implicit F: Applicative[F]): Applicative[MyBoxT[F, *]] =
    new MyBoxTApplicative[F] { implicit val F0: Applicative[F] = F }    
   
  implicit def myDataFunctorForMyBoxT[F[_]](implicit F: Functor[F]): Functor[MyBoxT[F, *]] =
    new MyBoxTFunctor[F] { implicit val F0: Functor[F] = F }
}













/// Monad Transformer - Complex Exercise: Autobots (ADVANCED)
The Autobots, wellknown robots in disguise, frequently send messages through unpredictable channel
during battle requesting the power levels of their team mates. 

//Example 
import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._


type Response[A] = EitherT[Future, String, A] //Future[Either[String,A]]

val powerLevels = Map(
  "Jazz"       -> 6,
    "Bumblebee" -> 8,
    "Hot Rod"       -> 10
)
 
def getPowerLevel(ally: String): Response[Int] = {
    powerLevels.get(ally) match {
        case Some(avg) =>  EitherT.right(Future(avg))
        case None       => EitherT.left(Future(s"$ally unreachable"))
    }
}

//Two autobots can perform a special move if their combined power level is greater than 15. 
def canSpecialMove(ally1: String, ally2: String): Response[Boolean] =
 for {
     power1 <- getPowerLevel(ally1)
     power2 <- getPowerLevel(ally2)
 } yield (power1 + power2) > 15


 def tacticalReport(ally1: String, ally2: String): String = {
     val stack = canSpecialMove(ally1, ally2).value //Future[Either[String,A]]

     Await.result(stack, 1.second) match {
         case Left(msg) =>
           s"Comms error: $msg"
         case Right(true)    =>
           s"$ally1 and $ally2 are ready to roll out!"
         case Right(false) =>
           s"$ally1 and $ally2 need a recharge."
     }
 }


tacticalReport("Jazz", "Bumblebee")
// res13: String = "Jazz and Bumblebee need a recharge."
tacticalReport("Bumblebee", "Hot Rod")
// res14: String = "Bumblebee and Hot Rod are ready to roll out!"
tacticalReport("Jazz", "Ironhide")
// res15: String = "Comms error: Ironhide unreachable"



///Complex Monad Transformer Stack  -- ADVANCED 
//Given 
case class ReaderT[F[_], -A, B](run: A => F[B])
case class WriterT[F[_], L, V](run: F[(L, V)])
case class StateT[F[_], S, A](val runF: F[S => F[(S, A)]]) 

type Reader[E, A] = ReaderT[Id, E, A] 
type Writer[W, A] = WriterT[Id, W, A]
type State[S, A]   = StateT[Eval, S, A]


Can we combine all and create 

State[List[String],Reader[ Map[String,String], Writer[Vector[String], String]]]
//or 
WriterT[ReaderT[State[List[String],*], Map[String,String], *], Vector[String], String]

such that an application can have access to immutable state, Configuration and Writer?

//Synopsis 
StateT[Eval, state, computation]
    Here 
    state = List[String]
    val step = State[state, computation] { oldstate =>
         val newstate = someTransformation(oldstate)
         val result    = someCalculation
         (newstate, result)
     }
    val (state, result) = step.run(initialStep).value


ReaderT[F[_], config, ReaderValue]
    Here 
    config = Map[String,String]
    val rs: Reader[config, ReaderValue] =
       Reader{ config => ReaderValue}


WriterT[F[_], Log, String ]
    Here 
    Log = Vector[String]

//State of Reader of Writer of String 
//so inside out 

type StateList[A] = State[List[String],A]  //S
type ReaderState[A] = ReaderT[StateList,  Map[String,String], A]   //RS
type WriterReaderState[A] = WriterT[ReaderState, Vector[String], A]  //WRS
//State[List[String],Reader[ Map[String,String], Writer[Vector[String], String]]]

//OR Alternate 
type Alternate[A] = WriterT[ReaderT[State[List[String],*],  Map[String,String], *], Vector[String], A]

//check 
implicitly[Alternate[String] =:= WriterReaderState[String]] //OK 


//pure takes only F[_] type param 
10.pure[StateList]              //State[List[String],Int]
10.pure[ReaderState]            //State[List[String],Reader[ Map[String,String], Int]]
10.pure[WriterReaderState]      //State[List[String],Reader[ Map[String,String], Writer[Vector[String], Int]]]


//Understanding StateList 
StateT 
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/IndexedStateT.scala

//example 
10.pure[StateList] //StateList[Int]

val step1 = State[List[String],Int]{ lstStringState =>    //oldstate
     val ans = "STEP1" :: lstStringState
     (ans, 10)   //(newState, value)
}

val step2 = State[List[String],Int]{ lstStringState =>
     val ans = "STEP2" :: lstStringState
     (ans, 20)
}

//map only has access of Value, flatMap has access of State and Value 
val both = for {
     a <- step1 // Get Value 
     b <- step2
} yield (a, b)


val (state, result) = both.run(Nil/*initialState*/).value
//val state: List[String] = List(STEP2, STEP1)
//val result: (Int, Int) = (10,20)

val steps = List( step1, step2)

val alsteps = steps.foldLeft(10.pure[StateList]){ (accum, step) =>
        accum.flatMap{ (accumV:Int) /*value*/ => 
            print(s"accumV=$accumV")
            step.map{ (stepV:Int) /*value*/ => 
                  println(s" stepV=$stepV ret=${accumV+stepV}")
                  accumV + stepV
                }
        }
    }

val (state, result) = alsteps.run(Nil).value
//output 
accumV=10 stepV=10 ret=20
accumV=20 stepV=20 ret=40
val state: List[String] = List(STEP2, STEP1)
val result: Int = 40


//Understanding ReaderState - Reader[ Map[String,String], StateList] 
ReaderT
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/Kleisli.scala

//example 
10.pure[ReaderState] //ReaderT[State[List[String],*],  Map[String,String], Int] 

//ReaderT returns State 
def rs(msg:String) =  ReaderT[StateList, Map[String,String], Int]{ mapConf /*conf*/ =>
              State[List[String],Int]{ lstStringState /*state*/ => 
                     val newState = msg :: lstStringState
                     //I can access mapConf here 
                     (newState, 10)
                    }
              }       
    
val value = for {
    value1 <- rs("STEP1")     // value:Int , comes from (newState, value) line of nested State 
    value2 <- rs("STEP2")
} yield s"${value1 * value2}"   //10*10 = 100
//ReaderT[StateList, Map[String,String],String]

value.run(Map("OK"->"OKVALUE")) //execute ReaderT 
//StateList[String] 

val (state, result) = value.run(Map("OK"->"OKVALUE")).run(Nil/*initialState*/).value 
//val state: List[String] = List(STEP1, STEP2)
//val result: String = 100


//Understanding WriterReaderState - State[List[String],Reader[ Map[String,String], Writer[Vector[String], A]]]
//Recall 
type StateList[A] = State[List[String],A]  //S
type ReaderState[A] = ReaderT[StateList,  Map[String,String], A]   //RS
type WriterReaderState[A] = WriterT[ReaderState, Vector[String], A]  //WRS

//ref 
WriterT 
    https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/WriterT.scala

    
//Example 
10.pure[WriterReaderState]
//State[List[String],Reader[ Map[String,String], Writer[Vector[String], Int]]]

def inner_rs(msg:String) =  ReaderT[StateList, Map[String,String], Int]{ mapConf =>
        State[List[String],Int]{ lstStringState => 
             val newState = msg :: lstStringState
             //I can access mapConf here              
             (newState, 10)
            }
       }
       

       
//liftF[F[_], L, V](fv: F[V])(implicit monoidL: Monoid[L], F: Applicative[F]): WriterT[F, L, V]
val ws = WriterT.liftF[ReaderState, Vector[String], Int](inner_rs("STEP1"))
//WriterT[ReaderState,Vector[String],Int]


//tell(l: L)(implicit functorF: Functor[F], semigroupL: Semigroup[L]): WriterT[F, L, V] 
ws.tell(Vector("x", "y", "z"))
//WriterT[ReaderState,Vector[String],Int]

val writer1 = for {
   a <- 10.pure[WriterReaderState]      //a=10
   b <- ws.tell(Vector("x", "y", "z"))  //b=10 from (newState, 10)
 } yield a + b
//WriterT[RT,Vector[String],Int]

val (state, (log, result)) = writer1.run/*WriterT*/.run( Map("OK"->"OKVALUE") )/*ReaderT*/.run(Nil/*initialState*/)./*Eval[String]*/value 
//output 
val state: List[String] = List(STEP1)
val log: Vector[String] = Vector(x, y, z)
val result: Int = 20



//Include Log 
def get_config =  ReaderT[StateList, Map[String,String], Map[String,String]]{ mapConf =>
    State[List[String],Map[String,String]]{ lstStringState =>           
         (lstStringState, mapConf)
        }
   }
   
def get_state =  ReaderT[StateList, Map[String,String], List[String]]{ mapConf =>
    State[List[String],List[String]]{ lstStringState =>           
         (lstStringState, lstStringState)
        }
   }
def set_state(newState:List[String]) =  ReaderT[StateList, Map[String,String], Unit]{ mapConf =>
    State[List[String],Unit]{ lstStringState =>           
         (newState, ())
        }
   }
            
       
    
def demo: WriterReaderState[String] = for {
        value1 <- ws     
        state1 <- WriterT.liftF[ReaderState, Vector[String], List[String]](get_state)
        conf <- WriterT.liftF[ReaderState, Vector[String], Map[String,String]](get_config)
        
        // put[F[_], L, V](v: V)(l: L)(implicit applicativeF: Applicative[F]): WriterT[F, L, V]
        //value[F[_], L, V](v: V)(implicit applicativeF: Applicative[F], monoidL: Monoid[L]): WriterT[F, L, V]
        //tell[F[_], L](l: L)(implicit applicativeF: Applicative[F]): WriterT[F, L, Unit]
        _ <- WriterT.tell[ReaderState,Vector[String]](Vector(s"currentConfig = $conf"))
        _ <- WriterT.tell[ReaderState,Vector[String]](Vector(s"currentState = $state1"))
        
        value2 <- WriterT.liftF[ReaderState, Vector[String], Int](inner_rs("STEP2"))
        _ <- WriterT.tell[ReaderState,Vector[String]](Vector(s"nextValue = $value2"))
    } yield s"${value1*value2}"

val (state, (log, result)) = demo.run/*WriterT*/.run( Map("OK"->"OKVALUE") )/*ReaderT*/.run(Nil/*initialState*/)./*Eval[String]*/value 
//output 
val state: List[String] = List(STEP2, STEP1)
val log: Vector[String] = Vector(currentConfig = Map(OK -> OKVALUE), currentState = List(STEP1), nextValue = 10)
val result: String = 100






///More on Free Monad  concepts -- ADVANCED 
For example, by working entirely through the Some and None markers, 
the Option monad is in fact a free monad. 

sealed trait Option[+A]{
    def get: A
    def isEmpty: Boolean = this eq None
    def pure[A](a: A): Option[A] = Option(a)
    
    def flatMap[B](f: A => Option[B]): Option[B] = if (isEmpty) None else f(this.get)
    def map[B](f: A => B): Option[B] =  if (isEmpty) None else Some(f(this.get))
    def ap[A, B](a: F[A])(ff: F[A => B]): F[B] = flatMap(ff)(f => map(a)(f))
}
object Option {
    def apply[A](x: A): Option[A] = if (x == null) None else Some(x)
}

final case class Some[+A](value: A) extends Option[A] {
  def get: A = value
}
case object None extends Option[Nothing] {
  def get: Nothing = throw new NoSuchElementException("None.get")
}

The List monad, on the other hand, is not a free monad 
since it brings extra, specific facts about lists (like append) into its definition

The free monad has advantages
    Gluing the computations together as classes happens in a heap and saves stack  memory.
    
    It is possible to pass the computation over to different parts of the code and the
    side-effects will be deferred until it is explicitly run.    
   
    represent stateful computations as data, and run them

    build an embedded DSL (domain-specific language)
    
    retarget a computation to another interpreter using natural transformations
    (In Cats, the type representing a free monad is abbreviated as Free[_])
    
The disadvantages lie in the same plane as they do for monads. These include additional
initial implementation effort, runtime overhead for the garbage collector, and processing
additional instructions and mental overhead for developers new to the concept.


///Free Monad - Example Console program 
We want to build Monad for Console programs consting of three instructions 
Return, PrintLine and ReadLine 

Note Free Monad is internally a Nested data structure and flatMapping is recursively evaluating it 
In our case, we need to build similar to 

val example1: Console[Unit] = 
  PrintLine("Hello, what is your name?",
    ReadLine(name =>
      PrintLine(s"Good to meet you, ${name}", Return(() => ())))
)


//Create ADT 
sealed trait Console[+A]

//Similar to Pure 
final case class Return[A](value: () => A) extends Console[A]  // pure or lift functionality 

//rest:Console[A] = provision for Nested structure 
final case class PrintLine[A](line: String, rest: Console[A]) extends Console[A]

//for any input , model as Fn whose arg (eg here String) is input, 
//and rest:nested Structure is modeled as fn return 
final case class ReadLine[A](rest: String => Console[A]) extends Console[A]


//STEP-1: Create Smart Methods - Return type is important which returns LHS in for comprehension 

//This is equaivalent to Monad Pure 
def succeed[A](a: => A): Console[A] = Return(() => a)

def printLine(line: String): Console[Unit] =
  PrintLine(line, succeed(()))    //return is Unit , lift it into Console[A]
  
val readLine: Console[String] =
  ReadLine(line => succeed(line))
  
//STEP-2: implement Monad with those case classes 
//extension method on Console[A]
implicit class ConsoleSyntax[+A](self: Console[A]) {
  def map[B](f: A => B): Console[B] =
    flatMap(a => succeed(f(a)))

  def flatMap[B](f: A => Console[B]): Console[B] =
    //each case must return Console[B] ie some way to call f(A)
    self match {
      case Return(value) => f(value())  //value() return A 
      case PrintLine(line, next) =>
        PrintLine(line, next.flatMap(f))  //next:Console[A] //recursive
      case ReadLine(next) =>
        ReadLine(line => next(line).flatMap(f))  //next(String) returns Console[A]
    }
}
//STEP-3: We can write program 
val consoleProgram: Console[String] =
  for {
    _    <- printLine("Whats your name?")
    name <- readLine
    _    <- printLine(s"Hello, ${name}, good to meet you!")
  } yield name  //this is Return(()=> name) or  succeed(name)
//val consoleProgram: Console[String] = 
//PrintLine(Whats your name?,ReadLine(lambda,PrintLine(Hello, ${name}, good to meet you!)))

//STEP-4: To execute above program, we need to write interpretor
//Different interpretor can be written based on requirement 
def run[A](program: Console[A]): A = program match {
  case Return(value) => 
    value()
  case PrintLine(line, next) => 
    println(line)
    run(next)
  case ReadLine(next) =>
    // Can use readChar(): Char 
    val value = scala.io.StdIn.readLine()
    println(value)
    run(next(value))
}

run(consoleProgram)
//Das

//input taking from List and output to List
def run2[A](program: Console[A], inputs:List[String], out:List[A]): List[A] = program match {
  case Return(value) => 
    value()
    out 
  case PrintLine(line, next) => 
    println(line)
    run2(next, inputs, out)
  case ReadLine(next) =>
    val value = inputs.head
    println(value)
    run2(next(value), inputs.tail, out :+ value.asInstanceOf[A] )
}

run2(consoleProgram, List("DAS"), List.empty[String])


//Using cats-free 
Use below 
libraryDependencies += "org.typelevel" %% "cats-free" % "2.4.2"

Using below methods 
Free
    def pure[F[_], A](a: A): Free[F, A]             //lifts a to Free
    def liftF[F[_], A](value: F[A]): Free[F, A]     //lifts F[_] to Free

Free[F[_], A] 
    def map[B](f: A => B): Free[F, B] 
    def flatMap[B](f: A => Free[F, B]): Free[F, B] 
    //converts F to any known Monad M 
    def foldMap[M[_]](f: FunctionK[F, M])(implicit M: Monad[M]): M[A] 
    
FunctionK[F,G] or F ~> M 
    def apply[A](arg:F[A]):G[M]
        Similar to Function1[-T,+R] but now for higher kinded type 
    

//Example 
//Step1- : Create ADT, extends clause must reflect the Actual Return in for comprehension
//(remove provision for nested structure)

sealed trait Console[+A]
//pure comes from Free[F[_],A], so no need to write 
final case class PrintLine(line: String) extends Console[Unit] 
final case class ReadLine() extends Console[String]

//STEP-2: Create Free Monad and smart constructor using liftF 
import cats._ 
import cats.implicits._ 
import cats.data._ 
import cats.free._ 


//Free[F[_], A]
type ConsoleMonad[A] = Free[Console, A]

//Create smart constructors using Free.liftF[F[_], A](value: F[A]): Free[F, A]  
//to lift Console[_] to ConsoleMonad
//Return type should exact match with ADT extends clause , only now ConsoleMonad

def printLine(line: String): ConsoleMonad[Unit] =
  Free.liftF[Console, Unit](PrintLine(line))
  
val readLine: ConsoleMonad[String] =
  Free.liftF[Console, String](ReadLine())

//Step3: Create program 
def program: ConsoleMonad[String] =
  for {
    _    <- printLine("Whats your name?")
    name <- readLine
    _    <- printLine(s"Hello, ${name}, good to meet you!")
  } yield name

//Step4- create Compiler, by Console~>Id, one known Monad (could be List, .. any Monad)
//Would be used with Free[F[_], A].foldMap[M[_]](f: FunctionK[F, M])(implicit M: Monad[M]): M[A] 
def interpret: Console ~> Id  =
  new (Console ~> Id) {  // Console[A] => Id[A]
    def apply[A](fa: Console[A]): Id[A] =
      fa match {
          case PrintLine(line) => 
            println(line)
            ()                  //Must match with  ' extends Console[Unit] '
          case ReadLine() =>            
            val input = scala.io.StdIn.readLine()
            println(input)
            input               //Must match with  ' extends Console[String] '
      }
  }
  
//STEP5. Run your program
//Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
//In our case M = Id and S=Console 

val result = program.foldMap(interpret)
//cats.Id[String] = Das

//collect toList 
def interpret2: Console ~> List  =
  new (Console ~> List) {  // Console[A] => Id[A]
    def apply[A](fa: Console[A]): List[A] =
      fa match {
          case PrintLine(line) => 
            println(line)
            List[A]( () )                         //Must match with  ' extends Console[Unit] '
          case ReadLine() =>            
            val input = scala.io.StdIn.readLine()
            println(input)
            List[A](input.asInstanceOf[A])        //Must match with  ' extends Console[String] '
      }
  }

val result = program.foldMap(interpret2)


///More Examples of Free Monad  using cats-free - ADVANCED 
Let imagine that we want to create a DSL for a key-value store. 
    put a value into the store, associated with its key.
    get a value from the store given its key.
    delete a value from the store given its key.

For example:

put("toto", 3)
get("toto") // returns 3
delete("toto")

//STEP1-Create an ADT representing your grammar

sealed trait KVStore[A]

//Note output of any action is part of 'extends KVStore[OUTPUT]'

//Put a value associated with a key into the store
case class Put[T](key: String, value: T) extends KVStore[Unit]

//Get a value associated with a key out of the store
case class Get[T](key: String) extends KVStore[Option[T]]

//Delete a value associated with a key from the store
case class Delete(key: String) extends KVStore[Unit]

    
//STEP2 Create a Free type based on your ADT
import cats._ 
import cats.implicits._ 
import cats.data._ 
import cats.free._ 

//Free[F[_], A]
type KVStoreMonad[A] = Free[KVStore, A]


//STEP2.Create smart constructors using Free.liftF to lift KVStore to KVStoreMonad
//return must match with 'extends KVStore[X]' only here KVStoreMonad[X]

def put[T](key: String, value: T): KVStoreMonad[Unit] =
  Free.liftF[KVStore, Unit](Put[T](key, value))

// Get returns a T value.
def get[T](key: String): KVStoreMonad[Option[T]] =
  Free.liftF[KVStore, Option[T]](Get[T](key))

// Delete returns nothing (i.e. Unit).
def delete(key: String): KVStoreMonad[Unit] =
  Free.liftF(Delete(key))

// Derived, helper Update composes get and set, and returns nothing.
def update[T](key: String, f: T => T): KVStoreMonad[Unit] =
  for {
    vMaybe <- get[T](key) //unwrap KVStoreMonad and get Option[T]
    _ <- vMaybe.map(v => put[T](key, f(v))).getOrElse(Free.pure(()))
  } yield ()

//STEP3.Build a application out of key-value DSL operations.

def program: KVStoreMonad[Option[Int]] =
  for {
    _ <- put("wild-cats", 2)
    _ <- update[Int]("wild-cats", (_ + 12))
    _ <- put("tame-cats", 5)
    n <- get[Int]("wild-cats")
    _ <- delete("tame-cats")
  } yield n

//STEP4. Write a compiler for your program, 

//Implementation-1:  convert KVStore[_] to Id[_]
import scala.collection.mutable

// the program will crash if a key is not found,
// or if a type is incorrectly specified.
def impureCompiler: KVStore ~> Id  =
  new (KVStore ~> Id) {  // KVStore[A] => Id[A]
    val kvs = mutable.Map.empty[String, Any]
    def apply[A](fa: KVStore[A]): Id[A]  =
      fa match {
        case Put(key, value) =>
          println(s"put($key, $value)")
          kvs(key) = value
          ()                        //Must match with X from   ' extends KVStore[X] '
        case Get(key) =>
          println(s"get($key)")
          kvs.get(key)
        case Delete(key) =>
          println(s"delete($key)")
          kvs.remove(key)
          ()
      }
  }

//STEP5. Run your program
//Free[S[_], A].foldMap[M[_]](f: FunctionK[S, M])(implicit M: Monad[M]): M[A] 
//In our case M = Id and S=KVStore

val result: Option[Int] = program.foldMap(impureCompiler)
// put(wild-cats, 2)
// get(wild-cats)
// put(wild-cats, 14)
// put(tame-cats, 5)
// get(wild-cats)
// delete(tame-cats)
// result: Option[Int] = Some(14)


//Another Example of compiler 
//Use a pure compiler (Using another compiler eg State whch is also Monad) 
   
    
type KVStoreState[A] = State[Map[String, Any], A]

val pureCompiler: KVStore ~> KVStoreState = new (KVStore ~> KVStoreState) {
  def apply[A](fa: KVStore[A]): KVStoreState[A] =
    fa match {
      case Put(key, value) => 
        //State.modify[S](f: S => S): State[S, Unit] 
        State.modify(map => map.updated(key, value))  //Map.updated(..):Map
      case Get(key) => 
        //State.inspect[S, T](f: S => T): State[S, T] 
        State.inspect(map => map.get(key))
      case Delete(key) => 
        //State.modify[S](f: S => S): State[S, Unit] 
        State.modify(map => map - key)
        
      //other methods of State 
      //set[S](s: S): State[S, Unit]    
      //get[S]: State[S, S]      
    }
}
//run to run the State 
val result: (Map[String, Any], Option[Int]) = program.foldMap(pureCompiler)/*State*/.run(Map.empty/*initialState*/).value
// result: (Map[String, Any], Option[Int]) = (Map("wild-cats" -> 14), Some(14))



///Actor Props - for passing Actor constructor argument 
import akka.actor.Props

import akka.actor._

class MyActor(magicNumber: Int) extends Actor with ActorLogging {
  import MyActor._
  //def receive: PartialFunction[Any, Unit]
  //Accept Any 
  //In Typed Actor, accept type is a Particular Type, so it can not accept any other type 
  
  //akka.loglevel = "INFO" by default 
  def receive = {
    case Greeting(greeter) => 
            log.info(s"$magicNumber: I was greeted by $greeter.")
            sender() ! "Greeted"
    case Goodbye           => 
            log.info(s"$magicNumber: Someone said goodbye to me.")
            context.stop(self)
  }
}
//RECOMENDED Practice, put props in companion object with below pattern , 
object MyActor {
   def props(magicNumber: Int): Props = Props(new MyActor(magicNumber))
   case class Greeting(from: String)
   case object Goodbye
}

//Example of creation 
import akka.actor.{ActorSystem, Props}

// ActorSystem is a heavy object: create only one per application
val system = ActorSystem("Dummy") //akka://Dummy
val resOne = system.actorOf(MyActor.props(42), "name") //name should unique 
//Actor[akka://Dummy/user/name#115048092]

//OR 
val resTwo =system.actorOf(MyActor.props(42))
//val res2: akka.actor.ActorRef = Actor[akka://Dummy/user/$a#2024249730]

//ActorSystem Important Attributes
https://doc.akka.io/api/akka/current/akka/actor/ActorSystem.html
def dispatcher: ExecutionContextExecutor
def mailboxes: Mailboxes
def scheduler: Scheduler

//Actor Important Attributes 
https://doc.akka.io/api/akka/current/akka/actor/Actor.html
val self: ActorRef
val context: ActorContext

//ActorRef - resOne/resTwo are actorRefs - Important Attributes 
https://doc.akka.io/api/akka/current/akka/actor/ActorRef.html
def path: ActorPath

//ActorContext  - Important Attributes 
https://doc.akka.io/api/akka/current/akka/actor/ActorContext.html
def children: Iterable[ActorRef]
def actorOf(props: Props): ActorRef

//Reference Conf (default values) 
https://doc.akka.io/docs/akka/current/general/configuration-reference.html

//Logging 
https://doc.akka.io/docs/akka/current/logging.html



//Message sending 
at-most-once delivery, i.e. no guaranteed delivery, 
    that message is delivered zero or one time
    For a given pair of actors, messages sent directly from the first to the second 
    will not be received out-of-order.

! , tell
    send a message, 
    Note any message can be sent, eg, Int, String, 
    any user defined Class/object(must be immutable and Serializable)
?,ask 
    Sends a message and wait for result in future
    
resOne ! MyActor.Greeting("Das")  //Response goes to Deadletter 
resTwo ! MyActor.Greeting("Das")

//To handle Response, either send from another Actor or use ask pattern 
import scala.concurrent.duration.*
import akka.pattern.ask

import system.dispatcher //brings ExecutionContext

val future = resOne.ask(MyActor.Greeting("Das"))(5.seconds).mapTo[String] //Future[String]

future.foreach(println) //Greeted
    
//Stopping 
stop            method      
    The actor will continue to process its current message (if any), 
    but no additional messages will be  processed. 
PoisonPill      message     
    A PoisonPill message will stop an actor when the message is processed. 
    A PoisonPill message is queued just like an ordinary message 
    and will be handled after other messages queued  ahead of it in its mailbox.
//Example 
resOne ! PoisonPill
resTwo ! MyActor.Goodbye

import system.dispatcher //brings ExecutionContext
system.terminate().foreach( _ => "Terminated")



///Testing 
https://doc.akka.io/docs/akka/current/testing.html

The TestKit contains an actor named testActor which is the entry point for messages 
to be examined with the various expectMsg... assertions . 

When mixing in the trait ImplicitSender this test actor is implicitly used 
as sender reference when dispatching messages from the test procedure. 

//Example 
import akka.actor._
import akka.testkit._
import org.scalatest.BeforeAndAfterAll
import org.scalatest.matchers.should.Matchers
import org.scalatest.wordspec.AnyWordSpecLike

class MySpec()
    extends TestKit(ActorSystem("Dummy"))
    with ImplicitSender //TestKit.testActor is sender 
    with AnyWordSpecLike //BDD like template 
    with Matchers
    with BeforeAndAfterAll //must be last trait
    {
  
  var actor:ActorRef =   _
  var probe: TestProbe = _

  override def beforeAll() : Unit = {
    actor = system.actorOf(MyActor.props(42)) 
    probe = TestProbe()    
    probe.watch(actor)
  }
  
  override def afterAll(): Unit = {
    TestKit.shutdownActorSystem(system)
  }

  "My First Actor" must {

    "send back Greeted" in {
      actor ! MyActor.Greeting("Das")
      expectMsg("Greeted")
    }
    
    "stop" in {
      import scala.concurrent.duration._
      actor ! MyActor.Goodbye
      probe.expectTerminated(actor)
    }
  }
}
scala> org.scalatest.run(new MySpec())
//In sbt , this must be in src/test/scala folder 
$ sbt test 
//https://www.scalatest.org/user_guide/using_scalatest_with_sbt


///Important testkit method   -- ADVANCED 
import scala.concurrent.duration._

val hello: String = expectMsg("hello")
val any: String = expectMsgAnyOf("hello", "world")
val all: immutable.Seq[String] = expectMsgAllOf("hello", "world")
val i: Int = expectMsgType[Int]                 //Conforms to Int 
expectNoMessage(200.millis)
val two: immutable.Seq[AnyRef] = receiveN(2)    //Receive N messages in a row
expectMsg(500.millis, "hello")                  //with Timeout 

///Helper Functions -- copy src/main/scala/actorhelper.scala -- ADVANCED 
import akka.actor._
import scala.util._

object ActorHelper{
    import scala.concurrent._
    import scala.concurrent.duration._
    
    def process(system: ActorSystem)(createActors: ActorSystem=>Seq[ActorRef])
            (stopActors:(ActorSystem, Seq[ActorRef])=>Unit)
            (body: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        val actors = createActors(system)
        println(s"Created: ${actors.map(_.toString).mkString("(",",",")")}")
      
        import system.dispatcher //brings ExecutionContext 
        body(system, actors).andThen{
            case x => 
                println(s"Stopping, body returned $x")
                stopActors(system,actors)
                x
          }
    }   
    def processSeq( system: ActorSystem, propNames:Seq[(String, Props)], stopMessage:Iterator[Any] =Iterator.continually(PoisonPill) )(sendfn: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]  = {
        process(system){system => 
            propNames.map{case (n,p) => system.actorOf(p, n)}
          }{ (system, seq) =>
            seq.zip(stopMessage).foreach{ case(a, m) => a ! m} 
          }{(system, seq) => 
            sendfn(system, seq)
        }
    }    
    
    def processOne( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system){system => 
            Seq(system.actorOf(props, "name"))}{ (system, seq) =>
                seq.head ! stopMessage }{  (system, seq) => 
                    sendfn(system, seq.head)
                }
    }    
    def processWithTestProb(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef, ActorRef) => Future[Any] ):Future[Any]  = {
      processSeq(system, Seq(("name", props)/*actor*/, ("testprob", Props(new TestProb))/*sender*/), 
        Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor, sender) = seqs 
            sendfn(system, actor, sender)/*Future*/.transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                    sender ! PoisonPill
                })
            }
        }
    }
    def processWithoutStop(system: ActorSystem, props:Props)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        processSeq(system, Seq(("name", props)), Iterator.continually(ActorStop.FAKESTOP)){(system, seqs) =>
            import system.dispatcher
            val Seq(actor) = seqs 
            sendfn(system, actor).transform{ case x =>
                println(s"Output: $x")
                Try(() => {
                    actor ! PoisonPill
                })
            }
        }
    }
    
    def processName( system: ActorSystem, props:Props, actorName: String, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]  = {
        process(system)(system => Seq(system.actorOf(props, actorName)))( (system, seq) =>seq.head ! stopMessage ){
            (system, seq) => sendfn(system, seq.head)
        }
    }

    
    def findActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds):Future[ActorRef] =     
        system.actorSelection(prefix+name).resolveOne(duration)
        
    def stopActor(system:ActorSystem, name:String, prefix:String="/user/", duration:FiniteDuration=5.seconds, stopMessage:Any=PoisonPill)={
        import system.dispatcher //brings ExecutionContext 
        findActor(system, name, prefix, duration).onComplete{
            case util.Success(ref) => 
                println(s"$ref")
                ref ! stopMessage
            case _ =>
        }
    }
    
    trait ActorStop { thisActor : Actor =>
        import ActorStop._ 
        
        def receiveSTOP: Actor.Receive = {    
           case STOP =>
              context.children.foreach { ch =>
                ch ! PoisonPill
              }
              self ! PoisonPill 
              
           case IMMSTOP =>
                 context.children.foreach { ch =>
                    context.stop(ch)
                }
              context.stop(self)
           case FAKESTOP =>
                 
        }
    }
    object ActorStop{
        sealed trait STOPMARKER
        case object STOP extends STOPMARKER
        case object IMMSTOP extends STOPMARKER
        case object FAKESTOP extends STOPMARKER
    }
    
    class TestProb extends Actor with ActorLogging {
        def receive: Receive = {    
               case msg => log.info(s"${self.path.name} - New msg received: $msg")      
            }
    }
    object TestProb{
        def props:Props = Props(new TestProb)
    }
}



///Creation of child Actor and various message patterns  -- ADVANCED 
ActorRefs can be freely shared among actors by message passing. 
Message passing conversely is their only purpose

//example 
import akka.actor._

class ExampleActor extends Actor with ActorLogging with ActorHelper.ActorStop {
  val other = context.actorOf(MyActor.props(32), "childName") // will be destroyed and re-created upon restart by default
  log.info(s"$self created $other")
  
  import ExampleActor._    
  
  def receiveAll:Actor.Receive = {
    case Request1(msg) => other ! MyActor.Greeting1(msg)                // uses this actor as sender reference, reply comes here 
    case Request2(msg) => other.tell(MyActor.Greeting2(msg), sender())  // forward sender reference, in other sender() would be this actor sender()
    case Request3(msg) =>
      import akka.pattern.{ask, pipe}
      import scala.concurrent.duration._
      val fut = other.ask(MyActor.Greeting3(msg))(5.seconds)
      import context.dispatcher
      pipe(fut) to sender()
      // ask: the ask call will get a future from other's reply
      // pipe: when the future is complete, send its value to the original sender      
  }
  
  override def receive:Actor.Receive = receiveAll.orElse(receiveSTOP)
}

object ExampleActor {
   def props: Props = Props(new ExampleActor)
   case class Request1(msg: String)
   case class Request2(msg: String)
   case class Request3(msg: String)
}

class MyActor(magicNumber: Int) extends Actor with ActorLogging {
  import MyActor._
  def receive = {
    case Greeting1(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.1")
        sender() !  ExampleActor.Request2(greeter)
    case Greeting2(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.2")
        //Here sender() is not ExampleActor, but MyActor because of other.tell(..)
        sender() !  MyActor.Goodbye
    case Greeting3(greeter) => 
        log.info(s"$magicNumber: I was greeted by $greeter.3")
        sender() !  "Completed"
    case Goodbye  => log.info(s"$magicNumber: Someone said goodbye to me.")
  }
}
object MyActor {
   def props(magicNumber: Int): Props = Props(new MyActor(magicNumber))
   case class Greeting1(from: String)
   case class Greeting2(from: String)
   case class Greeting3(from: String)
   case object Goodbye
}
//Using REPL 
val system = ActorSystem("Dummy") //akka://Dummy
val resOne = system.actorOf(ExampleActor.props, "name") //name should unique 
resOne ! ExampleActor.Request1("Das") 
//output 
32: I was greeted by Das.1
32: I was greeted by Das.2
32: Someone said goodbye to me.

//ask pattern 
import scala.concurrent.duration._
import akka.pattern.ask
val future = resOne.ask(ExampleActor.Request3("Das"))(5.seconds).mapTo[String] //Future[String]

import system.dispatcher //brings ExecutionContext
future.foreach(println) //Completed
resOne ! PoisonPill
system.terminate().foreach( _ => "Terminated")


//Using ActorHelper 
val system = ActorSystem("Dummy")
import system.dispatcher

//processOne( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, ExampleActor.props, ActorHelper.ActorStop.STOP){ (system, actor) =>
    import akka.pattern._ 
    import scala.concurrent.duration._
    import system.dispatcher //brings ExecutionContext  
    actor ! ExampleActor.Request1("Das")     
    val future = actor.ask(ExampleActor.Request3("Das"))(5.seconds).mapTo[String] //Future[String]
    future
}.foreach(println)
//output 
Created: Actor[akka://Dummy/user/name#-2078609943]
Actor[akka://Dummy/user/name#-2078609943] created Actor[akka://Dummy/user/name/childName#-145826343]
32: I was greeted by Das.1
32: I was greeted by Das.3
32: I was greeted by Das.2
32: Someone said goodbye to me.
Completed

system.terminate().foreach( _ => "Terminated")


///Actors and shared mutable state   
Messages should be immutable, this is to avoid the shared mutable state trap.
To update state, handle a message of that state and update the state 
(as message processing of any actor is always isolated/sequential ) 
Never ever update any state inside Future (as they might happen concurrently)


// Very bad, "sender" changes for every message, // shared mutable state bug
Future { expensiveCalculation(sender()) } 
//do like 
// Completely safe, we close over a fixed value
// and it's an ActorRef, which is thread-safe
val currentSender = sender()
Future { expensiveCalculation(currentSender) }


//example - follow pattern self ! UpdateState(value)
import akka.actor._ 

object UpdateActor {
  final case class Request(x: Int)
  final case class UpdateState(x: Int)
  def props: Props = Props(new UpdateActor)
}

class UpdateActor extends Actor with ActorLogging {
  var currentValue = 0
  
  import UpdateActor._
  import scala.util._ 
  import scala.concurrent._ 
  import context.dispatcher
  
  override def receive: Receive = {
    case Request(x) =>
      log.info(s"Got Request $x")
      val currentSender = sender()
      self ! UpdateState(x)
      Future { expensiveCalculation(currentSender) }.onComplete { 
        case Success(value) => self ! UpdateState(value)
        case Failure(ex)    => 
      }
    case UpdateState(value) => 
        log.info(s"Updating state $value")
        currentValue = value
  }
  
  def expensiveCalculation(s:ActorRef) ={
    25
  }
}
//Usage 
import scala.concurrent.duration._
import scala.concurrent._
val system = ActorSystem("Dummy")

//processOne( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, UpdateActor.props){ (system, actor) =>
    import akka.pattern._ 
    import scala.concurrent.duration._
    import system.dispatcher //brings ExecutionContext       
    actor.ask(UpdateActor.Request(2))(5.seconds) 
} 
//system.terminate().foreach( _ => "Terminated")



///Dispatchers (ExecutionContext) Types 
Dispatchers  are responsible for assigning CPU to the actors, managing actor mailboxes, 
and passing over messages from the mailbox to an actor. 


There are four commonly used types of dispatchers:

    Default dispatcher: This dispatcher creates one mailbox per actor and may be
    shared by any number of actors. 
    It uses java.util.concurrent.ExecutorService for this process. It is designed to
    be used in combination with actors having a nonblocking code. The dispatcher
    selects an idle thread and assigns it to an actor of its choice. The actor then
    processes a certain number of messages before releasing the thread.

    Balanced dispatcher: This dispatcher creates a single mailbox that can be shared
    by multiple actors of the same kind. Messages from the mailbox are distributed
    among actors sharing the dispatcher(one message to only one actor)

    Pinned dispatcher: This dispatcher uses a thread pool with a single thread. This
    thread is assigned to a single actor. Thus, each actor has its own thread and
    mailbox, and can perform blocking or long-running activities without starving
    other actors.

    CallingThread dispatcher: This dispatcher assigns one thread per actor. This is
    mainly used for testing.

//Example 
In our case, the BlockActor has a blocking call in its implementation. So update 

//src/main/resources/application.conf
blockactor-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}

//code 
import akka.actor._ 

object BlockActor {
  final case class Request(x: Int, y: Int)
  def props: Props = Props(new BlockActor).withDispatcher("blockactor-dispatcher")
}

class BlockActor extends Actor with ActorLogging{
  override def receive: Receive = {
    case BlockActor.Request(x,y) =>
      Thread.sleep(3000)
      sender() ! "Done"
      log.info("Done")
  }
}

//Usage 
val system = ActorSystem("Dummy")
import system.dispatcher

//process( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, BlockActor.props){ (system, actor) =>
    import akka.pattern._ 
    import scala.concurrent.duration._
    import system.dispatcher //brings ExecutionContext       
    actor.ask(BlockActor.Request(2,2))(50.seconds) 
}.foreach(println)

//system.terminate().foreach( _ => "Terminated")

///Dispatcher Details -- ADVANCED 
All MessageDispatcher implementations are also an ExecutionContext, 
which means that they can be used to execute arbitrary code, for instance Futures.

By default this is a "fork-join-executor", 
Other type of dispatchers - https://doc.akka.io/docs/akka/current/dispatchers.html?language=scala

Dispatchers implement the ExecutionContext interface 
and can thus be used to run Future invocations etc for use with Futures, Scheduler, etc.

import system.dispatcher // The ExecutionContext that will be used
//or a particular dispatcher 
implicit val executionContext = system.dispatchers.lookup("my-thread-pool-dispatcher")

//example that uses the "thread-pool-executor"
//application.conf 
my-thread-pool-dispatcher {
  # Dispatcher is the name of the event-based dispatcher
  type = Dispatcher
  # What kind of ExecutionService to use
  executor = "thread-pool-executor"
  # Configuration for the thread pool
  thread-pool-executor {
    # minimum number of threads to cap factor-based core number to
    core-pool-size-min = 2
    # No of core threads ... ceil(available processors * factor)
    core-pool-size-factor = 2.0
    # maximum number of threads to cap factor-based number to
    core-pool-size-max = 10
  }
  # Throughput defines the maximum number of messages to be
  # processed per actor before the thread jumps to the next actor.
  # Set to 1 for as fair as possible.
  throughput = 100
}

//Use it as in , for name "myactor" as given in Props
//application.conf
akka.actor.deployment {
  /myactor {
    dispatcher = my-thread-pool-dispatcher
  }
}

//OR An alternative to the deployment configuration is to define the dispatcher in code. 
import akka.actor.Props
val myActor = context.actorOf(Props[MyActor].withDispatcher("my-thread-pool-dispatcher"), "myactor")




///ActorSystem and Actor naming -- ADVANCED *
/ ,the  root guardian. 
    This is the parent of all actors in the system, and the last one to stop 
    when the system itself is terminated.
/user ,the guardian. 
    This is the parent actor for all user created actors. 
    Every actor you create using the Akka library will have the constant path /user/ prepended to it.
    system.actorOf(), creates an actor directly under /user.
    context.actorOf() from an existing actor, creates actors under that existing actor 
/system ,the system guardian.
    Internal actor system 
    
//Example for Actor naming 
import akka.actor._

class PrintMyActorRefActor extends Actor with ActorLogging with ActorHelper.ActorStop{
  override def receive: Receive = receiveSTOP.orElse{
    case "printit" =>
      val secondRef = context.actorOf(Props.empty, "second-actor")
      log.info(s"Second: $secondRef")
  }
}
object PrintMyActorRefActor{
    def props = Props(new PrintMyActorRefActor)
}

//Usage 
val system = ActorSystem("testSystem")
import system.dispatcher

//process( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, PrintMyActorRefActor.props, ActorHelper.ActorStop.STOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext       
    actor ! "printit"
    Future.successful("Completed")
}.foreach(println)
//(Actor[akka://testSystem/user/name#224803334]
//Second: Actor[akka://testSystem/user/name/second-actor#1823874161]

//system.terminate().foreach( _ => "Terminated")


///Identifying Actors via ActorSelection  -- ADVANCED * 

//OPTION-1:resolveOne method of the ActorSelection. 
It returns a Future of the matching ActorRef if such an actor exists. 
   def  resolveOne(timeout: FiniteDuration): Future[ActorRef]  
        Resolve the ActorRef matching this selection.
   def  resolveOne()(implicit timeout: Timeout): Future[ActorRef]  
        Resolve the ActorRef matching this selection.
        
//Example 
val system = ActorSystem("testSystem")
import akka.pattern._ 
import scala.concurrent.duration._
import scala.concurrent._
import system.dispatcher 
val prob = system.actorOf(ActorHelper.TestProb.props,"testprob")
system.actorSelection("/user/testprob").resolveOne(5.seconds).onComplete{
    case util.Success(ref) => 
        println(s"$ref")
        ref ! PoisonPill
    case _ =>
}

//OPTION-2: Use built-in Identify message that all Actors will understand 
//and automatically reply to with a ActorIdentity message containing the ActorRef.

final  case class  Identify(messageId: Any) extends AutoReceivedMessage with NotInfluenceReceiveTimeout with Product with Serializable 
final  case class  ActorIdentity(correlationId: Any, ref: Option[ActorRef]) extends Product with Serializable 
    The correlationId is taken from the messageId in the Identify message. 

//Example 
import akka.actor._
 
class Follower(path:String) extends Actor with ActorLogging with ActorHelper.ActorStop{
  val identifyId = 1
  context.actorSelection(path) ! Identify(identifyId)
 
  def receive = receiveSTOP.orElse{
    case ActorIdentity(`identifyId`, Some(ref)) =>
      log.info(s"${ref.path} Found")
      context.watch(ref)   //Registers this actor as a Monitor for the provided ActorRef.
      context.become(active(ref))   //Changes this actor  behavior to become the new 'Receive' (PartialFunction[Any, Unit]) handler.
    case ActorIdentity(`identifyId`, None) => context.stop(self)
    
  }
 
  def active(another: ActorRef): Actor.Receive = {
    case Terminated(`another`) => 
        log.info(s"${another.path} was terminated, so me stopping ${self.path}")
        context.stop(self)
  }
}
object Follower{
    def props(path:String):Props = Props(new Follower(path))
}

//REPL 
import akka.actor._ 
import akka.pattern._ 
import scala.concurrent.duration._
import scala.concurrent._

val system = ActorSystem("testSystem")
import system.dispatcher

val props = Follower.props("/user/testprob")
val prob = system.actorOf(ActorHelper.TestProb.props,"testprob")
val actor = system.actorOf(props,"name")
prob ! PoisonPill

///One Complex Example - Download via actor  -- ADVANCED  
package download  //download.Main.main(Array[String]())

import akka.actor._
import akka.event.Logging
import scala.util._
import scala.concurrent._
import akka.util._ 
import scala.concurrent.duration._
import akka.pattern._

case class xURL(url:String, sender:ActorRef)
case class rMap(url:String, urls:Seq[String], sender:ActorRef)
case object STOP

class Download extends Actor {
  import org.xml.sax._ 
  import java.io._ 
  import java.net._   
  
  def get(url: String) = scala.io.Source.fromURL(url, "ISO-8859-1").getLines.toList.mkString

  def downloadURLAndGetAllHref(base:String):Seq[String] = {
        val parserFactory = new org.ccil.cowan.tagsoup.jaxp.SAXFactoryImpl
        val parser = parserFactory.newSAXParser()
        val source = new InputSource( new StringReader( get(base) ) )
        val adapter = new scala.xml.parsing.NoBindingFactoryAdapter
        val xml = adapter.loadXML(source, parser)
        (xml \\ "a" ).map { n => n \@ "href"}.map{ url => if(url.startsWith("http")) url else (new URL(new URL(base),url)).toString}
    }
    def receive = {
        case  xURL(url,ori_sender) =>                            
                            val t = Try{downloadURLAndGetAllHref(url)}
                            t match {
                                case Failure(exe) => sender() ! rMap(url, Seq.empty[String],ori_sender)
                                case Success(urls) => sender() ! rMap(url, urls.asInstanceOf[Seq[String]],ori_sender)
                            }                          
        case STOP => context stop self
     }
}

class Service extends Actor with ActorLogging {
  import org.xml.sax._ 
  import java.io._ 
  import java.net._   
  val rnd = scala.util.Random
  
  def receive = {
        case  url:String => 
                log.info(""+ Thread.currentThread.getName+":"+url) //not multiargs 
                //start new actor                 
                val a = context.actorOf(Props[Download], "download-" + rnd.nextInt.abs)
                val currentSender = sender()
                a ! xURL(url,currentSender)  //Do it like this, to remove latest bug 
        case rMap(url:String, urls:Seq[String], ori_sender:ActorRef) =>  
                ori_sender ! Map( url -> urls.toList) 
                //kill child 
                sender ! STOP 
        case _      => log.info("received unknown message")
      } 
}

object Main extends App {

    val urls = List(  "http://www.google.com",
                      "http://www.scala-lang.org/",
                      "http://jskdlsycds.com", //invalid url-1
                      "http://rediff.com",
                      "http://wowslskdleodd.com") //invalid url-2

                      
                      
                      
                      
    //actual code 
    implicit val system = ActorSystem("testSystem")
    val service = system.actorOf(Props[Service], "service") //or .actorOf(Props(classOf[MyActor], arg1, arg2), "name")

    import system.dispatcher // The ExecutionContext(for futures) that will be used
    implicit val timeout = Timeout(5 seconds) // needed for `?` below


    val gMap = scala.collection.concurrent.TrieMap[String,List[String]]()

                      
    val htmls = urls.map {
      url => 
        val fut = (service ? url).mapTo[Map[String,List[String]]] 
        fut.onSuccess { case map:Map[_,_]  =>                         
                            val old = gMap.getOrElse(url, List.empty[String])
                            //Update only diff 
                            val newS = map.values.toList(0).asInstanceOf[List[String]].toSet &~ old.toSet 
                            gMap.getOrElseUpdate(map.keys.toList(0).asInstanceOf[String],newS.toList)
                    }
        fut
    }
    val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Inf)};res} }.collect{case Success(map) => map.values.flatten.size}.reduce(_ + _)
    
    println(s"Total nested links found $t1")
    val tfut = system.terminate 
    Await.result(tfut, Duration.Inf)
}

///Receive timeout  --ADVANCED 
The ActorContext setReceiveTimeout defines the inactivity timeout 
after which the sending of a ReceiveTimeout message is triggered

//Once set, the receive timeout stays in effect (i.e. continues firing repeatedly after inactivity periods). 
//Pass in Duration.Undefined to switch off this feature.

import akka.actor._
import scala.concurrent.duration._
class MyActor extends Actor with ActorLogging{
  // To set an initial delay
  context.setReceiveTimeout(30.milliseconds)
  def receive = {
    case "Hello" =>
      // To set in a response to a message
      context.setReceiveTimeout(1.seconds)
    case "OFFTIMEOUT" =>
      // To turn it off
      context.setReceiveTimeout(Duration.Undefined)
    case ReceiveTimeout =>
        log.info(s"ReceiveTimeout")
      
  }
}
//Usage 
val system = ActorSystem("testSystem")
import system.dispatcher

//process( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, Props(new MyActor), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext       
    actor ! "Hello"
    Future.successful("Completed")
}.foreach(println)
system.actorSelection("/user/name").resolveOne(5.seconds).onComplete{
    case util.Success(ref) => 
        println(s"$ref")
        ref ! PoisonPill
    case _ =>
}

///Understanding the Methods in the Akka Actor Lifecycle -- ADVANCED 
//Method                Description
constructor           
    An actor constructor is called just like any other Scala class constructor, 
    when an instance of the class is first created.     
    
preStart              
    Called right after the actor is started. 
    During restarts it is called by the default implementation of postRestart.

preRestart(reason: Throwable, message: Option[Any])            
    when an actor is restarted, the old actor is informed with  preRestart 
    and is called with the exception that caused the restart, 
    and the message that triggered the exception(=None if no message caused this restart). 
    In the default implementation,  stops all the children of the old actor
    and calls postStop() of old actor 
    
postRestart(reason: Throwable)           
    The new actor postRestart is invoked with the exception 
    that caused the restart. 
    In the default implementation, the preStart method of new actor  is called.
  
postStop              
    Called after an actor (old actor) is stopped, 
    it can be used to perform any needed cleanup work. 
    
///Actor - supervisorStrategy and LifeCycle -- ADVANCED * 

case class  OneForOneStrategy(maxNrOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf, loggingEnabled: Boolean = true)(decider: Decider) extends SupervisorStrategy with Product with Serializable  
case class  AllForOneStrategy(maxNrOfRetries: Int = -1, withinTimeRange: Duration = Duration.Inf, loggingEnabled: Boolean = true)(decider: Decider) extends SupervisorStrategy with Product with Serializable  
    Applies the fault handling Directive (Resume, Restart, Stop) specified in the Decider 
    to all children when one fails, as opposed to akka.actor.OneForOneStrategy 
    that applies it only to the child actor that failed. 
    
There are limits set on the restart frequency, namely maximum 10 restarts per minute; 
The child actor is stopped if the limit is exceeded.

Escalate is used if the defined strategy doesnot cover the exception that was thrown.
exception escalate all the way up to the root guardian and then handled by default as below 

The following exceptions are handled by default:
    ActorInitializationException    will stop the failing child actor
    ActorKilledException            will stop the failing child actor
    Exception                       will restart the failing child actor
    Other types of Throwable        will be escalated to parent actor


//You can mute the default logging of a SupervisorStrategy 
//by setting loggingEnabled to false when instantiating it. 

class ExampleActor(ns:Int) extends Actor with ActorHelper.ActorStop{
  import akka.actor.SupervisorStrategy._

  override val supervisorStrategy = OneForOneStrategy(maxNrOfRetries = 10, withinTimeRange = 30.seconds) {
    case _: ArithmeticException      => Resume
    case _: NullPointerException     => Restart
    case _: IllegalArgumentException => Stop
    case _: Exception                => Escalate
  }
  
  val refs = (0 until ns).toList.foreach{ i =>
    context.actorOf(BadActor.props(i)) //Nothing Bad about it, only it raises exception 
  }
  
  def receive = receiveSTOP  //from ActorHelper.ActorStop
}

object BadActor {
  private case object TickKey
  private case object FirstTick
  private case object Tick
  def props(id:Int):Props = Props(new BadActor(id))
}

class BadActor(val id:Int) extends Actor with Timers with ActorLogging{
    import BadActor._
    import scala.util.Random 
    import scala.util.chaining._

    val r = new Random
    val name = s"MyActor($id)"
    println(s"$name: entered the constructor")
      
    val excol = Seq(new ArithmeticException(s"$name"), new NullPointerException(s"$name"), 
        new IllegalArgumentException(s"$name"), new Exception(s"$name"))
  
    //Timers are bound to Actor 
    //startSingleTimer(name: String, msg: Any, delay: FiniteDuration): Unit
    timers.startSingleTimer(TickKey, FirstTick, 1.seconds)

    def receive = {
        case FirstTick =>
          // initalization of timer is done here 
          //sent repeatedly to the self actor with a fixed delay
          //startTimerWithFixedDelay(name: String, msg: Any, delay: FiniteDuration): Unit
          timers.startTimerWithFixedDelay(TickKey, Tick, 10.seconds) //first arg is Timer Key for cancellation 
        case Tick =>
            if (r.nextInt(10) > 5) 
                log.info(s"$name: Pass")
            else {
                r.shuffle(excol).head.tap{s =>
                  log.info(s"$name: $s ")
                }.pipe(s => throw s)
            }
    }

 
    override def preStart()= { 
       //Called right after the actor is started. 
       println(s"$name: preStart")  
    }
    
    override def postStop()= { 
       //Called after an actor is stopped, 
       println(s"$name: postStop") 
       
    }
    override def preRestart(reason: Throwable, message: Option[Any])={
      //when an actor is restarted, the old actor is informed with this 
      println(s"$name: preRestart reason=${reason.getMessage} message=$message")
      super.preRestart(reason, message)  //calls postStop() of old actor 
    }
    override def postRestart(reason: Throwable) ={
      //The postRestart method of the new actor is invoked with the exception 
      // that caused the restart. 
      println(s"$name: postRestart reason=${reason.getMessage}")
      super.postRestart(reason)  //preStart method of new actor  is called
    }
}
//Usage 
val system = ActorSystem("testSystem")
import system.dispatcher

//process( system: ActorSystem, props:Props, stopMessage:Any =PoisonPill)(sendfn: (ActorSystem, ActorRef) => Future[Any] ):Future[Any]
ActorHelper.processOne(system, Props(new ExampleActor(1)), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext       
    Future.successful("Completed")
}.foreach(println)
//Kill actor by ActorHelper 
system.actorSelection("/user/name").resolveOne(5.seconds).onComplete{
    case util.Success(ref) => 
        println(s"$ref")
        ref ! PoisonPill
    case _ => ActorHelper.ActorStop.STOP
}

//system.terminate().foreach( _ => "Terminated")



///Actor - Dead Letters -- ADVANCED 
Messages which cannot be delivered will be delivered to a synthetic actor called /deadLetters

case class DeadLetter(message: Any, sender: ActorRef, recipient: ActorRef) extends AllDeadLetters with Product with Serializable  
    An actor can handle above message 
    The subscribed actor will then receive all dead letters published in the (local) 
    system from that point onwards. 
    Dead letters are not propagated over the network, 

//Example 
import akka.actor._

val system = ActorSystem("testSystem")
import system.dispatcher

val propNames = Seq( 
    ("dead-letters-subscriber", Props(new ActorHelper.TestProb)),
    ("generic-echo-actor", Props(new ActorHelper.TestProb)))


//def processSeq( system: ActorSystem, propNames:Seq[(String, Props)], stopMessage:Iterator[Any] =Iterator.continually(PoisonPill) )(sendfn: (ActorSystem, Seq[ActorRef]) => Future[Any] ):Future[Any]
ActorHelper.processSeq(system, propNames, Iterator.continually(ActorHelper.ActorStop.FAKESTOP)){ (system, seq) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    
    val deadLettersSubscriber = seq.head
    val echoActor = seq.last
    
    system.eventStream.subscribe(deadLettersSubscriber, classOf[DeadLetter])

    echoActor ! "First Message"

    echoActor ! PoisonPill
    echoActor ! "Second Message"

    system.deadLetters ! "Dead Message"
    
    Future.successful("Completed")
}.foreach(println)

//Kill other 
import scala.concurrent.duration._
system.actorSelection("/user/dead-letters-subscriber").resolveOne(5.seconds).onComplete{
    case util.Success(ref) => 
        println(s"$ref")
        ref ! PoisonPill
    case _ =>
}
//Output 

dead-letters-subscriber - New msg received: DeadLetter(Dead Message,Actor[akka://testSystem/deadLetters],Actor[akka://testSystem/deadLetters])
generic-echo-actor - New msg received: First Message
dead-letters-subscriber - New msg received: FAKESTOP
dead-letters-subscriber - New msg received: DeadLetter(Second Message,Actor[akka://testSystem/deadLetters],Actor[akka://testSystem/user/generic-echo-actor#1206647008])
dead-letters-subscriber - New msg received: DeadLetter(FAKESTOP,Actor[akka://testSystem/deadLetters],Actor[akka://testSystem/user/generic-echo-actor#1206647008])

///Actor -Unhandled Message --ADVANCED 
There are two Types 
    Invalid message 
        actor receives message it is  not capable of handling aka UnhandledMessage
        By default gets published to event stream as
        context.system.eventStream.publish(UnhandledMessage(message, sender(), self))
        UnhandledMessage(message: Any, sender: ActorRef, recipient: ActorRef)
    Late message 
        actor receives message after it has died aka DeadLetter

//Unhandled Message
import akka.actor._

case object Message
case object InValidMessage

class MainActor extends Actor {
  def receive = {
    case Message => {
      println("Message Received")
    }
  }
}

val system = ActorSystem("ActorSystem")
val driverActor = system.actorOf(Props[MainActor], "mainActor")

driverActor ! Message
driverActor ! InValidMessage  //UnhandledMessage 
driverActor ! Message

//system.terminate().foreach( _ => "Terminated")

//Can be handled via event stream 
case object Message
case object InValidMessage

class MainActor extends Actor {
  def receive = {
    case Message => {
      println("Message Received")
    }
  }
}

class UnhandledListener extends Actor {
  def receive = {
    case u: UnhandledMessage => println("Unhandled message " + u.message)
  }
}

val system = ActorSystem("ActorSystem")
val driverActor = system.actorOf(Props[MainActor], "mainActor")
val listener = system.actorOf(Props[UnhandledListener], "deadActor")
system.eventStream.subscribe(listener, classOf[UnhandledMessage])

driverActor ! Message
driverActor ! InValidMessage
driverActor ! Message

//system.terminate().foreach( _ => "Terminated")

///Actor -  Lifecycle Monitoring aka DeathWatch -- ADVANCED 
Even if the watched actor has already been terminated at the time of registration.
This method can be called 

//to deregister from watching another actor’s liveliness using 
context.unwatch(target)

//Example 
import akka.actor._
 
class WatchActor extends Actor {
  val child = context.actorOf(Props.empty, "child")
  context.watch(child) // <-- this is the only call needed for registration
  var lastSender = context.system.deadLetters
 
  def receive = {
    case "kill" =>
      context.stop(child)
      lastSender = sender()
    case Terminated(child) => 
        lastSender ! "finished"
        context.stop(self)
  }
}
//Usage 
import akka.actor._

val system = ActorSystem("testSystem")
import system.dispatcher

ActorHelper.processOne(system, Props(new WatchActor), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    
    actor.ask("kill")(5.seconds).mapTo[String]    
}.foreach(println)

//Check 
system.actorSelection("/user/name").resolveOne(5.seconds)



///Actor - Mailboxes -- ADVANCED 
An Akka Mailbox holds the messages that are destined for an Actor. 
Normally each Actor has its own mailbox, 
OR for example a BalancingPool, all routees will share a single mailbox instance.

For example actor extend the parameterized trait RequiresMessageQueue. 
Other type of mail boxes 
https://doc.akka.io/docs/akka/current/typed/mailboxes.html#mailbox-implementations

//Example 
import akka.dispatch.RequiresMessageQueue
import akka.dispatch.BoundedMessageQueueSemantics
 
class MyBoundedActor extends MyActor with RequiresMessageQueue[BoundedMessageQueueSemantics]

//Config 
The type parameter, T to the RequiresMessageQueue[T] trait needs to be mapped to a mailbox 
//Then update application.conf 
akka.actor.mailbox.requirements {
  "akka.dispatch.BoundedMessageQueueSemantics" = bounded-mailbox
}

bounded-mailbox {
  mailbox-type = "akka.dispatch.BoundedMailbox"
  mailbox-capacity = 1000
  mailbox-push-timeout-time = 10s
}
 
//Default Mailbox
By default it is an unbounded mailbox, 
which is backed by a java.util.concurrent.ConcurrentLinkedQueue

//SingleConsumerOnlyUnboundedMailbox
SingleConsumerOnlyUnboundedMailbox is an even more efficient mailbox, 
and it can be used as the default mailbox, but it cannot be used with a BalancingDispatcher.
//Example 
akka.actor.default-mailbox {
  mailbox-type = "akka.dispatch.SingleConsumerOnlyUnboundedMailbox"
}

//Example- Check 
http://doc.akka.io/docs/akka/current/scala/mailboxes.html

//Actor with individual configuration 
//application.conf 
prio-mailbox {
  mailbox-type = "akka.dispatch.SingleConsumerOnlyUnboundedMailbox"
  //Other mailbox configuration goes here
}
//Usgae 
import akka.actor.Props
val myActor = context.actorOf(Props[MyActor]().withMailbox("prio-mailbox"))

//OR with auto deployement configs 
//application.conf 
akka.actor.deployment {
  /priomailboxactor {      #same as actor name in actor creation 
    mailbox = prio-mailbox
  }
}
//Usage 
import akka.actor.Props
val myActor = context.actorOf(Props[MyActor](), "priomailboxactor")
    


///Actor - System Scheduler - Schedule a code -- ADVANCED 

//The scheduler will throw an exception if attempts are made to schedule too far into the future 
//(which by default is around 8 months (Int.MaxValue seconds)

def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and frequency.
def scheduleAtFixedRate(initialDelay: FiniteDuration, interval: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    Schedules a Runnable to be run repeatedly with an initial delay and a frequency.
def scheduleOnce(delay: FiniteDuration)(f: => Unit)(implicit executor: ExecutionContext): Cancellable
    Schedules a function to be run once with a delay, i.e.
def scheduleOnce(delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent once with a delay, i.e.
def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration, receiver: ActorRef, message: Any)(implicit executor: ExecutionContext, sender: ActorRef = Actor.noSender): Cancellable
    Schedules a message to be sent repeatedly with an initial delay and a fixed delay between messages.
def scheduleWithFixedDelay(initialDelay: FiniteDuration, delay: FiniteDuration)(runnable: Runnable)(implicit executor: ExecutionContext): Cancellable
    Schedules a Runnable to be run repeatedly with an initial delay and a fixed delay between subsequent executions.
    

//trait Cancellable
def cancel(): Boolean
    Cancels this Cancellable and returns true if that was successful.
def isCancelled: Boolean
    Returns true if and only if this Cancellable has been successfully cancelled



//Usage 
import akka.actor._

val system = ActorSystem("testSystem")
import system.dispatcher

val fut = ActorHelper.processOne(system, Props(new ActorHelper.TestProb), ActorHelper.ActorStop.FAKESTOP){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    
    val run:Runnable = () => actor ! "5TICK"
    val id1 = system.scheduler.scheduleAtFixedRate(1.seconds, 5.seconds)(run)
    //OR 
    val id2 = system.scheduler.scheduleWithFixedDelay(1.seconds, 2.seconds, actor,"2TICK")
    Future.successful(() => { 
        id1.cancel()
        id2.cancel()
        })
}
fut.foreach{ lambda => lambda.asInstanceOf[Function0[Any]]()}

//Check 
ActorHelper.stopActor(system, "name")


///Actor - Switching Between Different States with become -- ADVANCED 
//context.become and context.unbecome
def  become(behavior: Receive, discardOld: Boolean): Unit 
    Changes the Actor behavior to become the new 'Receive' (PartialFunction[Any, Unit]) 
    handler. This method acts upon the behavior stack as follows:
        if discardOld = true it will replace the top element (i.e.default), 
            no need for unbecome(), This is default 
        if discardOld = false it will keep the current behavior and push the given one atop, 
            must issue unbecome()
def unbecome(): Unit
    Reverts the Actor behavior to the previous one on the behavior stack.


//Example 
import akka.actor._
object OneActor{
    case object GoToSecondState
    case object TryToFindSolution
    case object GoToOneState
    def props = Props(new OneActor)
}
class OneActor extends Actor with ActorLogging{
  import context._
  import OneActor._ 
  
	def oneState: Receive = {
	  case GoToSecondState =>
		   println("Moving to two State")
		   become(twoState)
	}

	def twoState: Receive = {
	  case TryToFindSolution =>
		   println("remaining in two State")
	  case GoToOneState =>
		   println("Moving to one state")
		   become(oneState)
	}

	def receive = {
	  case GoToOneState => become(oneState)
	  case GoToSecondState => become(twoState)
	}
}



val system = ActorSystem("testSystem")
import system.dispatcher

ActorHelper.processOne(system, OneActor.props){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    import OneActor._ 
    
    actor ! GoToOneState // init to normalState
    actor ! GoToSecondState
    actor ! TryToFindSolution
    Thread.sleep(1000)
    actor ! GoToOneState
    Future.successful("OK")
}.foreach(println)

//Check 
ActorHelper.findActor(system, "name")

//system.terminate().foreach( _ => "Terminated")


///Stash  -- ADVANCED 
The Stash trait enables an actor to temporarily stash away messages 
that can not or should not be handled using the actor current behavior
The stash is backed by a scala.collection.immutable.Vector.

If you want to enforce that your actor can only work with an unbounded stash, 
then you should use the UnboundedStash trait instead.

Note that the Stash trait can only be used together with actors that have a deque-based mailbox. 
which is true by default as SingleConsumerOnlyUnboundedMailbox (default mailbox) 

//Important methods , Stash has all Actor's methods 
trait Stash extends UnrestrictedStash with RequiresMessageQueue[DequeBasedMessageQueueSemantics] 
trait UnboundedStash extends UnrestrictedStash with RequiresMessageQueue[UnboundedDequeBasedMessageQueueSemantics] 
    def stash(): Unit
        Adds the current message (the message that the actor received last) 
        to the actors stash.
    def unstashAll(): Unit
        Prepends all messages in the stash to the mailbox, handling would start now 
        and then clears the stash.


//Example 
import akka.actor._ 

class ActorWithProtocol extends Actor with Stash {
  def receive = {
    case "open" =>
      println("b1: open")
      unstashAll()  //all stashed message are handled now after exit of this message 
      context.become({
        case "write" => 
            println("b2: write")
        case "close" =>
          println("b2: close")
          unstashAll() //all stashed message are handled now after exit of this message 
          context.unbecome() //go back to original Receive
        case msg => 
            println(s"b2: stash-$msg")
            stash()     //stash this message 
      }, discardOld = false) // stack on top instead of replacing
    case msg => 
        println(s"b1: stash-$msg")
        stash()  //stash this message 
  }
}

//usage 
val system = ActorSystem("testSystem")
import system.dispatcher

ActorHelper.processOne(system, Props(new ActorWithProtocol)){ (system, actor) =>    
    import akka.pattern._ 
    import scala.concurrent.duration._
    import scala.concurrent._
    import system.dispatcher //brings ExecutionContext     
    
    val seqs=Seq("some", "some", "open", "some", "some", "write", "some", "some", "close", "some", "open", "write", "close")
    seqs.foreach { m => actor ! m}
    
    Future.successful("OK")
}.foreach(println)

//Check 
ActorHelper.findActor(system, "name")

//system.terminate().foreach( _ => "Terminated")





///Akka-Cluster (Preferred over Remoting)  -- ADVANCED 
Akka Cluster provides a fault-tolerant decentralized peer-to-peer based cluster membership service 
with no single point of failure or single point of bottleneck. 

It does this using gossip protocols and an automatic failure detector.

//Steps 
In conf, put provider cluster and seed-nodes containing atleast one node 
Start that seed nodes 
All nodes should have same ActorSystem names 
Nodes would talk to each other and converge to cluster 
All Nodes can be remote 


//Terminologies 
node
    A logical member of a cluster. 
    There could be multiple nodes on a physical machine. 
    Defined by a hostname:port:uid tuple.
cluster
    A set of nodes joined together through the membership service.
    Cluster membership is communicated using a Gossip Protocol, 
    where the current state of the cluster is gossiped randomly through the cluster, 
    with preference to members that have not seen the latest version.
leader
    A single node in the cluster that acts as the leader. 
    Managing cluster convergence and membership state transitions.
    
    
//Automatic joining - application.conf 
akka.cluster.seed-nodes = [
  "akka.tcp://ClusterSystem@host1:2552",
  "akka.tcp://ClusterSystem@host2:2552"]
  
//OR 
-Dakka.cluster.seed-nodes.0=akka.tcp://ClusterSystem@host1:2552
-Dakka.cluster.seed-nodes.1=akka.tcp://ClusterSystem@host2:2552

//OR Manual joining 
import akka.actor.Address
import akka.cluster.Cluster

val cluster = Cluster(system)
val list: List[Address] = AddressFromURIString("akka.tcp://ClusterSystem@host2:2552")
cluster.joinSeedNodes(list)

//Subscribe 
def subscribe(subscriber: ActorRef, initialStateMode: SubscriptionInitialStateMode, to: Class[_]*): Unit
    Subscribe to one or more cluster domain events. 
    The to classes can be akka.cluster.ClusterEvent.ClusterDomainEvent or subclasses.
    
    If initialStateMode is ClusterEvent.InitialStateAsEvents the events corresponding 
    to the current state 
    will be sent to the subscriber to mimic what you would have seen if you were listening 
    to the events when they occurred in the past.
    
//The events to track the life-cycle of members are:
•ClusterEvent.MemberJoined 
    A new member has joined the cluster and its status has been changed to Joining
•ClusterEvent.MemberUp 
    A new member has joined the cluster and its status has been changed to Up
•ClusterEvent.MemberExited 
    A member is leaving the cluster and its status has been changed to Exiting Note 
    that the node might already have been shutdown when this event is published on another node.
•ClusterEvent.MemberRemoved 
    Member completely removed from the cluster.
•ClusterEvent.UnreachableMember 
    A member is considered as unreachable, detected by the failure detector of at least one other node.
•ClusterEvent.ReachableMember
    A member is considered as reachable again, after having been unreachable. 
    All nodes that previously detected it as unreachable has detected it as reachable again.






//This requires akka-cluster-typed in sbt dependencies ???

//Example - Actor using that cluster 
//start them manually as per seed-nodes 
$ sbt "runMain clustering.SimpleClusterApp 25251"
//$ sbt "runMain clustering.SimpleClusterApp 25252"

//Look at the log output in the different terminal windows. 

//0 means that it will use a random available port.
$ sbt "runMain clustering.SimpleClusterApp 0"

//Example 
//It registers itself as subscriber of certain cluster events. 
//It gets notified with an snapshot event, 
//`CurrentClusterState` that holds full state information of the cluster. 
//After that it receives events for changes that happen in the cluster.


//clusterMainApp.conf
akka {
  actor {
    provider = cluster

    serialization-bindings {
      "clustering.CborSerializable" = jackson-cbor
    }
  }
  remote {
    artery {
      canonical.hostname = "127.0.0.1"
      canonical.port = 0  # Autoselect , first 25250, ....
    }
  }
  cluster {
    seed-nodes = [
      #Two Node system min
      #ActorSystem must be ClusterSystem
      "akka://ClusterSystem@127.0.0.1:25251"    #, "akka://ClusterSystem@127.0.0.1:25252"
      ]
  }
}

//code 
package clustering 

import akka.cluster._
import akka.cluster.ClusterEvent._
import akka.actor._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory
import akka.cluster.ClusterEvent._ 
import scala.util._ 
import akka.util._ 
import java.util.concurrent.atomic.AtomicInteger

trait CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "ClusterSystem"
    val clusterMainApp = "clusterMainApp.conf"
    
    //val clusterTrx = "clusterTrx.conf"
    
    val sleeptime = 10*60*1000
    val killtime = 10.minutes 
    
    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=killtime, sleeptime:Int=sleeptime):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actor ! PoisonPill
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}




class SimpleClusterListener extends Actor with ActorLogging {

  val cluster = Cluster(context.system)

  // subscribe to cluster changes, re-subscribe when restart
  //def subscribe(subscriber: ActorRef, initialStateMode: SubscriptionInitialStateMode, to: Class[_]*): Unit
  //https://doc.akka.io/api/akka/2.6.13/akka/cluster/ClusterEvent$.html
  override def preStart(): Unit = {
    cluster.subscribe(self, initialStateMode = InitialStateAsEvents,
      classOf[MemberEvent], classOf[UnreachableMember])
  }
  override def postStop(): Unit = cluster.unsubscribe(self)

  def receive = {
    //https://doc.akka.io/api/akka/2.6.13/akka/cluster/ClusterEvent$.html
    case MemberUp(member) =>
      log.info("Member is Up: {}", member.address)
    case UnreachableMember(member) =>
      log.info("Member detected as unreachable: {}", member)
    case MemberRemoved(member, previousStatus) =>
      log.info(
        "Member is Removed: {} after {}",
        member.address, previousStatus)
    case _: MemberEvent => // ignore
  }
}
//app 
object SimpleClusterApp {
  def main(args: Array[String]): Unit = {
    startup(args)
  }

  def startup(ports: Seq[String]): Unit = {
    import Helper._ 
    
    ports foreach { port =>
      // Override the configuration of the port
      val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """).withFallback(ConfigFactory .load(clusterMainApp))

      // Create an Akka system , ClusterSystem must be as per seedNode 
      val system = ActorSystem(clusterActorSystem, config)
      // Create an actor that handles cluster domain events
      val lis = system.actorOf(Props(new SimpleClusterListener), name = "clusterListener")
      
      killThisSystem(system, lis)
    }
  }

}

///Cluster Example -Worker Dial-in Example  -- ADVANCED  
//workers, here named backend, can detect and register to new master nodes, here named frontend.

//The example application provides a service to transform text. 
//When some text is sent to one of the frontend services, 
//it will be delegated to one of the backend workers, which performs the reverse, 
//and sends the result back to the original client. 

//New backend nodes, as well as new frontend nodes, can be added or removed to the cluster dynamically.

//five window 
$ sbt "runMain clustering.TransformationFrontend 25251"
$ sbt "runMain clustering.TransformationFrontend 25252"
$ sbt "runMain clustering.TransformationBackend 0"
$ sbt "runMain clustering.TransformationBackend 0"
$ sbt "runMain clustering.TransformationFrontend 0"


//code 
package clustering 

import akka.cluster._
import akka.cluster.ClusterEvent._
import akka.actor._
import scala.concurrent._
import scala.concurrent.duration._
import com.typesafe.config.ConfigFactory
import akka.cluster.ClusterEvent._ 
import scala.util._ 
import akka.util._ 
import java.util.concurrent.atomic.AtomicInteger

trait CborSerializable  //To make serializations

object Helper {
    val clusterActorSystem = "ClusterSystem"
    val clusterMainApp = "clusterMainApp.conf"
    
    //val clusterTrx = "clusterTrx.conf"
    
    val sleeptime = 10*60*1000
    val killtime = 10.minutes 
    
    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=killtime, sleeptime:Int=sleeptime):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actor ! PoisonPill
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}

//Worker 
final case class TransformationJob(text: String) extends CborSerializable
final case class TransformationResult(text: String) extends CborSerializable
final case class JobFailed(reason: String, job: TransformationJob) extends CborSerializable

//Only use case class 
final case class BackendRegistration() extends CborSerializable
//case object BackendRegistration


//frontend 
class TransformationFrontend extends Actor {

  var backends = IndexedSeq.empty[ActorRef]
  var jobCounter = 0

  def receive = {
    case job: TransformationJob if backends.isEmpty =>
      sender() ! JobFailed("Service unavailable, try again later", job)

    case job: TransformationJob =>
      jobCounter += 1
      backends(jobCounter % backends.size) forward job

    //Backend Sends this 
    case _ : BackendRegistration if !backends.contains(sender()) =>
      context watch sender()
      backends = backends :+ sender()

    case Terminated(a) =>
      backends = backends.filterNot(_ == a)
  }
}

object TransformationFrontend {
  def main(args: Array[String]): Unit = {
    import Helper._ 
    
    // Override the configuration of the port when specified as program argument
    val port = if (args.isEmpty) "0" else args(0)
    val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
      .withFallback(ConfigFactory.parseString("akka.cluster.roles = [frontend]"))
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem(clusterActorSystem, config)
    val frontend = system.actorOf(Props(new TransformationFrontend), name = "frontend")

    
    import system.dispatcher
    val input = Seq("IAMCLUSTER", "HELLO WORLD")
    val counter = new AtomicInteger
    system.scheduler.scheduleAtFixedRate(1.seconds, 1.seconds){ () => 
      implicit val timeout = Timeout(5.seconds)
      import akka.pattern._
      
      val text = input(counter.incrementAndGet() % input.size)
      
      (frontend ? TransformationJob(text)).onComplete {
        case Success(TransformationResult(result)) => println(s"Result: $result")
        case Failure(ex)  => println(s"Result exception: $ex")
        case x => println(s"Result ???: $x")
      }
    }
    
          
    killThisSystem(system, frontend)

  }
}

//Backend 
class TransformationBackend extends Actor with ActorLogging{

  val cluster = Cluster(context.system)

  // subscribe to cluster changes, MemberUp
  // re-subscribe when restart
  override def preStart(): Unit = cluster.subscribe(self, classOf[MemberUp])
  override def postStop(): Unit = cluster.unsubscribe(self)

  def receive = {
    case TransformationJob(text) => sender() ! TransformationResult(text.reverse)
    case state: CurrentClusterState =>
      state.members.filter(_.status == MemberStatus.Up) foreach register
    case MemberUp(m) => register(m)
  }

  def register(member: Member): Unit = {
    if (member.hasRole("frontend")){
      log.info(s"member=$member ${member.address}")
      context.actorSelection(RootActorPath(member.address) / "user" / "frontend") ! BackendRegistration()
      }
   }
}

object TransformationBackend {
  def main(args: Array[String]): Unit = {
    import Helper._ 
    
    // Override the configuration of the port when specified as program argument
    val port = if (args.isEmpty) "0" else args(0)
    val config = ConfigFactory.parseString(s"""
        # akka.remote.netty.tcp.port=$port
        akka.remote.artery.canonical.port=$port
        """)
      .withFallback(ConfigFactory.parseString("akka.cluster.roles = [backend]"))
      .withFallback(ConfigFactory.load(clusterMainApp))

    val system = ActorSystem(clusterActorSystem, config)
    val backend = system.actorOf(Props(new TransformationBackend), name = "backend")
    
    killThisSystem(system, backend)
  }
}

///Routers  -- ADVANCED * 
router 
    which routes messages 
routee 
    actors which recieve message (ie Worker)

Messages can be sent via a router to efficiently route them to destination actors, 
known as its routees. 
A Router can be used inside or outside of an actor, 

//Ref 
final case class Router(logic: RoutingLogic, routees: IndexedSeq[Routee] = Vector.empty)
    For each message that is sent through the router via the #route method 
    the RoutingLogic decides to which Routee to send the message.
    
//The routing logic shipped with Akka are(akka.routing.) 
final class BroadcastRoutingLogic
    Broadcasts a message to all its routees.
final case class ConsistentHashingRoutingLogic(system: ActorSystem, virtualNodesFactor: Int = 0, hashMapping: ConsistentHashMapping = ...)
    Uses consistent hashing to select a routee based on the sent message.
final class RandomRoutingLogic
    Randomly selects one of the target routees to send a message to
final class RoundRobinRoutingLogic
    Uses round-robin to select a routee.
final case class ScatterGatherFirstCompletedRoutingLogic(within: FiniteDuration)
    Broadcasts the message to all routees, and replies with the first response.
final case class TailChoppingRoutingLogic(scheduler: Scheduler, within: FiniteDuration, interval: FiniteDuration, context: ExecutionContext)
    As each message is sent to the router, the routees are randomly ordered.
class SmallestMailboxRoutingLogic
    Tries to send to the non-suspended routee with fewest messages in mailbox.

//code 
package routing  
import akka.actor._
import com.typesafe.config.ConfigFactory
import scala.concurrent._
import scala.concurrent.duration._
import akka.routing._
import akka.util._
import scala.util._

object Helper {
    val routingActorSystem = "RoutingSystem"
    val routingApp = "routingApp.conf"
    

    def killThisSystem(system:ActorSystem, actor:ActorRef, killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        killThisSystemSeq(system, Seq(actor), killtime, sleeptime)
    }
    def killThisSystemSeq(system:ActorSystem, actors:Seq[ActorRef], killtime:FiniteDuration=10.minutes, sleeptime:Int=10*60*1000):Unit = {    
        import system.dispatcher
        system.scheduler.scheduleOnce(killtime){
            actors.foreach{ actor => actor ! PoisonPill }
        }         
        Thread.sleep(sleeptime)
        system.terminate.foreach{ _ => "Terminated"}    
    }

}

//Master  code  
case class Work(str:String)       
case class Result(str:String)       

class Master extends Actor with ActorLogging{
  var router = {
    val routees = Vector.fill(5) {
      val r = context.actorOf(Props(new Worker)) //Master creating Worker 
      context watch r                           // watch 
      ActorRefRoutee(r)   //create the routees as ordinary child actors wrapped in ActorRefRoutee
    }
    Router(RoundRobinRoutingLogic(), routees)  //master creates Router 
  }
 
  def receive = {
    case w: Work =>
      router.route(w, sender())  //Sending messages via the router is done with the route method
    case Terminated(a) =>       //watch message if child killed 
      router = router.removeRoutee(a)
      val r = context.actorOf(Props(new Worker)) //again start 
      context watch r
      router = router.addRoutee(r)
  }
}

class Worker extends Actor with ActorLogging{
   
    def receive = {
        case Work(str) => 
            sender() ! Result(str.reverse) 
        case x => 
            log.info(s"Non Work message: $x")
    }

}

object RoutingDemo extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)

  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val firstRef = system.actorOf(Props(new Master), "master")


  for (_ <- 0 to 5){
      firstRef.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, firstRef, 1.minutes, 1*60*1000)
}

///Routers : Specially Handled Messages -- ADVANCED  

//Broadcast Messages
A Broadcast message can be used to send a message to all of a router routees. 

Do not use Broadcast Messages when you use BalancingPool for routers.

When a router receives a Broadcast message, 
it will broadcast that message payload to all routees, 

//Example 
import akka.routing.Broadcast
firstRef.router ! Broadcast("Watch out for Davy Jones' locker") 
//router extracts its payload and send only payload, here String to Worker



//Specially Handled Messages - PoisonPill Messages
//(same treatment for Kill Messages)
//here router (only router) is getting PoisionPill or Kill 
//and when the router stops it also stops its children(routees)
import akka.actor.PoisonPill
firstRef.router ! PoisonPill

//If you wish to stop a router and its routees explicitely 
import akka.actor.PoisonPill
import akka.routing.Broadcast
firstRef.router ! Broadcast(PoisonPill)
//or for Kill 
import akka.actor.Kill
import akka.routing.Broadcast
firstRef.router ! Broadcast(Kill)

///Auto created Router via configuration -- ADVANCED 
//types 
Pool
    creates a round-robin router and N Worker routees
    that forwards messages to N Worker routees

Group 
    rather than having the router actor create its routees, 
    it is desirable to create routees separately and provide them to the router for its use. 
    Messages will be sent with ActorSelection to these paths.
    
//Uses forward functionality:  a message from one actor to another. 
//the original sender reference is maintained in 'target' when sender() is used 
target.forward(message)
//Works as below 
A -msg -> B 
     Creates C and calls   
     C.forward(msg) 
        C replies Res as 'sender() ! Res', but Res goes to A instead of B 

//routingApp.conf
akka.actor.deployment {
  /parent/router_rrp {   #router_rrp is used in code for actor name under /parent 
    router = round-robin-pool
    nr-of-instances = 5
  }
}

akka.actor.deployment {
  /parent/router_rrg {
    router = round-robin-group
    # created worker actor names 
    routees.paths = ["/user/workers/w1", "/user/workers/w2", "/user/workers/w3"]
  }
}

//Pool Router 
object RoutingDemoRRP extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrp: ActorRef = context.actorOf(FromConfig.props(Props(new Worker)), "router_rrp")
    
    override def receive: Receive = {
      case x =>
        router_rrp.forward(x)  //Response from router_rrp/Worker goes to 'sender' of parent  ie below ask 
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystem(system, parent, 1.minutes, 1*60*1000)
}
//Group  Router 
object RoutingDemoRRG extends App{
  import Helper._ 
  import akka.pattern._ 
  implicit val timeout = Timeout(5.seconds)
    
  val system = ActorSystem(routingActorSystem, ConfigFactory.load(routingApp)) 
  import system.dispatcher 
  
  val workers: ActorRef = system.actorOf(Props(new Actor {
    val seqw = (1 to 4).toList.map( i => context.actorOf(Props(new Worker), name = s"w$i") )

    override def receive: Receive = {
      case x =>
       println(s"In Workers !!! $x")
    }
  }), "workers")
  
  val parent: ActorRef = system.actorOf(Props(new Actor {
    val router_rrg: ActorRef = context.actorOf(FromConfig.props(), "router_rrg")
    
    override def receive: Receive = {
      case x =>
        router_rrg.forward(x) //Response from router_rrg/Worker goes to 'sender' of parent  ie below ask 
    }
  }), "parent")

  for (_ <- 0 to 5){
      parent.ask( Work("IAMROUTER")).onComplete{
          case Success(Result(str)) => println(s"Result: $str")
          case Failure(ex) => println(s"Result exception: $ex")
          case x =>  println(s"Result ???: $x")
      }
      Thread.sleep(1000)
    }
  killThisSystemSeq(system, Seq(parent, workers), 1.minutes, 1*60*1000)
}




///BalancingPool -- ADVANCED  
A Router that will try to redistribute work from busy routees to idle routees. 
All routees share the same mailbox.
Do not use Broadcast Messages when you use BalancingPool for routers

//conf 
akka.actor.deployment {
  /parent/router_bp {
    router = balancing-pool
    nr-of-instances = 5
    pool-dispatcher {
      attempt-teamwork = off
    }
  }
}
//Same Code as RoutingDemoRRP , only router_rrp line changed to below 
val router_bp: ActorRef =  context.actorOf(FromConfig.props(Props[Worker]), "router_bp")
//OR 
val router_bp: ActorRef =
      context.actorOf(BalancingPool(5).props(Props[Worker]), "router_bp")

//By default the fork-join-dispatcher is used 
//OR 
akka.actor.deployment {
  /parent/router_bptpe {
    router = balancing-pool
    nr-of-instances = 5
    pool-dispatcher {
      executor = "thread-pool-executor"

      # allocate exactly 5 threads for this pool
      thread-pool-executor {
        core-pool-size-min = 5
        core-pool-size-max = 5
      }
    }
  }
}





