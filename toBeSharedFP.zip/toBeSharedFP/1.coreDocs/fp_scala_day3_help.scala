///What is Effect and how to deal with them 
Effect (many times side effects of an computation) is modeled as a container  F[A]
containing the actual type A. For example, in case of exception thrown 
by a computation producing  A ,  effect is container Try[A] which encapsulates
the side effect of exception as well as A if no exception 

The advantage is that encapsulation would hide the side effects till we materialize 
them at our convinient time (Lazy computation) instead of breaking the computation flow 
at the time of occurance of side effect

However, this creates complexity of dealing them eg how to transform A inside F[A]
without materializing the effect .

These dealings can be abstracted(ie many effects can be modeled similarly).  
Few such abstraction are  
(in order of hierarchy ie later effect is a superset of earlier effect 
eg Applicative is also a Functor as map can be written interms of ap )

Functor  for effect, F[A],  has map 
    which transforms A to B by A => B given F[A] and resulting into F[B]
    Signature could be 
        Functor[F[A]].map(as:F[A])(fn:A=>B): F[B]
        or 
        Functor[F[A]].map(fn:A=>B): F[A] => F[B]    
    Another way to look at this as 
    map passes A from F[A](ie peels off effect) to fn : A => B 
    so fn can access whatever is inside effect and converts to B and return 
    
Applicative for effect, F[A],  has ap 
    which transforms A to B by F[A => B] 
    (note transformation is inside effect),   
    given F[A] and resulting into F[B]
    Signature could be 
        Applicative[F[A]].ap(as:F[A])(fn:F[A=>B]): F[B]
        or 
        Applicative[F[A]].map(fn:F[A=>B]): F[A] => F[B]    
    It also has helper which converts A to F[A](called lifting)
    and helper name is pure or unit 
        ApplicativeF[A]].pure[A](a:A):F[A]    
    Using these two, map can be written as (so it is a Functor)
        map[A,B](f: A => B)(fa: F[A]): F[B] = ap(fa)(pure(f))

Monad for effect, F[A], has flatMap 
    which transforms A to B by A => F[B]
    (note transformation produces B inside effect)
    given F[A] and resulting into F[B], 
    Signature could be 
        Monad[F[A]].flatMap[A, B](a: F[A])(fn: A => F[B]): F[B]
        or 
        Monad[F[A]].flatMap[A, B](fn: A => F[B]): F[A] => F[B]        
    (in scala, for is a syntatic sugar of flatMap)
    
    Another way to look at this as 
    flatMap passes A from F[A](ie peels off effect) to fn : A => F[B]
    so fn can access whatever is inside effect and converts to F[B] and return 
    
    Monad is also applicative (ie having pure ) as below could be 
    implementation for map and ap given flatMap 
        map[A, B](a: F[A])(f: A => B): F[B] = flatMap(a)(a => pure(f(a)))
        ap[A, B](ff: F[A => B])(fa: F[A]): F[B] = flatMap(f) { (fab: (A => B)) => map(a)(fab)}


Another advantage is that many effects can be composed over these abstractions 
and composed effects can be transformed together , just like simple effect.
    Functor[F[_]].compose[G[_]: Functor]: Functor[F[G[_]]
    Applicative[F[_]].compose[G[_]: Applicative]: Applicative[F[G[_]]
In case of Monad, we have Monad transfomer.

However, to apply these abstractions for an effect, particular implementation 
must satisfy few rules/properties such that composition etc can be safely applied 

///Effect : Option[T] 
//Option ADT 
sealed abstract class Option[+A]
case object None extends Option[Nothing]
final case class Some[+A](value: A) extends Option[A]

class Request {
    import scala.util.Random 
    val r = new Random 
    def nget = {
        if (r.nextInt(10) < 5) "Hello" else null
    }
    def get = Option(nget)
}

val ls = (0 to 10).toList.map{i => (new Request).get }
//map 
ls.map { o => o.map{_.size} }
//collapse
ls.flatMap { o => o.map{_.size} }
//OR collect take PF
ls.collect{ case Some(x) => x }
//OR map takes Function 
ls.map { 
    case Some(x) => x 
    case None  => "" 
    }

// monadic 
val one = (new Request).get 
one.map(_.trim).filter(_.size > 1).map(_.toUpperCase)
one.getOrElse("NOT FOUND")
Option(null).get

//OR  
one match {
    case Some(x) => println(x)
}

///Effect: Try[T] 
//Try ADT 
sealed abstract class Try[+T]
final case class Success[+T](value: T) extends Try[T]
final case class Failure[+T](exception: Throwable) extends Try[T]

//Example 
import scala.util._ 
class Request {
    import scala.util.Random 
    val r = new Random 
    def eget = {
        val den = if (r.nextInt(10) < 5) 42 else 0
        42/den
    }
    def get = Try(eget)
}
val ls = (0 to 10).toList.map{i => (new Request).get }
//map 
ls.map { o => o.map{x=>x*x} }

//following not there as Try does not implement flatten 
ls.flatMap{ o => o.map{x=>x*x} }
//but 
ls.collect{ case Success(x) => x}

// monadic 
val one = (new Request).get 
one.map(_.toString).map(_.trim).filter(_.size >= 1).map(_.toUpperCase)
one.toOption
one.toOption.get



///HANDS ON - fq.txt 
1. Read fq.txt file 
2. Each element of a row can be Int, Double or String or not present 
   Design appropriate class with conversion method from string 
   Handle exception appropriately 
3. Each row is represented by java.time.LocalDate, java.time.LocalTime and list of elements  for rest 
   instance(columnNumber) to get option of element (as element might not be present) 
   instance.year gives yeare etc convience methods 
   DateTimeFormatter.ISO_LOCAL_DATE and DateTimeFormatter.ISO_LOCAL_TIME are the formatters 
   Design appropriate class with above 
5. Group by Year vs 5 th column which is Int




///Effect: Future[T]

import scala.concurrent._ 
import scala.concurrent.duration._ 
import scala.concurrent.ExecutionContext.Implicits.global //default threadpool 

val fut = Future {
    Thread.sleep(10)
    "Hello"
}
//monadic 
fut.map{ x => x.toUpperCase}.filter(e => e.size != 0).map{_.size}
//Future[Int] = Future(<not completed>)

val re = Await.result(res54, Duration.Inf)

//or 
res54.foreach(println) 

//or 
res54.onSuccess{ case x:Int => println(x)}

//or 
res54.onComplete{
    case Success(x) => println(x)
    case Failure(ex) => println(ex)
}

//Note these are not in parallel, but in sequence 
def delta(startTime:Long) = System.currentTimeMillis - startTime
def time = System.currentTimeMillis
def sleep(time: Long): Unit = Thread.sleep(time)

val startTime = time
val fut = for {
    a <- Future { sleep(1000); 2*2 }
    b <- Future{ sleep(1000); "Hello" }.mapTo[String]
    c <- Future{ sleep(1000); a- 1} if a > 0
} yield {
    a*b.size*c 
}
println(Await.result(fut, Duration.Inf))
println(delta(startTime)) // ~3000 sec 

//To make it parallel , create them seperately as val 
val startTime = time
val a = Future { sleep(1000); 2*2 }
val b = Future{ sleep(1000); "Hello" }.mapTo[String]

val fut = for {
    a1 <- a
    b1 <- b
    c1 <- Future{ sleep(1000); a1 - 1} if a1 > 0
} yield {
    a1*b1.size*c1 
}
println(Await.result(fut, Duration.Inf))
println(delta(startTime))  //~2000 sec 

///Complex Future - download Example 
import scala.concurrent._
import scala.concurrent.ExecutionContext.Implicits.global //must for execution context
import scala.util._  //Success,Failure 
import scala.concurrent.duration._

//Dowload and sum of the bytes 

def get(url: String) = scala.io.Source.fromURL(url).getLines.toList.mkString
def create_urls(n:Int) =
       (0 to n).toList.map( e=> "https://www.google.co.in")

val htmls = create_urls(5).map {
        url => Future {   
            println(Thread.currentThread.getName)
            blocking { get(url) } 
        }.map(_.size)            
    } //List of Future
    
//Use sequence(simpler version of traverse)
//def sequence[A, M[X] <: TraversableOnce[X]](in: M[Future[A]])(implicit cbf: CanBuildFrom[M[Future[A]], A, M[A]], executor: ExecutionContext): Future[M[A]] 
// to convert imagesFuts from List[Future[...]] to a Future[List[...]].
//But one exception would result into full failure , hence only wait for this 
//but iterate original htmls 
val html2 = Future.sequence(htmls)   // Future of List 

//Or durectly using traverse
//def traverse[A, B, M[X] <: TraversableOnce[X]](in: M[A])(fn: (A) => Future[B])(implicit cbf: CanBuildFrom[M[A], B, M[B]], executor: ExecutionContext): Future[M[B]] 
//But one exception would result into full failure , hence only wait for this  

val html3 = Future.traverse(create_urls(5)){ url => 
    Future {   
            println(Thread.currentThread.getName)
            blocking { get(url) } 
        }.map(_.size)
} // Future of List 

Await.result(html2, Duration.Inf).sum 
Await.result(html3, Duration.Inf).sum 

If 'one exception would result into full failure' is not wanted , can use below types 
Future.firstCompletedOf[T](futures: IterableOnce[Future[T]])(implicit executor: ExecutionContext): Future[T]
Future.foldLeft[T, R](futures: collection.immutable.Iterable[Future[T]])(zero: R)(op: (R, T) => R)(implicit executor: ExecutionContext): Future[R]
//example 
f_fut = Future.foldLeft(htmls)(0)( (r,t) => r+t)
Await.result(html3, Duration.Inf)



///Duration 
import scala.concurrent.duration._
import java.util.concurrent.TimeUnit._

// instantiation
val d1 = Duration(100, MILLISECONDS) // from Long and TimeUnit
val d2 = Duration(100, "millis") // from Long and String
val d3 = 100 millis // implicitly from Long, Int or Double
val d4 = Duration("1.2 µs") // from String

// pattern matching
val Duration(length, unit) = 5 millis

///blocking construct
Used to designate a piece of code which potentially blocks, 
allowing the current BlockContext to adjust the runtime behavior. 
Properly marking blocking code may improve performance or avoid deadlocks.

//Usage - download
import scala.concurrent._

def get(url: String) = scala.io.Source.fromURL(url).getLines.toList.mkString

Future {
    blocking { get("http://www.example.com") }
} onComplete {
    case Success(html) => println("Result: " + html.length)
    case Failure(ex) => println(ex)
}

If you need to wrap long lasting blocking operations 
we recommend using a dedicated ExecutionContext instead of default threadpool 

val explicitly_created_executionContext = ExecutionContext.fromExecutor(
  new java.util.concurrent.ForkJoinPool(4) //initialParallelism: Int
)
OR 
val explicitly_created_executionContext = 
    ExecutionContext.fromExecutor(java.util.concurrent.Executors.newFixedThreadPool(4)) //limit: Int


Future {
    blocking {
      Thread.sleep(999999)
    }
  }(explicitly_created_executionContext)


///Recovering failed one , Result is Future 
'recover' - recover's PartiatialFunction returns simple value
'recoverWith'  - recoverWith's PartiatialFunction returns another Future
'fallbackTo'  - fallbackTo simply takes another future 

//Example 
val f = Future { 1/0 } recover { case e:Exception => 25 }

val f = Future { 1/0 } recoverWith { case e:Exception => Future { 200} }

val f = Future { 1/0 }.fallbackTo(Future { 200} )



///Few more methods of Future 
def  andThen[U](pf: PartialFunction[Try[T], U]): Future[T] 
//Applies Partial function(with Success or Failure) to the result of this future
//and returns a new future with final result 
 
val allposts = collection.mutable.Set[String]()

Future {
  List("Hello", "world")  
} andThen {
  case Success(posts) => allposts ++= posts
} andThen {
  case Success(posts) =>  for (post <- allposts) println(post)
}


///Promises - single time set 
import scala.concurrent.{ Future, Promise }
import scala.concurrent.ExecutionContext.Implicits.global

val p = Promise[Int]()
val f = p.future

def produceSomething() = 22
def continueDoingSomethingUnrelated() = ()
def startDoingSomething() = ()
def doSomethingWithResult(r:Int) = ()

val producer = Future {
  val r = produceSomething()
  p success r
  continueDoingSomethingUnrelated()
}

val consumer = Future {
  startDoingSomething()
  f foreach { r =>
    doSomethingWithResult(r)
  }
}

//Other usages 
To fail 
val p = Promise[T]()
val f = p.future

val producer = Future {
  val r = someComputation
  if (isInvalid(r))
    p failure (new IllegalStateException)
  else {
    val q = doSomeMoreComputation(r)
    p success q
  }
}

Or with another future 
val f = Future { 1 }
val p = Promise[Int]()

p completeWith f

p.future foreach { x =>
  println(x)
}

Or with trysuccess 
def first[T](f: Future[T], g: Future[T]): Future[T] = {
  val p = Promise[T]

  f foreach { x =>
    p.trySuccess(x)
  }

  g foreach { x =>
    p.trySuccess(x)
  }

  p.future
}

///Effect: Either[A, B]
Either represents the possibility of a function having 
one of two alternative results which
can not be represented by a single type.

//adt 
sealed abstract class Either[+A, +B]
final case class Left[+A, +B](value: A) extends Either[A, B]
final case class Right[+A, +B](value: B) extends Either[A, B]

//Example 
import scala.util._ 

class Request {
    import scala.util.Random 
    val r = new Random 
    def eget = if (r.nextInt(10) < 5) 42 else -42

    //def cond[A, B](test: Boolean, right_when_true: => B, left_when_false: => A): Either[A, B]
    def get = {
        val x = eget
        Either.cond(eget > 0, x, "negative_value")
     }
}
val ls = (0 to 10).toList.map{i => (new Request).get }
//map 
ls.map { case Right(x) => x*x 
         case Left(str) => str.size}

Either is right-biased, which means that Right is assumed to be the default case 
to operate on. 
If it is Left, operations like map and flatMap return the Left value unchanged:

def doubled(i: Int) = i * 2
Right(42).map(doubled) // Right(84)
Left(42).map(doubled)  // Left(42)

Right(12).foreach(println) // prints "12"
Left(12).foreach(println)  // doesn't print

Right(12).getOrElse(17) // 12
Left(12).getOrElse(17)  // 17

Right(12).toOption // Some(12)
Left(12).toOption  // None

val left: Either[String, Int]  = Left("left")
val right: Either[Int, String] = left.swap // Result: Right("left")

val right = Right(2)
val left  = Left(3)
for {
  r1 <- right
  r2 <- left.swap
} yield r1 * r2 // Right(6)

///Option, Try and Either fold --ADVANCED  
The Either.fold method is unbiased as it treats the left and right sides 
of Either equally.

Either[+A, +B]
    def fold[C](fa: (A) => C, fb: (B) => C): C
        Applies fa if this is a Left or fb if this is a Right.
    //Example 
    val result = util.Try("42".toInt).toEither
    result.fold(
      e => s"Operation failed with $e",
      v => s"Operation produced value: $v"
    )    
   
Option[+A]   
    def fold[B](ifEmpty: => B)(f: (A) => B): B
        This is equivalent to:
        option match {
          case Some(x) => f(x)
          case None    => ifEmpty
        }

Try[+T]
    def fold[U](fa: (Throwable) => U, fb: (T) => U): U
        Applies fa if this is a Failure or fb if this is a Success.
        //Example 
        val result: Try[Int] = Try { string.toInt }
        println(result.fold(
          ex => "Operation failed with " + ex,
          v => "Operation produced value: " + v
        ))
        
Future[+T]     
    def transform[S](f: (Try[T]) => Try[S])(implicit executor: ExecutionContext): Future[S]
        Creates a new Future by applying the specified function to the result of this Future.
    def transformWith[S](f: (Try[T]) => Future[S])(implicit executor: ExecutionContext): Future[S]
        Creates a new Future by applying the specified function, which produces a Future, 
        to the result of this Future.
    //
    val fut = Future( 100 ).transform { case Success(n) => Success(n-10)
                              case Failure(ex) => Failure(ex) }
    Await.result(fut, Duration.Inf)
        
        

       
        

///Algebraic Data Types (ADT) vs Algebric Structure  -- ADVANCED 
Algebraic data types (ADTs) are way of representing data using "ands" and "ors".
  a shape is a rectangle or a circle 
    'or' represented via sealed trait , a Coproduct or Sum 
  a rectangle has a width and a height 
    'and' represnted by case class , a Product 
  a circle has a radius
  
When sealed trait takes type parameter, it is GADT (Generalized ADT)
//eg below is GADT 

sealed trait Optional[+T] {                         //a Coproduct or Sum
   //Pattern matching is the way to handle ADT 
   def isDefined: Boolean = this match
      case Nn => false
      case _    => true
}
case class Sm[T](x:T) extends Optional[T]           //a Product 
case object Nn extends Optional[Nothing]

object Optional{
   def apply[T >: Null](x: T): Optional[T] =
      if x == null then Nn else Sm(x)
   //smart constructors 
   def sm[T](x:T):Optional[T] = Some(x)
   def nn:Optional[Nothing]  = Nn
}

List(Optional.sm(2), Optional.sm(3), Optional.nn)

Compred to Above Algebric Structures are from Abstract Algebra 
which abstracts computation(mathematical )

Many Datatypes can be abstracted by algebric structure 
which helps us in finding the commonality of them and write generic code for them 

Few examples are - List is monoid , Map is monoid and then can be operated 
with same syntax/functionality of Monoid , Monoid is also Semigroup 


///Algebric Type class -  Semigroup
Semigroup is fully defined by two qualities:
    It is defined for some (possibly infinite) set of elements
    It has a binary operation defined for any pairs of elements in this set
    
Example of Semigroups are Int, Double where op can be + 

trait Semigroup[S] {
  def combine(l: S, r: S): S
}

//Example using cats 
Cats use |+| for combine , has many implicits 
//https://github.com/typelevel/cats/blob/main/kernel/src/main/scala/cats/kernel/Semigroup.scala
eg Int, List Maps are examples of Semigroups 

import cats.implicits._

1 |+| 2
// res4: Int = 3

val map1 = Map("hello" -> 1, "world" -> 1)
val map2 = Map("hello" -> 2, "cats"  -> 3)

map1 |+| map2
// res6: Map[String, Int] = Map("hello" -> 3, "cats" -> 3, "world" -> 1)

//Complex combine 
def optionCombine[A: Semigroup](a: A, opt: Option[A]): A =
  opt.map(a |+| _).getOrElse(a)

def mergeMap[K, V: Semigroup](lhs: Map[K, V], rhs: Map[K, V]): Map[K, V] =
  lhs.foldLeft(rhs) {
    case (acc, (k, v)) => acc.updated(k, optionCombine(v, acc.get(k)))
  }

val xm1 = Map('a' -> 1, 'b' -> 2)
// xm1: Map[Char, Int] = Map('a' -> 1, 'b' -> 2)
val xm2 = Map('b' -> 3, 'c' -> 4)
// xm2: Map[Char, Int] = Map('b' -> 3, 'c' -> 4)

val x = mergeMap(xm1, xm2)
// x: Map[Char, Int] = Map('b' -> 5, 'c' -> 4, 'a' -> 1)

val ym1 = Map(1 -> List("hello"))
// ym1: Map[Int, List[String]] = Map(1 -> List("hello"))
val ym2 = Map(2 -> List("cats"), 1 -> List("world"))
// ym2: Map[Int, List[String]] = Map(2 -> List("cats"), 1 -> List("world"))

val y = mergeMap(ym1, ym2)
// y: Map[Int, List[String]] = Map(
//   2 -> List("cats"),
//   1 -> List("hello", "world")
// )

///SemiGroup - property 
It also has the following two properties:
    The operation is closed, which means that the result of the operation belongs to
    the same set as its operands

    The operation is associative, meaning that multiple operations should produce
    the same result, regardless of the order in which they are applied
    
    
//With propcheck 
import org.scalacheck._
import org.scalacheck.Prop._
import cats.implicits._
import cats._

def associativity[S : Semigroup : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Semigroup[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
    
implicitly[Semigroup[Int]]
implicitly[Arbitrary[Int]]

associativity[Int].check()

///SemiGroup - With cats-law and testing for custom class -- ADVANCED 
import cats._ 
import cats.implicits._

sealed trait Tree[+A]
final case class Node[A](p: A, left: Tree[A], right: Tree[A]) extends Tree[A]
final case class Leaf[A](value: A) extends Tree[A]
 
object Tree {
    def node[A](p:A, left: Tree[A], right: Tree[A]): Tree[A] =
     Node(p, left, right)
    def leaf[A](value: A): Tree[A] =
     Leaf(value)
     
  implicit def semigroupTree[A: Semigroup]: Semigroup[Tree[A]] = new Semigroup[Tree[A]] {
    def combine(x: Tree[A], y: Tree[A]) = (x, y) match {
      case (Leaf(v1), Leaf(v2)) => leaf(v1 |+| v2)
      case (Leaf(v), Node(yp, yLeft, yRight)) => node(v |+| yp, yLeft, yRight)
      case (Node(xp, xLeft, xRight), Leaf(v)) => node(xp |+| v, xLeft, xRight) 
      case (Node(xp, xLeft, xRight), Node(yp, yLeft, yRight)) =>
        node(xp |+| yp, xLeft |+| yLeft, xRight |+| yRight)
    }
  }
 }
 
import org.scalacheck._

object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[Tree[A]] =
    Arbitrary(Gen.oneOf(    
    (for {
      l <- Arbitrary.arbitrary[A]
    } yield Leaf(l)), 
    (for {
      e <- Arbitrary.arbitrary[A]
      l1 <- Arbitrary.arbitrary[A]
      l2 <- Arbitrary.arbitrary[A]
    } yield Node(e, Leaf(l1), Leaf(l2)))
    )
  )
}


import cats.kernel.laws.discipline.SemigroupTests
//import cats.kernel.laws.discipline.MonoidTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

class TreeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
  import arbitraries._ 
  implicit def eqTree[A: Eq]: Eq[Tree[A]] = Eq.fromUniversalEquals
  checkAll("Tree[Int].SemigroupLaws", SemigroupTests[Tree[Int]].semigroup)
  //checkAll("Tree[Int].MonoidLaws", MonoidTests[Tree[Int]].monoid)
}
scala> org.scalatest.run(new TreeLawTests())
TreeLawTests:
- Tree[Int].SemigroupLaws.semigroup.associative
- Tree[Int].SemigroupLaws.semigroup.combineAllOption
- Tree[Int].SemigroupLaws.semigroup.intercalateCombineAllOption
- Tree[Int].SemigroupLaws.semigroup.intercalateIntercalates
- Tree[Int].SemigroupLaws.semigroup.intercalateRepeat1
- Tree[Int].SemigroupLaws.semigroup.intercalateRepeat2
- Tree[Int].SemigroupLaws.semigroup.repeat1
- Tree[Int].SemigroupLaws.semigroup.repeat2
- Tree[Int].SemigroupLaws.semigroup.reverseCombineAllOption
- Tree[Int].SemigroupLaws.semigroup.reverseRepeat1
- Tree[Int].SemigroupLaws.semigroup.reverseRepeat2
- Tree[Int].SemigroupLaws.semigroup.reverseReverses



///Algebric Type class  - Monoid
A monoid is a semigroup with an identity element. 

trait Monoid[S] extends Semigroup[S] {
 def empty: S  //Identity 
}

//monoid for Int is implemented like 
implicit val intAddition: Monoid[Int] = new Monoid[Int] {
    override def empty: Int = 0
    override def combine(l: Int, r: Int): Int = l + r
}

The properties of Monoid 
    Properties of Semigroup eg associative and closure 
    Identity property 
        Formally, the identity element z is an element for which an equation, 
        z + x = x + z = x, holds for any x. 

///Monoid - Properties testing manually 
def associativity[S : Monoid : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Monoid[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
    
def identity[S : Monoid : Arbitrary]: Prop =
 forAll((a: S) => {
    val m = implicitly[Monoid[S]]
     m.combine(a, m.empty) == a && m.combine(m.empty, a) == a
  })

def monoidProp[S : Monoid : Arbitrary]: Prop = associativity[S] &&  identity[S]

monoidProp[Int].check()

///Why we require Monoid 
//eg  Collapsing a list - not possible with SemiGroup as Identity is missing 
def combineAll[A: Semigroup](as: List[A]): A =
  as.foldLeft(/* ?? what goes here ?? */)(_ |+| _)

//With Monoid 
def combineAll[A: Monoid](as: List[A]): A =
  as.foldLeft(Monoid[A].empty)(Monoid[A].combine)
  
This function is provided in Cats as Monoid.combineAll.
https://github.com/typelevel/cats/blob/main/kernel/src/main/scala/cats/kernel/Monoid.scala


Has many default implicits (whereever Zero is possible)
//Example 
import cats.Monoid
import cats.implicits._

Monoid.combineAll(List(1, 2, 3))
// res3: Int = 6

Monoid.combineAll(List("hello", " ", "world"))
// res4: String = "hello world"

Monoid.combineAll(List(Map('a' -> 1), Map('a' -> 2, 'b' -> 3), Map('b' -> 4, 'c' -> 5)))
// res5: Map[Char, Int] = Map('b' -> 7, 'c' -> 5, 'a' -> 3)

Monoid.combineAll(List(Set(1, 2), Set(2, 3, 4, 5)))
// res6: Set[Int] = Set(5, 1, 2, 3, 4)

///Example of Semigroup but not Monoid -- ADVANCED 
There are some types that can form a Semigroup but not a Monoid. 

For example, the following NonEmptyList type forms a semigroup through ++, 
but has no corresponding identity element to form a monoid.

import cats.Semigroup

final case class NonEmptyList[A](head: A, tail: List[A]) {
  def ++(other: NonEmptyList[A]): NonEmptyList[A] = NonEmptyList(head, tail ++ other.toList)
  def toList: List[A] = head :: tail
}

object NonEmptyList {
  implicit def nonEmptyListSemigroup[A]: Semigroup[NonEmptyList[A]] =
    new Semigroup[NonEmptyList[A]] {
      def combine(x: NonEmptyList[A], y: NonEmptyList[A]): NonEmptyList[A] = x ++ y
    }
}

How then can we collapse a List[NonEmptyList[A]] ? 
For such types that only have a Semigroup we can lift into Option to get a Monoid.

import cats.implicits._

implicit def optionMonoid[A: Semigroup]: Monoid[Option[A]] = new Monoid[Option[A]] {
  def empty: Option[A] = None

  def combine(x: Option[A], y: Option[A]): Option[A] =
    x match {
      case None => y
      case Some(xv) =>
        y match {
          case None => x
          case Some(yv) => Some(xv |+| yv)
        }
    }
}
//Then usage 
import cats.Monoid
import cats.data.NonEmptyList //cats already has NonEmptyList
import cats.implicits._

val list = List(NonEmptyList(1, List(2, 3)), NonEmptyList(4, List(5, 6)))
val lifted = list.map(nel => Option(nel))

Monoid.combineAll(lifted)
// res8: Option[NonEmptyList[Int]] = Some(NonEmptyList(1, List(2, 3, 4, 5, 6)))






///Monoid - With cats-law and testing -- ADVANCED 
import cats._ 
import cats.implicits._

sealed trait Tree[+A]

case class Node[A](p: A, left: Tree[A], right: Tree[A]) extends Tree[A]
final case class Leaf[A](value: A) extends Tree[A]
 
object Tree {
    def node[A](p:A, left: Tree[A], right: Tree[A]): Tree[A] =
     Node(p, left, right)
    def leaf[A](value: A): Tree[A] =
     Leaf(value)
     
  implicit def monoidTree[A: Monoid]: Monoid[Tree[A]] = new Monoid[Tree[A]] {
    def combine(x: Tree[A], y: Tree[A]) = (x, y) match {
      case (Leaf(v1), Leaf(v2)) => leaf(v1 |+| v2)
      case (Leaf(v), Node(yp, yLeft, yRight)) => node(v |+| yp, yLeft, yRight)
      case (Node(xp, xLeft, xRight), Leaf(v)) => node(xp |+| v, xLeft, xRight) 
      case (Node(xp, xLeft, xRight), Node(yp, yLeft, yRight)) =>
        node(xp |+| yp, xLeft |+| yLeft, xRight |+| yRight)
    }
    def empty: Tree[A] = leaf(Monoid[A].empty)    
  }
 }
import org.scalacheck._

object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[Tree[A]] =
    Arbitrary(Gen.oneOf(    
    (for {
      l <- Arbitrary.arbitrary[A]
    } yield Leaf(l)), 
    (for {
      e <- Arbitrary.arbitrary[A]
      l1 <- Arbitrary.arbitrary[A]
      l2 <- Arbitrary.arbitrary[A]
    } yield Node(e, Leaf(l1), Leaf(l2)))
    )
  )
}
import cats.kernel.laws.discipline.MonoidTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

class TreeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
  import arbitraries._ 
  implicit def eqTree[A: Eq]: Eq[Tree[A]] = Eq.fromUniversalEquals
  checkAll("Tree[Int].MonoidLaws", MonoidTests[Tree[Int]].monoid)
}
scala > org.scalatest.run(new TreeLawTests())

///Quick Eval from Cats    
Eval is a data type(actually a monad) for controlling synchronous evaluation. 

//Eval.now - eager evaluation 
import cats.Eval
import cats.implicits._


val eager = Eval.now {
  println("Running expensive calculation...")
  1 + 2 * 3
}
// Running expensive calculation...
// eager: Eval[Int] = Now(7)

egar.map( _ * 3) //as it is monad 

//Then get the value 
eager.value
// res0: Int = 21

//Eval.later- lazy evaluation, with memoization, like lazy val 
val lazyEval = Eval.later {
  println("Running expensive calculation...")
  1 + 2 * 3
}
// lazyEval: Eval[Int] = cats.Later@22ea4e3

lazyEval.value
// Running expensive calculation...
// res1: Int = 7

lazyEval.value
// res2: Int = 7

//Eval.always - lazy evaluation without memoization eg like Function0
val always = Eval.always {
  println("Running expensive calculation...")
  1 + 2 * 3
}
// always: Eval[Int] = cats.Always@29e3bb1b

always.value
// Running expensive calculation...
// res3: Int = 7

always.value
// Running expensive calculation...
// res4: Int = 7


///Algebric Type class - Foldable
Foldable type class instances can be defined for data structures 
that can be folded to a summary value.

Similar concept for Monoid(with Monoid.empty) is Reducible 

trait Reducible[A] {
    def reduceLeft(op: (A, A) => A): A
    def reduceRight(op: (A, A) => A): A
}

Foldable approach allows us to use any structure, not only monoids, for folding. 

trait Foldable[F[_]] {
 def foldLeft[A,B](as: F[A])(z: B)(f: (B, A) => B): B
 //note fn arg is reversed 
 def foldRight[A,B](as: F[A])(z: B)(f: (A, B) => B): B
}

//Example implementation for List 
def listFoldable: Foldable[List] = new Foldable[List] {
    def foldRight[A,B](as: F[A])(z: B)(f: (A, B) => B): B =
            as.foldRight(z)(f)
    def foldLeft[A,B](as: F[A])(z: B)(f: (B, A) => B): B =
            as.foldLeft(z)(f)
}



///Foldable from cats 
Note that, in order to support laziness(end could be infinite ), 
the signature of Foldable’s foldRight uses Eval[B] in cats 

trait Foldable[F[_]] {
    def foldLeft[A, B](fa: F[A], b: B)(f: (B, A) => B): B
    //note fn arg is reversed 
    def foldRight[A, B](fa: F[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B]
    
    //many concrete implementation 
    //https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/Foldable.scala
    def fold[A](fa: F[A])(implicit A: Monoid[A]): A =  A.combineAll(toIterable(fa))
    //Derived  - map and then fold   
    def foldMap[A, B](fa: F[A])(f: A => B)(implicit B: Monoid[B]): B =
        foldLeft(fa, B.empty)((b, a) => B.combine(b, f(a)))
    
    //Convert F[A] to an Iterable[A].
    def toIterable[A](fa: F[A]): Iterable[A] = ...
}

//Example implementation for List 
def listFoldable: Foldable[List] = new Foldable[List] {

    def foldLeft[A, B](fa: List[A], b: B)(f: (B, A) => B): B =
            fa.foldLeft(b)(f)

    def foldRight[A, B](fa: List[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B] = {
        def loop(as: List[A]): Eval[B] =
          as match {
            case Nil    => lb
            case h :: t => f(h, Eval.defer(loop(t)))
          }
        Eval.defer(loop(fa))
    }
}

//Explicits over Implicits
Remember that Scala will only use an instance of Foldable if the
method isnot explicitly available on the receiver. 

For example, the following code will use the version of foldLeft defined on List:

List(1, 2, 3).foldLeft(0)(_ + _)
// res14: Int = 6

whereas the following generic code will use Foldable:
def sum[F[_]: Foldable](values: F[Int]): Int =
      values.foldLeft(0)(_ + _)

///Foldable Example 
import cats._
import cats.implicits._ 

//def fold[A](fa: F[A])(implicit A: Monoid[A]): A 
Foldable[List].fold(List("a", "b", "c"))
// res0: String = "abc"

//def foldMap[A, B](fa: F[A])(f: A => B)(implicit B: Monoid[B]): B =
Foldable[List].foldMap(List(1, 2, 4))(_.toString)
// res1: String = "124"

Foldable[List].find(List(1,2,3))(_ > 2)
// res7: Option[Int] = Some(3)
Foldable[List].exists(List(1,2,3))(_ > 2)
// res8: Boolean = true
Foldable[List].forall(List(1,2,3))(_ > 2)
// res9: Boolean = false
Foldable[List].forall(List(1,2,3))(_ < 4)
// res10: Boolean = true

Foldable[List].isEmpty(List(1,2))
// res12: Boolean = false
Foldable[Option].isEmpty(None)
// res13: Boolean = true
Foldable[List].nonEmpty(List(1,2))
// res14: Boolean = true

val allFalse = Stream.continually(false)
// allFalse: Stream[Boolean] = Stream(
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
//   false,
// ...

which is an infinite stream of false values, 
and if you wanted to reduce this to a single false value using the logical and (&&).
 
You intuitively know that the result of this operation should be false. 
It is not necessary to consider the entire stream in order to determine this result, 
you only need to consider the first value. 

Using foldRight from the standard library will try to consider the entire stream, 
and thus will eventually cause a stack overflow:

try {
  allFalse.foldRight(true)(_ && _)
} catch {
  case e:StackOverflowError => println(e)
}
// java.lang.StackOverflowError
// res29: AnyVal = ()

With the lazy foldRight on Foldable, the calculation terminates 
after looking at only one value:

//def foldRight[A, B](fa: F[A], lb: Eval[B])(f: (A, Eval[B]) => Eval[B]): Eval[B]
Foldable[Stream].foldRight(allFalse, Eval.True)((a,b) => if (a) b else Eval.False).value
// res30: Boolean = false

///Cats law for Foldable -- ADVANCED 
import cats._ 
import cats.implicits._
import org.scalacheck._
import org.scalacheck.Prop._

import cats.laws.discipline.FoldableTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

class FTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
  checkAll("List[Int].FoldableLaws", FoldableTests[List].foldable[Int,Int])
}
scala > org.scalatest.run(new FTests())

FTests:
- List[Int].FoldableLaws.foldable.collectFirst reference
- List[Int].FoldableLaws.foldable.collectFirstSome reference
- List[Int].FoldableLaws.foldable.dropWhile_ reference
- List[Int].FoldableLaws.foldable.exists consistent with find
- List[Int].FoldableLaws.foldable.exists is lazy
- List[Int].FoldableLaws.foldable.filter_ reference
- List[Int].FoldableLaws.foldable.fold reference
- List[Int].FoldableLaws.foldable.foldLeft consistent with foldMap
- List[Int].FoldableLaws.foldable.foldM identity
- List[Int].FoldableLaws.foldable.foldRight consistent with foldMap
- List[Int].FoldableLaws.foldable.foldRight is lazy
- List[Int].FoldableLaws.foldable.foldRightDefer consistency
- List[Int].FoldableLaws.foldable.forall consistent with exists
- List[Int].FoldableLaws.foldable.forall is lazy
- List[Int].FoldableLaws.foldable.forall true if empty
- List[Int].FoldableLaws.foldable.get reference
- List[Int].FoldableLaws.foldable.nonEmpty reference
- List[Int].FoldableLaws.foldable.ordered consistency
- List[Int].FoldableLaws.foldable.reduceLeftOption consistent with reduceLeftToOption
- List[Int].FoldableLaws.foldable.reduceRightOption consistent with reduceRightToOption
- List[Int].FoldableLaws.foldable.takeWhile_ reference
- List[Int].FoldableLaws.foldable.toList reference
- List[Int].FoldableLaws.foldable.unorderedFold consistent with unorderedFoldMap


///Versatility of foldLeft/Right -- ADVANCED 
foldLeft and foldRight are very general methods.
And we can implement others eg map, flatmap etc 

def map[A, B](list: List[A])(func: A => B): List[B] =
    list.foldRight(List.empty[B]) { (item, accum) =>
       func(item) :: accum
    }

map(List(1, 2, 3))(_ * 2)
// res9: List[Int] = List(2, 4, 6)


def flatMap[A, B](list: List[A])(func: A => List[B]): List[B] =
    list.foldRight(List.empty[B]) { (item, accum) =>
       func(item) ::: accum
    }


flatMap(List(1, 2, 3))(a => List(a, a * 10, a * 100))
// res10: List[Int] = List(1, 10, 100, 2, 20, 200, 3, 30, 300)


def filter[A](list: List[A])(func: A => Boolean): List[A] =
    list.foldRight(List.empty[A]) { (item, accum) =>
       if(func(item)) item :: accum else accum
    }


filter(List(1, 2, 3))(_ % 2 == 1)
// res11: List[Int] = List(1, 3)

//We ve provided two definitions of sum, 
import scala.math.Numeric

def sumWithNumeric[A](list: List[A])(implicit numeric: Numeric[A]): A =
    list.foldRight(numeric.zero)(numeric.plus)

sumWithNumeric(List(1, 2, 3))
// res12: Int = 6

//and one using cats.Monoid 
import cats._
import cats.implicits._ 


def sumWithMonoid[A](list: List[A])(implicit monoid: Monoid[A]): A =
    list.foldRight(monoid.empty)(monoid.combine)

sumWithMonoid(List(1, 2, 3))
// res13: Int = 6



///Group: Monoid with Inverse
Abstract algebraic structures do not end with monoids. 
In fact, there are a lot of more advanced definitions out there like the
group, abelian group(commutative group), and ring(with two ops)
  

//Ie Group contains all below 
trait Group[A] {
  def empty: A // identity
  def inverse(a: A): A
  def combine(a: A, b: A): A
}
Abelian Group properties 
    Group Properties 
        Properties of Monoid eg associative and closure and  Identity property 
        Inverse Properties 
            the Inverse element z of x is an element for which an equation,   
            z + x = x + z = identity, holds for any x. 
    Commutative properties 
        For each a and b, a + b = b + a
    



///Group - Checking Props -- ADVANCED 
trait Semigroup[A] {
  def combine(l: A, r: A): A
}
trait Monoid[A] extends Semigroup[A] {
 def empty: A  //Identity 
}

trait Group[A] extends Monoid[A]{
  def inverse(a: A): A
}

import org.scalacheck._
import org.scalacheck.Prop._

def associativity[S : Semigroup : Arbitrary]: Prop =
    forAll((a: S, b: S, c: S) => {
      val sg = implicitly[Semigroup[S]]
      sg.combine(sg.combine(a, b), c) == sg.combine(a, sg.combine(b, c))
    })
    
def identity[S : Monoid : Arbitrary]: Prop =
 forAll((a: S) => {
    val m = implicitly[Monoid[S]]
     m.combine(a, m.empty) == a && m.combine(m.empty, a) == a
  })

def monoidProp[S : Monoid : Arbitrary]: Prop = associativity[S] &&  identity[S]


def invertibility[S : Group : Arbitrary]: Prop =
  forAll((a: S) => {
    val m = implicitly[Group[S]]
     m.combine(a, m.inverse(a)) == m.empty && m.combine(m.inverse(a), a) ==   m.empty
  })
  
def groupProp[S : Group: Arbitrary]: Prop = monoidProp[S] && invertibility[S]

//For abelian group 
def commutativity[S : Group : Arbitrary]: Prop =
  forAll((a: S, b: S) => {
    val m = implicitly[Group[S]]
     m.combine(a, b) == m.combine(b, a)
  })

def abelianGroupProp[S : Group: Arbitrary]: Prop =    groupProp[S] && commutativity[S]


One example of the abelian group is integer under addition. 

implicit val intAddition: Group[Int] = new Group[Int] {
 override def empty: Int = 0
 override def combine(l: Int, r: Int): Int = l + r
 override def inverse(a: Int): Int = empty - a
}

//Usage 
abelianGroupProp[Int].check 

///Group Tests from cats-law 

import cats._ 
import cats.implicits._
import org.scalacheck._
import org.scalacheck.Prop._

import cats.kernel.laws.discipline.GroupTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

class IntGroupTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
  checkAll("Int.GroupLaws", GroupTests[Int].group)
}
scala > org.scalatest.run(new IntGroupTests())
IntGroupTests:
- Int.GroupLaws.group.associative
- Int.GroupLaws.group.collect0
- Int.GroupLaws.group.combine all
- Int.GroupLaws.group.combineAllOption
- Int.GroupLaws.group.consistent inverse
- Int.GroupLaws.group.intercalateCombineAllOption
- Int.GroupLaws.group.intercalateIntercalates
- Int.GroupLaws.group.intercalateRepeat1
- Int.GroupLaws.group.intercalateRepeat2
- Int.GroupLaws.group.is id
- Int.GroupLaws.group.left identity
- Int.GroupLaws.group.left inverse
- Int.GroupLaws.group.repeat0
- Int.GroupLaws.group.repeat1
- Int.GroupLaws.group.repeat2
- Int.GroupLaws.group.reverseCombineAllOption
- Int.GroupLaws.group.reverseRepeat1
- Int.GroupLaws.group.reverseRepeat2
- Int.GroupLaws.group.reverseReverses
- Int.GroupLaws.group.right identity
- Int.GroupLaws.group.right inverse


///Example Group from cats   
Cats provides instances out of the box for various numerical types. 
(Int, Long, Float, Double)
//https://github.com/typelevel/cats/blob/main/kernel/src/main/scala/cats/kernel/Group.scala

Has few methods 

trait Group[A] extends Any with Monoid[A] 
  def inverse(a: A): A
  def remove(a: A, b: A): A 
  override def combineN(a: A, n: Int): A 
 
object Group 
    def inverse[@sp(Int, Long, Float, Double) A](a: A)(implicit ev: G[A]): A 
    def remove[@sp(Int, Long, Float, Double) A](x: A, y: A)(implicit ev: G[A]): A     
    def apply[A](implicit ev: Group[A]): Group[A] = ev
    
//from cats 
import cats._
import cats.implicits._ 


Group[Int].inverse(1)
//res0: Int = -1

Group[Int].remove(10, 1)
//res1: Int = 9

10 |-| 1
//res2: Int = 9

3 |+| 2 |-| 2
//res3: Int = 3



///Functor Definition 
F[_] is a type constructor or container type, also called Effect 
Functor is the abstraction to transform internal of Effect to another type 
without understanding of the effect (eg squaring each element of List of number)

//def 
import scala.language.higherKinds
trait Functor[F[_]] {
  def map[A,B](in: F[A])(f: A => B): F[B]
}

We could also define the map slightly differently, in a curried form, mapC

trait Functor[F[_]] {
  def map[A,B](in: F[A])(f: A => B): F[B]
  def mapC[A,B](f: A => B): F[A] => F[B] = fa => map(fa)(f)
}

///Functor Laws
Functors guarantee the same semantics whether we sequence many small operations 
one by one, or combine/compose them into a larger ops before mapping. 

To ensure this is the case the following laws must hold:
    Identity
    calling map with the identity function is the same as doing nothing:
      fa.map(a => a) == fa

    Composition/associativity
    mapping with two functions f and g is the same as mapping with f 
    and then mapping with g:
      fa.map(g(f(_))) == fa.map(f).map(g)


//Example implementation for List and Option 
implicit val functorForOption: Functor[Option] = new Functor[Option] {
  def map[A, B](fa: Option[A])(f: A => B): Option[B] = fa match {
    case None    => None
    case Some(a) => Some(f(a))
  }
}
implicit val listFunctor: Functor[List] = new Functor[List] {
    override def map[A, B](in: List[A])(f: A => B): List[B] = in.map(f)
    override def mapC[A, B](f: A => B): List[A] => List[B] = (_: List[A]).map(f)
}




///Testing Scalacheck Props -- ADVANCED 

import org.scalacheck._
import org.scalacheck.Prop._

def identity[A](x: A): A = x

def id[A, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]]): Prop =
    forAll { as: F[A] => F.map(as)(identity) == as }

//(CoGen is required for argument of Function )
def associativity[A, B, C, F[_]](implicit F: Functor[F],
                                  arbFA: Arbitrary[F[A]],
                                  arbB: Arbitrary[B],
                                  arbC: Arbitrary[C],
                                  cogenA: Cogen[A], //for f:A =>B
                                  cogenB: Cogen[B]): Prop = { //for g:B => C
  forAll((as: F[A], f: A => B, g: B => C) => {
     F.map(F.map(as)(f))(g) == F.map(as)(f andThen g)
  })
}

def functor[A, B, C, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],
                         cogenB: Cogen[B]): Prop =
    id[A, F] && associativity[A, B, C, F]

import cats._ 
import cats.implicits._ 

//Check option as functor 
functor[Int, String, Long, Option].check()

///Props check with  cats-law 
import cats.laws.discipline.FunctorTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
  checkAll("List.FunctorLaws", FunctorTests[List].functor[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests())
TreeLawTests:
- Tree.FunctorLaws.functor.covariant composition
- Tree.FunctorLaws.functor.covariant identity
- Tree.FunctorLaws.functor.invariant composition
- Tree.FunctorLaws.functor.invariant identity



///Functor - Usage from cats 
In Cats, Functors mapC is called lift 

trait Functor[F[_]] {
  def map[A, B](fa: F[A])(f: A => B): F[B]

  def lift[A, B](f: A => B): F[A] => F[B] =
    fa => map(fa)(f)
}
Many types have Functor implementions 
check in https://github.com/typelevel/cats/tree/main/core/src/main/scala/cats/instances


//Example 
import cats._ 
import cats.implicits._ 

//check 
implicitly[Functor[List]]

//function compose using Functor 
val func1 = (a: Int) => a + 1
val func2 = (a: Int) => a * 2
val func3 = (a: Int) => s"${a}!"
val func4 = func1.map(func2).map(func3) //nothing but compose 

func4(123)
// res3: String = "248!"

def doMath[F[_]](start: F[Int])(implicit functor: Functor[F]): F[Int] =
 start.map(n => n + 1 * 2)

doMath(Option(20))
// res4: Option[Int] = Some(22)
doMath(List(1, 2, 3))
// res5: List[Int] = List(3, 4, 5)

///Functor Advantage - We can Compose 
If you have Option[List[A]] or List[Either[String, Future[A]]] 
and tried to map over it, we do  _.map(_.map(_.map(f))). 

As it turns out, Functors compose, ie if F and G have Functor instances, 
then so does F[G[_]] ie Functor[F].compose[G].map(fga)(f) , where f: A => B 
of F[G[A]]

//example implementation 
trait Functor[F[_]] {
    def map[A,B](fa: F[A])(f: A => B): F[B]

    def compose[G[_]: Functor]: Functor[({type f[x]=F[G[x]]})#f] =  {   
        val F = this
        val G = implicitly[Functor[G]]
        new Functor[({type f[x]=F[G[x]]})#f] {
            override def map[A, B](fga: F[G[A]])(f: A => B): F[G[B]] =
                F.map(fga)(ga => G.map(ga)(f))
        }
    }
}

//example 
val optL = Option(List(1,2,3))

optL.map(_.map(_+2))
//OR
Functor[Option].compose[List].map(optL)(_ + 2)
//Some(List(3, 4, 5))
 
val listOption = List(Some(1), None, Some(2))
Functor[List].compose[Option].map(listOption)(_ + 1)

//OR with Nested[F[_], G[_], A](value: F[G[A]]) 
import cats.data.Nested

//Nested can help by composing the two map operations into one
val nested: Nested[List, Option, Int] = Nested(listOption)
nested.map(_ + 1) // Nested(List(Some(2), None, Some(3)))
nested.map(_ + 1).value

Nested is extremly valuable if we need to pass composed Functor to function 

def needsFunctor[F[_]: Functor, A](fa: F[A]): F[Unit] = Functor[F].map(fa)(_ => ())

def foo: List[Option[Unit]] = {
  val listOptionFunctor = Functor[List].compose[Option]
  type ListOption[A] = List[Option[A]]
  needsFunctor[ListOption, Int](listOption)(listOptionFunctor) 
  //listOptionFunctor is implicit Functor value 
}
//OR 
needsFunctor[({ type T[A] = Nested[List, Option, A] })#T, Int](nested)



///Custom Type for Functor --ADVANCED
import cats._ 

sealed trait Tree[+A]

case class Node[A](p: A, left: Tree[A], right: Tree[A]) extends Tree[A]
final case class Leaf[A](value: A) extends Tree[A]
 
object Tree {
    def node[A](p:A, left: Tree[A], right: Tree[A]): Tree[A] =
     Node(p, left, right)
    def leaf[A](value: A): Tree[A] =
     Leaf(value)
     
    implicit val treeFunctor: Functor[Tree] =
      new Functor[Tree] {
          def map[A, B](tree: Tree[A])(func: A => B): Tree[B] =
           tree match {
                case Node(p, left, right) =>
                 node(func(p), map(left)(func), map(right)(func))
                case Leaf(value) =>
                 leaf(func(value))
            }
      }
}

import cats.implicits._
Node(10, Leaf(10), Leaf(20)).map(_ * 2)
// error: value map is not a member of repl.Session.App0.Branch[Int]

Because of Covariant, as Covariant implicit resolution is with specific subtype 
or use smart constructor as we have implicit for base class 

//Use smart-constructor 
Tree.leaf(100).map(_ * 2)
// res9: Tree[Int] = Leaf(200)


Tree.node(10, Tree.leaf(10), Tree.leaf(20)).map(_ * 2)
// res10: Tree[Int] = Branch(Leaf(20), Leaf(40))


///Functor - Custom type testing using cats-law  --ADVANCED
import cats.laws.discipline.FunctorTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[Tree[A]] =
    Arbitrary(Gen.oneOf(    
    (for {
      l <- Arbitrary.arbitrary[A]
    } yield Leaf(l)), 
    (for {
      e <- Arbitrary.arbitrary[A]
      l1 <- Arbitrary.arbitrary[A]
      l2 <- Arbitrary.arbitrary[A]
    } yield Node(e, Leaf(l1), Leaf(l2)))
    )
  )
}

class TreeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._ 
 implicit def eqTree[A: Eq]: Eq[Tree[A]] = Eq.fromUniversalEquals
  
  checkAll("Tree.FunctorLaws", FunctorTests[Tree].functor[Int, Int, String])
}

scala> org.scalatest.run(new TreeLawTests())
TreeLawTests:
- Tree.FunctorLaws.functor.covariant composition
- Tree.FunctorLaws.functor.covariant identity
- Tree.FunctorLaws.functor.invariant composition
- Tree.FunctorLaws.functor.invariant identity

Where 
//https://github.com/typelevel/cats/tree/main/laws/src/main/scala/cats/laws/discipline

FunctorTests[F[_]].functor[A: Arbitrary, B: Arbitrary, C: Arbitrary](implicit
    ArbFA: Arbitrary[F[A]],
    CogenA: Cogen[A],
    CogenB: Cogen[B],
    CogenC: Cogen[C],
    EqFA: Eq[F[A]],
    EqFC: Eq[F[C]]
  ): RuleSet 



///Applicative
With functor, we now have a convenient way to apply functions 
to the contents of an effect, ie F[_],regardless of the type of the effect itself.

Applicative extends the original functor with two more methods:
(Applicative is more powerful because Functor can be implemented by that)

    The unit/pure method allows us to wrap a plain value, a, into the effect ie F[A] 
    This is often called lifting, as it "lifts" the original value 
    into the context of the effect, F.

    The apply method takes an effect, a, and a function, f, defined 
    in the context of the same effect F and applies f to a, 
    thus returning the result that wrapped in the very same effect, F

//definition 
trait Applicative[F[_]] extends Functor[F] {
  def apply[A, B](ff: F[A => B])(fa: F[A]): F[B] //ie in cats called ap[A,B]
  def pure[A](a: A): F[A]  //ie unit[A] 
  //from Functor but overridden 
  override def map[A,B](f: A => B)(fa: F[A]): F[B] =  
    apply(pure(f))(fa)
}


There are a few laws:
    1. Identity law states that an application of an identity function 
       should return the  argument unchanged, 
       the same way the identity function does. This is similar to
       the identity law for the functor, but this time defined for 
       the apply function.
       
    2. Homomorphism law states that applying a function to a value 
       and then lifting the result is the same as first lifting this function 
       and value and then applying them in the context of the applicative.
       
    3. Interchange law states that changing the order of the parameters 
       for the apply method should not change the result.
       
    4. Composition law states that function composition should be preserved.
    
//Example implementation for List and OPtion 
//for list, all functions are applied on all inputs 
//so 3 inputs, 3 functions would make 9 outputs 
implicit val listApplicative: Applicative[List] = new Applicative[List] {

  override def apply[A, B](a: List[A])(f: List[A => B]): List[B] = (a, f) match {
    case (Nil, _) => Nil
    case (_, Nil) => Nil
    case (aa :: as, ff :: fs) =>
      val fab: (A => B) => B = fn => fn(aa)
      ff(aa) :: as.map(ff) ::: fs.map(fab) ::: apply(as)(fs)
    case other => Nil
  }

  override def unit[A](a: => A): List[A] = List(a)
}

implicit val optionApplicative: Applicative[Option] = new Applicative[Option] {
  override def apply[A, B](a: Option[A])(f: Option[A => B]): Option[B] = (a,f) match {
    case (Some(a), Some(f)) => Some(f(a))
    case _ => None
  }
  override def unit[A](a: => A): Option[A] = Some(a)
}

//Example definition of Applicative 
trait Applicative[F[_]] extends Functor[F] {
  def apply[A,B](a: F[A])(f: F[A => B]): F[B]
  def unit[A](a: => A): F[A]
  override def map[A,B](fa: F[A])(f: A => B): F[B] =  
    apply(fa)(unit(f))

  //compose[G](implicit G):Applicative[F[G[_]]]
  //Applicative[F].compose[G].apply(a: F[G[A]])(f: F[G[A => B]])
  def compose[G[_]]( implicit  G: Applicative[G]): Applicative[({type f[x] = F[G[x]]})#f] = {
    val F = this

    def fab[A, B]: G[A => B] => G[A] => G[B] = (gf: G[A => B]) => (ga: G[A]) => G.apply(ga)(gf)

    def fg[B, A](f: F[G[A => B]]): F[G[A] => G[B]] = F.map(f)(fab)

    new Applicative[({type f[x] = F[G[x]]})#f] {
      def unit[A](a: => A) = F.unit(G.unit(a))
      override def apply[A, B](a: F[G[A]])(f: F[G[A => B]]): F[G[B]] =
        F.apply(a)(fg(f))
    }
  }
}
    
    
///Prop Checking - Applicative --ADVANCED  
//in scalacheck and cats (exit and import below - getting Functor etc from cats )
import cats._ 
import cats.implicits._ 

import org.scalacheck.Prop._
import org.scalacheck._

//Functors 
def identity[A](x: A): A = x

def id[A, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]]): Prop =
    forAll { as: F[A] => F.map(as)(identity) == as }

//(CoGen is required for argument of Function )
def associativity[A, B, C, F[_]](implicit F: Functor[F],
                                  arbFA: Arbitrary[F[A]],
                                  arbB: Arbitrary[B],
                                  arbC: Arbitrary[C],
                                  cogenA: Cogen[A],
                                  cogenB: Cogen[B]): Prop = {
  forAll((as: F[A], f: A => B, g: B => C) => {
     F.map(F.map(as)(f))(g) == F.map(as)(f andThen g)
  })
}

def functor[A, B, C, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]],
                         arbB: Arbitrary[B],
                         arbC: Arbitrary[C],
                         cogenA: Cogen[A],
                         cogenB: Cogen[B]): Prop =
    id[A, F] && associativity[A, B, C, F]
    
//Applicatves 
def identityProp[A, F[_]](implicit A: Applicative[F],
                          arbFA: Arbitrary[F[A]]): Prop =
  forAll { as: F[A] =>
    A.ap(A.pure((a: A) => a))(as) == as
  }

def homomorphism[A, B, F[_]](implicit A: Applicative[F],
                             arbA: Arbitrary[A],
                             arbB: Arbitrary[B],
                             cogenA: Cogen[A]): Prop = {
  forAll((f: A => B, a: A) => {
    A.ap(A.pure(f))(A.pure(a)) == A.pure(f(a))
  })
}

def interchange[A, B, F[_]](implicit A: Applicative[F],
                            arbFA: Arbitrary[F[A]],
                            arbA: Arbitrary[A],
                            arbB: Arbitrary[B],
                            cogenA: Cogen[A]): Prop = {
  forAll((f: A => B, a: A) => {
    val leftSide = A.ap(A.pure(f))(A.pure(a))
    val func = (ff: A => B) => ff(a)
    val rightSide = A.ap(A.pure(func))(A.pure(f))
    leftSide == rightSide
  })
}

def composeF[A, B, C]: (B => C) => (A => B) => (A => C) = _.compose

def composition[A, B, C, F[_]](implicit A: Applicative[F],
                               arbFA: Arbitrary[F[A]],
                               arbB: Arbitrary[B],
                               arbC: Arbitrary[C],
                               cogenA: Cogen[A],
                               cogenB: Cogen[B]): Prop = {
  forAll((as: F[A], f: A => B, g: B => C) => {
    val af: F[A => B] = A.pure(f)
    val ag: F[B => C] = A.pure(g)
    val ac: F[(B => C) => (A => B) => (A => C)] = A.pure(composeF)
    val leftSide = A.ap(A.ap(A.ap(ac)(ag))(af))(as)
    val rightSide = A.ap(ag)(A.ap(af)(as))

    leftSide == rightSide
  })
}

def applicative[A, B, C, F[_]](implicit fu: Applicative[F],
                               arbFA: Arbitrary[F[A]],
                               arbA: Arbitrary[A],
                               arbB: Arbitrary[B],
                               arbC: Arbitrary[C],
                               cogenA: Cogen[A],
                               cogenB: Cogen[B]): Prop = {
  identityProp[A, F] && homomorphism[A, B, F] &&
    interchange[A, B, F] && composition[A, B, C, F] &&
    functor[A, B, C, F] //old testing 
}
//Testing 
//Applicative[Option] 
applicative[Int, String, Long, Option].check()

//Applicative[Option] and String => Int, Int => Boolean
applicative[String, Int, Boolean, Option].check 

//Applicative[Try] and Int => String, String => Long
applicative[Int, String, Long, Try].check 
//Applicative[Try] and String => Int, Int => Boolean
applicative[String, Int, Boolean, Try].check 

type UnitEither[R] = Either[Unit, R]
//Applicative[Either] and Int => String, String => Long
applicative[Int, String, Long, UnitEither].check 
//Applicative[Either] and String => Int, Int => Boolean
applicative[String, Int, Boolean, UnitEither].check 
//Applicative[List] and Int => String, String => Long
applicative[Int, String, Long, List].check 
//Applicative[List] and String => Int, Int => Boolean
applicative[String, Int, Boolean, List].check 


///Applicative - Props check with  cats-law -- ADVANCED 
https://github.com/typelevel/cats/tree/main/laws/src/main/scala/cats/laws
https://github.com/typelevel/cats/blob/main/laws/src/main/scala/cats/laws/discipline/AlternativeTests.scala

import cats.laws.discipline.ApplicativeTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 // ApplicativeTests[F[_].applicative[A: Arbitrary, B: Arbitrary, C: Arbitrary]
  checkAll("List.ApplicativeLaws", ApplicativeTests[List].applicative[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
- List.ApplicativeLaws.applicative.ap consistent with product + map
- List.ApplicativeLaws.applicative.applicative homomorphism
- List.ApplicativeLaws.applicative.applicative identity
- List.ApplicativeLaws.applicative.applicative interchange
- List.ApplicativeLaws.applicative.applicative map
- List.ApplicativeLaws.applicative.applicative unit
- List.ApplicativeLaws.applicative.apply composition
- List.ApplicativeLaws.applicative.covariant composition
- List.ApplicativeLaws.applicative.covariant identity
- List.ApplicativeLaws.applicative.invariant composition
- List.ApplicativeLaws.applicative.invariant identity
- List.ApplicativeLaws.applicative.map2/map2Eval consistency
- List.ApplicativeLaws.applicative.map2/product-map consistency
- List.ApplicativeLaws.applicative.monoidal left identity
- List.ApplicativeLaws.applicative.monoidal right identity
- List.ApplicativeLaws.applicative.productL consistent map2
- List.ApplicativeLaws.applicative.productR consistent map2
- List.ApplicativeLaws.applicative.semigroupal associativity



///Example from  cats (apply called as ap)
Cats Applicative have few goodies 

Applicative[F[_]]
    def compose[G[_]: Applicative]: Applicative[F[G[X]]]
    def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] 
    //map2 can be seen as a binary version of map
    def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z]
    def ap[A, B](ff: F[A => B])(fa: F[A]): F[B]
    def product[A, B](fa: F[A], fb: F[B]): F[(A, B)] 
    def map[A, B](fa: F[A])(f: A => B): F[B]

//Example 
import cats._
import cats.implicits._

def applyFunc[A, B, F[_]](as: F[A])(f: F[A => B])(implicit app: Applicative[F]): F[B] = 
    app.ap(f)(as)

//for list, all functions are applied on all inputs 
//so 3 inputs, 3 functions would make 9 outputs 
applyFunc(List(1,2,3))(List( (_:Int) * 2, (_:Int) * 3, (e:Int) => e*e ))
//List(2, 4, 6, 3, 6, 9, 1, 4, 9) 

///Advantages - Applicatives compose
import cats.data.Nested
import cats.implicits._
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

val x: Future[Option[Int]] = Future.successful(Some(5))
val y: Future[Option[Char]] = Future.successful(Some('a'))

//def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z]
val composed = Applicative[Future].compose[Option].map2(x, y)(_ + _)
// composed: Future[Option[Int]] = Future(Success(Some(102)))

//with kind projector 
val nested = Applicative[Nested[Future, Option, *]].map2(Nested(x), Nested(y))(_ + _)
// nested: Nested[Future, Option, Int] = Nested(Future(Success(Some(102))))
//OR 
val nested = Applicative[({type n[x]=Nested[Future, Option, x]})#n].map2(Nested(x), Nested(y))(_ + _)




///Any Implementation can not be Applicative  - it must obey Applicative law -- ADVANCED 

import cats._ 
import cats.implicits._ 

Note, List applicatives creates N1 * N2 result 

val xs: List[Int] = List(1, 2, 3)
val fs: List[Int => Int] = List(_ + 2, _ + 2, _ +1)
val ys: List[Int] = Applicative[List].ap(fs)(xs) 
//List(3, 4, 5, 3, 4, 5, 2, 3, 4)
//ap is also called  <*>[A, B](ff: F[A => B])(fa: F[A]): F[B]
fs <*> xs

Requirement is to Implement such that 
output expected to be List(f1(1), f2(2), f3(3)) = List(3,4,4)

Define 
case class ZipList[A](val list: List[A])

implicit val zipListApplicative = new Applicative[ZipList] {

  def pure[A](a: A): ZipList[A] = ZipList(List(a))

  def ap[A, B](zf : ZipList[A => B])(za: ZipList[A]): ZipList[B] = {
    val bs = (za.list zip zf.list) map {case (a, f) => f(a)}
    ZipList(bs)
  }
  //Defined as below in Applicative 
  //def map[A,B](f: A => B)(fa: F[A]): F[B] =   ap(pure(f))(fa)
  
}


//Usage 
val xs: List[Int] = List(1, 2, 3)
val fs: List[Int => Int] = List(_ + 2, _ + 2, _ +1)

def <*>[F[_]:Applicative, A, B](ff: F[A => B])(fa: F[A]): F[B] = 
    Applicative[F].ap(ff)(fa)
    
ZipList(fs) <*> ZipList(xs)
//ZipList[Int] = ZipList(List(3, 4, 4))

But is ZipList a Applicative or Functor?

//Test Data 
import org.scalacheck.Prop._
import org.scalacheck._

implicit def arbZipList[T](implicit ev: Arbitrary[T]): Arbitrary[ZipList[T]] =Arbitrary {
  for {
    lst <-  Gen.listOf[T](ev.arbitrary)  //Arbitrary[T].arbitrary : Gen[T]
    } yield ZipList(lst)
}
//Check 
arbZipList[Int].arbitrary.sample 

//Check  for Applicative 
def identity[A](x: A): A = x

def id[A, F[_]](implicit F: Functor[F], arbFA: Arbitrary[F[A]]): Prop =
    forAll { as: F[A] => F.map(as)(identity) == as }

id[Int,ZipList].check //Failed when zipListApplicative is in scope 
//! Falsified after 2 passed tests.
//> ARG_0: ZipList(List(-1483655021, 499003824))


Is it Functor ,  restart scala prompt 
//Check for Functor - remove all instances of Applicative 
//else implicits comes from applicatives, so restart scala prompt 
implicit val zipListFunctor = new Functor[ZipList] {
  def map[A, B](fa: ZipList[A])(f: A => B): ZipList[B] = ZipList(fa.list.map(f))
}

id[Int,ZipList].check //OK when zipListFunctor is in scope 


//Reasons 
Because 
ZipList(List(-1483655021, 499003824)).map(identity) = ZipList(List(-1483655021))

gives first value only because identity is applied in firstvalue 
and secondValue is ignored, breaking identity laws 
because of below implementation
map[A,B](f: A => B)(fa: F[A]): F[B] =   ap(pure(f))(fa)

and ap is implemented  as a zip of function and ZipList 
and in zip , shortest length wins 

//With cats-law 
import cats.laws.discipline.ApplicativeTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[ZipList[A]] = Eq.fromUniversalEquals //because case class
 checkAll("ZipList.ApplicativeLaws", ApplicativeTests[ZipList].applicative[Int, Int, String])
}
org.scalatest.run(new SomeLawTests()) //Failed 






    
///Traverse 
Applicatives has following 

def ap2[A, B, Z](ff: F[(A, B) => Z])(fa: F[A], fb: F[B]): F[Z] 
def map2[A, B, Z](fa: F[A], fb: F[B])(f: (A, B) => Z): F[Z] 

till ap22 and map22 OR extension methods mapN/apN

//Usage example - create a java.sql.Connection from Optional parts 

import java.sql.Connection
import cats._
import cats.implicits._

val username: Option[String] = Some("username")
val password: Option[String] = Some("password")
val url: Option[String] = Some("some.login.url.here")

// And we have function which connects to URL 
def attemptConnect(username: String, password: String,   url: String): Option[Connection] = 
    None  //mock function 

//we have 3 Options, so we can use map3 specifically.
Applicative[Option].map3(username, password, url)(attemptConnect)
// res2: Option[Option[Connection]] = Some(None)

//OR using cats.syntax 
import cats.implicits._

//from project\Boilerplate.scala in github 
//Functor[F].mapN[Z](f: (A,...,N) => Z): F[Z]
(username, password, url).mapN(attemptConnect)
// res7: Option[Option[Connection]] = Some(None)

Sometimes we don’t know how many effects will be in play , So we require 

trait Traverse[F[_]] extends Functor[F]{   
  //main two methods 
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]
  def sequence[G[_]: Applicative, A](fga: F[G[A]]): G[F[A]] 
}
  
//Example 
import cats.implicits._

List(1, 2, 3).traverse(i => Some(i): Option[Int])  //Option is Applicative 
List(Option(1), Option(2), Option(3)).sequence 
List(1, 2, 3).map(Option(_)).sequence 
//  Option[List[Int]] = Some(List(1, 2, 3))


//OR 
List(username, password, url).sequence 
//Option[List[String]]
List(username, password, url).sequence.collect{ case List(un, p, url) => attemptConnect(un,p,url)}
//Option[Option[Connection]] = Some(None)


//Example implementation for List[A]
Note the example implementation could be for List[A]

def traverse[F[_]: Applicative, A, B](as: List[A])(f: A => F[B]): F[List[B]] =
  as.foldRight(Applicative[F].pure(List.empty[B])) { (a: A, acc: F[List[B]]) =>
    val fb: F[B] = f(a)
    Applicative[F].map2(fb, acc)(_ :: _)
  }
def sequence[G[_]: Applicative, A](fga: F[G[A]]): G[F[A]] =
    traverse(fga)(ga => ga)

///Traverse: Props check with  cats-law -- ADVANCED 
https://github.com/typelevel/cats/tree/main/laws/src/main/scala/cats/laws
https://github.com/typelevel/cats/blob/main/laws/src/main/scala/cats/laws/discipline/AlternativeTests.scala

import cats.laws.discipline.TraverseTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._

//Not required for List as by default Arbitrary present, but to show 
//for custom type how to generate 
object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[List[A]] =
    Arbitrary(
    Gen.listOf[A]( Arbitrary.arbitrary[A])
  )
}

//CommutativeApplicative
//Further than an Applicative, which just allows composition of independent 
//effectful functions,
//in a Commutative Applicative those functions can be composed in any order, 
//which guarantees that their effects do not interfere.

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 // ApplicativeTests[F[_].traverse[A: Arbitrary, B: Arbitrary, C: Arbitrary, M: Arbitrary, X[_]: CommutativeApplicative, Y[_]: CommutativeApplicative]
  checkAll("List.TraversalLaws", TraverseTests[List].traverse[Int, Int, Int, Int, Option, Option])
}

scala> org.scalatest.run(new SomeLawTests())
SomeLawTests:
SomeLawTests:
- List.TraversalLaws.traverse.collectFirst reference
- List.TraversalLaws.traverse.collectFirstSome reference
- List.TraversalLaws.traverse.covariant composition
- List.TraversalLaws.traverse.covariant identity
- List.TraversalLaws.traverse.dropWhile_ reference
- List.TraversalLaws.traverse.exists consistent with find
- List.TraversalLaws.traverse.exists is lazy
- List.TraversalLaws.traverse.filter_ reference
- List.TraversalLaws.traverse.fold reference
- List.TraversalLaws.traverse.foldLeft consistent with foldMap
- List.TraversalLaws.traverse.foldM identity
- List.TraversalLaws.traverse.foldRight consistent with foldMap
- List.TraversalLaws.traverse.foldRight is lazy
- List.TraversalLaws.traverse.foldRightDefer consistency
- List.TraversalLaws.traverse.forall consistent with exists
- List.TraversalLaws.traverse.forall is lazy
- List.TraversalLaws.traverse.forall true if empty
- List.TraversalLaws.traverse.get reference
- List.TraversalLaws.traverse.invariant composition
- List.TraversalLaws.traverse.invariant identity
- List.TraversalLaws.traverse.nonEmpty reference
- List.TraversalLaws.traverse.ordered consistency
- List.TraversalLaws.traverse.reduceLeftOption consistent with reduceLeftToOption
- List.TraversalLaws.traverse.reduceRightOption consistent with reduceRightToOption
- List.TraversalLaws.traverse.takeWhile_ reference
- List.TraversalLaws.traverse.toList reference
- List.TraversalLaws.traverse.traverse derive foldMap
- List.TraversalLaws.traverse.traverse identity
- List.TraversalLaws.traverse.traverse order consistency
- List.TraversalLaws.traverse.traverse parallel composition
- List.TraversalLaws.traverse.traverse ref mapWithIndex
- List.TraversalLaws.traverse.traverse ref traverseWithIndexM
- List.TraversalLaws.traverse.traverse ref zipWithIndex
- List.TraversalLaws.traverse.traverse sequential composition
- List.TraversalLaws.traverse.traverse traverseTap
- List.TraversalLaws.traverse.unordered traverse consistent with sequence
- List.TraversalLaws.traverse.unordered traverse parallel composition
- List.TraversalLaws.traverse.unordered traverse sequential composition
- List.TraversalLaws.traverse.unorderedFold consistent with unorderedFoldMap



///Traversable - Example from cats 

//Example implementation from cats 
import scala.{ Traversable => _ }

trait Traverse[F[_]] extends Functor[F]{ 
  
  //main two methods 
  def traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]
  def sequence[G[_]: Applicative, A](fga: F[G[A]]): G[F[A]] =
    traverse(fga)(ga => ga)
    
  //compose 
  implicit def compose[H[_]](implicit H: Traversable[H]): Traversable[({type f[x] = F[H[x]]})#f] = {
    val F = this
    new Traversable[({type f[x] = F[H[x]]})#f] {
      override def traverse[G[_]: Applicative, A, B](fa: F[H[A]])(f: A => G[B]) =
        F.traverse(fa)((ga: H[A]) => H.traverse(ga)(f))

      override def map[A, B](in: F[H[A]])(f: A => B): F[H[B]] =
        F.map(in)((ga: H[A]) => H.map(ga)(f))
    }
  }
    
  //other concrete methods from Cats 
  //F.flatten should exists which comes from FlatMap[F]
  def flatTraverse[G[_], A, B](fa: F[A])(f: A => G[F[B]])(implicit G: Applicative[G], F: FlatMap[F]): G[F[B]] =
    G.map(traverse(fa)(f))(F.flatten)

  def flatSequence[G[_], A](fgfa: F[G[F[A]]])(implicit G: Applicative[G], F: FlatMap[F]): G[F[A]] =
    G.map(sequence(fgfa))(F.flatten)

  def mapWithIndex[A, B](fa: F[A])(f: (A, Int) => B): F[B] = ...
  def traverseWithIndexM[G[_], A, B](fa: F[A])(f: (A, Int) => G[B])(implicit G: Monad[G]): G[F[B]] =
  def zipWithIndex[A](fa: F[A]): F[(A, Int)] =
    mapWithIndex(fa)((a, i) => (a, i))

}

//Exmaple 
import cats._ 
 
import cats.implicits._
import scala.util._ 
import cats.syntax._ 


//catchOnly from cats 
def parseInt(s: String): Option[Int] = 
    Either.catchOnly[NumberFormatException](s.toInt).toOption
    
List("1", "2", "3").traverse(parseInt)
//Option[List[Int]] = Some(List(1, 2, 3))
List("1", "two", "3").traverse(parseInt)
//Option[List[Int]] = None

//understand the difference with map 
List("1", "2", "3").map(parseInt)
//List[Option[Int]] = List(Some(1), Some(2), Some(3))
List("1", "two", "3").map(parseInt)
// List[Option[Int]] = List(Some(1), None, Some(3))


//A traverse followed by flattening the inner result.
import cats.implicits._
def parseInt(s: String): Option[Int] = 
    Either.catchOnly[NumberFormatException](s.toInt).toOption

val x = Option(List("1", "two", "3"))
x.flatTraverse(_.map(parseInt))
//List[Option[Int]] = List(Some(1), None, Some(3))


//Thread all the G effects through the F structure 
//to invert the structure from F[G[A]] to G[F[A]].

//One element None, means result None 
val list = List(Some(1), Some(2), None)
// list: List[Option[Int]] = List(Some(1), Some(2), None)
val traversed = list.traverse(identity)
// traversed: Option[List[Int]] = None
//Or 
val sequenced = list.sequence
// sequenced: Option[List[Int]] = None

//Thread all the G effects through the F structure 
//and flatten to invert the  structure from F[G[F[A]]] to G[F[A]].

val x: List[Option[List[Int]]] = List(Some(List(1, 2)), Some(List(3)))
val y: List[Option[List[Int]]] = List(None, Some(List(3)))
x.flatSequence
//Option[List[Int]] = Some(List(1, 2, 3))
y.flatSequence
//Option[List[Int]] = None

//Compose 
implicitly[Traverse[List]]
implicitly[Traverse[Option]]
implicitly[Traverse[Try]]
implicitly[Traverse[({type L[A]=Either[Unit,A]})#L]]

implicitly[Applicative[List]]
implicitly[Applicative[Option]]
implicitly[Applicative[Try]]
implicitly[Applicative[({type L[A]=Either[Unit,A]})#L]]

//Traverse[F[_]].traverse[G[_]: Applicative, A, B](fa: F[A])(f: A => G[B]): G[F[B]]
List(1, 2, 3).traverse(x => Option(x))
//Option[List[Int]] = Some(List(1, 2, 3))

Try(1).traverse(x => Option(x))
//Option[Try[Int]] = Some(Success(1))

//Traverse[F[_]].compose[H[_]:Traversable]: Traversable[F[H[_]]
implicit val opL = Traverse[Option].compose(Traverse[List])
//Traverse[Option[List[?]]]

Option(List(1,2,3)).traverse( (x:List[Int])  => Try(x) ) 
//Try[Option[List[Int]]] = Success(Some(List(1, 2, 3)))

Option(List(1,2,3)).traverse( (x:List[Int])  => Try(x.head) ) 
//Try[Option[Int]] = Success(Some(1))


//Traverse[F[_]].compose[H[_]:Traversable]: Traversable[F[H[_]]
implicit val LL = Traverse[List].compose(Traverse[List])
//Traverse[List[List[?]]]

List(List(1,2,3), List(2,3,4)).traverse( (x:List[Int])  => Try(x.size) ) 
//Try[List[Int]] = Success(List(3, 3))


///TraverseFilter = Filter and Traverse -- ADVANCED 
TraverseFilter represents list-like structures
that can essentially have a `traverse` and a `filter` applied as a single
combined operation as traverseFilter, 
We have instances for all Traversable types eg Option, List,...

trait TraverseFilter[F[_]]
    def traverseFilter[G[_]:Applicative, A, B](fa: F[A])(f: A => G[Option[B]]): G[F[B]]
    def sequenceFilter[G[_], A](fgoa: F[G[Option[A]]])(implicit G: Applicative[G]): G[F[A]]
    def filterA[G[_], A](fa: F[A])(f: A => G[Boolean])(implicit G: Applicative[G]): G[F[A]]
    def mapFilter[A, B](fa: F[A])(f: A => Option[B]): F[B] 
    //both Removes duplicate elements from a list, keeping only the first occurrence.
    def hashDistinct[A](fa: F[A])(implicit H: Hash[A]): F[A]
    def ordDistinct[A](fa: F[A])(implicit O: Order[A]): F[A]

//Example 
import cats._ 
import cats.implicits._

//TraverseFilter[F[_]].traverseFilter[G[_]:Applicative, A, B](fa: F[A])(f: A => G[Option[B]]): G[F[B]]
val m: Map[Int, String] = Map(1 -> "one", 3 -> "three")
val l: List[Int] = List(1, 2, 3, 4)
def asString(i: Int): Eval[Option[String]] = Now(m.get(i))
val result: Eval[List[String]] = l.traverseFilter(asString)
result.value
//List[String] = List(one, three)

//TraverseFilter[F[_]].sequenceFilter[G[_]:Applicative, A](fgoa: F[G[Option[A]]])(implicit G: Applicative[G]): G[F[A]] 
val a: List[Either[String, Option[Int]]] = List(Right(Some(1)), Right(Some(5)), Right(Some(3)))
val b: Either[String, List[Int]] = TraverseFilter[List].sequenceFilter(a)
//Either[String, List[Int]] = Right(List(1, 5, 3))


//Filter values inside a `G` context.
//TraverseFilter[F[_]].filterA[G[_]:Applicative, A](fa: F[A])(f: A => G[Boolean]): G[F[A]
val l: List[Int] = List(1, 2, 3, 4)
def odd(i: Int): Eval[Boolean] = Now(i % 2 == 1)
val res: Eval[List[Int]] = l.filterA(odd)
res.value
// List[Int] = List(1, 3)

List(1, 2, 3).filterA(_ => List(true, false))
//List[List[Int]] = List(List(1, 2, 3), List(1, 2), List(1, 3), List(1), List(2, 3), List(2), List(3), List())




///Some examples of Functor but not Applicative etc -- ADVANCED 

//Functor but not Applicative 
ZipList[A] is functor but not applicative 

//Functor but not Applicative 
tagged value ("tag", v) where  "tag" is some arbitrary

This is a functor - given a function f and a tagged value ("tag1", v), 
you can map over it to get the result ("tag1", f(v)). 

But it is not an applicative:
    1) there is no "default" tag, so it can not be Pured
    2) given ("function_tag", fn)  ie fn in applicative context 
       and value ("tag1", v), ap/apply should create ("??", fn(v)
       and what could be tag ?? from  two existing tags, "tag1" and "function_tag"

//Example 
import cats._ 
import cats.implicits._ 

case class TaggedValue[A](val value: (String, A) ){
    val tag = value._1
    val v = value._2
}


implicit val taggedValueFunctor = new Functor[TaggedValue] {
  def map[A, B](fa: TaggedValue[A])(f: A => B): TaggedValue[B] = 
    TaggedValue( (fa.tag, f(fa.v) ) )
}
//Prop check 
import cats.laws.discipline.FunctorTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._


object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[TaggedValue[A]] = Arbitrary{
    for {
        tag <- Arbitrary.arbString.arbitrary
        v <- Arbitrary.arbitrary[A]
        }  yield TaggedValue((tag, v))
  }
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[TaggedValue[A]] = Eq.fromUniversalEquals //because case class
 checkAll("TaggedValue.FunctorLaws", FunctorTests[TaggedValue].functor[Int, Int, String])
}

scala> org.scalatest.run(new SomeLawTests()) //OK 


//Exception of tagged Value 
The Writer monad is almost identical to the tagged value - (W, A)
But in Writer, W is required to be a monoid. 
This gives us a default value, pure  a way to combine logging values, 
so ("log1", f) and ("log2", v) can be combined into ("log1log2", f(v)). 
So Writer is Applicative, and in fact a full Monad.

case class TaggedValueM[A](val value: (String, A) ){
    val tag = value._1
    val v = value._2
}

implicit val taggedValueMApplicative = new Applicative[TaggedValueM] {

  def pure[A](a: A): TaggedValueM[A] = TaggedValueM( (Monoid[String].empty,  a) )

  def ap[A, B](zf : TaggedValueM[A => B])(za: TaggedValueM[A]): TaggedValueM[B] = {
    val tag = Monoid[String].combine(za.tag, zf.tag)
    val v = zf.v(za.v)
    TaggedValueM( (tag, v) )
  }
  //Defined as below in Applicative 
  //def map[A,B](f: A => B)(fa: F[A]): F[B] =   ap(pure(f))(fa)
  
}
//prop check 
import cats.laws.discipline.ApplicativeTests
import org.scalatest.funsuite.AnyFunSuite
import org.scalatestplus.scalacheck.Checkers
import org.typelevel.discipline.scalatest.FunSuiteDiscipline

import org.scalacheck._


object arbitraries {
  implicit def arbTree[A: Arbitrary]: Arbitrary[TaggedValueM[A]] = Arbitrary{
    for {
        tag <- Arbitrary.arbString.arbitrary
        v <- Arbitrary.arbitrary[A]
        }  yield TaggedValueM((tag, v))
  }
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[TaggedValueM[A]] = Eq.fromUniversalEquals //because case class
 checkAll("TaggedValueM.ApplicativeLaws", ApplicativeTests[TaggedValueM].applicative[Int, Int, String])
}

scala > org.scalatest.run(new SomeLawTests()) //OK 

//check for Monad 
import cats.laws.discipline.MonadTests


implicit val taggedValueMMonad = new Monad[TaggedValueM] {

  def pure[A](a: A): TaggedValueM[A] = TaggedValueM( (Monoid[String].empty,  a) )

  def flatMap[A, B](fa: TaggedValueM[A])(f: A => TaggedValueM[B]): TaggedValueM[B] = {
    val mappedV = f(fa.v)
    val tag = Monoid[String].combine(fa.tag, mappedV.tag)
    TaggedValueM( (tag, mappedV.v) )
  }
  //Not Stack safe - but required
  def tailRecM[A, B](a: A)(f: A => TaggedValueM[Either[A,B]]): TaggedValueM[B] = 
   flatMap(f(a) /*TaggedValueM[Either[A,B]]*/) { /* Either[A,B] */
      case Right(b) => pure(b)
      case Left(nextA) => tailRecM(nextA)(f)
    }
  //Defined as 
  //def flatten[A](ffa: F[F[A]]): F[A] =  flatMap(ffa)(fa => fa)
  //def ap[A, B](ff: F[A => B])(fa: F[A]): F[B] =    flatMap(ff)(f => map(fa)(f))
  //def map[A, B](fa: F[A])(f: A => B): F[B] =  flatMap(fa)(a => pure(f(a)))  
}

class SomeLawTests extends AnyFunSuite with FunSuiteDiscipline with Checkers {
 import arbitraries._  
 implicit def eqTaggedValue[A: Eq]: Eq[TaggedValueM[A]] = Eq.fromUniversalEquals //because case class
 //stackUnsafeMonad because tailRecM is not implemented 
 checkAll("TaggedValueM.MonadLaws", MonadTests[TaggedValueM].stackUnsafeMonad[Int, Int, String])
}
scala > org.scalatest.run(new SomeLawTests()) //OK 


//Applicative but not Traversable
IO Effect  
An IO is an Applicative - you can join an IO and an IO into an IO that 
just performs the side-effects of both source IOs in order. 

But the essential characteristic of a Traversable is that you can build an identical 
version of one just by looking at its internal values. 
A list is a Traversable - once you pull its values out, 
you can just put them in a new list in the same order, 
and the old and new are functionally indistinguishable. 

But the same isnot true of an IO - the internal value is the result of some operation 
which has side effects, and those side-effects arenot extractable or reproducible. 
If you try and make a new IO from an existing one, all that happens is you end up 
executing the side-effects once, and then the new one is a sterile IO 
with no side-effects at all.


/// cats.Validated -- ADVANCED 
Either[Error, Value] catches only one error and then fails fully 
Is there any way to capture all errors 

//Example 
case class Name(value: String)
case class Age(value: Int)
case class Person(name: Name, age: Age)
object Person{
    def makeName(name: String): Either[String, Name] = {
        if (name == "" || name == null) 
            Left("Name is empty.") 
        else Right(Name(name))
    }

    def makeAge(age: Int): Either[String, Age] = {
        if (age < 0) 
            Left("Age is out of range.") 
        else Right(Age(age))
    }

    def makePerson(name: String, age: Int): Either[String, Person] = 
        for {
            fname <- makeName(name)
            fage <-  makeAge(age)
        } yield Person(fname, fage)
}

    
Person.makePerson("", -10)
//Either[String,Person] = Left(Name is empty.)

//Solution could be using cats.Validated
sealed abstract class Validated[+E, +A]

object Validated {
  final case class Valid[+A](a: A) extends Validated[Nothing, A]
  final case class Invalid[+E](e: E) extends Validated[E, Nothing]
}
Note validated is not Monad, so does not flatMap or for syntax 
(This is because defining a Monad instance for Validated would be inconsistent 
with its error-accumulating behaviour.)
But it is Applicative 

Few Notes 
    Use NonEmptyChain, chain with atleast one element 
        Chain is faster data structure than List 
        with all most all methods of List 
        (Uses ADT to implement O(1) append)
        https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/data/Chain.scala
    
    Use ValidatedNec[String, A] is an alias for 
        Validated[NonEmptyChain[String], A]. 
        When you use ValidatedNec you are stating that your accumulative Error structure 
        will be a NonEmptyChain. 
        It is easier to use that Validated 
        
    .validNec and .invalidNec combinators lets us lift the success or failure 
        in their respective container (either a Valid or Invalid[NonEmptyChain[A]]).
        
    The applicative syntax (a, b, c, ...).mapN(...) 
        provides us a way to accumulatively apply the validation functions 
        and yield a product with their successful result or the accumulated errors 
        in the NonEmptyChain. 

//Example 
import cats.data.ValidatedNec
import cats.implicits._

case class Person(name: Name, age: Age)
case class Name(value: String)
case class Age(value: Int)

object Person  {
  private def validateName(name: String): ValidatedNec[String, Name] =
    if (name == "" || name == null) 
        "Name is empty.".invalidNec 
    else Name(name).validNec

  private def validateAge(age: Int): ValidatedNec[String, Age] =
    if (age < 0) "Age is out of range.".invalidNec else Age(age).validNec


  def validatePerson(name: String, age: Int): ValidatedNec[String, Person] = {
    (validateName(name), validateAge(age)).mapN(Person(_,_))
  }
}

Person.validatePerson(name = "Joe", age = 21)
//Valid(Person(Name(Joe),Age(21)))
Person.validatePerson(name = "Joe", age = 21).toEither
//Either[cats.data.NonEmptyChain[String],Person]

Person.validatePerson(name = "", age = -42)
//Invalid(Chain(Name is empty., Age is out of range.))

import cats.data.Validated

Person.validatePerson(name = "", age = -42) match {
    case Validated.Valid(x) => println(x)
    case Validated.Invalid(chain) =>   
                    chain.toList.foreach(println)
}       

//Another Solution is using Parallel
Then we can use Either instead of using Validated 
But we need to use Parallel , a type class which abstracts over Monads 
and also support parallel composition. 

trait Parallel[M[_]] {  //M[_] is Monad 
  type F[_]             //F[_] is Applicative 
  def sequential: F ~> M  //converts Applicative to Monad 
  def parallel: M ~> F    //converts Monad to Applicative 
}
~> is just an alias for FunctionK[F[_], G[_]]
A FunctionK transforms values from one first-order-kinded type into another 
first-order-kinded type.

Parallel has few methods via implicit conversions of Parallel[M]
https://github.com/typelevel/cats/blob/main/core/src/main/scala/cats/Parallel.scala
    //Like `Traverse[A].sequence, but uses Parallel 
    def parSequence[T[_]: Traverse, M[_], A](tma: T[M[A]])(implicit P: Parallel[M]): M[T[A]] 
    def parTraverse[T[_]: Traverse, M[_], A, B](ta: T[A])(f: A => M[B])(implicit P: Parallel[M]): M[T[B]]
    //traverse and then Flatten 
    def parFlatTraverse[T[_]: Traverse: FlatMap, M[_], A, B]( ta: T[A])(f: A => M[T[B]])(implicit P: Parallel[M]): M[T[B]]
    //filter and then traverse/sequence 
    def parTraverseFilter[T[_], M[_], A, B](ta: T[A])(f: A => M[Option[B]])(implicit T: TraverseFilter[T], P: Parallel[M]): M[T[B]]
    def parSequenceFilter[T[_], M[_], A](ta: T[M[Option[A]]])(implicit T: TraverseFilter[T], P: Parallel[M]): M[T[A]]

Also has (from projects/Boilerplate.scala in github) as implicit conversions on 
NonEmptyParallel[M]
    def parMap2 upto 22 [M[_], A,...,N, Z](a,...,n)(f: (A,...,N) => Z): M[Z]
    def parTuple2 upto 22[M[_], A,...,N](a,...,n): M[(A,...,N)] =
    def parMap[Z](f: (A,...,N) => Z): M[Z] 
    def parMapN[Z](f: (A,...,N) => Z): M[Z]
    def parTupled: M[(A,...,N)] 

NonEmptyParallel is non empty version of Parallel 
and instances eist for nonEmpty version of Either 
ie EitherNel=Either[NonEmptyList[A],B]
implicitly[NonEmptyParallel[({type L[A]=EitherNel[Unit,A]})#L]]

//NonEmptyList - List with atleast one element 
final case class NonEmptyList[+A](head: A, tail: List[A])
    
NonEmptyList.one(42)
NonEmptyList.of(1)
NonEmptyList.of(1, 2)
NonEmptyList.of(1, 2, 3, 4)
NonEmptyList.fromList(List())
//OR 
import cats.syntax.list._
List(1,2,3).toNel

  
//Example 

//EitherNel[A,B] is Either[NonEmptyList[A],B]
//NonEmptyList is List with atleast one Element 
import cats.data.{EitherNel, NonEmptyList} 
import cats.instances.parallel._
import cats.syntax.parallel._

case class Person(name: Name, age: Age)
case class Name(value: String)
case class Age(value: Int)
object Person  {
  private def validateName(name: String): EitherNel[String, Name] =
    if (name == "" || name == null) 
        Left(NonEmptyList.one("Name is empty.")) 
    else Right(Name(name))

  private def validateAge(age: Int): EitherNel[String, Age] =
    if (age < 0) Left(NonEmptyList.one("Age is out of range.")) 
        else Right(Age(age))


  def validatePerson(name: String, age: Int): Either[NonEmptyList[String], Person] = 
    (validateName(name), validateAge(age)).parMapN(Person(_,_))  //instead of mapN
}

Person.validatePerson(name = "Joe", age = 21)
//Either[NonEmptyList[String],Person] = Right(Person(Name(Joe),Age(21)))
Person.validatePerson(name = "", age = -42)
//Either[NonEmptyList[String],Person] = Left(NonEmptyList(Name is empty., Age is out of range.))




