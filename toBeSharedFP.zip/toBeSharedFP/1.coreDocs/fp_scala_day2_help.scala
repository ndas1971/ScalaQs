///File Handling and FP - scala.io.Source
Change this path 
"D:\handson\data\iris.csv"

csv file has five columns

case class Row(SepalLength:Double, SepalWidth:Double, 
    PetalLength:Double, PetalWidth:Double, Name:String)

object Examples  {
    
    def process[B](path:String)(f:Array[String] => B):List[B] = {
        val lines = scala.io.Source.fromFile(path).getLines.toList
        val lines2 = lines.drop(1).map(_.split(",")).map(f)
        lines2
    }    
        
    def demo_sql = {
        val path = raw"D:\handson\data\iris.csv"
        val rows = process(path){ arr =>
            val ( Array(a,b,c,d),e) = (arr.slice(0,4).map(_.toDouble), arr.last)
            Row(a,b,c,d,e)        
        }
        //println(rows)     
        val un = rows.map(_.Name).distinct  //or .toSet 
        //val un: List[String] = List(Iris-setosa, Iris-versicolor, Iris-virginica)
        //Aggregation 
        //get max of SepalLength of each Name 
        rows.groupBy(_.Name).map{case(n,lst) => (n -> lst.map(_.SepalLength).max) }
        rows.groupBy(_.Name).map{case(n,lst) => (n -> Map("sl"->lst.map(_.SepalLength).max, "sw" -> lst.map(_.SepalWidth).max)) }

        
    }
}

///Another HANDSON-  Create a csv file -- ADVANCED 
name,age,salary
ABC,2,3.0
XYZ,2,4.0
ABCD,10,9.0
AXYZ,10,18.0
Read this file and convert to immutable.List[Person]
where Person is case class with attributes name,age,salary 
Then find  age vs sum of salary (ie groupby on age)


///One HANDSON -  ADVANCCED
Write a case class Complex(not generic) with handling of + and comparison operation 
Complex has two args real, img and + adds real part and imaginary part of this with other
Then Create a List of few Complex numbers where real/img comes are Random 
and do sorting on them in general and by img part 
Then create a List of few Complex and do an operation which sums all real parts and all imaginary parts 




///Using JDBC -- ADVANCED  
//http://www.scala-lang.org/api/2.11.12/#scala.io.Source$
//fromFile, fromURL, fromChars, fromString, fromInputStream
libraryDependencies += "org.xerial" % "sqlite-jdbc" % "3.21.0.1"

case class Row(SepalLength:Double, SepalWidth:Double, PetalLength:Double, PetalWidth:Double, Name:String){
    override def toString = s"""( $SepalLength,$SepalWidth,$PetalLength,$PetalWidth,"$Name")"""
    def toSql = s"insert into iris values ${this.toString}"
}

object Examples  {
    Class.forName("org.sqlite.JDBC")
    import java.sql.{Array => JArray, _ }
    
    def process[B](path:String)(f:Array[String] =>B):List[B] = {
        val lines = scala.io.Source.fromFile(path).getLines.toList
        val lines2 = lines.drop(1). map(_.split(",")).map(f)
        lines2
    }
    
    def query[T](stmt:Statement)(sql:String)(f: ResultSet => T ) = {
        val rs = stmt.executeQuery(sql)
        new Iterator[T]{
            def hasNext = rs.next()
            def next() = f(rs)
        }   
    }
    
    //examples.Day4.demo_sql
    def demo_sql = {
        val path = raw"D:\handson\demo\iris.csv"
        val rows = process(path){ arr =>
            val ( Array(a,b,c,d),e) = (arr.slice(0,4).map(_.toDouble), arr.last)
            Row(a,b,c,d,e)        
        }
        
        //Using JDBC  
        val con = DriverManager.getConnection("jdbc:sqlite:iris.db")
        val stmt = con.createStatement()
        stmt.executeUpdate("drop table if exists iris")
        stmt.executeUpdate("""create table iris (
            SepalLength double, SepalWidth double,PetalLength double,PetalWidth double,Name string)""" )
        val how_many_rows = rows.map(_.toSql).map(stmt.executeUpdate).sum
        println(s"Inserted $how_many_rows rows")  
        val sql1 = "select count(*) from iris"
        val it = query(stmt)(sql1){ r =>
                r.getInt(1)
            }.toList 
        println(s"$sql1=$it")
        val sql2 = "select Name, max(SepalLength) from iris group by Name"
        val it1 = query(stmt)(sql2){ r =>
                (r.getString(1), r.getDouble(2))
            }.toList 
        println(s"$sql2=$it1")
        con.close
    }
}

///Executing External Commands --ADVANCED  

import sys.process._
val exitCode = "ls -al".!    //Get exit code, displays in stdout// beware leading whitespace // beware trailing whitespace
val  out = "ls -al".!!       //as a string
out.count( c => c == '\n')   //res18: Int = 40, how many lines
val  out2 = "ls -al".lineStream.toList  // Lines in List, lineStream returns Stream , older version- use lines

//When error
val out = "ls -l fred" !     //returns exitValue
//but !! raises Exception
val out = "ls -l fred" !!     // java.lang.RuntimeException: Nonzero exit value: 1
 
//Unexpected newline characters, use trim
val dir = "pwd" !!   //contains new line
val dir = "pwd".!!.trim

//to Use glob patterns , use Seq version not String version
Seq("ls", "*.txt").!!  //in String
Seq("ls", "*.txt").lineStream.toList  //In List

//Redirecting Input/Output
//Use  #<, #> and #>>, 
//may take as input either another ProcessBuilder or java.io.File or a java.io.InputStream. 
new java.net.URL("http://www.google.co.in") #> "grep google" #>> new java.io.File("google.txt") !

//Pipe - #|  , shell and - #&&, , shell or - #||
"ls" #| "grep .scala" #&& Seq("sh", "-c", "scalac *.scala") #|| "echo nothing found" !


///Understanding Types in Scala 
There are four ways to define a type in Scala:
    1) By defining a class, object, or trait to create a concrete type
    2) By defining a method that creates a method type
    3) By using a literal to define a singleton type
    4) By using the type keyword to define an alias for an abstract or concrete type


//1) Example 
class SomeClass      
object SomeObject    

:type SomeObject //SomeObject.type,  singleton type 
:type new SomeClass //SomeClass

trait SomeTrait {
    def usage(a: SomeClass, b: SomeObject.type): SomeTrait
}

class ClassWithSomeTrait extends SomeTrait{
    def usage(a: SomeClass, b: SomeObject.type): SomeTrait = this 
}
:type (new ClassWithSomeTrait).usage(new  SomeClass, SomeObject) //SomeTrait

//2) Example 
A method type does not denote a value, nor does it appear directly in the program. 
It is an internal representation of a method definition. 
As we defined in the usage method, the compiler internally created a method type called 
(a: SomeClass, b:SomeObject.type) SomeTrait.

//3)Example Type alias 
If used properly, infix types can greatly improve the readability of the code:

abstract class Dummy[A,B](x:A)

type |[A, B] = Dummy[A,B]       //OR 

implicitly[ Dummy[Int, Int] =:= (Int|Int)]

//Then usage 
class A[T](x:T) extends Dummy[T,T](x)
def func(x:Int):Int | Int = new A[Int](x)


//4) Example - Literal types  
It is available for all types for which literal syntax is available 
(for example, Boolean, Char, String, and Symbol). 

It is impossible to define a literal type for Unit (by specification) 
and for Byte and Short (because there is no syntax to define literals of such types). 

These literal types are not very interesting for day-to-day programming, 
but are very useful for type-level library development.

//Example 
val t:42 = 42
//val t: 42 = 42

Automatically converted to Int when usage 

t + 2
//val res6: Int = 44


def bool2String(b: true) = "ja"
//bool2String: (b: true)String

bool2String(true)
//res7: String = ja

bool2String(false)
//error: type mismatch;

A literal type is erased to the normal type during compilation, 
and so it is not possible to overload methods using literal types:

object scope {
    def bool2String(b: true) = "ja"
    def bool2String(b: false) = "nein"
}
// error: double definition:


///this.type  - returns concrete class type polymorphic --ADVANCED 
trait TA { def f:this } // NOK               

trait TA { def f:this.type  }  //OK

class A extends TA { def f = this} //returns A , override can change return type

class B extends TA { def f = this} //but Returns B 

:type (new A()).f   // Return A object
:type (new B()).f   // returns B object


//Example Usage - Method Chaining by using this.type
class A {def method1: A = this }
class B extends A {def method2: B = this }

val b = new B()

b.method2.method1

b.method1.method2   //NOK as method2 belongs to B

//Use with this.type
class A {def method1: this.type = this }
class B extends A {def method2: this.type = this }

val b = new B()

b.method2.method1   //b.type = B@4a3a0004

b.method1.method2  //res45: b.type = B@4a3a0004


///Path-dependent types 
Suppose we have Lock and its Key 

case class Lock() {
 final case class Key()
 def open(key: Key): Lock = this          //this.Key, Key of this Lock != Key of Any Lock 
 def close(key: Key): Lock = this         //this.Key
 def openWithMaster(key: Lock#Key): Lock = this //Lock#Key: type projection, Key of Any Lock 
 def makeKey: Key = new Key               //this.Key
 def makeMasterKey: Lock#Key = new Key    //type projection
}

//Check the difference between this.Key and Lock#Key 

val   blue: Lock = Lock()
val   red: Lock = Lock()
val   blueKey: blue.Key = blue.makeKey  //Note blue=this 
val   anotherBlueKey: blue.Key = blue.makeKey
val   redKey: red.Key = red.makeKey

blue.open(blueKey)          //takes only blue.Key 
blue.open(anotherBlueKey)
blue.open(redKey)           // compile error
red.open(blueKey)           // compile error

//The masterKey is not path-dependent
val masterKey: Lock#Key = red.makeMasterKey

blue.openWithMaster(masterKey)
red.openWithMaster(masterKey)




///Scala self type - creating dependencies 

trait   A   {   def a: String }
trait   B   {   def b: String }

//C must be mixed with A
trait   C   {   this: A => // override `this`, now this is A , so all methods of A can be called  
  def   c   =   this.a
}

//D must be mixed with A and B 
trait   D { self: A with B =>   // any alias is allowed, but generally this or self is used 
  def   d = self.a + this.b     //can access like self or this 
}

abstract class DD extends D  //Error 
abstract class DD extends D with A with B  //OK 

///More on Scala self type - ADVANCED 
//Other Example - self type also used for Renaming this or Outer.this 
class A {
    outer =>
    private val a:Int = 0
    class B {                       // if this is private, A can access it's public member, but outside world can not
      inner =>
        private val b:Int = 0       //since it is private, outerclass can not access (unlike Java)
        def m = outer.a + inner.b   // outer eq A.this and inner == this. Note inner class can access Outer's private 
    }
    def m2 = { val i = new B ; i.m }  
}
	
//new A#B()  // note A#B is only a type, can not be used as constructor
val a:A#B = { val m = new A; new m.B } //a: A#B = A$B@57b59fa2  // if B is private , new m.B fails
a.m //0


///Example of Type Bounds 
                      Name          Description
A <: B                Upper bound   A must be a subtype of B. , java- A extends B
A >: B                Lower bound   A must be a supertype of B. , java- none
A >: Lower  <: Upper  Both Bound    Lower must come first, Java - none


class A[T <: AnyVal]
new A[Int]

class A[T >: AnyVal]
new A[Any]

class A[T >:AnyVal <: Any]
new A[AnyVal]

///When to use Type parameters and Type members 
Type parameters, eg A are used to define input types 
and type members, eg Repr to define the output  type 

//Example 
trait Generic[A] {
    type Repr
    def to(value: A): Repr
    def from(value: Repr): A
}

Suppose we implement a method getRepr as follows.
What type will we get back?

def getRepr[A](value: A)(implicit gen: Generic[A]) =  gen.to(value)

The answer is it depends on the instance we get for gen

case class Vec(x: Int, y: Int)
case class Rect(origin: Vec, size: Vec)

Shapeless has few implicits for case class, lets use those 

import shapeless._

//Note the returned type is changing for each input argument 
getRepr(Vec(1, 2))
// res1: Int :: Int :: shapeless.HNil = 1 :: 2 :: HNil

getRepr(Rect(Vec(0, 0), Vec(5, 5)))
// res2: Vec :: Vec :: shapeless.HNil = Vec(0,0) :: Vec(5,5) :: HNil
 

Suppose we had specified Repr as type parameter on Generic instead of a type member:

trait Generic2[A, Repr]
def getRepr2[A, R](value: A)(implicit generic: Generic2[A, R]): R =   ???

We would have had to pass the desired value of Repr to getRepr 
as a type parameter, effectively making getRepr useless. 

Conclusion: type parameters are useful as "inputs" 
and type members are useful as "outputs".

///What is Shapeless -- ADVANCED 
//Note Shapeless is used for Heterogeneous List , HList 
import shapeless._

case class User(name:String) 

val product =  "Sunday" :: 1 :: User("someone")  :: HNil
//String :: Int :: User :: shapeless.HNil

//Many List methods are applicable 
val first = product.head
// first: String = Sunday

val second = product.tail.head
// second: Int = 1

//map,flatmap takes shapeless.Poly 
import shapeless._

//All type must be implemented 
object plusOneOrSize extends Poly1 {
  implicit def caseInt =  at[Int]{ _ + 1 }   //at[In]{return Out}
  implicit def caseString =  at[String]{ _.size }
  implicit def caseUser = at[User]{ case User(name) =>  User(name.toUpperCase())  }
}

product.map(plusOneOrSize) 
//Int :: Int :: User :: shapeless.HNil = 6 :: 2 :: User(SOMEONE) :: HNil

//Or FlatMap, must return HList 

object plusplusOne extends Poly1 {
  implicit def caseInt =  at[Int]{ num => num :: num :: HNil }  //T is Input, Return of lambda is output 
  implicit def caseString =  at[String]{ str => str :: str :: HNil }
  implicit def caseUser = at[User]{ case User(name) =>  User(name + 1) :: User(name+2) :: HNil  }
}
product.flatMap(plusplusOne) 

//FoldLeft etc takes Poly2 
object plusplusOne extends Poly2 {
  implicit def caseInt =  at[Double,Int]{ (r,num) => r+num }  //at[Input1,Input2]( (in1,in2)=> Output )
  implicit def caseString =  at[Double,String]{ (r,str) => r + str.size }
  implicit def caseUser = at[Double, User]{ (r, user) =>  r + user.name.size }
}
product.foldLeft(0.0)(plusplusOne) //14  



///Variance  Details --ADVANCED 
//In JAVA - PECS ie Producer-Extend,  
//Consumer-Super and they are put in call site unlike scala, which are put in definition
C[+T]  
    co-varient means , T is produced, ie in function-return or can be read/get from C 
    also means C[T'] is subtype of C[T] if T' <: T
    Whenever C[T] is required, one can pass C[T'] 
    and usage can operate on C[T'] to get/read T
C[-T]  
    contravarient means , T is consumed, or in function-arg or can be put/write in C 
    means C[T] is subtype of C[T'] if T' <: T 
    Whenever C[T'] is required, one can pass C[T] and usage can operate on C[T] to put/write of T   //'

Note  If C[T] and  C'[T] are always related if container is related 
ie C' <: C , then C'[T] <: C[T]
(ie List[Int] is subtype of Seq[Int] as List <: Seq) 

Variances  is for the case 
how C[T] and C[T'] are related if content T is related to T' 

OR can we use C[T'] when C[T] is required or vice versa?

Three cases (Rememeber in Function1[-T,+R] which T => R)
    if T , only same type can be used  and it is mutable
    if +T, Yes, use C[T'] at place of C[T]  when T' is subtype of T
        and it is immutable  and also this container produces T (ie in fn returns)
    if -T , Use C[T]  at place of C[T'] only when T' is subtype of T
        and it is immutable, but this container consumes T (ie in function arg)

Recomendation:
    if generic type only acts as fn parameter: Use contravariance. 
        One restricted workaround, if T should be used as fn return, 
        we can use like 
        class A[-T](x:T){  //no val or var so no get:T 
            def m[B <: T] (x:T):B = ???
        }
        Else Error "contravariant type T occurs in covariant position"
    if generic type only acts as return  value: Use covariance. 
        One restricted workaround, if T should be used as fn parameter, we can use like 
        class A[+T](val x:T){ //val OK as val means get:T which is fn return type 
            def m[B >: T] (x:B):T = ???
        }
        Else error "covariant type T occurs in contravariant position"        
    Else for both place or mutable, use Invariant
        No Restriction 
        class A[T]{
            var x:T = _  //OK , Note _ is only valid for var 
            def m(x:T):T = ???
        }

///Example of Variances - Note Array[T], List[+T]
val l:Array[AnyVal] = Array[Int](1,2,3,4) //NOK 
val l2 :List[AnyVal] = List[Int](1,2,3)

class A[T]
val la:A[AnyVal] = new A[Int] //Error 

class A[+T]
val la:A[AnyVal] = new A[Int] //OK

class A[-T]
val la:A[Int] = new A[AnyVal] //OK


///Existential types  
Existential types come into play if we stop caring 
about the specifics of type parameters.

(Existential types used in function arguments to denote any container arg
whereas Higher kinded is used in type parameters/members to denote Container type )

Array[_] means any Array, not Array of Any  

def p(x:Array[_]) = x.size 
//not same as 
def p1(x:Array[Any]) = x.size 

p1(Array("OK"))  //1
p1(Array[String]("OK")) //error as Array[String] <: Array[Any] as Array is invariant 
p(Array[String]("OK"))

//above means 
def p3[T](x:Array[T]) = x.size 

Can also have type bounds 
def f(x:List[_ <: AnyVal]) = x.length  //OK


///Higher kinded types 
Higer kinded are similar to HOF 

Higer kinded types are in Type parameters (in function or class type params)

//first order function
val f =  (x:Int,y:Int) => x+y
//f: (Int, Int) => Int = <function2>

:type f
//(Int, Int) => Int

//Type Constructor 
:kind -v List
//List's kind is F[+A]
//* -(+)-> *
//This is a type constructor: a 1st-order-kinded type.

class C[T,U[X]]
class D[T,U[_],X[_,_[_]]]  
//same as D[T,U[Z],X[Z,X1[Z]]] as inside []', _ can be used as Type variable to mean 'ignore it'

scala> :kind -v D
//D's kind is Y[A1,F1[A2],X[A3,F2[A4]]]
//* -> (* -> *) -> (* -> (* -> *) -> *) -> *
//This is a type constructor that takes type constructor(s): a higher-kinded type.


///One example of Higher kinded types: To remove complicated casting  -- ADVANCED 
trait Optional[+T]
case class Sm[T](x:T) extends Optional[T]
case object Nn extends Optional[Nothing]


val map: Map[Optional[Any], List[Any]] = Map(
   Sm("foo") -> List("f", "O"),
   Sm(42) -> List(2,3,4),
   Sm(true) -> List(true, false, false))

//ugly cast
val xs: List[String] = map(Sm("foo")).asInstanceOf[List[String]]
val ys: List[Int] = map(Sm(42)).asInstanceOf[List[Int]]


//:Paste
class HOMap[ K[_], V[_]]( val map : Map[ K[Any], V[Any] ]) {
 def apply[A](key: K[A]) : V[A] =  map(key.asInstanceOf[K[Any]]).asInstanceOf[V[A]]
}
object HOMap {
    type Pair[K[_], V[_]] = (K[Any], V[Any]) 
    def apply[K[_], V[_]](tuples: Pair[K,V]*) = new HOMap[K, V]( Map(tuples: _*) )
}


val map_b: HOMap[Optional, List] = HOMap[Optional, List](
  Sm("foo") -> List("foo", "bar", "baz"),
  Sm(42) -> List(1, 1, 2, 3, 5, 8),
  Sm(true) -> List(true, false, true, false)
)

val xs_b: List[String] = map_b(Sm("foo"))
val ys_b: List[Int] = map_b(Sm(42))
println(xs_b)
println(ys_b)

///Type Lambdas  
Type Lambda are used where container type/higher kinded type is required 
and on the fly, we want to create that (similar to function lambda but on type level)

def fn[A, F[_]](x : F[A]) = x  

(Existential types used in function arguments to denote any container arg
whereas Higher kinded is used in type parameters/members to denote Container type 
eg def fn[F[_] <--- higherkinded](x : List[_] <--- existential) = x
)

For List, Set, above can be used as those take single type parameters 

val x = List(1,2,3)
fn[Int, List](x)  
//OR 
fn(x)


But if we have Map[X,Y], then how to use it ? 
Solution is We need to fix one of X,Y 

//USage 
val m = Map(1 -> "OK", 2->"NOK")
fn(m) //OK 

fn[Int, Map](m)
//error: Map takes 2 type parameters, expected: 1

//Solution 
type MapA[A] = Map[Int, A]
fn[String, MapA](m)

//OR type lambda - syntax template - ({})#
fn[String, ({type L[A] = Map[Int, A]})#L](m) 


///Type Recursion or f bound polymorphic  -- ADVANCED 

One example - How to enforce comparison with same type
 
// naive impl, But problem is any derived class of Fruit can be used for comparison
trait Fruit {
  final def compareTo(other: Fruit): Boolean = true 
}

class Apple  extends Fruit
class Orange extends Fruit

val apple = new Apple()
val orange = new Orange()

apple compareTo orange 
// compiles, but we want to make this NOT compile!
//Because apple type is not same as orange type 

//Solution - use f bound polymorphic 

trait Fruit[T <: Fruit[T]] {
  final def compareTo(other: Fruit[T]): Boolean = true 
}

class Apple  extends Fruit[Apple]
class Orange extends Fruit[Orange]

val apple = new Apple
val orange = new Orange

orange compareTo apple  //NOK
orange compareTo orange  //res1: Boolean = true


///Phantom types to represent Domain constraints   -- ADVANCED 
(Phantom types is marker trait which does not have Runtime representation
but only useful at compile time to express application  constraints) 

Example , Suppose we have Lock 
How to Enforce that following state transitions are allowed for any locks?
open -> closed
closed -> open
closed -> broken
open -> broken

Use  phantom types Open, Closed, and Broken to model the states 

sealed   trait   LockState
sealed   trait   Open extends LockState
sealed   trait   Closed extends LockState
sealed   trait   Broken extends LockState


case class Lock[State <: LockState]() {
    //And define our state transitioning methods using type constraints:
    def break: Lock[Broken] = Lock()                        //Any State can break it 
    def open[_ >: State <: Closed](): Lock[Open] = Lock()   //when Closed, -> Open 
    def close[_ >: State <: Open](): Lock[Closed] = Lock()  //When Open, -> Closed
}

val openLock = Lock[Open]
//openLock: Lock[Open] = Lock()

val closedLock = openLock.close()
//closedLock: Lock[Closed] = Lock()

val broken = closedLock.break
//broken: Lock[Broken] = Lock()

closedLock.close()
//Error: inferred type arguments [Closed] do not conform to method close

openLock.open()
//error: inferred type arguments [Open] do not conform to method open type


We can also provide an alternative implementation 
by using generalized type constraints
(A=:= B is same as A = B but used like implicits such that proof of type equality is deferred ) 

def open(implicit ev: State =:= Closed): Lock[Open] = Lock()
def close(implicit ev: State =:= Open): Lock[Closed] = Lock()




///Various usages of Implicits

//1.implicit conversion - Scala3-Conversion or extension 
class Conv(x:String) {
    def toIntx(rx:Int) = Integer.valueOf(x,rx)
}

(new Conv("AB")).toIntx(16)
implicit def xyz(x:String) = new Conv(x)
"AB".toIntx(16)

//or 
implicit class Conv(x:String) {
    def toIntx(rx:Int) = Integer.valueOf(x,rx)
}
"AB".toIntx(16)

//2. Implicits as Context Parameter 
class A[T](val init:T)

implicit val x = new A[Int](20)  //only one must be in scope 

def m(y:Int)(implicit ev:A[Int]) =  "OK" + ev.init.toString

m(2)(new A[Int](30))
m(2)

//3. Usage in typeClass -  scala3: Context parameter-using and given 

trait Add[T]{
    def plus(x:T, y:T) :T
}

def add[T](x:T, y:T)(implicit ev:Add[T]) = ev.plus(x,y) 

add(2,3)//NOK 

//one of below two should be written as one one should be in scope 
implicit object xyws1 extends Add[Int]{
    def plus(x:Int, y:Int) = x+y 
}
//OR 
implicit val xyzw = new Add[Double]{def plus(x:Double, y:Double) = x-y}

add(2,3)//OK 


Check implicits in scope Scala2 REPL 
:implicits -v

//Type class might not be higher kinded
//in that case implicit should be function value , also called View Bounds(syntax deprecated)
trait Pretty {
  val print: String
}

def pretty[A](a: A)(implicit  ev: A => Pretty): String =
  a.print   //implicit conversion from an implicit function value 


implicit def con(x:Int) = new Pretty { val print:String = x.toString   }

implicit object PrettyDouble extends (Double => Pretty) {
    def apply(x:Double):Pretty = new Pretty{ val print = x.toString}
    }

pretty(3.0)
pretty(3)

//Another example 
case class CanEqual(hash: Int)

def equal[CA, CB](a: CA, b: CB)(implicit ca: CA => CanEqual, cb: CB =>CanEqual): Boolean = 
    //ca(a).hash == cb(b).hash //scala3 syntax  
    a.hash == b.hash 

//with view bounds syntax(deprecated, scala3-removed)
def equalsWithBounds[CA <% CanEqual, CB <% CanEqual](a: CA, b: CB): Boolean   = {
 //val hashA = implicitly[CA => CanEqual].apply(a).hash
 //val hashB = implicitly[CB => CanEqual].apply(b).hash
 //hashA == hashB
  a.hash == b.hash
}  
//OR 
def equalsWithPassing[CA <% CanEqual, CB <% CanEqual](a: CA, b: CB): Boolean = equal(a, b)

//usage 
case class A()
case class B()
implicit def coA(a:A) = CanEqual(a.hashCode)
implicit def coB(a:B) = CanEqual(a.hashCode)

equal(A(), B())
equalsWithBounds(A(), A())
equalsWithPassing(B(),B())


//Example of buily-in typeclasses - Many typeclass is available in scala 
For sorting ,
List[A].sorted[B >: A](implicit ord: Ordering[B]): List[A]

//Example 
case class Animal(name:String, age:Int)

implicit val ao = new Ordering[Animal]{
     def compare(x: Animal, y: Animal): Int = x.age.compare(y.age)
}

(10 to 20).toList.map(Animal("ABC", _)).sorted  

//OR could have done 
case class Animal2(name:String, age:Int) extends Ordered[Animal2]{
    def compare(that: Animal2) =  this.age.compare(that.age)
}
(10 to 20).toList.map(Animal2("ABC", _)).sorted  
// sorted[B >: A](implicit ord: Ordering[B]): List[A]

//Ordering object has many goodies , for example - for reverse sorting
object Ordering 
    def by[T, S](f: (T) => S)(implicit ord: Ordering[S]): Ordering[T]
    def fromLessThan[T](cmp: (T, T) => Boolean): Ordering[T]

(10 to 20).toList.map(Animal2("ABC", _)).sorted(
    Ordering.by[Animal2, Int](_.age).reverse)
//another example     
case class Animal3(name:String, age:Int)
(10 to 20).toList.map(Animal3("ABC", _)).sorted(Ordering.by[Animal3,Int](_.age))

//Similarly for Numeric 
def mean[T](xs: Seq[T]):Double = xs.sum / xs.size//Error 

def mean[T](xs: Seq[T])(implicit ev: Numeric[T]) :Double = {
    import ev._
    xs.sum.toDouble / xs.size
}
def mean[T:Numeric](xs: Seq[T]) :Double = {
    val ev = implicitly[Numeric[T]]
    import ev._
    xs.sum.toDouble / xs.size
}


///HandsOn  - Implement below 
Mean(lst) =         Sum of lst/length of lst 
Median(lst) =       sort and midddle value or average of two middle  if length is even
sd(lst) =           sqrt of( SUM of square of ( each elemnt - mean)  / length of lst  )
Mode(lst) =         sort with frequency, highest frequency
Put these methods in List 



///Another example of type class - Json Serialization  -- ADVANCED
//Implement instances in companion object of type class trait or in companion object of custom class 

sealed trait Json
final case class JsObject(get: Map[String, Json]) extends Json
final case class JsString(get: String) extends Json
final case class JsNumber(get: Double) extends Json
final case object JsNull extends Json


// The "serialize to JSON" behaviour is encoded in this trait
trait JsonWriter[A] {
    def write(value: A): Json
}


//FOr 
case class Person(name: String, email: String)

object JsonWriterInstances {
    implicit val stringWriter: JsonWriter[String] =
       new JsonWriter[String] {
           def write(value: String): Json =
            JsString(value)
       }

    implicit val personWriter: JsonWriter[Person] =
       new JsonWriter[Person] {
           def write(value: Person): Json =
            JsObject(Map(
               "name" -> JsString(value.name),
               "email" -> JsString(value.email)
             ))
       }
}
//Smart method - basically summons the implicit 
object JsonH {
    def toJson[A](value: A)(implicit w: JsonWriter[A]): Json =
      w.write(value)
}

import JsonWriterInstances._
//import JsonWriterInstances.given 

JsonH.toJson(Person("Dave", "dave@example.com"))

We can alternatively use extension methods on Person 
to extend existing types with interface methods. 

object JsonSyntax {
    implicit class JsonWriterOps[A](value: A) {
        def toJson(implicit w: JsonWriter[A]): Json =
          w.write(value)
    }
}

import JsonWriterInstances._
import JsonSyntax._
Person("Dave", "dave@example.com").toJson

implicitly[JsonWriter[String]]
 // res5: JsonWriter[String] = repl.Session$App0$JsonWriterInstances$$anon$1@6fccdc48
 //summon[JsonWriter[String]]


///Conditional Implicits  -- ADVANCED
Option[+A] is Used for null handling for type A 
eg Option("Hello") is Some("hello") , Some inherited from Option[String]
whereas Option(null:String) is None:Option[String]

Consider defining a JsonWriter for Option. 
Do we need a JsonWriter[Option[A]] for every A we care about in our application
like below?

implicit val optionIntWriter: JsonWriter[Option[Int]] =???
implicit val optionPersonWriter: JsonWriter[Option[Person]] =  ???
// and so on...

No. We can Use implicit def as conditional implicits 
then scala would search implicits for A 

implicit def optionWriter[A](implicit writer: JsonWriter[A]): JsonWriter[Option[A]] =
  new JsonWriter[Option[A]] {
      def write(option: Option[A]): Json =
        option match {
            case Some(aValue) => writer.write(aValue)
            case None        => JsNull
        }
  }

import JsonWriterInstances._

JsonH.toJson(Option("A string"))
//JsString(A string)

//But below fails, why?
JsonH.toJson(Some("A string"))
//error: could not find implicit value for parameter  -- WHY???
       

//Details of implicit searching 
When the compiler sees an expression like this:
JsonH.toJson(Option("A string"))

it searches for an implicit JsonWriter[Option[String]]. 
It finds the implicit method for JsonWriter[Option[A]]:

JsonH.toJson(Option("A string"))(optionWriter[String])
//JsonH.toJson(Option("A string"))(using optionWriter[String])

and recursively searches for a JsonWriter[String] 
to use as the parameterto optionWriter:
JsonH.toJson(Option("A string"))(optionWriter(stringWriter)) 
    
But With Variance , we have one complexity , If both base type 
and derived type implicits are available, which one is used ?

Type Class Variance               Invariant       Covariant      Contravariant

Supertype instance used?          No              No             Yes
More specific type preferred?     No              Yes            No


For Option[+A], it is Covariant , 
hence if Option and Some is present, Some is choosen 
But if Some is not present and Option is present , then Error , 

We can solve this problem with a type annotation like Some("Hello") : Option[String] 
or by using "smart constructors" like the 
Option.some, and none methods (not present builtin) which returns option[T] instead of Some or None 

object OptionEx{
    def some[A](x:A):Option[A] = Some(x)
    def none[A]:Option[A] = None
}

JsonH.toJson(OptionEx.some("A string"))

///Another Example of typeclass (idiomatic )--ADVANCED  

trait CsvEncoder[A] {
 def encode(value: A): List[String]
}
//1. create an apply method which summons implicits 
//2. Create constructor method which would be called for typeclass creation 
//3. Create basic instances and then create conditional instances based on basic instance 
object CsvEncoder {    
    def apply[A](implicit enc: CsvEncoder[A]): CsvEncoder[A] =  enc

    // "Constructor" method
    def instance[A](func: A => List[String]): CsvEncoder[A] =
     new CsvEncoder[A] {
         def encode(value: A): List[String] =
           func(value)
     }

    //Now generally any encoder can be written by calling above 
    implicit val booleanEncoder: CsvEncoder[Boolean] =
        instance(b => if(b) List("yes") else List("no"))
        
    implicit val stringEncoder: CsvEncoder[String] =
      instance(str => List(str))
    
    
    implicit val intEncoder: CsvEncoder[Int] =
      instance(num => List(num.toString))
      
    implicit def pairEncoder[A, B](  implicit aEncoder: CsvEncoder[A], bEncoder: CsvEncoder[B]): CsvEncoder[(A, B)] =
         instance{ pair: (A, B)  =>
                  val (a, b) = pair
                 aEncoder.encode(a) ++ bEncoder.encode(b)
             }


}

// Custom data type:
case class Employee(name: String, number: Int, manager: Boolean)
object Employee {
  import CsvEncoder._
 // CsvEncoder instance for the custom data type:
 implicit val employeeEncoder: CsvEncoder[Employee] =
     instance{ e =>
             List(
                 e.name,
                 e.number.toString,
                 if(e.manager) "yes" else "no"
             )
     }
}

//The apply method, known as a "summoner" or "materializer", does the 
//same job as scala.Predef.implicitly

CsvEncoder[Employee]
// res9: CsvEncoder[Employee] = $anon$1@5940ac6a
//OR 
implicitly[CsvEncoder[Employee]]
// res10: CsvEncoder[Employee] = $anon$1@5940ac6a

def writeCsv[A](values: List[A])(implicit enc: CsvEncoder[A]): String  =
     values.map(value => enc.encode(value).mkString(",")).mkString("\n")


val employees: List[Employee] = List(
     Employee("Bill", 1, true),
     Employee("Peter", 2, false),
     Employee("Milton", 3, false)
)

writeCsv(employees)
 
//We can use writeCsv with any data type we like, provided we have a corresponding implicit CsvEncoder in scope:

case class IceCream(name: String, numCherries: Int, inCone: Boolean)
object IceCream {
  import CsvEncoder._
  
    implicit val iceCreamEncoder: CsvEncoder[IceCream] =
     instance{i =>
          List(
              i.name,
              i.numCherries.toString,
              if(i.inCone) "yes" else "no"
          )
     }
}

val iceCreams: List[IceCream] = List(
 IceCream("Sundae", 1, false),
 IceCream("Cornetto", 0, true),
 IceCream("Banana Split", 0, false)
)


writeCsv(iceCreams)

//Then using pair 
writeCsv(employees zip iceCreams)


///Generalized type constraints -- ADVANCED  
There is also another way(than bounds) to specify boundaries 
for type parameters and type members in Scala, Generalized type constraints.

A <:< B is same as A <: B, but is used as implicits , 
hence resolution is deferred via searching implicit scope (at usage site)
whereas A <: B is checked during compiler type-checking 

abstract class Wrapper[A] {
  val a: A
  //eg, flatten Wrapper[A] when A is of Wrapper[X] 
  // A in flatten would shadow A in the Wrapper[A] if written below way 
  // def flatten[B, A <: Wrapper[B]]: Wrapper[B] = a
  def flatten[B](implicit ev: A <:< Wrapper[B]): Wrapper[B] = a
}

val aa = new Wrapper[Wrapper[Int]]{ val a = new Wrapper[Int]{ val a = 2} }
aa.flatten //Wrapper[Int]


Similarly A=:= B is same as A = B but used as implicits such that its resolution  is deferred 

//Example 
case class Foo[A](a:A) { // 'A' can be substituted with any type
    // getStringLength can only be used if this is a Foo[String]
    def getStringLength(implicit evidence: A =:= String) = a.length
}

Foo("blah").getStringLength
 
//Another example 
Suppose you want to define a "generic" homogeneous Pair(val first: T, val second: T) and 
define smaller method for comparing first and second only if T <: Ordered[T]

//example 
class Pair[T](val first: T, val second: T) {
    def smaller(implicit ev: T <:< Ordered[T]) = if (first < second) first else second
}

Above can be defined as below, but now T has to be ordered 
and Pair can not be used for any other T , To solve that, defer T <: Ordered[T] resolution 

class Pair[T <: Ordered[T]](val first: T, val second: T) {
    def smaller = if (first < second) first else second
}

//Few examples from builtin scala library 
On Either[+A, +B], you have below methods (so B1 or A1 must be Either)

 def joinRight[A1 >: A, B1 >: B, C](implicit ev: B1 <:< Either[A1, C]): Either[A1, C] = this match {
   case Left(a)  => Left(a)
   case Right(b) => b
 }

 def joinLeft[A1 >: A, B1 >: B, C](implicit ev: A1 <:< Either[C, B1]): Either[C, B1] = this match {
   case Left(a)  => a
   case Right(b) => Right(b)
 }

On Option, you have:

def orNull[A1 >: A](implicit ev: Null <:< A1): A1 = this getOrElse null




///Type class - Example from Cats - Show  -- ADVANCED
Show is an alternative to the Java toString method. 
It is defined by a single function show:

def show(a: A): String

The difference is that toString is defined on Any
and can therefore be called on anything, not just case classes. 

Most often, this is unwanted behaviour, as the standard implementation of 
toString on non case classes is mostly gibberish. 

(new {}).toString
// res0: String = "repl.MdocSession$App$$anon$1@31418a9b"


//Example 
import cats._ 
import cats.implicits._ 

//It has below 
trait Show[A] {
    def show(value: A): String
}
object Show {
    /** creates an instance of Show using the provided function */
    def show[A](f: A => String): Show[A]

    /** creates an instance of Show using object toString */
    def fromToString[A]: Show[A]
}
//USage 
import cats.Show

case class Person(name: String, age: Int)

implicit val showPerson: Show[Person] = Show.show(person => person.name)

case class Department(id: Int, name: String)

implicit val showDep: Show[Department] = Show.fromToString //case class has good ToString
// showDep: Show[Department] = cats.Show$$anon$3@184af520


import cats.implicits._

val john = Person("John", 31)
john.show
// res1: String = "John"

val engineering = Department(2, "Engineering")
show"$john works at $engineering"
// res2: String = "John works at Department(2,Engineering)"


///Show for Custom ---- ADVANCED 
import java.util.Date


implicit val dateShow: Show[Date] =
 new Show[Date] {
     def show(date: Date): String =
       s"${date.getTime}ms since the epoch."
 }


new Date().show
// res1: String = "1594650192117ms since the epoch."


//OR

implicit val dateShow: Show[Date] =
     Show.show(date => s"${date.getTime}ms since the epoch.")


//Our definition of Cat remains the same:
final case class Cat(name: String, age: Int, color: String)

implicit val catShow: Show[Cat] = Show.show[Cat] { cat =>
 val name   = cat.name.show
 val age    = cat.age.show
 val color = cat.color.show
 s"$name is a $age year-old $color cat."
}

println(Cat("Garfield", 38, "ginger and black").show)
// Garfield is a 38 year-old ginger and black cat.
 
 
///Type class - Example from Cats - Eq
Eq is designed to support typesafe equality and address annoyances 
using Scalas builtin == operator.
(which would always succeeds and return false if dissimilar types )
(we want dissimilar types to fail during compilation )

List(1, 2, 3).map(Option(_)).filter(item => item == 1)
// warning: Option[Int] and Int are unrelated: they will most likely never compare equal
// res: List[Option[Int]] = List()

The predicate in the filter clause always returns false 
because it is comparing an Int to an Option[Int].


//cats has below 
trait Eq[A] {
    def eqv(a: A, b: A): Boolean
    // other concrete methods based on eqv...
}

With Symbols 
=== compares two objects for equality;
=!= compares two objects for inequality.

//Example 
import cats._ 
import cats.implicits._ 


val eqInt = Eq[Int]

eqInt.eqv(123, 123)
// res1: Boolean = true
eqInt.eqv(123, 234)
// res2: Boolean = false


eqInt.eqv(123, "234")  
// error: type mismatch;
//     found   : String("234")
//     required: Int

123 === 123
// res4: Boolean = true
123 =!= 234
// res5: Boolean = true

123 === "123"    //ordinarily , it would return false, 123 == "123"
// error: type mismatch;
//     found   : String("123")
//     required: Int
// 123 === "123"
//             ^^^^^


Some(1) === None
// error: value === is not a member of Some[Int]
// Some(1) === None
// ^^^^^^^^^^^

We have received an error here because the types donot quite match up. 
We have Eq instances in scope for Int and Option[Int] 
but the values we are comparing are of type Some[Int] 
and Option is covariant, so either Some must have implementation 
or use smart constructor  


(Some(1) : Option[Int]) === (None : Option[Int])
// res8: Boolean = false

//OR 
Option(1) === Option.empty[Int]
// res9: Boolean = false

or using special syntax from cats.syntax.option:

1.some === none[Int]
// res10: Boolean = false
1.some =!= none[Int]
// res11: Boolean = true

///Eq - Comparing Custom Types -- ADVANCED 
import java.util.Date


implicit val dateEq: Eq[Date] = Eq.instance[Date] { (date1, date2) =>
    date1.getTime === date2.getTime
}


val x = new Date() // now
val y = new Date() // a bit later than now


x === x
// res12: Boolean = true
x === y
// res13: Boolean = false


final case class Cat(name: String, age: Int, color: String)

val cat1 = Cat("Garfield",      38, "orange and black")
val cat2 = Cat("Heathcliff", 33, "orange and black")

val optionCat1 = Option(cat1)
val optionCat2 = Option.empty[Cat]


implicit val catEqual: Eq[Cat] =
    Eq.instance[Cat] { (cat1, cat2) =>
       (cat1.name   === cat2.name ) &&
       (cat1.age    === cat2.age   ) &&
       (cat1.color === cat2.color)
    }



val cat1 = Cat("Garfield",        38, "orange and black")
// cat1: Cat = Cat("Garfield", 38, "orange and black")
val cat2 = Cat("Heathcliff", 32, "orange and black")
// cat2: Cat = Cat("Heathcliff", 32, "orange and black")

cat1 === cat2
// res15: Boolean = false
cat1 =!= cat2
// res16: Boolean = true


optionCat1 === optionCat2
// res17: Boolean = false
optionCat1 =!= optionCat2
// res18: Boolean = true






///Quick PBT Example 
import org.scalacheck._
import org.scalacheck.Prop._

val stringLengthProp = forAll { (_: String).length >= 0 }
//stringLength: org.scalacheck.Prop = Prop

stringLengthProp.check
//+ OK, passed 100 tests.


//more test 
val propReverseList = forAll { l: List[String] => l.reverse.reverse == l }

val propConcatString = forAll { (s1: String, s2: String) =>
  (s1 + s2).endsWith(s2)
}

propReverseList.check
propConcatString.check

///Properties Classification- Conditional Properties using ==>:
Now ScalaCheck will only care for the cases when n is not negative. 
We also filter out large numbers, since we donot want to generate huge lists.

val propMakeList = forAll { n: Int =>
  (n >= 0 && n < 10000) ==> (List.fill(n)("").length == n)
}
propMakeList.check


///Types of properties-Commutativity
If order operands do not matter, we say that the operation is commutative. 

scala> forAll((a: Int, b: Int) => a + b == b + a).check
+ OK, passed 100 tests.

scala> forAll((a: Int, b: Int) => a * b == b * a).check
+ OK, passed 100 tests.

For strings, the addition is defined as a concatenation but is not commutative in general:
    
scala> forAll((a: String, b: String) => a + b == b + a).check
! Falsified after 1 passed tests.
> ARG_0: "\u0001"
> ARG_0_ORIGINAL
> ARG_1: "\u0000"
> ARG_1_ORIGINAL:
(we would understand above meaning later)

If at least one of the strings is empty, the property becomes commutative 

scala> forAll((a: String) => a + "" == "" + a).check
+ OK, passed 100 tests.

///HandsON 
Check Associativity of three integers 
What about Strings?

///Types of properties-Identity 
scala> forAll((a: Int) => a + 0 == a && 0 + a == a).check
+ OK, passed 100 tests.

scala> forAll((a: Int) => a * 1 == a && 1 * a == a).check
+ OK, passed 100 tests.

scala> forAll((a: String) => a + "" == a && "" + a == a).check
+ OK, passed 100 tests.


///Types of properties-Induction -- ADVANCED 
Inductive properties reflect those of their operand(s). 
They are usually formulated for the inductive case.

For example, the factorial function for any argument should obey the factorial definition:

def factorial(n: Long): Long = if (n < 2) n else n * factorial(n-1)

scala> forAll((a: Long) => 
                    a > 2 ==> (factorial(a) == a * factorial(a - 1))).check
+ OK, passed 100 tests.
(Might fail because of Stack overflow for large n) 

import org.scalacheck.Gen
forAll(Gen.choose(0L,20L))((a: Long) => a > 2 ==> (factorial(a) == a * factorial(a - 1))).check


///Combining properties 
Note 
the == compares two values:T and returns a Boolean, 
which is then implicitly converted to the Prop

the =? or ?= is a method from Prop which compares two values:T and returns Prop
Use this method always 
(difference between =? and ?= are reporting (reports RHS or LHS fails) , check reference. Prop$)

A property can also be labelled(eg "Commutativity"), 
which makes it easier to spot in the results

Note |: from Prop class , used for combining and | should be towards label string 

Check all the methods 
//https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Prop$.html

//Check how it fails , by making != 
forAll { (a: Int, b: Int, c: Int, d: String) =>
  val multiplicationLaws = all(
    "Commutativity" |: (a * b ?= b * a),
    "Associativity" |: ((a * b) * c == a * (b * c)),
    "Identity" |: all(a * 1 == a, 1 * a == a)
  ) :| "Multiplication laws"

   val stringProps = atLeastOne(d.isEmpty, d.nonEmpty)
   all(multiplicationLaws, stringProps)
 }.check()

    + OK, passed 100 tests.

//Details 
val p1 = forAll(...)   //one Prop

val p2 = forAll(...)   // another Prop 

val p3 = p1 && p2       //p3 will hold if and only if both p1 and p2 hold

val p4 = p1 || p2       //p4 will hold if either p1 or p2 holds

val p5 = p1 == p2       //p5 will hold if p1 holds exactly when p2 holds and vice versa

val p6 = all(p1, p2)   // same as p1 && p2

val p7 = atLeastOne(p1, p2) // same as p1 || p2



///Grouping properties  -- ADVANCED 
import org.scalacheck._

object StringSpecification extends Properties("String") {
  import Prop.forAll

  //single property 
  //property(name: String)
  property("startsWith") = forAll { (a: String, b: String) =>
    (a+b).startsWith(a)
  }

  property("endsWith") = forAll { (a: String, b: String) =>
    (a+b).endsWith(b)
  }

  property("substring") = forAll { (a: String, b: String) =>
    (a+b).substring(a.length) == b
  }

  property("substring") = forAll { (a: String, b: String, c: String) =>
    (a+b+c).substring(a.length, a.length+b.length) == b
  }
}
scala > StringSpecification.check()

///Collecting Generated Test Data 
It is possible to collect statistics about what kind of test data 
that has been generated during property evaluation. 

def Prop.classify(c: => Boolean, ifTrue: Any, ifFalse: Any)(prop: Prop): Prop
def Prop.classify(c: => Boolean, ifTrue: Any)(prop: Prop): Prop
    Use Prop.classify to collect interesting information on the generated data. 
def Prop.collect[T](t: T)(prop: Prop): Prop
    Collect data for presentation in test report

//example 
import org.scalacheck.Prop._

//name must not be ordered 
def ordered_(l: List[Int]) = l == l.sorted

val myProp = forAll { l: List[Int] =>
  classify(ordered_(l), "ordered") {
    classify(l.length > 5, "large", "small") {
      l.reverse.reverse == l
    }
  }
}

scala> myProp.check
+ OK, passed 100 tests.
> Collected test data:
78% large
16% small, ordered
6% small

//We can also collect data directly, using the Prop.collect method. 
//As we can see, the frequency for each number is around 10%, which seems reasonable.

val dummyProp = forAll(Gen.choose(1,10)) { n =>
  collect(n) {
    n == n
  }
}

scala> dummyProp.check
+ OK, passed 100 tests.
> Collected test data:
13% 7
13% 5
12% 1
12% 6
11% 2
9% 9
9% 3
8% 10
7% 8
6% 4


///Gen vs Arbitrary - where the input data for these properties comes from 
Note there are two version of forAll , 
note P boolean can be implicitely converted to Prop 

Prop.forAll[T1, P](g1: Gen[T1])(f: (T1) => P)(implicit p: (P) => Prop,..):Prop 
Prop.forAll[A1, P](f: (A1) => P)(implicit p: (P) => Prop, a1: Arbitrary[A1],...):Prop

first version , forAll takes Gen[T], Gen[T] produces values/testdata  for Props
For each type (builtin or customized), Gen[T] must be available and be passed to forAll 

However, 2nd version of forAll takes implicit Arbitrary 
which has .arbitrary member to give Gen[T]

sealed abstract class Arbitrary[T] {
  val arbitrary: Gen[T]
}

There are many implicit Arbitrary available (eg Int, String...)
so for those type, explicit Gen[T] need not to be passed, use 2nd version of forAll
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Arbitrary$.html

//Existing generators
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen$.html
Check detail in above link 

All subtypes of AnyVal, Unit, Function0, chars and strings with different contents
(alphaChar, alphaLowerChar, alphaNumChar, alphaStr, alphaUpperChar, numChar,
numStr), containers, lists and maps (containerOf, containerOf1, containerOfN,
nonEmptyContainerOf, listOf, listOf1, listOfN, nonEmptyListOf, mapOf, mapOfN,
nonEmptyMap), numbers (chooseNum, negNum, posNum), duration, Calendar, BitSet, and
even Test.Parameters




///builtin Gen  and Custome Gen for data generator 
//Existing generators
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen$.html

//Example 
val genBool: Gen[Boolean] = Gen.oneOf(true,false)

//OR The same boolean generator is defined in Arbitrary as an implicit declaration 
val genBool: Gen[Boolean] = Arbitrary.arbitrary[Boolean]

//his is a boolean generator, but one that always produces true:
val genBool = Gen.const(true)

//This is a generator of booleans that is true at a 2-to-1 ratio:
val genBool = Gen.frequency(2 -> true, 1 -> false)

//Below frequency is uniform 
val vowel = Gen.oneOf('A', 'E', 'I', 'O', 'U', 'Y')
//To check 
forAll(vowel) { char =>
      Prop.collect(char)(true)
      }.check
//Only one sample 
vowel.sample.get       
      
//to have uneven distribution 
val vowel = Gen.frequency(
  (3, 'A'),
  (4, 'E'),
  (2, 'I'),
  (3, 'O'),
  (1, 'U'),
  (1, 'Y')
)

//This is a boolean generator that will produce true 75% of the time:
val genBool = Gen.prob(0.75)

//This is an example of a custom generator for integers:
val genSmallInt: Gen[Int] = Gen.choose(-100,100)

val genListOfInts: Gen[List[Int]] = Gen.listOf(genSmallInt)

val genSeqOfInts: Gen[Seq[Int]] = Gen.someOf(-100 to 100)

val genVectorOfInts: Gen[Vector[Int]] = Gen.containerOf[Vector,Int](genSmallInt)

val genMap: Gen[Map[Int,Boolean]] = Gen.mapOf(Gen.zip(genSmallInt, genBool))

val genOptionalInt: Gen[Option[Int]] = Gen.option(genSmallInt)

//Or collections of one or more small integers:
val genListOfInts: Gen[List[Int]] = Gen.nonEmptyListOf(genSmallInt)

val genSeqOfInts: Gen[Seq[Int]] = Gen.atLeastOne(-100 to 100)

val genVectorOfInts: Gen[Vector[Int]] = Gen.nonEmptyContainerOf[Vector,Int](genSmallInt)

val genMap: Gen[Map[Int,Boolean]] = Gen.nonEmptyMap(Gen.zip(genSmallInt, genBool))

val genOptionalInt: Gen[Option[Int]] = Gen.some(genSmallInt)

//For custom class, one can write Gen[T] 
//Gen offers map and flatMap methods to create a generator for a case class.
import org.scalacheck._
import org.scalacheck.Prop._

case class Person(firstName:String, lastName:String, age:Int)

val genPerson = for {
  firstName <- Gen.oneOf("Alan", "Ada", "Alonzo")
  lastName <- Gen.oneOf("Lovelace", "Turing", "Church")
  age <- Gen.choose(0,100) if (age >= 18)
} yield Person(firstName, lastName, age)

val myProp = Prop.forAll(genPerson) { (myClass: Person) =>
  println(myClass)
  List("Alan", "Ada", "Alonzo").contains(myClass.firstName) //Boolean is implicitly converted to Prop 
}
myProp.check()

//one value 
genPerson.sample.get
//Person = Person(Alan,Lovelace,73)


///Arbitrary type class for data generator 
Either use explicit Gen[T] or use implicit Arbitrary[T] for forALL 

abstract class Arbitrary[T] {
  val arbitrary: Gen[T]
}

Check 
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Arbitrary$.html
Has many default implicits eg arbInt, arbBigDecimal, arbString etc 

class Arbitrary also has many instance methods eg suchThat 
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Arbitrary.html

//Example 
import org.scalacheck._
import org.scalacheck.Prop._

val evenInteger:Gen[Int] = Arbitrary.arbitrary[Int] suchThat (_ % 2 == 0)

val squares = for {
  xs <- Arbitrary.arbitrary[List[Int]]
} yield xs.map(x => x*x)

//Example of Earlier custom class 
implicit val arbMyClass: Arbitrary[Person] = Arbitrary(genPerson)

val myProp2 = Prop.forAll { (myClass: Person) =>
  println(myClass)
  List("Alan", "Ada", "Alonzo").contains(myClass.firstName) //Boolean can be implicitly converted to Prop 
}
myProp2.check()

///More examples of Gen and Arbitrary   -- ADVANCED 

//Example 
sealed abstract class Tree
case class Node(left: Tree, right: Tree, v: Int) extends Tree
case object Leaf extends Tree

import org.scalacheck._
import org.scalacheck.Prop._

//:paste
def genLeaf = Gen.const(Leaf)
def genTree: Gen[Tree] = Gen.oneOf(genLeaf, Gen.lzy(genNode))  //Lazy is must as it is recursive 
def genNode = for {
  v <- Arbitrary.arbitrary[Int]
  left <- genTree
  right <- genTree
} yield Node(left, right, v)


genTree.sample
//Option[Tree] = Some(Node(Leaf,Node(Node(Node(Node(Node(Node(Leaf,Leaf,-71),Node(Leaf,Leaf,-49),17),Leaf,-20),Leaf,-7),Node(Node(Leaf,Leaf,26),Leaf,-3),49),Leaf,84),-29))

//More Example for custom class 
abstract class Tree[T] {
  def merge(t: Tree[T]) = Internal(List(this, t))

  def size: Int = this match {
    case Leaf(_) => 1
    case Internal(children) => (children :\ 0) (_.size + _)  //:\ is foldLeft 
  }
}
case class Internal[T](children: Seq[Tree[T]]) extends Tree[T]
case class Leaf[T](elem: T) extends Tree[T]

implicit def arbTree[T](implicit a: Arbitrary[T]): Arbitrary[Tree[T]] =Arbitrary {
  val genLeaf = for(e <- Arbitrary.arbitrary[T]) yield Leaf(e)

  def genInternal(sz: Int): Gen[Tree[T]] = for {
    n <- Gen.choose(sz/3, sz/2)
    c <- Gen.listOfN(n, sizedTree(sz/2))
  } yield Internal(c)

  def sizedTree(sz: Int) =
    if(sz <= 0) genLeaf
    else Gen.frequency((1, genLeaf), (3, genInternal(sz)))

  Gen.sized(sz => sizedTree(sz))
}

val propMergeTree = forAll( (t1: Tree[Int], t2: Tree[Int]) =>
  t1.size + t2.size == t1.merge(t2).size

//More Complex Examples of combining generators 
Gen offers map and flatMap methods to create a generator for a case class.

//Example of deck of cards 
sealed trait Rank

case class SymRank(s: Char) extends Rank {
 override def toString: String = s.toString
}

case class NumRank(n: Int) extends Rank {
 override def toString: String = n.toString
}

case class Card(suit: Char, rank: Rank) {
 override def toString: String = s"$suit $rank"
}

"""
https://javadoc.io/doc/org.scalacheck/scalacheck_2.13/latest/org/scalacheck/Gen$.html

def choose[T](min: T, max: T)(implicit c: Choose[T]): Gen[T]
    A generator that generates a random value in the given (inclusive) range.
def oneOf[T](g0: Gen[T], g1: Gen[T], gn: Gen[T]*): Gen[T]
    Picks a random generator from a list
def frequency[T](gs: (Int, Gen[T])*): Gen[T]
    Chooses one of the given generators with a weighted random distribution
def listOfN[T](n: Int, g: Gen[T]): Gen[List[T]]
    Generates a list with at most the given number of elements.
def containerOfN[C[_], T](n: Int, g: Gen[T])(implicit evb: Buildable[T, C[T]], evt: (C[T]) => Traversable[T]): Gen[C[T]]
    A convenience method for calling buildableOfN[C[T],T](n,g).
"""

val suits = Gen.oneOf('H', 'S', 'D', 'C')
val numbers = Gen.choose(2, 10).map(NumRank)
val symbols = Gen.oneOf('A', 'K', 'Q', 'J').map(SymRank)

//full deck 
val full: Gen[Card] = for {
 suit <- suits
 rank <- Gen.frequency((9, numbers), (4, symbols))
} yield Card(suit, rank)

full.sample.get 

//All check 
//forAll[T1, P](g1: Gen[T1])(f: (T1) => P)
forAll(full) { card =>
      Prop.collect(card)(true)  //collect for  test data collection 
}.check

//Or use implicit Arbitrary, then we dont have to pass Gen[Card] argument 
implicit lazy val arbBool: Arbitrary[Card] = Arbitrary(full)

forAll { (card:Card) =>
      Prop.collect(card)(true)
}.check

//More Example of Custom Generators
It is easy to change this generator to only make cards for a pique pack by using the
suchThat combinator:( https://en.wikipedia.org/wiki/Piquet)

Piquet is played with a 32-card pack, normally referred to as a piquet pack 
or piquet deck. 
The pack comprises the 7s through to 10s, the face cards, and the aces in each suit, 
and can be created by removing all 2–6 values from a 52-card poker pack

//def suchThat(f: (T) => Boolean): Gen[T]
//Create a new generator that uses this generator to produce a value that fulfills the given condition.

val piquet: Gen[Card] = full.suchThat {
 case Card(_, _: SymRank) => true
 case Card(_, NumRank(n)) => n > 6
}

//def collect[T](t: T)(prop: Prop): Prop
//Collect data for presentation in test report

forAll(piquet) { card =>
      Prop.collect(card)(true)
}.check
+ OK, passed 100 tests.
> Collected test data:
8%  J
6%  7
6%  10
... (couple of lines more)

//Then generate a handfull of cards from the deck 
val handOfCards: Gen[List[Card]] = Gen.listOfN(6, piquet) //pick 6 cards 

forAll(handOfCards) { (hand: Seq[Card]) =>
      Prop.collect(hand.mkString(","))(true)
}.check
! Gave up after only 58 passed tests. 501 tests were discarded.
> Collected test data:
2%  8, 10, 8, 7, Q, 8

//But we have duplicate cards in one hand of 6 cards 
//To Remove, use Set 

val handOfCards = Gen.containerOfN[Set, Card](6, piquet)

scala> forAll(handOfCards) { hand =>
      Prop.collect(hand.mkString(","))(true)
      }.check
! Gave up after only 75 passed tests. 501 tests were discarded.
> Collected test data:
1%  A, J, K, 6, K, A
1%  9, A, 8, 9

//But a lot of tests(eg 501 in above) are discarded to fulfil 'suchThat' condition
//hence not performant , To solve, choose pique cards from the begining 

val piquetNumbers = Gen.choose(7, 10).map(NumRank)

val piquet: Gen[Card] = for {
  suit <- suits
  rank <- Gen.frequency((5, piquetNumbers), (4, symbols))  //5:4 times 
} yield Card(suit, rank)

//Then repeatedly generate the set of cards 
//until it has an expected size using retryUntil combinator:

val handOfCards = Gen.containerOfN[Set, Card](6, piquet).retryUntil(_.size == 6)

scala> forAll(handOfCards) { hand =>
      Prop.collect(hand.mkString(","))(true)
      }.check
+ OK, passed 100 tests.
> Collected test data:
1%  9, 9, 9, Q, J, 10
...


///Sized Generators --ADVANCED  
When ScalaCheck uses a generator to generate a value, it feeds it with size value, 

If you want to use the size parameter in your own generator, 
you can use the Gen.sized method:

//Example 
def matrix[T](g: Gen[T]): Gen[Seq[Seq[T]]] = Gen.sized { size =>
  val side = scala.math.sqrt(size).asInstanceOf[Int]
  Gen.listOfN(side, Gen.listOfN(side, g))
}





///Shrinkers  -- ADVANCED 
One interesting feature of ScalaCheck is that if it finds an argument 
that falsifies a property, 
it tries to minimise that argument before it is reported. 

This is done automatically when you use Prop.forAll methods to create properties, 
but not if you use Prop.forAllNoShrink. 

In PBT, the test data comes from Gen[T]  and it is kind of random. 
Given this fact, we could expect that it might be hard to find out 
why a test is failing. 

//example 
forAllNoShrink { (num: Int) =>
      num < 42
      }.check()
//output 
! Falsified after 0 passed tests.
> ARG_0: 2008612603

Here, we can see that our property was falsified by the number 2008612603 
which is not < 42 

Compare this with Shrink where number 67 is > 42 and easily recongnizable to be > 42

forAll { (num: Int) =>
    num < 42
    }.check()
! Falsified after 0 passed tests.
> ARG_0: 67
> ARG_0_ORIGINAL: 1128316729


It is more or less obvious for an Int, but consider a case with a
list of many elements and a property formulated for these elements:

// def listOfN[T](n: Int, g: Gen[T]): Gen[List[T]], where List[T].size == n 
//Use Gen.alphaStr if we want to get alphanumeric str 
forAllNoShrink(Gen.listOfN(1000, Gen.asciiStr)) {
            _.forall(x => x.length < 10)
     }.check()
//output 
! Falsified after 10 passed tests.
> ARG_0: List

... // a lot of similar lines

Obviously, it is near to impossible to find out which of 1,000 strings 
had a wrong length in this test.

Use  Shrink. 
The job of the shrinker is to find a minimal test data 
with which the property does not hold. 

//example 
scala> forAll(Gen.listOfN(1000, Gen.asciiStr)) {
            _.forall(_.length < 10)
      }.check()
//output 
! Falsified after 10 passed tests.
> ARG_0: List("")
> ARG_0_ORIGINAL: // a long list as before

Here, we can see that the minimal list, which falsifies our property, 
is the list with one empty string. 
The original failing input is shown as ARG_0_ORIGINAL and it is of a similar
length and complexity as we have seen before.

The Shrink instances are passed as implicit parameters, 
so we can summon one to see how they work. 

forAllNoShrink { (num: Int) =>
      num < 42
      }.check()
//output 
! Falsified after 0 passed tests.
> ARG_0: 534044208

val intShrink: Shrink[Int] = implicitly[Shrink[Int]]

intShrink.shrink(534044208).toList
//output 
val res16: List[Int] = List(267022104, -267022104, 133511052, -133511052, 6675
5526, -66755526, 33377763, -33377763, 16688881, -16688881, 8344440, -8344440,
4172220, -4172220, 2086110, -2086110, 1043055, -1043055, 521527, -521527, 2607
63, -260763, 130381, -130381, 65190, -65190, 32595, -32595, 16297, -16297, 814
8, -8148, 4074, -4074, 2037, -2037, 1018, -1018, 509, -509, 254, -254, 127, -1
27, 63, -63, 31, -31, 15, -15, 7, -7, 3, -3, 1, -1, 0)

The shrink method generates a stream of values --the values produced 
by the Shrink lie symmetrically to the central value of 0 (zero), 
starting from the initial failing value, and then are each time
divided by two until they converge to the zero. 

It is easy to see that numbers produced by the Shrink will depend 
on the initial failing argument, in ourcase 2008612603. 
This is why for the first property the returned value will differ each time:

forAll { (_: Int) < 42 }.check()
//output 
! Falsified after 1 passed tests.
> ARG_0: 83
> ARG_0_ORIGINAL: 1394573331

intShrink.shrink(1394573331).toList //which contains 83 
//output 
val res17: List[Int] = List(697286665, -697286665, 348643332, -348643332, 1743
21666, -174321666, 87160833, -87160833, 43580416, -43580416, 21790208, -217902
08, 10895104, -10895104, 5447552, -5447552, 2723776, -2723776, 1361888, -13618
88, 680944, -680944, 340472, -340472, 170236, -170236, 85118, -85118, 42559, -
42559, 21279, -21279, 10639, -10639, 5319, -5319, 2659, -2659, 1329, -1329, 66
4, -664, 332, -332, 166, -166, 83, -83, 41, -41, 20, -20, 10, -10, 5, -5, 2, -
2, 1, -1, 0)

scala> forAll { (_: Int) < 42 }.check()
! Falsified after 0 passed tests.
> ARG_0: 54
> ARG_0_ORIGINAL: 908148321

scala> forAll { (_: Int) < 42 }.check
! Falsified after 2 passed tests.
> ARG_0: 57
> ARG_0_ORIGINAL: 969910515

scala> forAll { (_: Int) < 42 }.check
! Falsified after 6 passed tests.
> ARG_0: 44
> ARG_0_ORIGINAL: 745869268


///CoGen - for Function Generation  -- ADVANCED 
https://github.com/typelevel/scalacheck/blob/master/src/main/scala/org/scalacheck/Cogen.scala

Cogen[T] is used for random function generation of T => Output 
where Output type has Arbitrary[Output], hence Fn produces random output 

//Example , from String to Int 
import org.scalacheck._

val arb = implicitly[Arbitrary[String => Int]].arbitrary.sample.get

println(arb("a"))
println(arb("a")) // same output as above 
println(arb("b"))

because there is an implicit Cogen[String] and an Arbitrary[Int]

It is possible to generate arbitrary function from a random case class 
It should be enough to define a Cogen[File]. Either manually:

//example 
import org.scalacheck._
import org.scalacheck.Prop._

case class File(name: String, size:Long)
import rng.Seed
implicit val cogenFile: Cogen[File] = Cogen { 
  (seed: Seed, file: File) => Cogen.perturbPair(seed, (file.name, file.size))
}

//Slightly more code, but generalizes to more than 2 fields:
implicit val cogenFile: Cogen[File] = Cogen { (seed: Seed, file: File) => 
  val seed1 = Cogen.perturb(seed, file.name)
  Cogen.perturb(seed1, file.size)
}

val arb2 = implicitly[Arbitrary[File => Int]].arbitrary.sample.get
println(arb2(File("abc", 23)))

