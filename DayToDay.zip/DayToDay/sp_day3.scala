//option
case class Request1 (){
    import scala.util.Random
    val r = new Random 
    def _get = if (r.nextInt(10) < 5) "Hello" else null 
    def get = Option(_get)
}
val ls = (0 to 10).toList.map(i => 
            new Request1().get) //List[Option[String]]
//None, Some(Hello)
ls.map{ o => o.map(_.size)}
ls.flatMap{o => o.map(_.size)}
ls.collect{case Some(x) => x.size}

val ls2 = (0 to 10).toList.map(i => 
            new Request1()._get)
//can you give me size of each element 
ls2.map{o => if (o == null) 0 else o.size}

val o = new Request1().get
o.map{_.trim}.
  map{_.toUpperCase}.
  map{_.size}.getOrElse(0)
//res5: Option[Int] = Some(5)

val o = new Request1().get
o.map{_.size}  //res6: Option[Int] = None



//try
import scala.util._ 
class Request2{
    import scala.util.Random
    val r = new Random 
    def _get = if (r.nextInt(10) < 5) 42 else 0 
    def get = Try{42/_get}
}
val ls = (0 to 10).toList.map(i => 
            (new Request2).get) 
//Success(value) or Failure(ex)
ls.map{ o => o.map(i => i*i )}
ls.collect{case Success(x) => x}
ls.collect{case Success(x) => x
           case Failure(ex) => 
                println(ex)
                0
           }
//
val o = new Request2().get
o.map{o=> o*o}.toOption
//
try{ 
    1/0 
    } catch {
        case ex:Exception => println(ex)
    }

//Streams 
def fib(a:BigInt, b:BigInt):Stream[BigInt] = 
    a #:: fib(b, a+b) 
    
lazy val fib2:Stream[BigInt] = 
    BigInt(0) #:: BigInt(1) #::
        fib2.zip(fib2.tail).map{ case (a,b) => a+b}
        
fib(0,1).take(10).toList 
fib(0,1).drop(10).take(10).toList 
fib2.drop(10).take(10).toList 



//zip,zipWithIndex
scala> val ls = List("abc", "a", "d")
ls: List[String] = List(abc, a, d)

scala> val ls2 = List(20, 30,40)
ls2: List[Int] = List(20, 30, 40)

scala> ls.zip(ls2).foreach(println)
(abc,20)
(a,30)
(d,40)

scala> ls.zip(ls2)
res21: List[(String, Int)] = List((abc,20), (a,30), (d,40))

scala> ls.zip(ls.tail)
res22: List[(String, String)] = List((abc,a), (a,d))

scala> ls.zipWithIndex
res23: List[(String, Int)] = List((abc,0), (a,1), (d,2))

scala> ls.tail
res24: List[String] = List(a, d)

scala> ls.zip(ls2).toMap
res25: scala.collection.immutable.Map[String,Int] = Map(abc -> 20, a -> 30, d -> 40)

//par, seq

scala> (0 to 10).foreach(println)
scala> (0 to 10).par.foreach(println)
scala> (0 to 10).par.map(2 * _).seq.foreach(println)
scala> (0 to 10).toList
res37: List[Int] = List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

scala> (0 to 10).view.filter(_ % 2 ==0).map(2 * _)
res38: scala.collection.SeqView[Int,Seq[_]] = SeqViewFM(...)

scala> (0 to 10).view.filter(_ % 2 ==0).map(2 * _).force
res39: Seq[Int] = Vector(0, 4, 8, 12, 16, 20)

//Trait 
trait A{
    def m = "from A"
    def m2:String 
}

abstract class B extends A {
    override def m = "from B"

}
class C extends B with A {
    def a = super.m 
    def b = super[A].m 
    def m2 = "concrete"
}

scala> val a = new C
a: C = C@38f336c2

scala> a.a
res3: String = from B

scala> a.b
res4: String = from A

scala> a.m2
res5: String = concrete

scala> a.m
res6: String = from B

scala> scala.reflect.runtime.universe.typeOf[C].baseClasses
res7: List[reflect.runtime.universe.Symbol] = List(class C, class B, trait A, class Object, class Any)


class E 
val e = new E with A { def m2 = "String"}

//PECS - varince 

scala> val a:Array[Any] = Array[Int](1,2,3)
<console>:11: error: type mismatch;
 found   : Array[Int]
 required: Array[Any]
Note: Int <: Any, but class Array is invariant in type T.
You may wish to investigate a wildcard type such as `_ <: Any`. (SLS 3.2.10)
       val a:Array[Any] = Array[Int](1,2,3)
                                    ^

scala> val a:List[Any] = List[Int](1,2,3)
a: List[Any] = List(1, 2, 3)

class A[+T]  //covariant 
class B[-T]  //contra-variant 
class C[T]   //invariant 

val a:A[Any] = new A[Int] //OK 
val b:B[Int] = new B[Any] //ok 
val c:C[Int] = new C[Int] //Ok 

//always possible 
class AA[+T] extends A[T] 
val aa:A[Int] = new AA[Int] 

//bounds 
class A[U] {
    def meth[T <: Int](x:T) = x * x
}

class A[T <: AnyVal] 
val a = new A[Int] //OK 
val b = new A[String] //NOK 
class A[T >: AnyVal] 
val a = new A[Any] //OK 

class A[T >:AnyVal <: Any] 
val a = new A[Any] 


def s[T](x:List[T])=x.size 

scala> def s[T](x:List[T])=x.size
s: [T](x: List[T])Int

scala> def s[T](x:List[T])=x.sum
<console>:11: error: could not find implicit value for parameter num: Numeric[T]
       def s[T](x:List[T])=x.sum
                             ^

scala> def s(x:List[_])=x.sum
<console>:11: error: could not find implicit value for parameter num: Numeric[Any]
       def s(x:List[_])=x.sum
                          ^

scala> def s(x:List[_])=x.size
s: (x: List[_])Int

scala> s(List(1,2,3))
res11: Int = 3


//excel 
import org.apache.poi.ss.usermodel._ 
import java.io.File 
import collection.JavaConversions._ 

val f = new File("../../data/Nifty-17_Years_Data-V1.xlsx")
val wb = WorkbookFactory.create(f)
val sh = wb.getSheetAt(0) 
//sheet contains rows, each row contains cell, ie row.getCell(index)
//each cell has .getDateCellValue, .getNumericCellValue
Q. Which year has  max diff in Open 

val lines = sh.drop(1).map{row => 
                (row.getCell(0).getDateCellValue, 
                 (1 to 6).map(row.getCell(_).getNumericCellValue).toList)}
//Iterable[(java.util.Date, List[Double])]
case class Data(Date:java.util.Date,
        Open:Double, 
        High:Double , 
        Low:Double, 
        Close:Double, 
        `Day Wise Variation ( points)`: Double, 
         `Day Wise Variation ( %)   Open to Close`:Double){
    def year = Date.getYear + 1900 
}         
val rows = lines.map{case (a, List(b,c,d,e,f,g)) => (a,b,c,d,e,f,g)}.
                 map{ t => (Data.apply _).tupled(t)}
//Iterable[Data]
rows.groupBy(_.year).map{case(y,lst) =>
                    (y, lst.map(_.Open).max - lst.map(_.Open).min)}.
                    maxBy{case (y,d) => d }
                    
                    
//json 
import play.api.libs.json._ 
import java.io._ 

val in = new FileInputStream("../../data/example.json")
val json = Json.parse(in)
in.close() 

(json \ 0 \ "empId").as[Int]  // 1

val jarr = json.as[JsArray]
jarr.value.  //IndexedSeq[play.api.libs.json.JsValue]
     map(_.as[JsObject]).map{ o =>
            (o \ "empId").as[Int]}


//future 
import scala.concurrent._ 
import scala.concurrent.duration._ 
import scala.concurrent.ExecutionContext.Implicits.global 
val fut = Future{
    Thread.sleep(100)
    "Hello"
}
val fut2 = fut.map(_.toUpperCase).filter(e => e.size > 2).map(_.size)

val re = Await.result(fut2, Duration.Inf) 
//OR 
fut2.foreach(println)
//OR 
fut2.onSuccess{case x:Int => println(x)}
//OR 
import scala.util._ 
fut2.onComplete{
    case Success(x) => println(x)
    case Failure(ex) => println(ex)
}
val fut3 = for {
        a <- Future{ 2*2 }
        b <- Future{ "hello"}.mapTo[String]
        c <- Future { a-1 } 
} yield{
    a * b.size * c
}
val re = Await.result(fut3, Duration.Inf) 

//A

import akka.actor._ 
import akka.event.Logging
import scala.util._ 

case class Result(x:Int)
class MyActor(val a:Option[ActorRef]=None) extends Actor with ActorLogging{
    val own = self.path.toString 
    def receive = {
        case "test" => 
                        log.info(s"$own : handling test")
                        sender() ! "Test result 0"
                        a.map{ ac => ac ! "Test result 0"}
        case "stop" =>
                        context.stop(self)
                        
        case Result(x) =>
                        val z = x*x 
                        a.map{ ac => ac ! Result(z)}
                        log.info(s"$own : handling Result($x)")
                        
        case x =>   log.info(s"$own : could not handle $x")
        }
}

val system = ActorSystem("mysystem")
val aref1 = system.actorOf(Props(new MyActor), "test-actor")
aref1 ! "test"
val aref2 = system.actorOf(Props(new MyActor(Some(aref1))), "test-actor2")
aref2 ! "test"
aref2 ! Result(10)

system.terminate 

import akka.util._ 
import scala.concurrent.duration._ 
import scala.concurrent._ 
import akka.pattern._ 

//import system.dispatcher 
implicit val timeout = Timeout(1.second)
(aref1 ? "test").mapTo[String].foreach(println) 
//(aref1 ? Result(10)).mapTo[Result].foreach(x => println(x.x)) 
val fut = (aref1 ? "test").mapTo[String]

val re = Await.result(fut2, Duration.Inf) 




scala> class A[T]
defined class A

scala> def meth[T](x:T)(implicit ev:A[T]) = ???
meth: [T](x: T)(implicit ev: A[T])Nothing

scala> meth(2)(new A[Int])
scala.NotImplementedError: an implementation is missing
  at scala.Predef$.$qmark$qmark$qmark(Predef.scala:230)
  at .meth(<console>:46)
  ... 40 elided

scala> imlplicit val x = new A[Int]
<console>:1: error: ';' expected but 'val' found.
imlplicit val x = new A[Int]
          ^

scala> implicit val x = new A[Int]
x: A[Int] = A@6db508fd

scala> meth(2)
scala.NotImplementedError: an implementation is missing
  at scala.Predef$.$qmark$qmark$qmark(Predef.scala:230)
  at .meth(<console>:46)
  ... 40 elided

scala> meth(2)(new A[Int])
scala.NotImplementedError: an implementation is missing
  at scala.Predef$.$qmark$qmark$qmark(Predef.scala:230)
  at .meth(<console>:46)
  ... 40 elided

scala> implicit val y = new A[Int]
y: A[Int] = A@9333ce9

scala> meth(2)
<console>:49: error: ambiguous implicit values:
 both value x of type => A[Int]
 and value y of type => A[Int]
 match expected type A[Int]
       meth(2)
           ^

scala> "11".toInt
res21: Int = 11

scala> "AB".toInt(16)
<console>:48: error: Int does not take parameters
       "AB".toInt(16)
                 ^
             ^
scala> Integer.valueOf("AB",16)
res23: Integer = 171

scala> implicit class D(x:String){
     |     def toInt(rd:Int) = Integer.valueOf(x,rd)
     | }
defined class D

scala> "AB".toInt(16)
res24: Integer = 171


def meth[T](x:List[T]) = x.size 

def meth[T](x:List[T])(implicit ev:Numeric[T]) = {
    import ev._ 
    x.sum 
} 
              
def meth[T](x:T)(implicit ev:Numeric[T]):T = {import ev._;x*x }
    









