object Twice{
    def apply(x:Int) = x*2 
    def unapply(x:Int):Option[Int] = Some(x/2)
}

val x = Twice(2) //apply
val Twice(z) = 22 //unapply

case class Person(first:String, sec:String)
case object Request
def extract(o:Any) = o match {
    case 0 | 1 | 2 => s"alternate"
    case Request => s"request"
    case Twice(z) => s"Twice $z"
    case List(1,_,_) => s"list with three, first 1"
    case a @ List(x, y @ _*) => s"list $x $y $a"
    case Person("X", s) => s"Person $s"
    case Person(x,y) => s"Person $x $y"
    case (x,y) if x == y => s"same tuple"
    case (x,y) => s"Tuple"
    case x:String => s"string"
    case x:Array[String] => s"array string"
    case _:Seq[_] => s"seq"
    case ( (x,y), (a,b), c) => s"nested"
    case _ => s"default"
}


//recursion 
def mysum(x:List[Int]):Int =
    if (x.isEmpty) 0 else x.head + mysum(x.tail)

def mysum2(x:List[Int]):Int = x match {
    case h :: t => h + mysum2(t)
    case Nil => 0
}

mysum(1 to 100 toList)  //5050
mysum2(1 to 100 toList)

mysum(1 to 20000 toList) //


def mysum3(x:List[Int]) = {
    def _sum(y:List[Int], acc:BigInt):BigInt = y match{
        case h :: t => 
                     println(s"$h $t $acc")
                    _sum(t, h+acc)
        case Nil => acc
    }
    i_sum(x,0)
}
mysum3(1 to 20000 toList)

///HandsOn 
// Write one TR function which can find max 
//inside List 


def max(x:List[Int]) = {
    def _inner(y:List[Int], acc:Int):Int = y match{
        case h :: t => _inner(t, if (acc > h) acc 
                                 else h)
        case Nil => acc
    }
    _inner(x,x.head)
}

///Functions 

def add(x:Int, y:Int) = x+y 
add(2,3) 
val fp = add _  //(Int, Int) => Int
                //Function2[-T1, -T2, +R]
fp(2,3) 
fp.apply(2,3)

val fp1 = (x:Int, y:Int) => x+y  //lambda function
fp1(0,1)

val fp22 = (x:Int) => (y:Int) => x+y//curry 
val fp23 = (x:Int) => (y:Int) => (z:Int) => x+y+z//curry 
//
Int => Int => Int => Int 
//Int => (Int => Int)
fp22(2)(3)
//
def f(x:Int) = {
    def g(y:Int) = x+y 
    g _
}
f(2)(3)
//
def f(x:Int)(y:Int) = x+y 
f _         //Int => (Int => Int)
val fp1 = (x:Int, y:Int) => x+y 
fp1(2,3)
fp22(2)(3)
fp1.curried(2)(3)   //Int => (Int => Int)
//higher order function 
type addType = (Int, Int) => Int
def fun(f:(Int, Int) => Int, x:Int) = f(x,x)

def fun(f:addType, x:Int) = f(x,x)

val fp1 = (x:Int, y:Int) => x+y  
fun(fp1, 20) //40 // 20 + 20 

def add(x:Int, y:Int) = x+y 
fun(add _ , 20)
//shortcut if it is not overloaded 
fun(add,20)

//partially appllied 
def add(x:Int, y:Int) = x+y 

def add2( y:Int) = add(2,y) 
val  add2 = (y:Int) => add(2,y)
//OR 
val add2 = add(2, _:Int)
add2(20) //22 

//tupled 
def add(x:Int, y:Int) = x+y 
 
val t = (1,2) 
add(t._1, t._2)
//OR 
(add _).tupled(t) 

//case class 
case class Two(x:Int, y:Int)
val t = (1,2) 
Two(t._1, t._2)
Two.apply(t._1, t._2)
//OR 
(Two.apply _).tupled(t) //Two 

//compose 
val dou = (x:Int) => x*2 
val al = (x:Int) => x+5 

al(dou(5)) //15
(dou andThen al)(5)

dou(al(5)) //20
(dou compose al)(5)


//PF 
val pf:PartialFunction[Int,Int] = {case x:Int if x != 0  => 42/x }

scala> pf(0)
scala.MatchError: 0 (of class java.lang.I
scala> pf(42)
res40: Int = 1

pf.isDefinedAt(0) // false 
pf.isDefinedAt(1) // true 
//orElse 
val pf1:PartialFunction[Int,Int] = {case x:Int if x == 0  => 0 }
(pf1 orElse pf)(0)  //handles 0 and x!=0
(pf1 orElse pf)(42)

//FP 
val ls = List(1,2,3)
val map = Map("OK"->1 , "NOK"->2)

//foreach ,  List[A].foreach(f: (A) => Unit): Unit 
//Applies a function f to all elements of this list.
ls.foreach( x => println(x))
ls.foreach( println(_))
ls.foreach(println)
ls foreach println

map.foreach{case (k,v) => 
            println(k)
            println(v)
        }
//
for { e <- ls } println(e)
for { (k,v)  <- map } println(k)

//map - List[A].map[B](f: (A) => B): List[B] 
ls.map( x => x*x)
//OR 
for { 
    x <- ls 
} yield {
    x*x 
}

map.map{case (x,y) => y*y}

val fn = (x:Int) => (y:Int) => x+y 
ls.map(fn) //List[Int => Int]
ls.map(fn).  //A = Int, B = Int => Int 
   map(f => f(2)) //A = Int => Int    B=Int 
//3,4,5 
ls.map(fn) 
1  => (1) => (y:Int) => x+y 
2 => (2) => (y:Int) => x+y 
3 => (3) => (y:Int) => x+y 
List ( (y:Int) => x+y , (y:Int) => x+y , (y:Int) => x+y ]
.map(f => f(2) )
(y:Int) => x+y      => (2) => 1+2 
(y:Int) => x+y      => (2) => 2+2 
(y:Int) => x+y      => (2) => 2+3 

//
val lsm = List( ("age", 2, 3), ("adnce", 5, 6))
//convert to  each first element size , List(3,5)
lsm.map( t => t._1.size)
lsm.map{case (x,y,z) => x.size}

//flatMap  List[A].flatMap[B](f: (A) => GenTraversableOnce[B]): List[B] 
ls.map ( x => List(x,x*x, x*x*x))
//List[List[Int]] = List(List(1, 1, 1), List(2, 4, 8), List(3, 9, 27))
ls.flatMap( x => List(x,x*x, x*x*x))
//List[Int] = List(1, 1, 1, 2, 4, 8, 3, 9, 27)
map.flatMap{case (x,y) => Map(x -> y*y)}
//Map[String,Int] = Map(OK -> 1, NOK -> 4)


//filter 
//def List[A].filter(p: (A) => Boolean): List[A] 
ls.filter(x => x%2 == 0) 
map.filter{case(k,v) => v%2 == 0}

//collect = filter+map 
//List[A].collect[B](pf: PartialFunction[A, B]): List[B] 
ls.collect{case x:Int if x > 0 => x*x}
map.collect{case (x,y) if y > 0 => (x -> y*y) }


//groupBy 
//List[A].groupBy[K](f: (A) => K): Map[K, List[A]] 
ls.groupBy( x => x%2 )
//Map[Int,List[Int]] = Map(1 -> List(1, 3), 0 -> List(2))
map.groupBy{case (k,v) => v%2}
//Map[String,Int]] = Map(1 -> Map(OK -> 1), 0 -> Map(NOK -> 2))

//zip 

List("a", "b", "c").zip(List(10,20,20)) 
//List[(String, Int)] = List((a,10), (b,20), (c,20))
List("a", "b", "c").zipWithIndex
//res64: List[(String, Int)] = List((a,0), (b,1), (c,2))



//iris.csv 
val filename = raw"D:\Desktop\PPT\scala\code\recent\jp-sp-sc\toBeShared\data\iris.csv"

val lines = scala.io.Source.fromFile(filename).getLines.toList 
//lines: List[String] = List(SepalLength,SepalWidth,PetalLength,PetalWidth,Name, 5.1,3.5,1.4
val lines2 = lines.drop(1).map(_.split(",")). //List[Array[String]]
              map{ arr =>
                (arr.slice(0,4).map(_.toDouble), arr.last)}.//List[(Array[Double], String)]
              map{ case (Array(a,b,c,d),e) => (a,b,c,d,e)} //List[(Double, Double, Double, Double, String)]
              
case class Row(sl:Double, sw:Double, pl:Double, pw:Double, name:String)
val rowcs = lines2. map( t => (Row.apply _).tupled(t))//List[Row]
//unique names 
val un = rowcs.map(_.name).toSet 
//Set(Iris-setosa, Iris-versicolor, Iris-virginica)

//get Max of sl for each name 
rowcs.groupBy(_.name). //Map[String,List[Row]]
      map{case (n,lst) => (n, lst.map(_.sl).max)}
//Map[String,Double] = Map(Iris-virginica -> 7.9, Iris-setosa -> 5.8, Iris-versicolor -> 7.0)
   
//get max and min of sl for each name 
rowcs.groupBy(_.name).
      map{case (n,lst) => 
        Map(n -> Map("max" -> lst.map(_.sl).max, "min" -> lst.map(_.sl).min ))
      }
//Map[String,Map[String,Double]]] = List(Map(Iris-virginica -> Map(max -> 7.9, min -> 4.9)), Map(Iris-setosa -> Map(max -> 5.8, min -> 4.3)), Map(Iris-versicolor -> Map(max -> 7.0, min -> 4.9)))

//jdbc 
Class.forName("org.sqlite.JDBC")
import java.sql.{Array =>SArray, _ }
case class Row(sl:Double, sw:Double, pl:Double, pw:Double, name:String){
    override def toString = s"""($sl,$sw, $pl, $pw, "$name")"""
    def toSql= s"insert into iris values ${this.toString}"
}
val rowcs = lines2. map( t => (Row.apply _).tupled(t))//List[Row]
var con = DriverManager.getConnection("jdbc:sqlite:iris.db")
var stmt = con.createStatement()
stmt.executeUpdate("drop table if exists iris")
stmt.executeUpdate("""create table iris(sl double, sw double,
        pl double, pw double, name varchar(20))""")
rowcs.map(_.toSql). //List[String]
      map(stmt.executeUpdate) ///<-  ***
val rs = stmt.executeQuery("select count(*) from iris")
while( rs.next()){
    println(s"${rs.getInt(1)}")
}

val rs = stmt.executeQuery("select name, max(sl) from iris group by name")
def it[T](rs:ResultSet)(f: ResultSet => T) = new Iterator[T]{
    def hasNext = rs.next()
    def next() = f(rs)
}
it(rs)(r => (r.getString(1), r.getDouble(2))).toList
con.close()



















