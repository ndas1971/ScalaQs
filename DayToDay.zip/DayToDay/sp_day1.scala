scala> val x = 0
x: Int = 0
scala> x = 2
<console>:12: error: reassignment
       x = 2
         ^

scala> var y = 0
y: Int = 0

scala> y = 20
y: Int = 20

scala> val x:Byte = 0
x: Byte = 0

scala> for (i <- 1 to 10) {
        val x = i*i 
        println(x)
 }
     
for { 
    i <- 1 to 10 if i%2 == 0
    j = i*i 
    j <- 1 to j if j % 2 == 1} {
        val k = j*i
        println(s"$i $j $k")
        }
     
for (i <- 1 to 10) println(i)
for (i <- 1 until 10) println(i)
for (i <- 1.0 to 10.0 by 2.0) println(i) //1.0.to(10.0).by(2.0)

//while 
var i = 0
while( i < 20 ) {
    println(i)
    i += 1 
   }

//Functions 
def meth[T](x:T):T = x 

def f(x:Int) = {
    def g(y:Int) = x+y
    g(x+100)
}
val res = f(20)

def printAll[T](ns:T*) {  //Seq[T]
    for ( i <- ns) println(i)
}
printAll()
printAll("foo", "bar")
val ns = List("a", "b")
printAll(ns(0), ns(1))
printAll(ns : _*)

def func = ("APPLE", 200)
val (symbol, price) = func
val result = func 

result._1 
result._2 

def make(timeout:Int = 500, protocol:String = "http") = (timeout, protocol)

make()
make(600)
make(protocol="https", timeout=600)

def doubleIf(test1: =>Boolean)(test2: =>Boolean)(code: =>Unit){
    if (test1 &&  test2)
        code 
}
val age = 20 
val count = 0 
doubleIf( age >= 18 )(count == 0){
    println("OK")
}

1 to 1000  sum

def time[R](code: =>R) = {
    val st = System.nanoTime()
    val res = code 
    println(s"Time taken=${System.nanoTime - st} ns")
    res 
}

time{ 1 to 1000 sum }

  
//Strings 
val s = "Hello World Hello"
s.size 
s(0)
s(0) = 'K'  //Error 
s.contains("Hello")
s contains "Hello"
//
s.trim   //String 

val s = """Hello World 
Hello"""

val s = raw"Hello"

val s = "Hello World Hello"
val s2 = s.split(raw"\s+")
//res27: Array[String] = Array(Hello, World, Hello)
s2.foreach(println)

     
val ms = new StringBuilder
ms += 'a'
ms ++= "buffer"
ms.toString 
     
     
val s = "Hello World Hello"
val s2 = s.split(raw"\s+")



for (ch <- s2) println(ch)

for (ch <- s2) {
    var counter = 0 
    for (ch1 <- s2) {      
        if(ch == ch1)
            counter += 1 
    }
    println(s"$ch = ${counter}")
}

//Array 

val arr = Array(1,2,3)  //Array[Int]
//+  - for one element, ++ - for another sequence 
// :+  - asso LHS , +: assoc RHS 
Array.empty[Int] ++ Array[Int]()
scala> val arr2 = arr :+ 2 :+ 3
arr2: Array[Int] = Array(1, 2, 3, 2, 3)

scala> 2 +: arr2
res35: Array[Int] = Array(2, 1, 2, 3, 2, 3)

scala> Array(2,3,4) ++: arr2
res36: Array[Int] = Array(2, 3, 4, 1, 2, 3, 2, 3)

arr2 ++ Array(2,3,4)

arr2(0)  //1
arr2(0)  = 2 //
arr2 contains 2 
for ( i <- arr2) println(i)
arr2.size
arr2.isEmpty

//List - indexing - OK, duplicates-ok, insertion ordered - OK 
val lst = List(1,2,3)  //Array[Int]
//+  - for one element, ++ - for another sequence 
// :+  - asso LHS , +: assoc RHS 
List.empty[Int] ++ List[Int]()
val lst2 = lst :+ 2 :+ 3
2 +: lst2
List(2,3,4) ++: lst2
lst2 ++ List(2,3,4)
lst(0)  //1
lst(0)  = 2 //Error 
lst contains 2 
for ( i <- lst2) println(i)
lst.size
lst.isEmpty
val lst = scala.collection.mutable.ListBuffer(1,2,3) 
lst += 2 
lst ++= List(2,3,4)
lst(0) = 2

val lst3 = 1 :: 2 :: Nil 
lst3.head
lst3.tail 

lst3.last 
lst3.init 

scala> val lst3 = 1 :: 2 :: 3:: 4::7 ::Nil // ((Nil.::(7)).::(4)).::(3)
lst3: List[Int] = List(1, 2, 3, 4, 7)

scala> lst3.head +: lst3.tail
res47: List[Int] = List(1, 2, 3, 4, 7)

scala> lst3.init :+ lst3.last
res48: List[Int] = List(1, 2, 3, 4, 7)

scala> List(1,2) ::: List(2,3) ::: Nil
res49: List[Int] = List(1, 2)

//Set - indexing - nOK, duplicates-nok, insertion ordered - nOK 
val set1 = Set(1,2,3)  //Array[Int]
val m_set = scala.collection.mutable.Set(1,2,3)

set1 contains  3 
set1.size 
for(i <- set1) println(i)

m_set contains  3 
m_set.size 
for(i <- m_set) println(i)
m_set += 50
val set2 = Set(3,4,5) 
set1 | set2 //union 
set1 & set2 //intersection 
set1 &~ set2 // difference 
//Conversion to* 
lst.toSet 
set1.toList 
set1.toArray 
//remove 
set1 - 2 
m_set -= 2 

//Map 
val map1 = Map(1 -> 2,  3 -> 4)  //Array[Int]
val m_map = scala.collection.mutable.Map[String, Int]()

map1 contains  3 
map1.size 
for( (k,v) <- map1) println(s"$k $v")
//access 
map1(3)

m_map += ("OK" -> 3) 
m_map ++= Map("NOK" -> 3) 

//creation of new key 
m_map("new") = 50 
m_map("OK") = 30 
m_map -= "OK"
//
m_map.toList 

//Tuples 
val t2 = ("OK", 2, 2.3, List(1,2,3))
scala> val t2 = ("OK", 2, 2.3, List(1,2,3))
t2: (String, Int, Double, List[Int]) = (OK,2,2.3,List(1, 2, 3))

scala> t2._1
res74: String = OK

scala> t2._2
res75: Int = 2

scala> t2._3
res76: Double = 2.3

scala> t2._4
res77: List[Int] = List(1, 2, 3)

scala> t2._5
<console>:13: error: value _5 is not a member of (String, Int, Double, List[Int])
       t2._5
          ^

scala> val t3 = (t2, t2, (t2,(t2,t2)))
t3: ((String, Int, Double, List[Int]), (String, Int, Double, List[Int]), ((String, Int, Do
uble, List[Int]), ((String, Int, Double, List[Int]), (String, Int, Double, List[Int])))) =
 ((OK,2,2.3,List(1, 2, 3)),(OK,2,2.3,List(1, 2, 3)),((OK,2,2.3,List(1, 2, 3)),((OK,2,2.3,L
ist(1, 2, 3)),(OK,2,2.3,List(1, 2, 3)))))

scala> t3.getClass
res79: Class[_ <: ((String, Int, Double, List[Int]), (String, Int, Double, List[Int]), ((String, Int, Double, List[Int]), ((String, Int, Double, List[Int]), (String, Int, Double, L
ist[Int]))))] = class scala.Tuple3


//Concurrent 
val s2 = scala.collection.concurrent.TrieMap[String, Int]()

//Class 
//run witb :paste 
class MyInt( private val v:Int) extends Ordered[MyInt] {
    def this() {this(0)}
    override def toString = s"MyInt($v)"
    override def hashCode = v.hashCode 
    override def equals(o:Any) = o match {
        case _:MyInt => o.hashCode == this.hashCode 
        case _ => false 
    }
    def +(o:MyInt) = MyInt(this.v + o.v)
    def compare(o:MyInt) =  this.v.compare(o.v) //+1, 0, -1 
}
object MyInt{
    def apply(x:Int) = new MyInt(x)
    def get_me = new MyInt(0)
}
//OR 
case class MyInt2(v:Int) extends Ordered[MyInt2] {    
    def +(o:MyInt2) = MyInt2(this.v + o.v)
    def compare(o:MyInt2) =  this.v compare o.v //+1, 0, -1 
}
object MyInt2{
    def get_me = new MyInt(0)
}






















     
     
     
     