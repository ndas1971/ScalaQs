val x = 2
var y = 2
//println(x)
x = 3 //Error 
y = 10 

val ch = 'A'
val str = "OK"
val i = 2
val b:Byte = 1
val b:Byte = 1 : Byte
val l = 1L
val f = 2.0f
val d = 2.0
val bi = BigInt("1111111")
val bd = BigDecimal("1.111")
val b = true
val i2 = i + 2
val i3 = "12".toInt
1.toFloat
1.toDouble

if ( i > 1){
    println(i)
} else{
    println(i)
}
val i4 = if ( i > 1) {
            i + 1 
        } else {
            i +10
        }

val i4 = if ( i > 1) {
            println(i + 1)
            i + 1
        } else {
            i +10
        }
        
/*
if name is "XYZ" 
and age is below 40, 
print "suitable" 
else if age is greater
than 50, print "old", 
else print "OK"
For all other names, 
print "not known" 
*/
// == , != , > , < , >=, <=
// && ||  !       
if ( true ) {
} 
else if ( false ) {
}
else {
}
//for loop    
for ( i <- 1 to 10) 
    println(i)
    
for ( i <- 1 until 10){
    val z = 3*3 
    println(i)   
}        
for ( i <- 1 until 10 by 2){
    println(i)   
}         
for {
    i <- 1 to 10 if i%2 == 0 
    x = i*i 
    j <- 1 to x if j%2 == 0
} {
    val y = i*i 
    println(s"i=$i j=$j x=$x y=$y")
}       
        
for {
    i <- 1 to 3 
    j <- 1 to 2
} {
    val y = i*i 
    println(s"i=$i j=$j")
}       
 
Print prime numbers between 0 to 10 
        
val last = 100 
println("2 is prime")
for( i <- 3 to last by 2){
    var prime = true 
    for( j <- 3 to i-1){
        if ( i % j == 0){
            prime = false 
        }
    }
    if (prime)
        println(s"$i is prime")
}
//this would not work
val last = 100 
for {
    i <- 3 to last by 2
    j <- 3 to i-1 if i % j == 0
}{
    println(s"$i is not prime")
}

//Print Pythogorus triplets  below 100
       
        
val last = 50       
for {
    x <- 1 to last 
    y <- x to last 
    z <- y to last if z*z == x * x + y * y
} {
    println(s"($x,$y,$z)")
}        
//getPyTriplets: (last: Int)Unit    
def getPyTriplets(last:Int) {
    for {
        x <- 1 to last 
        y <- x to last 
        z <- y to last if z*z == x * x + y * y
    } {
        println(s"($x,$y,$z)")
    }  
}     
getPyTriplets(100) 
//while 
scala> var c = 0
c: Int = 0

while (c < 3){
  println(c)
  c += 1
}
//String 
val i = 10 
val s = "He\"l\"lo"
val sm = """Hello 
"world"
hello"""
val rs = raw" Hello \n"
val is = s" $i and ${s.size}"
val ifs = f" $i%02d and ${s.size.toFloat}%03.2f"

val s = "Hello World"
s.size
s.isEmpty
s(0)
s(0) = 'K' //Error 
s == "Hello"
for ( ch <- s){
        println(ch)
}  
s.contains("He")
s.indexOf("e") //finds index 
s.split(" ") //Array[String]

//Check 
trim 
stripPrefix 
stripSuffix 
startsWith 
endsWith
capitalize 

//mutable string
val buf = new StringBuilder
buf += 'a' 
buf ++= "abc"
buf.toString 
///HandsOn 
val s = "Hello World Hello"
//== is used comparison 
// for for iteration 
for{
    word <- s.split(" ")
}{
    println(word)
}
//print 
Hello - 2
world - 1

def frequency(str:String) {
    // Take each word(wd1) from str after splitting
    for(wd1 <- str.split(" ")){
        // initialize counter 
        var counter = 0 
        // Take each word(wd2) after split 
        for (wd2 <- str.split(" ")){
            // if wd1 and wd2 are same 
            if ( wd1 == wd2 ){
                // increment counter 
                counter += 1 
                }
        }
        // print wd1 and counter 
        println(s"$wd1 -  $counter")    
    }        
}        
        
val input = "ABCDEF0123456789"
// Print every 2nd element 
// start from 2nd elemnt  and then print every 2nd element
def funnyCode(str:String, every:Int, skip:Int=0){
    for( g <- str.drop(skip).grouped(every)){
        println(g(0))
    }
}
def funnyCode(str:String, every:Int, skip:Int=0):String={
    val rt = new StringBuilder
    for( g <- str.drop(skip).grouped(every)){
        rt += g(0)
    }
    return rt.toString 
}
def funnyCode(str:String, every:Int=2, skip:Int=0)={
    val rt = new StringBuilder
    for( g <- str.drop(skip).grouped(every)){
        rt += g(0)
    }
    rt.toString //return optional, last stm is return 
}
funnyCode(input, 2,0)
funnyCode(input, 2)
funnyCode(input)
funnyCode(input, 2,1)
funnyCode(input,skip=1) //funnyCode(input, 2,1)

////COllections 
/*
Array[T] - mutable, can npt expand size 
mutable.ArrayBuffer[T] - mutable, can expand size 

*, immutable.List[T] - D-A, Indexing-A, IO - A
mutable.ListBuffer[T] 

*, immutable.Set[T] - D-NA, Indexing-NA, IO - NA
mutable.Set[T] 

*, immutable.Map[K,V] - pair of key and value, keys are like set 
mutable.Map[K,V]
*/
val arr = Array(1,2,3,4)//Array[Int]
val ea = Array[Int]() //empty
val ea = Array.empty[Int]
//Array, ArrayOps 
arr(0)  // 1
arr(0) = 20 
arr.size //size 
arr.isEmpty //
arr.contains(2) //true 
2 +: arr :+ 3 //Array(2, 20, 2,3,4,3)
2 +: ea :+ 3 // new array ea
            //(ea.+:(2)).:+(3)
val arr1 = ea ++ Array(1,2,3) 

val buf = scala.collection.mutable.ArrayBuffer.empty[Int]
buf += 1 
buf ++= Array(2,3)
buf.toArray 
//.to* gives conversion 

val er = Array(1, 1.0, "OK")
for (e <- er){
   println( s"${e.size}")
 }
//Tuple - 2 to 22 
val er = (1, 1.0, "OK")
//(Int, Double, String) = (1,1.0,OK)
scala> er._1
res49: Int = 1
scala> er._2
res50: Double = 1.0
scala> er._3
res51: String = OK
//OR
scala> val (i,d,n) = er
i: Int = 1
d: Double = 1.0
n: String = OK
//List 
val lst = List(1,2,3,4)//List[Int]
val ea = List[Int]() //empty
val ea = List .empty[Int]
//List[T]
lst(0)  // 1
lst(0) = 20 //ERROR 
lst.size //size 
lst.isEmpty //
lst.contains(2) //true 
2 +: lst :+ 3 //List(2, 20, 2,3,4,3)
2 +: lst :+ 3 // new List, ea
val lst1 = ea ++ List(1,2,3) 
for ( e <- lst){
    println(e)
}
val lst = 1 :: 2 :: 3 :: Nil //List[Int]

lst.head 
lst.tail 
//lst = lst.head +: lst.tail 

lst.init 
lst.last 
//lst = lst.init :+ lst.last 

val buf = scala.collection.mutable.ListBuffer.empty[Int]
buf += 1 
buf ++= List(2,3)
buf.toArray 
//HandsOn 
val lst = List(0,1,2,3,4,5) //0 to 5 toList 
val out = List(0, 1, 4, 9, 16, 25)

def sq(lst:List[Int]) = {
    val buf = collection.mutable.ListBuffer.empty[Int]
    for ( e <- lst){
        buf += e*e 
    }
    buf.toList
}
///Hands ON 
val lst = List( ("xyz", 2, 3), ("abcd", 10,3)   )
out = List(3,4) //ie first string's size 
def sq(lst:List[(String, Int, Int)]) = {
    val buf = collection.mutable.ListBuffer.empty[Int]
    for ( e <- lst){
        buf += e._1.size
    }
    buf.toList
}
//OR 
def sq(lst:List[(String, Int, Int)]) = {
    val buf = collection.mutable.ListBuffer.empty[Int]
    for ( (f,s,t) <- lst){
        buf += f.size
    }
    buf.toList
}


//Set 
//.toSet 
val s = Set(1,2,3,4)
//2 +: s :+ 3 
s.contains(3)
for (e <- s) println(e)
s + 10 //adding one key 
s - 4 //removing one key 
s.size 
s.isEmpty 
List(1,1,1,2).toSet.toList // List(1,2)
val s2 = Set(4,5,6)
//union 
s | s2
//intersection 
s & s2 
//diff 
s &~ s2 
//mutable 
val s = collection.mutable.Set.empty[Int]
s += 2 //add
s -= 2 //removing 
s.toSet 

//Map 
val m = Map("ok" -> 2, "nok" -> 3) //immutable.Map[String,Int]
m("ok")  //given key , get value 
m.contains("ok") //check key existance 
m.size 
for ( (k,v) <- m) println(s"$k $v")
m ++ Map("c" -> 30) 
m + ("d" -> 30)  //add, tuple= ->
m - "ok"  //removing 
//mutable 
val mm = collection.mutable.Map("ok" -> 2, "nok" -> 3)
mm("ok")  //accessing 
mm("ok") = 30  //updating
mm("okok") = 20 //creating new key 
mm.toMap 
mm.keys
mm.values 
mm.toList // List of tuple of k and v 








     
        
