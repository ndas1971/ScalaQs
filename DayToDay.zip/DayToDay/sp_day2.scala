///HANDSON - Given a string 
val s = "Hello World Hello"
//Given a List of String
//write a function, that returns Map of  
//each word and it's frequency 
//
def getFrequency[U](lst:Seq[U])={ //Map[U,Int]
    import scala.collection.mutable.Map 
    val m = Map.empty[U, Int]
    for(e <- lst ) {
          if (m contains e){
                m(e) = m(e) + 1
            }
            else {
               m(e) = 1 
            }
    }
    //lst(0).size 
    m.toMap
}
scala> getFrequency(s.split(" ").toList)
res1: scala.collection.immutable.Map[String,Int] = Map(Hello -> 2, World -> 1)

scala> getFrequency(s.toList)
res2: scala.collection.immutable.Map[Char,Int] = Map(e -> 2,   -> 2, l -> 5, H -
> 2, W -> 1, r -> 1, o -> 3, d -> 1)

scala> getFrequency(List(1,1,1,2,3))
res3: scala.collection.immutable.Map[Int,Int] = Map(2 -> 1, 1 -> 3, 3 -> 1)

//Genrics 
def  met[T](x:T) = x == x //T is scala.Any 

def f(x:Int):Int = {
    //val x = 0 //ERROR
    def g(y:Int) = {
        val x = 0
        x*y
    }
    g(100+x)
}
f(10) //

//variable 
def printAll[T](ns:T*){   
    for (e <- ns) println(e)  //ns:Seq[T]
}

printAll(1,2,3,4)
printAll(1, 1.2, "OK")
printAll("OK")

val lst = List(1,2,3)
prinAll(lst : _*)

//call by syntax 

def doubleIf(test1: => Boolean)(test2: =>Boolean)(code: =>Unit){
    println("inside")
    if(test1 && test2){
        code 
    }
}
val age = 20 
val acc = 0 
doubleIf(age > 18)(acc == 0){println("very good")}

def ifi( code: Unit){
    println("inside")
}
ifi(println("very good"))

///
def fun(last:Int)={
    1 to last sum
}
//if function takes no arg, can use () or without ()
def time[R](code: =>R):R={
    val st = System.nanoTime()
    val res = code 
    println(s"time diff= ${System.nanoTime - st} ns")
    res
}
scala> time {  1 to 100 sum}
warning: there was one feature warning; re-run with -feature for details
time diff=156974
res17: Int = 5050
time {  fun(1000) }

//
val y = 20 
val x = {
    println("y")
    y + 20     
}

time { x }
time {
        println("y")
        y + 20     

}
//
lazy val x = {
    println("y")
    y + 20     
}
println(x)
time { x }

///HandsOn 
Write a Class case class Complex with + operation handled 
and comparison possible 
Complex has two arg real, img and + adds real, 
real and imaginary and imaginary

//java -cp target\scala-2.11\learning-assembly.jar first.Main3 mumbai 
//java -cp target\scala-2.11\learning-assembly.jar first.Main3 mumbai c false


case class MyInt2(x: Int) extends Ordered[MyInt2]{
    def +(o:MyInt2) = MyInt2(this.x + o.x)
    def compare(o:MyInt2) = this.x compare o.x
}

case class Complex(re:Int, img:Int) extends Ordered[Complex]{
    def +(o:Complex) = Complex(this.re+o.re, this.img+o.img)
    def compare(o:Complex) = 
        Ordering[(Int,Int)].compare( (re,img) , (o.re,o.img) ) 
}
val a = Complex(1,2)
val b = (((((a + a) + a) + a) + a) + a)











