object Twice{
    def apply(x:Int) = x*2 
    def unapply(z:Int): Option[Int] = Some(z/2)
}
val x = Twice(21)  //apply
val Twice(z) = 22  // unapply

object M{
    def apply(a: String*) = a.mkString(":")
    def unapplySeq(m:String):Option[Seq[String]] = 
        Some(m.split(":"))
}
val m = M("OK", "NOK")
val M(s,a) = "ok:nok"

case class Person(first:String, sec:String)
case object Request 

def extract(o:Any) = o match {
    case 0 | 1 | 2 => s"Alternate"
    case Request => "request"
    case Twice(x) => s"Twice $x"
    case List(1, _, _) => "List with head 1"
    case a @ List(x,y @ _*) => s"$a $x $y"
    case Person("X", s) => s"X $s"
    case Person(a,b) => s"Person $a $b"
    case (x,y) if x == y => "same element tuple"
    case (x,y) => "tuple2"
    case x:String => s"a string"
    case x:Array[String]  => "array string"
    case l:Seq[_] => "seq"
    case ( (x,y), (z,a), b) => "nested"
    case _ => "default"

}

scala> extract(0)
res1: String = Alternate

scala> extract(Request)
res2: String = request

scala> extract(Twice(22))
res3: String = Twice 22

scala> extract(List(1,2,3))
res4: String = List with head 1

scala> extract(List(2,2,3))
res5: String = List(2, 2, 3) 2 List(2, 3)

scala> extract(List(1,2))
res6: String = List(1, 2) 1 List(2)

scala> extract(List(1,2, 3,4))
res7: String = List(1, 2, 3, 4) 1 List(2, 3,

scala> extract(Person("X","wsd"))
res8: String = X wsd

scala> extract(Person("Xe","wsd"))
res9: String = Person Xe wsd

scala> extract((1,1))
res10: String = same element tuple

scala> extract((1,2))
res11: String = tuple2

scala> extract("sa")
res12: String = a string

scala> extract(Array("sa"))
res13: String = array string

scala> extract(Seq("sa"))
res14: String = List(sa) sa List()

scala> extract(((1,2),(3,4),5))
res15: String = nested

scala> extract(10)
res16: String = Twice 5

scala> extract(10.0)
res17: String = default

scala> extract(Seq[Int]())
res18: String = seq

scala> extract(Twice(22))
res19: String = Twice 22

scala> extract(10)
res20: String = Twice 5


//Recursion

def mysum(x:List[Int]):Int = 
    if (x.isEmpty) 0 else x.head + mysum(x.tail)
    
def mysum2(x:List[Int]):Int = x match {
    case h :: t  => h + mysum2(t)
    case Nil => 0
}

mysum(List.range(1,100)) 
mysum2(List.range(1,100)) 

def mysum3(x:List[Int]) = {
    def _sum (y:List[Int], acc:BigInt):BigInt = 
      y match {
          case h :: t => 
             println(s"t=$t, acc=$acc, h=$h, sum=${h+acc}")
            _sum(t, h+acc)
          case Nil => acc 
      }
    _sum(x, 0)
}


//Given a List , find max in that list using TCO
 
def max(x:List[Int]) ={
    def _max(y:List[Int], maxUntil:Int):Int = 
        y match {
            case h :: t => _max(t, if (h>maxUntil)
                                    h else maxUntil)
            case Nil => maxUntil        
        }
    _max(x, x.head)
}

//FP 

def add(x:Int, y:Int) = x+y 
scala> add _
res28: (Int, Int) => Int = <function2>

val add1 = (x:Int, y:Int) => x+y 
add1(2,3) 
type TWO_ARG = (Int, Int) => Int

val add2 = (x:Int) => (y:Int) => x+y //Int => (Int => Int)
def f(x:Int) = {
    def g(y:Int) = x+y 
    g _ 
}
add2(2)(3)
f(2)(3)

//partial application 
add(2, _:Int)
scala> val f = add(2, _:Int)
f: Int => Int = <function1>

scala> f(2)
res36: Int = 4

scala> (add _).curried
res38: Int => (Int => Int) = <function1>

(add _).tupled //((Int, Int)) => Int = <function1>
(add _).tupled((2,3))

case class Two(f:Int, s:Int)
val t = (1,2)

Two(t._1, t._2)
(Two.apply _).tupled(t)

//compose - Function1 
val dou = (x:Int) => x*x 
val ai = (x:Int) => x+5 
dou(2)
ai(2)

(dou andThen ai)(2)  // ai(dou(2))
(dou compose ai)(2) // dou(ai(2))

val pf: PartialFunction[Int,Int] = {
    case x:Int if x != 0 => 42/x }
    

pf.isDefinedAt(0)
pf.isDefinedAt(1)

val pf1: PartialFunction[Int,Int] = {
    case x:Int if x == 0 => 0 }
    
(pf orElse pf1)(0)


val ls = List(1,2,3)  //List[Int]
val map = Map("OK"->1, "NOK" -> 2) //Map[String, Int]


//List[A].foreach(f: (A) => Unit): Unit 


def p(x:Int) = println(x) 
ls.foreach(p _)

ls.foreach( (x:Int) => println(x))
ls.foreach( println(_))
ls.foreach( println _ )
//not for overloaded cases 
ls.foreach( println )
ls foreach println 

map.foreach{ case (x,y) => println(s"$x $y")}

//for 
for {
    x <- ls 
} {
    println(x)
}
//List[A].map[B](f: (A) => B): List[B] 
ls.map{ x => x*x}
map.map{case(x,y)=> x+y}
map.map{case(x,y)=> (x,y*y)}.toMap

val out = for {
    x <- ls 
} yield {
  x*x 
}
//filter List[A].filter(p: (A) => Boolean): List[A] 
ls.filter{ x => x %2 == 0}
map.filter{case(x,y) => y%2 == 0}

//flatmap 
//def List[A].flatMap[B](f: (A) => 
//  GenTraversableOnce[B]): List[B] 

ls.flatMap{x => List(x,x*x, x*x*x)}
map.flatMap{case(x,y) => Map(x->y*y)}.toMap 

//loops 
val first = List(1,2)
val next = List(8,9)
val last = List("ab", "cd", "ghk")
for {
    i <- first if i%2 == 0 //withFilter //flatmap
    j <- next  //flatmap
    k <- last //map
} yield {
    println(s"$i $j $j")
    val len = k.size
    i*j*len 
}
//equivalent 
first withFilter(i => i%2 ==0) flatMap{ i =>
    next flatMap { j =>
        last map { k =>
            val len = k.size 
            i*j*len 
        }
    }
}
//collect 
ls.collect{case x:Int if x%2 == 0 => x*x }
map.collect{case (x,y) if y%2 == 0 => (x,y)}

val lst2 = List[String]("ab", null:String)
lst2.collect{case x:String if x != null => x.size 
            case _ => null:String
        }


//reduce - def reduce[A1 >: A](op: (A1, A1) => A1): A1 
ls.reduce{ (r,t) => r+t}
map.reduce{ (r,t) => (r._1+t._1, r._2+t._2)}



//List[A].foldLeft[B](z: B)(op: (B, A) => B): B 
ls.foldLeft(0){ (r,t) => r+t}
map.foldLeft( ("pre",10) ){(r,t) => 
                    (r._1+t._1, r._2+t._2)}

ls.map(x => x*x)
ls.foldLeft(List[Int]()){ (r,e) => 
            println(s"$r $e")
            r :+ e*e 
      }
//



//xy.txt 
val lines = scala.io.Source.
                 fromFile(raw"xy.txt").
                 getLines.
                 toList 

List(qbcd, abcd, abcd, "", cdfe, cdef, "", "", "", abcd, abcs, "", "", abcd)
Convert to 
List(List(qbcd, abcd, abcd), List(cdfe, cdef), List(abcd, abcs), List(abcd))

import scala.collection.mutable.ListBuffer
def process(r:ListBuffer[ListBuffer[String]], e:String)={
    if (!e.isEmpty)
        r.last.append(e) //r.lst :+ e
    else if (e.isEmpty && r.last.isEmpty)
        r
    else 
        r.append(ListBuffer[String]()) // r ++ List[String]()
    r
}


lines.foldLeft(ListBuffer[ListBuffer[String]]
    (ListBuffer[String]()))(process _)
    
//ListBuffer(ListBuffer(qbcd, abcd, abcd), ListBuffer(abcd))

//sorting 
ls.sorted 
map.toList.sorted 

val lsw = List("a", "bb", "c", "xyz")
lsw.sortBy{ e => e.size}

map.toList.sortBy{case (k,v) => v}


//Given a dir, find fileName with max size recursively

//Use java.io.File  
//listFiles 
//isFile 
//isDirectory 
//length   to get size 

import java.io.File 
def getMaxFileName(dir:File) = {
    def getAllFiles(dir:Array[File], acc:Array[File]=Array.empty[File]):Array[File]={
        val files = dir.flatMap{ f => f.listFiles.filter(_.isFile)}
        val subs = dir.flatMap{ f => f.listFiles.filter(_.isDirectory)}
        if (subs.isEmpty) acc ++ files else getAllFiles(subs, acc ++ files)
    }
    val allFiles = getAllFiles(Array(dir))
    val map = allFiles.map(f => (f,f.length)).toMap 
    val s_map = map.toList.sortBy{case (k,v) => v}
    s_map.last
}

//maxBy 
ls.maxBy(x => x)
map.toList.maxBy{case (x,y) => y}

//groupBy
// List(1, 2, 3)
ls.groupBy( x => x%2 ) //Map(1 -> List(1, 3), 0 -> List(2))
//Map(OK -> 1, NOK -> 2)
map.groupBy{case(x,y) => x.size}//Map(2 -> Map(OK -> 1), 3 -> Map(NOK -> 2))


///Iris.csv -- 
val lines = scala.io.Source.fromFile("../../data/iris.csv").getLines.toList//List[String]
val lines2 = lines.drop(1).map{_.split(",")}. //List[Array[String]]
     map{ arr =>
      (arr.slice(0,4).map(_.toDouble), arr.last)}. //List[(Array[Double],String)]
      map{ case (Array(a,b,c,d),e) =>
       (a,b,c,d,e)}  //List[(Double, Double, Double, Double, String)]
       
case class Row(sl:Double, sw:Double, pl:Double, pw:Double, n:String)
val rows = lines2.map{t => (Row.apply _).tupled(t)} //List[Row]
val un = rows.map(_.n).toSet
val un = rows.map(r => r.n).toSet
//Set(Iris-setosa, Iris-versicolor, Iris-virginica)

rows.groupBy(_.n) //Map[String,List[Row]]
rows.groupBy(_.n).map{ case (n, lst) => (n , lst.map(_.sl).max)}
//Map(Iris-virginica -> 7.9, Iris-setosa -> 5.8, Iris-versicolor -> 7.0)

rows.groupBy(_.n).map{ case (n, lst) => (n , Map("sl" -> lst.map(_.sl).max, 
            "sw" -> lst.map(_.sw).max))}
//List((Iris-virginica,Map(sl -> 7.9),(sw,3.8)), (Iris-setosa,Map(sl -> 5.8),(sw,4.4)), (Iris-versicolor,Map(sl -> 7.0),(sw,3.4)))

rows.groupBy(_.n).map{ case (n, lst) => (n , Map("sl" -> Map("max" ->lst.map(_.sl).max, 
                                                              "sum" -> lst.map(_.sl).sum),
                                                 "sw" -> Map("max" ->lst.map(_.sw).max, 
                                                              "sum" -> lst.map(_.sw).sum)))}

//Map(Iris-virginica -> Map(sl -> Map(max -> 7.9, sum -> 329.3999999999999), sw -> Map(max -> 3.8, sum -> 148.7)), Iris-setosa -> Map(sl ->
//Map(max -> 5.8, sum -> 250.29999999999998), sw -> Map(max -> 4.4, sum -> 170.90000000000003)), Iris-versicolor -> Map(sl -> Map(max -> 7.0, sum -> 296.8), sw -> Map(max -> 3.4, sum -> 138.50000000000003)))

























