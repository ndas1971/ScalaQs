//location = 'mumbai'
//http://query.yahooapis.com/v1/public/yql?q=select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='mumbai') and u='c' &format=json
package first 
class Weather(var location:String,
            private val unit:String="c",
            private val format:Boolean=true){ //true means json 
    import java.net.URLEncoder
    override def toString = s"Weather(${this.location})"
    private val base = "http://query.yahooapis.com/v1/public/yql"
    private def encode = s"select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='${this.location}') and u='${this.unit}'"
    def full_url = s"""${base}?q=${URLEncoder.encode(encode,"UTF-8")}&format=${if(format) "json" else "xml"}"""
    
    def get = scala.io.Source.fromURL(full_url).mkString
        
}