package first

object Main extends App {
    val a = MyInt(1)
    val b = MyInt(2)
    val c = a + b 
    println(c)
}

//sbt assembly 
//java -cp target\scala-2.11\learning-assembly.jar   first.Main 

object Main2 {
    def main(args:Array[String]){
        val a = MyInt2(1)
        val b = MyInt2(2)
        val c = a + b 
        println(c)
    }
}
//java -cp target\scala-2.11\learning-assembly.jar   first.Main2 
//args contains command line arguments 
object Main3 extends App {
    val Array(location, unit, json) = 
        if (args.size >= 3) args.slice(0,3)
        else if (args.size == 2) args :+ "true"
        else args :+ "c" :+ "true"
    val w = new Weather(location, unit, json.toBoolean)
    println(w.get)
}
//java -cp target\scala-2.11\learning-assembly.jar first.Main3 mumbai 
//java -cp target\scala-2.11\learning-assembly.jar first.Main3 mumbai c false




