package examples 

import org.apache.spark._ 
import org.apache.spark.rdd._ 

import org.apache.spark.sql.types._ 
import org.apache.spark.sql.streaming._ 
import scala.util._ 
import scala.concurrent.duration._

object WordCountSubmit{
    def main(args:Array[String]){
        val inputfile = if (args.size >= 1) args(0) else "README"
        //val inputfile = "hdfs://locahost:19000/user/jp/README"
        val conf = new SparkConf().setAppName("wordcount")
        val sc = new SparkContext(conf) //main entry point
        val input = sc.textFile(inputfile) //each line , RDD[String]
        //TRANSFORMATION is lazy 
        val words = input.flatMap(line => line.split(" ")) //RDD[String]
        val counts = words.map(w => (w,1)). //RDD[(String,Int)]
                           reduceByKey{case (v1,v2) => v1+v2}//RDD[(String,Int)]
        counts.collect(). //ACTION
                foreach(println) //in Driver     
    }
}
//$ spark-submit --class examples.WordCountSubmit --master local[4]  
//target/scala-2.11/learning-assembly.jar README  
//DF
import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F}

object DFCount{
    def main(args:Array[String]){
        val inputfile = if (args.size >= 1) args(0) else "README"
        val spark = SparkSession.builder.appName("wordcount").getOrCreate()
        import spark.implicits._ 
        val input = spark.read.text(inputfile) //DF with col "value"
        val words = input.select(F.split(F.col("value")," ").alias("words"))
        val counts = words.select(F.explode($"words").alias("word"))
        val grp = counts.groupBy("word")
        grp.count().collect().foreach(println)
        //sql 
        counts.createOrReplaceTempView("words")
        val df = spark.sql("select word, count(*) as COUNT from words group by word")
        df.show()
    }
}
//spark-submit --class examples.DFCount --master local[4]  target/scala-2.11/learning-assembly.jar README  


import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql.streaming._ 
import scala.concurrent.duration._

object StreamDFCount{
    def main(args:Array[String]){
        val inputDir = if (args.size >= 1) args(0) else "stream-in"
        val spark = SparkSession.builder.appName("wordcount").getOrCreate()
        import spark.implicits._ 
        val input = spark.readStream.textFile(inputDir) //DF with col "value"
        val words = input.select(F.split(F.col("value")," ").alias("words"))
        val counts = words.select(F.explode($"words").alias("word"))
        val grp = counts.groupBy("word").count()        
        val query = grp.writeStream.outputMode("complete").
                                    format("console").
                                    option("truncate", false).
                                    trigger(Trigger.ProcessingTime(20.seconds)).
                                    start()                                    
        query.awaitTermination()
    }
}

//spark-submit --class examples.StreamDFCount --master local[4]  target/scala-2.11/learning-assembly.jar 
/*
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:00:00.002Z,"mine",20
*/
object KafkaSourceSink{
    def main(args:Array[String]){
        val spark = SparkSession.builder.appName("wordcount").getOrCreate()
        import spark.implicits._ 
        val df = spark.readStream.format("kafka").
                       option("subscribe", "topic1").
                       option("kafka.bootstrap.servers", "localhost:9092").
                       load()                       
        df.printSchema 
        /*
        root
             |-- key: binary (nullable = true)
             |-- value: binary (nullable = true)
             |-- topic: string (nullable = true)
             |-- partition: integer (nullable = true)
             |-- offset: long (nullable = true)
             |-- timestamp: timestamp (nullable = true)  ///ingestion time 
             |-- timestampType: integer (nullable = true)

        */    
        //2017-08-23T00:00:00.002Z,"mine",20        
        val query = df.select($"value".cast("string")).
                     withColumn("tokens", F.split($"value", ",")).
                     withColumn("eventTime", F.to_timestamp($"tokens".getItem(0))).
                     withColumn("deviceId", $"tokens".getItem(1).cast("string")).
                     withColumn("signal", $"tokens".getItem(2).cast("int")).
                     select("eventTime","deviceId","signal").
                     groupBy("deviceId").
                     agg(F.avg("signal").cast("string").alias("value")). //sink requires "value"
                     writeStream.
                     format("kafka").outputMode("update").
                     option("topic", "topicName").
                     option("kafka.bootstrap.servers", "localhost:9092").
                     option("checkpointLocation", "./kafka-checkpoint").
                     start()              
                     
                                     
        query.awaitTermination()
    }
}

//spark-submit --class examples.KafkaSourceSink --master local[4]  target/scala-2.11/learning-assembly.jar 





