package first
import org.scalatest._

class MyIntTest extends FunSuite with BeforeAndAfter{
    var a:MyInt = _
    var c:MyInt = _ 
    before {
         a = MyInt(1)
         c = MyInt(2)
    }
    test(" equality check "){
        assert(a == a)
    }
    test(" addition "){
        assert(a + a == c)
    }
}