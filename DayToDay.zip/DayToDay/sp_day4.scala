$ hdfs namenode -format 
$ start-dfs 
$ hdfs dfs -mkdir /user
$ hdfs dfs -mkdir /user/jp 
$ hdfs dfs -put debug.log /user/jp/README

$ hdfs dfs -ls /user/jp 
$ hdfs dfs -cat /user/jp/README

package examples 

import org.apache.spark._ 
import org.apache.spark.SparkContext._ 

object WordCount{
    def main(args:Array[String]){
        val file = "hdfs://localhost:19000/user/jp/README"
        //file://C:/.....
        val conf = new SparkConf().setAppName("wordcount")
        val sc = new SparkContext(conf)
        
        val in = sc.textFile(file)
        val words = in.flatMap(line =>line.split(" "))
        val counts = words.map(w => (w,1)).
                          reduceByKey{case (v1,v2) => v1+v2} //same key, add value 
        counts.collect().foreach(println)    
    }
}
//spark-submit --class examples.WordCount --master local[4] target/scala-2.11/learning-assembly.jar



//iris.csv 
val lines = sc.textFile(raw"data\iris.csv")
val lines1 = lines.repartition(4)

lines.count 
lines.take(5)
lines.glom().collect() //Array[Array[String]] 

val lines2 = lines.zipWithIndex().
                   filter{case ( e,i) => i !=0}.
                   map{case (e,i) => e} //RDD[String]
                   
val iris = lines2.map(_.split(",")).
                  map(e=> (e.last, e.init.map(_.toDouble)))
//RDD[(String,RDD[(String, Array[Double])]
                
val unique = iris.groupByKey().keys.collect.toSet.toList 
//unique names //
import org.apache.spark._ 

class MyPartitioner(n:Int, lst:List[String]) extends Partitioner{
    def numPartitions = n
    def getPartition(k:Any) = 
        lst.indexOf(k.asInstanceOf[String]) % numPartitions
}

val iris2 = iris.groupByKey(
    new MyPartitioner(unique.size, unique))
//RDD[(String, Iterable[Array[Double]])]
    
iris2.glom().
      collect().map(rows => rows(0)._2.size) 
//res10: Array[Int] = Array(50, 50, 50)

//RDD[T].mapPartitions[U](func: (Iterator[T]) => Iterator[U])(implicit arg0: Encoder[U]): Dataset[U]

def func(it:Iterator[(String, Iterable[Array[Double]])]) = {
        val lst = it.toList(0)  //(String, Iterable[Array[Double]])
        List( (lst._1, lst._2.toList.map(e => e(0)))).iterator  // 0 means first column 
}
val iris3 = iris2.mapPartitions( it => func(it), true) 
//RDD[(String, List[Double])]
val iris4 = iris3.map{ case(k,lst) =>
            (k, Map("max" -> lst.max))}
//RDD[(String, scala.collection.immutable.Map[String,Double])]
iris4.collect()
//Array((Iris-versicolor,Map(max -> 7.0)), (Iris-virginica,Map(max -> 7.9)), (Iris-setosa,Map(max -> 5.8)))


///DF 
import org.apache.spark._
import org.apache.spark.rdd._
import org.apache.spark.sql._
import org.apache.spark.sql.functions._ 

import spark.implicits._ 

val auc = spark.read.format("csv").
                     option("header", true).
                     option("inferSchema", true).
                     load("data/spark/Cartier+for+WinnersCurse.csv")

val auc1 = auc.repartition(col("auctionId"))//$"auctionId, 'auctionId
scala> auc1.rdd.getNumPartitions
res17: Int = 200

scala> auc.printSchema
root
 |-- auctionid: integer (nullable = tru
 |-- bid: double (nullable = true)
 |-- bidtime: double (nullable = true)
 |-- bidder: string (nullable = true)
 |-- bidderrate: integer (nullable = tr
 |-- openbid: double (nullable = true)
 |-- price: double (nullable = true)

auc.show 
auc.collect 
auc.count
auc.cache

auc.filter("bidder like 'c%'").show 
auc.select("auctionId").distinct.count 

auc.select("auctionId", "bid").where("bid >= 1000").show 
auc.select("*").where("bid >= 1000").show 

auc.registerTempTable("auctions")
spark.sql("select auctionId, count(*) from auctions group by auctionId").show 

auc.groupBy("bidder").count().sort(desc("count")).
        show(200,truncate=false)

auc.groupBy("auctionId").
    agg(sum("bid") as "sb", count("bidder") as "cb").
    select("auctionId", "sb", "cb").show 

auc.agg(max("bid"),count("bidder")).collect() 
val df3 = auc.withColumn("new_price", col("price")* 20)
df3.withColumnRenamed("new_price", "price2")
val df2 = auc.groupBy("bidder").count 
//savings 
df2.repartition(1).write.format("csv").option("header", true).
                   mode("append").save("data/spark/out-csv")
//spark-shell --jars "..."                 
df2.write.format("jdbc").options(Map("url" -> "jdbc:sqlite:wc.db",
                 "driver" -> "org.sqlite.JDBC",
                 "dbtable" -> "new_table")).mode("append").save()
                 
val df4 = spark.read.format("jdbc").options(Map("url" -> "jdbc:sqlite:wc.db",
                 "driver" -> "org.sqlite.JDBC",
                 "dbtable" -> "new_table")).load()




//Boston 
val boston = spark.read.format("csv").
                     option("header", true).
                     option("inferSchema", true).
                     load("data/spark/boston.csv")
                     
val mc = boston.agg(max("crim")).collect()(0).getDouble(0)
boston.select("medv").where(s"crim==$mc").show 


//streaming 
import org.apache.spark.sql.types._ 
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.streaming.OutputMode._
import scala.concurrent.duration._ 

//6262,Coach: Season 9: Grimmworld,1996,,1320
val schema = StructType(Array(
                StructField("id", IntegerType),
                StructField("name", StringType),
                StructField("year", IntegerType),
                StructField("rating", DoubleType),
                StructField("duration", IntegerType)))

val df = spark.readStream.schema(schema).csv("data/spark/csv-in")
val new_df = df.selectExpr("CAST(id as STRING) AS key",
                            "to_json(struct(*)) as value")

val sql = new_df.writeStream.format("csv").
                             option("header", true).
                             option("checkpointLocation" , "./first_stream").
                             trigger(ProcessingTime(10.seconds)).
                             start("data/spark/csv-out")
                             
val sql2 = new_df.writeStream.format("console").
                             option("truncate", false).
                             trigger(ProcessingTime(10.seconds)).
                             start()                            
                             
spark.streams.active.foreach(q => q.stop)


//spark 
val rawData = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load() 
  
  
import org.apache.spark._
import org.apache.spark.rdd._
import org.apache.spark.sql._
import org.apache.spark.sql.{functions =>F}
import org.apache.spark.sql.types._ 
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.streaming.OutputMode._
import scala.concurrent.duration._ 



val eventsDF = rawData.
  select(F.col("value").cast("string")).          
  withColumn("tokens", F.split(col("value"), ",")).    
  withColumn("eventTime", F.to_timestamp(col("tokens").getItem(0))).
  withColumn("deviceId", F.col("tokens").getItem(1).cast("string")).
  withColumn("signal", F.col("tokens").getItem(2).cast("int")).
  select("eventTime", "deviceId", "signal")

val avgSignalDF = eventsDF.groupBy("deviceId").avg("signal")

val sq = avgSignalDF.writeStream.
  format("console").
  option("truncate", false).
  trigger(Trigger.ProcessingTime(10.seconds)).
  outputMode("update").  
  start()










