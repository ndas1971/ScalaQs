val ls = List(1,2,3)
val map = Map("OK"->1 , "NOK"->2)

//reduce 
//def List[A].reduce[A1 >: A](op: (A1, A1) => A1): A1 

ls.reduce{ (r,e) =>
                println(s"r=$r e=$e")
                r+e
         }
map.reduce{ (r,e) =>
            println(s"r=$r e=$e")
            (r._1+e._1, r._2+e._2)
     }
//def foldLeft[B](z: B)(op: (B, A) => B): B 
ls.foldLeft(0){ (r,e) =>
                println(s"r=$r e=$e")
                r+e
         }
map.foldLeft( ("pre", 0) ){ (r,e) =>
            println(s"r=$r e=$e")
            (r._1+e._1, r._2+e._2)
     }
//sort
// def sortBy[B](f: (A) => B)(implicit ord: math.Ordering[B]): List[A] 
// def sortWith(lt: (A, A) => Boolean): List[A] 
// def sorted[B >: A](implicit ord: math.Ordering[B]): List[A] 
List("a", "bbb", "aa", "x").sorted
//List(a, aa, bbb, x)
List("a", "bbb", "aa", "x").sortBy{ e =>
    e.size} //List(a, x, aa, bbb)
List("a", "bbb", "aa", "x").sortWith{ (a,b) =>
    a.size > b.size}//List(bbb, aa, a, x)
map.toList.sortBy{case (k,v) => k} //based on k 
map.toList.sortBy{case (k,v) => v} //based on v
// def max: A
// def maxBy[B](f: (A) => B): A 
ls.max //3 
map.toList.maxBy{case (k,v) => v}
///HandsOn 
// forall(p: (A) => Boolean): Boolean 
//dropWhile(p: (A) => Boolean): List[A] 
//takeWhile(p: (A) => Boolean): List[A]  
List(1,2,3,1,2).dropWhile( e => e <= 2) 
//List(3,1,2)
List(1,2,3,1,2).takeWhile( e => e <= 2) //List(1, 2)
List(1,2,3).takeWhile( e => e > 1) //List()













///Option[T] 
class Request1{
    import scala.util.Random
    val r = new Random 
    def _get = if (r.nextInt(10) < 5) 
        "   Hello   " else null 
    def get = Option(_get)
}
val ls = (0 to 10).toList.map{ i => 
    (new Request1).get} 
//map 
ls.map{ e => e.map(_.size)}//List[Option[Int]]
ls.flatMap{e => e.map(_.size)} //List[Int]
ls.collect{ case Some(x) => x.size} //List[Int]
//monadic
val o = (new Request1).get
//o: Option[String] = Some(   Hello   )
val o1 = (new Request1).get
//o1: Option[String] = None
o.map(e => e.trim).
  filter(_.size>1).
  map(_.toUpperCase).
  map(_.size).getOrElse(0)
o1.map(e => e.trim).
  filter(_.size>1).
  map(_.toUpperCase).
  map(_.size).getOrElse(0)
///Try[T] 
import scala.util._
class Request2{
    import scala.util.Random
    val r = new Random 
    def _get = if (r.nextInt(10) < 5) 
        42 else 0 
    def get = Try(42/_get)
}
val o = (new Request2).get
//scala.util.Try[Int] = Failure(java.lang.ArithmeticException: / by zero)
val o1 = (new Request2).get
//scala.util.Try[Int] = Success(1)
o.map(_.toString).map(e => e.trim).
  filter(_.size>=1).
  map(_.toUpperCase).
  map(_.size).toOption.getOrElse(0)
o1.map(_.toString).map(e => e.trim).
  filter(_.size>=1).
  map(_.toUpperCase).
  map(_.size).toOption.getOrElse(0)
//list
val ls = (0 to 10).toList.map{ i => 
    (new Request2).get} 
//map 
ls.map{ e => e.map(x => x*x)}//List[Option[Int]]
ls.collect{ case Success(x) => x
            case Failure(ex) => { println(ex);0}
          } //List[Int]

//Exception 
try {
    1/0
} catch {
    case ex:Exception => println(ex)
} finally{
    println("finally")
}


///Stream 
def fib(a:BigInt, b:BigInt):Stream[BigInt] =
    a #:: fib(b, a+b)

fib(0,1).take(20000).toList.last.toString.size //#of digits  of last number 

///Iterator 
class Fib extends Iterator[BigInt]{
    var (a,b) = (0:BigInt, 1:BigInt)
    def hasNext = true 
    def next() = {
        val tmp=a; a=b; b=tmp+b;
        b
    }
}
val f = new Fib 
f.drop(100).take(100).toList 
///View 
val ls = 0 to 100 
ls.view.filter( _ % 2 == 0).map(x => x*x).force
///Par 
val ls = 0 to 10 toList 
ls.par.foreach(println)
ls.par.map(x => x*x).seq.toList 





///HandsOn  - Given a Dir, find out fileName of max size
//recursion, map, filter, sortBy  
Use java.io.File 
listFiles 
    gives you list of files and subdirs
isFile, isDirectory 
    to check whether  it's a file or directory
Then for each file 
    get size(length) and name in a Map 
for each subdir 
    call the same method 
Use accumulator pattern for recursion 
Once you get Map of files and it's size 
sort the map based on it's size 
pick the last element if it's sorted in ascending order 













///Abstract class 
//can have ctor 
abstract class A(val name:String){
    def print:Unit 
    def print2 = println(this.name)
}
class D(name:String) extends A(name) {
    def print = println(this.name)
}
val d2 = new D("OK")
val d = new A("OK"){
    def print = println(this.name)
}
d.print ; d.print2 
///trait 
//can not have ctor 
trait A{
    def name:String 
    def print2 = println(this.name)
}
class D extends A {
    def name = "OK"
    override def print2 = println(s"Hello ${this.name}")
}
val d2 = new D; d2.print2 ; //new implementation
val d = new A{
    def name = "OK"
}
d.print2  //default

//Runtime mixing 
class E 
trait A{
    def name:String 
    def print2 = println(this.name)
}
val e = new E 
val e1 = new E with A {
    def name = "OK"
}
class E1{
    def name = "NOK"
}
trait A2 extends A {
    override def print2 = println(s"Hello ${this.name}")
}
val e2 = new E1 with A 
val e3 = new E1 with A2
//
abstract class D {
    def name:String 
}
trait A{
    self:D => 
    def print2 = println(self.name)
}
class E extends D with A {
    def name:String = "OK"
}
// illegal inheritance;
class E extends A {

}
///Variances 
class A[T]
class A1[+T]
class A2[-T]

val a:A[Int] = new A[Int] //OK 
val a1:A1[Any] = new A1[Int] //OK for + 
val a2:A2[Int] = new A2[Any] //OK for -


//
class C[T]{
    def meth[U](x:T) = ???
}

///Bounds can be on method generic 
class A[T <: AnyVal]
new A[Int]//OK 
new A[String] //NOK 
//
class A1[T >: AnyVal]
new A1[Any] //OK
new A1[Int] //NOK
//
class A2[T >: AnyVal <: Any]
new A2[AnyVal] //OK 
//
class A3[T]
new A3[String] //OK 
//
def meth[T](x:T) =??? //only from scala.Any 

///Existential type 

def get[T](x:List[T]) = x.size 

def get(x:Array[_]) = x.size 
get(Array(1,1,1))//OK
get(Array[Int](1,1,1))//OK

def get(x:Array[Any]) = x.size 
get(Array(1,1,1))//OK
get(Array[Int](1,1,1))//NOK


///implicits - conversion 
"12".toInt 
"AB".toInt(16) //ERROR 

implicit class AB(x:String) {
    def toInt(rx:Int) = Integer.parseInt(x,rx)
}
"AB".toInt(16) //171 

///implicits type 
class A[T]

def meth[T](x:T)(implicit yv:A[T]) = x

meth(2)(new A[Int])  //2

implicit val xyz = new A[Double]
meth(2.0) //OK 
meth(2.0)(new A[Double]) //OK
meth(2)//NOK
implicit val xyz2 = new A[Int]
meth(2)//OK


///type class - Numeric implicits 
//context bound def meth[T : Numeric](x:T) = ...
def meth[T](x:T)( implicit ev:Numeric[T]) ={
    import ev._ 
    x + x 
}

def getsum[T](x:List[T])( implicit ev:Numeric[T])={
    import ev._ 
    x.sum
}










///Future 
import scala.concurrent._ 
import scala.concurrent.duration._ 
import scala.concurrent.ExecutionContext.Implicits.global 
import scala.util._ 
val fut = Future {
    Thread.sleep(1000)
    " Hello  "
    //scala.io.Source.fromURL("http://www.google.co.in").mkString
}
//monadic 
val pf = fut.map{ e => e.trim }.filter(_.size != 0).map{_.size} //Future[Int]
val re = Await.result(pf, Duration.Inf)
//or 
pf.foreach(println)
//or 
pf.onSuccess{ case x: Int => println(x) }
//or 
pf.onComplete{
    case Success(x) => println(x) 
    case Failure(ex) => println(ex) 
}
//Multiple Future 
val pf = for {
    a <- Future( 2*2)
    b <- Future( "hello").mapTo[String]
    c <- Future(a-1) if a > 0 
} yield {
    a * b.size * c 
} //Future[Int]
val re = Await.result(pf, Duration.Inf)

///Akka - Actor 
import akka.actor._
import akka.event.Logging 
import scala.util._ 
import akka.util._ 
import scala.concurrent.duration._ 
import scala.concurrent._ 
import akka.pattern._ 

class MyActor(val a:Option[ActorRef]=None) extends Actor with ActorLogging{
    val own = self.path.toString 
    def receive = {
        case "DOIT" => 
                    log.info(s"$own handling DOIT")
                    sender() ! "RESULT ZERO"
                    a.map{ ref => ref ! "DOIT"}
        case "stop" =>
                    context.stop(self)
        case  x     =>
                    log.info(s"$own cound not handle $x")
    
    }
}
val system = ActorSystem("user")
val aref1 = system.actorOf(Props(new MyActor), "actor1")
aref1 ! "DOIT" //sending message 

val aref2 = system.actorOf(Props(new MyActor(Some(aref1)), "actor2")
aref2 ! "DOIT"
//without sender 
import system.dispatcher
//or 
import scala.concurrent.ExecutionContext.Implicits.global 


implicit val timeout = Timeout(1.second)
(aref1 ? "DOIT").mapTo[String]. //Future[String]
    foreach(println)

///"stop"
aref1 ! "stop"; aref2 ! "stop"
system.terminate







///Json 
libraryDependencies += "com.typesafe.play" %% "play-json" % "2.6.7" 

import play.api.libs.json._ 
import java.io._ 

val in = new FileInputStream(raw"D:\Desktop\PPT\scala\code\recent\jp-sp-sc\toBeShared\data\example.json")
val json = Json.parse(in)
in.close()

//convert to String 
Json.stringify(json)

//from scala type 
Json.toJson(Map("empId" -> 201 ))

//handling 
(json \ 1 \ "empId").as[Int]  //index starts from zero 

//all emp 
val jar = json.as[JsArray]
jar.value.map{ case o:JsObject => (o \ "empId").as[Int]}
//IndexedSeq[Int] = ArrayBuffer(1, 20)
jar.value.map{ case o:JsObject => (o \ "details" \ "firstName").as[String]}

