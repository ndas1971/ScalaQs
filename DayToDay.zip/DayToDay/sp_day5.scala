val lines = sc.textFile(raw"iris.csv")
scala> lines.take(5)
res0: Array[String] = Array(SepalLength,SepalWidth,PetalLength,PetalWidth,Name, 5.1,3.5,1.
4,0.2,Iris-setosa, 4.9,3.0,1.4,0.2,Iris-setosa, 4.7,3.2,1.3,0.2,Iris-setosa, 4.6,3.1,1.5,0
.2,Iris-setosa)

val header = lines.first
val lines2 = lines.filter( _ != header)
lines2.collect
lines.glom().collect()  //res5: Array[Array[String]]

//5.1,3.5,1.4,0.2,Iris-setosa
val iris = lines2.map(x => x.split(",")).  //RDD[Array[String]]
                  map(e => (e.last, e.init.map(_.toDouble))) //RDD[(String, Array[Double])]
       
val un = iris.groupByKey().keys.collect.  //action 
                                toSet.toList
//List[String] = List(Iris-versicolor, Iris-virginica, Iris-setosa)
import org.apache.spark.rdd._ 
import org.apache.spark._ 
class MyPartition(lst:List[String]) extends Partitioner{
    def numPartitions = lst.size 
    def getPartition(k:Any) = 
        lst.indexOf(k.asInstanceOf[String]) % numPartitions
}
val iris2 = iris.groupByKey(new MyPartition(un)) //RDD[(String, Iterable[Array[Double]])]
iris2.getNumPartitions 
iris2.glom().  //RDD[Array[(String, Iterable[Array[Double]])]]
      collect().map(rows => rows(0)._2.size) //Array(50,50,50)

//RDD[(String, Iterable[Array[Double]])] -> RDD[(String, List[Double])]
//def mapPartitions[U](f: (Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U]): RDD[U] 
def func(it:Iterator[(String, Iterable[Array[Double]])]={
    val lst = it.toList(0)  //(String, Iterable[Array[Double]])
    //println(lst)
    List( (lst._1,  //String, key 
           lst._2.toList.map(e => e(0))) //Iterable[Array[Double]] 
         ).iterator
}
val iris3 = iris2.mapPartitions(func, true) //RDD[(String, List[Double])]
//find the max of 1st col 
val iris4 = iris3.map{ case(k,lst) =>
                        (k, Map("max" -> lst.max, "min" -> lst.min))}
                        
scala> iris4.collect
//Map[String,Double])] = Array((Iris-versicolor,Map(max -> 7.0, min -> 4.9)), (Iris-virginica,Map(max -> 7.9, min -> 4.9)), (Iris-setosa,Map(max -> 5.8, min -> 4.3)))



///DF 
spark.sql("set -v").repartition(1).write.
    option("header", true).format("csv").save("conf")
spark.sql("show all functions").repartition(1).write.
    option("header", true).format("csv").save("conf1")
    
import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F}

val df = spark.read.format("json").option("multiLine", "true").
                    load("./input-json")
val jsonSchema = df.schema
    
scala> df.printSchema
root
 |-- details: struct (nullable = true)
 |    |-- address: struct (nullable = true)
 |    |    |-- city: string (nullable = true)
 |    |    |-- postalCode: string (nullable = true)
 |    |    |-- state: string (nullable = true)
 |    |    |-- streetAddress: string (nullable = true)
 |    |-- age: long (nullable = true)
 |    |-- children: array (nullable = true)
 |    |    |-- element: string (containsNull = true)
 |    |-- firstName: string (nullable = true)
 |    |-- isAlive: boolean (nullable = true)
 |    |-- lastName: string (nullable = true)
 |    |-- phoneNumbers: array (nullable = true)
 |    |    |-- element: struct (containsNull = true)
 |    |    |    |-- number: string (nullable = true)
 |    |    |    |-- type: string (nullable = true)
 |    |-- salary: double (nullable = true)
 |    |-- spouse: string (nullable = true)
 |-- empId: long (nullable = true)
    
df.show(truncate=false)
scala> df.rdd.getNumPartitions
res23: Int = 2
    
//for accessing structure , use . 
//for map and array, use (index_or_key)
//F.col(colName) or $"colName" or 'colName (import spark.implicits._)
df.select('empId, $"details.phoneNumbers"(0).alias("phs")). //'
   select("empId", "phs.*").show()
//
+-----+------------+----+
|empId|      number|type|
+-----+------------+----+
|   20|212 555-1234|home|
|    1|212 555-1234|home|
+-----+------------+----+
//complex 
df.select($"empId", F.explode(F.col("details.phoneNumbers")) as "phs").
   select("empId", "phs.*").
   where("type == 'office'").
   select("empId", "number").
   repartition(1).write.
   format("csv").mode("overwrite").
   save("output-csv-from-json")
   
//kafka 
$ zookeeper-server-start.bat  c:\training\zookeeper\conf\zoo.cfg  ///client binds to ..:2181
$ kafka-server-start.bat     c:\training\kafka\config\server.properties   ///server binds to localhost:9092, called broker-list 
$ kafka-console-producer.bat --broker-list localhost:9092 --topic topic1
$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic topicName --from-beginning

    
$ zookeeper-server-start.bat  c:\zookeeper\conf\zoo.cfg  ///client binds to ..:2181
$ kafka-server-start.bat     c:\kafka\config\server.properties   ///server binds to localhost:9092, called broker-list 
$ kafka-console-producer.bat --broker-list localhost:9092 --topic topic1
$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic topicName --from-beginning

    
    

