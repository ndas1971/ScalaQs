package examples 
import org.apache.spark._
import org.apache.spark.rdd._ 

object WordCountRDD{
    def main(args:Array[String]){
        val inputfile = if (args.size >=1) args(0)
                            else "README"
        val conf = new SparkConf().setAppName("wordcount")
        val sc = new SparkContext(conf) //driver entry point
        
        val input = sc.textFile(inputfile) //RDD[String]
        //transformations are lazy
        val words = input.flatMap( _.split(" "))//RDD[String]
        val counts = words.map( w => (w,1)).//RDD[(String,Int)]
                           reduceByKey{(v1,v2) => v1+v2} //RDD[(String,Int)]
        //action is where spark acts 
        counts.collect. //Array[(String,Int)]
            foreach(println)
        sc.stop
    }
}

//spark-submit --class examples.WordCountRDD --master local[*] target/scala-2.11/learning-assembly.jar README