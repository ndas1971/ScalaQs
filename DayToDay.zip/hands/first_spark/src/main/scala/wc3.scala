package examples 
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql.types._ 
import scala.util._ 
import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql.streaming._ 
import scala.concurrent.duration._

object KafkaSourceSink{
    def main(args:Array[String]){
        val spark = SparkSession.builder.appName("wordcount").
                getOrCreate()
        import spark.implicits._ 
        val df = spark.readStream.format("kafka").
                       option("subscribe", "topic1").
                       option("kafka.bootstrap.servers", "localhost:9092").
                       load()
        df.printSchema
        /*
        root
             |-- key: binary (nullable = true)
             |-- value: binary (nullable = true)
             |-- topic: string (nullable = true)
             |-- partition: integer (nullable = true)
             |-- offset: long (nullable = true)
             |-- timestamp: timestamp (nullable = true)
             |-- timestampType: integer (nullable = true)
             */
        //value is column name 
        //2017-08-23T00:00:00.002Z,"mine",20
        val query = df.select('value cast("string")).
                       withColumn("tokens", F.split('value, ",")).
                       withColumn("eventTime", F.to_timestamp('tokens.getItem(0))).
                       withColumn("deviceId", 'tokens.getItem(1).cast("string")).
                       withColumn("signal", 'tokens.getItem(2).cast("int")).
                       select('eventTime, 'deviceId, 'signal).
                       groupBy("deviceId").
                       agg(F.avg("signal").cast("string").as("value")).
                       writeStream.
                       format("kafka").
                       outputMode("update").
                       option("topic", "topicName").
                       option("kafka.bootstrap.servers", "localhost:9092").
                       option("checkpointLocation", "./kafka-stream-1").
                       start()
        query.awaitTermination
        spark.stop
    }    
}
//spark-submit --class examples.KafkaSourceSink --master local[*] target/scala-2.11/learning-assembly.jar 

