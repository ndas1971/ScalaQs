package examples 
import org.apache.spark._
import org.apache.spark.rdd._ 
import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql.streaming._ 
import scala.concurrent.duration._

object WordCountStreaming{
    def main(args:Array[String]){
        val inputDir = if (args.size >=1) args(0)
                            else "stream-in" //Change 
        val spark = SparkSession.builder.
                        appName("wordcount").
                        getOrCreate()
        import spark.implicits._
        val input = spark.readStream.text(inputDir) //CHANGE
        val words = input.select(
            F.split(F.col("value"), " ").alias("words"))
        val counts = words.select(F.explode($"words").as("word"))
        val grp = counts.groupBy('word)//OR $"word" or "word" //'
        //change 
        val query = grp.count.writeStream.
                        outputMode("complete").
                        format("console").
                        option("truncate", false).
                        trigger(Trigger.ProcessingTime(20.seconds)).
                        start()
        query.awaitTermination 
        spark.stop
    }
}

//spark-submit --class examples.WordCountStreaming --master local[*] target/scala-2.11/learning-assembly.jar 










