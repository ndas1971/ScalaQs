package examples 
import org.apache.spark._
import org.apache.spark.rdd._ 
import org.apache.spark.sql._ 
import org.apache.spark.sql.{functions => F}

object WordCountDF{
    def main(args:Array[String]){
        val inputfile = if (args.size >=1) args(0)
                            else "README"
        val spark = SparkSession.builder.
                        appName("wordcount").
                        getOrCreate()
        import spark.implicits._
        val input = spark.read.text(inputfile)
        val words = input.select(
            F.split(F.col("value"), " ").alias("words"))
        val counts = words.select(F.explode($"words").as("word"))
        val grp = counts.groupBy('word)//OR $"word" or "word" //'
        grp.count.collect.foreach(println)
        //SQL
        counts.createOrReplaceTempView("words")       
        val df = spark.sql("""
            select word, count(*) as COUNT from words group by word""")
        df.show(truncate=false)
        spark.stop
    }
}

//spark-submit --class examples.WordCountDF --master local[*] target/scala-2.11/learning-assembly.jar README










