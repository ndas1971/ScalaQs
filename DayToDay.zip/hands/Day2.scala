class Animal(val name:String, val age:Int = 0){
    // def this(name:String) {
        // this(name, 0)
    // }
    def talk = "animal talk"
    def location = "someplace"
    override def toString = s"$name :  $age "
    //other AnyRef's method == etc , you can implement
}
//companion object if both are in same file 
object Animal{
    def apply(name:String, age:Int) = new Animal(name,age)
    def someMethod = "SomeMethod"
}
//usage
val a = new Animal("xy", 20)
println(a.name) //"xy"
println(a.age) // 20 
a.talk
val b = Animal("gh", 201) //Animal.apply("gh", 201)
//b.name = "xy" //Error as it is val 
Animal.someMethod 
//inheritence
class Dog(name:String,age:Int, val owner:String) 
    extends Animal(name, age) {
    override def talk = s"(${super.talk}) dog talk"
}
val d = new Dog("xy", 20, "fg")
println(d.talk)   //overridden 
println(d.location) //from base class 
println(d) //from base class 
//case class - instead of writing all std AnyRef methods
case class Animal2(name:String, age:Int){ //case class injects this val 
    def talk = "animal talk"
    def location = "someplace"
    //toString created by case class - Animal2(name,age)
}
//there is no companion object 
//case class injects those 
val b2 = Animal2("gh", 201) //Animal2.apply("gh", 201)

//pattern matching 
case class Person(first:String, last:String)
case object Request
def extract(o:Any) = o match {
    case 0 | 1 | 2 => "integer 012"
    case "abc"    => "abc"
    case Request => "request"
    case Person("X", s) => s"Person(X,${s})"
    case Person(first,last) => s"any person $first , $last"
    case List(_,_,_) => "three element list"
    case a @ List(x, y @ _*) => s"$a $x, $y"
    case (x,y) if x == y => "Same element tuple"
    case (x,y) => s"Tuple $x, $y"
    case x:String => s"some string $x"
    case ( (x,y), (a,b), c) => s"complex tuple $c"
    //default 
    case _ => "default"
}
//recursion
def mysum1(x:List[Int]):Int = 
    if (x.isEmpty) 0 else x.head + mysum1(x.tail)
    
def mysum2(x:List[Int]):Int = x match {
    case h :: t => h + mysum2(t)
    case Nil => 0
}

mysum2(0 to 20000 toList)
  
//accumlator pattern - TCO 
def mysum3(x:List[Int], acc:BigInt = 0):BigInt = x match {
    case h :: t => mysum3(t, acc+h)
    case Nil => acc
}  
mysum3(0 to 100000 toList)

// anonymous function
def add(x:Int, y:Int) = x+y
val add1 = (x:Int, y:Int) => x+y
val add2 = add _
add2(2,3)
List( add1, add2, (z:Int,  a:Int) => z -a)
//List[(Int, Int) => Int] = List(<function2>, <functio
type AddType = (Int, Int) => Int
def p(x:Int, f:AddType) = f(x,x)
def p(x:Int, f:(Int, Int) => Int) = f(x,x)
p(20,add1) //40
p(30, (x:Int, y:Int) => x-y) //0 
//alternate form 
def p(x:Int)(f:(Int, Int) => Int) = f(x,x)
p(30){(x:Int, y:Int) => x-y}
//OR 
p(30){_ - _}
//OR 
p(30){(x,y) => x-y }

//partially applied 
def add(x:Int, y:Int) = x+y
add(2, _:Int)  // Int => Int , single arg function 
val a = add(2, _:Int)
a(3) //5 
a(10)//12 
val t = (1,2)
add(t._1, t._2)
//tupling 
(add _).tupled(t) //3
(add _).tupled //((Int, Int)) => Int = <function1>
//currying 
(add _).curried //Int => (Int => Int) = <function1>
(add _).curried(2)(3) //5
//composition 
val dou = (x:Int) => x*x 
val ai = (x:Int) => x+5 
(dou andThen ai)(5) //30 ie ai(dou(5))
(dou compose ai)(5) //100 ie dou(ai(5))
//Partial function
val pf:PartialFunction[Int,Double] = 
    { case x:Int if x != 0   => 1.0/x } 

pf(0)
//scala.MatchError: 0 
pf.isDefinedAt(0) //false
pf.isDefinedAt(1)//true
pf(1)  //Int = 1
val pf1:PartialFunction[Int,Double] = 
    { case x:Int if x == 0   => 0.0 } 
    
val fun:Function[Int,Double] = pf orElse pf1 
//if pf not defined, call pf1
fun(0) //0 
fun(1) // 1

//FP with collection 
val ls = List(1,2,3)
val map = Map("ok" -> 1, "nok" ->2)
//List[A].foreach(f: (A) => Unit): Unit 
def p(x:Int) = println(x)
ls.foreach(p _)
ls.foreach{println _}
//no overloading 
ls.foreach(println)
ls foreach println 
map foreach println //printing tuple of key,value 
//follow below syntax
ls.foreach{ x => println(x)}
ls.foreach{println(_)}
map.foreach{case(k,v) => println(s"$k $v")}
//List[A].map[B](f: (A) => B): List[B] 
ls.map{x => x*x} // List(1, 4, 9)
map.map{case(k,v) => (k, v*v)} //.toMap
//List[A].filter(p: (A) => Boolean): List[A] 
ls.filter{x => x%2 == 0 } // List(2)
map.filter{case(k,v) => v%2 == 0} //Map(nok -> 2)
//List[A].def flatMap[B](f: (A) => List[B]): List[B] 
//flatmap = map + flatten 
ls.flatMap{ x => List(x, x*x, x*x*x)}
//collect = filter+map
ls.filter{x => x%2 == 0 }.map{x => x*x}
ls.collect{case x:Int if x%2 == 0 => x*x}

//List[A].reduce(op: (A, A) => A): A 
ls.reduce{(r,e) => r+e} //sum of all elements 

//foldLeft - reduce with extra zero 
//List[A].foldLeft[B](z: B)(op: (B, A) => B): B 
ls.foldLeft(0){(r,e) => r+e}
map.foldLeft( ("",0) ){ 
    (r,e) => (r._1 + e._1, r._2+e._2)}
    
ls.map{x => x*x} //List(1, 4, 9) 
ls.foldLeft( List[Int]() ) {
    (r,e) => r :+ e*e 
}//List(1, 4, 9)

map.foldLeft( Map[String,Int]() ) {
    (r,e) => r ++ Map(e._1 -> e._2*e._2)
}
    
//sorted, sortBy 
val list = List("x","a", "aaa", "b", "xyz")
list.sorted
list.sortBy{e => e.size} //based on size 
map.toList.sortBy{case(x,y) => y} //value based map sorting 
map.toList.sortBy{case(x,y) => x} //based on key 
//maxBy, minBy 
list.maxBy{e => e.size}
list.minBy{e => e.size}
//groupBy 
list.groupBy{e => e.size}
//Map(1 -> List(x, a, b), 3 -> List(aaa, xyz))
//zip
List('a', 'b').zip(List(10,20))
//List((a,10), (b,20))
//zipWithIndex 
List('a', 'b').zipWithIndex
//List((a,0), (b,1))
//dropWhile, drop, take, takeWhile 
lst.drop(1) //drops first and takes remaining 
lst.take(1) //takes till n element 
//dropWhile, takewhile - HW

/*
https://github.com/ndas1971/scalaQs 
Download "initial-reference.zip"
iris.csv 
*/
val lines = scala.io.Source.
       fromFile("data/iris.csv").
       getLines.toList 
//List of string like 4.9,3.0,1.4,0.2,Iris-setosa
val lines2 = lines.drop(1).
     map{_.split(",")}.
     map{ arr =>
        (arr.slice(0,4).map(_.toDouble),arr.last)}.
     map{case (Array(a,b,c,d),e) => (a,b,c,d,e)}
        
case class Row(sl:Double,sw:Double,
               pl:Double, pw:Double , name:String)
               
val rows = lines2.map{t => (Row.apply _).tupled(t)}              
//List[Row]
val un = rows.map(_.name).toSet 
//Set(Iris-setosa, Iris-versicolor, Iris-virginica)
//for each name, what is max SepalLength 
rows.groupBy(_.name).
     map{ case(n,lst) => (n -> lst.map(_.sl).max)}
//Map(Iris-virginica -> 7.9, Iris-setosa -> 5.8, Iris-versicolor -> 7.0)
rows.groupBy(_.name).
     map{ case(n,lst) => 
        (n -> Map("sl" -> lst.map(_.sl).max,
                   "sw" -> lst.map(_.sw).max))}
//Iris-versicolor -> Map(sl -> 7.0, sw -> 3.4) ....

//DB 
Class.forName("org.sqlite.JDBC")
case class Row(sl:Double,sw:Double,
               pl:Double, pw:Double , name:String){
    override def toString = s"""($sl,$sw,$pl,$pw,"$name")"""
    def toSql = s"insert into iris values ${this.toString}"
}    
val lines = scala.io.Source.
       fromFile("data/iris.csv").
       getLines.toList 
//List of string like 4.9,3.0,1.4,0.2,Iris-setosa
val rows = lines.drop(1).
     map{_.split(",")}.
     map{ arr =>
        (arr.slice(0,4).map(_.toDouble),arr.last)}.
     map{case (Array(a,b,c,d),e) => (a,b,c,d,e)}.
     map{t => (Row.apply _).tupled(t)} 
//JDBC 
import java.sql.{Array => JArray, _} //???
val con = DriverManager.getConnection("jdbc:sqlite:iris.db")
val stmt = con.createStatement()
stmt.executeUpdate("drop table if exists iris")
stmt.executeUpdate("""create table iris (sl double,
    sw double, pl double, pw double, name string)""")
rows.map(_.toSql).foreach(stmt.executeUpdate)
val rs = stmt.executeQuery("select count(*) from iris")
while(rs.next()){
    println(s"${rs.getInt(1)}")
}

def it[T](rs:ResultSet)(f: ResultSet=>T)= new Iterator[T]{
    def hasNext = rs.next()
    def next() = f(rs)
}
val rs = stmt.executeQuery("""
    select name, max(sl) from iris group by name""")
it(rs){
    r => (r.getString(1), r.getDouble(2))
}.toList
//List((Iris-setosa,5.8), (Iris-versicolor,7.0), (Iris-virginica,7.9))
con.close()
