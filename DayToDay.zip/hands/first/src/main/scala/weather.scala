package first
import java.net.URLEncoder

class ScalaWeather(var location:String ,
                    private val unit:String,
                    private val json:Boolean = true ){                   
    override def toString = s"ScalaWeather(${location})"
    private val url = "http://weatherapi1971.pythonanywhere.com/query.yahooapis.com/v1/public/yql"
    def encode = s"select* from weather.forecast where woeid in (select woeid from geo.places(1) where text='${location}') and u='${unit}'"
    def base_url = s"""${url}?q=${URLEncoder.encode(encode, "UTF-8")}"""
    def full_url = s"""${base_url}&format=${if (json) "json" else "xml"}"""
    println(full_url)
    def get = scala.io.Source.fromURL(full_url).mkString                    
}
object Main2 /*extends App*/{
    def main(args: Array[String]){
        val location = args(0)
        val w = new ScalaWeather(location, "c")
        println(w.get)
    }
}
// sbt assemby 
//java -cp target\scala-2.11\learning-assembly.jar first.Main2 mumbai