package support

object Stub {
  def main(args: Array[String]) {
   // do something
   args foreach println
  }
}

class Stub {
  // do something
}
