// https://github.com/ndas1971/scalaQs 
//Download again initial-reference.zip

//Option(x) generates either Some(x) or None if null
class Request{
    import scala.util.Random
    val r = new Random 
    def _get = if (r.nextInt(10) < 5) "Hello" else null
    def get = Option(_get)    
}
val r = new Request
r.get.map{o =>o.toUpperCase}.
      map{_.size}.
      filter{n => n > 1}.
      getOrElse(0)
//Try 
try {
    1/0
} catch {
    case ex:Exception => println(ex)
}
import scala.util._ 
class Request{
    import scala.util.Random
    val r = new Random 
    def _get = if (r.nextInt(10) < 5) "Hello" 
                   else throw new Exception("Error!!")
    def get = Try(_get)//returns Success(x) or Failure(exception)
}
val r = new Request
r.get.map{o =>o.toUpperCase}.
      map{_.size}.filter{n => n > 1}.
      toOption.getOrElse(0)
//Iterator 

class Fib extends Iterator[BigInt]{
    var (a,b) = (BigInt(0), BigInt(1))
    def hasNext = true 
    def next = {
        val tmp = a 
        a = b 
        b = tmp + b
        b
    }
}     
val it = new Fib 
val nos = it.map{_.toString}.map{_.size} //Lazy 
it.take(10)
it.take(10).toList
it.drop(10).take(10).toList //force it 
nos.drop(20000).take(1).toList
      
//par 
0 to 10 foreach println 
(0 to 10).par.foreach(println)
(0 to 10).par.map{2*_}.seq.foreach(println)

//trait
trait A{
    def name:String
    def print2 = println(this.name)
}
trait B{
    def age:Int
    def print2 = println(this.age)
} 
class D extends A with B /* with C with D */{
    def name = "OK"
    def age = 10 
    //option if you want to change trait default implementation
    //override def print2 = println("from D")
    override def print2 = super[B].print2
}   
val d = new D 
d.print2  
//runtime mixing 
class E //dont have access source code of E 
val e = new E with A{
    def name = "NOK"
}  
e.print2    

val e = new E with A with B{
    def name = "NOK"
    def age = 10 
    override def print2 = super[B].print2
}    
e.age 
//variance 
//Array[T], List[+T]
val l:Array[AnyVal] = Array[Int](1,2,3) //Error 
val l:List[AnyVal] = List[Int](1,2,3) //OK 
//C[T] means you must pass always C[T]
//C[+T] means you can pass C[T'] if T' is subtype of T 
//C[-T] means you can pass C[T''] if T'' is supertype of T   

//C[T] means you can always pass C'[T] is C' is subtype of C
val l:Seq[Int] = List[Int](1,2,3) 
      
//type bound 
class A[T <: AnyVal] //Upper bound 
new A[Int]

class A[T >: AnyVal] //Lower Bound
new A[Any]

class A[T >: AnyVal <: Any] //Lower and upper bound 
new A[AnyVal]

def s[T](x:Array[T]) = x.size 
//OR 
def s(x:Array[_]) = x.size
//but not same as below 
def s1(x:Array[Any]) = x.size

//implicits 
//Extending already existing class 
class Conv(x:String){
    def toInt(rx:Int) = Integer.valueOf(x,rx)
}
val x = new Conv("AB")
x.toInt(16)
implicit def ccc(x:String) = new Conv(x)
"AB".toInt(16)
//OR 
implicit class Conv(x:String){
    def toInt(rx:Int) = Integer.valueOf(x,rx)
}
"AB".toInt(16)
//in ur scope , only one implicit for that type must exist 

//for default parameters 
class A[T]
def m(y:Int)(implicit x:A[Int]) = "OK"
m(2)(new A[Int]) //OK 
implicit val x = new A[Int]
m(2)
m(2)(new A[Int]) //this is OK 
//Place-1 
object AllMyImplicits{
    implicit val x = new A[Int]
}

import AllMyImplicits._  //Priority-1
m(2)
//Place-2 
class B[T]
object B{
    implicit val x = new B[Int]
}
def m(y:Int)(implicit x:B[Int]) = "NOK"
m(2)
m(2)(B.x)
//Usage of implicits 
def mean[T](xs:Seq[T])(implicit num:Numeric[T]) = {
    import num._
    xs.sum.toDouble/xs.size 
}
//OR symbol : is called context bound 
//mean: [T](xs: Seq[T])(implicit evidence$1: Numeric[T])
def mean[T : Numeric](xs:Seq[T]) = {
    val num = implicitly[Numeric[T]]
    import num._
    xs.sum.toDouble/xs.size 
}
///xml
val v = <a>OK</a>
//v: scala.xml.Elem = <a>OK</a>
<a>{ 3 + 4 }</a>
val yearMade = 1922
<a>{ if (yearMade == 1922) <old>{yearMade}</old> else xml.NodeSeq.Empty} </a>

//processing 
val xml = scala.xml.XML.loadFile("data/example.xml")
xml \ "country" \ "rank"
//NodeSeq(<rank>1</rank>, <rank>4</rank>, <rank>68</rank>)
xml \ "country" \ "rank" map{_.text} //List(1,...)
(xml \ "country")(0) \ "rank" 

// \ only for children 
// \\ for all descendents 
xml \\ "rank" map{_.text}
xml \ "country" map{_ \ "@name" text} //all country names 
xml \ "country" map{ n => ( (n \ "@name").text , 
    (n \ "neighbor").map{_ \ "@name" text}) }
//(Liechtenstein,List(Austria, Switzerland))
//OR
xml \ "country" map{ n => ( (n \@ "name") , 
    (n \ "neighbor").map{_ \@ "name"}) }
//Sum of gdppc
xml \\ "gdppc" map{_.text.toInt} reduce{(r,e) => r+e} //214600

//json 
import com.fasterxml.jackson.databind._
import com.fasterxml.jackson.module.scala._
import com.fasterxml.jackson.module.scala.experimental._
val json = scala.io.Source.fromFile("data/example.json").
                    getLines.mkString 
                    
val mapper = new ObjectMapper() with ScalaObjectMapper
mapper.registerModule(DefaultScalaModule)
val pjson = mapper.readValue[Array[Map[String,Object]]](json)
// Array(Map(empId -> 1, details -> Map(....)))

implicit class Convert(x:Any){
    def as[T] = x.asInstanceOf[T]
}
pjson.map{_("empId").as[Int]} //Array[Int] = Array(1, 20)
//Give Me fullName of all records 
pjson.map{e => e("details").as[Map[String,Object]]("firstName").
    as[String] +
    e("details").as[Map[String,Object]]("lastName").as[String]}

//Give me all office phone numbers 
pjson.flatMap{e => 
    e("details").as[Map[String,Object]]("phoneNumbers").
        as[List[Map[String,String]]].
        //filter{ m => m("type") == "office"}.
        //map{m => m("number")}
        collect{ 
          case m:Map[String,String] if m("type") == "office" => 
                m("number")
        }
    }
//Array(646 555-4567, 646 555-4567)
//Future 

import scala.concurrent._ 
import scala.concurrent.duration._ 
import scala.concurrent.ExecutionContext.Implicits.global
val fut = Future{
    Thread.sleep(100)
    "Hello"
}
fut.foreach(println)
val fut = Future{
    Thread.sleep(100)
    "Hello"
}
//all clauses work on future only when it is available 
val fut2 = fut.map{o =>o.toUpperCase}.
      map{_.size}.filter{n => n > 1} //returns another Future
val rs = Await.result(fut2, Duration.Inf)
fut2.onSuccess{ case x:Int => println(x)}
import scala.util._ 
fut2.onComplete{
    case Success(x) => println(x)
    case Failure(ex) => println(ex)    
}
val fut = for {
    a <- Future{ Thread.sleep(100); 2*2}
    b <- Future {Thread.sleep(200); "Hello"}.mapTo[String]
    c <- Future{ a-1 } if b.size > 0
} yield {
    a * b.size *c 
}//Returns Future 
val rs = Await.result(fut, Duration.Inf)

//Spark

















      
      