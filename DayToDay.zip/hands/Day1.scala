//Call by 
def doubleIf(test1 : =>Boolean, test2: =>Boolean, block: =>Unit){
    if (test1 && test2){
        block 
        }
}

val i = 2 
val name = "OK"
doubleIf(i>1, name == "OK", println("Found"))

//new syntax 
def doubleIf(test1 : =>Boolean)(test2: =>Boolean)(block: =>Unit){
    if (test1 && test2){
        block 
        }
}
doubleIf(i>1)(name == "OK"){
        println("Found")
        println("Again FOund")
    }   
    
//How to measure  time of code 
//eg how much time below code takes 
1 to 1000 sum // 1.to(1000).sum
def measure[R](codeblock: =>R)={
    val st = System.nanoTime
    val res = codeblock 
    println(s"taken ${(System.nanoTime - st)/1e06} ms")
    res
}
measure{
   var s = 0
   for (i <- 1 to 10){
        s += (1 to 1000 sum)
    }
   s
}
measure( 1 to 1000 sum)
measure{ scala.io.Source.fromURL(full_url).mkString }
val a = {
  println("OK")
  20
  }


///String 
"OK"
"""Hello
      World"""
raw"\n"
"\n".size
raw"\n".size
val str = "Hello World"
val a = 1
s"text=${str}"  //interplorated string 
f"${a}%d  ${str}%s" //interploration with format specifier 
//print 
prinln(str)  //appends \n 
print(str) //does not append \n 
printf("%s,%d", str, a)
//accessing 
str(0)
str(0) = 'K' //ERROR as string is immutable 
str.size 
for(ch <- str){
    println(ch)
}
str == "OK" //false 
str + " Another string"
"    A  ".trim  //removing leading and trailing whitespaces 
"abc".indexOf("b")
"A:B:C".split(":") //Array[String] = Array(A, B, C) 
// if statement can be assigned to var 
val result = if ( str == "OK"){
                "FOund" } else if ( str != "OK") {
                   "NOT OK" } else { 
                     "totally else " }
                     

//Prob: 
val str = "Hello World Hello"
for ( ch <- str){
    var count = 0 
    for (ch1 <- str){
        if (ch == ch1){
            count += 1
        }
    }
    println(s"$ch - $count")
}
// +  : single element 
// ++ with another collection 
// +:  prepend  
// :+  append 
// .empty[T]
//ARRAY 
val arr = Array(1,2,3,4)
(0 to 10).toArray
Array.empty[Int]
Array[Int]()
arr :+ 10  //append , returns new 
20 +: arr :+ 30 //prepend and append , returns new 
arr(0)
arr(0) = 20
Array[Int]() ++ arr
Array[Int]() + arr // Only + is not present , use :+ 
arr.size 
arr contains 2 //true 
for (i <- arr){
    println(i)
}
arr == Array(1,2,3) // content comparison 
//Tuple 
val t = (1, 2.0, "OK")                 //22 
val t2 = 1 -> 2.3 //or (1, 2.3)
scala> t._1
res91: Int = 1
scala> t._2
res92: Double = 2.0
scala> t._3
res93: String = OK
scala> val (name, age) = t2
name: Int = 1
age: Double = 2.3
val tn = ( (1,2), (1.0, 2.0))
tn._2._2 
//List 
val lst = List(1,2,3)
(0 to 10).toList
List.empty[Int]
List[Int]()
lst :+ 10  //append , returns new 
20 +: lst :+ 30 //prepend and append , returns new 
lst(0)
lst(0) = 20 //Error 
List[Int]() ++ arr
List[Int]() + 10 // Only + is not present , use :+ 
lst.size 
lst contains 2 //true 
for (i <- lst){
    println(i)
}
lst == List(1,2,3)
//List special 
lst.head  // 1 
lst.tail // (2,3)
lst.init //(1,2)
lst.last // 3
val list = 1 :: 2 :: 3 :: Nil 
//mutable List 
val lst = scala.collection.mutable.ListBuffer(1,2,3)
lst(0) = 20 
lst += 30 
lst ++= List(50,60)
//
val lst = List(1,2,3,4)
//val out = List(1,4,9,16)
val out = scala.collection.mutable.ListBuffer[Int]()
for ( e <- lst){
    out += e*e 
}
out.toList
//Set 
List(1,1,1,2).toSet.toList
val set1 = Set(1,2,3)
val set2 = scala.collection.mutable.Set(2,3,4)
set1.size 
set1 contains 3 
for (e <- set1) println(e)
set1 + 20 
set2.add(30)
set1 - 20  //remove 
//intersection, union, diff 
set1 & set2 
set1 | set2 
set1 &~ set2 
//Map 
val map1 = Map("Ok" -> 2, "Nok" -> 3)
val em = Map[String,Int]()
val map2 = scala.collection.mutable.Map("Ok" -> 2)
map1.size 
map1 contains "Ok"
for( (k,v) <- map1) println(s"$k $v")
//Accessing 
map1("Ok")
map2("nok") = 20 //first time, key creation 
map2("nok") = 40 // next time onwards, update old value 
//Update 
map1 ++ Map("new" -> 3)
map1 + ("nko" -> 50)
map2 += ("nko" -> 50)
//deletion with key 
map2 -= "nko" 
map1.keys 
map2.values 
map1.toList // List of Tuple of Key and Value 
val str = "Hello World Hello"
for ( ch <- str){
    var count = 0 
    for (ch1 <- str){
        if (ch == ch1){
            count += 1
        }
    }
    println(s"$ch - $count")
}

val out = scala.collection.mutable.Map[Char, Int]()
val str = "Hello World Hello"
for ( ch <- str){
    if (out contains ch){
        out(ch) += 1
    } else {
        out(ch) = 1
    }
}












