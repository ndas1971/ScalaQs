//RDD
sc.defaultParallelism//Int = 4
val lines = sc.textFile("data/iris.csv")
lines.getNumPartitions//Int = 2
val lines = sc.textFile("data/iris.csv", 8)
lines.getNumPartitions//Int = 8
lines.glom().collect //Array[Array[String]]
val lines2 = lines.coalesce(4)
lines2.getNumPartitions
lines2.take(5)
lines.count
val iris1 = lines.zipWithIndex().
    filter{case (e,i) => i !=0}.
    map{case (e,i) => e.split(",")}
iris1.toDebugString
val iris1 = lines.zipWithIndex().map{case(e,i) => (i,e)}
iris1.collect
iris1.getNumPartitions

//CoGroup 
RDD[(K,V)].cogroup[W](other: RDD[(K, W)))
    :RDD[(K, (Iterable[V], Iterable[W)))]


val x = sc.parallelize(Array( ("a", 1), ("b",4))).coalesce(2)
val y = sc.parallelize(Array( ("c", 2), ("a",3))).coalesce(2)
val rdd = x.cogroup(y)
rdd.toDebugString
(2) MapPartitionsRDD[29] at cogroup at <console>:27 []
 |  CoGroupedRDD[28] at cogroup at <console>:27 []
 +-(2) CoalescedRDD[25] at coalesce at <console>:24 []
 |  |  ParallelCollectionRDD[24] at parallelize at <console>:24 []
 +-(2) CoalescedRDD[27] at coalesce at <console>:24 []
    |  ParallelCollectionRDD[26] at parallelize at <console>:24 []

rdd.collect()
rdd.map{case(k, (lst1,lst2)) => }
RDD[(K,V)].aggregateByKey[U](zeroValue: U)
    (seqOp: (U, V) => U, combOp: (U, U) => U)
    : RDD[(K, U)]
//Average by key 
//ZeroValue=(0,0), first index =sum, 2ndindex=count 
>>> sc.parallelize(Array((0,1), (0,2), (1,3), (1,4))).
 aggregateByKey((0,0))((u,v)=>(u._1+v, u._2+1), 
 (u1,u2) => (u1._1+u2._1,u1._2+u2._2)).///RDD[Int,(Int,Int)]
 mapValues( t => t._1/t._2.toDouble).collect()
//Array((0,1.5), (1,3.5))    


//DF xml 

$ spark-shell --packages com.databricks:spark-xml_2.11:0.6.0
 
import org.apache.spark.sql.{functions =>F}
import com.databricks.spark.xml._
val df = spark.read.format("xml").option("rowTag","country").
            load("data/example.xml")
            
scala> df.printSchema
root
 |-- _name: string (nullable = true)
 |-- gdppc: long (nullable = true)
 |-- neighbor: array (nullable = true)
 |    |-- element: struct (containsNull = true)
 |    |    |-- _VALUE: string (nullable = true)
 |    |    |-- _direction: string (nullable = true)
 |    |    |-- _name: string (nullable = true)
 |-- rank: long (nullable = true)
 |-- year: long (nullable = true)            
/*
    <country name="Liechtenstein">
        <rank>1</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor name="Austria" direction="E"/>
        <neighbor name="Switzerland" direction="W"/>
    </country>
*/ 
            
import spark.implicits
df.select('_name).show
df.select('rank cast("int") as "rs").show          
 
//select name vs neighbor name 
import org.apache.spark.sql.Row 

//first one 
df.select('_name, 'neighbor(0).getField("_name")).show  
//all             
//Use custom UDF 
val get = F.udf( (arg:scala.collection.mutable.WrappedArray[Row], index:Int) =>{
    arg.map{r => r.getString(index)}
})
df.select('_name, get('neighbor, F.lit(2))).show(truncate=false)
//so on...  
            
///Streaming Note for outputMode
Any query           append, update 
join                append
groupby with WM     append, update, complete(no dropping) 
groupBy             update, complete 
//for sink 
FileSink            append 
kafkaSink           append, update, complete
console             append, update, complete
memory              append, complete (Table name is the queryName)    
            
            
            
 
 

