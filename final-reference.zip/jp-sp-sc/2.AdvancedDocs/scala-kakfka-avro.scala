//https://dzone.com/articles/kafka-avro-scala-example
///*** Avro
//Apache Avro is a language neutral data serialization format. 
//Avro data is described in a language independent schema. 
//The schema is usually written in JSON format 
//and the serialization is usually to binary files 
//although serialization to JSON is also supported.

//build.sbt 
"org.apache.avro"  %  "avro"  %  "1.7.7"


///Schema 
//A schema may be one of: 
    1.A record, mapping field names to field value data; 
    2.An enum, containing one of a small set of symbols; 
    3.An array of values, all of the same schema; 
    4.A map, containing string/value pairs, of a declared schema; 
    5.A union of other schemas; 
    6.A fixed sized binary object; 
    7.A unicode string; 
    8.A sequence of bytes; 
    9.A 32-bit signed int; 
    10.A 64-bit signed long; 
    11.A 32-bit IEEE single-float; or 
    12.A 64-bit IEEE double-float; or 
    13.A boolean; or 
    14.null. 
    
//schema Example 
SCHEMA_STRING="""{
    "namespace": "kakfa-avro.test",
     "type": "record",
     "name": "user",
     "fields":[
         {  "name": "id", "type": "int"},
         {   "name": "name",  "type": "string"},
         {   "name": "email", "type": ["string", "null"]}
     ]
}"""
//instantiate schema as follows:
import org.apache.avro.Schema
import org.apache.avro.Schema.Parser

val schema: Schema = new Schema.Parser().parse(SCHEMA_STRING)

//create an Avro generic record object with instantiated schema 
//and put user data into it.
val genericRecord: GenericRecord = new GenericData.Record(schema)
genericUser.put("id", "1")
genericUser.put("name", "singh")
genericUser.put("email", null)

//to serialize the above generic record object. 
//use Avro binary encoder to encode object into byte array.
val writer = new SpecificDatumWriter[GenericRecord](schema)
val out = new ByteArrayOutputStream()
val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
writer.write(genericUser, encoder)
encoder.flush()
out.close()
val serializedBytes: Array[Byte] = out.toByteArray()


//To define a default value, use the default attribute: 
{
    "type" : "record",
    "name" : "userInfo",
    "namespace" : "my.example",
    "fields" : [{"name" : "age", "type" : "int", "default" : -1}]
}


//To add multiple fields, specify an array in the fields field.  
{
    "type" : "record",
    "name" : "userInfo",
    "namespace" : "my.example",
    "fields" : [{"name" : "username", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "age", 
                "type" : "int", 
                "default" : -1},

                {"name" : "phone", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "housenum", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "street", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "city", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "state_province", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "country", 
                "type" : "string", 
                "default" : "NONE"},

                {"name" : "zip", 
                "type" : "string", 
                "default" : "NONE"}]
} 

//by using an embedded record: 
{
    "type" : "record",
    "name" : "hatInventory",
    "namespace" : "avro",
    "fields" : [{"name" : "sku", "type" : "string", "default" : ""},
                  {"name" : "description",
                     "type" : {
                         "type" : "record",
                         "name" : "hatInfo",
                         "fields" : [
                                     {"name" : "style", 
                                      "type" : "string", 
                                      "default" : ""},

                                     {"name" : "size", 
                                      "type" : "string", 
                                      "default" : ""},

                                     {"name" : "color", 
                                      "type" : "string", 
                                      "default" : ""},

                                     {"name" : "material", 
                                      "type" : "string", 
                                      "default" : ""}
                            ]}
                }
    ]
}

//Putting some data 
import java.io.File;

import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.Schema;


// Parse our schema file
final Schema.Parser parser = new Schema.Parser();
try {
    parser.parse(new File("HatSchema.avsc"));
} catch (IOException io) {
    io.printStackTrace();
}


// Get two Schema objects. We need two because of the 
// embedded record.
final Schema hatInventorySchema = parser.getTypes().get("avro.hatInventory");
final Schema hatInfoSchema =  parser.getTypes().get("avro.hatInfo");

// Get two GenericRecords so we can manipulate both of
// the records in the schema
final GenericRecord hatRecord =  new GenericData.Record(hatInventorySchema);
final GenericRecord hatInfoRecord = new GenericData.Record(hatInfoSchema);

// Now populate our records. Start with the 
// embedded record.
hatInfoRecord.put("style", "western");
hatInfoRecord.put("size", "medium");
hatInfoRecord.put("color", "black");
hatInfoRecord.put("material", "leather");

// Now the top-level record. Notice that we
// set the embedded record as the value for the 
// description field.
hatRecord.put("sku", "289163009");
hatRecord.put("description", hatInfoRecord);

// Now we need a binding. Only one is required,
// and we use the top-level schema to create it.

//to serialize the above generic record object. 
//use Avro binary encoder to encode object into byte array.
val writer = new SpecificDatumWriter[GenericRecord](hatInventorySchema)
val out = new ByteArrayOutputStream()
val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
writer.write(hatRecord, encoder)
encoder.flush()
out.close()
val serializedBytes: Array[Byte] = out.toByteArray()





//These are the modifications you can safely perform to schema without any concerns: 
//for others check - https://docs.oracle.com/database/nosql-12.1.3.2/GettingStartedGuide/schemaevolution.html
• A field with a default value is added. 
• A field that was previously defined with a default value is removed. 
• A field doc attribute is changed, added or removed. 
• A field order attribute is changed, added or removed. 
• A fields default value is added, or changed. 
• Field or type aliases are added, or removed. 
• A non-union type may be changed to a union that contains only the original type, or vice-versa. 


///* Primitive Data Types
• null 
    No value. 
• boolean 
    A binary value. 
• int 
    A 32-bit signed integer. 
• long 
    A 64-bit signed integer. 
• float 
    A single precision (32 bit) IEEE 754 floating-point number. 
• double 
    A double precision (64-bit) IEEE 754 floating-point number. 
• bytes 
    A sequence of 8-bit unsigned bytes. 
• string 
    A Unicode character sequence. 


//Complex Data Types
record
    A record represents an encapsulation of attributes that, all combined, 
    describe a single thing. 
    The attributes that an Avro record supports are: 
    • type 
        Identifies the JSON field type. 
        For Avro schemas, this must always be record 
        The type record means that there will be multiple fields defined. 
    • namespace 
        This identifies the namespace in which the object lives. 
        It is used to differentiate one schema type from another should they share the same name. 
    • name 
        This is the schema name which, when combined with the namespace, 
        uniquely identifies the schema within the store. 
    • fields 
        This is the actual schema definition. 
        It defines what fields are contained in the value, 
        and the data type for each field. 
        A field can be a simple data type, such as an integer or a string, 
        or it can be complex data. 
        Note that schema field names must begin with [A-Za-z_], 
        and subsequently contain only [A-Za-z0-9_]. 
Enum
    Enums are enumerated types, and it supports the following attributes 
    • name 
        A required attribute that provides the name for the enum. This name must begin with [A-Za-z_], and subsequently contain only [A-Za-z0-9_]. 
    • namespace 
        An optional attribute that qualifies the enum's name attribute. 
    • aliases 
        An optional attribute that provides a JSON array of alternative names for the enum. 
    • doc 
        An optional attribute that provides a comment string for the enum. 
    • symbols 
        A required attribute that provides the enum's symbols as an array of names. These symbols must begin with [A-Za-z_], and subsequently contain only [A-Za-z0-9_]. 
    //For example: 
    { "type" : "enum",
      "name" : "Colors",
      "namespace" : "palette",
      "doc" : "Colors supported by the palette.",
      "symbols" : ["WHITE", "BLUE", "GREEN", "RED", "BLACK"]}
Arrays
    Defines an array field. 
    It only supports the items attribute, which is required. 
    The items attribute identifies the type of the items in the array: 
    {"type" : "array", "items" : "string"}
Maps
    A map is an associative array, or dictionary, 
    that organizes data as key-value pairs. 
    The key for an Avro map must be a string. 
    Avro maps supports only one attribute: values. 
    This attribute is required and it defines the type for the value portion of the map. 
    {"type" : "map", "values" : "int"}
Unions
    A union is used to indicate that a field may have more than one type. 
    They are represented as JSON arrays. 
    For example, suppose you had a field that could be either a string or null. 
    Then the union is represented as: 
    ["string", "null"]
    You might use this in the following way: 
    {
         "type": "record",
         "namespace": "com.example",
         "name": "FullName",
         "fields": [
           { "name": "first", "type": ["string", "null"] },
           { "name": "last", "type": "string", "default" : "Doe" }
         ]
    } 
Fixed
    A fixed type is used to declare a fixed-sized field 
    that can be used for storing binary data. 
    It has two required attributes: 
    the field name, and the size in 1-byte quantities. 
    For example, to define a fixed field that is one megabyte in size: 
    {"type" : "fixed" , "name" : "bdata", "size" : 1048576}

    
    
///*** Zookeeper 
///* Introduction 
//ZooKeeper is a distributed, open-source coordination service for distributed applications. 


//ZooKeeper is replicated over a sets of hosts called an ensemble

//ZooKeeper consists of multiple components.
• Client is the Java client library, used by applications to connect to a ZooKeeper ensemble. 
• Server is the Java server that runs on the ZooKeeper ensemble nodes.


//A name is a sequence of path elements separated by a slash (/)(standard file system. )
//Every node in ZooKeeper name space is identified by a path.

//Unlike is standard file systems, 
//each node in a ZooKeeper namespace can have data associated with it as well as children

//znode : ZooKeeper data nodes
//Znodes maintain a stat structure that includes version numbers for data changes, ACL changes, 
//and timestamps, to allow cache validations and coordinated updates. 


//The data stored at each znode in a namespace is read and written atomically. 

//ZooKeeper also has the notion of ephemeral nodes. 
//These znodes exists as long as the session that created the znode is active. 
//When the session ends the znode is deleted. 

//Zookeeper provides a set of guarantees. These are:
•Sequential Consistency - Updates from a client will be applied in the order that they were sent.
•Atomicity - Updates either succeed or fail. No partial results.
•Single System Image - A client will see the same view of the service regardless of the server that it connects to.
•Reliability - Once an update has been applied, it will persist from that time forward until a client overwrites the update.
•Timeliness - The clients view of the system is guaranteed to be up-to-date within a certain time bound.

//it supports below operations:
create 
    creates a node at a location in the tree
delete 
    deletes a node
exists 
    tests if a node exists at a location
get data 
    reads the data from a node
set data 
    writes data to a node
get children 
    retrieves a list of children of a node
sync 
    waits for data to be propagated



///* Standalone Operation
//Download from https://archive.apache.org/dist/zookeeper/zookeeper-3.4.10/zookeeper-3.4.10.tar.gz
//And unzip and add to PATH bin dir 

//conf/zoo.cfg:
tickTime=2000
dataDir=C:/zookeeper/data
clientPort=2181

//Change the value of dataDir to specify an existing (empty to start with) directory


//start ZooKeeper:
bin/zkServer.cmd start

//CLI to ZooKeeper
bin/zkCli.cmd -server 127.0.0.1:2181

//simple, file-like operations.
Connecting to localhost:2181
log4j:WARN No appenders could be found for logger (org.apache.zookeeper.ZooKeeper).
log4j:WARN Please initialize the log4j system properly.
Welcome to ZooKeeper!
JLine support is enabled
[zkshell: 0] help
ZooKeeper host:port cmd args
        get path [watch]
        ls path [watch]
        set path data [version]
        delquota [-n|-b] path
        quit
        printwatches on|off
        createpath data acl
        stat path [watch]
        listquota path
        history
        setAcl path acl
        getAcl path
        sync path
        redo cmdno
        addauth scheme auth
        delete path [version]
        setquota -n|-b val path

[zkshell: 8] ls /
[zookeeper]
        

//create a new znode by running create /zk_test my_data. 
//This creates a new znode and associates the string "my_data" with the node. You should see:

[zkshell: 9] create /zk_test my_data
Created /zk_test
      
[zkshell: 11] ls /
[zookeeper, zk_test]

[zkshell: 12] get /zk_test
my_data
cZxid = 5
ctime = Fri Jun 05 13:57:06 PDT 2009
mZxid = 5
mtime = Fri Jun 05 13:57:06 PDT 2009
pZxid = 5
cversion = 0
dataVersion = 0
aclVersion = 0
ephemeralOwner = 0
dataLength = 7
numChildren = 0
        
//change the data associated with zk_test by issuing the set command, as in: 

[zkshell: 14] set /zk_test junk
cZxid = 5
ctime = Fri Jun 05 13:57:06 PDT 2009
mZxid = 6
mtime = Fri Jun 05 14:01:52 PDT 2009
pZxid = 5
cversion = 0
dataVersion = 1
aclVersion = 0
ephemeralOwner = 0
dataLength = 4
numChildren = 0
[zkshell: 15] get /zk_test
junk
cZxid = 5
ctime = Fri Jun 05 13:57:06 PDT 2009
mZxid = 6
mtime = Fri Jun 05 14:01:52 PDT 2009
pZxid = 5
cversion = 0
dataVersion = 1
aclVersion = 0
ephemeralOwner = 0
dataLength = 4
numChildren = 0
      
//delete the node by issuing: 

[zkshell: 16] delete /zk_test
[zkshell: 17] ls /
[zookeeper]
[zkshell: 18]

///* Running Replicated ZooKeeper

// a minimum of three servers are required for a fault tolerant clustered setup, 
//and it is strongly recommended that you have an odd number of servers. 
//REF: https://zookeeper.apache.org/doc/r3.4.10/zookeeperStarted.html

//A replicated group of servers in the same application is called a quorum, 
//and in replicated mode, all servers in the quorum have copies of the same configuration file


//*Uasges 
//Can be used to created synchornization primitives over distributed system 
//eg Barriers, locks etc 
https://zookeeper.apache.org/doc/r3.4.10/recipes.html
https://cwiki.apache.org/confluence/display/ZOOKEEPER/Tutorial




///*** Kafka 
//distributed streaming platform
1.It lets you publish and subscribe to streams of records. 
  In this respect it is similar to a message queue or enterprise messaging system. 
2.It lets you store streams of records in a fault-tolerant way. 
3.It lets you process streams of records as they occur. 

//•Kafka is run as a cluster on one or more servers. 
//•The Kafka cluster stores streams of records in categories called topics. 
//•Each record consists of a key, a value, and a timestamp. 

//API 
•The Producer API allows an application to publish a stream of records to one or more Kafka topics. 
•The Consumer API allows an application to subscribe to one or more topics and process the stream of records produced to them. 
•The Streams API allows an application to act as a stream processor, consuming an input stream from one or more topics and producing an output stream to one or more output topics, effectively transforming the input streams to output streams. 
•The Connector API allows building and running reusable producers or consumers that connect Kafka topics to existing applications or data systems. 
 For example, a connector to a relational database might capture every change to a table

//A topic is a category or feed name to which records are published. 
//Topics in Kafka are always multi-subscriber

//For each topic, the Kafka cluster maintains a partitioned log 

//Each partition is an ordered, immutable sequence of records that is continually appended to—a structured commit log. 
//The records in the partitions are each assigned a sequential id number called the offset that uniquely identifies each record within the partition. 

//The Kafka cluster retains all published records—whether or not they have been consumed—using a configurable retention period

//Producers publish data to the topics of their choice. 
//The producer is responsible for choosing which record to assign to which partition within the topic. 
//This can be done in a round-robin fashion simply to balance load or it can be done according to some semantic partition function 

//Consumers label themselves with a consumer group name, 
//and each record published to a topic is delivered to one consumer instance within each subscribing consumer group. 
//Consumer instances can be in separate processes or on separate machines. 

//If all the consumer instances have the same consumer group, 
//then the records will effectively be load balanced over the consumer instances.

//If all the consumer instances have different consumer groups, 
//then each record will be broadcast to all the consumer processes


//At a high-level Kafka gives the following guarantees: 
•Messages sent by a producer to a particular topic partition will be appended in the order they are sent. That is, if a record M1 is sent by the same producer as a record M2, and M1 is sent first, then M1 will have a lower offset than M2 and appear earlier in the log. 
•A consumer instance sees records in the order they are stored in the log. 
•For a topic with replication factor N, kafka will tolerate up to N-1 server failures without losing any records committed to the log. 


///* Usages of Kafka 
Messaging
    Kafka works well as a replacement for a more traditional message broker.

Website Activity Tracking
    The original use case for Kafka was to be able to rebuild a user activity tracking pipeline as a set of real-time publish-subscribe feeds. This means site activity (page views, searches, or other actions users may take) is published to central topics with one topic per activity type. These feeds are available for subscription for a range of use cases including real-time processing, real-time monitoring, and loading into Hadoop or offline data warehousing systems for offline processing and reporting. 

Metrics
    Kafka is often used for operational monitoring data. 
    This involves aggregating statistics from distributed applications to produce centralized feeds of operational data. 

Log Aggregation
    Many people use Kafka as a replacement for a log aggregation solution. Log aggregation typically collects physical log files off servers and puts them in a central place (a file server or HDFS perhaps) for processing

Stream Processing
    Many users of Kafka process data in processing pipelines consisting of multiple stages, where raw input data is consumed from Kafka topics and then aggregated, enriched, or otherwise transformed into new topics for further consumption or follow-up processing

Event Sourcing
    Event sourcing is a style of application design where state changes are logged as a time-ordered sequence of records. Kafka support for very large stored log data makes it an excellent backend for an application built in this style. 

Commit Log
    Kafka can serve as a kind of external commit-log for a distributed system




///* Operations of Kafka - Update PATH with <<install>>\windows\bin and C:\windows\system32\wbem
//https://archive.apache.org/dist/kafka/0.11.0.0/kafka_2.11-0.11.0.0.tgz

//Start the server 

$ zookeeper-server-start.bat  conf/zookeeper.properties  //client binds to ..:2181

$ kafka-server-start.bat conf/server.properties   //server binds to localhost:9092, called broker-list 


//Create a topic
//create a topic named "test" with a single partition and only one replica

$ kafka-topics.bat --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic test
 

//list the topic 

$ kafka-topics.bat  --list --zookeeper localhost:2181
test
 

//Send some messages
//Run the producer and then type a few messages into the console to send to the server.

$ kafka-console-producer.bat --broker-list localhost:9092 --topic test

This is a message
This is another message
 

//Start a consumer
$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic test --from-beginning
This is a message
This is another message
 
//Update producer terminal and check the consumer terminal 


///* Multi broker/server operations 
//https://kafka.apache.org/quickstart#quickstart_multibroker


$ cp config/server.properties config/server-1.properties
$ cp config/server.properties config/server-2.properties
 
//update 
config/server-1.properties:
    broker.id=1
    listeners=PLAINTEXT://:9093
    log.dir=/tmp/kafka-logs-1
 
config/server-2.properties:
    broker.id=2
    listeners=PLAINTEXT://:9094
    log.dir=/tmp/kafka-logs-2
 

//listerns: The address the socket server listens on
//FORMAT: listeners = listener_name://host_name:port
//EXAMPLE:  listeners = PLAINTEXT://your.host.name:9092

//broker.id  :  unique and permanent name of each node in the cluster. 
//by default it is zero 

//override port or log as we are running on single machine 

//start other two nodes 
 
$ kafka-server-start.bat config/server-1.properties &

$ kafka-server-start.bat config/server-2.properties &

 

//create a new topic with a replication factor of three:

$ kafka-topics.bat --create --zookeeper localhost:2181 --replication-factor 3 --partitions 1 --topic my-replicated-topic
 

//run the "describe topics" command:
$ kafka-topics.bat --describe --zookeeper localhost:2181 --topic my-replicated-topic
Topic:my-replicated-topic   PartitionCount:1    ReplicationFactor:3 Configs:
    Topic: my-replicated-topic  Partition: 0    Leader: 1   Replicas: 1,2,0 Isr: 1,2,0
 

//The first line gives a summary of all the partitions, each additional line gives information about one partition. 
//Since we have only one partition for this topic there is only one line.
•"leader" is the node(broker.id) responsible for all reads and writes for the given partition. 
  Each node will be the leader for a randomly selected portion of the partitions. 
•"replicas" is the list of nodes(broker.id) that replicate the log for this partition 
  regardless of whether they are the leader or even if they are currently alive. 
•"isr" is the set of "in-sync" replicas. 
  This is the subset of the replicas list that is currently alive and caught-up to the leader. 

  
//for earlier topic 
$ kafka-topics.bat --describe --zookeeper localhost:2181 --topic test
Topic:test  PartitionCount:1    ReplicationFactor:1 Configs:
    Topic: test Partition: 0    Leader: 0   Replicas: 0 Isr: 0
 

//publish 
$ kafka-console-producer.bat --broker-list localhost:9092 --topic my-replicated-topic
...
my test message 1
my test message 2
^C
 

//consume these messages:

$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --from-beginning --topic my-replicated-topic
...
my test message 1
my test message 2
^C
 

///test out fault-tolerance. Broker 1 was acting as the leader so let's kill it:
 
$ ps aux | grep server-1.properties
7564 ttys002    0:15.91 /System/Library/Frameworks/JavaVM.framework/Versions/1.8/Home/bin/java...
> kill -9 7564
 
//On Windows use: 
> wmic process get processid,caption,commandline | find "java.exe" | find "server-1.properties"
java.exe    java  -Xmx1G -Xms1G -server -XX:+UseG1GC ... "build\libs\kafka_2.11-0.11.0.0.jar"  kafka.Kafka config\server-1.properties    644
> taskkill /pid 644 /f
 

//check now, Leader is 2 now 
 
$ kafka-topics.bat --describe --zookeeper localhost:2181 --topic my-replicated-topic
Topic:my-replicated-topic   PartitionCount:1    ReplicationFactor:3 Configs:
    Topic: my-replicated-topic  Partition: 0    Leader: 2   Replicas: 1,2,0 Isr: 2,0
 

//But the messages are still available for consumption 
$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --from-beginning --topic my-replicated-topic
...
my test message 1
my test message 2
^C
 


///* Use Kafka Connect to import/export data
//Kafka Connect is an extensible tool that runs connectors, 
//which implement the custom logic for interacting with an external system

//create a file, Our external system is File 
 
> echo -e "foo\nbar" > test.txt
 

//create two connectors: the first is a source connector that reads lines from an input file 
//and produces each to a Kafka topic 
//the second is a sink connector that reads messages from a Kafka topic 
//and produces each as a line in an output file. 

$ connect-standalone.bat config/connect-standalone.properties config/connect-file-source.properties config/connect-file-sink.properties

//connect-file-source.properties
name=local-file-source
connector.class=FileStreamSource
tasks.max=1
file=test.txt
topic=connect-test

//connect-file-sink.properties
name=local-file-sink
connector.class=FileStreamSink
tasks.max=1
file=test.sink.txt
topics=connect-test


//verify the data from test.sink.txt
 
> cat test.sink.txt
foo
bar
 

//or run console command to dump 
 
$ kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic connect-test --from-beginning
{"schema":{"type":"string","optional":false},"payload":"foo"}
{"schema":{"type":"string","optional":false},"payload":"bar"}
...
 

//The connectors continue to process data
//Add another line 
//line appear in the console consumer output and in the sink file.
> echo "Another line" >> test.txt
 

///* To enable delete 
//Add one line to server.properties file under config folder:
delete.topic.enable=true


//run this command:
$ kafka-topics.bat --zookeeper localhost:2181 --delete --topic test


///* to stop broker 
$ kafka-server-stop.bat
 

///*** Example using Avro and Kafka
//ProducerApp.scala 
import domain.User
import producer. KafkaProducer

object ProducerApp extends App {

  private val topic = "demo-topic"

  val producer = new KafkaProducer()

  val user1 = User(1, "Sushil Singh", None)
  val user2 = User(2, "Satendra Kumar Yadav", Some("satendra@knoldus.com"))

  producer.send(topic, List(user1, user2))

}

//ConsumerApp.scala 
import consumer.KafkaConsumer

object ConsumerApp extends App {

  val consumer = new KafkaConsumer()

  while (true) {
    consumer.read() match {
      case Some(message) =>
        println("Got message: " + message)

        Thread.sleep(100)
      case _ =>
        println("Queue is empty.......................  ")
        // wait for 2 second
        Thread.sleep(2 * 1000)
    }
  }

}

//domanin.scala 
case class User(id: Int, name: String, email: Option[String])

//Producer.scala 
import java.util.{Properties, UUID}

import org.apache.avro.Schema
import org.apache.avro.Schema.Parser
import domain.User
import org.apache.avro.generic.GenericData
import org.apache.avro.generic.GenericRecord
import org.apache.avro.specific.SpecificDatumWriter
import java.io.ByteArrayOutputStream

import org.apache.avro.io._
import kafka.producer.{KeyedMessage, Producer, ProducerConfig}

import scala.io.Source

class KafkaProducer() {

  private val props = new Properties()

  props.put("metadata.broker.list", "localhost:9092")
  props.put("message.send.max.retries", "5")
  props.put("request.required.acks", "-1")
  props.put("serializer.class", "kafka.serializer.DefaultEncoder")
  props.put("client.id", UUID.randomUUID().toString())

  private val producer = new Producer[String, Array[Byte]](new ProducerConfig(props))

  //Read avro schema file and
  val schema: Schema = new Parser().parse(Source.fromURL(getClass.getResource("/schema.avsc")).mkString)

  def send(topic: String, users: List[User]): Unit = {
    val genericUser: GenericRecord = new GenericData.Record(schema)
    try {
      val queueMessages = users.map { user =>
        // Create avro generic record object
        //Put data in that generic record object
        genericUser.put("id", user.id)
        genericUser.put("name", user.name)
        genericUser.put("email", user.email.orNull)

        // Serialize generic record object into byte array
        val writer = new SpecificDatumWriter[GenericRecord](schema)
        val out = new ByteArrayOutputStream()
        val encoder: BinaryEncoder = EncoderFactory.get().binaryEncoder(out, null)
        writer.write(genericUser, encoder)
        encoder.flush()
        out.close()

        val serializedBytes: Array[Byte] = out.toByteArray()

        new KeyedMessage[String, Array[Byte]](topic, serializedBytes)
      }
      producer.send(queueMessages: _*)
    } catch {
      case ex: Exception =>
        println(ex.printStackTrace().toString)
        ex.printStackTrace()
    }
  }

}


//Consumer.scala 
import java.util.Properties

import domain.User
import org.apache.avro.Schema
import org.apache.avro.io.DatumReader
import org.apache.avro.io.Decoder
import org.apache.avro.specific.SpecificDatumReader
import org.apache.avro.generic.GenericRecord
import org.apache.avro.io.DecoderFactory
import kafka.consumer.{Consumer, ConsumerConfig, ConsumerTimeoutException, Whitelist}
import kafka.serializer.DefaultDecoder

import scala.io.Source


class KafkaConsumer() {
  private val props = new Properties()

  val groupId = "demo-topic-consumer"
  val topic = "demo-topic"

  props.put("group.id", groupId)
  props.put("zookeeper.connect", "localhost:2181")
  props.put("auto.offset.reset", "smallest")
  props.put("consumer.timeout.ms", "120000")
  props.put("auto.commit.interval.ms", "10000")

  private val consumerConfig = new ConsumerConfig(props)
  private val consumerConnector = Consumer.create(consumerConfig)
  private val filterSpec = new Whitelist(topic)
  private val streams = consumerConnector.createMessageStreamsByFilter(filterSpec, 1, new DefaultDecoder(), new DefaultDecoder())(0)

  lazy val iterator = streams.iterator()

  val schemaString = Source.fromURL(getClass.getResource("/schema.avsc")).mkString
  // Initialize schema
  val schema: Schema = new Schema.Parser().parse(schemaString)

  private def getUser(message: Array[Byte]): Option[User] = {

    // Deserialize and create generic record
    val reader: DatumReader[GenericRecord] = new SpecificDatumReader[GenericRecord](schema)
    val decoder: Decoder = DecoderFactory.get().binaryDecoder(message, null)
    val userData: GenericRecord = reader.read(null, decoder)

    // Make user object
    val user = User(userData.get("id").toString.toInt, userData.get("name").toString, try {
      Some(userData.get("email").toString)
    } catch {
      case _ => None
    })
    Some(user)
  }

  /**
    * Read message from kafka queue
    *
    * @return Some of message if exist in kafka queue, otherwise None
    */
  def read() =
    try {
      if (hasNext) {
        println("Getting message from queue.............")
        val message: Array[Byte] = iterator.next().message()
        getUser(message)
      } else {
        None
      }
    } catch {
      case ex: Exception => ex.printStackTrace()
        None
    }

  private def hasNext: Boolean =
    try
      iterator.hasNext()
    catch {
      case timeOutEx: ConsumerTimeoutException =>
        false
      case ex: Exception => ex.printStackTrace()
        println("Got error when reading message ")
        false
    }

  def close(): Unit = consumerConnector.shutdown()

}