Jars targeted to the ${app.home}/lib directory should be placed here.
See lib/README in the distribution package for more details.
