package examples 

// $ spark-submit --class examples.LoadDataIntoMySQL  --driver-class-path mysql-connector-java-5.1.34.jar  --conf spark.executor.extraClassPath=mysql-connector-java-5.1.34.jar  --jars mysql-connector-java-5.1.34.jar --master local[4] target/scala-2.11/learning-assembly.jar

import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

import java.sql.DriverManager




/* Create Table as 
(id, name, phone, email)

CREATE TABLE student (
id INT,
name varchar(200),
phone varchar(50),
email varchar(200),
PRIMARY KEY (id));

*/

object LoadDataIntoMySQL extends App {


  val url = "jdbc:mysql://localhost:3306/spark?user=root&password="

  val spark = SparkSession
      .builder()
      .appName("Loading Data example ")
      .getOrCreate()
  
  val tmp = spark.read.format("csv")
                           .option("sep", "|")
                           .option("header", true)
                           .load(raw"D:\Desktop\PPT\spark\data\StudentDataHeader.csv")
  
  //convert to Int 
  val students = tmp.withColumnRenamed("id", "id2")
                    .withColumn("id", col("id2").cast(IntegerType))
                    .drop("id2")
                    .select("id","name","phone","email") //last select is to reorder

  
  students.foreachPartition { iter=>
      val conn = DriverManager.getConnection(url)
      val statement = conn.prepareStatement("insert into spark.student (id, name, phone, email) values (?,?,?,?) ")
      
      for (eachRow <- iter) {
        statement.setInt(1, eachRow.getInt(0))
        statement.setString(2, eachRow.getString(1))
        statement.setString(3, eachRow.getString(2))
        statement.setString(4, eachRow.getString(3))
        statement.addBatch()
      }
      
      statement.executeBatch()
      conn.close()
      println ("All rows inserted successfully")
  }
  
  spark.stop()
}