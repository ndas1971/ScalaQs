package examples

import org.apache.spark._
import org.apache.spark.SparkContext._

object WordCount {
    def main(args: Array[String]) {
      val inputFile = "README"
      
      val conf = new SparkConf().setAppName("wordCount")  //.setMaster("local[2]")
      // Create a Scala Spark Context.
      val sc = new SparkContext(conf)
      // Load our input data.
      val input =  sc.textFile(inputFile)
      // Split up into words.
      val words = input.flatMap(line => line.split(" "))
      // Transform into word and count.
      val counts = words.map(word => (word, 1)).reduceByKey{case (v1, v2) => v1 + v2} //same key, func for values 
      
      //print
      counts.collect().foreach(println)
    }
}

object WordCountSubmit {
    def main(args: Array[String]) {
      val inputFile = "hdfs://localhost:19000/user/das/README"
      
      val conf = new SparkConf().setAppName("wordCount")
      // Create a Scala Spark Context.
      val sc = new SparkContext(conf)
      // Load our input data.
      val input =  sc.textFile(inputFile)
      // Split up into words.
      val words = input.flatMap(line => line.split(" "))
      // Transform into word and count.
      val counts = words.map(word => (word, 1)).reduceByKey{case (v1, v2) => v1 + v2} //same key, func for values 
      
      //print
      counts.collect().foreach(println)
    }
}