package domain

case class User(id: Int, name: String, email: Option[String])