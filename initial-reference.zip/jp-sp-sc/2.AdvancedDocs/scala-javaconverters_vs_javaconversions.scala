object scala.collection.JavaConversions extends WrapAsScala with WrapAsJava
    A variety of implicit conversions supporting interoperability between Scala and Java collections.
    The following conversions are supported:
        scala.collection.Iterable       <=> java.lang.Iterable
        scala.collection.Iterable       <=> java.util.Collection
        scala.collection.Iterator       <=> java.util.{ Iterator, Enumeration }
        scala.collection.mutable.Buffer <=> java.util.List
        scala.collection.mutable.Set    <=> java.util.Set
        scala.collection.mutable.Map    <=> java.util.{ Map, Dictionary }
        scala.collection.concurrent.Map <=> java.util.concurrent.ConcurrentMap
    In all cases, converting from a source type to a target type 
    and back again will return the original source object:
        import scala.collection.JavaConversions._
        val sl = new scala.collection.mutable.ListBuffer[Int]
        val jl : java.util.List[Int] = sl
        val sl2 : scala.collection.mutable.Buffer[Int] = jl
        assert(sl eq sl2)
    In addition, the following one way conversions are provided:
        scala.collection.Seq         => java.util.List
        scala.collection.mutable.Seq => java.util.List
        scala.collection.Set         => java.util.Set
        scala.collection.Map         => java.util.Map
        java.util.Properties         => scala.collection.mutable.Map[String, String]
    The transparent conversions provided here are considered fragile 
    because they can result in unexpected behavior and performance.
    Therefore, this API has been deprecated and JavaConverters should be used instead. 
    JavaConverters provides the same conversions, but through extension methods. 


object scala.collection.JavaConverters extends DecorateAsJava with DecorateAsScala
    Enables converting between Scala and Java collections using extension methods, asScala and asJava.
    The extension methods return adapters for the corresponding API.
    The following conversions are supported via asScala and asJava:
        scala.collection.Iterable       <=> java.lang.Iterable
        scala.collection.Iterator       <=> java.util.Iterator
        scala.collection.mutable.Buffer <=> java.util.List
        scala.collection.mutable.Set    <=> java.util.Set
        scala.collection.mutable.Map    <=> java.util.Map
        scala.collection.concurrent.Map <=> java.util.concurrent.ConcurrentMap
    The following conversions are supported via asScala 
    and through specially-named extension methods to convert to Java collections, as shown:
        scala.collection.Iterable    <=> java.util.Collection   (via asJavaCollection)
        scala.collection.Iterator    <=> java.util.Enumeration  (via asJavaEnumeration)
        scala.collection.mutable.Map <=> java.util.Dictionary   (via asJavaDictionary)
    In addition, the following one-way conversions are provided via asJava:
        scala.collection.Seq         => java.util.List
        scala.collection.mutable.Seq => java.util.List
        scala.collection.Set         => java.util.Set
        scala.collection.Map         => java.util.Map
    The following one way conversion is provided via asScala:
        java.util.Properties => scala.collection.mutable.Map
    In all cases, converting from a source type to a target type 
    and back again will return the original source object. For example:
        import scala.collection.JavaConverters._
        val source = new scala.collection.mutable.ListBuffer[Int]
        val target: java.util.List[Int] = source.asJava
        val other: scala.collection.mutable.Buffer[Int] = target.asScala
        assert(source eq other)
    Alternatively, the conversion methods have descriptive names and can be invoked explicitly.
        scala> val vs = java.util.Arrays.asList("hi", "bye")
        vs: java.util.List[String] = [hi, bye]
        scala> val ss = asScalaIterator(vs.iterator)
        ss: Iterator[String] = non-empty iterator
        scala> .toList
        res0: List[String] = List(hi, bye)
        scala> val ss = asScalaBuffer(vs)
        ss: scala.collection.mutable.Buffer[String] = Buffer(hi, bye)

    //Methods 
        implicit def asJavaCollectionConverter[A](i: Iterable[A]): AsJavaCollection[A]
            Adds an asJavaCollection method that implicitly converts a Scala Iterable to an immutable Java Collection.
        implicit def asJavaDictionaryConverter[A, B](m: mutable.Map[A, B]): AsJavaDictionary[A, B]
            Adds an asJavaDictionary method that implicitly converts a Scala mutable Map to a Java Dictionary.
        implicit def asJavaIterableConverter[A](i: Iterable[A]): AsJava[java.lang.Iterable[A]]
            Adds an asJava method that implicitly converts a Scala Iterable to a Java Iterable.
        implicit def asJavaIteratorConverter[A](i: Iterator[A]): AsJava[java.util.Iterator[A]]
            Adds an asJava method that implicitly converts a Scala Iterator to a Java Iterator.
        implicit def asScalaBufferConverter[A](l: java.util.List[A]): AsScala[Buffer[A]]
            Adds an asScala method that implicitly converts a Java List to a Scala mutable Buffer.
        implicit def asScalaIteratorConverter[A](i: java.util.Iterator[A]): AsScala[Iterator[A]]
            Adds an asScala method that implicitly converts a Java Iterator to a Scala Iterator.
        implicit def asScalaSetConverter[A](s: java.util.Set[A]): AsScala[mutable.Set[A]]
            Adds an asScala method that implicitly converts a Java Set to a Scala mutable Set.
        implicit def bufferAsJavaListConverter[A](b: Buffer[A]): AsJava[java.util.List[A]]
            Adds an asJava method that implicitly converts a Scala mutable Buffer to a Java List.
        implicit def mapAsJavaMapConverter[A, B](m: Map[A, B]): AsJava[java.util.Map[A, B]]
            Adds an asJava method that implicitly converts a Scala Map to a Java Map.
        implicit def asJavaEnumerationConverter[A](i: Iterator[A]): AsJavaEnumeration[A]
            Adds an asJavaEnumeration method that implicitly converts a Scala Iterator to a Java Enumeration.
        implicit def collectionAsScalaIterableConverter[A](i: Collection[A]): AsScala[Iterable[A]]
            Adds an asScala method that implicitly converts a Java Collection to an Scala Iterable.
        implicit def dictionaryAsScalaMapConverter[A, B](p: Dictionary[A, B]): AsScala[mutable.Map[A, B]]
            Adds an asScala method that implicitly converts a Java Dictionary to a Scala mutable Map.
        implicit def enumerationAsScalaIteratorConverter[A](i: java.util.Enumeration[A]): AsScala[Iterator[A]]
            Adds an asScala method that implicitly converts a Java Enumeration to a Scala Iterator.
        implicit def iterableAsScalaIterableConverter[A](i: java.lang.Iterable[A]): AsScala[Iterable[A]]
            Adds an asScala method that implicitly converts a Java Iterable to a Scala Iterable.
        implicit def mapAsJavaConcurrentMapConverter[A, B](m: concurrent.Map[A, B]): AsJava[ConcurrentMap[A, B]]
            Adds an asJava method that implicitly converts a Scala mutable concurrent.Map to a Java ConcurrentMap.
        implicit def mapAsScalaConcurrentMapConverter[A, B](m: ConcurrentMap[A, B]): AsScala[concurrent.Map[A, B]]
            Adds an asScala method that implicitly converts a Java ConcurrentMap to a Scala mutable concurrent.Map.
        implicit def mapAsScalaMapConverter[A, B](m: java.util.Map[A, B]): AsScala[mutable.Map[A, B]]
            Adds an asScala method that implicitly converts a Java Map to a Scala mutable Map.
        implicit def mutableMapAsJavaMapConverter[A, B](m: mutable.Map[A, B]): AsJava[java.util.Map[A, B]]
            Adds an asJava method that implicitly converts a Scala mutable Map to a Java Map.
        implicit def mutableSeqAsJavaListConverter[A](b: mutable.Seq[A]): AsJava[java.util.List[A]]
            Adds an asJava method that implicitly converts a Scala mutable Seq to a Java List.
         implicit def mutableSetAsJavaSetConverter[A](s: mutable.Set[A]): AsJava[java.util.Set[A]]
            Adds an asJava method that implicitly converts a Scala mutable Set to a Java Set.
        implicit def propertiesAsScalaMapConverter(p: Properties): AsScala[mutable.Map[String, String]]
            Adds an asScala method that implicitly converts a Java Properties to a Scala mutable Map[String, String].
        implicit def seqAsJavaListConverter[A](b: Seq[A]): AsJava[java.util.List[A]]
            Adds an asJava method that implicitly converts a Scala Seq to a Java List.
        implicit def setAsJavaSetConverter[A](s: Set[A]): AsJava[java.util.Set[A]]
            Adds an asJava method that implicitly converts a Scala Set to a Java Set.        
            
        def asJavaCollection[A](i: Iterable[A]): Collection[A]
            Converts a Scala Iterable to an immutable Java Collection.        
        def asJavaDictionary[A, B](m: mutable.Map[A, B]): Dictionary[A, B]
            Converts a Scala mutable Map to a Java Dictionary.
        def asJavaEnumeration[A](i: Iterator[A]): java.util.Enumeration[A]
            Converts a Scala Iterator to a Java Enumeration.
        def asJavaIterable[A](i: Iterable[A]): java.lang.Iterable[A]
            Converts a Scala Iterable to a Java Iterable.
        def asJavaIterator[A](i: Iterator[A]): java.util.Iterator[A]
            Converts a Scala Iterator to a Java Iterator.
        def asScalaBuffer[A](l: java.util.List[A]): Buffer[A]
            Converts a Java List to a Scala mutable Buffer.
        def asScalaIterator[A](i: java.util.Iterator[A]): Iterator[A]
            Converts a Java Iterator to a Scala Iterator.
        def asScalaSet[A](s: java.util.Set[A]): mutable.Set[A]
            Converts a Java Set to a Scala mutable Set.
        def bufferAsJavaList[A](b: Buffer[A]): java.util.List[A]
            Converts a Scala mutable Buffer to a Java List.
        def collectionAsScalaIterable[A](i: Collection[A]): Iterable[A]
            Converts a Java Collection to an Scala Iterable.
        def dictionaryAsScalaMap[A, B](p: Dictionary[A, B]): mutable.Map[A, B]
            Converts a Java Dictionary to a Scala mutable Map.
        def enumerationAsScalaIterator[A](i: java.util.Enumeration[A]): Iterator[A]
            Converts a Java Enumeration to a Scala Iterator.
        def iterableAsScalaIterable[A](i: java.lang.Iterable[A]): Iterable[A]
            Converts a Java Iterable to a Scala Iterable.
        def mapAsJavaConcurrentMap[A, B](m: concurrent.Map[A, B]): ConcurrentMap[A, B]
            Converts a Scala mutable concurrent.Map to a Java ConcurrentMap.
        def mapAsJavaMap[A, B](m: Map[A, B]): java.util.Map[A, B]
            Converts a Scala Map to a Java Map.
        def mapAsScalaConcurrentMap[A, B](m: ConcurrentMap[A, B]): concurrent.Map[A, B]
            Converts a Java ConcurrentMap to a Scala mutable ConcurrentMap.
        def mapAsScalaMap[A, B](m: java.util.Map[A, B]): mutable.Map[A, B]
            Converts a Java Map to a Scala mutable Map.
        def mutableMapAsJavaMap[A, B](m: mutable.Map[A, B]): java.util.Map[A, B]
            Converts a Scala mutable Map to a Java Map.
        def mutableSeqAsJavaList[A](s: mutable.Seq[A]): java.util.List[A]
            Converts a Scala mutable Seq to a Java List.
        def mutableSetAsJavaSet[A](s: mutable.Set[A]): java.util.Set[A]
            Converts a Scala mutable Set to a Java Set.
        def propertiesAsScalaMap(p: Properties): mutable.Map[String, String]
            Converts a Java Properties to a Scala mutable Map[String, String].
        def seqAsJavaList[A](s: Seq[A]): java.util.List[A]
            Converts a Scala Seq to a Java List.
        def setAsJavaSet[A](s: Set[A]): java.util.Set[A]
            Converts a Scala Set to a Java Set.
