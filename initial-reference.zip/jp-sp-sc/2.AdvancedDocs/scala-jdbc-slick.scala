///*** Mysql
//build.sbt 
libraryDependencies += "mysql" % "mysql-connector-java" % "5.1.12"


//Database = - Can use Java classes for DB access

import java.sql.DriverManager
import java.sql.Connection
OR
import java.sql._

"""
You can also use below

Apache DbUtils provides some utility classes surrounding JDBC 

Spring's JDBC integration provides good framework

If you want an ORM (object-relational mapping), then Hibernate is a good choice.

Querulous, SQueryL and OR/Broker that provide Scala-friendly database layers

For non-sql DB, mongoDB, you can use casbah famework

"""



package jdbc

import java.sql.DriverManager
import java.sql.Connection


object ScalaJdbcConnectSelect {

  def main(args: Array[String]) {
    // connect to the database named "mysql" on the localhost
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://localhost/books"
    val username = "root"
    val password = ""

    // there's probably a better way to do this
    var connection:Connection = null

    try {
      // make the connection
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)

      // create the statement, and run the select query
      val statement = connection.createStatement()
      val resultSet = statement.executeQuery("SELECT host, user FROM user")
      while ( resultSet.next() ) {
        val host = resultSet.getString("host")
        val user = resultSet.getString("user")
        println("host, user = " + host + ", " + user)
      }
    } catch {
      case e => e.printStackTrace
    }
    connection.close()
  }

}

///*** sqllite 
//build.sbt 
libraryDependencies += "org.xerial" % "sqlite-jdbc" % "3.21.0.1"



//URL string 
jdbc:sqlite:sqlite_database_file_path
//Example 
jdbc:sqlite:sample.db
jdbc:sqlite:C:/sqlite/db/chinook.db

//To connect to an in-memory database
jdbc:sqlite::memory


//Example 

import java.sql._

object ScalaJdbcConnectSelect {

  def main(args: Array[String]) {
    var connection:Connection = null
    try
    {
      // make the connection
      Class.forName("org.sqlite.JDBC")
      // create a database connection
      connection = DriverManager.getConnection("jdbc:sqlite:sample.db");
      val statement = connection.createStatement();
      statement.setQueryTimeout(30);  // set timeout to 30 sec.

      statement.executeUpdate("drop table if exists person");
      statement.executeUpdate("create table person (id integer, name string)");
      statement.executeUpdate("insert into person values(1, 'leo')");
      statement.executeUpdate("insert into person values(2, 'yui')");
      val rs = statement.executeQuery("select * from person");
      while (rs.next())
      {
        val id = rs.getInt("id")
        val name = rs.getString("name")
        println("id, name = " + id + ", " + name)
      }
    }catch {
      case e => e.printStackTrace
    }
    connection.close()
  }
}

///*** Quick Anorm -  DB parsing from Play 
import java.sql._ 
import anorm._ 
import SqlParser._

Class.forName("org.h2.Driver")
implicit val conn: Connection = DriverManager.getConnection("jdbc:h2:mem:project;MODE=MYSQL;DATABASE_TO_UPPER=FALSE");

SQL("create table emp (id integer primary key, name varchar(30))").execute()
SQL("insert into emp (id, name) values ({id}, {name})").on("id" -> 1, "name" -> "name1").executeUpdate()
SQL("insert into emp (id, name) values ({id}, {name})").on("id" -> 2, "name" -> "name2").executeUpdate()

conn.commit()

val selectAll: SqlQuery = SQL("select id, name from emp")
val all = selectAll.as(int(1) ~ str(2) map(flatten) *)  //flaten converts A ~ B to (A,B)


all.foreach {
row => println(row)
}

case class Emp(id: Int, name: String)
object Emp {
    implicit val EmpR = play.api.libs.json.Json.reads[Emp]
    implicit val EmpW = play.api.libs.json.Json.writes[Emp]
}

val res = SQL("select id,name from emp") as{int(1) ~ str(2) map{
    case id ~ name => Emp(id, name)
} *}

import play.api.libs.json._
Json.prettyPrint(Json.toJson(res))

val simple = {
    get[Int]("emp.id") ~ str("emp.name") map {
      case id ~ name => Emp(id, name)
    }
  }
  
val res1: Either[List[Throwable],Seq[(String, String)]] = SQL"select * from emp order by name".
      fold(Seq.empty[(String, String)], ColumnAliaser.empty) { (acc, row) => // Anorm streaming
        row.as(simple) match {
          case scala.util.Failure(parseErr) => {
            println(s"Fails to parse $row: $parseErr")
            acc
          }
          case scala.util.Success(Emp(id, name)) =>
            (id.toString -> name) +: acc
        }
      }
//Create a Future 
import scala.concurrent._ 
import scala.concurrent.ExecutionContext.Implicits.global

res1 match {
    case Left(err :: _) => Future.failed(err)
    case Left(_) => Future(Seq.empty)
    case Right(acc) => Future.successful(acc.reverse)
  }
res14 foreach println


/// Anorm basics 
///To run a query using anorm you need to do three things:
 1. Connect to the database (with or without a transaction)
 2. Create an instance of `anorm.SqlQuery` using the `SQL` string interpolator
 3. Call one of the methods on `SqlQuery` to actually run the query
 4. In some cases, pass a `ResultSetParser` to dictate how to parse the results.

//Step 1: Connect to the database
//conf/application.conf
db.default.driver=...
db.default.url=...

//Code 

import play.api.db._

// Option A. Connect to the "default" database without a transaction:
DB.withConnection { implicit conn =>
  // query code goes here...
}

// Option B. Connect to another database without a transaction:
DB.withConnection("databaseid") { implicit conn =>
  // query code goes here...
}

// Option A. Connect to the "default" database with a transaction:
DB.withTransaction { implicit conn =>
  // query code goes here...
}

// Option B. Connect to another database with a transaction:
DB.withTransaction("databaseid") { implicit conn =>
  // query code goes here...
}

//Step 2. Create an SqlQuery
import anorm._

// We create the query using the `SQL""` string interpolator:
val query = SQL"select * from mytable;"

// We can embed Scala values in the SQL using the standard `${}` syntax.
// Anorm escapes interpolated values appropriately:

val value = // some scala value
val query = SQL"select * from mytable where mycolumn = ${value};"


//Step 3. Call a method to execute the query
//Each method accepts an implicit `Connection` as a parameter,
//so we can only call them within a call to `withConnection` or `withTransaction`:

// Option A. `query.execute()` executes a query and returns nothing:
DB.withConnection { implicit conn =>
  SQL"""
    update mytable set col1 = $value where col2 = $anotherValue;
  """.execute()
  
  // etc...
}

// Option B. `query.as(...)` executes a query and returns results.
// The argument to `as(...)` is a `ResultSetParser`
DB.withConnection { implicit conn =>
  val rsParser: ResultSetParser[List[MyType]] = // ...

  val results: List[MyType] = SQL"""
    select * from mytable;
  """.as(rsParser)

  // etc...
}

// Option C. `query.executeInsert()` returns an `Option[Long]` primary key...
// assuming your table is set up with an auto-incrementing integer primary key:
DB.withConnection { implicit conn =>
  val newPK: Option[Long] = SQL"""
    insert into mytable (...) values (...);
  """.executeInsert()
  
  // etc...
}

// Option D. `query.executeInsert(...)` returns a primary key of another type.
// The argument to `executeInsert(...)` is a `ResultSetParser` to parse the keys:
DB.withConnection { implicit conn =>
  val rsParser: ResultSetParser[List[MyType]] = // ...

  val newPKs: List[MyType] = SQL"""
    insert into mytable (...) values (...);
  """.executeInsert(rsParser)

  // etc...
}



///Create a `ResultSetParser` to tell Anorm how to parse the results 
//We create `ResultSetParsers` in two steps:
//A. Create a `RowParser` to specify what information is stored in each row.
//B. Call one of four methods on `RowParser` to convert it to a `ResultSetParser` that parses more than one row.

//Step 4A. Create a `RowParser`
//A `RowParser` is a like a Json `Reads` -- it specifies a transformation from untyped data
//(in this case a `java.sql.ResultSet`) to typed Scala data (an `Option` or `List` of domain objects).

// Here is the syntax for creating a `RowParser`:
val myCaseClassParser: RowParser[MyCaseClass] = (
  SqlParser.somemethod1("columnname1") ~
  SqlParser.somemethod2("columnname2") ~
  SqlParser.somemethod3("columnname3") ~
  SqlParser.somemethod4("columnname4") ~
  SqlParser.somemethod5("columnname5") // etc...
) map {
  case columnvalue1 ~ columnvalue2 ~ columnvalue3 ~ columnvalue4 ~ columnvalue5 => // etc...
    MyCaseClass(columnvalue1, columnvalue2, columnvalue3, columnvalue4, columnvalue5) // etc...
}

//`anorm.SqlParser` is an object with a bunch of methods for parsing column data types:
//"columnname" could be columnPosition: Int or columnName: String
//https://www.playframework.com/documentation/2.6.x/api/scala/index.html#anorm.SqlParser$
 - `SqlParser.str("columnname")`  creates a `RowParser[String]`  that parses "columname" as a `String`;
 - `SqlParser.int("columnname")`  creates a `RowParser[Int]`     that parses "columname" as a `Int`;
 - `SqlParser.long("columnname")` creates a `RowParser[Long]`    that parses "columname" as a `Long`;
 - `SqlParser.date("columnname")` creates a `RowParser[Date]`    that parses "columname" as a `Date`;
 - `SqlParser.bool("columnname")` creates a `RowParser[Boolean]` that parses "columname" as a `Boolean`;
 - and so on...
 - `SqlParser.scalar[Type]` creates a `RowParser[Type]` that parses a single-column row,
   no matter what the column name is (useful for "select count(*) ..." style queries).
 - SqlParser.flatten Flattens columns tuple-like ie converts A ~ B ~ C types to (A, B, C) tuple 
    import anorm.SQL
    import anorm.SqlParser.{ long, str, int }
    val tuple: (Long, String, Int) = SQL("SELECT a, b, c FROM Test").
            as(long("a") ~ str("b") ~ int("c") map (SqlParser.flatten) single)
//Example 

val rowParser1: RowParser[Int]    = SqlParser.int("column1") // parses "column1" as an `Int`
val rowParser2: RowParser[String] = SqlParser.str("column2") // parses "column2" as a `String`

val rowParser3: RowParser[~[Int, String]] = rowParser1 ~ rowParser2
//`anorm.~` is a pair-like case class that holds two values with attribute _1 and _2 

val pairLikeThing: Int ~ String = ~(123, "456")

pairLikeThing match {
  case a ~ b =>
    assert(a == 123)
    assert(b == "456")
}

//use of `~` is a method on `RowParser`:
rowParser1 ~ rowParser2
val rowParser3: RowParser[~[A, B]] = rowParser1 ~ rowParser2
val rowParser3: RowParser[A ~ B] = rowParser1 ~ rowParser2
//We can `map` over a `RowParser` to produce a new parser with a different output:
val rowParser4: RowParser[String] = rowParser3.map { valueFromRowParser3 =>
  valueFromRowParser3 match {
    case ~(valueFromRowParser1, valueFromRowParser2) =>
      s"I extracted the integer $valueFromRowParser1 and the string $valueFromRowParser2"
  }
}
//OR 
val rowParser4: RowParser[String] = rowParser3.map { valueFromRowParser3 =>
  valueFromRowParser3 match {
    case valueFromRowParser1 ~ valueFromRowParser2 =>
      s"I extracted the integer $valueFromRowParser1 and the string $valueFromRowParser2"
  }
}
//OR 
val rowParser4: RowParser[String] = rowParser3.map {
  case valueFromRowParser1 ~ valueFromRowParser2 =>
    s"I extracted the integer $valueFromRowParser1 and the string $valueFromRowParser2"
}

//`RowParsers` is that instances of `~(a, b)`can be nested:
val nestedTildes: ~[A, ~[B, C]] = ~(a, ~(b, c))
val nestedTildes: A ~ B ~ C = ~(a, ~(b, c))
nestedTildes match {
  case a ~ b ~ c =>
    // etc...
}

//Step 4B. Turn our `RowParser` into a `ResultSetParser`
//RowParser` states how we want to parse a single row from our results. 

// `rowParser.*` creates a `ResultSetParser` that parses all rows and returns a `List`:
val allRowsParser: ResultSetParser[List[MyCaseClass]] = myCaseClassParser.*

// `rowParser.single` creates a `ResultSetParser` that parses a single row
// (and fails if the result set is empty);
val singleRowParser: ResultSetParser[MyCaseClass] = myCaseClassParser.single

// `rowParser.singleOpt` creates a `ResultSetParser` that parses 0 or 1 rows and returns an `Option`:
val optionalRowParser: ResultSetParser[Option[MyCaseClass]] = myCaseClassParser.singleOpt

//Other Methods 
RowParser[+A] extends (anorm.Row) => anorm.SqlResult[A] 
    def *: ResultSetParser[List[A]]
        Returns possibly empty list parsed from result.
    def +: ResultSetParser[List[A]]
        Returns non empty list parse from result, or raise error if there is no result.
    def <~[B](p: RowParser[B]): RowParser[A]
        Combines this current parser with the one given as argument p, 
        if and only if the current parser can first successfully parse a row, 
        without keeping the values of the parser p.
    def >>[B](f: (A) => RowParser[B]): RowParser[B]
        Alias for flatMap
    def ?: RowParser[Option[A]]
        Returns a row parser for optional column, that will turn missing or null column as None.
    def andThen[A](g: (SqlResult[A]) => A): (Row) => A
    def collect[B](otherwise: String)(f: PartialFunction[A, B]): RowParser[B]
        Returns parser which collects information from already parsed row data using f.
    def compose[A](g: (A) => Row): (A) => SqlResult[A]
    def flatMap[B](k: (A) => RowParser[B]): RowParser[B]
    def map[B](f: (A) => B): RowParser[B]
        Returns a parser that will apply given function f to the result of this first parser.
    def single: ResultSetParser[A]
        Returns a result set parser expecting exactly one row to parse.
    def singleOpt: ResultSetParser[Option[A]]
        Returns a result set parser for none or one parsed row.
    def toString(): String
    def |[B >: A](p: RowParser[B]): RowParser[B]
    def ~[B](p: RowParser[B]): RowParser[~[A, B]]
        Combines this parser on the left of the parser p given as argument.
    def ~>[B](p: RowParser[B]): RowParser[B]
        Combines this current parser with the one given as argument p, 
        if and only if the current parser can first/on left side successfully parse a row, 
        without keeping these values in parsed result.
sealed trait SqlResult[+A] extends AnyRef 
    def flatMap[B](k: (A) => SqlResult[B]): SqlResult[B]
    def fold[B](e: (SqlRequestError) => B, f: (A) => B): B
        Either applies function e if result is erroneous, or function f with successful result if any.
    def map[B](f: (A) => B): SqlResult[B] 


// We can pass any of these `ResultSetParsers` to `as(...)` or `executeInsert(...)` to receive the relevant results:
val allRows: List[MyCaseClass] = 
  SQL"""select * from mytable;""".
  as(allRowsParser)

val firstRow: Option[MyCaseClass] = 
  SQL"""select * from mytable limit 1;""".
  as(optionalRowParser)

val countRows: Int = 
  SQL"""select count(*) from mytable;""".
  as(SqlParser.scalar[Int].single)




///Anorm: Generated parsers using Macro 
//The anorm.macro.debug system property can be set to true (e.g. sbt -Danorm.macro.debug=true ...) 
//to debug the generated parsers.


//The macro namedParser[T] can be used to create a RowParser[T] at compile-time, for any case class T.
import anorm.{ Macro, RowParser }

case class Info(name: String, year: Option[Int])

val parser: RowParser[Info] = Macro.namedParser[Info]  //column names must be same as case class attributes 
/* Generated as:
get[String]("name") ~ get[Option[Int]]("year") map {
  case name ~ year => Info(name, year)
}
*/

val result: List[Info] = SQL"SELECT * FROM list".as(parser.*)

//The similar macros indexedParser[T] and offsetParser[T] are available 
//to get column values by positions instead of names.

import anorm.{ Macro, RowParser }

case class Info(name: String, year: Option[Int])

val parser1: RowParser[Info] = Macro.indexedParser[Info]
/* Generated as:
get[String](1) ~ get[Option[Int]](2) map {
  case name ~ year => Info(name, year)
}
*/

val result1: List[Info] = SQL"SELECT * FROM list".as(parser1.*)

// With offset
val parser2: RowParser[Info] = Macro.offsetParser[Info](2)
/* Generated as:
get[String](2 + 1) ~ get[Option[Int]](2 + 2) map {
  case name ~ year => Info(name, year)
}
*/

val result2: List[Info] = SQL"SELECT * FROM list".as(parser2.*)

//To indicate custom names for the columns to be parsed, the macro parser[T](names) can be used.
import anorm.{ Macro, RowParser }

case class Info(name: String, year: Option[Int])

val parser: RowParser[Info] = Macro.parser[Info]("a_name", "creation")
/* Generated as:
get[String]("a_name") ~ get[Option[Int]]("creation") map {
  case name ~ year => Info(name, year)
}
*/

val result: List[Info] = SQL"SELECT * FROM list".as(parser.*)

//It�s also possible to configure the named parsers using a naming strategy 
//for the corresponding columns.
//A custom column naming can be defined using ColumnNaming(String => String).

import anorm.{ Macro, RowParser }, Macro.ColumnNaming

case class Info(name: String, lastModified: Long)

val parser: RowParser[Info] = Macro.namedParser[Info](ColumnNaming.SnakeCase)
/* Generated as:
get[String]("name") ~ get[Long]("last_modified") map {
  case name ~ year => Info(name, year)
}
*/



//The RowParser exposed in the implicit scope can be used as nested one generated by the macros.
case class Bar(lorem: Float, ipsum: Long)
case class Foo(name: String, bar: Bar, age: Int)

import anorm._

// nested parser
implicit val barParser = Macro.parser[Bar]("bar_lorem", "bar_ipsum")

val fooBar = Macro.namedParser[Foo] 
/* generated as:
  get[String]("name") ~ barParser ~ get[Int]("age") map {
    case name ~ bar ~ age => Foo(name, bar, age)
  }
*/

val result: Foo = SQL"""SELECT f.name, age, bar_lorem, bar_ipsum 
  FROM foo f JOIN bar b ON f.name=b.name WHERE f.name=${"Foo"}""".
  as(fooBar.single)

//A row parser for sealed trait can be generated by the macro sealedParser.
import anorm._

sealed trait Family
case class Bar(v: Int) extends Family
case object Lorem extends Family

// First, RowParser instances for all the subtypes must be provided,
// either by macros or by custom parsers
implicit val barParser = Macro.namedParser[Bar]
implicit val loremParser = RowParser[Lorem.type] {
  anyRowDiscriminatedAsLorem => Success(Lorem)
}

val familyParser = Macro.sealedParser[Family]

// Generate a parser as following...
//a column named �classname� is expected to specify the fully qualified name of a subtype 
//(e.g. scalaguide.sql.MacroFixtures.Bar for the child case class Bar).
val generated: RowParser[Family] =
  SqlParser.str("classname").flatMap { discriminator: String =>
    discriminator match {
      case "scalaguide.sql.MacroFixtures.Bar" =>
        implicitly[RowParser[Bar]]

      case "scalaguide.sql.MacroFixtures.Lorem" =>
        implicitly[RowParser[Lorem.type]]

      case (d) => RowParser.failed[Family](Error(SqlMappingError(
        "unexpected row type \'%s\'; expected: %s".format(d, "scalaguide.sql.MacroFixtures.Bar, scalaguide.sql.MacroFixtures.Lorem")
      )))
    }
  }



//The discriminator strategy can be customized.
import anorm._

// Defines the name of the discriminator column according the family name;
// There use "foo" as column name for any family
val naming = DiscriminatorNaming(_ => "foo")

// How to use the name of each family type as a discriminator value;
// There "type:<type-name>"
val discriminate = Discriminate { t => s"type:$t" }

val familyParser = Macro.sealedParser[Family](naming, discriminate)


///ToParameterList
//to define more complete encoders for parameters, for example encoder for a case case.

import anorm.{ Macro, SQL, ToParameterList }
import anorm.NamedParameter, NamedParameter.{ namedWithString => named }

case class Bar(v: Int)

// Convert all supported properties as parameters 
implicit val barToParams: ToParameterList[Bar] = Macro.toParameters()

// Custom-manual statement using-knowing class properties order
SQL("INSERT INTO table(col_w) VALUES({v})").bind(Bar(1)) // bind as param using implicit barToParams



//More Example 
// Convert all supported properties as parameters
val toParams1: ToParameterList[Bar] = Macro.toParameters[Bar]

val params1: List[NamedParameter] = toParams1(bar1) // --> List(NamedParameter(v,ParameterValue(1)))

val names1: List[String] = params1.map(_.name)// --> List(v)

val placeholders = names1.map { n => s"{$n}" } mkString ", "// --> "{v}"

val generatedStmt = s"""INSERT INTO bar(${names1 mkString ", "}) VALUES ($placeholders)"""
val generatedSql1 = SQL(generatedStmt).on(params1: _*)

//Using Macro.ParameterProjection is possible to customize the parameter names, 
//instead of using the names of the class properties by default.

// Convert only `v` property as `w`
implicit val toParams2: ToParameterList[Bar] = Macro.toParameters(
  Macro.ParameterProjection("v", "w"))

toParams2(bar1)
// --> List(NamedParameter(w,ParameterValue(1)))

val insert1 = SQL("INSERT INTO table(col_w) VALUES ({w})").
  bind(bar1) // bind bar1 as params implicit toParams2

//Nested Class 
case class Foo(n: Int, bar: Bar)

val foo1 = Foo(2, bar1)

// For Nested case class
val toParams3: ToParameterList[Foo] =  Macro.toParameters() // uses `toParams2` from implicit scope for `bar` property

toParams3(foo1)
// --> List(NamedParameter(n,ParameterValue(2)), NamedParameter(bar_w,ParameterValue(1)))
// * bar_w = Bar.{v=>w} with Bar instance itself as `bar` property of Foo

import anorm._

val query = SQL("INSERT INTO foo(id, bar) VALUES ({n}, {bar_v})").bind(Foo(1, Bar(2)))

//By default, the nested properties (e.g. Bar.w) are represented using _ as separator, 
//as for bar_w in the previous example. 
//A custom separator can be specified.

// With parameter projection (aliases) and custom separator # instead of the default _
val toParams4: ToParameterList[Foo] =
  Macro.toParameters("#", Macro.ParameterProjection("bar", "lorem"))

toParams4(foo1)
// --> List(NamedParameter(lorem#w,ParameterValue(1)))

//A sealed trait with some known subclasses can also be supported.

sealed trait Family
case class Sub1(v: Int) extends Family
case object Sub2 extends Family

val sealedToParams: ToParameterList[Family] = {
  // the instances for the subclasses need to be in the implicit scope first
  implicit val sub1ToParams = Macro.toParameters[Sub1]
  implicit val sub2ToParams = ToParameterList.empty[Sub2.type]

  Macro.toParameters[Family]
}






///Anorm : Streaming results
//Query results can be processed row per row, not having all loaded in memory.


def fold[T](z: => T)(op: (T, Row) => T)(implicit connection: Connection): Either[List[Throwable], T]
    Aggregates over all rows using the specified operator.
def foldWhile[T](z: => T)(op: (T, Row) => (T, Boolean))(implicit connection: Connection): Either[List[Throwable], T]
    Aggregates over part of or the while row stream, using the specified operator.  
    Boolean = false, stops processing 


//In the following example we will count the number of country rows.
//either it�s the successful Long result (right), or the list of errors (left).
val countryCount: Either[List[Throwable], Long] = 
  SQL"Select count(*) as c from Country".fold(0L) { (c, _) => c + 1 }

//Result can also be partially processed:
val books: Either[List[Throwable], List[String]] = 
  SQL("Select name  from Books").foldWhile(List[String]()) { (list, row) => 
    if (list.size == 100) (list -> false) // stop with `list`
    else (list :+ row[String]("name")) -> true // continue with one more name
  }

//It�s possible to use a custom streaming:
import anorm.{ Cursor, Row }

@annotation.tailrec
def go(c: Option[Cursor], l: List[String]) : List[String] = c match {
  case Some(cursor) => {
    if (l.size == 100) l // custom limit, partial processing
    else {
      go(cursor.next, l :+ cursor.row[String]("name"))
    }
  }
  case _ => l
}

val books: Either[List[Throwable], List[String]] = 
  SQL("Select name from Books").withResult(go(_, List.empty[String]))

//The parsing API can be used with streaming, using RowParser on each cursor .row. 
//The previous example can be updated with row parser.
import scala.util.{ Try, Success => TrySuccess, Failure }

// bookParser: anorm.RowParser[Book]

@annotation.tailrec
def go(c: Option[Cursor], l: List[Book]): Try[List[Book]] = c match {
  case Some(cursor) => {
    if (l.size == 100) l // custom limit, partial processing
    else {
      val parsed: Try[Book] = cursor.row.as(bookParser)

      parsed match {
        case TrySuccess(book) => // book successfully parsed from row
          go(cursor.next, l :+ book)
        case Failure(f) => /* fails to parse a book */ Failure(f)
      }
    }
  }
  case _ => l
}

val books: Either[List[Throwable], Try[List[Book]]] = 
  SQL("Select name from Books").withResult(go(_, List.empty[Book]))

books match {
  case Left(streamingErrors) => ???
  case Right(Failure(parsingError)) => ???
  case Right(TrySuccess(listOfBooks)) => ???
}




///Akka Stream
//The query result from Anorm can be processed as Source with Akka Stream .
libraryDependencies ++= Seq(
  "com.typesafe.play" %% "anorm-akka" % "2.5.1",
  "com.typesafe.akka" %% "akka-stream" % "2.4.4")


//Example 
import java.sql.Connection

import scala.concurrent.Future

import akka.stream.Materializer
import akka.stream.scaladsl.{ Sink, Source }

import anorm._

def resultSource(implicit m: Materializer, con: Connection): Source[String, Future[Int]] = AkkaStream.source(SQL"SELECT * FROM Test", SqlParser.scalar[String], ColumnAliaser.empty)

def countStrings()(implicit m: Materializer, con: Connection): Future[Int] =
  resultSource.runWith(Sink.fold[Int, String](0) { (count, str) => count + str.length })

//It materializes a Future containing either the number of read rows from the source if successful, 
//or the exception if row parsing failed.
//This could be useful to actually close the connection afterwards.
import java.sql.Connection

import scala.concurrent.Future

import akka.stream.Materializer
import akka.stream.scaladsl.{ Sink, Source }

import anorm._

def source(implicit m: Materializer, connection: Connection): Source[String, Future[Int]]#ReprMat[String, Unit] = 
  AkkaStream.source(SQL"SELECT * FROM Test", SqlParser.scalar[String], ColumnAliaser.empty)
    .mapMaterializedValue(_.onComplete { _ =>
      connection.close()
    })




///Anorm: Multi-value support
//Anorm parameter can be multi-value, like a sequence of string.
//In such case, values will be prepared to be passed to JDBC.
// With default formatting (", " as separator)
SQL("SELECT * FROM Test WHERE cat IN ({categories})").
  on('categories -> Seq("a", "b", "c")
// -> SELECT * FROM Test WHERE cat IN ('a', 'b', 'c')

// With custom formatting
import anorm.SeqParameter
SQL("SELECT * FROM Test t WHERE {categories}").
  on('categories -> SeqParameter(
    values = Seq("a", "b", "c"), separator = " OR ", 
    pre = "EXISTS (SELECT NULL FROM j WHERE t.id=j.id AND name=",
    post = ")"))
/* ->
SELECT * FROM Test t WHERE 
EXISTS (SELECT NULL FROM j WHERE t.id=j.id AND name='a') 
OR EXISTS (SELECT NULL FROM j WHERE t.id=j.id AND name='b') 
OR EXISTS (SELECT NULL FROM j WHERE t.id=j.id AND name='c')
*/

//On purpose multi-value parameter must strictly be declared with one of supported types 
//(List, �Seq,Set,SortedSet,Stream,VectorandSeqParameter`).
// Value of a subtype must be passed as parameter with supported:
val seq = IndexedSeq("a", "b", "c")
// seq is instance of Seq with inferred type IndexedSeq[String]

// Wrong
SQL"SELECT * FROM Test WHERE cat in ($seq)"
// Erroneous - No parameter conversion for IndexedSeq[T]

// Right
SQL"SELECT * FROM Test WHERE cat in (${seq: Seq[String]})"

// Right
val param: Seq[String] = seq
SQL"SELECT * FROM Test WHERE cat in ($param)"

//In case parameter type is JDBC array (java.sql.Array), 
//its value can be passed as Array[T], as long as element type T is a supported one.
val arr = Array("fr", "en", "ja")
SQL"UPDATE Test SET langs = $arr".execute()

//A column can also be multi-value if its type is JDBC array (java.sql.Array), 
//then it can be mapped to either array or list (Array[T] or List[T]), 
//provided type of element (T) is also supported in column mapping.
import anorm.SQL
import anorm.SqlParser.{ scalar, * }

// array and element parser
import anorm.Column.{ columnToArray, stringToArray }

val res: List[Array[String]] =
  SQL("SELECT str_arr FROM tbl").as(scalar[Array[String]].*)




///Anorm: Batch update
import anorm.BatchSql

val batch = BatchSql(
  "INSERT INTO books(title, author) VALUES({title}, {author})", 
  Seq[NamedParameter]("title" -> "Play 2 for Scala", 
    "author" -> "Peter Hilton"),
  Seq[NamedParameter]("title" -> "Learning Play! Framework 2", 
    "author" -> "Andy Petrella"))

val res: Array[Int] = batch.execute() // array of update count



///Anorm: Edge cases
//Type of parameter value should be visible, to be properly set on SQL statement.
//Using value as Any, explicitly or due to erasure, leads to compilation error No implicit view available from Any => anorm.ParameterValue.

// Wrong #1
val p: Any = "strAsAny"
SQL("SELECT * FROM test WHERE id={id}").
  on('id -> p) // Erroneous - No conversion Any => ParameterValue

// Right #1
val p = "strAsString"
SQL("SELECT * FROM test WHERE id={id}").on('id -> p)

// Wrong #2
val ps = Seq("a", "b", 3) // inferred as Seq[Any]
SQL("SELECT * FROM test WHERE (a={a} AND b={b}) OR c={c}").
  on('a -> ps(0), // ps(0) - No conversion Any => ParameterValue
    'b -> ps(1), 
    'c -> ps(2))

// Right #2
val ps = Seq[anorm.ParameterValue]("a", "b", 3) // Seq[ParameterValue]
SQL("SELECT * FROM test WHERE (a={a} AND b={b}) OR c={c}").
  on('a -> ps(0), 'b -> ps(1), 'c -> ps(2))

// Wrong #3
val ts = Seq( // Seq[(String -> Any)] due to _2
  "a" -> "1", "b" -> "2", "c" -> 3)

val nps: Seq[NamedParameter] = ts map { t => 
  val p: NamedParameter = t; p
  // Erroneous - no conversion (String,Any) => NamedParameter
}

SQL("SELECT * FROM test WHERE (a={a} AND b={b}) OR c={c}").on(nps :_*) 

// Right #3
val nps = Seq[NamedParameter]( // Tuples as NamedParameter before Any
  "a" -> "1", "b" -> "2", "c" -> 3)
SQL("SELECT * FROM test WHERE (a={a} AND b={b}) OR c={c}").
  on(nps: _*) // Fail - no conversion (String,Any) => NamedParameter


//In some cases, some JDBC drivers returns a result set positioned on the first row 
//rather than before this first row  (e.g. stored procedured with Oracle JDBC driver).

//To handle such edge-case, .withResultSetOnFirstRow(true) can be used as following.
SQL("EXEC stored_proc {arg}").on("arg" -> "val").withResultSetOnFirstRow(true)
SQL"""EXEC stored_proc ${"val"}""".withResultSetOnFirstRow(true)

SQL"INSERT INTO dict(term, definition) VALUES ($term, $definition)".
  withResultSetOnFirstRow(true).executeInsert()
// Also needed on executeInsert for such driver, 
// as a ResultSet is returned in this case for the generated keys




///Using Pattern Matching
//You can also use Pattern Matching to match and extract the Row content. 
//In this case the column name doesn�t matter. 
//Only the order and the type of the parameters is used to match.


import java.sql.Connection
import anorm._

trait Country
case class SmallCountry(name:String) extends Country
case class BigCountry(name:String) extends Country
case object France extends Country

val patternParser = RowParser[Country] {
  case Row("France", _) => Success(France)
  case Row(name:String, pop:Int) if (pop > 1000000) => Success(BigCountry(name))
  case Row(name:String, _) => Success(SmallCountry(name))
  case row => Error(TypeDoesNotMatch(s"unexpected: $row"))
}

def countries(implicit con: Connection): List[Country] =
  SQL("SELECT name,population FROM Country WHERE id = {i}").
    on("i" -> "id").as(patternParser.*)



///Using for-comprehension
//Row parser can be defined as for-comprehension, working with SQL result type. 
//It can be useful when working with lot of column, possibly to work around case class limit.
import anorm.SqlParser.{ str, int }

val parser = for {
  a <- str("colA")
  b <- int("colB")
} yield (a -> b)

val parsed: (String, Int) = SELECT("SELECT * FROM Test").as(parser.single)



///Working with optional/nullable values
//If a column in database can contain Null values, you need to parse it as an Option type.

case class Info(name: String, year: Option[Int])

val parser = str("name") ~ get[Option[Int]]("indepYear") map {
  case n ~ y => Info(n, y)
}

val res: List[Info] = SQL("Select name,indepYear from Country").as(parser.*)


//A nullable parameter is also passed as Option[T], T being parameter base type 
//Passing directly None for a NULL value is not supported, as inferred as Option[Nothing] (Nothing being unsafe for a parameter value). 
//In this case, Option.empty[T] must be used.
SQL("INSERT INTO Test(title) VALUES({title})").on("title" -> Some("Title"))

val title1 = Some("Title1")
SQL("INSERT INTO Test(title) VALUES({title})").on("title" -> title1)

val title2: Option[String] = None
// None inferred as Option[String] on assignment
SQL("INSERT INTO Test(title) VALUES({title})").on("title" -> title2)

// Not OK:
SQL("INSERT INTO Test(title) VALUES({title})").on("title" -> None)

// OK:
SQL"INSERT INTO Test(title) VALUES(${Option.empty[String]})"





///*** Slick -uses Functional Relational Mapping (FRM)

//Check database connection 
//http://slick.lightbend.com/doc/3.0.0/database.html

//Example: with H2 mem database 
//File:build.sbt 
name := "hello-slick"

mainClass in Compile := Some("HelloSlick")

scalaVersion := "2.11.12"

libraryDependencies ++= List(
  "com.typesafe.slick" %% "slick" % "3.0.0",
  "org.slf4j" % "slf4j-nop" % "1.6.4",
  "com.h2database" % "h2" % "1.3.175",
  "org.scalatest" %% "scalatest" % "2.2.4" % "test"
)
//File:src\main\resources\application.conf
h2mem1 = {
  url = "jdbc:h2:mem:test1;MODE=MYSQL;DATABASE_TO_UPPER=FALSE;MVCC=TRUE;LOCK_TIMEOUT=10000;DB_CLOSE_ON_EXIT=FALSE"
  driver = org.h2.Driver
  connectionPool = disabled
  keepAliveConnection = true
}

//File based database URL
driver=org.h2.Driver
url="jdbc:h2:/path/to/db-file"
//username,password 
user="sa"
password=""

//starting H2 web browser 
//https://mvnrepository.com/artifact/com.typesafe/config
//build.sbt 
libraryDependencies += "com.typesafe" % "config" % "1.3.3"

//example
import org.h2.tools.Server
import com.typesafe.config.{ConfigFactory, Config}
val config = ConfigFactory.load()
val usedConfig = config.getConfig("h2mem1") 
val conn = usedConfig.getString("url")
//start browsing 
Server.startWebServer(conn)
//OR 
h2WebServer = Server.createWebServer("-web","-webAllowOthers","-webPort","8082");
h2WebServer.start();
//for serving via TCP 
h2Server = Server.createTcpServer("-tcp", "-tcpAllowOthers", "-tcpPort", "9092");
h2Server.start();

///*** Slick - Quick Introduction

//*STEP-1:import the API for the database
// Use H2Driver to connect to an H2 database
import slick.driver.H2Driver.api._

//Slick�s API is fully asynchronous and runs database call in a separate thread pool. 
import scala.concurrent.ExecutionContext.Implicits.global

//*STEP-2:Database Configuration
h2mem1 = {
  url = "jdbc:h2:mem:test1"
  driver = org.h2.Driver
  connectionPool = disabled
  keepAliveConnection = true
}

val db = Database.forConfig("h2mem1")
try {
  // ...
} finally db.close


//*STEP-3: Schema - http://slick.lightbend.com/doc/3.0.0/schemas.html
//Describe a database schema with Table row classes and TableQuery values for  tables. 
//use http://slick.lightbend.com/doc/3.0.0/code-generation.html to automatically create them 
//or manually by below 

//All columns get a name (in camel case for Scala and upper case with underscores for SQL) 
//and a Scala type (from which the SQL type can be derived automatically). 
//The table object also needs a Scala name, SQL name and type. 
//The type argument of the table must match the type of the special * projection. 

// Definition of the SUPPLIERS table
class Suppliers(tag: Tag) extends Table[(Int, String, String, String, String, String)](tag, "SUPPLIERS") {
  def id = column[Int]("SUP_ID", O.PrimaryKey) // This is the primary key column
  def name = column[String]("SUP_NAME")
  def street = column[String]("STREET")
  def city = column[String]("CITY")
  def state = column[String]("STATE")
  def zip = column[String]("ZIP")
  // Every table needs a * projection with the same type as the table's type parameter
  //sql select would return below in order 
  def * = (id, name, street, city, state, zip)
}

//Note TableQuery is a Query,hence has below methods 
//flatMap, filter, drop, take etc 
val suppliers = TableQuery[Suppliers]

//The foreignKey definition in the coffees table ensures 
//that the supID field can only contain values for which a corresponding id exists in the suppliers table, 
//thus creating an n to one relationship: 
//A Coffees row points to exactly one Suppliers row but any number of coffees can point to the same supplier. 
//This constraint is enforced at the database level.

// Definition of the COFFEES table
class Coffees(tag: Tag) extends Table[(String, Int, Double, Int, Int)](tag, "COFFEES") {
  def name = column[String]("COF_NAME", O.PrimaryKey)
  def supID = column[Int]("SUP_ID")
  def price = column[Double]("PRICE")
  def sales = column[Int]("SALES")
  def total = column[Int]("TOTAL")
  def * = (name, supID, price, sales, total)
  // A reified foreign key relation that can be navigated to create a join
  def supplier = foreignKey("SUP_FK", supID, suppliers)(_.id)
}
val coffees = TableQuery[Coffees]




//*STEP-4:Populating the Database
//TableQuery.schema gives schema and .create would create it , Returns Action
//TableQuery +=(value_tuple), ++=(seq_tuple) to insert data , Returns Action 
//Create a sequence of Actions, by DBIO.seq,  which can be run by db.run() to get a futures 

//Multiple DDL values can be combined with ++ to allow all entities to be created and dropped in the correct order, 
//even when they have circular dependencies on each other.

//Inserting the tuples of data is done with the += and ++= methods, 
//similar to how you add data to mutable Scala collections.

//The .schema.create, += and ++= methods return an Action (can be executed later)
//Use Action.seq(DBIO.seq), which can concatenate any number of Actions, 
//discarding the return values (i.e. the resulting Action produces a result of type Unit). 

//Note other methods on .schema are .create, createIfNotExists, drop, dropIfExists,truncate


val setup = DBIO.seq(
  // Create the tables, including primary and foreign keys
  (suppliers.schema ++ coffees.schema).create,

  // Insert some suppliers
  suppliers += (101, "Acme, Inc.",      "99 Market Street", "Groundsville", "CA", "95199"),
  suppliers += ( 49, "Superior Coffee", "1 Party Place",    "Mendocino",    "CA", "95460"),
  suppliers += (150, "The High Ground", "100 Coffee Lane",  "Meadows",      "CA", "93966"),
  // Equivalent SQL code:
  // insert into SUPPLIERS(SUP_ID, SUP_NAME, STREET, CITY, STATE, ZIP) values (?,?,?,?,?,?)
  
    //Database connections and transactions are managed automatically by Slick. 
    //By default connections are acquired and released on demand and used in auto-commit mode. 
    //In this mode we have to populate the suppliers table first because the coffees data can only refer to valid supplier IDs. 
  
  // Insert some coffees (using JDBC's batch insert feature, if supported by the DB)
  coffees ++= Seq(
    ("Colombian",         101, 7.99, 0, 0),
    ("French_Roast",       49, 8.99, 0, 0),
    ("Espresso",          150, 9.99, 0, 0),
    ("Colombian_Decaf",   101, 8.99, 0, 0),
    ("French_Roast_Decaf", 49, 9.99, 0, 0)
  )
  // Equivalent SQL code:
  // insert into COFFEES(COF_NAME, SUP_ID, PRICE, SALES, TOTAL) values (?,?,?,?,?)
)

//execute the setup Action asynchronously with db.run, yielding a Future[Unit].
val setupFuture = db.run(setup)

//Await for the result 
import scala.concurrent.{Future, Await}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
Await.result(setupFuture, Duration.Inf)

//* Reference of DBIOAction
//A Database I/O Action that can be executed on a database
sealed  trait  DBIOAction[+R, +S <: NoStream, -E <: Effect] extends Dumpable 
R
    The result type when executing the DBIOAction and fully materializing the result.
S
    An encoding of the result type for streaming results. 
    If this action is capable of streaming, it is Streaming[T] for an element type T. 
    For non-streaming DBIOActions it is NoStream.
E
    The DBIOAction effect type, e.g. Effect.Read with Effect.Write. 
    When composing actions, the correct combined effect type will be inferred. 
    Effects can be used in user code, e.g. to automatically direct all read-only Actions 
    to a slave database and write Actions to the master copy.

//StreamingDBIO and DBIO are type aliases 
type  DBIO[+R] = DBIOAction[R, NoStream, All] 
type  StreamingDBIO[+R, +T] = DBIOAction[R, Streaming[T], All] 

//DBIOAction instance methods 
final  def  >>[R2, S2 <: NoStream, E2 <: Effect](a: DBIOAction[R2, S2, E2]): DBIOAction[R2, S2, E with E2] 
    A shortcut for andThen.
def andFinally[E2 <: Effect](a: DBIOAction[_, NoStream, E2]): DBIOAction[R, S, E with E2] 
    Run another action after this action, whether it succeeds or fails, 
    and then return the result of the first action.
def andThen[R2, S2 <: NoStream, E2 <: Effect](a: DBIOAction[R2, S2, E2]): DBIOAction[R2, S2, E with E2] 
    Run another action after this action, if it completed successfully, 
    and return the result of the second action.
def asTry: DBIOAction[Try[R], NoStream, E] 
    Convert a successful result v of this action into a successful result Success(v) 
    and a failure t into a successful result Failure(t).
def cleanUp[E2 <: Effect](f: (Option[Throwable]) ? DBIOAction[_, NoStream, E2], keepFailure: Boolean = true)(implicit executor: ExecutionContext): DBIOAction[R, S, E with E2] 
    Run another action after this action, whether it succeeds or fails, 
    in order to clean up or transform an error produced by this action.
def collect[R2](pf: PartialFunction[R, R2])(implicit executor: ExecutionContext): DBIOAction[R2, NoStream, E] 
    Transform the result of a successful execution of this action, 
    if the given partial function is defined at that value, 
    otherwise, the result DBIOAction will fail with a NoSuchElementException.
def failed: DBIOAction[Throwable, NoStream, E] 
    Return an action which contains the Throwable with which this action failed as its result.
final  def  filter(p: (R) ? Boolean)(implicit executor: ExecutionContext): DBIOAction[R, NoStream, E] 
    Filter the result of this action with the given predicate.
def flatMap[R2, S2 <: NoStream, E2 <: Effect](f: (R) ? DBIOAction[R2, S2, E2])(implicit executor: ExecutionContext): DBIOAction[R2, S2, E with E2] 
    Use the result produced by the successful execution of this action to compute 
    and then run the next action in sequence.
def flatten[R2, S2 <: NoStream, E2 <: Effect](implicit ev: <:<[R, DBIOAction[R2, S2, E2]]): DBIOAction[R2, S2, E with E2] 
    Creates a new DBIOAction with one level of nesting flattened, this method is equivalent to flatMap(identity).
def isLogged: Boolean 
    Whether or not this action should be included in log output by default.
def map[R2](f: (R) ? R2)(implicit executor: ExecutionContext): DBIOAction[R2, NoStream, E] 
    Transform the result of a successful execution of this action.
def named(name: String): DBIOAction[R, S, E] 
    Get a wrapping action which has a name that will be included in log output.
def nonFusedEquivalentAction: DBIOAction[R, S, E] 
    Get the equivalent non-fused action if this action has been fused, otherwise this action is returned.
def withFilter(p: (R) ? Boolean)(implicit executor: ExecutionContext): DBIOAction[R, NoStream, E] 
def withPinnedSession: DBIOAction[R, S, E] 
    Use a pinned database session when running this action.
def zip[R2, E2 <: Effect](a: DBIOAction[R2, NoStream, E2]): DBIOAction[(R, R2), NoStream, E with E2] 
    Run another action after this action, if it completed successfully, 
    and return the result of both actions.
def zipWith[R2, E2 <: Effect, R3](a: DBIOAction[R2, NoStream, E2])(f: (R, R2) ? R3)(implicit executor: ExecutionContext): DBIOAction[R3, NoStream, E with E2] 
    Run another action after this action, if it completed successfully, 
    and zip the result of both actions with a function f, 
    then create a new DBIOAction holding this result, 
    If either of the two actions fails, the resulting action also fails.
//DBIOAction object methods 
def failed(t: Throwable): DBIOAction[Nothing, NoStream, Effect] 
    Create a DBIOAction that always fails.
def fold[T, E <: Effect](actions: Seq[DBIOAction[T, NoStream, E]], zero: T)(f: (T, T) ? T)(implicit ec: ExecutionContext): DBIOAction[T, NoStream, E] 
    Create a DBIOAction that runs some other actions in sequence 
    and combines their results with the given function.
def from[R](f: Future[R]): DBIOAction[R, NoStream, Effect] 
    Convert a Future to a DBIOAction.
def seq[E <: Effect](actions: DBIOAction[_, NoStream, E]*): DBIOAction[Unit, NoStream, E] 
    A simpler version of sequence that takes a number of DBIOActions 
    with any return type as varargs and returns a DBIOAction 
    that performs the individual actions in sequence, returning () in the end.
def sequence[R, M[+_] <: TraversableOnce[_], E <: Effect](in: M[DBIOAction[R, NoStream, E]])(implicit cbf: CanBuildFrom[M[DBIOAction[R, NoStream, E]], R, M[R]]): DBIOAction[M[R], NoStream, E] 
    Transform a TraversableOnce[ DBIO[R] ] into a DBIO[ TraversableOnce[R] ].
def sequenceOption[R, E <: Effect](in: Option[DBIOAction[R, NoStream, E]]): DBIOAction[Option[R], NoStream, E] 
    Transform a Option[ DBIO[R] ] into a DBIO[ Option[R] ].
def successful[R](v: R): DBIOAction[R, NoStream, Effect] 
    Lift a constant value to a DBIOAction.



///* Querying
//The simplest kind of query iterates over all the data in a table:
//TableQuery.result Gives Action, that can be run by db.run() to get Future 

// Read all coffees and print them to the console
//This corresponds to a SELECT * FROM COFFEES in SQL 
//(except that the * is the table�s * projection we defined earlier and not whatever the database sees as *). 
//The type of the values we get in the loop is, the type parameter of Coffees.

//add a projection to this basic query. 
//This is written in Scala with the map method or a for comprehension:
println("Coffees:")
db.run(coffees.result).map(_.foreach {
  case (name, supID, price, sales, total) =>
    println("  " + name + "\t" + supID + "\t" + price + "\t" + sales + "\t" + total)
})
// Equivalent SQL code:
// select COF_NAME, SUP_ID, PRICE, SALES, TOTAL from COFFEES


//OR 
// The first string constant needs to be lifted manually to a LiteralColumn
// so that the proper ++ operator is found
val q1 = for(c <- coffees)
  yield LiteralColumn("  ") ++ c.name ++ "\t" ++ c.supID.asColumnOf[String] ++
    "\t" ++ c.price.asColumnOf[String] ++ "\t" ++ c.sales.asColumnOf[String] ++
    "\t" ++ c.total.asColumnOf[String]
// Equivalent SQL code:
// select '  ' || COF_NAME || '\t' || SUP_ID || '\t' || PRICE || '\t' SALES || '\t' TOTAL from COFFEES

//use Reactive Streams to get a streaming result from the database
//Note for stream, we have .result.head and .result.headOption other methods 
db.stream(q1.result).foreach(println)

//Joining and filtering tables is done the same way as when working with Scala collections:
// Perform a join to retrieve coffee names and supplier names for
// all coffees costing less than $9.00

//Note the use of === instead of == for comparing two values for equality 
//and =!= instead of != for inequality. 
//This is necessary because these operators are already defined 
//with unsuitable types and semantics) on the base type Any, 
//so they cannot be replaced by extension methods. 
//The other comparison operators are the same as in standard Scala code: <, <=, >=, >.
val q2 = for {
  c <- coffees if c.price < 9.0
  s <- suppliers if s.id === c.supID
} yield (c.name, s.name)
// Equivalent SQL code:
// select c.COF_NAME, s.SUP_NAME from COFFEES c, SUPPLIERS s where c.PRICE < 9.0 and s.SUP_ID = c.SUP_ID



//The generator expression suppliers if s.id === c.supID follows the relationship 
//established by the foreign key Coffees.supplier. 
//Instead of repeating the join condition here we can use the foreign key directly:
val q3 = for {
  c <- coffees if c.price < 9.0
  s <- c.supplier
} yield (c.name, s.name)
// Equivalent SQL code:
// select c.COF_NAME, s.SUP_NAME from COFFEES c, SUPPLIERS s where c.PRICE < 9.0 and s.SUP_ID = c.SUP_ID


///* Slick - Full example 
//File:src\main\scala\Tables.scala
//schema: http://slick.lightbend.com/doc/3.0.0/schemas.html
import slick.driver.H2Driver.api._
import slick.lifted.{ProvenShape, ForeignKeyQuery}

// A Suppliers table with 6 columns: id, name, street, city, state, zip
class Suppliers(tag: Tag)
  extends Table[(Int, String, String, String, String, String)](tag, "SUPPLIERS") {

  // This is the primary key column:
  def id: Rep[Int] = column[Int]("SUP_ID", O.PrimaryKey)
  def name: Rep[String] = column[String]("SUP_NAME")
  def street: Rep[String] = column[String]("STREET")
  def city: Rep[String] = column[String]("CITY")
  def state: Rep[String] = column[String]("STATE")
  def zip: Rep[String] = column[String]("ZIP")
  
  // Every table needs a * projection with the same type as the table's type parameter
  def * : ProvenShape[(Int, String, String, String, String, String)] =
    (id, name, street, city, state, zip)
}

// A Coffees table with 5 columns: name, supplier id, price, sales, total
class Coffees(tag: Tag)
  extends Table[(String, Int, Double, Int, Int)](tag, "COFFEES") {

  def name: Rep[String] = column[String]("COF_NAME", O.PrimaryKey)
  def supID: Rep[Int] = column[Int]("SUP_ID")
  def price: Rep[Double] = column[Double]("PRICE")
  def sales: Rep[Int] = column[Int]("SALES")
  def total: Rep[Int] = column[Int]("TOTAL")
  
  def * : ProvenShape[(String, Int, Double, Int, Int)] =
    (name, supID, price, sales, total)
  
  // A reified foreign key relation that can be navigated to create a join
  def supplier: ForeignKeyQuery[Suppliers, (Int, String, String, String, String, String)] = 
    foreignKey("SUP_FK", supID, TableQuery[Suppliers])(_.id)
}



//src\main\scala\HelloSlick.scala
import scala.concurrent.{Future, Await}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import slick.backend.DatabasePublisher
import slick.driver.H2Driver.api._

// The main application
object HelloSlick extends App {
  val db = Database.forConfig("h2mem1")


  try {

    // The query interface for the Suppliers table
    val suppliers: TableQuery[Suppliers] = TableQuery[Suppliers]

    // the query interface for the Coffees table
    val coffees: TableQuery[Coffees] = TableQuery[Coffees]

    val setupAction: DBIO[Unit] = DBIO.seq(
      // Create the schema by combining the DDLs for the Suppliers and Coffees
      // tables using the query interfaces
      (suppliers.schema ++ coffees.schema).create,

      // Insert some suppliers
      suppliers += (101, "Acme, Inc.", "99 Market Street", "Groundsville", "CA", "95199"),
      suppliers += ( 49, "Superior Coffee", "1 Party Place", "Mendocino", "CA", "95460"),
      suppliers += (150, "The High Ground", "100 Coffee Lane", "Meadows", "CA", "93966")
    )

    val setupFuture: Future[Unit] = db.run(setupAction)
    val f = setupFuture.flatMap { _ =>

      // Insert some coffees (using JDBC's batch insert feature)
      val insertAction: DBIO[Option[Int]] = coffees ++= Seq (
        ("Colombian",         101, 7.99, 0, 0),
        ("French_Roast",       49, 8.99, 0, 0),
        ("Espresso",          150, 9.99, 0, 0),
        ("Colombian_Decaf",   101, 8.99, 0, 0),
        ("French_Roast_Decaf", 49, 9.99, 0, 0)
      )
      //do it after above 
      val insertAndPrintAction: DBIO[Unit] = insertAction.map { coffeesInsertResult =>
        // Print the number of rows inserted
        coffeesInsertResult foreach { numRows =>
          println(s"Inserted $numRows rows into the Coffees table")
        }
      }

      val allSuppliersAction: DBIO[Seq[(Int, String, String, String, String, String)]] =  suppliers.result
      //compose from left to right 
      val combinedAction: DBIO[Seq[(Int, String, String, String, String, String)]] = insertAndPrintAction >> allSuppliersAction

      val combinedFuture: Future[Seq[(Int, String, String, String, String, String)]] = db.run(combinedAction)

      combinedFuture.map { allSuppliers =>
        allSuppliers.foreach(println)
      }

    }.flatMap { _ =>

      /* Streaming */

      val coffeeNamesAction: StreamingDBIO[Seq[String], String] =  coffees.map(_.name).result

      val coffeeNamesPublisher: DatabasePublisher[String] =    db.stream(coffeeNamesAction)

      coffeeNamesPublisher.foreach(println)

    }.flatMap { _ =>

      /* Filtering / Where */

      // Construct a query where the price of Coffees is > 9.0
      val filterQuery: Query[Coffees, (String, Int, Double, Int, Int), Seq] =   coffees.filter(_.price > 9.0)

      // Print the SQL for the filter query
      println("Generated SQL for filter query:\n" + filterQuery.result.statements)

      // Execute the query and print the Seq of results
      db.run(filterQuery.result.map(println))

    }.flatMap { _ =>

      /* Update */

      // Construct an update query with the sales column being the one to update
      val updateQuery: Query[Rep[Int], Int, Seq] = coffees.map(_.sales)

      val updateAction: DBIO[Int] = updateQuery.update(1)

      // Print the SQL for the Coffees update query
      println("Generated SQL for Coffees update:\n" + updateQuery.updateStatement)

      // Perform the update
      db.run(updateAction.map { numUpdatedRows =>
        println(s"Updated $numUpdatedRows rows")
      })

    }.flatMap { _ =>

      /* Delete */

      // Construct a delete query that deletes coffees with a price less than 8.0
      val deleteQuery: Query[Coffees,(String, Int, Double, Int, Int), Seq] =
        coffees.filter(_.price < 8.0)

      val deleteAction = deleteQuery.delete

      // Print the SQL for the Coffees delete query
      println("Generated SQL for Coffees delete:\n" + deleteAction.statements)

      // Perform the delete
      db.run(deleteAction).map { numDeletedRows =>
        println(s"Deleted $numDeletedRows rows")
      }

    }.flatMap { _ =>

      /* Sorting / Order By */

      val sortByPriceQuery: Query[Coffees, (String, Int, Double, Int, Int), Seq] =
        coffees.sortBy(_.price)

      println("Generated SQL for query sorted by price:\n" +
        sortByPriceQuery.result.statements)

      // Execute the query
      db.run(sortByPriceQuery.result).map(println)

    }.flatMap { _ =>

      /* Query Composition */

      val composedQuery: Query[Rep[String], String, Seq] =
        coffees.sortBy(_.name).take(3).filter(_.price > 9.0).map(_.name)

      println("Generated SQL for composed query:\n" +
        composedQuery.result.statements)

      // Execute the composed query
      db.run(composedQuery.result).map(println)

    }.flatMap { _ =>

      /* Joins */

      // Join the tables using the relationship defined in the Coffees table
      val joinQuery: Query[(Rep[String], Rep[String]), (String, String), Seq] = for {
        c <- coffees if c.price > 9.0
        s <- c.supplier
      } yield (c.name, s.name)

      println("Generated SQL for the join query:\n" + joinQuery.result.statements)

      // Print the rows which contain the coffee name and the supplier name
      db.run(joinQuery.result).map(println)

    }.flatMap { _ =>

      /* Computed Values */

      // Create a new computed column that calculates the max price
      val maxPriceColumn: Rep[Option[Double]] = coffees.map(_.price).max

      println("Generated SQL for max price column:\n" + maxPriceColumn.result.statements)

      // Execute the computed value query
      db.run(maxPriceColumn.result).map(println)

    }.flatMap { _ =>

      /* Manual SQL / String Interpolation */

      // A value to insert into the statement
      val state = "CA"

      // Construct a SQL statement manually with an interpolated value
      val plainQuery = sql"select SUP_NAME from SUPPLIERS where STATE = $state".as[String]

      println("Generated SQL for plain query:\n" + plainQuery.statements)

      // Execute the query
      db.run(plainQuery).map(println)

    }
    Await.result(f, Duration.Inf)

  } finally db.close
}

//src\main\scala\CaseClassMapping.scala
import scala.concurrent.Await
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import slick.driver.H2Driver.api._

object CaseClassMapping extends App {

  // the base query for the Users table
  val users = TableQuery[Users]

  val db = Database.forConfig("h2mem1")
  try {
    Await.result(db.run(DBIO.seq(
      // create the schema
      users.schema.create,

      // insert two User instances
      users += User("John Doe"),
      users += User("Fred Smith"),

      // print the users (select * from USERS)
      users.result.map(println)
    )), Duration.Inf)
  } finally db.close
}

case class User(name: String, id: Option[Int] = None)

class Users(tag: Tag) extends Table[User](tag, "USERS") {
  // Auto Increment the id primary key column
  def id = column[Int]("ID", O.PrimaryKey, O.AutoInc)
  // The name can't be null
  def name = column[String]("NAME", O.NotNull)
  // the * projection (e.g. select * ...) auto-transforms the tupled
  // column values to / from a User
  def * = (name, id.?) <> (User.tupled, User.unapply)
}

//src\main\scala\QueryActions.scala
import slick.driver.H2Driver.api._

import scala.concurrent.Await
import scala.concurrent.duration.Duration
import scala.concurrent.ExecutionContext.Implicits.global

// Demonstrates various ways of reading data
object QueryActions extends App {

  // A simple dictionary table with keys and values
  class Dict(tag: Tag) extends Table[(Int, String)](tag, "INT_DICT") {
    def key = column[Int]("KEY", O.PrimaryKey)
    def value = column[String]("VALUE")
    def * = (key, value)
  }
  val dict = TableQuery[Dict]

  val db = Database.forConfig("h2mem1")
  try {

    // Define a pre-compiled parameterized query for reading all key/value
    // pairs up to a given key.
    val upTo = Compiled { k: Column[Int] =>
      dict.filter(_.key <= k).sortBy(_.key)
    }

    // A second pre-compiled query which returns a Set[String]
    val upToSet = upTo.map(_.andThen(_.to[Set]))

    Await.result(db.run(DBIO.seq(

      // Create the dictionary table and insert some data
      dict.ddl.create,
      dict ++= Seq(1 -> "a", 2 -> "b", 3 -> "c", 4 -> "d", 5 -> "e"),

      upTo(3).result.map { r =>
        println("Seq (Vector) of k/v pairs up to 3")
        println("- " + r)
      },

      upToSet(3).result.map { r =>
        println("Set of k/v pairs up to 3")
        println("- " + r)
      },

      dict.map(_.key).to[Array].result.map { r =>
        println("All keys in an unboxed Array[Int]")
        println("- " + r)
      },

      upTo(3).result.head.map { r =>
        println("Only get the first result, failing if there is none")
        println("- " + r)
      },

      upTo(3).result.headOption.map { r =>
        println("Get the first result as an Option, or None")
        println("- " + r)
      }

    )), Duration.Inf)

    // The Publisher captures a Database plus a DBIO action.
    // The action does not run until you consume the stream.
    val p = db.stream(upTo(3).result)

    println("Stream k/v pairs up to 3 via Reactive Streams")
    Await.result(p.foreach { v =>
      println("- " + v)
    }, Duration.Inf)

  } finally db.close
}


//src/test/scala/TableSuite.scala 
import org.scalatest._
import org.scalatest.concurrent.ScalaFutures
import org.scalatest.time.{Seconds, Span}
import slick.driver.H2Driver.api._
import slick.jdbc.meta._

class TablesSuite extends FunSuite with BeforeAndAfter with ScalaFutures {
  implicit override val patienceConfig = PatienceConfig(timeout = Span(5, Seconds))

  val suppliers = TableQuery[Suppliers]
  val coffees = TableQuery[Coffees]
  
  var db: Database = _

  def createSchema() =
    db.run((suppliers.schema ++ coffees.schema).create).futureValue
  
  def insertSupplier(): Int =
    db.run(suppliers += (101, "Acme, Inc.", "99 Market Street", "Groundsville", "CA", "95199")).futureValue
  
  before { db = Database.forConfig("h2mem1") }
  
  test("Creating the Schema works") {
    createSchema()
    
    val tables = db.run(MTable.getTables).futureValue

    assert(tables.size == 2)
    assert(tables.count(_.name.name.equalsIgnoreCase("suppliers")) == 1)
    assert(tables.count(_.name.name.equalsIgnoreCase("coffees")) == 1)
  }

  test("Inserting a Supplier works") {
    createSchema()
    
    val insertCount = insertSupplier()
    assert(insertCount == 1)
  }
  
  test("Query Suppliers works") {
    createSchema()
    insertSupplier()
    val results = db.run(suppliers.result).futureValue
    assert(results.size == 1)
    assert(results.head._1 == 101)
  }
  
  after { db.close }
}




///*** Slick - Queries

//In simple list of case class, use filter and map 
case class Coffee(name: String, price: Double)
val coffees: List[Coffee] = //...

val l = coffees.filter(_.price > 8.0).map(_.name)
//                       ^       ^          ^
//                       Double  Double     String


//similar code in Slick:
//But All plain types are lifted into Rep. 
//The same is true for the table row type Coffees which is a subtype of Rep[(String, Double)]. 
//Even the literal 8.0 is automatically lifted to a Rep[Double] by an implicit conversion 
//because that is what the > operator on Rep[Double] expects for the right-hand side. 


class Coffees(tag: Tag) extends Table[(String, Double)](tag, "COFFEES") {
  def name = column[String]("COF_NAME")
  def price = column[Double]("PRICE")
  def * = (name, price)
}
val coffees = TableQuery[Coffees]

//Collection values are represented by the Query class (a Rep[Seq[T]]) 
//which contains many standard collection methods like flatMap, filter, take and groupBy. 

//The operators and other methods which are commonly used in queries are added through implicit conversions defined in ExtensionMethodConversions. 
//The actual methods can be found in the classes AnyExtensionMethods, ColumnExtensionMethods, 
//NumericColumnExtensionMethods, BooleanColumnExtensionMethods and StringColumnExtensionMethods 

//Most operators mimic the plain Scala equivalents, 
//but use === instead of == for comparing two values for equality 
//and =!= instead of != for inequality. 

//Note .price is actually a Column with corresponding ExtensionMethods applied 
val q = coffees.filter(_.price > 8.0).map(_.name)
//                       ^       ^          ^
//               Rep[Double]  Rep[Double]  Rep[String]

// Execute the query and print the Seq of results
//Query.result returns Action, run by db.run(), returns a Future 
import scala.concurrent.Await
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
val f  = db.run(q.result.map(println))
Await.result(f, Duration.Inf)





//*Sorting and Filtering
//they take a Query and return a new Query of the same type)

val q1 = coffees.filter(_.supID === 101)
// compiles to SQL (simplified):
//   select "COF_NAME", "SUP_ID", "PRICE", "SALES", "TOTAL"
//     from "COFFEES"
//     where "SUP_ID" = 101

val q2 = coffees.drop(10).take(5)
// compiles to SQL (simplified):
//   select "COF_NAME", "SUP_ID", "PRICE", "SALES", "TOTAL"
//     from "COFFEES"
//     limit 5 offset 10

//From Ordering class, asc ,desc ,reverse,nullsDefault,nullsFirst ,nullsLast 
//returns Ordering such that can be chained 
val q3 = coffees.sortBy(_.name.desc.nullsFirst)
// compiles to SQL (simplified):
//   select "COF_NAME", "SUP_ID", "PRICE", "SALES", "TOTAL"
//     from "COFFEES"
//     order by "COF_NAME" desc nulls first

// building criteria using a "dynamic filter" e.g. from a webform. 
val criteriaColombian = Option("Colombian")
val criteriaEspresso = Option("Espresso")
val criteriaRoast:Option[String] = None

val q4 = coffees.filter { coffee => 
  List(
      criteriaColombian.map(coffee.name === _),
      criteriaEspresso.map(coffee.name === _),
      criteriaRoast.map(coffee.name === _) // not a condition as `criteriaRoast` evaluates to `None`
                                           //Creates Option[Boolean] as originals are Option
  ).collect({case Some(criteria)  => criteria}).reduceLeftOption(_ || _) //BooleanColumnExtensionMethods , && , and , || or ,! not
    .getOrElse(true:Column[Boolean])
}
// compiles to SQL (simplified):
//   select "COF_NAME", "SUP_ID", "PRICE", "SALES", "TOTAL"
//     from "COFFEES"
//     where ("COF_NAME" = 'Colombian' or "COF_NAME" = 'Espresso')



//*Joining and Zipping
//Joins are used to combine two different tables or queries into a single query. 
//There are two different ways of writing joins: Applicative and monadic.

//	From 			To			  Transformation Name
//a) ( A=>B )     ( C[A]=>C[B] )   | Functor   , Given A=>B function, create C[A] =>C[B] ie map
//b) ( A=>C[B] )  ( C[A]=>C[B] )   | Monad      , Given A =>C[B], create C[A] =>C[B], ie flatMap
//c) ( C[A=>B] )  ( C[A]=>C[B] )   | Applicative , Given C[A=>B], create C[A]=>C[B] , 


//Applicative joins
//Applicative joins are performed by calling a method 
//that joins two queries into a single query of a tuple of the individual results. 

//They have the same restrictions as joins in SQL, 
//i.e. the right-hand side may not depend on the left-hand side. 
//This is enforced naturally through Scala�s scoping rules.


val crossJoin = for {
  (c, s) <- coffees join suppliers
} yield (c.name, s.name)
// compiles to SQL (simplified):
//   select x2."COF_NAME", x3."SUP_NAME" from "COFFEES" x2
//     inner join "SUPPLIERS" x3

val innerJoin = for {
  (c, s) <- coffees join suppliers on (_.supID === _.id)
} yield (c.name, s.name)
// compiles to SQL (simplified):
//   select x2."COF_NAME", x3."SUP_NAME" from "COFFEES" x2
//     inner join "SUPPLIERS" x3
//     on x2."SUP_ID" = x3."SUP_ID"

val leftOuterJoin = for {
  (c, s) <- coffees joinLeft suppliers on (_.supID === _.id)
} yield (c.name, s.map(_.name))
// compiles to SQL (simplified):
//   select x2."COF_NAME", x3."SUP_NAME" from "COFFEES" x2
//     left outer join "SUPPLIERS" x3
//     on x2."SUP_ID" = x3."SUP_ID"

val rightOuterJoin = for {
  (c, s) <- coffees joinRight suppliers on (_.supID === _.id)
} yield (c.map(_.name), s.name)
// compiles to SQL (simplified):
//   select x2."COF_NAME", x3."SUP_NAME" from "COFFEES" x2
//     right outer join "SUPPLIERS" x3
//     on x2."SUP_ID" = x3."SUP_ID"

val fullOuterJoin = for {
  (c, s) <- coffees joinFull suppliers on (_.supID === _.id)
} yield (c.map(_.name), s.map(_.name))
// compiles to SQL (simplified):
//   select x2."COF_NAME", x3."SUP_NAME" from "COFFEES" x2
//     full outer join "SUPPLIERS" x3
//     on x2."SUP_ID" = x3."SUP_ID"




//Monadic joins
//Monadic joins are created with flatMap. 
//They are theoretically more powerful than applicative joins 
//because the right-hand side may depend on the left-hand side. 
//However, this is not possible in standard SQL, 
//so Slick has to compile them down to applicative joins, 
//If a monadic join cannot be properly translated, it will fail at runtime.

//A cross-join is created with a flatMap operation on a Query 
//(i.e. by introducing more than one generator in a for-comprehension):


val monadicCrossJoin = for {
  c <- coffees
  s <- suppliers
} yield (c.name, s.name)
// compiles to SQL:
//   select x2."COF_NAME", x3."SUP_NAME"
//     from "COFFEES" x2, "SUPPLIERS" x3


//add a filter expression, it becomes an inner join:


val monadicInnerJoin = for {
  c <- coffees
  s <- suppliers if c.supID === s.id
} yield (c.name, s.name)
// compiles to SQL:
//   select x2."COF_NAME", x3."SUP_NAME"
//     from "COFFEES" x2, "SUPPLIERS" x3
//     where x2."SUP_ID" = x3."SUP_ID"


//*Zip joins
//Slick also has zip joins which create a pairwise join of two queries. 
//The semantics are again the same as for Scala collections, using the zip and zipWith methods:


val zipJoinQuery = for {
  (c, s) <- coffees zip suppliers
} yield (c.name, s.name)

val zipWithJoin = for {
  res <- coffees.zipWith(suppliers, (c: Coffees, s: Suppliers) => (c.name, s.name))
} yield res


//A particular kind of zip join is provided by zipWithIndex. 
//It zips a query result with an infinite sequence starting at 0. 
val zipWithIndexJoin = for {
  (c, idx) <- coffees.zipWithIndex
} yield (c.name, idx)



//* Unions
//Two queries can be concatenated with the ++ (or unionAll) 
//and union operators if they have compatible types:

//Unlike union which filters out duplicate values, 
//++ simply concatenates the results of the individual queries, which is usually more efficient.


val q1 = coffees.filter(_.price < 8.0)
val q2 = coffees.filter(_.price > 9.0)

val unionQuery = q1 union q2
// compiles to SQL (simplified):
//   select x8."COF_NAME", x8."SUP_ID", x8."PRICE", x8."SALES", x8."TOTAL"
//     from "COFFEES" x8
//     where x8."PRICE" < 8.0
//   union select x9."COF_NAME", x9."SUP_ID", x9."PRICE", x9."SALES", x9."TOTAL"
//     from "COFFEES" x9
//     where x9."PRICE" > 9.0

val unionAllQuery = q1 ++ q2
// compiles to SQL (simplified):
//   select x8."COF_NAME", x8."SUP_ID", x8."PRICE", x8."SALES", x8."TOTAL"
//     from "COFFEES" x8
//     where x8."PRICE" < 8.0
//   union all select x9."COF_NAME", x9."SUP_ID", x9."PRICE", x9."SALES", x9."TOTAL"
//     from "COFFEES" x9
//     where x9."PRICE" > 9.0




//* Aggregation

//The simplest form of aggregation consists of computing a primitive value 
//from a Query that returns a single column, usually with a numeric type, e.g.:


val q = coffees.map(_.price)

val q1 = q.min
// compiles to SQL (simplified):
//   select min(x4."PRICE") from "COFFEES" x4

val q2 = q.max
// compiles to SQL (simplified):
//   select max(x4."PRICE") from "COFFEES" x4

val q3 = q.sum
// compiles to SQL (simplified):
//   select sum(x4."PRICE") from "COFFEES" x4

val q4 = q.avg
// compiles to SQL (simplified):
//   select avg(x4."PRICE") from "COFFEES" x4


//Note that these aggregate queries return a scalar result, not a collection. 
//Some aggregation functions are defined for arbitrary queries (of more than one column):

val q1 = coffees.length
// compiles to SQL (simplified):
//   select count(1) from "COFFEES"

val q2 = coffees.exists
// compiles to SQL (simplified):
//   select exists(select * from "COFFEES")


//Grouping is done with the groupBy method. 
//It has the same semantics as for Scala collections:

val q = (for {
  c <- coffees
  s <- c.supplier
} yield (c, s)).groupBy(_._1.supID)

val q2 = q.map { case (supID, css) =>
  (supID, css.length, css.map(_._1.price).avg)
}
// compiles to SQL:
//   select x2."SUP_ID", count(1), avg(x2."PRICE")
//     from "COFFEES" x2, "SUPPLIERS" x3
//     where x3."SUP_ID" = x2."SUP_ID"
//     group by x2."SUP_ID"


//* Querying to Action
//A Query can be converted into an Action by calling its result method. 
//The Action can then be executed directly in a streaming or fully materialized way, 
//or composed further with other Actions:

//If you only want a single result value, you can call head or headOption on the result Action.
import scala.concurrent.Await
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
val q = coffees.map(_.price)
val action = q.result
val result: Future[Seq[Double]] = db.run(action)
val sql = action.statements.head

Await.result(result.map(println), Duration.Inf)



//*Deleting
//You write a query which selects the rows to delete 
//and then get an Action by calling the delete method on it:

//A query for deleting must only select from a single table. 
//Any projection is ignored (it always deletes full rows).

val q = coffees.filter(_.supID === 15)
val action = q.delete
val affectedRowsCount: Future[Int] = db.run(action)
val sql = action.statements.head



//*Inserting
//Inserts are done based on a projection of columns from a single table. 
//When you use the table directly, the insert is performed against its * projection. 
//Omitting some of a table�s columns when inserting causes the database to use the default values specified in the table definition, 
//or a type-specific default in case no explicit default was given. 


val insertActions = DBIO.seq(
  coffees += ("Colombian", 101, 7.99, 0, 0),

  coffees ++= Seq(
    ("French_Roast", 49, 8.99, 0, 0),
    ("Espresso",    150, 9.99, 0, 0)
  ),

  // "sales" and "total" will use the default value 0:
  coffees.map(c => (c.name, c.supID, c.price)) += ("Colombian_Decaf", 101, 8.99)
)

// Get the statement without having to specify a value to insert:
val sql = coffees.insertStatement

// compiles to SQL:
//   INSERT INTO "COFFEES" ("COF_NAME","SUP_ID","PRICE","SALES","TOTAL") VALUES (?,?,?,?,?)


//When you include an AutoInc column in an insert operation, 
//it is silently ignored, so that the database can generate the proper value. 
//In this case you usually want to get back the auto-generated primary key column. 

//By default, += gives you a count of the number of affected rows (which will usually be 1) 
//and ++= gives you an accumulated count in an Option (which can be None if the database system does not provide counts for all rows).

//This can be changed with the returning method where you specify the columns to be returned 
//(as a single value or tuple from += and a Seq of such values from ++=):


val userId =  (users returning users.map(_.id)) += User(None, "Stefan", "Zeiger")

//You can follow the returning method with the into method 
//to map the inserted values and the generated keys (specified in returning) to a desired value. 
//Here is an example of using this feature to return an object with an updated id:
val userWithId =
  (users returning users.map(_.id)
         into ((user,id) => user.copy(id=Some(id)))
  ) += User(None, "Stefan", "Zeiger")


//Instead of inserting data from the client side 
//you can also insert data created by a Query or a scalar expression 
//that is executed in the database server:
//In these cases, AutoInc columns are not ignored.

class Users2(tag: Tag) extends Table[(Int, String)](tag, "users2") {
  def id = column[Int]("id", O.PrimaryKey)
  def name = column[String]("name")
  def * = (id, name)
}
val users2 = TableQuery[Users2]

val actions = DBIO.seq(
  users2.schema.create,
  users2 forceInsertQuery (users.map { u => (u.id, u.first ++ " " ++ u.last) }),
  users2 forceInsertExpr (users.length + 1, "admin")
)


//*Updating
//Updates are performed by writing a query that selects the data to update 
//and then replacing it with new data. 
//The query must only return raw columns (no computed values) selected from a single table. 
//The relevant methods for updating are defined in UpdateExtensionMethods.


val q = for { c <- coffees if c.name === "Espresso" } yield c.price
val updateAction = q.update(10.49)

// Get the statement without having to specify an updated value:
val sql = q.updateStatement

// compiles to SQL:
//   update "COFFEES" set "PRICE" = ? where "COFFEES"."COF_NAME" = 'Espresso'


//*Compiled Queries
//Database queries typically depend on some parameters, 
//e.g. an ID for which you want to retrieve a matching database row. 

//You can write a regular Scala function to create a parameterized Query object
// each time you need to execute that query but this will incur the cost of recompiling the query in Slick (and possibly also on the database if you don�t use bind variables for all parameters). 
//It is more efficient to pre-compile such parameterized query functions:

//use a compiled query for querying, inserting, updating and deleting data. 
def userNameByIDRange(min: Rep[Int], max: Rep[Int]) =
  for {
    u <- users if u.id >= min && u.id < max
  } yield u.first

val userNameByIDRangeCompiled = Compiled(userNameByIDRange _)

// The query will be compiled only once:
val namesAction1 = userNameByIDRangeCompiled(2, 5).result
val namesAction2 = userNameByIDRangeCompiled(1, 3).result
// Also works for .insert, .update and .delete


//Be aware that take and drop take ConstColumn[Long] parameters. 
//Unlike Rep[Long]], which could be substituted by another value computed by a query, 
//a ConstColumn can only be literal value or a parameter of a compiled query. 


val userPaged = Compiled((d: ConstColumn[Long], t: ConstColumn[Long]) => users.drop(d).take(t))

val usersAction1 = userPaged(2, 1).result
val usersAction2 = userPaged(1, 3).result



//For backwards-compatibility with Slick 1.0 you can still create a compiled query 
//by calling flatMap on a Parameters object. 
//In many cases this enables you to write a single for comprehension for a compiled query:


val userNameByID = for {
  id <- Parameters[Int]
  u <- users if u.id === id
} yield u.first

val nameAction = userNameByID(2).result.head

val userNameByIDRange = for {
  (min, max) <- Parameters[(Int, Int)]
  u <- users if u.id >= min && u.id < max
} yield u.first

val namesAction = userNameByIDRange(2, 5).result


//* Reference 
sealed abstract  class  Query[+E, U, C[_]] extends QueryBase[C[U]] 
//Query Instance methods 
def ++[O >: E, R, D[_]](other: Query[O, U, D]): Query[O, U, C] 
    Return a new query containing the elements from both operands.
def distinct: Query[E, U, C] 
    Remove duplicate elements.
def distinctOn[F, T](f: (E) ? F)(implicit shape: Shape[_ <: FlatShapeLevel, F, T, _]): Query[E, U, C] 
    Remove duplicate elements which are the same in the given projection.
def drop(num: Int): Query[E, U, C] 
    Select all elements except the first num ones.
def drop(num: Long): Query[E, U, C] 
    Select all elements except the first num ones.
def drop(num: ConstColumn[Long]): Query[E, U, C] 
    Select all elements except the first num ones.
def encodeRef(path: Node): Query[E, U, C] 
    Encode a reference into this Rep.
def exists: Rep[Boolean] 
    Test whether this query is non-empty.
def filter[T <: Rep[_]](f: (E) ? T)(implicit wt: CanBeQueryCondition[T]): Query[E, U, C] 
    Select all elements of this query which satisfy a predicate.
def filterNot[T <: Rep[_]](f: (E) ? T)(implicit wt: CanBeQueryCondition[T]): Query[E, U, C] 
def flatMap[F, T, D[_]](f: (E) ? Query[F, T, D]): Query[F, T, C] 
    Build a new query by applying a function to all elements of this query and using the elements of the resulting queries.
def forUpdate: Query[E, U, C] 
    Specify part of a select statement for update and marked for row level locking
def groupBy[K, T, G, P](f: (E) ? K)(implicit kshape: Shape[_ <: FlatShapeLevel, K, T, G], vshape: Shape[_ <: FlatShapeLevel, E, _, P]): Query[(G, Query[P, U, Seq]), (T, Query[P, U, Seq]), C] 
    Partition this query into a query of pairs of a key and a nested query containing the elements for the key, according to some discriminator function.
def join[E2, U2, D[_]](q2: Query[E2, U2, D]): BaseJoinQuery[E, E2, U, U2, C, E, E2] 
    Join two queries with a cross join or inner join.
def joinFull[E1 >: E, E2, U2, D[_], O1, U1, O2](q2: Query[E2, _, D])(implicit ol1: OptionLift[E1, O1], sh1: Shape[FlatShapeLevel, O1, U1, _], ol2: OptionLift[E2, O2], sh2: Shape[FlatShapeLevel, O2, U2, _]): BaseJoinQuery[O1, O2, U1, U2, C, E, E2] 
    Join two queries with a full outer join.
def joinLeft[E2, U2, D[_], O2](q2: Query[E2, _, D])(implicit ol: OptionLift[E2, O2], sh: Shape[FlatShapeLevel, O2, U2, _]): BaseJoinQuery[E, O2, U, U2, C, E, E2] 
    Join two queries with a left outer join.
def joinRight[E1 >: E, E2, U2, D[_], O1, U1](q2: Query[E2, U2, D])(implicit ol: OptionLift[E1, O1], sh: Shape[FlatShapeLevel, O1, U1, _]): BaseJoinQuery[O1, E2, U1, U2, C, E, E2] 
    Join two queries with a right outer join.
def length: Rep[Int] 
    The total number of elements (i.e.
def map[F, G, T](f: (E) ? F)(implicit shape: Shape[_ <: FlatShapeLevel, F, T, G]): Query[G, T, C] 
    Build a new query by applying a function to all elements of this query.
def pack[R](implicit packing: Shape[_ <: FlatShapeLevel, E, _, R]): Query[R, U, C] 
final  lazy val   packed: Node 
def size: Rep[Int] 
    The total number of elements (i.e.
def sortBy[T](f: (E) ? T)(implicit ev: (T) ? Ordered): Query[E, U, C] 
    Sort this query according to a function which extracts the ordering criteria from the query elements.
def sorted(implicit ev: (E) ? Ordered): Query[E, U, C] 
    Sort this query according to a the ordering of its elements.
def subquery: Query[E, U, C] 
    Force a subquery to be created when using this Query as part of a larger Query.
def take(num: Int): Query[E, U, C] 
    Select the first num elements.
def take(num: Long): Query[E, U, C] 
    Select the first num elements.
def take(num: ConstColumn[Long]): Query[E, U, C] 
    Select the first num elements.
def to[D[_]](implicit ctc: TypedCollectionTypeConstructor[D]): Query[E, U, D] 
    Change the collection type to build when executing the query.
def toString(): String 
def union[O >: E, R, D[_]](other: Query[O, U, D]): Query[O, U, C] 
    Return a new query containing the elements from both operands.
def unionAll[O >: E, R, D[_]](other: Query[O, U, D]): Query[O, U, C] 
    Return a new query containing the elements from both operands.
def withFilter[T](f: (E) ? T)(implicit arg0: CanBeQueryCondition[T]): Query[E, U, C] 
    Select all elements of this query which satisfy a predicate.
def zip[E2, U2, D[_]](q2: Query[E2, U2, D]): Query[(E, E2), (U, U2), C] 
    Return a query formed from this query and another query by combining corresponding elements in pairs.
def zipWith[E2, U2, F, G, T, D[_]](q2: Query[E2, U2, D], f: (E, E2) ? F)(implicit shape: Shape[_ <: FlatShapeLevel, F, T, G]): Query[G, T, C] 
    Return a query formed from this query and another query by combining corresponding elements with the specified function.
def zipWithIndex: BaseJoinQuery[E, Rep[Long], U, Long, C, E, Rep[Long]] 
    Zip this query with its indices (starting at 0).



///***Slick - Plain SQL Queries

//String Interpolation
//contain plain sql with binding variables 
//sql, sqlu and tsql interpolators. 


//*sqlu - type DBIO[Int]
//used for DML statements which produce a row count instead of a result set. 



import slick.driver.H2Driver.api._


def createCoffees: DBIO[Int] =
  sqlu"""create table coffees(
    name varchar not null,
    sup_id int not null,
    price double not null,
    sales int not null,
    total int not null,
    foreign key(sup_id) references suppliers(id))"""

def createSuppliers: DBIO[Int] =
  sqlu"""create table suppliers(
    id int not null primary key,
    name varchar not null,
    street varchar not null,
    city varchar not null,
    state varchar not null,
    zip varchar not null)"""

def insertSuppliers: DBIO[Unit] = DBIO.seq(
  // Insert some suppliers
  sqlu"insert into suppliers values(101, 'Acme, Inc.', '99 Market Street', 'Groundsville', 'CA', '95199')",
  sqlu"insert into suppliers values(49, 'Superior Coffee', '1 Party Place', 'Mendocino', 'CA', '95460')",
  sqlu"insert into suppliers values(150, 'The High Ground', '100 Coffee Lane', 'Meadows', 'CA', '93966')"
)

//Any variable or expression injected (with $var or ${var}) into a query gets turned into a bind variable 
//It is not inserted directly into a query string, so there is no danger of SQL injection attacks. 

def insert(c: Coffee): DBIO[Int] =
  sqlu"insert into coffees values (${c.name}, ${c.supID}, ${c.price}, ${c.sales}, ${c.total})"

//The SQL statement produced by this method is always the same:
insert into coffees values (?, ?, ?, ?, ?)


//use of the DBIO.sequence combinator alog with sqlu 
//DBIO.seq combinator which runs a (varargs) sequence of database I/O actions in the given order 
//and discards the return values
//DBIO.sequence turns a Seq[DBIO[T]] into a DBIO[Seq[T]], thus preserving the results of all individual actions. 

//Example - It is used here to sum up the affected row counts of all inserts.

val inserts: Seq[DBIO[Int]] = Seq(
  Coffee("Colombian", 101, 7.99, 0, 0),
  Coffee("French_Roast", 49, 8.99, 0, 0),
  Coffee("Espresso", 150, 9.99, 0, 0),
  Coffee("Colombian_Decaf", 101, 8.99, 0, 0),
  Coffee("French_Roast_Decaf", 49, 9.99, 0, 0)
).map(insert)

val combined: DBIO[Seq[Int]] = DBIO.sequence(inserts)
combined.map(_.sum)



//*sql -type ResultSet 
//Convert result set into DBIO by as[Tuple_of_return_types]

//now type is DBIO[Seq[(String, String)]]
sql"""select c.name, s.name
      from coffees c, suppliers s
      where c.price < $price and s.id = c.sup_id""".as[(String, String)]


//The call to 'as' takes an implicit GetResult parameter 
//which extracts data of the requested type from a result set. 

//There are predefined GetResult implicits for the standard JDBC types, 
//for Options of those (to represent nullable columns) and for tuples of types which have a GetResult. 

//For non-standard return types ,define own converters:

// Case classes for our data
case class Supplier(id: Int, name: String, street: String, city: String, state: String, zip: String)
case class Coffee(name: String, supID: Int, price: Double, sales: Int, total: Int)

// Result set getters
//GetResult[T] is simply a wrapper for a function PositionedResult => T. 
//The implicit val for Supplier uses the explicit PositionedResult methods getInt and getString 
//to read the next Int or String value in the current row. 
implicit val getSupplierResult = GetResult(r => Supplier(r.nextInt, r.nextString, r.nextString,
  r.nextString, r.nextString, r.nextString))
  
//uses the shortcut method << which returns a value of whatever type is expected at this place. 
//use it when the type is actually known like in this constructor call.
implicit val getCoffeeResult = GetResult(r => Coffee(r.<<, r.<<, r.<<, r.<<, r.<<))



//*Splicing Literal Values
//$ is used for bind variables 
//which is not suitable for identifiers like column or table names, 
//whereas #$ is a mere string replacement like the s"" string interpolation.

//here $name would be bind variable
//and #$tables would be directly replaceed by 'coffees'
val table = "coffees"
sql"select * from #$table where name = $name".as[Coffee].headOption


//*tsql - Type-Checked SQL Statements
//sql,sqlu construct a SQL statement at runtime. 
//tsql interpolator is used for compile time 
//produces a DBIOAction of the correct type without requiring a call to .as.
def getSuppliers(id: Int): DBIO[Seq[(Int, String, String, String, String, String)]] =
  tsql"select * from suppliers where id > $id"


//In order to give the compiler access to the database, 
//you have to provide a configuration that can be resolved at compile-time. 
//This is done with the StaticDatabaseConfig annotation:
@StaticDatabaseConfig("file:src/main/resources/application.conf#tsql")


//This 'tsql' must contain an appropriate configiration for a StaticDatabaseConfig object, not just a Database.
//eg 
tsql {
  driver = "slick.driver.H2Driver$"
  db {
    connectionPool = disabled
    driver = "org.h2.Driver"
    url = "jdbc:h2:mem:tsql1;INIT=runscript from 'src/main/resources/create-schema.sql'"
  }
}

//You can also retrieve the statically configured DatabaseConfig at runtime:
val dc = DatabaseConfig.forAnnotation[JdbcProfile]
import dc.driver.api._
val db = dc.db



///*example- Plain SQL 
//src\main\resources\application.conf
h2mem1 = {
  url = "jdbc:h2:mem:test1"
  driver = org.h2.Driver
  connectionPool = disabled
  keepAliveConnection = true
}

tsql {
  driver = "slick.driver.H2Driver$"
  db {
    connectionPool = disabled
    driver = "org.h2.Driver"
    url = "jdbc:h2:mem:tsql1;INIT=runscript from 'src/main/resources/create-schema.sql'"
  }
}

//src\main\resources\create-schema.sql
create table suppliers(
  id int not null primary key,
  name varchar not null,
  street varchar not null,
  city varchar not null,
  state varchar not null,
  zip varchar not null);

insert into suppliers values(101, 'Acme, Inc.', '99 Market Street', 'Groundsville', 'CA', '95199');
insert into suppliers values(49, 'Superior Coffee', '1 Party Place', 'Mendocino', 'CA', '95460');
insert into suppliers values(150, 'The High Ground', '100 Coffee Lane', 'Meadows', 'CA', '93966');

//src\main\scala\Transfer.scala
import slick.driver.H2Driver.api._
import slick.jdbc.GetResult

/** The Data Transfer Objects for the PlainSQL app */
trait Transfer { this: PlainSQL.type =>

  // Case classes for our data
  case class Supplier(id: Int, name: String, street: String, city: String, state: String, zip: String)
  case class Coffee(name: String, supID: Int, price: Double, sales: Int, total: Int)

  // Result set getters
  implicit val getSupplierResult = GetResult(r => Supplier(r.nextInt, r.nextString, r.nextString,
    r.nextString, r.nextString, r.nextString))
  implicit val getCoffeeResult = GetResult(r => Coffee(r.<<, r.<<, r.<<, r.<<, r.<<))
}

//Dsrc\main\scala\Interpolation.scala
import slick.driver.H2Driver.api._

import scala.concurrent.ExecutionContext.Implicits.global

trait Interpolation { this: PlainSQL.type =>

  def createCoffees: DBIO[Int] =
    sqlu"""create table coffees(
      name varchar not null,
      sup_id int not null,
      price double not null,
      sales int not null,
      total int not null,
      foreign key(sup_id) references suppliers(id))"""

  def createSuppliers: DBIO[Int] =
    sqlu"""create table suppliers(
      id int not null primary key,
      name varchar not null,
      street varchar not null,
      city varchar not null,
      state varchar not null,
      zip varchar not null)"""

  def insertSuppliers: DBIO[Unit] = DBIO.seq(
    // Insert some suppliers
    sqlu"insert into suppliers values(101, 'Acme, Inc.', '99 Market Street', 'Groundsville', 'CA', '95199')",
    sqlu"insert into suppliers values(49, 'Superior Coffee', '1 Party Place', 'Mendocino', 'CA', '95460')",
    sqlu"insert into suppliers values(150, 'The High Ground', '100 Coffee Lane', 'Meadows', 'CA', '93966')"
  )

  def insertCoffees: DBIO[Unit] = {
    def insert(c: Coffee): DBIO[Int] =
      sqlu"insert into coffees values (${c.name}, ${c.supID}, ${c.price}, ${c.sales}, ${c.total})"

    // Insert some coffees. The SQL statement is the same for all calls:
    // "insert into coffees values (?, ?, ?, ?, ?)"
    val inserts: Seq[DBIO[Int]] = Seq(
      Coffee("Colombian", 101, 7.99, 0, 0),
      Coffee("French_Roast", 49, 8.99, 0, 0),
      Coffee("Espresso", 150, 9.99, 0, 0),
      Coffee("Colombian_Decaf", 101, 8.99, 0, 0),
      Coffee("French_Roast_Decaf", 49, 9.99, 0, 0)
    ).map(insert)

    val combined: DBIO[Seq[Int]] = DBIO.sequence(inserts)
    combined.map(_.sum)
  }

  def printAll: DBIO[Unit] =
    // Iterate through all coffees and output them
    sql"select * from coffees".as[Coffee].map { cs =>
      println("Coffees:")
      for(c <- cs)
        println("* " + c.name + "\t" + c.supID + "\t" + c.price + "\t" + c.sales + "\t" + c.total)
    }

  def namesByPrice(price: Double): DBIO[Seq[(String, String)]] = sql"""
    select c.name, s.name
    from coffees c, suppliers s
    where c.price < $price and s.id = c.sup_id""".as[(String, String)]

  def supplierById(id: Int): DBIO[Seq[Supplier]] =
    sql"select * from suppliers where id = $id".as[Supplier]

  def printParameterized: DBIO[Unit] = {
    // Perform a join to retrieve coffee names and supplier names for
    // all coffees costing less than $9.00
    namesByPrice(9.0).flatMap { l2 =>
      println("Parameterized StaticQuery:")
      for (t <- l2)
        println("* " + t._1 + " supplied by " + t._2)
      supplierById(49).map(s => println(s"Supplier #49: $s"))
    }
  }

  def coffeeByName(name: String): DBIO[Option[Coffee]] = {
    val table = "coffees"
    sql"select * from #$table where name = $name".as[Coffee].headOption
  }

  def deleteCoffee(name: String): DBIO[Int] =
    sqlu"delete from coffees where name = $name"
}



//src\main\scala\PlainSQL.scala
import scala.concurrent.{Future, Await}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import slick.driver.H2Driver.api._


object PlainSQL extends App with Interpolation with Transfer {
  val db = Database.forConfig("h2mem1")
  try {
    val f: Future[_] = {

      val a: DBIO[Unit] = DBIO.seq(
        createSuppliers,
        createCoffees,
        insertSuppliers,
        insertCoffees,
        printAll,
        printParameterized,
        coffeeByName("Colombian").map { s =>
          println(s"Coffee Colombian: $s")
        },
        deleteCoffee("Colombian").map { rows =>
          println(s"Deleted $rows rows")
        },
        coffeeByName("Colombian").map { s =>
          println(s"Coffee Colombian: $s")
        }
      )
      db.run(a)

    }
    Await.result(f, Duration.Inf)
  } finally db.close
}

//src\main\scala\TypedSQL.scala
import slick.driver.JdbcProfile

import scala.concurrent.{Future, Await}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import slick.backend.{DatabaseConfig, StaticDatabaseConfig}

@StaticDatabaseConfig("file:src/main/resources/application.conf#tsql")
object TypedSQL extends App {
  val dc = DatabaseConfig.forAnnotation[JdbcProfile]
  import dc.driver.api._

  def getSuppliers(id: Int): DBIO[Seq[(Int, String, String, String, String, String)]] =
    tsql"select * from suppliers where id > $id"

  val db = dc.db
  try {

    val a: DBIO[Unit] =
      getSuppliers(50).map { s =>
        println("All suppliers > 50:")
        s.foreach(println)
      }

    val f: Future[Unit] = db.run(a)
    Await.result(f, Duration.Inf)
  } finally db.close
}
