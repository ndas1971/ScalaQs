///*** Play JSON - Introduction
//https://github.com/playframework/play-json
libraryDependencies += "com.typesafe.play" %% "play-json" % "2.6.7"

//The base type in Play JSON is play.api.libs.json.JsValue, 
//and has several subtypes representing different JSON types:
JsObject
    a JSON object, represented as a Map. 
    Can be constructed from an ordered Seq or any kind of Map using JsObject.apply
JsArray
    a JSON array, consisting of a Seq[JsValue]
JsNumber
    a JSON number, represented as a BigDecimal.
JsString
    a JSON string.
JsBoolean
    a JSON boolean, either JsTrue or JsFalse.
JsNull
    the JSON null value.

///*** Play JSON - Basic reading and writing
import play.api.libs.json._ 

Json.parse(input: Array[Byte]): JsValue 
    Parses some bytes representing a JSON input, and returns it as a JsValue.
Json.parse(input: InputStream): JsValue 
    Parses a stream representing a JSON input, and returns it as a JsValue.
Json.parse(input: String): JsValue 
    Parses a String representing a JSON input, and returns it as a JsValue.
Json.prettyPrint(json: JsValue): String 
    Converts a JsValue to its pretty string representation using default pretty printer (line feeds after each fields and 2-spaces indentation).
Json.stringify(json: JsValue): String 
    Converts a JsValue to its string representation.



//Json.parse parses a JSON string or InputStream into a JSON tree:

val json: JsValue = Json.parse("""
{
  "name" : "Watership Down",
  "location" : {
    "lat" : 51.235685,
    "long" : -1.309197
  },
  "residents" : [ {
    "name" : "Fiver",
    "age" : 4,
    "role" : null
  }, {
    "name" : "Bigwig",
    "age" : 6,
    "role" : "Owsla"
  } ]
}
""")

//or using shortcuts 
import play.api.libs.json.{ JsNull, Json, JsString, JsValue }

val json: JsValue = Json.obj(
  "name" -> "Watership Down",
  "location" -> Json.obj("lat" -> 51.235685, "long" -> -1.309197),
  "residents" -> Json.arr(
    Json.obj(
      "name" -> "Fiver",
      "age" -> 4,
      "role" -> JsNull
    ),
    Json.obj(
      "name" -> "Bigwig",
      "age" -> 6,
      "role" -> "Owsla"
    )
  )
)

//Json.stringify is used to convert a JsValue to a String of JSON:

val jsonString = Json.stringify(json)
// {"name":"Watership Down","location":{"lat":51.235685,"long":-1.309197},"residents":[{"name":"Fiver","age":4,"role":null},{"name":"Bigwig","age":6,"role":"Owsla"}]}


///*** Play JSON - Constructing directly 
import play.api.libs.json._

val json: JsValue = JsObject(Seq(
  "name" -> JsString("Watership Down"),
  "location" -> JsObject(Seq("lat" -> JsNumber(51.235685), "long" -> JsNumber(-1.309197))),
  "residents" -> JsArray(IndexedSeq(
    JsObject(Seq(
      "name" -> JsString("Fiver"),
      "age" -> JsNumber(4),
      "role" -> JsNull
    )),
    JsObject(Seq(
      "name" -> JsString("Bigwig"),
      "age" -> JsNumber(6),
      "role" -> JsString("Owsla")
    ))
  ))
))

//or using short cuts 
import play.api.libs.json.{ JsNull, Json, JsString, JsValue }

val json: JsValue = Json.obj(
  "name" -> "Watership Down",
  "location" -> Json.obj("lat" -> 51.235685, "long" -> -1.309197),
  "residents" -> Json.arr(
    Json.obj(
      "name" -> "Fiver",
      "age" -> 4,
      "role" -> JsNull
    ),
    Json.obj(
      "name" -> "Bigwig",
      "age" -> 6,
      "role" -> "Owsla"
    )
  )
)



///*** Play JSON  - Traversing a JsValue - Jpath \




//The (json \ "location" \ "lat") returns a JsLookupResult 
//which may or may not contain a value. 
val lat = (json \ "location" \ "lat").get
// returns JsValue(51.235685)

//use \ to look up indices within a JsArray:
val bigwig = (json \ "residents" \ 1).get
// returns {"name":"Bigwig","age":6,"role":"Owsla"}

//Recursive path \
//Applying the \\ operator will do a lookup for the field in the current object 
//and all descendants.

val names = json \\ "name"
// returns Seq(JsString("Watership Down"), JsString("Fiver"), JsString("Bigwig"))

//Index lookup
//retrieve a value in a JsObject or JsArray using an apply operator 
//with the index number or key.

val name = json("name")
// returns JsString("Watership Down")

val bigwig = json("residents")(1)
// returns {"name":"Bigwig","age":6,"role":"Owsla"}


//using 'validate', 'as' and 'asOpt' methods. 
//use validate since it returns a JsResult which may contain an error if the JSON is malformed.
val unsafeName = (json \ "name").as[String]
// String: "Watership Down"

val unsafeBogusName = (json \ "bogus").as[String]
// throws exception

val nameOption = (json \ "name").asOpt[String]
// Some("Watership Down")

val bogusOption = (json \ "bogus").asOpt[String]
// None

val nameResult = (json \ "name").validate[String]
// JsSuccess("Watership Down")

val bogusResult = (json \ "bogus").validate[String]
// JsError

val unsafeName2 = json("name").as[String]
// "Watership Down"

val unsafeBogusName2 = json("bogus").as[String]
// throws exception

///*** Play JSON  - Using Rread Writes converters
//(conversion to/from JsValue from/to Scala objects/case class)
Json.toJson[T](o: T)(implicit tjs: Writes[T]): JsValue 
    This functionality depends on a converter of type Writes[T] 
    which can convert a T to a JsValue.
    The Play JSON API provides implicit Writes for most basic types, such as Int, Double, String, and Boolean. 
    It also supports Writes for collections of any type T that a Writes[T] exists.
    T
        the type of the value to be written as JSON
    o
        the value to convert as JSON
    
Json.fromJson[T](json: JsValue)(implicit fjs: Reads[T]): JsResult[T] 
    Converts a JsValue to a value of requested type T. 
    T
    The type of conversion result, only supported if a Reads implicit is available for.
    json
    the JsValue to convert

//Example 
import play.api.libs.json._

// basic types
val jsonString = Json.toJson("Fiver")
val jsonNumber = Json.toJson(4)
val jsonBoolean = Json.toJson(false)

// collections of basic types
val jsonArrayOfInts = Json.toJson(Seq(1, 2, 3, 4))
val jsonArrayOfStrings = Json.toJson(List("Fiver", "Bigwig"))





///*** Play JSON  - Constructing Reads for own objects(case class)
//The play.api.libs.json package defines an alias for JsPath:
// __ (double underscore)
val longPath = __ \ "location" \ "long"

//example 

case class Location(lat: Double, long: Double)
case class Resident(name: String, age: Int, role: Option[String])
case class Place(name: String, location: Location, residents: Seq[Resident])

//using combinator patterns(using and/or)
import play.api.libs.json._
import play.api.libs.json.Reads._
import play.api.libs.functional.syntax._

implicit val locationReads: Reads[Location] = (
  (JsPath \ "lat").read[Double](min(-90.0) keepAnd max(90.0)) and
  (JsPath \ "long").read[Double](min(-180.0) keepAnd max(180.0))
)(Location.apply _)

implicit val residentReads: Reads[Resident] = (
  (JsPath \ "name").read[String](minLength[String](2)) and
  (JsPath \ "age").read[Int](min(0) keepAnd max(150)) and
  (JsPath \ "role").readNullable[String]
)(Resident.apply _)

implicit val placeReads: Reads[Place] = (
  (JsPath \ "name").read[String](minLength[String](2)) and
  (JsPath \ "location").read[Location] and
  (JsPath \ "residents").read[Seq[Resident]]
)(Place.apply _)


val json = { ... }

json.validate[Place] match {
  case s: JsSuccess[Place] => {
    val place: Place = s.get
    // do something with place
  }
  case e: JsError => {
    // error handling flow
  }
}

val placeResult: JsResult[Place] = json.validate[Place]
// JsSuccess(Place(...),)

val residentResult: JsResult[Resident] = (json \ "residents")(1).validate[Resident]
// JsSuccess(Resident(Bigwig,6,Some(Owsla)),)


///*** Play JSON  - Constructing Writes for own objects(case class)construct Writes 
//Direct or combinator ways 
import play.api.libs.json._

implicit val locationWrites = new Writes[Location] {
  def writes(location: Location) = Json.obj(
    "lat" -> location.lat,
    "long" -> location.long
  )
}

implicit val residentWrites = new Writes[Resident] {
  def writes(resident: Resident) = Json.obj(
    "name" -> resident.name,
    "age" -> resident.age,
    "role" -> resident.role
  )
}

implicit val placeWrites = new Writes[Place] {
  def writes(place: Place) = Json.obj(
    "name" -> place.name,
    "location" -> place.location,
    "residents" -> place.residents
  )
}

val place = Place(
  "Watership Down",
  Location(51.235685, -1.309197),
  Seq(
    Resident("Fiver", 4, None),
    Resident("Bigwig", 6, Some("Owsla"))
  )
)

val json = Json.toJson(place)

//OR define your Writes using the combinator pattern
import play.api.libs.json._
import play.api.libs.functional.syntax._

implicit val locationWrites: Writes[Location] = (
  (JsPath \ "lat").write[Double] and
  (JsPath \ "long").write[Double]
)(unlift(Location.unapply))

implicit val residentWrites: Writes[Resident] = (
  (JsPath \ "name").write[String] and
  (JsPath \ "age").write[Int] and
  (JsPath \ "role").writeNullable[String]
)(unlift(Resident.unapply))

implicit val placeWrites: Writes[Place] = (
  (JsPath \ "name").write[String] and
  (JsPath \ "location").write[Location] and
  (JsPath \ "residents").write[Seq[Resident]]
)(unlift(Place.unapply))


val place = Place(
  "Watership Down",
  Location(51.235685, -1.309197),
  Seq(
    Resident("Fiver", 4, None),
    Resident("Bigwig", 6, Some("Owsla"))
  )
)

val json = Json.toJson(place)


///*** Play JSON  - Constructing Reads,Writes - Details 

//Reads
//Reads converters are used to convert from a JsValue to another type. 
//combine and nest Reads to create more complex Reads.

//The JSON library provides implicit Reads for basic types 
//such as String, Int, Double, etc. and collections of them 


import play.api.libs.json._ // JSON library
import play.api.libs.json.Reads._ // Custom validation helpers
import play.api.libs.functional.syntax._ // Combinator syntaxCopy


//Path Reads
//JsPath has methods to apply another Reads to a JsValue at a specified path:
JsPath.read[T](implicit r: Reads[T]): Reads[T] 
    Creates a Reads[T] that will apply the implicit argument r 
    to the JsValue at this path.
JsPath.readNullable[T](implicit r: Reads[T]): Reads[Option[T]] 
    Use for paths that may be missing or can contain a null value.

//Example 
val nameReads: Reads[String] = (JsPath \ "name").read[String]


//Complex Reads for case class 
//combine (using 'and') individual path Reads to form more complex Reads 
//type of FunctionalBuilder[Reads]#CanBuild2[Double, Double]
val locationReadsBuilder =     
  (JsPath \ "lat").read[Double] and
    (JsPath \ "long").read[Double]

//Convert to Reads, Note case class has default .apply from Product trait 
implicit val locationReads = locationReadsBuilder.apply(Location.apply _)

//OR single line 
implicit val locationReads: Reads[Location] = (
  (JsPath \ "lat").read[Double] and
  (JsPath \ "long").read[Double]
)(Location.apply _)


//Validation with Reads
val json = { ... }

val nameReads: Reads[String] = (JsPath \ "name").read[String]

val nameResult: JsResult[String] = json.validate[String](nameReads)

nameResult match {
  case s: JsSuccess[String] => println("Name: " + s.get)
  case e: JsError => println("Errors: " + JsError.toJson(e).toString())
}

//OR use Default validation for Reads 
Reads.email 
    Validates a String has email format.
Reads.minLength(nb) 
    Validates the minimum length of a collection or String.
Reads.min 
    Validates a minimum value.
Reads.max 
    Validates a maximum value.
Reads[A] keepAnd Reads[B] => Reads[A] 
    Operator that tries Reads[A] and Reads[B] 
    but only keeps the result of Reads[A] 
Reads[A] andKeep Reads[B] => Reads[B] 
    Operator that tries Reads[A] and Reads[B] but only keeps the result of Reads[B] 
Reads[A] or Reads[B] => Reads 
    Operator that performs a logical OR 
    and keeps the result of the last Reads checked.

//Example 
val improvedNameReads = (JsPath \ "name").read[String](minLength[String](2))

//complete example 
case class Location(lat: Double, long: Double)
case class Resident(name: String, age: Int, role: Option[String])
case class Place(name: String, location: Location, residents: Seq[Resident])

//using combinator patterns(using and/or)
import play.api.libs.json._
import play.api.libs.json.Reads._
import play.api.libs.functional.syntax._

implicit val locationReads: Reads[Location] = (
  (JsPath \ "lat").read[Double](min(-90.0) keepAnd max(90.0)) and
  (JsPath \ "long").read[Double](min(-180.0) keepAnd max(180.0))
)(Location.apply _)

implicit val residentReads: Reads[Resident] = (
  (JsPath \ "name").read[String](minLength[String](2)) and
  (JsPath \ "age").read[Int](min(0) keepAnd max(150)) and
  (JsPath \ "role").readNullable[String]
)(Resident.apply _)

implicit val placeReads: Reads[Place] = (
  (JsPath \ "name").read[String](minLength[String](2)) and
  (JsPath \ "location").read[Location] and
  (JsPath \ "residents").read[Seq[Resident]]
)(Place.apply _)


val json = { ... }

json.validate[Place] match {
  case s: JsSuccess[Place] => {
    val place: Place = s.get
    // do something with place
  }
  case e: JsError => {
    // error handling flow
  }
}

val placeResult: JsResult[Place] = json.validate[Place]
// JsSuccess(Place(...),)

val residentResult: JsResult[Resident] = (json \ "residents")(1).validate[Resident]
// JsSuccess(Resident(Bigwig,6,Some(Owsla)),)



//Writes
//Writes converters are used to convert from some type to a JsValue.
//Similar to Reads 
//There are a few differences between complex Writes and Reads:
1.The individual path Writes are created using the JsPath.write method.
2.There is no validation on conversion to JsValue 
  which makes the structure simpler and you won’t need any validation helpers.
3.The intermediary FunctionalBuilder#CanBuildX (created by and combinators) 
  takes a function that translates a complex type T to a tuple 
  matching the individual path Writes. 
  Although this is symmetrical to the Reads case, 
  the unapply method of a case class returns an Option of a tuple of properties 
  and must be used with unlift to extract the tuple.

//Example 

import play.api.libs.json._
import play.api.libs.functional.syntax._

implicit val locationWrites: Writes[Location] = (
  (JsPath \ "lat").write[Double] and
  (JsPath \ "long").write[Double]
)(unlift(Location.unapply))

implicit val residentWrites: Writes[Resident] = (
  (JsPath \ "name").write[String] and
  (JsPath \ "age").write[Int] and
  (JsPath \ "role").writeNullable[String]
)(unlift(Resident.unapply))

implicit val placeWrites: Writes[Place] = (
  (JsPath \ "name").write[String] and
  (JsPath \ "location").write[Location] and
  (JsPath \ "residents").write[Seq[Resident]]
)(unlift(Place.unapply))

val place = Place(
  "Watership Down",
  Location(51.235685, -1.309197),
  Seq(
    Resident("Fiver", 4, None),
    Resident("Bigwig", 6, Some("Owsla"))
  )
)

val json = Json.toJson(place)



///*Recursive Types
//to handle Reads and Writes for recursive types. 
//JsPath provides lazyRead and lazyWrite methods 
//that take call-by-name parameters to handle this

case class User(name: String, friends: Seq[User])

implicit lazy val userReads: Reads[User] = (
  (__ \ "name").read[String] and
  (__ \ "friends").lazyRead(Reads.seq[User](userReads))
)(User)

implicit lazy val userWrites: Writes[User] = (
  (__ \ "name").write[String] and
  (__ \ "friends").lazyWrite(Writes.seq[User](userWrites))
)(unlift(User.unapply))

@@@

//Format
//Format[T] is just a mix of the Reads and Writes traits 
//and can be used for implicit conversion in place of its components.

val locationReads: Reads[Location] = (
  (JsPath \ "lat").read[Double](min(-90.0) keepAnd max(90.0)) and
  (JsPath \ "long").read[Double](min(-180.0) keepAnd max(180.0))
)(Location.apply _)

val locationWrites: Writes[Location] = (
  (JsPath \ "lat").write[Double] and
  (JsPath \ "long").write[Double]
)(unlift(Location.unapply))

implicit val locationFormat: Format[Location] =  Format(locationReads, locationWrites)


//Creating Format using combinators when Reads and Writes are symmetrical
implicit val locationFormat: Format[Location] = (
  (JsPath \ "lat").format[Double](min(-90.0) keepAnd max(90.0)) and
  (JsPath \ "long").format[Double](min(-180.0) keepAnd max(180.0))
)(Location.apply, unlift(Location.unapply))



///*** Play JSON - Automatic conversion to case class
//using Play's automatic JSON macros

//define a Reads (JSON parser), Writes (JSON writer) using convenient macros:
Json.reads[A]: Reads[A] 
    Creates a Reads[T] by resolving, at compile-time, the case class fields or sealed family, and the required implicits.
Json.writes[A]: OWrites[A] 
    Creates a OWrites[T] by resolving, at compile-time, the case class fields or sealed family, and the required implicits.

///*Requirements for using Automatic macro 
1.It must have a companion object having apply and unapply methods
2.The return types of the unapply must match the argument types of the apply method.
3.The parameter names of the apply method must be the same as the property names desired in the JSON.

//Exmaple 
case class Resident(name: String, age: Int, role: Option[String])
    
implicit val residentReads = Json.reads[Resident]
implicit val residentWrites = Json.writes[Resident]

//OR define a Format that does both:
implicit val residentFormat = Json.format[Resident]

//Now use   Json.toJson[T: Writes] and Json.fromJson[T: Reads] 
//Here T is Resident and defined via context bound 


//Example - reads - When compiling, the macro will inspect the given class and inject the following code, 
//macro is done at compile-time, so you don’t lose any type safety or performance.
import play.api.libs.json._
import play.api.libs.functional.syntax._

implicit val residentReads = (
  (__ \ "name").read[String] and
  (__ \ "age").read[Int] and
  (__ \ "role").readNullable[String]
)(Resident)


//Example 
import play.api.libs.json._

implicit val residentWrites = Json.writes[Resident]

val resident = Resident(name = "Fiver", age = 4, role = None)

val residentJson: JsValue = Json.toJson(resident)


implicit val residentReads = Json.reads[Resident]

val jsonString: JsValue = Json.parse(
  """{
    "name" : "Fiver",
    "age" : 4
  }"""
)

val residentFromJson: JsResult[Resident] = Json.fromJson[Resident](jsonString)

residentFromJson match {
  case JsSuccess(r: Resident, path: JsPath) => println("Name: " + r.name)
  case e: JsError => println("Errors: " + JsError.toJson(e).toString())
}





@@@
///*** Play JSON - Json Transforms , in place of JsValue.validate(reads)

//exactly the same JsValue.validate(reads)
// but semantic as  a Reads[T] is a transformer 
JsValue.transform[A <: JsValue](reads: Reads[A]): JsResult[A]

//Example 
val json = Json.parse("""
{
  "key1" : "value1",
  "key2" : {
    "key21" : 123,
    "key22" : true,
    "key23" : [ "alpha", "beta", "gamma"],
    "key24" : {
      "key241" : 234.123,
      "key242" : "value242"
    }
  },
  "key3" : 234
}""")


//Example : Pick JSON value in JsPath

import play.api.libs.json._

val jsonTransformer = (__ \ 'key2 \ 'key23).json.pick

scala> json.transform(jsonTransformer)
res9: play.api.libs.json.JsResult[play.api.libs.json.JsValue] =
  JsSuccess(
    ["alpha","beta","gamma"],
    /key2/key23
  )

//Details 
(__ \ 'key2 \ 'key23).json
    All JSON transformers are in JsPath.json.
(__ \ 'key2 \ 'key23).json.pick
    pick is a Reads[JsValue] which picks the value IN the given JsPath. 
    Here ["alpha","beta","gamma"]
    jsPath.json.pick gets ONLY the value inside the JsPath
    jsPath.json.pick[T <: JsValue] extracts ONLY the typed value inside the JsPath
JsSuccess(["alpha","beta","gamma"],/key2/key23)
    This is a simply successful JsResult.

//Example : Pick value as Type

import play.api.libs.json._

val jsonTransformer = (__ \ 'key2 \ 'key23).json.pick[JsArray]

scala> json.transform(jsonTransformer)
res10: play.api.libs.json.JsResult[play.api.libs.json.JsArray] =
  JsSuccess(
    ["alpha","beta","gamma"],
    /key2/key23
  )


//Example : Pick branch following JsPath


import play.api.libs.json._

val jsonTransformer = (__ \ 'key2 \ 'key24 \ 'key241).json.pickBranch

scala> json.transform(jsonTransformer)
res11: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
  {
    "key2": {
      "key24":{
        "key241":234.123
      }
    }
  },
  /key2/key24/key241
  )


//Details '
(__ \ 'key2 \ 'key23).json.pickBranch
    pickBranch is a Reads[JsValue] which picks the branch from root to given JsPath
    jsPath.json.pickBranch extracts the single branch down to JsPath 
    and the value inside JsPath


//Example : a value from input JsPath into a new JsPath
import play.api.libs.json._

val jsonTransformer = (__ \ 'key25 \ 'key251).json.From( (__ \ 'key2 \ 'key21).json.pick )

scala> json.transform(jsonTransformer)
res12: play.api.libs.json.JsResult[play.api.libs.json.JsObject]
  JsSuccess(
    {
      "key25":{
        "key251":123
      }
    },
    /key2/key21
  )

//Details 
(__ \ 'key25 \ 'key251).json.From( reads: Reads[A <: JsValue] )
    From is a Reads[JsValue]
    From reads the JsValue from input JSON using provided Reads[A]
    From copies this extracted JsValue as the leaf of a new branch corresponding to given JsPath






//Example : full input Json & update a branch
import play.api.libs.json._

val jsonTransformer = (__ \ 'key2 \ 'key24).json.update(
  __.read[JsObject].map{ o => o ++ Json.obj( "field243" -> "coucou" ) }
)

scala> json.transform(jsonTransformer)
res13: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
    {
      "key1":"value1",
      "key2":{
        "key21":123,
        "key22":true,
        "key23":["alpha","beta","gamma"],
        "key24":{
          "key241":234.123,
          "key242":"value242",
          "field243":"coucou"
        }
      },
      "key3":234
    },
  )

//Details 
(__ \ 'key2).json.update(reads: Reads[A < JsValue])  //'
    Is a Reads[JsObject]
(__ \ 'key2 \ 'key24).json.update(reads) 
    jsPath.json.update(Reads[A <: JsValue]) only works for JsObject, 
    copies full input JsObject and updates jsPath with provided Reads[A <: JsValue]
    does 3 things:
    Extracts value from input JSON at JsPath (__ \ 'key2 \ 'key24).
    Applies reads on this relative value and re-creates a branch (__ \ 'key2 \ 'key24) adding result of reads as leaf.
    Merges this branch with full input JSON replacing existing branch (so it works only with input JsObject and not other type of JsValue).


//Example : Put a given value in a new branch
import play.api.libs.json._

val jsonTransformer = (__ \ 'key24 \ 'key241).json.put(JsNumber(456))

scala> json.transform(jsonTransformer)
res14: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
    {
      "key24":{
        "key241":456
      }
    },
  )


//Details 
(__ \ 'key24 \ 'key241).json.put( a: => JsValue )
    Is a Reads[JsObject]
(__ \ 'key24 \ 'key241).json.put( a: => JsValue )
    Creates a new branch (__ \ 'key24 \ 'key241)
    and Puts a as leaf of this branch.
    Does not care at all about input JSON.
    Simply replace input JSON by given value.

//Example: Prune a branch from input JSON
import play.api.libs.json._

val jsonTransformer = (__ \ 'key2 \ 'key22).json.prune

scala> json.transform(jsonTransformer)
res15: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
    {
      "key1":"value1",
      "key3":234,
      "key2":{
        "key21":123,
        "key23":["alpha","beta","gamma"],
        "key24":{
          "key241":234.123,
          "key242":"value242"
        }
      }
    },
    /key2/key22/key22
  )

//Details 
(__ \ 'key2 \ 'key22).json.prune
    Is a Reads[JsObject] that works only with JsObject
    Removes given JsPath from input JSON (key22 has disappeared under key2)
    Note the resulting JsObject hasn’t same keys order as input JsObject. 
    - prune doesn’t work for recursive JsPath for the time being
    - if prune doesn’t find any branch to delete, it doesn’t generate any error and returns unchanged JSON.

//Example - Pick a branch and update its content in 2 places
import play.api.libs.json._
import play.api.libs.json.Reads._

val jsonTransformer = (__ \ 'key2).json.pickBranch(
  (__ \ 'key21).json.update(
    of[JsNumber].map{ case JsNumber(nb) => JsNumber(nb + 10) }
  ) andThen
  (__ \ 'key23).json.update(
    of[JsArray].map{ case JsArray(arr) => JsArray(arr :+ JsString("delta")) }
  )
)
//'
scala> json.transform(jsonTransformer)
res16: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
    {
      "key2":{
        "key21":133,
        "key22":true,
        "key23":["alpha","beta","gamma","delta"],
        "key24":{
          "key241":234.123,
          "key242":"value242"
        }
      }
    },
    /key2
  )

//Details 
(__ \ 'key2).json.pickBranch(reads: Reads[A <: JsValue])
    Extracts branch __ \ 'key2 from input JSON 
    and applies reads to the relative leaf of this branch (only to the content).
(__ \ 'key21).json.update(reads: Reads[A <: JsValue])
    Updates (__ \ 'key21) branch.
of[JsNumber]
    Is just a Reads[JsNumber].
    Extracts a JsNumber from (__ \ 'key21).
of[JsNumber].map{ case JsNumber(nb) => JsNumber(nb + 10) }
    Reads a JsNumber (_value 123_ in __ \ 'key21).
    Uses Reads[A].map to increase it by 10 (in immutable way naturally).
andThen
    Is just the composition of 2 Reads[A].
    First reads is applied and then result is piped to second reads.
of[JsArray].map{ case JsArray(arr) => JsArray(arr :+ JsString("delta") }
    Reads a JsArray (_value [alpha, beta, gamma] in __ \ 'key23_).
    Uses Reads[A].map to append JsString("delta") to it.
result
result is just the __ \ 'key2 branch since we picked only this branch



//Example : Pick a branch and prune a sub-branch
import play.api.libs.json._

val jsonTransformer = (__ \ 'key2).json.pickBranch(
  (__ \ 'key23).json.prune
)

scala> json.transform(jsonTransformer)
res18: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
    {
      "key2":{
        "key21":123,
        "key22":true,
        "key24":{
          "key241":234.123,
          "key242":"value242"
        }
      }
    },
    /key2/key23
  )

//Details 
(__ \ 'key2).json.pickBranch(reads: Reads[A <: JsValue])
    Extracts branch __ \ 'key2 from input JSON 
    and applies reads to the relative leaf of this branch (only to the content).
(__ \ 'key23).json.prune
    Removes branch __ \ 'key23 from relative JSON
result
    result is just the __ \ 'key2 branch without key23 field.  //'



//Example : mixing JSON transformers with previously presented Reads combinators. 
//as JSON transformers are just Reads[A <: JsValue]

//from gizmo to Gremlin
val gizmo = Json.obj(
  "name" -> "gizmo",
  "description" -> Json.obj(
    "features" -> Json.arr( "hairy", "cute", "gentle"),
    "size" -> 10,
    "sex" -> "undefined",
    "life_expectancy" -> "very old",
    "danger" -> Json.obj(
      "wet" -> "multiplies",
      "feed after midnight" -> "becomes gremlin"
    )
  ),
  "loves" -> "all"
)


val gremlin = Json.obj(
  "name" -> "gremlin",
  "description" -> Json.obj(
    "features" -> Json.arr("skinny", "ugly", "evil"),
    "size" -> 30,
    "sex" -> "undefined",
    "life_expectancy" -> "very old",
    "danger" -> "always"
  ),
  "hates" -> "all"
)


import play.api.libs.json._
import play.api.libs.json.Reads._
import play.api.libs.functional.syntax._

val gizmo2gremlin = (
  (__ \ 'name).json.put(JsString("gremlin")) and
  (__ \ 'description).json.pickBranch(
    (__ \ 'size).json.update( of[JsNumber].map{ case JsNumber(size) => JsNumber(size * 3) } ) and
    (__ \ 'features).json.put( Json.arr("skinny", "ugly", "evil") ) and
    (__ \ 'danger).json.put(JsString("always"))
    reduce
  ) and
  (__ \ 'hates).json.From( (__ \ 'loves).json.pick )
) reduce

scala> gizmo.transform(gizmo2gremlin)
res22: play.api.libs.json.JsResult[play.api.libs.json.JsObject] =
  JsSuccess(
    {
      "name":"gremlin",
      "description":{
        "features":["skinny","ugly","evil"],
        "size":30,
        "sex":"undefined",
        "life_expectancy":
        "very old","danger":"always"
      },
      "hates":"all"
    },
  )

//Details 
(__ \ 'features).json.put(…) is after (__ \ 'size).json.update 
    so that it overwrites original (__ \ 'features)
(Reads[JsObject] and Reads[JsObject]) reduce
    It merges results of both Reads[JsObject] (JsObject ++ JsObject)
    It also applies the same JSON to both Reads[JsObject] 
    unlike andThen which injects the result of the first reads into second one.

@@@
///*** PLay JSON -  object Reads memebers 
implicit  object  ArrayNodeReads extends Reads[ArrayNode] 
    Deserializer for Jackson ArrayNode 
implicit  def  ArrayReads[T](implicit arg0: Reads[T], arg1: ClassTag[T]): Reads[Array[T]] 
    Deserializer for Array[T] types.
implicit  object  BooleanReads extends Reads[Boolean] 
    Deserializer for Boolean types.
implicit  object  ByteReads extends Reads[Byte] 
    Deserializer for Byte types.
implicit  val  DefaultDateReads: Reads[Date] 
    the default implicit java.util.Date reads 
implicit  val  DefaultInstantReads: Reads[Instant] 
    The default typeclass to reads java.time.Instant from JSON.
implicit  val  DefaultJavaDurationReads: Reads[Duration] 
    Deserializer of Java Duration, from either a time-based amount of time (string representation such as '34.5 seconds'), or from a number of milliseconds (see javaDurationMillisReads).
implicit  val  DefaultJavaPeriodReads: Reads[Period] 
    Deserializer of Java Period, from either a time-based amount of time in the ISO-8601 calendar system, such as '2 years, 3 months and 4 days' or from a number of days (see javaPeriodDaysReads).
implicit  val  DefaultLocalDateReads: Reads[LocalDate] 
    The default typeclass to reads java.time.LocalDate from JSON.
implicit  val  DefaultLocalDateTimeReads: Reads[LocalDateTime] 
    The default typeclass to reads java.time.LocalDateTime from JSON.
implicit  val  DefaultLocalTimeReads: Reads[LocalTime] 
    The default typeclass to reads java.time.LocalTime from JSON.
implicit  val  DefaultOffsetDateTimeReads: Reads[OffsetDateTime] 
    The default typeclass to reads java.time.OffsetDateTime from JSON.
implicit  val  DefaultSqlDateReads: Reads[Date] 
    the default implicit SqlDate reads 
implicit  val  DefaultZonedDateTimeReads: Reads[ZonedDateTime] 
    The default typeclass to reads java.time.ZonedDateTime from JSON.
implicit  object DoubleReads extends Reads[Double] 
    Deserializer for Double types.
implicit  object FloatReads extends Reads[Float] 
    Deserializer for Float types.
implicit  object IntReads extends Reads[Int] 
    Deserializer for Int types.
object  IsoDateReads extends Reads[Date] 
    ISO 8601 Reads 
implicit  object JsArrayMonoid extends Monoid[JsArray] 
implicit  object JsArrayReads extends Reads[JsArray] 
    Deserializer for JsArray.
implicit  val  JsArrayReducer: Reducer[JsValue, JsArray] 
implicit  object JsBooleanReads extends Reads[JsBoolean] 
    Deserializer for JsBoolean.
def JsErrorObj(knownValue: JsValue, key: String, args: JsValue*): JsObject 
    builds a JsErrorObj JsObject { VAL : "current known erroneous jsvalue", ERR : "the i18n key of the error msg", ARGS : "the args for the error msg" (JsArray) } 
implicit  object JsNumberReads extends Reads[JsNumber] 
    Deserializer for JsNumber.
implicit  object JsObjectMonoid extends Monoid[JsObject] 
implicit  object JsObjectReads extends Reads[JsObject] 
    Deserializer for JsObject.
implicit  val  JsObjectReducer: Reducer[JsObject, JsObject] 
implicit  object JsStringReads extends Reads[JsString] 
    Deserializer for JsString.
implicit  object JsValueReads extends Reads[JsValue] 
    Deserializer for JsValue.
implicit  object JsonNodeReads extends Reads[JsonNode] 
    Deserializer for Jackson JsonNode 
implicit  object LongReads extends Reads[Long] 
    Deserializer for Long types.
implicit  object ObjectNodeReads extends Reads[ObjectNode] 
    Deserializer for Jackson ObjectNode 
implicit  object ShortReads extends Reads[Short] 
    Deserializer for Short types.
implicit  object StringReads extends Reads[String] 
    Deserializer for String types.
object  TemporalParser 
    Parsing companion
implicit def Tuple10R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10)] 
implicit def Tuple11R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11)] 
implicit def Tuple12R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12)] 
implicit def Tuple13R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13)] 
implicit def Tuple14R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14)] 
implicit def Tuple15R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15)] 
implicit def Tuple16R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16)] 
implicit def Tuple17R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16], arg16: Reads[T17]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17)] 
implicit def Tuple18R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16], arg16: Reads[T17], arg17: Reads[T18]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18)] 
implicit def Tuple19R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16], arg16: Reads[T17], arg17: Reads[T18], arg18: Reads[T19]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19)] 
implicit def Tuple1R[T1](implicit arg0: Reads[T1]): Reads[(T1)] 
implicit def Tuple20R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16], arg16: Reads[T17], arg17: Reads[T18], arg18: Reads[T19], arg19: Reads[T20]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20)] 
implicit def Tuple21R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16], arg16: Reads[T17], arg17: Reads[T18], arg18: Reads[T19], arg19: Reads[T20], arg20: Reads[T21]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21)] 
implicit def Tuple22R[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9], arg9: Reads[T10], arg10: Reads[T11], arg11: Reads[T12], arg12: Reads[T13], arg13: Reads[T14], arg14: Reads[T15], arg15: Reads[T16], arg16: Reads[T17], arg17: Reads[T18], arg18: Reads[T19], arg19: Reads[T20], arg20: Reads[T21], arg21: Reads[T22]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22)] 
implicit def Tuple2R[T1, T2](implicit arg0: Reads[T1], arg1: Reads[T2]): Reads[(T1, T2)] 
implicit def Tuple3R[T1, T2, T3](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3]): Reads[(T1, T2, T3)] 
implicit def Tuple4R[T1, T2, T3, T4](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4]): Reads[(T1, T2, T3, T4)] 
implicit def Tuple5R[T1, T2, T3, T4, T5](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5]): Reads[(T1, T2, T3, T4, T5)] 
implicit def Tuple6R[T1, T2, T3, T4, T5, T6](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6]): Reads[(T1, T2, T3, T4, T5, T6)] 
implicit def Tuple7R[T1, T2, T3, T4, T5, T6, T7](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7]): Reads[(T1, T2, T3, T4, T5, T6, T7)] 
implicit def Tuple8R[T1, T2, T3, T4, T5, T6, T7, T8](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8)] 
implicit def Tuple9R[T1, T2, T3, T4, T5, T6, T7, T8, T9](implicit arg0: Reads[T1], arg1: Reads[T2], arg2: Reads[T3], arg3: Reads[T4], arg4: Reads[T5], arg5: Reads[T6], arg6: Reads[T7], arg7: Reads[T8], arg8: Reads[T9]): Reads[(T1, T2, T3, T4, T5, T6, T7, T8, T9)] 
implicit  val  ZoneIdReads: Reads[ZoneId] 
    Reads for the java.time.ZoneId type.
implicit def alternative(implicit a: Applicative[Reads]): Alternative[Reads] 
implicit def applicative(implicit applicativeJsResult: Applicative[JsResult]): Applicative[Reads] 
def apply[A](f: (JsValue) ⇒ JsResult[A]): Reads[A] 
def at[A](path: JsPath)(implicit reads: Reads[A]): Reads[A] 
implicit  val  bigDecReads: Reads[BigDecimal] 
    Deserializer for BigDecimal 
def charMapReads[V](implicit vr: Reads[V]): Reads[Map[Char, V]] 
    Deserializer for a Map[Char, V]
val  constraints: ConstraintReads 
def dateReads(pattern: String, corrector: (String) ⇒ String = identity): Reads[Date] 
    Reads for the java.util.Date type.
def email(implicit reads: Reads[String]): Reads[String] 
def enumNameReads[E <: Enumeration](enum: E): Reads[DefaultReads.enumNameReads.E.Value] 
    Reads for scala.Enumeration types using the name.
def filter[A](otherwise: JsonValidationError)(p: (A) ⇒ Boolean)(implicit reads: Reads[A]): Reads[A] 
def filterNot[A](error: JsonValidationError)(p: (A) ⇒ Boolean)(implicit reads: Reads[A]): Reads[A] 
implicit def functorReads(implicit a: Applicative[Reads]): Functor[Reads] 
def instantReads[T](parsing: T, corrector: (String) ⇒ String = identity)(implicit p: (T) ⇒ TemporalParser[Instant]): Reads[Instant] 
    Reads for the java.time.Instant type.
implicit  val  javaBigDecReads: Reads[BigDecimal] 
    Deserializer for BigDecimal 
val  javaDurationMillisReads: Reads[Duration] 
    Deserializer of Java Duration from a number of milliseconds.
def javaDurationNumberReads(unit: TemporalUnit): Reads[Duration] 
    Deserializer of Java Duration from an integer (long) number, using the specified temporal unit.
val  javaPeriodDaysReads: Reads[Period] 
    Deserializer of Java Period from a number (integer) of days.
val  javaPeriodMonthsReads: Reads[Period] 
    Deserializer of Java Period from a number (integer) of months.
val javaPeriodWeeksReads: Reads[Period] 
    Deserializer of Java Period from a number (integer) of weeks.
val  javaPeriodYearsReads: Reads[Period] 
    Deserializer of Java Period from a number (integer) of years.
def jsCopyTo[A <: JsValue](path: JsPath)(reads: Reads[A]): Reads[JsObject] 
def jsPick[A <: JsValue](path: JsPath)(implicit reads: Reads[A]): Reads[A] 
def jsPickBranch[A <: JsValue](path: JsPath)(implicit reads: Reads[A]): Reads[JsObject] 
def jsPrune(path: JsPath): Reads[JsObject] 
def jsPut(path: JsPath, a: ⇒ JsValue): Reads[JsObject] 
def jsUpdate[A <: JsValue](path: JsPath)(reads: Reads[A]): Reads[JsObject] 
def list[A](implicit reads: Reads[A]): Reads[List[A]] 
def localDateReads[T](parsing: T, corrector: (String) ⇒ String = identity)(implicit p: (T) ⇒ TemporalParser[LocalDate]): Reads[LocalDate] 
    Reads for the java.time.LocalDate type.
def localDateTimeReads[T](parsing: T, corrector: (String) ⇒ String = identity)(implicit p: (T) ⇒ TemporalParser[LocalDateTime]): Reads[LocalDateTime] 
    Reads for the java.time.LocalDateTime type.
def localTimeReads[T](parsing: T, corrector: (String) ⇒ String = identity)(implicit p: (T) ⇒ TemporalParser[LocalTime]): Reads[LocalTime] 
    Reads for the java.time.LocalTime type.
val  localeObjectReads: Reads[Locale] 
    Deserializer for a Locale from an object representation
implicit  val  localeReads: Reads[Locale] 
    Deserializer for a Locale from a IETF BCP 47 string representation
def map[A](implicit reads: Reads[A]): Reads[Map[String, A]] 
implicit def mapReads[V](implicit fmtv: Reads[V]): Reads[Map[String, V]] 
    Deserializer for a Map[String,V]
implicit def mapReads[K, V](k: (String) ⇒ JsResult[K])(implicit fmtv: Reads[V]): Reads[Map[K, V]] 
    Deserializer for a Map[K,V]
def max[O](m: O)(implicit reads: Reads[O], ord: Ordering[O]): Reads[O] 
    Defines a maximum value for a Reads.
def maxLength[M](m: Int)(implicit reads: Reads[M], p: (M) ⇒ TraversableLike[_, M]): Reads[M] 
def min[O](m: O)(implicit reads: Reads[O], ord: Ordering[O]): Reads[O] 
    Defines a minimum value for a Reads.
def minLength[M](m: Int)(implicit reads: Reads[M], p: (M) ⇒ TraversableLike[_, M]): Reads[M] 
def nullable[A](path: JsPath)(implicit reads: Reads[A]): Reads[Option[A]] 
    Reads a Option[T] search optional or nullable field at JsPath (field not found or null is None and other cases are Error).
def nullableWithDefault[A](path: JsPath, defaultValue: ⇒ Option[A])(implicit reads: Reads[A]): Reads[Option[A]] 
    Reads a Option[T] search nullable field at JsPath (null is None and other cases are Error).
def of[A](implicit r: Reads[A]): Reads[A] 
    The simpler of all Reads that just finds an implicit Reads[A] of the expected type
def offsetDateTimeReads[T](parsing: T, corrector: (String) ⇒ String = identity)(implicit p: (T) ⇒ TemporalParser[OffsetDateTime]): Reads[OffsetDateTime] 
    Reads for the java.time.OffsetDateTime type.
def optionNoError[A](implicit reads: Reads[A]): Reads[Option[A]] 
    Stupidly reads a field as an Option mapping any error (format or missing field) to None
def optionWithNull[T](implicit rds: Reads[T]): Reads[Option[T]] 
    very simple optional field Reads that maps "null" to None
val  path: PathReads 
def pattern(regex: ⇒ Regex, error: String = "error.pattern")(implicit reads: Reads[String]): Reads[String] 
    Defines a regular expression constraint for String values, i.e.
def pure[A](a: A): Reads[A] 
    Returns a JsSuccess(a) (with root path) for any JSON value read.
def pure[A](a: ⇒ A): Reads[A] 
def required(path: JsPath)(implicit reads: Reads[JsValue]): Reads[JsValue] 
def seq[A](implicit reads: Reads[A]): Reads[Seq[A]] 
def set[A](implicit reads: Reads[A]): Reads[Set[A]] 
def sqlDateReads(pattern: String, corrector: (String) ⇒ String = identity): Reads[Date] 
    Reads for the java.sql.Date type.
implicit  def  traversableReads[F[_], A](implicit bf: CanBuildFrom[F[_], A, F[A]], ra: Reads[A]): Reads[F[A]] 
    Generic deserializer for collections types.
implicit  val  uuidReads: Reads[UUID] 
def  verifying[A](cond: (A) ⇒ Boolean)(implicit rds: Reads[A]): Reads[A] 
def  verifyingIf[A](cond: (A) ⇒ Boolean)(subreads: Reads[_])(implicit rds: Reads[A]): Reads[A] 
def  withDefault[A](path: JsPath, defaultValue: ⇒ A)(implicit reads: Reads[A]): Reads[A] 
def  zonedDateTimeReads[T](parsing: T, corrector: (String) ⇒ String = identity)(implicit p: (T) ⇒ TemporalParser[ZonedDateTime]): Reads[ZonedDateTime] 
    Reads for the java.time.ZonedDateTime type.

///*** PLay JSON -  object Writes members 
implicit  object BigDecimalWrites extends Writes[BigDecimal] 
    Serializer for BigDecimal types.
implicit  object BooleanWrites extends Writes[Boolean] 
    Serializer for Boolean types.
implicit  object ByteWrites extends Writes[Byte] 
    Serializer for Byte types.
implicit  object DefaultDateWrites extends Writes[Date] 
    Default Serializer java.util.Date -> JsNumber(d.getTime (nb of ms)) 
implicit  val  DefaultInstantWrites: Writes[Instant] 
    The default typeclass to write a java.time.Instant, using '2011-12-03T10:15:30Z' format.
implicit  val  DefaultLocalDateTimeWrites: Writes[LocalDateTime] 
    The default typeclass to write a java.time.LocalDateTime, using '2011-12-03T10:15:30' format.
implicit  val  DefaultLocalDateWrites: Writes[LocalDate] 
    The default typeclass to write a java.time.LocalDate, using '2011-12-03' format.
implicit  val  DefaultLocalTimeWrites: Writes[LocalTime] 
    The default typeclass to write a java.time.LocalTime, using '10:15:30' format.
implicit  val  DefaultOffsetDateTimeWrites: Writes[OffsetDateTime] 
    The default typeclass to write a java.time.OffsetDateTime, using '2011-12-03T10:15:30+02:00' format.
implicit  val  DefaultZonedDateTimeWrites: Writes[ZonedDateTime] 
    The default typeclass to write a java.time.ZonedDateTime, using '2011-12-03T10:15:30+01:00[Europe/Paris]' format.
implicit  object DoubleWrites extends Writes[Double] 
    Serializer for Double types.
implicit  object FloatWrites extends Writes[Float] 
    Serializer for Float types.
val InstantEpochMilliWrites: Writes[Instant] 
    Serializer for java.time.Instant as JSON number.
implicit  object IntWrites extends Writes[Int] 
    Serializer for Int types.
implicit  object JsValueWrites extends Writes[JsValue] 
    Serializer for JsValues.
implicit  object JsonNodeWrites extends Writes[JsonNode] 
    Serializer for Jackson JsonNode 
val LocalDateEpochMilliWrites: Writes[LocalDate] 
    Serializer for java.time.LocalDate as JSON number.
val LocalDateTimeEpochMilliWrites: Writes[LocalDateTime] 
    Serializer for java.time.LocalDateTime as JSON number.
val LocalTimeNanoOfDayWrites: Writes[LocalTime] 
    Serializer for java.time.LocalTime as JSON number.
implicit  object LongWrites extends Writes[Long] 
    Serializer for Long types.
implicit def OptionWrites[T](implicit fmt: Writes[T]): Writes[Option[T]] 
    Serializer for Option.
implicit  object ShortWrites extends Writes[Short] 
    Serializer for Short types.
implicit  object StringWrites extends Writes[String] 
    Serializer for String types.
object  TemporalFormatter 
    Formatting companion
implicit def Tuple10W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10)] 
implicit def Tuple11W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11)] 
implicit def Tuple12W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12)] 
implicit def Tuple13W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13)] 
implicit def Tuple14W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14)] 
implicit def Tuple15W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15)] 
implicit def Tuple16W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16)] 
implicit def Tuple17W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16], arg16: Writes[T17]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17)] 
implicit def Tuple18W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16], arg16: Writes[T17], arg17: Writes[T18]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18)] 
implicit def Tuple19W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16], arg16: Writes[T17], arg17: Writes[T18], arg18: Writes[T19]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19)] 
implicit def Tuple1W[T1](implicit arg0: Writes[T1]): Writes[(T1)] 
implicit def Tuple20W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16], arg16: Writes[T17], arg17: Writes[T18], arg18: Writes[T19], arg19: Writes[T20]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20)] 
implicit def Tuple21W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16], arg16: Writes[T17], arg17: Writes[T18], arg18: Writes[T19], arg19: Writes[T20], arg20: Writes[T21]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21)] 
implicit def Tuple22W[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9], arg9: Writes[T10], arg10: Writes[T11], arg11: Writes[T12], arg12: Writes[T13], arg13: Writes[T14], arg14: Writes[T15], arg15: Writes[T16], arg16: Writes[T17], arg17: Writes[T18], arg18: Writes[T19], arg19: Writes[T20], arg20: Writes[T21], arg21: Writes[T22]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22)] 
implicit def Tuple2W[T1, T2](implicit arg0: Writes[T1], arg1: Writes[T2]): Writes[(T1, T2)] 
implicit def Tuple3W[T1, T2, T3](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3]): Writes[(T1, T2, T3)] 
implicit def Tuple4W[T1, T2, T3, T4](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4]): Writes[(T1, T2, T3, T4)] 
implicit def Tuple5W[T1, T2, T3, T4, T5](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5]): Writes[(T1, T2, T3, T4, T5)] 
implicit def Tuple6W[T1, T2, T3, T4, T5, T6](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6]): Writes[(T1, T2, T3, T4, T5, T6)] 
implicit def Tuple7W[T1, T2, T3, T4, T5, T6, T7](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7]): Writes[(T1, T2, T3, T4, T5, T6, T7)] 
implicit def Tuple8W[T1, T2, T3, T4, T5, T6, T7, T8](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8)] 
implicit def Tuple9W[T1, T2, T3, T4, T5, T6, T7, T8, T9](implicit arg0: Writes[T1], arg1: Writes[T2], arg2: Writes[T3], arg3: Writes[T4], arg4: Writes[T5], arg5: Writes[T6], arg6: Writes[T7], arg7: Writes[T8], arg8: Writes[T9]): Writes[(T1, T2, T3, T4, T5, T6, T7, T8, T9)] 
implicit  object UuidWrites extends Writes[UUID] 
    Serializer for java.util.UUID 
implicit  val  ZoneIdWrites: Writes[ZoneId] 
    Serializer for java.time.ZoneId as JSON string.
val ZonedDateTimeEpochMilliWrites: Writes[ZonedDateTime] 
    Serializer for java.time.ZonedDateTime as JSON number.
def apply[A](f: (A) ⇒ JsValue): Writes[A] 
implicit def arrayWrites[T](implicit arg0: ClassTag[T], arg1: Writes[T]): Writes[Array[T]] 
    Serializer for Array[T] types.
def at[A](path: JsPath)(implicit wrs: Writes[A]): OWrites[A] 
val constraints: ConstraintWrites 
implicit  val  contravariantfunctorWrites: ContravariantFunctor[Writes] 
def dateWrites(pattern: String): Writes[Date] 
    Serializer for java.util.Date
implicit def enumNameWrites[E <: Enumeration]: Writes[DefaultWrites.enumNameWrites.E.Value] 
    Serializer for scala.Enumeration by name.
val javaDurationMillisWrites: Writes[Duration] 
    Serializer of Java Duration as a number of milliseconds.
implicit  val  javaDurationWrites: Writes[Duration] 
    Serializer of Java Duration using ISO representation (e.g.
implicit  val  javaPeriodWrites: Writes[Period] 
    Serializer of Java Period using ISO representation (e.g.
def jsPick(path: JsPath): Writes[JsValue] 
def jsPickBranch(path: JsPath): OWrites[JsValue] 
def jsPickBranchUpdate(path: JsPath, wrs: OWrites[JsValue]): OWrites[JsValue] 
def list[A](implicit writes: Writes[A]): Writes[List[A]] 
val localeObjectWrites: OWrites[Locale] 
    Serializer for a Locale using a object representation
implicit  val  localeWrites: Writes[Locale] 
    Serializer for a Locale using the IETF BCP 47 string representation
def map[A](implicit writes: Writes[A]): OWrites[Map[String, A]] 
implicit def mapWrites[V](implicit arg0: Writes[V]): OWrites[Map[String, V]] 
    Serializer for Map[String,V] types.
def nullable[A](path: JsPath)(implicit wrs: Writes[A]): OWrites[Option[A]] 
    writes a optional field in given JsPath : if None, doesnot write field at all.
def of[A](implicit w: Writes[A]): Writes[A] 
def optionWithNull[A](implicit wa: Writes[A]): Writes[Option[A]] 
P   ure Option Writer[T] which writes "null" when None which is different from JsPath.writeNullable which omits the field when None 
val path: PathWrites 
def pruned[A](implicit w: Writes[A]): Writes[A] 
def pure[A](fixed: ⇒ A)(implicit wrs: Writes[A]): Writes[JsValue] 
def pure[A](path: JsPath, fixed: ⇒ A)(implicit wrs: Writes[A]): OWrites[JsValue] 
def seq[A](implicit writes: Writes[A]): Writes[Seq[A]] 
def set[A](implicit writes: Writes[A]): Writes[Set[A]] 
def sqlDateWrites(pattern: String): Writes[Date] 
    Serializer for java.sql.Date
def temporalWrites[A <: Temporal, B](formatting: B)(implicit f: (B) ⇒ TemporalFormatter[A]): Writes[A] 
    Serializer for Java8 temporal types (e.g.
def transform[A](w: Writes[A])(f: (A, JsValue) ⇒ JsValue): Writes[A] 
    Transforms the resulting JsValue using the given function, which is also applied with the initial input.
implicit def traversableWrites[A](implicit arg0: Writes[A]): Writes[Traversable[A]] 
    Serializer for Traversables types.