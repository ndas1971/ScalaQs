package examples

// $ spark-submit --class examples.SparkHiveExample2  --master local[4] target/scala-2.11/learning-assembly.jar

import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession


object SparkHiveExample2 {


  case class Student (id:String, name:String, phone:String, email:String)


  def main(args: Array[String]) {
    // When working with Hive, one must instantiate `SparkSession` with Hive support, including
    // connectivity to a persistent Hive metastore, support for Hive serdes, and Hive user-defined
    // functions. Users who do not have an existing Hive deployment can still enable Hive support.
    // When not configured by the hive-site.xml, the context automatically creates `metastore_db`
    // in the current directory and creates a directory configured by `spark.sql.warehouse.dir`,
    // which defaults to the directory `spark-warehouse` in the current directory that the spark
    // application is started.

    
    // warehouseLocation points to the default location for managed databases and tables
    val warehouseLocation = "file:///tmp/spark-warehouse"

    val spark = SparkSession
      .builder()
      .appName("Spark Hive Example")
      .config("spark.sql.warehouse.dir", warehouseLocation)
      .enableHiveSupport()
      .getOrCreate()

    import spark.implicits._
    import spark.sql
    
      
    val students = spark.read.format("csv")
                           .option("sep", "|")
                           .option("header", true)
                           .load(raw"D:\Desktop\PPT\spark\data\StudentDataHeader.csv").as[Student]
                           
    students.show()
    students.write.mode(org.apache.spark.sql.SaveMode.Overwrite).saveAsTable("studentpq3")
    
    
    

    // Queries are expressed in HiveQL
    sql("SELECT * FROM studentpq3").show()
    
    // Aggregation queries are also supported.
    sql("SELECT COUNT(*) FROM studentpq3").show()
    

    // The results of SQL queries are themselves DataFrames and support all normal functions.
    val sqlDF = sql("SELECT name, email FROM studentpq3 WHERE id < 10 ORDER BY name")

    sqlDF.show()
    
    
    // read
    val studentDFrame = spark.read.table("studentpq3").as[Student]
    
    studentDFrame.createOrReplaceTempView("studentsView")

    // Queries can then join DataFrame data with data stored in Hive.
    sql("SELECT * FROM studentsView r JOIN studentpq3 s ON r.id = s.id").show()
    

    spark.stop()
  }
}
