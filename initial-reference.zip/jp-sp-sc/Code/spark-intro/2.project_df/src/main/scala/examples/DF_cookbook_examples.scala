package examples

// $ spark-submit --class examples.DataFrameFromProductClass  --master local[4] target/scala-2.11/learning-assembly.jar

import org.apache.spark._
import org.apache.spark.sql._
import org.apache.spark.rdd._
import scala.util.Try
import org.apache.spark.sql.types._
import scala.reflect.io.File
import scala.io.Source

object DataFrameFromProductClass extends App {

  val conf = new SparkConf().setAppName("DataWith33Atts")
  val spark = SparkSession.builder().config(conf).getOrCreate()
  
  import spark.implicits._  //rdd to DF conversion 

  val rddOfStudents = convertCSVToStudents(raw"D:\Desktop\PPT\spark\data\student-mat_header_removed.csv", spark.sparkContext)
  
  //Create DataFrame
  val studentDFrame = rddOfStudents.toDF()

  studentDFrame.printSchema()

  studentDFrame.show()
  
  spark.stop()

  def convertCSVToStudents(filePath: String, sc: SparkContext): RDD[Student] = {
    //first line is header so, update the csv file 
    //better option is to use spark.load.csv()
    val rddOfOptionStudents: RDD[Option[Student]] = sc.textFile(filePath).map(eachLine => Student(eachLine))
    rddOfOptionStudents.flatMap(x => x)
  }

}




object DataFrameCSV extends App{
  
  val conf = new SparkConf().setAppName("DataLoadCSV")
  val spark = SparkSession.builder().config(conf).getOrCreate()
  
  import spark.implicits._  //rdd to DF conversion 
  
  //Now, lets load our pipe-separated file
  //students is of type org.apache.spark.sql.DataFrame
  val students = spark.read.format("csv")
                           .option("sep", "|")
                           .option("header", true)
                           .load(raw"D:\Desktop\PPT\spark\data\StudentDataHeader.csv")
  
  //Print the schema of this input
  students.printSchema
  
   //Sample n records along with headers 
  students.show (3)
  
  //Sample 20 records along with headers 
  students.show ()  
  
  //Sample the first 5 records
  students.head(5).foreach(println)
  
  //Alias of head
  students.take(5).foreach(println)
    
  //Select just the email id to a different dataframe
  val emailDataFrame:DataFrame=students.select("email")
  
  emailDataFrame.show(3)
  
  //Select more than one column and create a different dataframe
  val studentEmailDF=students.select("name", "email")
  
  studentEmailDF.show(3)
  
  //Print the first 5 records that has student id more than 5
  students.filter("id > 5").show(7)
  
  //Records with No student names
  students.filter("name =''").show(7)
  
  //Show all records whose student names are empty or null
  students.filter("name ='' OR name = 'NULL'").show(7)
  
  //Get all students whose name starts with the letter 'M'
  students.filter("SUBSTR(name,0,1) ='M'").show(7)
  
  //The real power of DataFrames lies in the way we could treat it like a relational table and use SQL to query
  //Step 1. Register the students dataframe as a table with name "students" (or any name)
  students.registerTempTable("students")
  
  //Step 2. Query it away
  val dfFilteredBySQL=spark.sql("select * from students where name!='' order by email desc")
  
  dfFilteredBySQL.show(7)
  
  //You could also optionally order the dataframe by column without registering it as a table.
  //Order by descending order
  students.sort(students("name").desc).show(10)
  
  //Order by a list of column names - without using SQL
  students.sort("name", "id").show(10)
  
  
    
  //Modify dataframe - pick studentname and email columns, change 'studentName' column name to just 'name' 
  val copyOfStudents=students.select(students("name").as("studentName"), students("email"))
  
  copyOfStudents.show()
  //Save this new dataframe with headers and with file name "ModifiedStudent.csv"
  copyOfStudents.write.mode(SaveMode.Overwrite).option("header", true).save(raw"D:\Desktop\PPT\spark\data\ModifiedStudent.csv")
  
  spark.stop()
  
}



object DataFrameFromJSON extends App {

  val conf = new SparkConf().setAppName("DataFrameFromJSON")
  val spark = SparkSession.builder().config(conf).getOrCreate()
  
  import spark.implicits._  //rdd to DF conversion 

  //puts the file profiles.json into HDFS, starts hadoop etc 

  val dFrame = spark.read.json("hdfs://localhost:19000/data/profiles.json")
  dFrame.printSchema()
  dFrame.show()

  //infer schema 
  val strRDD = spark.sparkContext.textFile("hdfs://localhost:19000/data/profiles.json")
  val jsonRDD = spark.read.json(strRDD)

  jsonRDD.printSchema()
  jsonRDD.show()

  //Explicit Schema Definition
  val profilesSchema = StructType(Seq(
      StructField("id", StringType, true),
      StructField("about", StringType, true),
      StructField("address", StringType, true),
      StructField("age", IntegerType, true),
      StructField("company", StringType, true),
      StructField("email", StringType, true),
      StructField("eyeColor", StringType, true),
      StructField("favoriteFruit", StringType, true),
      StructField("gender", StringType, true),
      StructField("name", StringType, true),
      StructField("phone", StringType, true),
      StructField("registered", TimestampType, true),
      StructField("tags", ArrayType(StringType), true)))

  //explicit schema 
  val jsonRDDWithSchema = spark.read.schema(profilesSchema).json(strRDD)

  jsonRDDWithSchema.printSchema() //Has timestamp
  jsonRDDWithSchema.show()

  jsonRDDWithSchema.registerTempTable("profilesTable")

  //Filter based on timestamp
  val filterCount = spark.sql("select * from profilesTable where registered> CAST('2014-08-26 00:00:00' AS TIMESTAMP)").count

  val fullCount = spark.sql("select * from profilesTable").count

  println("All Records Count : " + fullCount) //200
  println("Filtered based on timestamp count : " + filterCount) //106

  //Writes schema as JSON to file
  File(raw"D:\Desktop\PPT\spark\data\profileSchema.json").writeAll(profilesSchema.json)

  val loadedSchema = DataType.fromJson(Source.fromFile(raw"D:\Desktop\PPT\spark\data\profileSchema.json").mkString)
  //Print loaded schema
  println(loadedSchema.prettyJson)

}



object DataFramePreparation extends App{
  
  val conf = new SparkConf().setAppName("DataFrameFromJSON")
  val spark = SparkSession.builder().config(conf).getOrCreate()
  
  import spark.implicits._  //rdd to DF conversion 

  val students1= spark.read.format("csv")
                           .option("sep", "|")
                           .option("header", true)
                           .load(raw"D:\Desktop\PPT\spark\data\StudentPrep1.csv")
  val students2= spark.read.format("csv")
                           .option("sep", "|")
                           .option("header", true)
                           .load(raw"D:\Desktop\PPT\spark\data\StudentPrep2.csv")
  
//  1. Combining two or more DataFrames
  val allStudents=students1.union(students2)
  println ("union")
  allStudents.foreach( row => println(row) )
  
  //2. intersection
  val intersection=students1.intersect(students2)
  println ("intersection")
  intersection.foreach(row => println(row))
  
  //3. Print all distinct
  val distinctStudents=allStudents.distinct
  println ("distinct")
  distinctStudents.foreach(row => println(row))
  println(distinctStudents.count())
  
  //4.Subtraction
  val subtraction=students1.except(students2)
  println ("subtraction")
  subtraction.foreach(row => println(row))

  //Sort by Id - Treating it a number 
  val sortByIdRdd=allStudents.rdd.map(eachRow=>(Try(eachRow.getString(0).toInt).getOrElse(Int.MaxValue),eachRow)).sortByKey(true)
  println ("sorting")
  sortByIdRdd.values.foreach(row => println(row))
  
  //Removes duplicates by id and holds on to the row with the longest name
  val idStudentPairs=allStudents.rdd.map(eachRow=>(eachRow.getString(0),eachRow))
  val longestNameRdd=idStudentPairs.reduceByKey((row1, row2) =>
  	if (row1.getString(1).length()>row2.getString(1).length()) row1 else row2
  )

  longestNameRdd.values.foreach(row => println(row))
  
}

