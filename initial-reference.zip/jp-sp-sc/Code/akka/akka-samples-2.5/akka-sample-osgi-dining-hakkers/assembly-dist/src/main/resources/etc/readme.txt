Configuration files for the Karaf etc/ directory.

Place Karaf ConfigAdmin files here.
