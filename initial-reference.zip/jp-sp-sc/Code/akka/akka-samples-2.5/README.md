## Akka Sample Projects

This repository contains a number of projects that illustrate various usages of Akka. Samples are written in Scala and Java and use sbt or maven for build definitions.
