///* Quick spark
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.ml.linalg._
import org.apache.spark.ml.tuning._
import org.apache.spark.ml._
import org.apache.spark.ml.classification._
import org.apache.spark.ml.feature._
import org.apache.spark.mllib.evaluation._
import org.apache.spark.ml.evaluation._


val conf = new SparkConf().setAppName("CSV").setMaster("local[*]")
implicit val sc = new SparkContext(conf)
implicit val sqlContext=new SQLContext(sc)
implicit val spark=sqlContext.sparkSession

///* DF operations 
import spark.implicits._
val iris = spark.read.option("header", true).option("inferSchema",true).csv(raw"D:/Desktop/PPT/spark/data/iris.csv")

iris.printSchema
iris.show(3)
iris.show()  
iris.head(5).foreach(println)
iris.take(5).foreach(println)

//Select more than one column and create a different dataframe
val irisSW=iris.select("name", "SepalWidth")
irisSW.show(3)
iris.filter("""Name == "Iris-setosa" """).show(7)
iris.filter("""Name == "Iris-setosa" OR Name = "Iris-versicolor" """).show(7)
//Row as get*(index) to get a particular value 
iris.filter("""Name == "Iris-setosa" """).map{row => row.getDouble(0)}.show()
//other functions 
iris.sort("Name").show()
iris.groupBy("Name").count().show()
iris.groupBy("Name").max().collect()
iris.groupBy("Name").agg($"Name", max("SepalLength"),min("SepalWidth"),avg("PetalLength"),stddev_samp("PetalWidth")).show()
//OR 
iris.groupBy("Name").agg(Map("SepalLength" -> "max")).collect()

//Groupby 
iris.registerTempTable("iris")
val dfFilteredBySQL=spark.sql("select Name, max(SepalWidth) from iris group by Name order by Name desc")
dfFilteredBySQL.show(7)
spark.stop()

//* Classifications 
//load like below 
case class Features(x:Double, y:Double, z:Double, a:Double)
val convert = udf((x: Long, y: Double, z: Double, a:Double) => Features(x,y,z,a))
val irisnew2 = iris.withColumn("features", convert($"SepalLength",$"SepalWidth",$"PetalLength",$"PetalWidth"))
irisnew2.show()


//Load like below 
def loadIris(filePath: String)(implicit spark: SparkSession): DataFrame = { 
    val irisData = spark.sparkContext.textFile(filePath).zipWithIndex.filter{case (d,idx) => idx != 0 }.map{case (d,idx) => d}.flatMap { text => 
      text.split("\n").toList.map(_.split(",")).collect { 
        case Array(sepalLength, sepalWidth, petalLength, petalWidth, irisType) => 
          (Vectors.dense(sepalLength.toDouble, sepalWidth.toDouble, petalLength.toDouble, petalWidth.toDouble), irisType) 
      } 
    } 
    spark.createDataFrame(irisData).toDF("features", "Name") 
  }  
  
val irisnew = loadIris(raw"D:/Desktop/PPT/spark/data/iris.csv")
  
//Classifications 
val (trainingData, testData) = {
  // Experiment with adjusting the size of the training set vs the test set
  val split = irisnew.randomSplit(Array(0.8, 0.2))
  (split(0), split(1))
}

/*  Build the Pipeline
 *  
 *  StringIndexer:
 *  The iris types are all Strings. These need to be indexed (i.e. turned into unique doubles)
 *  in order to work with a classifier. e.g. "Iris-setosa" might become 1.0
 *  
 *  RandomForestClassifier:
 *  A multiclass classifier using a collection of decision trees. This classifier will create
 *  a model for predicting the "class" (i.e. iris type) of a flower based on its measurements
 *  
 *  Pipeline: Indexer -> Classifier
 */
val indexer = new StringIndexer().setInputCol("Name").setOutputCol("label")
val classifier = new RandomForestClassifier().setFeaturesCol("features")
val pipeline = new Pipeline().setStages(Array(indexer, classifier))
  
/*
 * There are a large number of "hyper" parameters that we can change to tune the accuracy
 * of our classifier. Instead of manually testing them, we can build a grid of parameters
 * and use a `TrainValidationSplit` to test the effectiveness of each combination
 */
val paramGrid = new ParamGridBuilder()
  .addGrid(classifier.maxDepth, Array(2, 5, 10))
  .addGrid(classifier.numTrees, Array(10, 20, 40))
  .addGrid(classifier.impurity, Array("gini", "entropy"))
  .build()

val trainValidationSplit = new TrainValidationSplit()
  .setEstimator(pipeline)
  .setEvaluator(new MulticlassClassificationEvaluator())
  .setEstimatorParamMaps(paramGrid)
  // Use 80% of the data to train and 20% to validate
  .setTrainRatio(0.8)

// Create our model with the training-set of data
trainingData.cache()
val model = trainValidationSplit.fit(trainingData)

// Use the model with our test-set of data
testData.cache()
val testResults = model.transform(testData)

/*
 * Review the test. Our model has added the following columns:
 * - 'probability' a probability vector showing the odds the given flower is iris type iris_i for
 *    all i. e.g. [0.0, 0.4, 0.6] translates to 0% chance it is iris_0.0, 40% chance it
 *    is iris_1.0, 60% chance it is iris_2.0
 * - 'prediction' the label for the iris type that our model believes this row should be classified
 *    as. e.g. 2.0
 *    
 * We can compare the predicted label in `prediction` to the actual label in `label` to see how well
 * we did. A more advanced system might ignore predictions with a low probability in the `probability` vector
 */
val predAndLabels = testResults.select("prediction", "label").map { case Row(prediction: Double, label: Double) => 
      (prediction, label)
    }
val metrics = new MulticlassMetrics(predAndLabels.rdd)
println(s"Precision ${metrics.precision}")
println(s"Recall ${metrics.recall}")
println(s"F1 Score ${metrics.fMeasure}")

///** With clustering 
def mostCommon[A](l: List[A]): A = {
    l.groupBy(identity).mapValues(_.size).maxBy(_._2)._1
}

def accuracyOf(irisType: String, predsAndTypes: List[Row]): Double = {
    val clusters = predsAndTypes.collect {
        case Row(prediction: Int, iris: String) if iris == irisType => prediction
    }
    val cluster = mostCommon(clusters)
    clusters.filter(_ == cluster).size / clusters.size.toDouble
}

import org.apache.spark.ml.clustering._
val (trainingData, testData) = {
  // Experiment with adjusting the size of the training set vs the test set
  val split = irisnew.randomSplit(Array(0.8, 0.2))
  (split(0), split(1))
}

/*
 *  KMeans will look at the feature vector and cluster (or "lump") the
 *  data into `K` groups (here we have chosen 3 groups) based on how similar their properties are.
 *  
 *  An important point: KMeans does not look at the labels i.e. it is an unsupervised learning
 *  algorithm. This is very useful if we have unlabeled data and we are looking to find related data
 *  e.g. given a document, find related documents.
 */
val kmeans = new KMeans()
  .setK(3)
  .setFeaturesCol("features")

// Create 3 clusters based on our training data
trainingData.cache()
val model = kmeans.fit(trainingData)

/*
 *  For each flower in the test data, determine which cluster it should belong to.
 *  An iris will be assigned to a cluster based on which flowers in the training data
 *  it most closely resembles
 */
testData.cache()
val predictions = model.transform(testData)

/*
 * Primary Question: Can KMeans accurately guess an iris' type without using the labels in training?
 * Hypothesis: Yes, the clusters created by KMeans will roughly align with the iris types
 *
 * This analysis makes the assumption that the majority of two or three iris types are not in a single cluster
 */
val predsAndTypes = predictions.select("prediction", "Name").collect().toList
    predsAndTypes.foreach { case Row(prediction: Int, irisType: String) =>
        println(s"Assigned Cluster: $prediction\tIris Type: $irisType")
}

val setosaAccuracy = accuracyOf("Iris-setosa", predsAndTypes)
println(s"Accuracy of iris setosa is ${setosaAccuracy * 100}")
val versicolorAccuracy = accuracyOf("Iris-versicolor", predsAndTypes)
println(s"Accuracy of iris versicolor is ${versicolorAccuracy * 100}")
val virginicasAccuracy = accuracyOf("Iris-virginica", predsAndTypes)
println(s"Accuracy of iris virginicas is ${virginicasAccuracy * 100}")















/******DAY-1 ********/


///+++ Spark Introduction 
Apache Spark 2 Tuning .pdf
    Apache Spark
    Spark on Hadoop YARN
    Spark 2.x vs Spark 1.x
    Spark 2.x – Performance Improvements
Mastering_spark.docx
     Spark Jobs anatomy
     
     
     
///submit 

$ spark-shell --master local[4] --driver-memory 2G
//sc(spark context) and spark(spark session) are autocreated 

//or submit 
$ sbt assembly 
$ spark-submit  --master local[4] --class examples.WordCountSubmit target/scala-2.11/learning-assembly.jar  args 

//with script starting as without setMaster 
val conf = new SparkConf().setAppName("NAME") 
val sc = new SparkContext(conf)

//or in sbt console 
$ sbt console 
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.{functions => F}
import org.apache.spark.ml.{linalg => ML}
import org.apache.spark.mllib.linalg._
import org.apache.spark.ml._
import org.apache.spark.ml.feature._
import org.apache.spark.ml.evaluation._
import org.apache.spark.ml.param._
import org.apache.spark.ml.regression._
import org.apache.spark.ml.tuning._
import org.apache.spark.ml.classification._
import org.apache.spark.mllib.evaluation._
import org.apache.spark.mllib.regression._
import org.apache.spark.mllib.classification._
import org.apache.spark.mllib.tree._
import org.apache.spark.mllib.tree.configuration._
import org.apache.spark.mllib.tree.model._
import org.apache.spark.mllib.clustering._
import org.apache.spark.graphx._
import org.apache.spark.graphx.lib._


val conf = new SparkConf().setAppName("EXPERIMENT").setMaster("local[*]")
implicit val sc = new SparkContext(conf)
implicit val sqlContext=new SQLContext(sc)
implicit val spark= sqlContext.sparkSession

import spark.implicits._ 
import scala.concurrent.duration._ 
import scala.reflect.runtime.universe._ 
def getType[T:TypeTag](obj: T) = typeTag[T].tpe


//do activities here 
sc.stop()


//Check application web UI at http://192.168.1.4:4040  (http://<driver>:4040 )(till sc is not stopped)
//check Spark properties in the 'Environment' tab
//spark properties are at conf/spark-defaults.conf, SparkConf(), or the command line will appear.
//Help of properties: https://spark.apache.org/docs/latest/configuration.html#available-properties


///Spark-Configuration 
//There are the following places where a Spark application looks for Spark properties (in the order of importance from the least important to the most important):
    conf/spark-defaults.conf 
        the configuration file with the default Spark properties. Read spark-defaults.conf.
    --conf or -c 
        the command-line option used by spark-submit (and other shell scripts that use spark-submit or spark-class under the covers, e.g. spark-shell)
    SparkConf 
        where user programatically set options 
RuntimeConfig
    Runtime configuration interface for Spark. To access this, use SparkSession.conf.
    Options set here are automatically propagated to the Hadoop configuration during I/O. 
SparkConf
    Configuration for a Spark application. Used to set various Spark parameters as key-value pairs. 

>>> sc.setLogLevel("WARN")
>>> spark.conf.get("spark.app.name")
>>> sc.getConf.getAll //spark.sparkContext.getConf.getAll or spark.conf.getAll
[('spark.app.id', 'local-1532678326302'), ('spark.sql.catalogImplementation', 'hive'), 
('spark.driver.host', '192.168.1.2'), ('spark.rdd.compress', 'True'), 
('spark.serializer.objectStreamReset', '100'), ('spark.master', 'local[*]'), 
('spark.executor.id', 'driver'), ('spark.submit.deployMode', 'client'), 
('spark.driver.port', '60209'), ('spark.app.name', 'PySparkShell'), 
('spark.ui.showConsoleProgress', 'true')]

//SQL parameters 
spark.sql("set -v").show(200, truncate=false)
spark.sql("set -v").select($"key",'value).show(200, truncate=false) //'
spark.sql("set -v").select($"key",'value).count  //'


///Properties that specify some time duration should be configured with a unit of time. 
//The following format is accepted:
    25ms (milliseconds)
    5s (seconds)
    10m or 10min (minutes)
    3h (hours)
    5d (days)
    1y (years)


//Properties that specify a byte size should be configured with a unit of size. 
//The following format is accepted:
    1b (bytes)
    1k or 1kb (kibibytes = 1024 bytes)
    1m or 1mb (mebibytes = 1024 kibibytes)
    1g or 1gb (gibibytes = 1024 mebibytes)
    1t or 1tb (tebibytes = 1024 gibibytes)
    1p or 1pb (pebibytes = 1024 tebibytes)
    
//The application web UI at http://<driver>:4040 lists Spark properties in the “Environment” tab.

//By command line 
//spark-submit will also read configuration options from conf/spark-defaults.conf
$ spark-submit --name "My app" --class "Main" --master local[4] --conf spark.eventLog.enabled=true
  --conf "spark.executor.extraJavaOptions=-verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps" myApp.jar
        
        
//Properties set directly on the SparkConf take highest precedence, 
//then flags passed to spark-submit or spark-shell, then options in the spark-defaults.conf file

//List of Properties -https://spark.apache.org/docs/latest/configuration.html


///Detals of execution 
//Application -> Job -> many stages, stage boundary at map and reduce(ShuffleBoundary)
//stage -> many task , each task -> one partition of RDD - uses one core of Executors , 
//one core -> one thread 
//RDD -> many partitions 
//node -> many executors 

//Transformations like repartition and reduceByKey induce stage boundaries(shuffling is required)
//Transformations with (usually) Narrow dependencies:Each partition of the parent RDD is used by at most one partition of the child RDD. 
•	map
•	mapValues
•	flatMap
•	filter
•	mapPartitions
•	mapPartitionsWithIndex
//Transformations with (usually) Wide dependencies: (might cause a shuffle):Each partition of the parent RDD may be used by multiple child partitions 
•	cogroup
•	groupWith
•	join
•	leftOuterJoin
•	rightOuterJoin
•	groupByKey
•	reduceByKey
•	combineByKey
•	distinct
•	intersection
•	repartition
•	coalesce


//To increase parallelism - increase partitions - use spark.conf/sc.getConf.set(key,value)
1.Explicitely mention more partitions eg in sc.textfile(), rdd1.reduceByKey(_ + _, numPartitions = X), where X=parent partitions*1.5,(heuristic) 
2.Use rdd.coalesce(no) to decrease partition with min shuffle, or rdd/df.repartition(no) to increase with full shuffle    
3.Set spark.sql.shuffle.partitions configures the number of partitions that are used when shuffling data frame for joins or aggregations.
4.Set spark.default.parallelism is the default number of partitions in raw RDDs returned by transformations like join, reduceByKey, and parallelize 


///Stages 
//A stage is consisting of many parallel tasks where one task is on one  partition 

//When a job is submitted, a new stage is created with the parent ShuffleMapStage, they can be created from scratch or linked to, i.e. shared, if other jobs use them already.
//DAGScheduler splits up a job into a collection of stages. 
//Each stage contains a sequence of narrow transformations that can be completed without shuffling the entire data set, separated at shuffle boundaries, i.e. where shuffle occurs.


//stage is uniquely identified by  id . 
//When a stage is created, 
//DAGScheduler increments internal counter  nextStageId  to track the number of stage submissions.

//stage can only work on the partitions of a single RDD (identified by  rdd ), 
//but can be associated with many other dependent parent stages (via internal field  parents ), 
//with the boundary of a stage marked by shuffle dependencies.       
        
        
//There are two types of stages:
•ShuffleMapStage is an intermediate stage (in the execution DAG) that produces data for other stage(s). 
 It writes map output files for a shuffle. 
•ResultStage is the final stage that executes a Spark action in a user program by running a function on an RDD.

//Submitting a stage can therefore trigger execution of a series of dependent parent stages   

//Display means 
[Stage7:===========>                              (14174 + 5) / 62500]        
        
//Stage 7: shows the stage you are in now, 
//(14174 + 5) / 62500] is (numCompletedTasks + numActiveTasks) / totalNumOfTasksInThisStage 

//The progress bar shows numCompletedTasks / totalNumOfTasksInThisStage.

//shown when both spark.ui.showConsoleProgress is true (by default) 
//and log level in conf/log4j.properties is INFO (log.isInfoEnabled is true).
       
        
        
        
///Spark - partition (aka split) 
//a logical chunk of a large distributed data set, called RDD 
//(an be imagined as rows of elements, eg for 1D, org.apache.spark.rdd.RDD[Int] 
//for 2D, rows of vector , org.apache.spark.rdd.RDD[Vector[Int]]
  
//Spark manages data using partitions that helps parallelize distributed data processing 
//with minimal network traffic for sending data between executors.

     
//For example 
//Note all Higher order functions are lazy, to force, use some Action at the end 
>>> val rdd = sc.parallelize(0 to 100) //default no of partitions = no of cores //org.apache.spark.rdd.RDD[Int]
>>> rdd.count()
100 
//shows 4/4
//ie 4 Tasks in Total because it is a  4core laptop 
//and by default the number of partitions is the number of all available cores.     
>>> rdd.getNumPartitions
4
        
//Manually modifying 
>>> val ints = sc.parallelize(0 to 100, 2) //two partitions 
>>> ints.getNumPartitions
2
scala> ints.partitions.size
res2: Int = 2

//check patition with values 
//RDD[T].mapPartitionsWithIndex[U](f: (Int, Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U]): RDD[U] 
>>> ints.mapPartitionsWithIndex((index,values)=> Iterator( index->values.toList)).collect()
res7: Array[(Int, List[Int])] = Array((0,List(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24
, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46,
47, 48, 49)), (1,List(50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66,
67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89
, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100)))

 
//smaller/more numerous partitions allow work to be distributed among more workers, 
//but larger/fewer partitions allow work to be done in larger chunks, which may result in the work getting done more quickly as long as all workers are kept busy, due to reduced overhead.
        
//Spark can only run 1 concurrent task for every partition of an RDD, 
//up to the number of cores in your cluster. 
// you generally want at least as many as the number of executors for parallelism. 
//You can get this computed value by calling  sc.defaultParallelism .

>>> sc.defaultParallelism  //no of cores 
4


//Modify the no of partitions to 400 
rdd = sc.textFile("hdfs://file.txt", 400) 

//For compressed file, # of partion is always 1 as .gz etc can not work in parallel
//After reading change the partition via repartition or coalesce

//Both returns new RDD 
def repartition(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T]
//repartition  is coalesce with  numPartitions  and  shuffle  enabled.  , Use coalesce for decreasing partitions as by defauly shuffle is not enabled     
def coalesce(numPartitions: Int, shuffle: Boolean = false)(implicit ord: Ordering[T] = null): RDD[T]

scala> val rdd = sc.parallelize(0 to 10, 8)
rdd: org.apache.spark.rdd.RDD[Int] = ParallelCollectionRDD[0] at parallelize at <console>:24

scala> rdd.partitions.size
res0: Int = 8

scala> rdd.coalesce(numPartitions=8, shuffle=false)  
res1: org.apache.spark.rdd.RDD[Int] = CoalescedRDD[1] at coalesce at <console>:27

scala> res1.toDebugString
res2: String =
(8) CoalescedRDD[1] at coalesce at <console>:27 []
 |  ParallelCollectionRDD[0] at parallelize at <console>:24 []

scala> rdd.coalesce(numPartitions=8, shuffle=true)
res3: org.apache.spark.rdd.RDD[Int] = MapPartitionsRDD[5] at coalesce at <console>:27

//indents are stages and stage boundary needs shuffling 
//(No) is for partitions 
scala> res3.toDebugString
res4: String =
(8) MapPartitionsRDD[5] at coalesce at <console>:27 []
 |  CoalescedRDD[4] at coalesce at <console>:27 []
 |  ShuffledRDD[3] at coalesce at <console>:27 []
 +-(8) MapPartitionsRDD[2] at coalesce at <console>:27 []
    |  ParallelCollectionRDD[0] at parallelize at <console>:24 []
      
      
      
      
      
      
///RDD Lineage
//evaluation of RDD is lazy in nature. 
//It means a series of transformations are performed on an RDD, which is not even evaluated immediately.
//Action makes it evaluated 

//While we create a new RDD from an existing Spark RDD, 
//that new RDD also carries a pointer to the parent RDD in Spark. 
//That is same as all the dependencies between the RDDs those are logged in a graph, 
//rather than the actual data. 
//It is what we call as lineage graph.

//RDD lineage is nothing but the graph of all the parent RDDs of an RDD. 
//We also call it an RDD operator graph or RDD dependency graph. 
//To be very specific, it is an output of applying transformations to the spark. 
//Then, it creates a logical execution plan.
//physical execution plan or execution DAG is known as DAG of stages.

//Check data\rdd-lineage.jpg to see the RDD lineage created because of below operations 

//After an action has been called, this is a graph of what transformations need to be executed.
val r00 = sc.parallelize(0 to 9)
val r01 = sc.parallelize(0 to 90 by 10)

val r10 = r00 cartesian r01
val r11 = r00.map(n => (n, n))
val r12 = r00 zip r01  //for zip to work, no of elements in each partition (same order) of both rdd should match 
val r13 = r01.keyBy(_ / 20)
val r20 = Seq(r11, r12, r13).foldLeft(r10)(_ union _)


///ToDebugString Method to get RDD Lineage Graph in Spark

>>> val wordCount1 = sc.textFile("README.md").flatMap(_.split("\\s+")).map((_, 1)).reduceByKey(_ + _)
wordCount1: org.apache.spark.rdd.RDD[(String, Int)] = ShuffledRDD[21] at reduceByKey at <console>:24

>>> wordCount1.toDebugString
res13: String =
(2) ShuffledRDD[21] at reduceByKey at <console>:24 []
+-(2) MapPartitionsRDD[20] at map at <console>:24 []
|  MapPartitionsRDD[19] at flatMap at <console>:24 []
|  README.md MapPartitionsRDD[18] at textFile at <console>:24 []
|  README.md HadoopRDD[17] at textFile at <console>:24 []

//for indication of shuffle boundary, this method 'toDebugString method' uses indentations.
//N in round brackets refers, numbers that show the level of parallelism at each stage.
//For example, (2) in the above output.
>>> wordCount1.getNumPartitions
res14: Int = 2

//Another Example 
//(id, data)
RDD 1: (1, 1), (2, 1), (3, 1)
RDD 2: (3, 2), (4, 2), (5, 2)
RDD 3: (2, 3), (3, 3), (5, 3)
//
val rdd1 = sc .parallelize( Array( (1, 1), (2, 1), (3, 1) ), 3)
val rdd2 = sc .parallelize( Array( (3, 2), (4, 2), (5, 2) ), 3)
val rdd3 = sc .parallelize( Array( (2, 3), (3, 3), (5, 3) ), 3)

>>> rdd1.glom().collect() //looks OK, each partition gets one 
res0: Array[Array[(Int, Int)]] = Array(Array((1,1)), Array((2,1)), Array((3,1)))
//OR to force it 
rdd1.partitionBy(new HashPartitioner(3))  //partitionBy is for (K,V) and  HashPartitioner is default 

//to get the most recent data in the result for each id 
//result : (1, 1), (2, 3), (3, 3), (4, 2), (5, 3).

def v2[T](r:T, v:T)(implicit ev: scala.math.Ordering[T]) = ev.max(r,v) 
    
//the ideas are:
//RDD[T].union(other: RDD[T)): RDD[T]
val union =  rdd1.union(rdd2).union(rdd3).reduceByKey(v2);

//RDD[(K,V)].fullOuterJoin[W](other: RDD[(K, W))): RDD[(K, (Option[V], Option[W)))]
//Note reduceByKey and foldByKey of RDD[(K,V)] works on initial value type V 
//to change initial value to new Type, use 
//def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C): RDD[(K, C)]
def cc[T](v: Tuple2[Option[T],Option[T]]) (implicit ev: scala.math.Ordering[T]) = {
        v match {
            case (Some(x),Some(y)) => ev.max(x,y)
            case (Some(x), None)  => x
            case (None, Some(x)) => x
        }
    }
def mv[T](r:T, v: Tuple2[Option[T],Option[T]]) (implicit ev: scala.math.Ordering[T]) = ev.max(r, cc[T](v))

val join = rdd1.fullOuterJoin(rdd2).combineByKey(cc[Int] _, mv[Int] _, v2[Int] _).fullOuterJoin(rdd3).combineByKey(cc[Int] _, mv[Int] _, v2[Int] _)

//RDD[(K,V)].cogroup[W](other: RDD[(K, W))): RDD[(K, (Iterable[V], Iterable[W)))]
val cc = (v: ( Iterable[Int], Iterable[Int]) ) => v._1 ++ v._2 max 
val mv = (r:Int , v: ( Iterable[Int], Iterable[Int]) ) => r.max(v._1 ++ v._2 max)
val mc = (r: Int, v:Int) => r.max(v)
val cogroup = rdd1.cogroup(rdd2).combineByKey(cc,mv,mc).cogroup(rdd3).combineByKey(cc,mv,mc); //cogroup allows to group more, than one rdd, but it’s an example.



// toDebugString look like:
union.toDebugString  //note partition is 9 because union partition is sum of all partitions 
res2: String =
(9) ShuffledRDD[7] at reduceByKey at <console>:99 []
 +-(9) UnionRDD[6] at union at <console>:99 []
    |  UnionRDD[5] at union at <console>:99 []
    |  ParallelCollectionRDD[0] at parallelize at <console>:96 []
    |  ParallelCollectionRDD[2] at parallelize at <console>:96 []
    |  ParallelCollectionRDD[3] at parallelize at <console>:96 []

join.toDebugString 
res47: String =
(3) MapPartitionsRDD[56] at combineByKey at <console>:102 []
 |  MapPartitionsRDD[55] at fullOuterJoin at <console>:102 []
 |  MapPartitionsRDD[54] at fullOuterJoin at <console>:102 []
 |  CoGroupedRDD[53] at fullOuterJoin at <console>:102 []
 |  MapPartitionsRDD[52] at combineByKey at <console>:102 []
 |  MapPartitionsRDD[51] at fullOuterJoin at <console>:102 []
 |  MapPartitionsRDD[50] at fullOuterJoin at <console>:102 []
 |  CoGroupedRDD[49] at fullOuterJoin at <console>:102 []
 +-(3) ParallelCollectionRDD[0] at parallelize at <console>:96 []
 +-(3) ParallelCollectionRDD[2] at parallelize at <console>:96 []
 +-(3) ParallelCollectionRDD[3] at parallelize at <console>:96 []

cogroup.toDebugString
res54: String =
(3) MapPartitionsRDD[68] at combineByKey at <console>:102 []
 |  MapPartitionsRDD[67] at cogroup at <console>:102 []
 |  CoGroupedRDD[66] at cogroup at <console>:102 []
 |  MapPartitionsRDD[65] at combineByKey at <console>:102 []
 |  MapPartitionsRDD[64] at cogroup at <console>:102 []
 |  CoGroupedRDD[63] at cogroup at <console>:102 []
 +-(3) ParallelCollectionRDD[0] at parallelize at <console>:96 []
 +-(3) ParallelCollectionRDD[2] at parallelize at <console>:96 []
 +-(3) ParallelCollectionRDD[3] at parallelize at <console>:96 []

      

///Two kinds of partitioning available in Spark:
Hash partitioning, org.apache.spark.HashPartitioner(numPartitions)
    p = k.hashCode() % numPartitions
    in java, k.hashCode 
Range partitioning
    Assumptions: (a) Keys non-negative, (b) 800 is the biggest key in the RDD
    Set of ranges: from (800/4): [1-200), [201-400), [401-600), [601-800] 

    In scala, org.apache.spark.RangePartitioner(numPartitions,rdd)
    May use  sortByKey(ascending=True, numPartitions=None, keyfunc=lambda x: x) ,uses rangePartitioner , hence use this if required 
    keyBy returns tuple, rdd.map(x => (keyfunc(x), x))
    rdd.keyBy(keyfunc).sortByKey(ascending, numPartitions).values()
Custom partitioner      
case class CP(partitions:Int) extends Partitioner{
        def getPartition(key: Any): Int = {
                if(key == 17850 || key == 12583) return 0
                    import scala.util.Random 
                    val r = new Random
                    return r.nextInt(partitions-1)+1  //1... partions-1
                 }
        def numPartitions: Int = partitions
        }       
        
val data = Array(17850, 12583, 12584, 17851)
val r = new scala.util.Random
val rdddata = (0 to 100).toList.map(i => (data(r.nextInt(4)),i,i*2) )
val rdd = sc.parallelize(rdddata)

val keyedRDD = rdd.keyBy( _._1 )
>>> keyedRDD.partitionBy(new CP(3)).map(_._1).glom().collect().foreach(x=>println(x.size))
50
24
27
        
        

//Automatically partitioners:
//Some operations on RDDs automatically result in an RDD with a known partitioner for when it makes sense. 
//E.g. by default, when using sortByKey, a RangePartitioner is used. 
//Further, the default partitioner when using groupByKey, is a HashPartitioner, .
//Operations on Pair RDDs that hold to and propagate a partitioner:
•	cogroup
•	groupWith
•	join
•	leftOuterJoin
•	rightOuterJoin
•	groupByKey
•	reduceByKey
•	foldByKey
•	combineByKey
•	partitionBy
•	sort
•	mapValues (if parent has a partitioner)
•	flatMapValues (if parent has a partitioner)
•	filter (if parent has a partitioner)








///+++ Working with RDDs in Spark

//src/main/examples/wordcount.scala 
package examples

import org.apache.spark._
import org.apache.spark.SparkContext._

object WordCount {
    def main(args: Array[String]) {
      val inputFile = "README"  //HDFS, a local file system (available on all nodes), or any Hadoop-supported file system URI
      
      val conf = new SparkConf().setAppName("wordCount")//.setMaster("local[*]") //when running without spark-submit
      // Create a Scala Spark Context.
      val sc = new SparkContext(conf)
      // Load our input data.
      val input =  sc.textFile(inputFile)  // default partitions, or use textFile(inputFile,100)
      // Split up into words.
      val words = input.flatMap(line => line.split(" ")) //on executors,
      // Transform into word and count.
      val counts = words.map(word => (word, 1))  //on executors 
                //Shuffle boundary , creates map files for reduce phase 
                .reduceByKey{case (v1, v2) => v1 + v2} //same key, func for values 
      
      //print
      counts.collect().foreach(println) //on driver , action, hence now getting executed 
    }
}

//Few Important methods of SparkContext
class org.apache.spark.SparkContext
    def makeRDD[T](seq: Seq[T], numSlices: Int = defaultParallelism)(implicit arg0: ClassTag[T]): RDD[T]
        Distribute a local Scala collection to form an RDD.
        Note Array has implicit conversion to Seq 
        >>> sc.makeRDD(List(0, 2, 3, 4, 6), 5).glom().collect() //glom() returns Array of each partition's value seperately
        Array[Array[Int]] = Array(Array(0), Array(2), Array(3), Array(4), Array(6))
        
    def parallelize[T](seq: Seq[T], numSlices: Int = defaultParallelism)(implicit arg0: ClassTag[T]): RDD[T]
        Distribute a local scala collection to form an RDD. 
        List, range, Buffer are subclass of Seq, but not Set and Map are not, but these have .toSeq method 
        Note Array can be converted to Seq implicitly(scala.collection.mutable.WrappedArray (a subtype of scala.collection.Seq))
        Note T can be anything, even a Tuple . In Spark, Paired RDD is RDD[(K,V)]
        >>> sc.parallelize(List(0, 2, 3, 4, 6), 5).glom().collect() //glom() returns Array of each partition's value seperately
        Array[Array[Int]] = Array(Array(0), Array(2), Array(3), Array(4), Array(6))
        >>> sc.parallelize(0 to 6 by 2, 5).glom().collect()
        res5: Array[Array[Int]] = Array(Array(), Array(0), Array(2), Array(4), Array(6))
        
    def range(start: Long, end: Long, step: Long = 1, numSlices: Int = defaultParallelism): RDD[Long]
        Create a new RDD of int containing elements from start to end (exclusive), 
        >>> sc.range(0,5).collect()
        res7: Array[Long] = Array(0, 1, 2, 3, 4)   
        
    def union[T](rdds: Seq[RDD[T]])(implicit arg0: ClassTag[T]): RDD[T]
        Build the union of a list of RDDs of same type 
        val textFile = sc.parallelize(Array("Hello"))
        val parallelized = sc.parallelize(Array("World!"))
        >>> sc.union(Array(textFile, parallelized)).collect.sorted 
        res5: Array[String] = Array(Hello, World!)        
        
    def hadoopConfiguration: org.apache.hadoop.conf.Configuration 
        A default Hadoop Configuration for the Hadoop code (e.g. file systems) 
        This is for global 
        These configuration is from core-default.xml: Read-only defaults for hadoop.
        and core-site.xml: Site-specific configuration for a given hadoop installation.
        check https://hadoop.apache.org/docs/r2.7.3/api/org/apache/hadoop/conf/Configuration.html
        Use Configuration.dumpConfiguration(sc.hadoopConfiguration, new java.io.PrintWriter(scala.Console.out) )
        to dump all and get(name)/set(name,value) to get/set single config items 
        
    def textFile(path: String, minPartitions: Int = defaultMinPartitions): RDD[String]
        Read a text file linewise       
        Note Path supports running on directories, compressed files, and wildcards as well. 
        >>> val textFile = sc.textFile(path)
        >>> textFile.collect()
        ["Hello world!"]    
        
    def wholeTextFiles(path: String, minPartitions: Int = defaultMinPartitions): RDD[(String, String)]
        read a directory containing multiple text files, and returns each of them as (filename, content) pairs.
        This is in contrast with textFile, which would return one record per line in each file.        
    
    def sequenceFile[K, V](path: String, minPartitions: Int = defaultMinPartitions)(implicit km: ClassTag[K], vm: ClassTag[V], kcf: () => WritableConverter[K], vcf: () => WritableConverter[V]): RDD[(K, V)]
    def sequenceFile[K, V](path: String, keyClass: Class[K], valueClass: Class[V]): RDD[(K, V)]
    def sequenceFile[K, V](path: String, keyClass: Class[K], valueClass: Class[V], minPartitions: Int): RDD[(K, V)]
        Read a Hadoop SequenceFile(=(K,V) pair) with arbitrary key and value Writable class from HDFS, a local file system (available on all nodes), 
        or any Hadoop-supported file system URI
        •path – path to Hadoop file, hdfs://, file:// etc 
        //Create a RDD of K,V and save as sequence file , coalesce repartitions to one, hence creates one file 
        >>> sc.parallelize(List(("foo", """{"foo": 1}"""), ("bar", """{"bar": 2}"""))).coalesce(1).saveAsSequenceFile("example")
        //Read K,V , mention, scala type
        val rdd_k_v = sc.sequenceFile[String,String]("example")   
        >>> rdd_k_v.collect()
        res1: Array[(String, String)] = Array((foo,{"foo": 1}), (bar,{"bar": 2}))
        val rdd_v = rdd_k_v.values
        >>> rdd_v.first
        res2: String = {"foo": 1}           

    def newAPIHadoopFile[K, V, F <: InputFormat[K, V]](path: String, fClass: Class[F], kClass: Class[K], vClass: Class[V], conf: Configuration = hadoopConfiguration): RDD[(K, V)]
    def newAPIHadoopFile[K, V, F <: InputFormat[K, V]](path: String)(implicit km: ClassTag[K], vm: ClassTag[V], fm: ClassTag[F]): RDD[(K, V)]
        Based on org.apache.hadoop.mapreduce.InputFormat (new MapReduce API)
        Create a new org.apache.hadoop.conf.Configuration object to be used with this API 
        new Configuration(true).set(String name, String value)
        //Example with new deliminator , K=Line number, V= text line 
        import org.apache.hadoop.io.LongWritable
        import org.apache.hadoop.io.Text
        import org.apache.hadoop.conf.Configuration
        import org.apache.hadoop.mapreduce.lib.input.TextInputFormat
        val conf = new Configuration
        conf.set("textinputformat.record.delimiter", "##")
        val data = sc.newAPIHadoopFile("mydata.txt", classOf[TextInputFormat], classOf[LongWritable], classOf[Text], conf).map(_._2.toString)
        data: org.apache.spark.rdd.RDD[(org.apache.hadoop.io.LongWritable, org.apache.hadoop.io.Text)] = NewHadoopRDD[0] at newAPIHadoopFile at <console>:19

        
    def newAPIHadoopRDD[K, V, F <: InputFormat[K, V]](conf: Configuration = hadoopConfiguration, fClass: Class[F], kClass: Class[K], vClass: Class[V]): RDD[(K, V)]
        Create a new org.apache.hadoop.conf.Configuration object to be used with this API 
        Note configuration contains connection detail. This is used for HBase reading 
        
    def objectFile[T](path: String, minPartitions: Int = defaultMinPartitions)(implicit arg0: ClassTag[T]): RDD[T]
        Load an RDD saved as a SequenceFile containing serialized objects, 
        with NullWritable keys and BytesWritable values that contain a serialized partition.

    def binaryFiles(path: String, minPartitions: Int = defaultMinPartitions): RDD[(String, PortableDataStream)]
        Get an RDD for a Hadoop-readable dataset as PortableDataStream 
        for each file (useful for binary data)
        
    def binaryRecords(path: String, recordLength: Int, conf: Configuration = hadoopConfiguration): RDD[Array[Byte]]
        Load data from a flat binary file, assuming the length of each record is constant.
        Create a new org.apache.hadoop.conf.Configuration object to be used with this API             
            
            
            
///+++ RDD - Transformations(lazy, does not get executed without Action, closure in executor )
//T could be even (K,V)
RDD[T]
    map(func)  
    filter(func)  
    flatMap(func)  

    mapPartitions(func)   
    mapPartitionsWithIndex(func)  

    sample(withReplacement, fraction, seed)
    distinct([numPartitions]))  
    pipe(command, [envVars]) 

    union(otherDataset)  
    intersection(otherDataset) 
    cartesian(otherDataset)
    groupBy(f)    
    keyBy(f)   //converts to (f(e),e)
    
    coalesce(numPartitions)   
    repartition(numPartitions)  
    repartitionAndSortWithinPartitions(partitioner)  
RDD[(K,V)]
    groupByKey([numPartitions])   
    reduceByKey(func, [numPartitions])   
    aggregateByKey(zeroValue)(seqOp, combOp, [numPartitions])   
    sortByKey([ascending], [numPartitions])  
    cogroup(otherDataset, [numPartitions])      //other: RDD[(K, W)] returns  RDD[(K, (Iterable[V], Iterable[W]))]
    groupWith(other, *others) //Type: other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)])
                              //Returns RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3]))]
    join(otherDataset, [numPartitions])         //other: RDD[(K, W)] Returns  RDD[(K, (V, W))]
    fullOuterJoin(other, numPartitions=None)    //other:RDD[(K, W)], Returns RDD[(K, (Option[V], Option[W]))] , Option means Some(value) or None 
    leftOuterJoin(other, numPartitions=None)    //other:RDD[(K, W)], Returns RDD[(K, (V, Option[W]))]
    rightOuterJoin(other, numPartitions=None)   //other:RDD[(K, W)], Returns RDD[(K, (Option[V], W))]

    
///RDD - Actions(eager - executes whole pipeline before it , closure in executor , final value processing in driver) 
//T could be even (K,V)
RDD[(K,V)]
    countByKey()
RDD[T]
    reduce(func) 
    count()  
    foreach(func)  
    
    collect()  
    first()    
    take(n)  
    takeSample(withReplacement, num, [seed])  
    takeOrdered(n, [ordering])  

    saveAsTextFile(path)  
    saveAsSequenceFile(path) 
    saveAsObjectFile(path) 





///+++RDD- Understanding Execution 
//what would be value of counter ?
var counter = 0
val rdd = sc.parallelize(Array(1,2,3))


def increment_counter(x:Int){
    counter += x
}

rdd.foreach(increment_counter)

println(s"Counter value: $counter")


//Function gets executed in executor only 
//Any closure along with captured variables are serialized by driver and sent to executors
//Executors execuate that function for it's own partitions .
//If it requires other partition data, then spark does a shuffle 

//The variables within the closure sent to each executor are now copies 
//and thus, when counter is referenced within the foreach function(ie in executor), it’s no longer the counter on the driver node

//hence final counter is zero(but would be ok for local mode)
//SOLUTION: Use Accumulator in this case 



///+++Spark - RDD - Printing elements of an RDD

//in local mode, OK 
//in cluster mode - stdout is executer/another machines stdout, hence check SPARK_WORKER_DIR or sparkUI/ResourceManagerUI
rdd.foreach(println) 
rdd.map(println) //Wrong as map is transformation, hence lazy , no execution 

//Best solution -  use the collect() method to first bring the RDD to the driver node thus: 
rdd.collect().foreach(println) 

//This can cause the driver to run out of memory- hence safer is to use take 
rdd.take(100) //==> returns Array 







///+++Spark - RDD - Passing Functions in the driver program to run on the cluster. 
//IMP*** functions along with captured variables must be serialized - else ERROR 
//Note if captured variables are not serializable(eg contains complicated state eg socket/DB/file connection). IT WOULD FAIL 


//Followings are performant
//Anonymous function syntax, which can be used for short pieces of code.
//Static methods in a global singleton object. 
//For example, you can define object MyFunctions and then pass MyFunctions.func1

object MyFunctions {
  def func1(s: String): String = { ... }
}

myRdd.map(MyFunctions.func1)

//For class methods, check captured variable  
//Note: For below type of cases, 
//whole object/class needs to be sent to cluster which might  not be performant 
class MyClass extends Serializable {
  def func1(s: String): String = { ... }
  def doStuff(rdd: RDD[String]): RDD[String] = { rdd.map(func1) }
}
//OR 
class MyClass extends Serializable  {
  val field = "Hello"
  def doStuff(rdd: RDD[String]): RDD[String] = { rdd.map(x => field + x) }
}

//One Solution - copy field into a local variable 
def doStuff(rdd: RDD[String]): RDD[String] = {
  val field_ = this.field
  rdd.map(x => field_ + x)
}
    
//Using kyro serialization(note by default DF uses advanced serialization, called Encoders, hence no need to use kyro)
//hence kyro is required only if using spark RDD features 
//Since Spark 2.0.0,Spark use Kryo serializer(bydefault) when shuffling RDDs with simple types, arrays of simple types, or string type
conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
//For custom class registration, use scala 
//if "buffer limit exceeded" exception inside Kryo. 
conf.set("spark.kryoserializer.buffer.max", "64m")  //<2048m 
//Then use StorageLevel.MEMORY_ONLY in persist() (in scala MEMORY_ONLY_SER)


    
//Example - Bad code 
val connection = createNewConnection()  // executed at the driver
rdd.foreach { record =>         ////connection is getting serialized and sent to executor 
connection.send(record) // executed at the worker
}



//One solution is to open connection in executor 
//But for each element, connection would be opened - not performant
rdd.foreach { record =>
    val connection = createNewConnection()
    connection.send(record)
    connection.close()
  }


//Better solution can be Partitionwise 
rdd.foreachPartition { partitionOfRecords =>
    val connection = createNewConnection()
    partitionOfRecords.foreach(record => connection.send(record))
    connection.close()
  }

               
            
///RDD Operations Examples     
//Note there is no Map[K,V], for K,V pair, it is RDD[(K,V)] , called pairedRDD[K,V] 

//RDD[T] is converted to belwo via implicits operations 
rdd:RDD[Double]  --> DoubleRDDFunctions
rdd: RDD[T](implicit num: Numeric[T] -->  DoubleRDDFunctions
rdd: RDD[(K, V)])(implicit arg0: Ordering[K]) -->  OrderedRDDFunctions[K, V, (K, V)]
rdd: RDD[(K, V)] --> PairRDDFunctions[K, V]
rdd: RDD[(K, V)] --> SequenceFileRDDFunctions[K, V] 
     
//Examples  
org.apache.spark.rdd.CoGroupedRDD[K] extends RDD[(K, Array[Iterable[_]])]
    Returns of cogroup
    All RDD operations are possible, now Type is (K, Array[Iterable[_]])   
    
org.apache.spark.rdd.OrderedRDDFunctions[K, V, P <: Product2[K, V]] extends Logging with Serializable
	Extra functions available on RDDs of (key, value) pairs where the K is sortable through an implicit conversion.
    filterByRange(lower: K, upper: K): RDD[P]//inclusive range lower to upper.
    repartitionAndSortWithinPartitions(partitioner: Partitioner): RDD[(K, V)]
       val rdd = sc.parallelize(Array((0, 5), (3, 8), (2, 6), (0, 8), (3, 8), (1, 3)))
        //repartition with whether key 
        case class CustomPartitioner(partitions:Int) extends Partitioner{
            def getPartition(key: Any): Int = {
                        key.asInstanceOf[Int] % partitions 
                     }
            def numPartitions: Int = partitions
            }
        val rdd2 = rdd.repartitionAndSortWithinPartitions(CustomPartitioner(2))//org.apache.spark.rdd.RDD[(Int, Int)]
        >>> rdd2.glom().collect()
       res47: Array[Array[(Int, Int)]] = Array(Array((0,5), (0,8), (2,6)), Array((1,3), (3,8), (3,8)))

    sortByKey(ascending: Boolean = true, numPartitions: Int = self.partitions.length): RDD[(K, V)]
        val tmp = Array(('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5))
        >>> sc.parallelize(tmp).sortByKey().first
        ('1', 3)
        >>> sc.parallelize(tmp).sortByKey(true, 1).collect()
        [('1', 3), ('2', 5), ('a', 1), ('b', 2), ('d', 4)]
        
     
        
org.apache.spark.rdd.DoubleRDDFunctions extends Logging with Serializable
    Extra functions available on RDDs of Doubles through an implicit conversion.
    histogram(buckets_or_bucketCount), mean(),popStdev(), popVariance() etc 
    stats() Returns StatCounter which has count,max,mean,min,popStdev,popVariance,stdev,sum,variance: Double
         >>> sc.parallelize(Array(1, 2, 3)).mean()
            2.0  
        
org.apache.spark.rdd.SequenceFileRDDFunctions[K, V] extends Logging with Serializable
    saveAsSequenceFile(path: String, codec: Option[Class[_ <: CompressionCodec]] = None): Unit
      
     
org.apache.spark.rdd.PairRDDFunctions[K, V] extends Logging with Serializable
	Extra functions available on RDDs of (key, value) pairs through an implicit conversion.
    def collectAsMap(): Map[K, V]
        For RDD of (K,V)
        Return the key-value pairs in this RDD to the driver as a dictionary.
        val  m = sc.parallelize(Array((1, 2), (3, 4))).collectAsMap()
        >>> m(1)
        2
        >>> m(3)
        4
    def keys: RDD[K]
        Return an RDD with the keys of each tuple.
        val m = sc.parallelize(Array((1, 2), (3, 4))).keys
        >>> m.collect()
        [1, 3]
    def values: RDD[V]
        Return an RDD with the values of each tuple.
        val m = sc.parallelize(Array((1, 2), (3, 4))).values
        >>> m.collect()
        [2, 4]

    def lookup(key: K): Seq[V]
        Return the list of values in the RDD for key key.
        val l = (0 to 1000).toList
        val rdd = sc.parallelize(l.zip(l), 10)
        >>> rdd.lookup(42)  // slow
        res52: Seq[Int] = WrappedArray(42)
        val sorted = rdd.sortByKey().cache 
        >>> sorted.lookup(42)  // fast
        res52: Seq[Int] = WrappedArray(42)
        >>> sorted.lookup(1024)
        res54: Seq[Int] = ArrayBuffer()
        val rdd2 = sc.parallelize(Array((('a', 'b'), 'c'))).groupByKey()
        >>> rdd2.lookup(('a', 'b'))(0)
        res56: Iterable[Char] = CompactBuffer(c)

    def mapValues[U](f: (V) => U): RDD[(K, U)]
        Pass each value in the key-value pair RDD through a map function without changing the keys; this also retains the original RDDs partitioning.
        val x = sc.parallelize(Array(("a", Array("apple", "banana", "lemon")), ("b", Array("grapes"))))
        >>> def f(x:Array[_])= x.size
        >>> x.mapValues(f).collect()
        res58: Array[(String, Int)] = Array((a,3), (b,1))
        
    def flatMapValues[U](f: (V) => TraversableOnce[U)): RDD[(K, U)]
        Pass each value in the key-value pair RDD through a flatMap function without changing the keys; this also retains the original RDDs partitioning.
        val x = sc.parallelize(Array(("a", Seq("x", "y", "z")), ("b", Seq("p", "r"))))
        >>> def f[T](x:T) = x
        >>> x.flatMapValues(f).collect()
        res60: Array[(String, String)] = Array((a,x), (a,y), (a,z), (b,p), (b,r))

    def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def cogroup[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def cogroup[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def cogroup[W](other: RDD[(K, W))): RDD[(K, (Iterable[V], Iterable[W)))]
    def cogroup[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Iterable[V], Iterable[W)))]
    def cogroup[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Iterable[V], Iterable[W)))]
        For each key k in this or other1 or other2 or other3, 
        return a resulting RDD that contains a tuple with the list of values 
        for that key in this, other1, other2 and other3.
        Note Result is a PairedRDD 
        We can use Result of this to instantiate , CoGroupedRDD[K] extends RDD[(K, Array[Iterable[_]))]
        for many other methods 
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2), ("a",3)))
        val rdd = x.cogroup(y).cache //org.apache.spark.rdd.RDD[(String, (Iterable[Int], Iterable[Int]))]
        >>> x.cogroup(y).collect()
        res51: Array[(String, (Iterable[Int], Iterable[Int]))] = Array((a,(CompactBuffer(1),CompactBuffer(2, 3))), (b,(CompactBuffer(4),CompactBuffer())))
        val rdd2 = new  CoGroupedRDD(Seq(rdd), Partitioner.defaultPartitioner(rdd)) //org.apache.spark.rdd.CoGroupedRDD[String]
        >>> rdd2.groupByKey().collect()
        
    def groupWith[W1, W2, W3](other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3)))]
    def groupWith[W1, W2](other1: RDD[(K, W1)], other2: RDD[(K, W2))): RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2)))]
    def groupWith[W](other: RDD[(K, W))): RDD[(K, (Iterable[V], Iterable[W)))]
        Alias for cogroup.
        val w = sc.parallelize(Array(("a", 5), ("b", 6)))
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2)))
        val z = sc.parallelize(Array(("b", 42)))
        >>> w.groupWith(x, y, z).collect() 
         Array[(String, (Iterable[Int], Iterable[Int], Iterable[Int], Iterable[Int]))] = 

        
    def subtractByKey[W](other: RDD[(K, W)], p: Partitioner)(implicit arg0: ClassTag[W)): RDD[(K, V)]
    def subtractByKey[W](other: RDD[(K, W)], numPartitions: Int)(implicit arg0: ClassTag[W)): RDD[(K, V)]
    def subtractByKey[W](other: RDD[(K, W)))(implicit arg0: ClassTag[W)): RDD[(K, V)]
        Return an RDD with the pairs from this whose keys are not in other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4), ("b", 5), ("a", 2)))
        val y = sc.parallelize(Array(("a", 3), ("c", null )))
        >>> x.subtractByKey(y).collect()
        res65: Array[(String, Int)] = Array((b,4), (b,5))

    def groupByKey(): RDD[(K, Iterable[V))]
    def groupByKey(numPartitions: Int): RDD[(K, Iterable[V))]
    def groupByKey(partitioner: Partitioner): RDD[(K, Iterable[V))]
        Group the values for each key in the RDD into a single sequence.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.groupByKey().mapValues(_.size).collect()
        res66: Array[(String, Int)] = Array((a,2), (b,1))
        >>> rdd.groupByKey().mapValues(_.toList).collect()
        Array[(String, List[Int])] = Array((a,List(1, 1)), (b,List(1)))
    
    def partitionBy(partitioner: Partitioner): RDD[(K, V)]
        Return a copy of the RDD partitioned using the specified partitioner.
        val pairs = sc.parallelize(Array(1, 2, 3, 4, 2, 4, 1)).map(x => (x, x))
        >>> pairs.partitionBy(new HashPartitioner(2)).glom().collect()
        res68: Array[Array[(Int, Int)]] = Array(Array((2,2), (4,4), (2,2), (4,4)), Array((1,1), (3,3), (1,1)))

    def aggregateByKey[U](zeroValue: U)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): RDD[(K, U)]
    def aggregateByKey[U](zeroValue: U, numPartitions: Int)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): RDD[(K, U)]
    def aggregateByKey[U](zeroValue: U, partitioner: Partitioner)(seqOp: (U, V) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): RDD[(K, U)]
        Aggregate the values of each key, using given combine functions and a neutral "zero value".
            //sum by Key 
            >>> sc.parallelize(Array((0,1), (0,2), (1,3), (1,4))).aggregateByKey(0)((u,v)=> u+v, (u1,u2)=> u1+u2).collect()
            res69: Array[(Int, Int)] = Array((0,3), (1,7))
            //Average by key 
            //ZeroValue=(0,0), first index =sum, 2ndindex=count 
               
            >>> sc.parallelize(Array((0,1), (0,2), (1,3), (1,4))).aggregateByKey((0,0))((u,v)=>(u._1+v, u._2+1), (u1,u2) => (u1._1+u2._1,u1._2+u2._2)).mapValues( t => t._1/t._2.toDouble).collect()
            res1: Array[(Int, Double)] = Array((0,1.5), (1,3.5))        

    def foldByKey(zeroValue: V)(func: (V, V) => V): RDD[(K, V)]
    def foldByKey(zeroValue: V, numPartitions: Int)(func: (V, V) => V): RDD[(K, V)]
    def foldByKey(zeroValue: V, partitioner: Partitioner)(func: (V, V) => V): RDD[(K, V)]
        Merge the values for each key using an associative function and a neutral "zero value" which may be added to the result an arbitrary number of times, and must not change the result (e.g., Nil for list concatenation, 0 for addition, or 1 for multiplication.).
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> from operator import add
        >>> rdd.foldByKey(0)(_+_).collect()
        res2: Array[(String, Int)] = Array((a,2), (b,1))
    
    def reduceByKey(func: (V, V) => V): RDD[(K, V)]
    def reduceByKey(func: (V, V) => V, numPartitions: Int): RDD[(K, V)]
    def reduceByKey(partitioner: Partitioner, func: (V, V) => V): RDD[(K, V)]
        Merge the values for each key using an associative and commutative reduce function.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.reduceByKey(_+_).collect()
        res3: Array[(String, Int)] = Array((a,2), (b,1))

    def reduceByKeyLocally(func: (V, V) => V): Map[K, V]
        Merge the values for each key using an associative and commutative reduce function, but return the results immediately to the master as a Map.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.reduceByKeyLocally(_+_).toList 
        res4: List[(String, Int)] = List((a,2), (b,1))

    def countByKey(): Map[K, Long]
        Count the number of elements for each key, collecting the results to a local Map.
        val rdd = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        >>> rdd.countByKey().toList
        [('a', 2), ('b', 1)]
    
    def fullOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Option[V], Option[W)))]
    def fullOuterJoin[W](other: RDD[(K, W))): RDD[(K, (Option[V], Option[W)))]
    def fullOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Option[V], Option[W)))]
        Perform a full outer join of this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2), ("c", 8)))
        >>> x.fullOuterJoin(y).collect()
        res5: Array[(String, (Option[Int], Option[Int]))] = Array((a,(Some(1),Some(2))), (b,(Some(4),None)), (c,(None,Some(8))))
        
    def join[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (V, W))]
    def join[W](other: RDD[(K, W))): RDD[(K, (V, W))]
    def join[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (V, W))]
        Return an RDD containing all pairs of elements with matching keys in this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2), ("a", 3)))
        >>> x.join(y).collect()
        res6: Array[(String, (Int, Int))] = Array((a,(1,2)), (a,(1,3)))   

    
    def leftOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (V, Option[W)))]
    def leftOuterJoin[W](other: RDD[(K, W))): RDD[(K, (V, Option[W)))]
    def leftOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (V, Option[W)))]
        Perform a left outer join of this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2)))
        >>> x.leftOuterJoin(y).collect()
        res7: Array[(String, (Int, Option[Int]))] = Array((a,(1,Some(2))), (b,(4,None)))

    def rightOuterJoin[W](other: RDD[(K, W)], numPartitions: Int): RDD[(K, (Option[V], W))]
    def rightOuterJoin[W](other: RDD[(K, W))): RDD[(K, (Option[V], W))]
    def rightOuterJoin[W](other: RDD[(K, W)], partitioner: Partitioner): RDD[(K, (Option[V], W))]
        Perform a right outer join of this and other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4)))
        val y = sc.parallelize(Array(("a", 2)))
        >>> y.rightOuterJoin(x).collect()
        res8: Array[(String, (Option[Int], Int))] = Array((a,(Some(2),1)), (b,(None,4)))

    def sampleByKey(withReplacement: Boolean, fractions: Map[K, Double], seed: Long = Utils.random.nextLong): RDD[(K, V)]
    def sampleByKeyExact(withReplacement: Boolean, fractions: Map[K, Double], seed: Long = Utils.random.nextLong): RDD[(K, V)]
        Return a subset of this RDD sampled by key (via stratified sampling) containing exactly math.ceil(numItems * samplingRate) for each stratum (group of pairs with the same key).
        val fractions = Map("a"-> 0.2, "b"-> 0.1) //for key a, 20%, for key b, 10% 
        val rdd = sc.parallelize(fractions.keys.toSeq).cartesian(sc.parallelize(0 to 1000)) //org.apache.spark.rdd.RDD[(String, Int)]
        val sample = rdd.sampleByKey(false, fractions, 2).groupByKey().collect().toMap
        
    def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C): RDD[(K, C)]
    def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, numPartitions: Int): RDD[(K, C)]
    def combineByKey[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, partitioner: Partitioner, mapSideCombine: Boolean = true, serializer: Serializer = null): RDD[(K, C)]
        It does not provide combiner classtag information to the shuffle     
    def combineByKeyWithClassTag[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C)(implicit ct: ClassTag[C]): RDD[(K, C)]
    def combineByKeyWithClassTag[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, numPartitions: Int)(implicit ct: ClassTag[C]): RDD[(K, C)]
    def combineByKeyWithClassTag[C](createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C, partitioner: Partitioner, mapSideCombine: Boolean = true, serializer: Serializer = null)(implicit ct: ClassTag[C]): RDD[(K, C)]
        For RDD of (K,V), 
        //createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C
        Turns an RDD[(K, V)] into a result of type RDD[(K, C)], for a 'combined type' C.
        For same Key, K, 
            •createCombiner, which converts first V into a C 
            •mergeValue, to merge a V(from remaining Vs) into a C 
            •mergeCombiners, to combine two C into a single one.
        >>> val x = sc.parallelize(Array(("a", 1), ("b", 1), ("a", 1)))
        def cc(x:Int) = x.toString
        def mv(c:String, v:Int) = c + v.toString
        def mc(c1:String, c2:String) = c1+c2
        x.combineByKeyWithClassTag[String](cc _,mv _ ,mc _).collect.sorted 
        //[('a', '11'), ('b', '1')]
        x.combineByKey(cc _,mv _ ,mc _).collect.sorted 

    
org.apache.spark.rdd.RDD[T] extends Serializable with Logging   
    def collect[U](f: PartialFunction[T, U])(implicit arg0: ClassTag[U)): RDD[U]
        Return an RDD that contains all matching values by applying f.
    def collect(): Array[T]
        
    def ++(other: RDD[T)): RDD[T]  //union 
    def union(other: RDD[T)): RDD[T]
        Return the union of this RDD and another one.
        val rdd = sc.parallelize(Array(1, 1, 2, 3))
        >>> rdd.union(rdd).collect()
        [1, 1, 2, 3, 1, 1, 2, 3]
        
    def cartesian[U](other: RDD[U))(implicit arg0: ClassTag[U)): RDD[(T, U)]
        Return the Cartesian product of this RDD and another one, 
        that is, the RDD of all pairs of elements (a, b) where a is in this and b is in other.
        val rdd = sc.parallelize(Array(1, 2))
        >>> rdd.cartesian(rdd).collect()
        [(1, 1), (1, 2), (2, 1), (2, 2)]
        >>> rdd.cartesian(rdd).collect{case (x,y) if x % 2 == 0 => y }.collect()
        res14: Array[Int] = Array(1, 2)
        
    def count(): Long
        Return the number of elements in the RDD.
        >>> sc.parallelize(Array(2, 3, 4)).count()
        3
        
    def countByValue()(implicit ord: Ordering[T] = null): Map[T, Long]
        Return the count of each unique value in this RDD as a local map of (value, count) pairs.
        >>> sc.parallelize(Array(1, 2, 1, 2, 2), 2).countByValue().toList 
        [(1, 2), (2, 3)]
        
    def distinct(numPartitions: Int)(implicit ord: Ordering[T] = null): RDD[T]
    def distinct(): RDD[T]
        Return a new RDD containing the distinct elements in this RDD.
        >>> sc.parallelize(Array(1, 1, 2, 3)).distinct().collect()
        [1, 2, 3]

    def filter(f: (T) => Boolean): RDD[T]
        Return a new RDD containing only the elements that satisfy a predicate.
        val rdd = sc.parallelize(Array(1, 2, 3, 4, 5))
        >>> rdd.filter(_ % 2 == 0).collect()
        [2, 4]
    
    def first(): T
        Return the first element in this RDD.
        >>> sc.parallelize(Array(2, 3, 4)).first()
        2
        
    def flatMap[U](f: (T) => TraversableOnce[U))(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by first applying a function to all elements of this RDD, 
        and then flattening the results.
        val rdd = sc.parallelize(Array(2, 3, 4))
        >>> rdd.flatMap(x => 1 to x )).collect()
        [1, 1, 1, 2, 2, 3]
        >>> rdd.flatMap(x => Array((x, x), (x, x))).collect()
        res15: Array[(Int, Int)] = Array((2,2), (2,2), (3,3), (3,3), (4,4), (4,4))

    def aggregate[U](zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U)(implicit arg0: ClassTag[U)): U
        Aggregate the elements of each partition, 
        and then the results for all the partitions, using given combine functions 
        and a neutral "zero value"
        Like foldLeft(zeroValue)(seqOp) on each Partition
        then results collected from each partition are aggregated using combOp
             >>> sc.parallelize(Array(1, 2, 3, 4)).aggregate((0, 0))((u,v)=>(u._1+v, u._2+1), (u1,u2) => (u1._1+u2._1,u1._2+u2._2))
            (10, 4)
    
    def fold(zeroValue: T)(op: (T, T) => T): T
        Aggregate the elements of each partition, and then the results for all the partitions, 
        using a given associative function and a neutral "zero value".
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).fold(0)(_+_)
        15
    
    def reduce(f: (T, T) => T): T
        Reduces the elements of this RDD using the specified commutative 
        and associative binary operator.
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).reduce(_+_)
        15
    
    def treeAggregate[U](zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U, depth: Int = 2)(implicit arg0: ClassTag[U)): U
        Aggregates the elements of this RDD in a multi-level tree pattern.
        depth – suggested depth of the tree (default: 2) 
        val rdd = sc.parallelize(Array(-5, -4, -3, -2, -1, 1, 2, 3, 4), 10)
        >>> rdd.treeAggregate(0)(_+_ , _+_ ,2)        -5
    
    def treeReduce(f: (T, T) => T, depth: Int = 2): T
        Reduces the elements of this RDD in a multi-level tree pattern.
        val rdd = sc.parallelize(Array(-5, -4, -3, -2, -1, 1, 2, 3, 4], 10)
        >>> rdd.treeReduce(_+_, 2)        -5

    def foreach(f: (T) => Unit): Unit
        Applies a function f to all elements of this RDD.
        >>> def f[T](x:T) = println(x)
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).foreach(f) 
    
    def foreachPartition(f: (Iterator[T]) => Unit): Unit
        Applies a function f to each partition of this RDD.
        >>> def f[T](iterator:Iterator[T])=   for (x <- iterator) println(x)
        >>> sc.parallelize(Array(1, 2, 3, 4, 5)).foreachPartition(f)    

    def glom(): RDD[Array[T]]
        Return an RDD created by coalescing all elements within each partition into an array.
        val rdd = sc.parallelize(Array(1, 2, 3, 4), 2)
        >>> rdd.glom().collect()
        res15: Array[Array[Int]] = Array(Array(1, 2), Array(3, 4))
        
    def groupBy[K](f: (T) => K, p: Partitioner)(implicit kt: ClassTag[K], ord: Ordering[K] = null): RDD[(K, Iterable[T))]
    def groupBy[K](f: (T) => K, numPartitions: Int)(implicit kt: ClassTag[K)): RDD[(K, Iterable[T))]
    def groupBy[K](f: (T) => K)(implicit kt: ClassTag[K)): RDD[(K, Iterable[T))]
        Return an RDD of grouped items.   Note result is Paired RDD, so implicits PairedRDD functions are applicable 
        val rdd = sc.parallelize(Array(1, 1, 2, 3, 5, 8))
        val result = rdd.groupBy( _ % 2).collect() // Array[(Int, Iterable[Int])]
        >>> result.map{case (i,j) => (i, j.toList)}

    def intersection(other: RDD[T], numPartitions: Int): RDD[T]
    def intersection(other: RDD[T], partitioner: Partitioner)(implicit ord: Ordering[T] = null): RDD[T]
    def intersection(other: RDD[T)): RDD[T]
        Return the intersection of this RDD and another one.
        val rdd1 = sc.parallelize(Array(1, 10, 2, 3, 4, 5))
        val rdd2 = sc.parallelize(Array(1, 6, 2, 3, 7, 8))
        >>> rdd1.intersection(rdd2).collect()
        [1, 2, 3]
    
    def isCheckpointed: Boolean
        Return whether this RDD is checkpointed and materialized, either reliably or locally.
        
    def isEmpty(): Boolean
        >>> sc.parallelize(Array()).isEmpty()
        true
        >>> sc.parallelize(Array(1)).isEmpty()
        false
        
    def keyBy[K](f: (T) => K): RDD[(K, T)]
        Creates tuples of the elements in this RDD by applying f.
        Note result is Paired RDD, so implicits PairedRDD functions are applicable 
        val x = sc.parallelize(range(0,3)).keyBy(x => x*x)
        >>> x.collect()
        [(0, 0), (1, 1), (4, 2)]

    def map[U](f: (T) => U)(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by applying a function to all elements of this RDD.
        val rdd = sc.parallelize(Array("b", "a", "c"))
        >>> rdd.map(x => (x, 1)).collect().sorted
        [('a', 1), ('b', 1), ('c', 1)]

    def mapPartitions[U](f: (Iterator[T]) => Iterator[U], preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by applying a function to each partition of this RDD.
        val rdd = sc.parallelize(Array(1, 2, 3, 4), 2)
        >>> def f(iterator:Iterator[Int]) = iterator.map(x=>x*x)
        >>> rdd.mapPartitions(f).glom().collect
        res26: Array[Array[Int]] = Array(Array(1, 4), Array(9, 16))
    
    def mapPartitionsWithIndex[U](f: (Int, Iterator[T]) => Iterator[U), preservesPartitioning: Boolean = false)(implicit arg0: ClassTag[U)): RDD[U]
        Return a new RDD by applying a function to each partition of this RDD, while tracking the index of the original partition.
        val rdd = sc.parallelize(Array(1, 2, 3, 4), 4)
        >>> def f(index:Int,iterator:Iterator[Int]) = iterator.map(x=>x*index)
        >>> rdd.mapPartitionsWithIndex(f).sum()
        7.0

    def max()(implicit ord: Ordering[T]): T
    def min()(implicit ord: Ordering[T]): T
        Returns the max of this RDD as defined by the implicit Ordering[T].
        val rdd = sc.parallelize(Array(1.0, 5.0, 43.0, 10.0))
        >>> rdd.max()
        43.0            
  
    def randomSplit(weights: Array[Double), seed: Long = Utils.random.nextLong): Array[RDD[T]]
        Randomly splits this RDD with the provided weights.
        val rdd = sc.parallelize(0 to 500, 1)
        >>> val rdds = rdd.randomSplit(Array(2, 3), 17)
        >>> rdds(0).collect().size + rdds(1).collect().size
        501  

    def sample(withReplacement: Boolean, fraction: Double, seed: Long = Utils.random.nextLong): RDD[T]
        Return a sampled subset of this RDD.
        val rdd = sc.parallelize(0 to 100, 4)
        >>> 6 <= rdd.sample(false, 0.1, 81).count() &&  rdd.sample(false, 0.1, 81).count() <= 14
        true

    def saveAsObjectFile(path: String): Unit
    def saveAsTextFile(path: String, codec: Class[_ <: CompressionCodec)): Unit
    def saveAsTextFile(path: String): Unit

    def sortBy[K](f: (T) => K, ascending: Boolean = true, numPartitions: Int = this.partitions.length)(implicit ord: Ordering[K), ctag: ClassTag[K)): RDD[T]
        Return this RDD sorted by the given key function.
        val tmp = Array(('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5))
        >>> sc.parallelize(tmp).sortBy(_._1).collect()
        res32: Array[(Char, Int)] = Array((1,3), (2,5), (a,1), (b,2), (d,4))
    
    def subtract(other: RDD[T), p: Partitioner)(implicit ord: Ordering[T] = null): RDD[T]
    def subtract(other: RDD[T), numPartitions: Int): RDD[T]
    def subtract(other: RDD[T]): RDD[T]
        Return an RDD with the elements from this that are not in other.
        val x = sc.parallelize(Array(("a", 1), ("b", 4), ("b", 5), ("a", 3)))
        val y = sc.parallelize(Array(("a", 3), ("c", 2)))
        >>> x.subtract(y).collect().sorted
        res34: Array[(String, Int)] = Array((a,1), (b,4), (b,5))

    def take(num: Int): Array[T]
        Take the first num elements of the RDD.
         >>> sc.parallelize(Array(2, 3, 4, 5, 6)).cache().take(2)
        [2, 3]
        
    def takeOrdered(num: Int)(implicit ord: Ordering[T]): Array[T]
        Returns the first k (smallest) elements from this RDD as defined by the specified implicit Ordering[T] and maintains the ordering.
        >>> sc.parallelize(Array(10, 1, 2, 9, 3, 4, 5, 6, 7)).takeOrdered(6)
        [1, 2, 3, 4, 5, 6]

    def takeSample(withReplacement: Boolean, num: Int, seed: Long = Utils.random.nextLong): Array[T]
        Return a fixed-size sampled subset of this RDD in an array
        val rdd = sc.parallelize(0 to 10)
        >>>rdd.takeSample(true, 20, 1).size
        20
   
    def toDebugString: String
        A description of this RDD and its recursive dependencies for debugging.
        
    def toLocalIterator: Iterator[T]
        Return an iterator that contains all of the elements in this RDD.
        val rdd = sc.parallelize(0 to 10)
        >>> rdd.toLocalIterator().toList 
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def top(num: Int)(implicit ord: Ordering[T]): Array[T]
        Returns the top k (largest) elements from this RDD as defined by the specified implicit Ordering[T] and maintains the ordering.
        >>> sc.parallelize(Array(10, 4, 2, 12, 3)).top(1)
        [12]        
    
    def zip[U](other: RDD[U))(implicit arg0: ClassTag[U)): RDD[(T, U)]
        Zips this RDD with another one, returning key-value pairs with the first element in each RDD, 
        second element in each RDD, etc.Note this and other must have same partitions and same number of elements in each parition 
        Note result is Paired RDD, so implicits PairedRDD functions are applicable 
        val x = sc.parallelize(0 to 5)
        val y = sc.parallelize(1000 to 1005)
        >>> x.zip(y).collect()
        res35: Array[(Int, Int)] = Array((0,1000), (1,1001), (2,1002), (3,1003), (4,1004), (5,1005))
       
    def zipWithIndex(): RDD[(T, Long)]
        Zips this RDD with its element indices.
        >>> sc.parallelize(Array("a", "b", "c", "d"), 3).zipWithIndex().collect()
        [('a', 0), ('b', 1), ('c', 2), ('d', 3)]

    def zipWithUniqueId(): RDD[(T, Long)]
        Zips this RDD with generated unique Long ids.
        >>> sc.parallelize(Array("a", "b", "c", "d", "e"), 3).zipWithUniqueId().collect()
        [('a', 0), ('b', 1), ('c', 4), ('d', 2), ('e', 5)]
  
    def coalesce(numPartitions: Int, shuffle: Boolean = false, partitionCoalescer: Option[PartitionCoalescer] = Option.empty)(implicit ord: Ordering[T] = null): RDD[T]
        Return a new RDD that is reduced into numPartitions partitions.
         >>> sc.parallelize(Array(1, 2, 3, 4, 5), 3).glom().collect()
        [[1), [2, 3), [4, 5]]
        >>> sc.parallelize(Array(1, 2, 3, 4, 5), 3).coalesce(1).glom().collect()
        [[1, 2, 3, 4, 5]]
        
    def partitions: Array[Partition]
    def unpersist(blocking: Boolean = true): RDD.this.type
    def persist(): RDD.this.type
    def persist(newLevel: StorageLevel): RDD.this.type
    def cache(): RDD.this.type
    def checkpoint(): Unit
    def getCheckpointFile: Option[String]
    def localCheckpoint(): RDD.this.type
    def getNumPartitions: Int
    def context: SparkContext
    def sparkContext: SparkContext
    def getStorageLevel: StorageLevel
    val id: Int

     



    
///+++RDD -  Shared variables(broadcast and accumulators) 
 
//Spark natively supports accumulators of numeric types, 
//and programmers can add support for new types.
val accum = sc.accumulator(0) //Driver
sc.parallelize(Array(1, 2, 3, 4)).foreach(x => accum.add(x)) //Executor
accum.value  //10  //Driver 

//OR 
val accum = sc.longAccumulator("My Accumulator") //Driver
sc.parallelize(Array(1, 2, 3, 4)).foreach(x => accum.add(x))//Executor
accum.value  //res2: Long = 10 //Driver

//Otheres are collectionAccumulator[T](name: String), collectionAccumulator[T]
//doubleAccumulator(name: String), doubleAccumulator, longAccumulator(name: String), longAccumulator


///*User defined accumulator 

//The AccumulatorV2 abstract class has several methods which one has to override: 
//reset for resetting the accumulator to zero, 
//add for adding another value into the accumulator, 
//merge for merging another same-type accumulator into this one

//abstract  class  AccumulatorV2[IN, OUT] extends Serializable 
//that can accumulate inputs of type IN, and produce output of type OUT.
import org.apache.spark.util._
class VectorAccumulatorV2 extends AccumulatorV2[MyVector, MyVector] {

  private val myVector: MyVector = MyVector.createZeroVector

  def reset(): Unit = {
    myVector.reset()
  }

  def add(v: MyVector): Unit = {
    myVector.add(v)
  }
  def  copy(): AccumulatorV2[MyVector, MyVector] = {
  
  }
  def  isZero: Boolean = {
  
  }
  def  merge(other: AccumulatorV2[MyVector, MyVector]): Unit = {
  
  }
  def  value: MyVector = {
  
  }
}

// Then, create an Accumulator of this type:
val myVectorAcc = new VectorAccumulatorV2
// Then, register it into spark context:
sc.register(myVectorAcc, "MyVectorAcc1")




////Spark - RDD - Shared Variables - Broadcast Variables


val b = sc.broadcast(Array(1, 2, 3, 4, 5))
>>> b.value     //Driver 
[1, 2, 3, 4, 5]
>>> sc.parallelize(Array(0, 0)).flatMap(x => b.value).collect() //closure in executor 
es41: Array[Int] = Array(1, 2, 3, 4, 5, 1, 2, 3, 4, 5)





///+++Spark - RDD - Persistence

//You can mark an RDD to be persisted using the persist() or cache() methods on it. 
//The first time it is computed in an action, it will be kept in memory on the nodes.

//The cache() method is a shorthand for using the default storage level, 
//which is StorageLevel.MEMORY_ONLY 

//Spark automatically monitors cache usage on each node 
//and drops out old data partitions in a least-recently-used (LRU) fashion. 
//OR use the RDD.unpersist() method.


///StorageLevel describes how an RDD is persisted (and addresses the following concerns):
    Does RDD use disk?
    How much of RDD is in memory?
    Does RDD use off-heap memory?
    Should an RDD be serialized (while persisting)?
    How many replicas (default: 1) to use (can only be less than 40)?

//Example 
val lines = sc.textFile("README.md")
>>> lines.getStorageLevel
res0: org.apache.spark.storage.StorageLevel = StorageLevel(disk=false, memory=false, offheap=..)


//There are the following StorageLevel (number _2 in the name denotes 2 replicas):
MEMORY_ONLY         
    Store RDD as deserialized Java objects in the JVM. If the RDD does not fit in memory, 
    some partitions will not be cached and will be recomputed on the fly each time they are needed. 
    This is the default level.  
MEMORY_AND_DISK     
    Store RDD as deserialized Java objects in the JVM. 
    If the RDD does not fit in memory, store the partitions that dont fit on disk, 
    and read them from there when theyre needed.  
MEMORY_ONLY_SER     
    (Java and Scala)  Store RDD as serialized Java objects (one byte array per partition). 
    This is generally more space-efficient than deserialized objects, especially 
    when using a fast serializer, but more CPU-intensive to read.  
MEMORY_AND_DISK_SER 
    (Java and Scala)  Similar to MEMORY_ONLY_SER, but spill partitions that dont fit in memory 
    to disk instead of recomputing them on the fly each time they re needed.  
DISK_ONLY           
    Store the RDD partitions only on disk.  
MEMORY_ONLY_2, MEMORY_AND_DISK_2, etc.  
    Same as the levels above, but replicate each partition on two cluster nodes.  
OFF_HEAP (experimental)     
    Similar to MEMORY_ONLY_SER, but store the data in off-heap memory. 
    This requires off-heap memory to be enabled.  

///Which Storage Level to Choose
•If your RDDs fit comfortably with the default storage level (MEMORY_ONLY), leave them that way. 
 This is the most CPU-efficient option, allowing operations on the RDDs to run as fast as possible.

•If not, try using MEMORY_ONLY_SER and selecting a fast serialization library to make the objects much more space-efficient, 
 but still reasonably fast to access. (Java and Scala)

•Don’t spill to disk unless the functions that computed your datasets are expensive, 
 or they filter a large amount of the data. 
 Otherwise, recomputing a partition may be as fast as reading it from disk.

•Use the replicated storage levels if you want fast fault recovery 
 (e.g. if using Spark to serve requests from a web application). 
 All the storage levels provide full fault tolerance by recomputing lost data, 
 but the replicated ones let you continue running tasks on the RDD without waiting to recompute a lost partition.
  
            
            
            
            
///+++ Example Iris

val iris = sc.textFile(raw"D:\Desktop\PPT\spark\data\iris.csv", 8)

>>> iris.take(5)
es44: Array[String] = Array('SepalLength,SepalWidth,PetalLength,PetalWidth,Name', '5.1,3.5,1.4,0.2,Iris-setosa', '4.9,3.0,1.4,0.2,Iris-setosa', '4.7,3.2,1.3,0.2,Iris-setosa', '4.6,3.1,1.5,0.2,Iris-setosa')

//remove header 
val iris1 = iris.zipWithIndex().filter(t => t._2 != 0).map(t => t._1.split(","))

val iris2 = iris1.map(t => (t.last , t.init.map(x=>x.toDouble)))

val uniqueName = iris2.groupByKey().keys.collect


//Create a Partitioner based on "Name"
case class NamePartioner(partitions:Int, lst:Array[String]) extends Partitioner{
    def getPartition(key: Any): Int = {
                lst.indexOf(key.asInstanceOf[String]) % partitions
             }
    def numPartitions: Int = partitions
    }

val iris3 = iris2.groupByKey(NamePartioner(3,uniqueName))//new org.apache.spark.HashPartitioner(3)) 
//Array[(String, Iterable[Array[Double]])]

>>> iris3.glom().take(3)  //ie each partition has only one element ie (Name, Iterable( Array(1st row), Array(2nd Row )) )
es49: Array[Array[(String, Iterable[Array[Double]])]] = Array(Array((Iris-setosa,CompactBuffer([D@788bbbaa, [D@5d3ccbc3, [D@7a369174, [D@7a95626b, [D@5fe6d078,[D@64bf6a94, [D@2accea46, [D@7b9b434e, [D@12973955, [D@de31a59, [D@40b04f79, [D

>>> iris3.first()
es50: (String, Iterable[Array[Double]]) = (Iris-setosa,CompactBuffer([D@12f2ea1

iris3.foreachPartition(it => println(it.toList))


//preserve key and partitioning 
//it contains only one element (as partition contains one element)
//func: (it: Iterator[(String, Iterable[Array[Double]])], which: Int):Iterator[(String, List[Double])]
def func(it:Iterator[(String, Iterable[Array[Double]])], which:Int=0)={
    val lst = it.toList(0) //tuple (String, Iterable[Array[Double]])
    //println(lst)
    //must return a iterator  for that partition
    List( (lst._1, lst._2.toList.map(array => array(which)))).iterator
}


val iris4 = iris3.mapPartitions(it => func(it,0), true)
>>> iris4.first
res51: (String, List[Double]) = (Iris-setosa,List(5.1, 4.9, 4.7, 4.6, 5.0, 5.4..

val iris5 = iris4.map(t => (t._1, Map("max"-> t._2.max) ))   

>>> iris5.collect()            
res81: Array[(String, scala.collection.immutable.Map[String,Double])] = Array((Iris-virginica,Map(max -> 7.9)), (Iris-versicolor,Map(max -> 7.0)), (Iris-setosa,Map(max -> 5.8)))           
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

    






///+++ Shuffling  Affect 
case class CFFPurchase(customerId: Int, destination: String, price: Double)

val purchases = List( CFFPurchase(100, "Geneva", 22.25),
                      CFFPurchase(100, "Zurich", 42.10),
                      CFFPurchase(100, "Fribourg", 12.40),
                      CFFPurchase(100, "St.Gallen", 8.20),
                      CFFPurchase(100, "Lucerne", 31.60),
                      CFFPurchase(100, "Basel", 16.20) )

                      
val purchasesRdd = sc.parallelize(purchases,3)
>>> purchasesRdd.glom().collect()
[[CFFPurchase(customerId=100, destination='Geneva', price=22.25), CFFPurchase(customerId=100, destination='Zurich', price=42.1)), 
[CFFPurchase(customerId=100, destination='Fribourg', price=12.4), CFFPurchase(customerId=100, destination='St.Gallen', price=8.2)), 
[CFFPurchase(customerId=100, destination='Lucerne', price=31.6), CFFPurchase(customerId=100, destination='Basel', price=16.2)]]

//Calculate how many trips, and how much money was spent by each individual customer over the course of the month.
val purchasesPerMonth = purchasesRdd.map( p => (p.customerId, p.price) ) // pair RDD
                                    .groupByKey()                        // RDD[K, Iterable[V]] i.e RDD[p.customerId, Iterable[p.price]]
                                    .map( p => (p._1, (p._2.size, p._2.sum)) )
                                   
 
    
purchasesPerMonth.collect()
>>> purchasesPerMonth.toDebugString()
(3) PythonRDD[32] at RDD at PythonRDD.scala:48 []
 |  MapPartitionsRDD[31] at mapPartitions at PythonRDD.scala:122 []
 |  ShuffledRDD[30] at partitionBy at NativeMethodAccessorImpl.java:0 []
 +-(3) PairwiseRDD[29] at groupByKey at <stdin>:2 []
    |  PythonRDD[28] at groupByKey at <stdin>:2 []
    |  ParallelCollectionRDD[16] at parallelize at PythonRDD.scala:175 []


*** Mastering_spark.docx :: Spark Shuffling

//Can we do a better job?,use reduceByKey.

val purchasesPerMonth = purchasesRdd.map( p => (p.customerId, (1, p.price)) ) // pair RDD
                                    .reduceByKey( (v1, v2) => (v1._1 + v2._1, v1._2 + v2._2) )
                                                       

purchasesPerMonth.collect()                          
>>>purchasesPerMonth.toDebugString()
(3) PythonRDD[27] at RDD at PythonRDD.scala:48 []
 |  MapPartitionsRDD[26] at mapPartitions at PythonRDD.scala:122 []
 |  ShuffledRDD[25] at partitionBy at NativeMethodAccessorImpl.java:0 []
 +-(3) PairwiseRDD[24] at reduceByKey at <stdin>:3 []
    |  PythonRDD[23] at reduceByKey at <stdin>:3 []
    |  ParallelCollectionRDD[16] at parallelize at PythonRDD.scala:175 []
    
    
//Operations that might cause a shuffle:
•	cogroup
•	groupWith
•	join
•	leftOuterJoin
•	rightOuterJoin
•	groupByKey
•	reduceByKey
•	combineByKey
•	distinct
•	intersection
•	repartition
•	coalesce

//Common scenarios where Network Shuffle can be avoided using Partitioning
1.	reduceByKey running on a pre-partitioned RDD will cause the values to be computed locally, 
     requiring only the final reduced value to be sent from worker to the driver.
2.	join called on 2 RDDs that are pre-partitioned with the same partitioner 
    and cached on the same machine will cause the join to be computed locally, with no shuffling across the network.


       

       
       

//******DAY-2 ********//
///++++++ Spark SQL and Data Frames
Dataset[T]
    Typed one     
    T(each element) can be primitives , Array, Seq, Set, Map of those 
    or case class or Tuple of these (for whom Encoder is present, for implicits, check SQLImplicits)
    map,filter,reduce.. can handle T as each element 
    To convert from DataFrame to Dataset[U], use df.as[U], U is case class or tuple or a class child of Product 
DataFrame 
    untyped, each element is Row(*Any) ie type DataFrame = Dataset[Row] 
    map,filter,reduce only can handle Row(Any*) , use case Pattern matching or casting Any to Type 
    Row elements can be of StructType(another row), primitives(LongType, StringType,...), ArrayType of other elements , MapType 
    Use apply(index/ket), getItem(index/key) or getField(fieldName) or field1.field2 for accessing nested element of MapType, ArrayType, StructType
    

    
///Displaying DataFrame - Note various options of show 
def  show(numRows: Int, truncate: Int): Unit 
def  show(numRows: Int, truncate: Boolean): Unit 
def  show(truncate: Boolean): Unit 
def  show(): Unit   //Displays the top 20 rows of Dataset in a tabular form.
def  show(numRows: Int): Unit 
//to display all columns and all rows use 
df.show(Int.MaxValue, false)


///Column : A column in a DataFrame.

//Columns have +, -, like, and many operations , check http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.Column
//Also column can take any functions defined in http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$

//A new column is constructed based on the input columns present in a dataframe:
import spark.implicits._   //for conversion from $"col" to Column
df("columnName")            // On a specific DataFrame.
col("columnName")           // A generic column no yet associated with a DataFrame.
col("columnName.field")     // Extracting a struct field
col("`a.column.with.dots`") // Escape `.` in column names.
$"columnName"               // Scala short hand for a named column.
expr("a + 1")               // A column that is constructed from a parsed SQL Expression.
lit("abc")                  // A column that produces a literal (constant) value.
'columnName                 //from symbol , '

//Many Methods 
explain(extended: Boolean): Unit
apply(extraction: Any): Column //from complex type 
%, *, +, -, / , <, <=, ===(note the equality), =!=(note for enequality),...
&&, !, ||
alias(alias: String): Column, as(alias: String, metadata: Metadata): Column
as(aliases: Seq[String]): Column,as(alias: String): Column,cast(to: String): Column//to is string of DataType 
contains(other: Any): Column, asc: Column, asc_nulls_first: Column, asc_nulls_last: Column, desc: Column, desc_nulls_first: Column, desc_nulls_last: Column
endsWith/startsWith(literal: String): Column, endsWith/startsWith(other: Column): Column 
getField(fieldName: String): Column, getItem(key: Any): Column
isin(list: Any*): Column.like(literal: String): Column, rlike(literal: String): Column
when(condition: Column, value: Any): Column, otherwise(value: Any): Column
over(window: WindowSpec): Column
substr(startPos: Int, len: Int): Column substr(startPos: Column, len: Column): Column
as[U](implicit arg0: Encoder[U]): TypedColumn[Any, U], expr: Expression



///Row 
val row = Row(1, true, "a string", null)  //Any*
val firstValue = row(0)
val fourthValue = row(3)

val firstValue = row.getInt(0)// firstValue: Int = 1
val isNull = row.isNullAt(3)// isNull: Boolean = true

import org.apache.spark.sql._
val pairs = spark.sql("SELECT key, value FROM src").rdd.map {
  case Row(key: Int, value: String) =>
    key -> value
}  

//many methods 
apply(i: Int): Any 
fieldIndex(name: String): Int 
getAs[T](fieldName: String): T 
getAs[T](i: Int): T 
getBoolean(i: Int): Boolean , getInt(i:Int):Int,,getDate(i: Int): java.sql.Date ,getTimestamp(i: Int): java.sql.Timestamp , ....
getList[T](i: Int): List[T],getMap[K, V](i: Int): Map[K, V] ,getSeq[T](i: Int): Seq[T] ,getStruct(i: Int): Row 
getValuesMap[T](fieldNames: Seq[String]): Map[String, T] 
isNullAt(i: Int): Boolean 
schema: StructType 
size: Int 
toSeq: Seq[Any] 
Row.empty: Row 
Row.fromSeq(values: Seq[Any]): Row ,Row.fromTuple(tuple: Product): Row 
Row.merge(rows: Row*): Row 
  
  
  
///Convert to To RDD[Row] ie each element is Row(*Any) 
df.rdd 

///Creation of DF or DS 
import spark.implicits._ 

//If  RDD[Row], must use schema in createDataFrame , Row can contain another Row, ArrayType, MapType, primitives 
//Seq[Product],RDD[Product], use createDataFrame, no schema is required 
spark.createDataFrame(rowRDD: RDD[Row], schema: StructType): DataFrame
spark.createDataFrame[A <: Product](data: Seq[A])(implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[A]): DataFrame
spark.createDataFrame[A <: Product](rdd: RDD[A])(implicit arg0: scala.reflect.api.JavaUniverse.TypeTag[A]): DataFrame

//If Seq[T], RDD[T], 
//use createDataSet or toDS() or df.as[T] for DataSet or toDF()/toDF(*cols) for DataFrame , no schema is required 
//but Encoders[T] must be present , T /each element must ie primitives , Array, Seq, Set, Map of those 
//or case class or Tuple of these or nested of these(for implicits, check SQLImplicits)
toDF(colNames: String*): DataFrame 
toDF(): DataFrame 
toDS(): Dataset[T]  
spark.createDataset[T](data: RDD[T])(implicit arg0: Encoder[T]): Dataset[T]
spark.createDataset[T](data: Seq[T])(implicit arg0: Encoder[T]): Dataset[T]



///From RDD[T] 

import spark.implicits._  //toDF()
case class Person(name: String, age: Long)
val peopleDF = spark.sparkContext
  .textFile(raw"D:\Desktop\PPT\spark\data\people.txt")
  .map(_.split(","))
  .map(attributes => Person(attributes(0), attributes(1).trim.toInt))
  .toDF()  //peopleDF: org.apache.spark.sql.DataFrame = [name: string, age: bigint]
  
peopleDF.map{case Row(name: String, age: Long) => name } //res87: org.apache.spark.sql.Dataset[String] = [value: string]
>>> peopleDF.printSchema
root
 |-- name: string (nullable = true)
 |-- age: long (nullable = false)

 
//DS 
peopleDF.as[Person] //res90: org.apache.spark.sql.Dataset[Person] = [name: string, age: bigint]

val peopleDF2 = spark.sparkContext
  .textFile(raw"D:\Desktop\PPT\spark\data\people.txt")
  .map(_.split(","))
  .map(attributes => Person(attributes(0), attributes(1).trim.toInt))
  .toDS()  //peopleDF2: org.apache.spark.sql.Dataset[Person] = [name: string, age: bigint]
  
peopleDF2.map(_.name) //res88: org.apache.spark.sql.Dataset[String] = [value: string]
>>> peopleDF2.printSchema
root
 |-- name: string (nullable = true)
 |-- age: long (nullable = false)


//From Seq[T]
case class UserEvent(id: Int, data: String, isLast: Boolean)
case class UserSession(userEvents: Seq[UserEvent])


>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDS()
res2: org.apache.spark.sql.Dataset[(Int, String, Boolean)] = [_1: int, _2: string ... 1 more field]

//DF column names must match to UserEvent attribute name 
>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDF().as[UserEvent]
org.apache.spark.sql.AnalysisException: cannot resolve '`id`' given input columns: [_1, _2, _3];

>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDS().map{case (id,data,isLast) => UserEvent(id,data,isLast)}
res91: org.apache.spark.sql.Dataset[UserEvent] = [id: int, data: string ... 1 more field]

>>> Seq( (1,"XYZ",true), (2,"yz",false)).toDF("id", "data","isLast").as[UserEvent]
res4: org.apache.spark.sql.Dataset[UserEvent] = [id: int, data: string ... 1 more field]

//each element is Product , Seq[Product] , Array[Product], Set[Product], Map and nested of this 
>>> Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)).toDF()
es104: org.apache.spark.sql.DataFrame = [id: int, data: string ... 1 more field

>>> Seq( Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)), Seq( UserEvet(1,"XYZ",true), UserEvent(2,"yz",false))).toDF()
res96: org.apache.spark.sql.DataFrame = [value: array<struct<id:int,data:string,isLast:boolean>>]
>>> res96.map{case Row(value:Seq[_]) => value.size}
res99: org.apache.spark.sql.Dataset[Int] = [value: int]

>>> Seq( Seq( (1,"XYZ",true), (2,"yz",false)), Seq( (1,"XYZ",true), (2,"yz",false))).toDF("userEvents")
res8: org.apache.spark.sql.DataFrame = [userEvents: array<struct<_1:int,_2:string,_3:boolean>>]

>>> Seq( Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)), Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false))).toDF("userEvents").as[UserSession]
res12: org.apache.spark.sql.Dataset[UserSession] = [userEvents: array<struct<id:int,data:string,isLast:boolean>>]

>>> Seq( Array( (1,"XYZ",true), (2,"yz",false)), Array( (1,"XYZ",true), (2,"yz",false))).toDF("userEvents")
res100: org.apache.spark.sql.DataFrame = [userEvents: array<struct<_1:int,_2:string,_3:boolean>>]

>>>  Seq( Set( (1,"XYZ",true), (2,"yz",false)), Set( (1,"XYZ",true), (2,"yz",false))).toDF("userEvents")
res101: org.apache.spark.sql.DataFrame = [userEvents: array<struct<_1:int,_2:string,_3:boolean>>]

>>> res101.collect
res102: Array[org.apache.spark.sql.Row] = Array([WrappedArray([1,XYZ,true], [2,yz,false])], [WrappedArray([1,XYZ,true], [2,yz,false])])

>>>  Seq( Map( 1-> (1,"XYZ",true), 2->(2,"yz",false)), Map(1-> (1,"XYZ",true), 2-> (2,"yz",false))).toDF("userEvents")
res103: org.apache.spark.sql.DataFrame = [userEvents: map<int,struct<_1:int,_2:string,_3:boolean>>]


//Each element is Seq[UserEvent], then convert to UserSession 
>>> Seq( Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)), Seq( UserEvent(1,"XYZ",true), UserEvent(2,"yz",false)))
    .toDS()
    .map { case ue @ Seq(v @ _*) => UserSession(ue) }
res13: org.apache.spark.sql.Dataset[UserSession] = [userEvents: array<struct<id:int,data:string,isLast:boolean>>]


///From RDD[Row] and schema 
// Create an RDD an specify schema 
import spark.implicits._
val peopleRDD = spark.sparkContext.textFile(raw"D:\Desktop\PPT\spark\data\people.txt")
// The schema is encoded in a string
val schemaString = "name age"
// Generate the schema based on the string of schema
val fields = schemaString.split(" ").map(fieldName => StructField(fieldName, StringType, nullable = true)).toList
val schema = StructType(fields)
// Convert records of the RDD (people) to Rows
val rowRDD = peopleRDD
  .map(_.split(","))
  .map(attributes => Row(attributes(0), attributes(1).trim))
// Apply the schema to the RDD
val peopleDF = spark.createDataFrame(rowRDD, schema)  //toDF does not work for Row as Row does not have implicit Encoder 


//Using createDataset
case class Person(name: String, age: Long)
val data = Seq(Person("Michael", 29), Person("Andy", 30), Person("Justin", 19))
val ds = spark.createDataset(data)
ds.show()



///Example 

import org.apache.spark.sql.Encoder

import org.apache.spark.sql.Row

import org.apache.spark.sql.SparkSession

import org.apache.spark.sql.types._

val spark = SparkSession
  .builder()
  .appName("Spark SQL basic example")
  .config("spark.some.config.option", "some-value")
  .getOrCreate()


val df = spark.read.json(raw"D:\Desktop\PPT\spark\data\people.json")

// Displays the content of the DataFrame to stdout
df.show()


// This import is needed to use the $-notation
import spark.implicits._
// Print the schema in a tree format
df.printSchema()

// Select only the "name" column
df.select("name").show()

// Select everybody, but increment the age by 1
df.select($"name", $"age" + 1).show()

// Select people older than 21
df.filter($"age" > 21).show()

// Count people by age
df.groupBy("age").count().show()


// Register the DataFrame as a SQL temporary view
df.createOrReplaceTempView("people")

val sqlDF = spark.sql("SELECT * FROM people")
sqlDF.show()


// Register the DataFrame as a global temporary view
df.createGlobalTempView("people")

// Global temporary view is tied to a system preserved database `global_temp`
spark.sql("SELECT * FROM global_temp.people").show()


// Global temporary view is cross-session
spark.newSession().sql("SELECT * FROM global_temp.people").show()




///Example - String interpretation with the array() method
val df = Seq(
  ("i like blue and red"),
  ("you pink and blue")
).toDF("word1")

val actualDF = df.withColumn(
  "colors",
  array(
    when(col("word1").contains("blue"), "blue"),
    when(col("word1").contains("red"), "red"),
    when(col("word1").contains("pink"), "pink"),
    when(col("word1").contains("cyan"), "cyan")
  )
)
//The array() function unfortunately includes null values in the colors column. 
actualDF.show(truncate = false)
+-------------------+------------------------+
|word1              |colors                  |
+-------------------+------------------------+
|i like blue and red|[blue, red, null, null] |
|you pink and blue  |[blue, null, pink, null]|
+-------------------+------------------------+

//OR 
val colors = Array("blue", "red", "pink", "cyan")

val actualDF = df.withColumn(
  "colors",
  array(
    colors.map{ c: String =>  when(col("word1").contains(c), c) }: _*
  )
)
actualDF.show(truncate=false)
+-------------------+------------------------+
|word1              |colors                  |
+-------------------+------------------------+
|i like blue and red|[blue, red, null, null] |
|you pink and blue  |[blue, null, pink, null]|
+-------------------+------------------------+

///Eliminating null from the arrays

val actualDF = df.withColumn(
  "colors",
  split(
    concat_ws(
      ",",
      when(col("word1").contains("blue"), "blue"),
      when(col("word1").contains("red"), "red"),
      when(col("word1").contains("pink"), "pink"),
      when(col("word1").contains("cyan"), "cyan")
    ),
    ","
  )
)

actualDF.show(truncate=false)
+-------------------+------------+
|word1              |colors      |
+-------------------+------------+
|i like blue and red|[blue, red] |
|you pink and blue  |[blue, pink]|
+-------------------+------------+



///Example - Splitting a string into an ArrayType column

import spark.implicits._ 

val singersDF = Seq(  ("beatles", "help|hey jude"),  ("romeo", "eres mia")).toDF("name", "hit_songs")

//def withColumn(colName: String, col: Column): DataFrame
//Returns a new Dataset by adding a column or replacing the existing column that has the same name. 
val actualDF = singersDF.withColumn( "hit_songs", split(col("hit_songs"), "\\|") )

actualDF.show()
//output 
+-------+----------------+
|   name|       hit_songs|
+-------+----------------+
|beatles|[help, hey jude]|
|  romeo|      [eres mia]|
+-------+----------------+

actualDF.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- hit_songs: array (nullable = true)
 |    |-- element: string (containsNull = true)

  
///Directly creating an ArrayType column

val rdd = sc.parallelize( Seq( Row("bieber", Array("baby", "sorry")), Row("ozuna", Array("criminal"))))
val schema = StructType(StructField("name", StringType, true) :: StructField("hit_songs", ArrayType(StringType, true), true) ::Nil)
val singersDFA = spark.createDataFrame(rdd, schema)
 
singersDFA.show()
//output 
+------+-------------+
|  name|    hit_songs|
+------+-------------+
|bieber|[baby, sorry]|
| ozuna|   [criminal]|
+------+-------------+
singersDFA.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- hit_songs: array (nullable = true)
 |    |-- element: string (containsNull = true)

//Example - selecting 1st index 
singersDFA.select(
    col("name"),
    col("hit_songs")(0).as("First")
  ).show()
  
 
///Directly creating a MapType column

val singersDF = spark.createDataFrame(
  sc.parallelize(Seq(
    Row("sublime", Map(
      "good_song" -> "santeria",
      "bad_song" -> "doesn't exist")
    ),
    Row("prince_royce", Map(
      "good_song" -> "darte un beso",
      "bad_song" -> "back it up")
    )
  )), StructType(List(
    StructField("name", StringType, true),
    StructField("songs", MapType(StringType, StringType, true), true)
  ))
)

singersDF.show()
//output 
+------------+--------------------+
|        name|               songs|
+------------+--------------------+
|     sublime|Map(good_song -> ...|
|prince_royce|Map(good_song -> ...|
+------------+--------------------+

singersDF.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: string (valueContainsNull = true)

//Example - we can display the singer name and their bad song:
singersDF.select(
    col("name"),
    col("songs")("bad_song").as("bad song!")
  ).show()
//output 
+------------+-------------+
|        name|    bad song!|
+------------+-------------+
|     sublime|doesnt exist|
|prince_royce|   back it up|
+------------+-------------+

///Creating a schema with a column that uses MapType and ArrayType
val singersDFMA = spark.createDataFrame(
  sc.parallelize(Seq(
    Row("miley", Map(
      "good_songs" -> Array("party in the usa", "wrecking ball"),
      "bad_songs" -> Array("younger now"))
    ),
    Row("kesha", Map(
      "good_songs" -> Array("tik tok", "timber"),
      "bad_songs" -> Array("rainbow"))
    )
  )), StructType(List(
    StructField("name", StringType, true),
    StructField("songs", MapType(StringType, ArrayType(StringType, true), true), true)
  ))
)

singersDFMA.show()
//output
+-----+--------------------+
| name|               songs|
+-----+--------------------+
|miley|Map(good_songs ->...|
|kesha|Map(good_songs ->...|
+-----+--------------------+

singersDFMA.printSchema()
//output 
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: array (valueContainsNull = true)
 |    |    |-- element: string (containsNull = true)

// display the good songs for each singer.
singersDFMA
  .select(
    col("name"),
    col("songs")("good_songs")(0).as("fun")  //check how items are accessed 
  ).show()
//output 
+-----+----------------+
| name|             fun|
+-----+----------------+
|miley|party in the usa|
|kesha|         tik tok|
+-----+----------------+

///array_contains() and explode() methods for ArrayType columns
//forall() and exists() methods for ArrayType columns that function similar to the Scala forall() and exists() methods.
//The array_contains method returns true if the column contains a specified element.
val peopleDF = spark.createDataFrame(
  sc.parallelize(Seq(
    Row("bob", Array("red", "blue")),
    Row("maria", Array("green", "red")),
    Row("sue", Array("black"))
  )), StructType(List(
    StructField("name", StringType, true),
    StructField("favorite_colors", ArrayType(StringType, true), true)
  ))
)

val actualDF = peopleDF.withColumn(
  "likes_red",
  array_contains(col("favorite_colors"), "red")
)

actualDF.show()

+-----+---------------+---------+
| name|favorite_colors|likes_red|
+-----+---------------+---------+
|  bob|    [red, blue]|     true|
|maria|   [green, red]|     true|
|  sue|        [black]|    false|
+-----+---------------+---------+

//The explode() method creates a new row for every element in an array.
peopleDF.select(
  col("name"),
  explode(col("favorite_colors")).as("color")
).show()

+-----+-----+
| name|color|
+-----+-----+
|  bob|  red|
|  bob| blue|
|maria|green|
|maria|  red|
|  sue|black|
+-----+-----+

///Example complex example 
case class Person(userId: String, tech: Option[Tech])
case class Browser(family: Option[String],
               major: Option[Int] = None, 
               minor: Option[Int] = None,               
               language: Option[String],
               timesSeen: Long = 1
               )
case class Tech(browsers: Seq[Browser], 
                     oss: String)

import spark.implicits._ 
val df = Seq(Person("abc",Some(Tech(browsers=Seq(
    Browser(family=Some("IE"), major=Some(7), language=Some("en"), timesSeen=3),
    Browser(family=None, major=None, language=Some("en-us"), timesSeen=1),
    Browser(family=Some("Firefox"), major=None, language=None, timesSeen=1)
  ), oss="win"))),
  Person("abc",Some(Tech(browsers=Seq(
    Browser(family=Some("IE"), major=Some(7), language=Some("en"), timesSeen=3),
    Browser(family=None, major=None, language=Some("en-us"), timesSeen=1),
    Browser(family=Some("Firefox"), major=None, language=None, timesSeen=1)
  ), oss="win")))).toDF()
//df:[userId: string, tech: struct<browsers: array<struct<family:string,major:int,minor:int,language:string,timesSeen:bigint>>, oss: string>]

// Select two columns
df.select("userId", "tech.browsers").show()
//output 
+------+--------------------+
|userId|            browsers|
+------+--------------------+
|   abc|[[IE,7,null,en,3]...|
|   abc|[[IE,7,null,en,3]...|
+------+--------------------+


// Select the nested values only
df.select("tech.browsers").show(truncate = false)
+------------------------------------------------------------------------+
|browsers                                                                |
+------------------------------------------------------------------------+
|[[IE,7,null,en,3], [null,null,null,en-us,1], [Firefox,null,null,null,1]]|
|[[IE,7,null,en,3], [null,null,null,en-us,1], [Firefox,null,null,null,1]]|
+------------------------------------------------------------------------+

// Extract the family (nested value)
// This way you can iterate over the persons, and get their browsers
// Family values are nested
df.select("tech.browsers.family").show()
//output 
+-------------------+
|             family|
+-------------------+
|[IE, null, Firefox]|
|[IE, null, Firefox]|
+-------------------+

// Normalize the family: One row for each family
// Then you can iterate over all families
// Family values are un-nested, empty values/null/None are handled by explode()
df.select(explode(col("tech.browsers.family")).alias("family")).show()
+-------+
| family|
+-------+
|     IE|
|   null|
|Firefox|
|     IE|
|   null|
|Firefox|
+-------+

//
val families = df.select(explode(col("tech.browsers.family"))).map(row => row.getString(0)).distinct().collect().toList
println(families) //List(null, Firefox, IE)







///More Operation on DF and using sql.{functions => F}
import spark.implicits._ 
import org.apache.spark.sql.{functions => F}
import org.apache.spark.sql.types._ 
import org.apache.spark.sql._

//Basic Examples 
//json should contain all objects one by one , not with array syntax 
val people = spark.read.json(raw"D:\Desktop\PPT\spark\data\peopledepart.json")
val names = people.select("name") // in Scala; names is a Dataset[String]
names.show()
val ageCol = people("age")  
people("age") + 10  // in Scala

//Join example 
val department = spark.read.json(raw"D:\Desktop\PPT\spark\data\department.json")
//wheneever, list of columns needs to be mentioned,
//use 
//(col1: String,cols: String*) or (cols: org.apache.spark.sql.Column*) 
//dont mix it eg (String, Column) etc 
people.filter("age > 30")
  .join(department, people("departId") === department("id")) //Note === for eq or =!= for ne 
  .groupBy(department("name"), people("gender"))
  .agg(F.avg(people("salary")), F.max(people("age"))).orderBy(department("name")).show()
  
//Describe and filter 
people.describe("age", "height").show()
// The following are equivalent:
people.filter($"age" > 75)
people.where($"age" > 75) 


// Example of when and otherwise of Column 
//select(col: String,cols: String*)
//select(cols: org.apache.spark.sql.Column*)
//def  when(condition: Column, value: Any): Column 
//def  otherwise(value: Any): Column 
case class Person(name: String, age: Long)
val peopleDF = spark.sparkContext
  .textFile("./data/people.txt")
  .map(_.split(","))
  .map(attributes => Person(attributes(0), attributes(1).trim.toInt))
  .toDF()
  
peopleDF.select(when(peopleDF("name") === "Michael", 0)
  .when(peopleDF("name") === "Andy", 1)
  .otherwise(2).alias("cond"), peopleDF("age")).show()
  
  

//Getting a specefic row of DF 
//Not straight forward as DF are distributed 
//Getting a named column is df.select("colname")
df = spark.createDataFrame([("a", 1), ("b", 2), ("c", 3)], ["letter", "name"])
myIndex = 1
values = (df.rdd.zipWithIndex()
            .filter(lambda ((l, v), i): i == myIndex)
            .map(lambda ((l,v), i): (l, v))
            .collect())

print(values[0])


//Example - Below selects all columns from dataframe df 
//which has the column name mentioned in the Array 
colNames = Array("x","y")
df = df.select(colNames.head, colNames.tail: _*)

//for index ,colNos array which has following index 
import org.apache.spark.sql.functions._
colNos = Array(10,20,25,45)
df.select(colNos map df.columns map col: _*)
//or:
df.select(colNos map (df.columns andThen col): _*)
//or:
df.select(colNos map (col _ compose df.columns): _*)
//basically for single column index 
df.select(col(df.columns(index)))


//Few creation 
val l = Seq( Row("Alice", 1), Row("das", 2) )
val schema = StructType(List(StructField("name", StringType, true),  StructField("age", IntegerType, true)))
val rdd = sc.parallelize(l)
val df = spark.createDataFrame(rdd, schema)
val df2 = spark.createDataFrame(rdd, schema)

    
//Methods of Dataset[T]   , T for DF is Row(Any*)
def collect(): Array[T]
def collectAsList(): List[T]
def count(): Long  
   
def show(numRows: Int, truncate: Int, vertical: Boolean): Unit
def show(numRows: Int, truncate: Int): Unit
def show(numRows: Int, truncate: Boolean): Unit
def show(truncate: Boolean): Unit
def show(): Unit
def show(numRows: Int): Unit

def head(): T
def head(n: Int): Array[T]
def first(): T
def take(n: Int): Array[T]
def takeAsList(n: Int): List[T]
def toLocalIterator(): Iterator[T]
def limit(n: Int): Dataset[T]

///Basic Dataset functions
def  as[U](implicit arg0: Encoder[U]): Dataset[U]
def toDF(colNames: String*): DataFrame
def toDF(): DataFrame

def persist(newLevel: StorageLevel): Dataset.this.type
def persist(): Dataset.this.type
def cache(): Dataset.this.type
def unpersist(): Dataset.this.type
def unpersist(blocking: Boolean): Dataset.this.type
def storageLevel: StorageLevel

def printSchema(): Unit
lazy val rdd: RDD[T]
val sparkSession: SparkSession
def toJSON: Dataset[String]
def schema: StructType //schema("fieldName") gives fieldName 
def localCheckpoint(eager: Boolean): Dataset[T]
def localCheckpoint(): Dataset[T]
def checkpoint(eager: Boolean): Dataset[T]
def checkpoint(): Dataset[T]
def columns: Array[String]
def dtypes: Array[(String, String)]
def explain(): Unit
def explain(extended: Boolean): Unit
    
def createGlobalTempView(viewName: String): Unit
def createOrReplaceGlobalTempView(viewName: String): Unit //The lifetime is tied to this Spark application.
    SELECT * FROM global_temp.view1.
def createOrReplaceTempView(viewName: String): Unit //tied to the SparkSession that was used to create this Dataset.

def alias(alias: Symbol): Dataset[T]
def alias(alias: String): Dataset[T]
def as(alias: Symbol): Dataset[T]
def as(alias: String): Dataset[T]

def apply(colName: String): Column
def col(colName: String): Column
def colRegex(colName: String): Column
def select(col: String, cols: String*): DataFrame
def select(cols: Column*): DataFrame
def selectExpr(exprs: String*): DataFrame  
def withColumn(colName: String, col: Column): DataFrame
def withColumnRenamed(existingName: String, newName: String): DataFrame
    
def coalesce(numPartitions: Int): Dataset[T]//when the fewer partitions are requested.
def repartition(partitionExprs: Column*): Dataset[T] //Column expression 
def repartition(numPartitions: Int, partitionExprs: Column*): Dataset[T]
def repartition(numPartitions: Int): Dataset[T]
def repartitionByRange(partitionExprs: Column*): Dataset[T]  //Column expression eg $"col" > 2
def repartitionByRange(numPartitions: Int, partitionExprs: Column*): Dataset[T]

def distinct(): Dataset[T]
def na: DataFrameNaFunctions
def stat: DataFrameStatFunctions
def describe(cols: String*): DataFrame
    //Computes basic statistics for numeric and string columns, 
    people .describe("age", "height").show()
def summary(statistics: String*): DataFrame
    people.summary().show()
    people.summary("count", "min", "25%", "75%", "max").show()
    people.select("age", "height").summary().show()
    
    
def dropDuplicates(col1: String, cols: String*): Dataset[T]
def dropDuplicates(colNames: Array[String]): Dataset[T]
def dropDuplicates(colNames: Seq[String]): Dataset[T]
def dropDuplicates(): Dataset[T]
def drop(col: Column): DataFrame
def drop(colNames: String*): DataFrame
def drop(colName: String): DataFrame
    
def except(other: Dataset[T]): Dataset[T]   //set minus 
def intersect(other: Dataset[T]): Dataset[T] 
def union(other: Dataset[T]): Dataset[T]
def unionByName(other: Dataset[T]): Dataset[T] 
def unionAll(other: Dataset[T]): Dataset[T]

def foreach(f: (T) => Unit): Unit  
def foreachPartition(f: (Iterator[T]) => Unit): Unit
def  reduce(func: (T, T) => T): T

def filter(func: (T) => Boolean): Dataset[T]
def filter(conditionExpr: String): Dataset[T]  //sql filter expression 
def filter(condition: Column): Dataset[T]   //column filter expression   
def where(conditionExpr: String): Dataset[T]
def where(condition: Column): Dataset[T]

def flatMap[U](func: (T) => TraversableOnce[U])(implicit arg0: Encoder[U]): Dataset[U]
def map[U](func: (T) => U)(implicit arg0: Encoder[U]): Dataset[U]
def mapPartitions[U](func: (Iterator[T]) => Iterator[U])(implicit arg0: Encoder[U]): Dataset[U]
def transform[U](t: (Dataset[T]) => Dataset[U]): Dataset[U]

def sort(sortExprs: Column*): Dataset[T]  //Column expression
def sort(sortCol: String, sortCols: String*): Dataset[T]
def sortWithinPartitions(sortExprs: Column*): Dataset[T]
def sortWithinPartitions(sortCol: String, sortCols: String*): Dataset[T]



def randomSplit(weights: Array[Double]): Array[Dataset[T]]
def randomSplit(weights: Array[Double], seed: Long): Array[Dataset[T]]
def randomSplitAsList(weights: Array[Double], seed: Long): List[Dataset[T]]   
def sample(withReplacement: Boolean, fraction: Double): Dataset[T]
def sample(withReplacement: Boolean, fraction: Double, seed: Long): Dataset[T]
def sample(fraction: Double): Dataset[T]
def sample(fraction: Double, seed: Long): Dataset[T]



//* agg(*exprs)
//Aggregate on the entire DataFrame without groups (shorthand for df.groupBy.agg()).
df.agg( Map("age" -> "max") ).collect()
res8: Array[org.apache.spark.sql.Row] = Array([2])
df.agg(min($"age")).collect()
res10: Array[org.apache.spark.sql.Row] = Array([1])



//* alias(alias)
//Returns a new DataFrame with an alias set.
val df_as1 = df.alias("df_as1")
val df_as2 = df.alias("df_as2")
val joined_df = df_as1.join(df_as2, col("df_as1.name") === col("df_as2.name"), "inner") //note ===
joined_df.select("df_as1.name", "df_as2.name", "df_as2.age").collect()
//res11: Array[org.apache.spark.sql.Row] = Array([Alice,Alice,1], [das,das,2])


//* collect()
//Returns all the records as a list of Row.
df.collect()
//res12: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])


//* columns
//Returns all column names as a list.
df.columns
//res13: Array[String] = Array(name, age)




//* count()
//Returns the number of rows in this DataFrame.
df.count()
//res14: Long = 2


//* cube(*cols)
//Create a multi-dimensional cube for the current DataFrame using the specified columns, 
//so we can run aggregation on them.
// cube() returns RelationalGroupedDataset 
//note select/orderby args must be all Column or String, no mix-in 

scala> df.show()
+-----+---+
| name|age|
+-----+---+
|Alice|  1|
|  das|  2|
+-----+---+

>>> df.cube("name", "age").count().orderBy("name", "age").show()
+-----+----+-----+
| name| age|count|
+-----+----+-----+
| null|null|    2|
| null|   1|    1|
| null|   2|    1|
|Alice|null|    1|
|Alice|   1|    1|
|  das|null|    1|
|  das|   2|    1|
+-----+----+-----+



//* describe(*cols)
//Computes statistics for numeric and string columns.
//This include count, mean, stddev, min, and max. 

>>> df.describe("age").show()
+-------+------------------+
|summary|               age|
+-------+------------------+
|  count|                 2|
|   mean|               1.5|
| stddev|0.7071067811865476|
|    min|                 1|
|    max|                 2|
+-------+------------------+
>>> df.describe().show() //df.describe("age", "name").show()
+-------+-----+------------------+
|summary| name|               age|
+-------+-----+------------------+
|  count|    2|                 2|
|   mean| null|               1.5|
| stddev| null|0.7071067811865476|
|    min|Alice|                 1|
|    max|  das|                 2|
+-------+-----+------------------+



//* distinct()
//Returns a new DataFrame containing the distinct rows in this DataFrame.
df.distinct().count()
//res20: Long = 2



//* drop(*cols)
//Returns a new DataFrame that drops the specified column. 
//This is a no-op if schema doesn’t contain the given column name(s).
>>> df.drop("age").collect()
res21: Array[org.apache.spark.sql.Row] = Array([Alice], [das])
>>> df.join(df2, df("name") === df2("name"), "inner").drop(df("name")).collect()
res22: Array[org.apache.spark.sql.Row] = Array([1,Alice,1], [2,das,2])



//* dropDuplicates(subset=None)
//Return a new DataFrame with duplicate rows removed, optionally only considering certain columns.
//drop_duplicates() is an alias for dropDuplicates().

//Row can not be toDF 
//product class can be 
case class Person( name:String, age:Int, height:Int)
val dfn = sc.parallelize(Seq( Person("Alice", 5, 80), Person("Alice", 5, 80))).toDF()
dfn.dropDuplicates().show()
+-----+---+------+
| name|age|height|
+-----+---+------+
|Alice|  5|    80|
+-----+---+------+


//* filter(condition)
//Filters rows using the given condition.
//where() is an alias for filter().
//condition – a Column of types.BooleanType or a string of SQL expression. 
>>> df.filter(df("age") > 1).collect()
res25: Array[org.apache.spark.sql.Row] = Array([das,2])
>>> df.where(df("age") === 2).collect()  //Note ===
res26: Array[org.apache.spark.sql.Row] = Array([das,2])
>>> df.filter("age > 1").collect()
res28: Array[org.apache.spark.sql.Row] = Array([das,2])
>>> df.where("age = 2").collect()
res29: Array[org.apache.spark.sql.Row] = Array([das,2])


//* first()
//Returns the first row as a Row.
>>> df.first()
//res30: org.apache.spark.sql.Row = [Alice,1]

//* map(f) , filter(f), reduce(f)
df.map{case Row(name:String, age:Int) => name }
//upper style not working 
df.filter{ r => r match{ case Row(name:String,age:Int) => name.size != 0 }}
//(Row,Row) => Row 
df.reduce{(r,e) => (r,e) match{case (Row(n:String,a:Int),Row(n1:String, a1:Int)) => Row(n+n1,a+a1) } }
//with typed 
case class Person(name:String, age:Int){
    def +(o:Person) = Person(name+o.name, age+o.age)
}
df.as[Person].map(_.name)
df.as[Person].filter(_.name.size != 0)
df.as[Person].reduce(_+_)
//* foreach(f)
//Applies the f function to all Row of this DataFrame.
//This is a shorthand for df.rdd.foreach().
scala> df.foreach(r => println(r))
[Alice,1]
[das,2]
>>> df.foreach{r => r match {case Row(name:String, age:Int) => println(name) } }
df.as[Person].foreach(p => println(p)) //Person 



//* foreachPartition(f)
//Applies the f function to each partition of this DataFrame.Note F takes Iterator 
//This a shorthand for df.rdd.foreachPartition().
scala> df.foreachPartition(Itr => println(Itr.toList))
List()
List()
List([das,2])
List([Alice,1])



//* groupBy(*cols)
//Groups the DataFrame using the specified columns, so we can run aggregation on them. 
//Returns RelationalGroupedDataset, groupby() is an alias for groupBy().
//cols – list of columns to group by. Each element should be a column name (string) or an expression (Column). 


df.groupBy().avg().collect()
res40: Array[org.apache.spark.sql.Row] = Array([1.5])
//for same name, what is mean age 
scala> df.groupBy("name").agg(Map("age" -> "mean")).collect.sortBy( row => row(0).asInstanceOf[String])
res43: Array[org.apache.spark.sql.Row] = Array([Alice,1.0], [das,2.0])

df.groupBy("name", "age").count().show()
+-----+---+-----+
| name|age|count|
+-----+---+-----+
|  das|  2|    1|
|Alice|  1|    1|
+-----+---+-----+



//* head(n=None)
//Returns the first n rows.

>>> df.head()
res45: org.apache.spark.sql.Row = [Alice,1]
>>> df.head(2)
res46: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])



//* join(other, on=None, how=None)
//Joins with another DataFrame, using the given join expression.
•other – Right side of the join
•on – a string for the join column name, a list of column names, a join expression (Column), or a list of Columns. If on is a string or a list of strings indicating the name of the join column(s), the column(s) must exist on both sides, and this performs an equi-join.
•how – str, default ‘inner’. One of inner, outer, left_outer, right_outer, leftsemi.
 

//full outer join between df1 and df2.(Note ===)
>>> df.join(df2, df("name") === df2("name"), "outer").select(df("name"), df2("age")).collect()
res47: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])



//* limit(num)
//Limits the result count to the number specified.

>>> df.limit(1).collect()
res48: Array[org.apache.spark.sql.Row] = Array([Alice,1])
>>> df.limit(0).collect()
[]


//* orderBy(*cols, **kwargs)
//Returns a new DataFrame sorted by the specified column(s).
//•ascending – boolean or list of boolean (default True). Sort ascending vs. descending. 
//Specify list for multiple sort orders. 
//If a list is specified, length of the list must equal length of the cols.
//* sort(*cols, **kwargs)
//Returns a new DataFrame sorted by the specified column(s).
//•ascending – boolean or list of boolean (default True). Sort ascending vs. descending. Specify list for multiple sort orders. If a list is specified, length of the list must equal length of the cols.


>>> df.sort($"age".desc).collect()
res52: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])

scala> df.sort(desc("age")).collect()  //desc, asc from functions 
res54: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])

>>> df.orderBy(df("age").desc).collect()
res57: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])

scala> df.orderBy(desc("age"), df("name")).collect()
res56: Array[org.apache.spark.sql.Row] = Array([das,2], [Alice,1])



//* randomSplit(weights, seed=None)
//Randomly splits this DataFrame with the provided weights.
•weights – list of doubles as weights with which to split the DataFrame. Weights will be normalized if they don’t sum up to 1.0.
•seed – The seed for sampling.
 
val splits = df.randomSplit(Array(1.0, 2.0), 24)   //1:2 splits 
scala> splits(0).show()
+-----+---+
| name|age|
+-----+---+
|Alice|  1|
+-----+---+


scala> splits(1).collect()
res59: Array[org.apache.spark.sql.Row] = Array([das,2])

//* rollup(*cols)
//Create a multi-dimensional rollup for the current DataFrame 
//using the specified columns, so we can run aggregation on them.
//returns RelationalGroupedDataset

>>> df.rollup("name", "age").count().orderBy("name", "age").show()
+-----+----+-----+
| name| age|count|
+-----+----+-----+
| null|null|    2|
|Alice|null|    1|
|Alice|   1|    1|
|  das|null|    1|
|  das|   2|    1|
+-----+----+-----+


//* select(*cols)
//cols – list of column names (string) or expressions (Column). 
//If one of the column names is ‘*’, that column is expanded to include all columns in the current DataFrame. 


>>> df.select("*").collect()
res60: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])
>>> df.select("name", "age").collect()
res61: Array[org.apache.spark.sql.Row] = Array([Alice,1], [das,2])
>>> df.select(df("name"), ($"age" + 10).alias("age_new")).collect()
res62: Array[org.apache.spark.sql.Row] = Array([Alice,11], [das,12])



//* selectExpr(*expr)
//This is a variant of select() that accepts SQL expressions.
>>> df.selectExpr("age * 2", "abs(age)").collect()
res63: Array[org.apache.spark.sql.Row] = Array([2,1], [4,2])



//* toJSON(use_unicode=True)
//Converts a DataFrame into a RDD of string.
//Each row is turned into a JSON document as one element in the returned RDD.

scala> df.toJSON.collect
res66: Array[String] = Array({"name":"Alice","age":1}, {"name":"das","age":2})


//* toLocalIterator()
//Returns an iterator that contains all of the rows in this DataFrame. The iterator will consume as much memory as the largest partition in this DataFrame.
import collection.JavaConversions._
println(List() ++ df.toLocalIterator())
List([Alice,1], [das,2])


//* withColumn(colName, col)
//Returns a new DataFrame by adding a column 
//or replacing the existing column that has the same name.
•colName – string, name of the new column.
•col – a Column expression for the new column.
 
scala> df.withColumn("age2", $"age" + 2).show()
+-----+---+----+
| name|age|age2|
+-----+---+----+
|Alice|  1|   3|
|  das|  2|   4|
+-----+---+----+


//* withColumnRenamed(existing, new)
//Returns a new DataFrame by renaming an existing column. 
•existing – string, name of the existing column to rename.
•col – string, new name of the column.
 
scala> df.withColumnRenamed("age", "age2").show()
+-----+----+
| name|age2|
+-----+----+
|Alice|   1|
|  das|   2|
+-----+----+




//*  DataFrameStatFunctions  
//returned from df.stat
approxQuantile(col, probabilities, relativeError)
corr(col1, col2, method=None)
cov(col1, col2)
crosstab(col1, col2)
freqItems(cols, support=None) //Finding frequent items for columns, possibly with false positives. Using the frequent element count algorithm described in “http://dx.doi.org/10.1145/762471.762473, proposed by Karp, Schenker, and Papadimitriou”. DataFrame.freqItems() and DataFrameStatFunctions.freqItems() are aliases.
sampleBy(col, fractions, seed=None)

//cols,col etc are string 
val peopleStat = people.stat 
peopleStat.crosstab("gender", "departId").show() //allretruns DF 



//* DataFrameNaFunctions  (check PY usage)
//returned by df.na 
val df4 = spark.read.json(raw"D:\Desktop\PPT\spark\data\people1.json")
df4.na.drop().show()
df4.na.drop().dropDuplicates().show()
df4.na.fill(50).show()
df4.na.fill(Map("age"-> 50, "name" -> "unknown", "height" -> 60)).show()






///Using sql.functions 
// http://spark.apache.org/docs/latest/api/scala/index.html#org.apache.spark.sql.functions$
//Note function operate on Column and returns a New Column 
//hence wherever Column is needed, you can use func(Column)

import org.apache.spark.sql.functions ._
import org.apache.spark.sql.types._ 

scala> spark.catalog.listFunctions.count
res1: Long = 251


//org.apache.spark.sql.functions.add_months(start, months) 
//Must be DateType which is java.sql.Date // Note TimestampType represents  java.sql.Timestamp values
//org.apache.spark.sql.functions.date_format(date, format)

//Using java.sql.Date.valueOf(String date) where date = yyyy-MM-dd 
import spark.implicits._ 

val schema = StructType(List(StructField("d", DateType, true))) //A date type, supporting "0001-01-01" through "9999-12-31".
val rows = sc.parallelize( Seq(Row( java.sql.Date.valueOf("2004-04-08")  ) ) )
val df = spark.createDataFrame(rows , schema )
df.select(add_months(df("d"), 1).alias("added")).collect()
df.select(date_format($"d", "MM/dd/yyy").alias("formatedDate")).collect()


//org.apache.spark.sql.functions.array_contains(col, value)
val schema = StructType(Array(  StructField("data", ArrayType(StringType, false ), true)  )   )
val rows = sc.parallelize( Seq( Row(Array( "a", "b", "c")) , Row(Array.empty[String])  ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(array_contains(df("data"), "a").alias("DoesA") ).collect()
//Array([true], [false])


//org.apache.spark.sql.functions.concat_ws(sep, *cols)
//Concatenates multiple input string columns together into a single string column, 
//using the given separator.
val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )
val rows = sc.parallelize( Seq( Row("abcd","123")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(concat_ws("-", df("s"), df("d")).alias("sd") ).show() //or collect() to get whole dataframe 



//org.apache.spark.sql.functions.corr(col1, col2)
//Returns a new Column for the Pearson Correlation Coefficient for col1 and col2.
val schema = StructType(Array(  StructField("a", IntegerType, true) ,StructField("b", IntegerType, true) )   )
val a = (1 to 20).toSeq
val b = (1 to 20).toList.map( _ * 2).toSeq
val rows = sc.parallelize( a.zip(b).map( t => Row(t._1,t._2) ).toSeq ) 
val df = spark.createDataFrame(rows , schema )
df.agg(corr("a", "b").alias("c")).collect()  //Array([1.0])


//org.apache.spark.sql.functions.countDistinct(col, *cols)
//Returns a new Column for distinct count of col or cols.
df.agg(countDistinct(df("a"), df("b")).alias("c")).collect()  //Array([20])
df.agg(countDistinct("a", "b").alias("c")).collect()



//org.apache.spark.sql.functions.expr(str)
//Parses the expression string into the column that it represents
val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )
val rows = sc.parallelize( Seq( Row("abcd","123")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(expr("length(s)")).collect() //Array([4])




//org.apache.spark.sql.functions.format_string(format, *cols)
//Formats the arguments in printf-style and returns the result as a string column.
val schema = StructType(Array(  StructField("a", IntegerType, true) ,StructField("b", StringType, true) )   )
val rows = sc.parallelize( Seq( Row(5,"hello")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(format_string("%d %s", df("a"), df("b")).alias("v")).collect()



//org.apache.spark.sql.functions.grouping(col)
//Aggregate function: indicates whether a specified column in a GROUP BY list is aggregated or not, 
//returns 1 for aggregated or 0 for not aggregated in the result set.
// cube() returns RelationalGroupedDataset 
val df = spark.read.json(raw"D:\Desktop\PPT\spark\data\peopledepart.json")
df.cube("name").agg(grouping("name"), sum("age")).orderBy("name").show()



//org.apache.spark.sql.functions.instr(str, substr)
//Locate the position of the first occurrence of substr column in the given string. Returns null if either of the arguments are null.
//org.apache.spark.sql.functions.substring(str, pos, len)
val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )
val rows = sc.parallelize( Seq( Row("abcd","123") ,Row("abcd","123")  ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(instr(df("s"), "b").alias("sd")).collect() // Array([2])
df.select(substring(df("s"), 1, 2).alias("sub")).collect() 
//res89: Array[org.apache.spark.sql.Row] = Array([ab], [ab])


//org.apache.spark.sql.functions.length(col)
//Calculates the length of a string or binary expression.
val schema = StructType(Array(  StructField("s", StringType, true) ,StructField("d", StringType, true) )   )
val rows = sc.parallelize( Seq( Row("abcd","123")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(length(col("s")) ).collect() //Array([4])



//org.apache.spark.sql.functions.nanvl(col1, col2)
//Returns col1 if it is not NaN, or col2 if col1 is NaN.
//Both inputs should be floating point columns (DoubleType or FloatType).
val schema = StructType(Array(  StructField("a", DoubleType, true) ,StructField("b", DoubleType, true) )   )
val rows = sc.parallelize( Seq( Row( 1.0, Double.NaN), Row(  Double.NaN, 2.0)   ) ) 
val df = spark.createDataFrame(rows , schema )

df.select(nanvl(df("a"), df("b")).alias("r2")).collect() // Array([1.0], [2.0])


//org.apache.spark.sql.functions.regexp_extract(str, pattern, idx)
//Extract a specific group matched by a Java regex, from the specified string column. If the regex did not match, or the specified group did not match, an empty string is returned.
//*org.apache.spark.sql.functions.regexp_replace(str, pattern, replacement)
//*org.apache.spark.sql.functions.split(str, pattern)
val schema = StructType(Array(  StructField("str", StringType, true) ,StructField("dtr", StringType, true) )   )
val rows = sc.parallelize( Seq( Row("100-200","100-200")   ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(regexp_extract(col("str"), raw"(\d+)-(\d+)", 1).alias("d")).collect() //Array([100])
df.select(regexp_replace(col("str"), raw"(\d+)", "--").alias("d")).collect() // Array([-----])
df.select(split(col("str"), raw"[0-9]+").alias("s")).collect() //Array([WrappedArray(, -, )])



//org.apache.spark.sql.functions.repeat(col, n)
//Repeats a string column n times, and returns it as a new string column.
df.select(repeat(df("str"), 3).alias("s")).collect() //Array([100-200100-200100-200])


//org.apache.spark.sql.functions.size(col)
//Collection function: returns the length of the array or map stored in the column.
//org.apache.spark.sql.functions.sort_array(col, asc=True)
val schema = StructType(Array(  StructField("data", ArrayType(StringType, false ), true)  )   )
val rows = sc.parallelize( Seq( Row(Array( "a", "b", "c")) , Row(Array.empty[String])  ) ) 
val df = spark.createDataFrame(rows , schema )
df.select(size(df("data"))).collect()//Array([3], [0])
df.select(sort_array(df("data"), asc=false).alias("r")).collect() //Array([WrappedArray(c, b, a)]







///cast Operator
//cast method casts a column to a data type. 
//It makes for type-safe maps with Row objects of the proper type (not Any).
cast(to: String): Column
cast(to: DataType): Column


scala> val df = Seq((0f, "hello")).toDF("label", "text")
df: org.apache.spark.sql.DataFrame = [label: float, text: string]

scala> df.printSchema
root
 |-- label: float (nullable = false)
 |-- text: string (nullable = true)

// without cast
import org.apache.spark.sql.Row
scala> df.select("label").map { case Row(label) => label.getClass.getName }.show(false)
+---------------+
|value          |
+---------------+
|java.lang.Float|
+---------------+

// with cast
import org.apache.spark.sql.types.DoubleType
scala> df.select(col("label").cast(DoubleType)).map { case Row(label) => label.getClass.getName }.show(false)
+----------------+
|value           |
+----------------+
|java.lang.Double|
+----------------+

///Defining UDFs—udf Function
udf(f: FunctionN[...]): UserDefinedFunction
//The udf family of functions allows you to create user-defined functions (UDFs) 
// based on a user-defined function in Scala. 
// It accepts f function of 0 to 10 arguments and the input 
// and output types are automatically inferred (given the types of the respective input and output types of the function f).

import org.apache.spark.sql.functions._
val _length: String => Int = _.length
val _lengthUDF = udf(_length)

// define a dataframe
val df = sc.parallelize(0 to 3).toDF("num")

// apply the user-defined function to "num" column
scala> df.withColumn("len", _lengthUDF($"num")).show
+---+---+
|num|len|
+---+---+
|  0|  1|
|  1|  1|
|  2|  1|
|  3|  1|
+---+---+

//Since Spark 2.0.0, there is another variant of udf function:
udf(f: AnyRef, dataType: DataType): UserDefinedFunction
//udf(f: AnyRef, dataType: DataType) allows you to use a Scala closure 
//for the function argument (as f) and explicitly declaring the output data type (as dataType).

// given the dataframe above
import org.apache.spark.sql.types.IntegerType
val byTwo = udf((n: Int) => n * 2, IntegerType)

scala> df.withColumn("len", byTwo($"num")).show
+---+---+
|num|len|
+---+---+
|  0|  0|
|  1|  2|
|  2|  4|
|  3|  6|
+---+---+


///Current Date As Date Column—current_date Function
current_date(): Column
//current_date function gives the current date as a date column.

val df = spark.range(1).select(current_date)
scala> df.show
+--------------+
|current_date()|
+--------------+
|    2017-09-16|
+--------------+

scala> df.printSchema
root
 |-- current_date(): date (nullable = false)

///date_format Function
date_format(dateExpr: Column, format: String): Column
//date_format creates a Column with DateFormatClass binary expression. 
//DateFormatClass takes the expression from dateExpr column and format.

val c = date_format($"date", "dd/MM/yyyy")

import org.apache.spark.sql.catalyst.expressions.DateFormatClass
val dfc = c.expr.asInstanceOf[DateFormatClass]
scala> println(dfc.prettyName)
date_format

scala> println(dfc.numberedTreeString)
00 date_format('date, dd/MM/yyyy, None)
01 :- 'date
02 +- dd/MM/yyyy

///current_timestamp Function
current_timestamp(): Column
//current_timestamp is also now function in SQL.


///to_date Function
to_date(e: Column, fmt: String): Column
to_timestamp(s: Column): Column
to_timestamp(s: Column, fmt: String): Column

///Converting Current or Specified Time to Unix Timestamp—unix_timestamp Function
unix_timestamp(): Column  (1)
unix_timestamp(time: Column): Column (2)
unix_timestamp(time: Column, format: String): Column
//Gives current timestamp (in seconds)
//Converts time string in format yyyy-MM-dd HH:mm:ss to Unix timestamp (in seconds)
//unix_timestamp converts the current or specified time in the specified format 
//to a Unix timestamp (in seconds).

//unix_timestamp supports a column of type Date, Timestamp or String.

// no time and format => current time
scala> spark.range(1).select(unix_timestamp as "current_timestamp").show
+-----------------+
|current_timestamp|
+-----------------+
|       1493362850|
+-----------------+

// no format so yyyy-MM-dd HH:mm:ss assumed
scala> Seq("2017-01-01 00:00:00").toDF("time").withColumn("unix_timestamp", unix_timestamp($"time")).show
+-------------------+--------------+
|               time|unix_timestamp|
+-------------------+--------------+
|2017-01-01 00:00:00|    1483225200|
+-------------------+--------------+

scala> Seq("2017/01/01 00:00:00").toDF("time").withColumn("unix_timestamp", unix_timestamp($"time", "yyyy/MM/dd")).show
+-------------------+--------------+
|               time|unix_timestamp|
+-------------------+--------------+
|2017/01/01 00:00:00|    1483225200|
+-------------------+--------------+

unix_timestamp returns null if conversion fails.

// note slashes as date separators
scala> Seq("2017/01/01 00:00:00").toDF("time").withColumn("unix_timestamp", unix_timestamp($"time")).show
+-------------------+--------------+
|               time|unix_timestamp|
+-------------------+--------------+
|2017/01/01 00:00:00|          null|
+-------------------+--------------+

	

//unix_timestamp is also supported in SQL mode.

scala> spark.sql("SELECT unix_timestamp() as unix_timestamp").show
+--------------+
|unix_timestamp|
+--------------+
|    1493369225|
+--------------+

///Generating Time Windows—window Function
window(
  timeColumn: Column,
  windowDuration: String): Column  
window(
  timeColumn: Column,
  windowDuration: String,
  slideDuration: String): Column   
window(
  timeColumn: Column,
  windowDuration: String,
  slideDuration: String,
  startTime: String): Column       

//    Creates a tumbling time window with slideDuration as windowDuration and 0 second for startTime
//    Creates a sliding time window with 0 second for startTime
//    Creates a delayed time window
//window generates tumbling, sliding or delayed time windows of windowDuration duration 
//given a timeColumn timestamp specifying column.
//Tumbling windows are a series of fixed-sized, non-overlapping and contiguous time intervals.

//windowDuration and slideDuration are strings specifying the width of the window 
//for duration and sliding identifiers, respectively.

scala> val timeColumn = window('time, "5 seconds")    //'
timeColumn: org.apache.spark.sql.Column = timewindow(time, 5000000, 5000000, 0) AS `window`

//timeColumn should be of TimestampType, i.e. with java.sql.Timestamp values.
//Use java.sql.Timestamp.from or java.sql.Timestamp.valueOf factory methods to create Timestamp instances.
// https://docs.oracle.com/javase/8/docs/api/java/time/LocalDateTime.html
import java.time.LocalDateTime
// https://docs.oracle.com/javase/8/docs/api/java/sql/Timestamp.html
import java.sql.Timestamp
val levels = Seq(
  // (year, month, dayOfMonth, hour, minute, second)
  ((2012, 12, 12, 12, 12, 12), 5),
  ((2012, 12, 12, 12, 12, 14), 9),
  ((2012, 12, 12, 13, 13, 14), 4),
  ((2016, 8,  13, 0, 0, 0), 10),
  ((2017, 5,  27, 0, 0, 0), 15)).
  map { case ((yy, mm, dd, h, m, s), a) => (LocalDateTime.of(yy, mm, dd, h, m, s), a) }.
  map { case (ts, a) => (Timestamp.valueOf(ts), a) }.
  toDF("time", "level")
scala> levels.show
+-------------------+-----+
|               time|level|
+-------------------+-----+
|2012-12-12 12:12:12|    5|
|2012-12-12 12:12:14|    9|
|2012-12-12 13:13:14|    4|
|2016-08-13 00:00:00|   10|
|2017-05-27 00:00:00|   15|
+-------------------+-----+

val q = levels.select(window($"time", "5 seconds"), $"level")
scala> q.show(truncate = false)
+---------------------------------------------+-----+
|window                                       |level|
+---------------------------------------------+-----+
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|5    |
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|9    |
|[2012-12-12 13:13:10.0,2012-12-12 13:13:15.0]|4    |
|[2016-08-13 00:00:00.0,2016-08-13 00:00:05.0]|10   |
|[2017-05-27 00:00:00.0,2017-05-27 00:00:05.0]|15   |
+---------------------------------------------+-----+

scala> q.printSchema
root
 |-- window: struct (nullable = true)
 |    |-- start: timestamp (nullable = true)
 |    |-- end: timestamp (nullable = true)
 |-- level: integer (nullable = false)

// calculating the sum of levels every 5 seconds
val sums = levels.
  groupBy(window($"time", "5 seconds")).
  agg(sum("level") as "level_sum").
  select("window.start", "window.end", "level_sum")
scala> sums.show
+-------------------+-------------------+---------+
|              start|                end|level_sum|
+-------------------+-------------------+---------+
|2012-12-12 13:13:10|2012-12-12 13:13:15|        4|
|2012-12-12 12:12:10|2012-12-12 12:12:15|       14|
|2016-08-13 00:00:00|2016-08-13 00:00:05|       10|
|2017-05-27 00:00:00|2017-05-27 00:00:05|       15|
+-------------------+-------------------+---------+




//Internally, window creates a Column (with TimeWindow expression) available as window alias.

// q is the query defined earlier
scala> q.show(truncate = false)
+---------------------------------------------+-----+
|window                                       |level|
+---------------------------------------------+-----+
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|5    |
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|9    |
|[2012-12-12 13:13:10.0,2012-12-12 13:13:15.0]|4    |
|[2016-08-13 00:00:00.0,2016-08-13 00:00:05.0]|10   |
|[2017-05-27 00:00:00.0,2017-05-27 00:00:05.0]|15   |
+---------------------------------------------+-----+

scala> println(timeColumn.expr.numberedTreeString)
00 timewindow('time, 5000000, 5000000, 0) AS window#22
01 +- timewindow('time, 5000000, 5000000, 0)
02    +- 'time   //'


//Another example 
import spark.implicits._ 
import org.apache.spark.sql.functions ._
import org.apache.spark.sql.types._ 
import org.apache.spark.sql._

val schema = StructType(List(StructField("data", TimestampType, true),  //format yyyy-[m]m-[d]d hh:mm:ss[.f...]. 
                            StructField("val", IntegerType, true))) //A date type, supporting "0001-01-01" through "9999-12-31".

val rows = sc.parallelize( Seq(Row( java.sql.Timestamp.valueOf("2016-03-11 09:00:07"), 1  ),
                               Row( java.sql.Timestamp.valueOf("2016-03-11 09:00:14"), 2  )   ) )


val df = spark.createDataFrame(rows , schema )
val w = df.groupBy(window($"data", "5 seconds")).agg(sum($"val").alias("sum"))
//w: org.apache.spark.sql.DataFrame = [window: struct<start: timestamp,end: timestamp>, sum: bigint]

w.select(w("window")("start").cast("string").alias("start"),
          w("window")("end").cast("string").alias("end"), w("sum")).collect()
          
//res5: Array[org.apache.spark.sql.Row] = Array([2016-03-11 09:00:05,2016-03-11 09:00:10,1], [2016-03-11 09:00:10,2016-03-11 09:00:15,2])

w.select(w("window")("start").cast("string").alias("start"),
          w("window")("end").cast("string").alias("end"), w("sum")).show()
+-------------------+-------------------+---+
|              start|                end|sum|
+-------------------+-------------------+---+
|2016-03-11 09:00:05|2016-03-11 09:00:10|  1|
|2016-03-11 09:00:10|2016-03-11 09:00:15|  2|
+-------------------+-------------------+---+



///+++ Window Aggregation Functions
//perform a calculation over a group of records called window 
    // ranking functions  - rank,dense_rank,percent_rank,ntile,row_number
    // analytic functions - cume_dist,lag,lead
    // aggregate functions

///For aggregate functions, you can use the existing aggregate functions as window functions, 
//e.g. sum, avg, min, max and count.


case class Salary(depName: String, empNo: Long, salary: Long)
val empsalary = Seq(
  Salary("sales", 1, 5000),
  Salary("personnel", 2, 3900),
  Salary("sales", 3, 4800),
  Salary("sales", 4, 4800),
  Salary("personnel", 5, 3500),
  Salary("develop", 7, 4200),
  Salary("develop", 8, 6000),
  Salary("develop", 9, 4500),
  Salary("develop", 10, 5200),
  Salary("develop", 11, 5200)).toDS

import org.apache.spark.sql.expressions.Window
// Windows are partitions of deptName
scala> val byDepName = Window.partitionBy('depName)
byDepName: org.apache.spark.sql.expressions.WindowSpec = org.apache.spark.sql.expressions.WindowSpec@1a711314

scala> empsalary.withColumn("avg", avg('salary) over byDepName).show
+---------+-----+------+-----------------+
|  depName|empNo|salary|              avg|
+---------+-----+------+-----------------+
|  develop|    7|  4200|           5020.0|
|  develop|    8|  6000|           5020.0|
|  develop|    9|  4500|           5020.0|
|  develop|   10|  5200|           5020.0|
|  develop|   11|  5200|           5020.0|
|    sales|    1|  5000|4866.666666666667|
|    sales|    3|  4800|4866.666666666667|
|    sales|    4|  4800|4866.666666666667|
|personnel|    2|  3900|           3700.0|
|personnel|    5|  3500|           3700.0|
+---------+-----+------+-----------------+


///WindowSpec—Window Specification
import org.apache.spark.sql.expressions.Window

scala> val byHTokens = Window.partitionBy('token startsWith "h")  //'
byHTokens: org.apache.spark.sql.expressions.WindowSpec = org.apache.spark.sql.expressions.WindowSpec@574985d8

val tokens = Seq("hello", "henry", "and", "harry")
  .zipWithIndex
  .map(_.swap)
  .toDF("id", "token")
  
// count the sum of ids in each group
val result = tokens.select('*, sum('id) over byHTokens as "sum over h tokens").orderBy('id) //'

scala> .show
+---+-----+-----------------+
| id|token|sum over h tokens|
+---+-----+-----------------+
|  0|hello|                4|
|  1|henry|                4|
|  2|  and|                2|
|  3|harry|                4|
+---+-----+-----------------+

///Ordering in Windows—orderBy Methods


import org.apache.spark.sql.expressions.Window
val byDepnameSalaryDesc = Window.partitionBy('depname).orderBy('salary desc)

// a numerical rank within the current row's partition for each distinct ORDER BY value
scala> val rankByDepname = rank().over(byDepnameSalaryDesc)
rankByDepname: org.apache.spark.sql.Column = RANK() OVER (PARTITION BY depname ORDER BY salary DESC UnspecifiedFrame)

scala> empsalary.select('*, rankByDepname as 'rank).show
+---------+-----+------+----+
|  depName|empNo|salary|rank|
+---------+-----+------+----+
|  develop|    8|  6000|   1|
|  develop|   10|  5200|   2|
|  develop|   11|  5200|   2|
|  develop|    9|  4500|   4|
|  develop|    7|  4200|   5|
|    sales|    1|  5000|   1|
|    sales|    3|  4800|   2|
|    sales|    4|  4800|   2|
|personnel|    2|  3900|   1|
|personnel|    5|  3500|   2|
+---------+-----+------+----+

///rangeBetween Method
rangeBetween(start: Long, end: Long): WindowSpec
//Window.unboundedPreceding, Window.unboundedFollowing and Window.currentRow 

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.expressions.WindowSpec
val spec: WindowSpec = Window.rangeBetween(Window.unboundedPreceding, Window.currentRow)

// PARTITION BY country ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
Window.partitionBy('country).orderBy('date).rowsBetween(Long.MinValue, 0)
// PARTITION BY country ORDER BY date ROWS BETWEEN 3 PRECEDING AND 3 FOLLOWING
Window.partitionBy('country).orderBy('date).rowsBetween(-3, 3)

//Types of boundaries (two positions and three offsets):
    UNBOUNDED PRECEDING - the first row of the partition
    UNBOUNDED FOLLOWING - the last row of the partition
    CURRENT ROW
    <value> PRECEDING
    <value> FOLLOWING

//Offsets specify the offset from the current input row.
//Types of frames:
    ROW - based on physical offsets from the position of the current input row
    RANGE - based on logical offsets from the position of the current input row

//you can use two methods to define a frame:
    rowsBetween
    rangeBetween

//Window frame definition is simply not supported by Hive 

//Another issue , Only orderBy does not work 
wSpec = Window.orderBy(df.a)
df.select(df.a, func.rank().over(wSpec).alias("rank"))

//you can make it work by changing window definition to this:
wSpec = Window.partitionBy().orderBy(df.a)
    
    
///Window Operators in SQL Queries
//The grammar of windows operators in SQL accepts the following:
    CLUSTER BY or PARTITION BY or DISTRIBUTE BY for partitions,
    ORDER BY or SORT BY for sorting order,
    RANGE, ROWS, RANGE BETWEEN, and ROWS BETWEEN for window frame types,
    UNBOUNDED PRECEDING, UNBOUNDED FOLLOWING, CURRENT ROW for frame bounds.

///Examples -Top N per Group
//Top N per Group is useful when you need to compute the first and second best-sellers in category.
//Question: What are the best-selling and the second best-selling products in every category

val data = Seq(
  ("Thin",       "cell phone", 6000),
  ("Normal",     "tablet",     1500),
  ("Mini",       "tablet",     5500),
  ("Ultra thin", "cell phone", 5000),
  ("Very thin",  "cell phone", 6000),
  ("Big",        "tablet",     2500),
  ("Bendable",   "cell phone", 3000),
  ("Foldable",   "cell phone", 3000),
  ("Pro",        "tablet",     4500),
  ("Pro2",       "tablet",     6500))
  .toDF("product", "category", "revenue")

scala> data.show
+----------+----------+-------+
|   product|  category|revenue|
+----------+----------+-------+
|      Thin|cell phone|   6000|
|    Normal|    tablet|   1500|
|      Mini|    tablet|   5500|
|Ultra thin|cell phone|   5000|
| Very thin|cell phone|   6000|
|       Big|    tablet|   2500|
|  Bendable|cell phone|   3000|
|  Foldable|cell phone|   3000|
|       Pro|    tablet|   4500|
|      Pro2|    tablet|   6500|
+----------+----------+-------+

scala> data.where('category === "tablet").show  //'
+-------+--------+-------+
|product|category|revenue|
+-------+--------+-------+
| Normal|  tablet|   1500|
|   Mini|  tablet|   5500|
|    Big|  tablet|   2500|
|    Pro|  tablet|   4500|
|   Pro2|  tablet|   6500|
+-------+--------+-------+

//The question boils down to ranking products in a category 
//based on their revenue, and to pick the best selling and the second best-selling products 
//based the ranking.

import org.apache.spark.sql.expressions.Window
val overCategory = Window.partitionBy('category).orderBy('revenue.desc)

val ranked = data.withColumn("rank", dense_rank.over(overCategory))

scala> ranked.show
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|       Pro|    tablet|   4500|   3|
|       Big|    tablet|   2500|   4|
|    Normal|    tablet|   1500|   5|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
|  Bendable|cell phone|   3000|   3|
|  Foldable|cell phone|   3000|   3|
+----------+----------+-------+----+

scala> ranked.where('rank <= 2).show  //'
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
+----------+----------+-------+----+

///Revenue Difference per Category
import org.apache.spark.sql.expressions.Window
val reveDesc = Window.partitionBy('category).orderBy('revenue.desc)
val reveDiff = max('revenue).over(reveDesc) - 'revenue

scala> data.select('*, reveDiff as 'revenue_diff).show
+----------+----------+-------+------------+
|   product|  category|revenue|revenue_diff|
+----------+----------+-------+------------+
|      Pro2|    tablet|   6500|           0|
|      Mini|    tablet|   5500|        1000|
|       Pro|    tablet|   4500|        2000|
|       Big|    tablet|   2500|        4000|
|    Normal|    tablet|   1500|        5000|
|      Thin|cell phone|   6000|           0|
| Very thin|cell phone|   6000|           0|
|Ultra thin|cell phone|   5000|        1000|
|  Bendable|cell phone|   3000|        3000|
|  Foldable|cell phone|   3000|        3000|
+----------+----------+-------+------------+

///Difference on Column
//Compute a difference between values in rows in a column.

val pairs = for {
  x <- 1 to 5
  y <- 1 to 2
} yield (x, 10 * x * y)
val ds = pairs.toDF("ns", "tens")

scala> ds.show
+---+----+
| ns|tens|
+---+----+
|  1|  10|
|  1|  20|
|  2|  20|
|  2|  40|
|  3|  30|
|  3|  60|
|  4|  40|
|  4|  80|
|  5|  50|
|  5| 100|
+---+----+

import org.apache.spark.sql.expressions.Window
val overNs = Window.partitionBy('ns).orderBy('tens)
val diff = lead('tens, 1).over(overNs)

scala> ds.withColumn("diff", diff - 'tens).show
+---+----+----+
| ns|tens|diff|
+---+----+----+
|  1|  10|  10|
|  1|  20|null|
|  3|  30|  30|
|  3|  60|null|
|  5|  50|  50|
|  5| 100|null|
|  4|  40|  40|
|  4|  80|null|
|  2|  20|  20|
|  2|  40|null|
+---+----+----+

///Running Total
//The running total is the sum of all previous lines including the current one.

val sales = Seq(
  (0, 0, 0, 5),
  (1, 0, 1, 3),
  (2, 0, 2, 1),
  (3, 1, 0, 2),
  (4, 2, 0, 8),
  (5, 2, 2, 8))
  .toDF("id", "orderID", "prodID", "orderQty")

scala> sales.show
+---+-------+------+--------+
| id|orderID|prodID|orderQty|
+---+-------+------+--------+
|  0|      0|     0|       5|
|  1|      0|     1|       3|
|  2|      0|     2|       1|
|  3|      1|     0|       2|
|  4|      2|     0|       8|
|  5|      2|     2|       8|
+---+-------+------+--------+

val orderedByID = Window.orderBy('id)

val totalQty = sum('orderQty).over(orderedByID).as('running_total)
val salesTotalQty = sales.select('*, totalQty).orderBy('id)

scala> salesTotalQty.show
16/04/10 23:01:52 WARN Window: No Partition Defined for Window operation! Moving all data to a single partition, this can cause serious performance degradation.
+---+-------+------+--------+-------------+
| id|orderID|prodID|orderQty|running_total|
+---+-------+------+--------+-------------+
|  0|      0|     0|       5|            5|
|  1|      0|     1|       3|            8|
|  2|      0|     2|       1|            9|
|  3|      1|     0|       2|           11|
|  4|      2|     0|       8|           19|
|  5|      2|     2|       8|           27|
+---+-------+------+--------+-------------+

val byOrderId = orderedByID.partitionBy('orderID)
val totalQtyPerOrder = sum('orderQty).over(byOrderId).as('running_total_per_order)
val salesTotalQtyPerOrder = sales.select('*, totalQtyPerOrder).orderBy('id)

scala> salesTotalQtyPerOrder.show
+---+-------+------+--------+-----------------------+
| id|orderID|prodID|orderQty|running_total_per_order|
+---+-------+------+--------+-----------------------+
|  0|      0|     0|       5|                      5|
|  1|      0|     1|       3|                      8|
|  2|      0|     2|       1|                      9|
|  3|      1|     0|       2|                      2|
|  4|      2|     0|       8|                      8|
|  5|      2|     2|       8|                     16|
+---+-------+------+--------+-----------------------+







///+++ Spark SQL Options - 78 options 
//https://spark.apache.org/docs/latest/configuration.html
spark.sql("SET -v").show(n=200, truncate=false) //DataFrame[key: string, value: string, meaning: string]
>>> spark.sql("SET -v").select("key").show(truncate=false)
+-----------------------------------------------------+
|key                                                  |
+-----------------------------------------------------+
|spark.sql.adaptive.enabled                           |
|spark.sql.adaptive.shuffle.targetPostShuffleInputSize|
|spark.sql.autoBroadcastJoinThreshold                 |
|spark.sql.broadcastTimeout                           |
|spark.sql.cbo.enabled                                |






///+++WinnersCurse example 
val lines =sc.textFile(raw"D:\Desktop\PPT\spark\data\Cartier+for+WinnersCurse.csv")
val headers = lines.first

import org.apache.spark.sql.types._

val fs = headers.split(",").map(f => StructField(f, StringType))
//fs: Array[org.apache.spark.sql.types.StructField] = Array(StructField(auctionid,StringType,true), StructField(bid,StringType,true), StructField(bidtime,StringType,true), StructField(bidder,StringType,true), StructField(bidderrate,StringType,true), StructField(openbid,StringType,true), StructField(price,StringType,true))

val schema = StructType(fs)

val noheaders = lines.filter(_ != headers)
noheaders: org.apache.spark.rdd.RDD[String] = MapPartitionsRDD[10] at filter at <console>:33

>>> val rows = noheaders.map(_.split(",")).map(a => Row.fromSeq(a))
rows: org.apache.spark.rdd.RDD[org.apache.spark.sql.Row] = MapPartitionsRDD[12] at map at <console>:35

>>> val auctions = spark.createDataFrame(rows, schema)
auctions: org.apache.spark.sql.DataFrame = [auctionid: string, bid: string, bidtime: string, bidder: string, bidderrate: string, openbid: string, price: string]

>>> auctions.printSchema
root
 |-- auctionid: string (nullable = true)
 |-- bid: string (nullable = true)
 |-- bidtime: string (nullable = true)
 |-- bidder: string (nullable = true)
 |-- bidderrate: string (nullable = true)
 |-- openbid: string (nullable = true)
 |-- price: string (nullable = true)

>>> auctions.dtypes
res28: Array[(String, String)] = Array((auctionid,StringType), (bid,StringType), (bidtime,StringType), (bidder,StringType), (bidderrate,StringType), (openbid,StringType), (price,StringType))

>>> auctions.show(5)


///Creating DataFrame from CSV file
>>> val header = lines.first
header: String = auctionid,bid,bidtime,bidder,bidderrate,openbid,price

>>> lines.count
res3: Long = 1349

>>> case class Auction(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate: Int, openbid: Float, price: Float)
defined class Auction

>>> val noheader = lines.filter(_ != header)
noheader: org.apache.spark.rdd.RDD[String] = MapPartitionsRDD[53] at filter at <console>:31

//get Row 
>>> val auctions = noheader.map(_.split(",")).map(r => Auction(r(0), r(1).toFloat, r(2).toFloat, r(3), r(4).toInt, r(5).toFloat, r(6).toFloat))
auctions: org.apache.spark.rdd.RDD[Auction] = MapPartitionsRDD[59] at map at <console>:35

>>> val df = auctions.toDF
df: org.apache.spark.sql.DataFrame = [auctionid: string, bid: float, bidtime: float, bidder: string, bidderrate: int, openbid: float, price: float]

df.show

///Creating DataFrame from CSV files using spark-csv module
//Support for CSV data sources is available by default in Spark 2.0.0. No need for an external module.

>>> val df = spark.read.format("csv").option("header", "true").load(raw"D:\Desktop\PPT\spark\data\Cartier+for+WinnersCurse.csv")
df: org.apache.spark.sql.DataFrame = [auctionid: string, bid: string, bidtime: string, bidder: string, bidderrate: string, openbid: string, price: string]

>>> df.printSchema
>>> df.show

///Querying DataFrame
>>> auctions.groupBy("bidder").count().show(5)
>>> auctions.groupBy("bidder").count().sort($"count".desc).show(5)

import org.apache.spark.sql.functions._

>>> auctions.groupBy("bidder").count().sort(desc("count")).show(5)
>>> df.select("auctionid").distinct.count
>>> df.groupBy("bidder").count.show

///Using SQL
df.registerTempTable("auctions") 
>>> val sql = spark.sql("SELECT count(*) AS count FROM auctions")
sql: org.apache.spark.sql.DataFrame = [count: bigint]

//before the query is executed it is optimized by Catalyst query optimizer. 
//You can print the physical plan for a DataFrame using the explain operation.
>>> sql.explain
>>> sql.show

>>> val count = sql.collect()(0).getLong(0)
count: Long = 1348

//Filtering
auctions.filter(F.col("bidder").like("c%")).show()
auctions.filter('bidder like "c%"').show()








///+++iris example 
val iris =spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\iris.csv")
iris.show(5)
>>> iris.dtypes
res109: Array[(String, String)] = Array((SepalLength,DoubleType), (SepalWidth,DoubleType), (PetalLength,DoubleType), (PetalWidth,DoubleType), (Name,StringType))

 
//Return new DF 
>>> val iris1 = iris.withColumn("sepal_ratio" , round(iris("SepalWidth") / iris("SepalLength"), 2) )
-----------+----------+-----------+----------+-----------+-----------+
SepalLength|SepalWidth|PetalLength|PetalWidth|       Name|sepal_ratio|
-----------+----------+-----------+----------+-----------+-----------+
        5.1|       3.5|        1.4|       0.2|Iris-setosa|       0.69|
        4.9|       3.0|        1.4|       0.2|Iris-setosa|       0.61|

//Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:
iris.filter("SepalLength > 5 AND SepalLength < 5.2").show()
iris.filter((col("SepalLength") > 5) && ($"SepalLength" < 5.2) ).show()
iris.filter('SepalLength.between(5.01,5.1) ).show()  #'


iris.filter("SepalLength > 5").withColumn("SepalRatio", col("SepalWidth") / iris("SepalLength")).
    withColumn("PetalRatio" , $"PetalWidth" / 'PetalLength)  //'
    


//CIf ploted learly two clusters 
val iris_m =iris.filter("SepalLength > 5").withColumn("SepalRatio", col("SepalWidth") / iris("SepalLength")).
    withColumn("PetalRatio" , $"PetalWidth" / $"PetalLength")

    
    
//Quick K-Means - Find those two clusters 

import org.apache.spark.mllib.clustering.{KMeans, KMeansModel}

iris_m.select(array(round($"SepalRatio",2),round($"PetalRatio",2)).alias("features")).show()
val parsedData =iris_m.select(array(round($"SepalRatio",2), round($"PetalRatio",2)).alias("features"))
//org.apache.spark.sql.DataFrame = [features: array<double>]

val Array(trainData, testData) = parsedData.randomSplit(Array(3.0,1.0), seed=34)

// Build the model (cluster the data), MLIB only takes LabeledPoint(label,Vector_as_features) or Vector for unsupervised learning
//Vectors.dense takes Array[Double] or var args Double 
//train(data: RDD[Vector], k: Int, maxIterations: Int, initializationMode: String)
// k=2, maxIterations=10, initializationMode="random"
val clusters =KMeans.train(trainData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)) , 2,10, "random")

>>> clusters.clusterCenters
res18: Array[org.apache.spark.mllib.linalg.Vector] = Array([0.6938888888888889,0.19166666666666668], [0.4597142857142855,0.3385714285714285])

val predictedRDD =clusters.predict(testData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)))
//org.apache.spark.rdd.RDD[Int]

// Evaluate clustering by computing Within Set Sum of Squared Errors
val WSSSE = clusters.computeCost(testData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)))
println(s"Within Set Sum of Squared Errors = $WSSSE")
val WSSSE = clusters.computeCost(trainData.rdd.map(row => Vectors.dense(row.getSeq[Double](0).toArray)))
println(s"Within Set Sum of Squared Errors = $WSSSE")



// Save and load model
clusters.save(sc, "KMeansModel")
val sameModel =KMeansModel.load(sc, "KMeansModel")


//OR Use VectorAssembler to convert to org.apache.spark.ml.linalg.DenseVector 
//
val parsedData =iris_m.select(round($"SepalRatio",2).alias("sr"),round($"PetalRatio",2).alias("pr"))
val assembler = new VectorAssembler().setInputCols(Array("pr", "sr")).setOutputCol("features")
val out =assembler.transform(parsedData)//org.apache.spark.sql.DataFrame = [sr: double, pr: double ... 1 more field]
val parsedRdd = out.rdd.map(row => Vectors.dense(row.getAs[org.apache.spark.ml.linalg.DenseVector ](2).toArray))





      
//Unique Name 
>>> iris.select(collect_set("Name")).collect()
res0: Array[org.apache.spark.sql.Row] = Array([WrappedArray(Iris-virginica, Iris-setosa, Iris-versicolor)])

//String proessing 
iris.select(lower(col("Name"))).show(5)

//Note sql.functions return Column, hence usage of below is wrong, Write a UDF 
//>>> iris.select(substring(col("Name"), instr(col("Name"),"-")+1, length(col("Name")))).show(5)

//To work with SQL ///+++ UDF 
spark.udf.register("get", (s:String) => s.slice(s.indexOf("-")+1, s.size))
//OR 
val get = udf((s:String) => s.slice(s.indexOf("-")+1, s.size))

iris.select(get(col("Name")).alias("nm")).show(5)

//To show in SQL , must use 
iris.createOrReplaceTempView("iris")
spark.sql("select get(Name) as nm from iris").show()





//Statistic 
val stat =iris.describe().cache() //DataFrame[summary: string, SepalLength: string, SepalWidth: string, PetalLength: string, PetalWidth: string, Name: string]
stat.show(false)  //DF 
//create only one file, else no of files = no of partitions 
stat.coalesce(1).write.format("csv").option("header","true").save("summary")

//groupBy 
iris.groupBy("Name").agg(Map("*" -> "count", "SepalLength" -> "min")).collect()
iris.groupBy("Name").agg(count("*"), stddev($"SepalLength")).collect()

//Pivoting a particular value 
iris.select(sort_array(collect_set($"SepalLength"))).collect()
[4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9

iris.agg(countDistinct($"SepalLength")).collect()  //35 
//find each distinct values count 
val irisd = iris.withColumn("cnt", count('SepalLength).over(org.apache.spark.sql.expressions.Window.partitionBy('SepalLength))).withColumn("maps", array($"SepalLength", $"cnt"))
irisd.select($"maps").distinct.collect
es43: Array[org.apache.spark.sql.Row] = Array([WrappedArray(6.9, 4.0)], [WrappeArray(6.2, 4.0)], [WrappedArray(5.2, 4.0)], [WrappedArray(4.4, 3.0)], [WrappedA


// Compute the avg of SepalWidth for evalue of SepalLength
//note These functions takes only ColumnName 
iris.groupBy("Name").pivot("SepalLength", Seq(6.9, 6.2)).avg("SepalWidth")
res49: Array[org.apache.spark.sql.Row] = Array([Iris-virginica,3.1333333333333333,3.0999999999999996], [Iris-setosa,null,null], [Iris-versicolor,3.1,2.55])

// Or without specifying column values (less efficient)
iris.groupBy("Name").pivot("SepalLength").avg("SepalWidth").collect

//Userdefined aggregate function, to use with GroupBy 
import org.apache.spark.sql.expressions.{MutableAggregationBuffer, UserDefinedAggregateFunction}


//Extend UserDefinedAggregateFunction to write custom aggregate function
    initialize 
        On a given node, this method is called once for each group.
    update
        For a given group, spark will call “update” for each input record of that group.
    merge 
        if the function supports partial aggregates, spark might (as an optimization) 
        compute partial result and combine them together
    evaluate 
        Once all the entries for a group are exhausted, 
        spark will call evaluate to get the final result.
        
   
//You can also specify any constructor arguments. For instance you 
//can have CustomMean(arg1: Int, arg2: String)
//Example Normalize = accumulate all values , then (each-mean)/std 
//As per definition or aggergation , it can only return one Value , hence array type 
class Normalize extends UserDefinedAggregateFunction {
    def mean(x:Seq[Double]) = x.toList.reduce(_+_)/x.toList.size  
    def std(x:Seq[Double]) = scala.math.sqrt(x.toList.map(e => scala.math.pow(e-mean(x),2)).sum/x.toList.size)

    // Input Data Type Schema ie for each group, what would be Data Frame schema 
    def inputSchema: StructType = StructType(Seq(StructField("input",DoubleType,true)))
    // Intermediate Schema
    def bufferSchema = StructType(Seq(StructField("temp",ArrayType(DoubleType,true),true)))
    // Returned Data Type .
    def dataType: DataType = ArrayType(DoubleType,true)
    // Self-explaining
    def deterministic = true
    // This function is called whenever key changes
    def initialize(buffer: MutableAggregationBuffer) = {  //bufferSchema
        buffer(0) = Seq[Double]()
    }
    // Iterate over each entry of a group
    def update(buffer: MutableAggregationBuffer, input: Row) = {
        buffer(0) = buffer.getSeq[Double](0) ++ Seq(input.getDouble(0))
    }
    // Merge two partial aggregates
    def merge(buffer1: MutableAggregationBuffer, buffer2: Row) = {
        buffer1(0) = buffer1.getSeq[Double](0) ++ buffer2.getSeq[Double](0)
    }
    // Called after all the entries are exhausted.
    def evaluate(buffer: Row) = {
        val lst = buffer.getSeq[Double](0)
        val m = mean(lst)
        val s = std(lst)        
        val tr = lst.toList.map(e => (e-m)/s ).toSeq 
        //println(s"$lst  $m  $s $tr")
        tr   //return Seq because dataType is ArrayType, if dataType is StructType(ArrayType), then return Row(tr)
    }
}
//Usage 
// define UDAF
val norm = new Normalize()
spark.udf.register("norm", norm)
val q = iris.groupBy('Name).agg(norm.apply('SepalLength).alias("NormedSepalLength"))  //'
q.collect() 
q.select(explode($"NormedSepalLength").alias("SepalLength"), $"Name").show()
+--------------------+--------------+
|         SepalLength|          Name|
+--------------------+--------------+
| -0.4575141833581041|Iris-virginica|
| -1.2518096405770391|Iris-virginica|
|  0.8133585481921916|Iris-virginica|

//With sql 
spark.sql("select Name, count(*) as cnt, min(SepalLength) as min from iris group by Name order by Name").show()
spark.sql("select Name, norm(SepalLength) as NormedSepalLength from iris group by Name order by Name").show()









///+++ DataFrame and SQL Join Operators - of Dataset[T]
def  joinWith[U](other: Dataset[U], condition: Column): Dataset[(T, U)]  //inner equi-join to join for each pair where condition evaluates to true.
def  joinWith[U](other: Dataset[U], condition: Column, joinType: String): Dataset[(T, U)]
    condition: $"LHS_ColumnName" === $"RHS_ColumnName"
    jointype: inner, cross, outer, full, full_outer, left, left_outer, right, right_outer, left_semi, left_anti.
def crossJoin(right: Dataset[_]): DataFrame //cartesian join with another DataFrame.
def join(right: Dataset[_], joinExprs: Column, joinType: String): DataFrame
    df1.join(df2, $"df1Key" === $"df2Key", "outer")
def join(right: Dataset[_], joinExprs: Column): DataFrame //inner join 
    df1.join(df2, $"df1Key" === $"df2Key")
    df1.join(df2).where($"df1Key" === $"df2Key")
    df1.join(df2, "df1Key == df2Key")
    df1.join(df2).where("df1Key == df2Key")
    df1.join(df2).filter("df1Key == df2Key")
def join(right: Dataset[_], usingColumns: Seq[String], joinType: String): DataFrame
def join(right: Dataset[_], usingColumns: Seq[String]): DataFrame
    // Joining df1 and df2 using the columns "user_id" and "user_name"
    df1.join(df2, Seq("user_id", "user_name"))
def join(right: Dataset[_], usingColumn: String): DataFrame
    // Joining df1 and df2 using the column "user_id"
    df1.join(df2, "user_id")
def join(right: Dataset[_]): DataFrame



//inner equi-join
//joinWith creates a Dataset with two columns _1 and _2 
//that each contain records for which condition holds.
case class Person(id: Long, name: String, cityId: Long)
case class City(id: Long, name: String)
val family = Seq(
  Person(0, "Agata", 0),
  Person(1, "Iweta", 0),
  Person(2, "Patryk", 2),
  Person(3, "Maksym", 0)).toDS
val cities = Seq(
  City(0, "Warsaw"),
  City(1, "Washington"),
  City(2, "Sopot")).toDS

val joined = family.joinWith(cities, family("cityId") === cities("id"))
>>> joined.printSchema
root
 |-- _1: struct (nullable = false)
 |    |-- id: long (nullable = false)
 |    |-- name: string (nullable = true)
 |    |-- cityId: long (nullable = false)
 |-- _2: struct (nullable = false)
 |    |-- id: long (nullable = false)
 |    |-- name: string (nullable = true)
>>> joined.show




///+++ Multidimensional cube, rollup, groupBy of Dataset[T]
val people = spark.read.json(raw"D:\Desktop\PPT\spark\data\peopledepart.json")


def groupByKey[K](func: (T) => K)(implicit arg0: Encoder[K]): KeyValueGroupedDataset[K, T]
def orderBy(sortExprs: Column*): Dataset[T]
def orderBy(sortCol: String, sortCols: String*): Dataset[T]
def agg(expr: Column, exprs: Column*): DataFrame  // ds.agg(...) is a shorthand for ds.groupBy().agg(...)
    people.agg(max($"age"), avg($"salary"))
    people.groupBy().agg(max($"age"), avg($"salary"))
def agg(exprs: Map[String, String]): DataFrame
    people.agg(Map("age" -> "max", "salary" -> "avg"))
    people.groupBy().agg(Map("age" -> "max", "salary" -> "avg"))
def agg(aggExpr: (String, String), aggExprs: (String, String)*): DataFrame
    people.agg("age" -> "max", "salary" -> "avg")
    people.groupBy().agg("age" -> "max", "salary" -> "avg")    
def cube(col1: String, cols: String*): RelationalGroupedDataset
def cube(cols: Column*): RelationalGroupedDataset
    // Compute the average for all numeric columns cubed by department and gender.
    people.cube($"departId", $"gender").avg()
    // Compute the max age and average salary, cubed by department and gender.
    people.cube($"departId", $"gender").agg(Map(
      "salary" -> "avg",
      "age" -> "max"
    ))
def rollup(col1: String, cols: String*): RelationalGroupedDataset
def rollup(cols: Column*): RelationalGroupedDataset
    // Compute the average for all numeric columns rolluped by department and gender.
    people.rollup($"departId", $"gender").avg()
    // Compute the max age and average salary, rolluped by department and gender.
    people.rollup($"departId", $"gender").agg(Map(
      "salary" -> "avg",
      "age" -> "max"
    ))
def groupBy(col1: String, cols: String*): RelationalGroupedDataset
def groupBy(cols: Column*): RelationalGroupedDataset
    // Compute the average for all numeric columns grouped by department.
    ds.groupBy($"departId").avg()
    // Compute the max age and average salary, grouped by department and gender.
    ds.groupBy($"departId", $"gender").agg(Map(
      "salary" -> "avg",
      "age" -> "max"
    ))
    
    
    
//Difference between cube, rollup and groupby 
val df =sc.parallelize(Array((2, "Alice"), (5, "Bob"))).toDF("age","name")
                          
cube(*cols)
    create cartesian product of (null, all values from name) x (null, all values from age)
    null means  any value of that column possible , means other columns subtotal 
    >>> df.cube($"name", df("age")).count().orderBy("name", "age").show()
    +-----+----+-----+
    | name| age|count|
    +-----+----+-----+
    | null|null|    2|
    | null|   2|    1|
    | null|   5|    1|
    |Alice|null|    1|
    |Alice|   2|    1|
    |  Bob|null|    1|
    |  Bob|   5|    1|
    +-----+----+-----+
rollup(*cols)
    create cartesian product of (null, all values from name) x (null, all values from age)
    null means  any value of that column possible , means other columns subtotal
    and them remove rows with "null" of first column and only keeping null,null row
    >>> df.rollup($"name", 'age).count().orderBy("name", "age").show() //'
    +-----+----+-----+
    | name| age|count|
    +-----+----+-----+
    | null|null|    2|
    |Alice|null|    1|
    |Alice|   2|    1|
    |  Bob|null|    1|
    |  Bob|   5|    1|
    +-----+----+-----+
groupBy(*cols) 
groupby(*cols)    
    create cartesian product of (null, all values from name) x (null, all values from age)
    null means  any value of that column possible , means other columns subtotal
    and them remove rows with any null 
    >>> df.groupBy('name, 'age).count().orderBy("name", "age").show()
    +-----+---+-----+
    | name|age|count|
    +-----+---+-----+
    |Alice|  2|    1|
    |  Bob|  5|    1|
    +-----+---+-----+

//Multidimensional 
val sales = Seq(
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)
).toDF("city", "year", "amount")

// very labor-intense
// groupBy's unioned
val groupByCityAndYear = sales
  .groupBy("city", "year")  // <-- subtotals (city, year)
  .agg(sum("amount") as "amount")
val groupByCityOnly = sales
  .groupBy("city")          // <-- subtotals (city)
  .agg(sum("amount") as "amount")
  .select($"city", lit(null) as "year", $"amount")  // <-- year is null
val withUnion = groupByCityAndYear
  .union(groupByCityOnly)
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
>>> withUnion.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+

//grouping(*cols)  is an aggregate function that indicates whether a specified column is aggregated or not and:
//    returns  1  if the column is in a subtotal and is  NULL 
//    returns  0  if the underlying value is  NULL  or any other value
//grouping_id(*cols)  is an aggregate function that computes the level of grouping:
//    Returns 
//        0  for combinations of each column
//        1  for subtotals of column 1 ie other columns null 
//        2  for subtotals of column 2 ie other columns null 
//        And so on…

///Multi-dimensional aggregate operators are semantically equivalent to union operator 
//(or SQL’s UNION ALL) to combine single grouping queries.
val withRollup = sales
  .rollup("city", "year")
  .agg(sum("amount") as "amount", grouping_id() as "gid")
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
  .filter(grouping_id() =!= 3)
  .select("city", "year", "amount")
>>> withRollup.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+

// SQL only, 
sales.createOrReplaceTempView("sales")
val withGroupingSets = sql("""
  SELECT city, year, SUM(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city))
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> withGroupingSets.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+

///Details of  rollup 
//Note the subtotal 
val sales = Seq(
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)
).toDF("city", "year", "amount")

val q = sales
  .rollup("city", "year")
  .agg(sum("amount") as "amount")
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
>>> q.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100| <-- subtotal for Warsaw in 2016
| Warsaw|2017|   200|
| Warsaw|null|   300| <-- subtotal for Warsaw (across years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550| <-- grand total
+-------+----+------+

// The above query is semantically equivalent to the following
val q1 = sales
  .groupBy("city", "year")  // <-- subtotals (city, year)
  .agg(sum("amount") as "amount")
val q2 = sales
  .groupBy("city")          // <-- subtotals (city)
  .agg(sum("amount") as "amount")
  .select($"city", lit(null) as "year", $"amount")  // <-- year is null
val q3 = sales
  .groupBy()                // <-- grand total
  .agg(sum("amount") as "amount")
  .select(lit(null) as "city", lit(null) as "year", $"amount")  // <-- city and year are null
val qq = q1
  .union(q2)
  .union(q3)
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
>>> qq.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|
+-------+----+------+


///Details of cube - cube is more than rollup operator, 
//i.e. cube does rollup with aggregation over all the missing combinations given the columns.

val sales = Seq(
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)
).toDF("city", "year", "amount")

val q = sales.cube("city", "year")
  .agg(sum("amount") as "amount")
  .sort($"city".desc_nulls_last, $"year".asc_nulls_last)
>>> q.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|  <-- total in Warsaw in 2016
| Warsaw|2017|   200|  <-- total in Warsaw in 2017
| Warsaw|null|   300|  <-- total in Warsaw (across all years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total in 2015 (across all cities)
|   null|2016|   250|
|   null|2017|   250|
|   null|null|   550|  <-- grand total (across cities and years)
+-------+----+------+


///Details of GROUPING SETS SQL Clause
//GROUPING SETS clause generates a dataset that is equivalent to union operator 
//of multiple groupBy operators.

val sales = Seq(
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)
).toDF("city", "year", "amount")
sales.createOrReplaceTempView("sales")

// equivalent to rollup("city", "year")
val q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|  <-- grand total across all cities and years
+-------+----+------+

// equivalent to cube("city", "year")
// note the additional (year) grouping set
val q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), (year), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total across all cities in 2015
|   null|2016|   250|  <-- total across all cities in 2016
|   null|2017|   250|  <-- total across all cities in 2017
|   null|null|   550|
+-------+----+------+







///+++ Hive 

import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession


val warehouseLocation = "spark-warehouse"

val spark = SparkSession
  .builder()
  .appName("Spark Hive Example")
  .config("spark.sql.warehouse.dir", warehouseLocation)
  .enableHiveSupport()
  .getOrCreate()

import spark.implicits._
import spark.sql

sql("CREATE TABLE IF NOT EXISTS src (key INT, value STRING)")
sql("LOAD DATA LOCAL INPATH 'file://D:/Desktop/PPT/spark/data/kv1.txt' INTO TABLE src")

// Queries are expressed in HiveQL
sql("SELECT * FROM src").show()

// Aggregation queries are also supported.
sql("SELECT COUNT(*) FROM src").show()

// The results of SQL queries are themselves DataFrames and support all normal functions.
val sqlDF = sql("SELECT key, value FROM src WHERE key < 10 ORDER BY key")

// The items in DaraFrames are of type Row, which allows you to access each column by ordinal.
val stringsDS = sqlDF.map {
  case Row(key: Int, value: String) => s"Key: $key, Value: $value"
}
stringsDS.show()

// You can also use DataFrames to create temporary views within a SparkSession.
val recordsDF = spark.createDataFrame((1 to 100).map(i => Record(i, s"val_$i")))
recordsDF.createOrReplaceTempView("records")

// Queries can then join DataFrame data with data stored in Hive.
sql("SELECT * FROM records r JOIN src s ON r.key = s.key").show()






///*** JDBC To Other Databases
//This functionality should be preferred over using JdbcRDD
// --conf spark.executor.extraClassPath=postgresql-9.4.1207.jar if required in executor  
$ spark-shell --driver-class-path postgresql-9.4.1207.jar --jars postgresql-9.4.1207.jar
//for mysql 
$ spark-shell --driver-class-path mysql-connector-java-5.1.34.jar  --jars mysql-connector-java-5.1.34.jar

//Or Include in sbt/build.sbt and create fat jar 
  
//Sqllite 
//include in build.sbt:
libraryDependencies += "org.xerial" % "sqlite-jdbc" % "3.21.0.1"
//Append rows 
import org.apache.spark.sql.SaveMode

val driverClass = "org.sqlite.JDBC"
           
                 
val df = spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\iris.csv")
              
df.write.format("jdbc").options(Map("url" -> "jdbc:sqlite:iris.db",
                 "driver" -> driverClass,
                 "dbtable" -> "iris2")).mode(SaveMode.Append).save()                 
                 
                 
//or Class.forName("org.sqlite.JDBC")
val dfs = spark.read.format("jdbc").options(Map("url" -> "jdbc:sqlite:iris.db",
                 "driver" -> driverClass,
                 "dbtable" -> "iris2")).load()
                 
>>> dfs.columns
res2: Array[String] = Array(SepalLength, SepalWidth, PetalLength, PetalWidth, Name)                 
                 
                 
//Example -Checking all Data 
val metaData = spark.read.format("jdbc")
    .options(Map("url" -> "jdbc:sqlite:iris.db","driver" -> driverClass,
                 "dbtable" -> "(SELECT * FROM sqlite_master) AS t")).load()

val myTableNames = metaData.select("tbl_name").map(_.getString(0)).collect()

for (t <- myTableNames) {
  println(t.toString)
  val tableData = spark read.format("jdbc")
    .options(
      Map(
        "url" -> "jdbc:sqlite:file.db","Driver" -> driverClass,
        "dbtable" -> t)).load()
  tableData.show()
}
    
   



   
   
   
///++++ Spark Streaming Vs Structured Streaming 
Spark Streaming 
    Main: spark-streaming_2.11_2.2.0.jar
        Kafka 	spark-streaming-kafka-0-8_2.11
        Flume 	spark-streaming-flume_2.11
        Kinesis	spark-streaming-kinesis-asl_2.11
    Has StreamingContext 
    has DStream, InputDStream, PairDStreamFunctions
    Has below trsnformations 
        map(func)                   
        flatMap(func)               
        filter(func)                
        repartition(numPartitions)  
        union(otherStream)          
        count()                     
        reduce(func)                
        countByValue()                 
        reduceByKey(func, [numTasks])  
        join(otherStream, [numTasks])  
        cogroup(otherStream, [numTasks])
        transform(func)                 
        updateStateByKey(func)    
        mapWithState(func)
    Has below Actions 
        print(), saveAsObjectFiles(prefix, [suffix]) , saveAsHadoopFiles(prefix, [suffix])  
        saveAsTextFiles(prefix, [suffix])  
        foreachRDD(func)  
//Example 
import org.apache.spark.SparkConf
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.{Seconds, StreamingContext}

//run at first 
$ nc -lk 9999`
 
object NetworkWordCount {
  def main(args: Array[String]) {
    if (args.length < 2) {
      System.err.println("Usage: NetworkWordCount <hostname> <port>")
      System.exit(1)
    }

    // Create the context with a 1 second batch size
    val sparkConf = new SparkConf().setAppName("NetworkWordCount")
    val ssc = new StreamingContext(sparkConf, Seconds(1))

    // Create a socket stream on target ip:port and count the
    // words in input stream of \n delimited text (eg. generated by 'nc')
    // Note that no duplication in storage level only for running locally.
    // Replication necessary in distributed scenario for fault tolerance.
    val lines = ssc.socketTextStream(args(0), args(1).toInt, StorageLevel.MEMORY_AND_DISK_SER)
    val words = lines.flatMap(_.split(" "))
    val wordCounts = words.map(x => (x, 1)).reduceByKey(_ + _)
    wordCounts.print()
    ssc.start()
    ssc.awaitTermination()
  }
}



Structured Streaming 
    Better performance than spark streaming 
    Use the Dataset/DataFrame API 
        below are not supported 
            Multiple streaming aggregations (i.e. a chain of aggregations on a streaming DF) are not yet supported on streaming Datasets.
            Limit and take first N rows are not supported on streaming Datasets.
            Distinct operations on streaming Datasets are not supported.
            Sorting operations are supported on streaming Datasets only after an aggregation 
                and in Complete Output Mode.
            Outer joins between a streaming and a static Datasets are conditionally supported.
                Full outer join with a streaming Dataset is not supported
                Left outer join with a streaming Dataset on the right is not supported
                Right outer join with a streaming Dataset on the left is not supported
            Any kind of joins between two streaming Datasets is not yet supported.
            count() - Cannot return a single count from a streaming Dataset. 
                Instead, use ds.groupBy().count() which returns a streaming Dataset containing a running count.
            foreach() - Instead use ds.writeStream.foreach(...) (see next section).
            show() - Instead use the console sink 
    Reading  by spark.readStream, writing by spark.writeStream
    Then use DataStreamReader and DataStreamWriter 
    
//Example 

import java.sql.Timestamp

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

//Usage: StructuredNetworkWordCountWindowed <hostname> <port> <window duration>    [<slide duration>]
// <hostname> and <port> describe the TCP server that Structured Streaming
// would connect to receive data.
// <window duration> gives the size of window, specified as integer number of seconds
// <slide duration> gives the amount of time successive windows are offset from one another,
// given in the same units as above. <slide duration> should be less than or equal to
// <window duration>. If the two are equal, successive windows have no overlap. If
// <slide duration> is not provided, it defaults to <window duration>.
//To run this on your local machine, you need to first run a Netcat server
//$ nc -lk 9999`
//One recommended <window duration>, <slide duration> pair is 10, 5
//StructuredNetworkWordCountWindowed.main(Array("localhost", "9999", "10", "5"))
object StructuredNetworkWordCountWindowed {

  def main(args: Array[String]) {
    if (args.length < 3) {
      System.err.println("Usage: StructuredNetworkWordCountWindowed <hostname> <port>" +
        " <window duration in seconds> [<slide duration in seconds>]")
      System.exit(1)
    }

    val host = args(0)
    val port = args(1).toInt
    val windowSize = args(2).toInt
    val slideSize = if (args.length == 3) windowSize else args(3).toInt
    if (slideSize > windowSize) {
      System.err.println("<slide duration> must be less than or equal to <window duration>")
    }
    val windowDuration = s"$windowSize seconds"
    val slideDuration = s"$slideSize seconds"

    val spark = SparkSession
      .builder
      .appName("StructuredNetworkWordCountWindowed")
      //.master("local[*]")
      .getOrCreate()

    import spark.implicits._

    // Create DataFrame representing the stream of input lines from connection to host:port
    val lines = spark.readStream
      .format("socket")
      .option("host", host)
      .option("port", port)
      .option("includeTimestamp", true)
      .load()

    // Split the lines into words, retaining timestamps
    val words = lines.as[(String, Timestamp)].flatMap(line =>
      line._1.split(" ").map(word => (word, line._2))
    ).toDF("word", "timestamp")

    // Group the data by window and word and compute the count of each group
    val windowedCounts = words.withWatermark("timestamp", "10 minutes").groupBy(
      window($"timestamp", windowDuration, slideDuration), $"word"
    ).count().orderBy("window")

    // Start running the query that prints the windowed word counts to the console
    val query = windowedCounts.writeStream
      .outputMode("complete")
      .format("console")
      .option("truncate", "false")
      .start()

    query.awaitTermination()
  }
}



///+++ Spark structured Streaming 

import scala.concurrent.duration._

val schema =StructType(Seq(
  StructField("name", StringType, false) ,
  StructField("age", IntegerType, false) ))
  
val q =spark.readStream
  .format("json")
  .schema(schema)
  .load("file:///D:/Desktop/PPT/spark/data/input-json")  //input-json is a directory , Keep on moving a file to it 
  .select("name", "age")
  .where("age > 15")   
  .writeStream
  .trigger(ProcessingTime(10.seconds))
  .format("console")   //or to convert to csv , .format("csv").option("header","true").start("file:///D:/Desktop/PPT/spark/data/json-to-csv")
  .start()
  
//q.awaitTermination()  //blocks 
//q.stop() 
q.processAllAvailable()  //testng purpose only , only once triggered 
>>> sq.explain()
== Physical Plan ==
...
>>> sq.explain(True)
== Parsed Logical Plan ==
...
== Analyzed Logical Plan ==
...
== Optimized Logical Plan ==
...
== Physical Plan ==
...
>>> sq.stop()


// -------------------------------------------
// Batch: 1
// -------------------------------------------
// +-----+-----+
// | name|age  |
// +-----+-----+
// |Jacek| 20.5|
// +-----+-----+


///Available Output Modes OutputMode 	Name 	Behaviour
Append
	append	
    Default output mode that writes "new" rows only.
    For streaming aggregations, "new" row is when the intermediate state becomes final, 
    i.e. when new events for the grouping key can only be considered late 
    which is when watermark moves past the event time of the key.
    Append output mode requires that a streaming query defines event time watermark 
    (using withWatermark operator) on the event time column that is used in aggregation 
    (directly or using window function).
    Required for datasets with FileFormat format (to create FileStreamSink)
    Used for flatMapGroupsWithState operator
    Append is mandatory when multiple flatMapGroupsWithState operators are used in a structured query.
Complete	
    complete
    Writes all rows (every time there are updates) 
    and therefore corresponds to a traditional batch query.
    Supported only for streaming queries with groupBy or groupByKey aggregations 
    (as asserted by UnsupportedOperationChecker).
Update
    update
    Write the rows that were updated (every time there are updates). 
    If the query does not contain aggregations, it is equivalent to Append mode.
    Used for mapGroupsWithState and flatMapGroupsWithState operators

    

///Kafka structured streaming - uses new Kafka API 

$ spark-shell --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0

//cd  to zookeeper dir and then kafka dir 
$ zookeeper-server-start.bat  conf/zoo.cfg  //client binds to ..:2181
$ kafka-server-start.bat config/server.properties   //server binds to localhost:9092, called broker-list 

$ kafka-console-producer.bat --broker-list localhost:9092 --topic topic1

//Example 
import org.apache.spark._ 
import org.apache.spark.rdd._ 
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.streaming._
import org.apache.spark.sql.functions._
import scala.concurrent.duration._
 
// time,key,value
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70

/// DataFrame w/ schema [eventTime: timestamp, deviceId: string, signal: bigint]
val rawData  = spark.
  readStream.
  format("kafka").
  option("subscribe", "topic1").
  option("kafka.bootstrap.servers", "localhost:9092").
  load() 

scala> rawData.printSchema
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)
 
 
val eventsDF = rawData.
  select(col("value").cast("string")).          
  withColumn("tokens", split(col("value"), ",")).    
  withColumn("eventTime", to_timestamp(col("tokens").getItem(0))).
  withColumn("deviceId", col("tokens").getItem(1).cast("string")).
  withColumn("signal", col("tokens").getItem(2).cast("int")).
  select("eventTime", "deviceId", "signal")

avgSignalDF = eventsDF.groupBy("deviceId").avg("signal")

//With only window 
windowedAvgSignalDF = eventsDF.
    groupBy(window("eventTime", "5 minute")).
    count()

//OR sliding window 
windowedAvgSignalDF =  eventsDF.
    groupBy(window("eventTime", "10 minutes", "5 minutes")).
    count()
    
//With deviceId and window 
windowedCountsDF = eventsDF.
    groupBy(
      "deviceId",
      window("eventTime", "10 minutes", "5 minutes")).
    count()

//Watermarking to Limit State while Handling Late Data
//Watermark is a moving threshold in event-time that trails behind the maximum event-time seen by the query in the processed data. 
//The trailing gap defines how long we will wait for late data to arrive
val windowedCountsDF =  eventsDF.
    withWatermark("eventTime", "20 minutes").
    groupBy(
      $"deviceId",
      window($"eventTime", "5 minutes")).
    agg(collect_list(col("signal")).alias("signals")).
    select($"deviceId", $"signals", size(col("signals")).as("count"), $"window")

val sq = windowedCountsDF.writeStream.
  format("console").
  option("truncate", false).
  trigger(ProcessingTime(10.seconds)).
  outputMode("update").  
  start()
  
sq.processAllAvailable()  //testng purpose only , only once triggered   
  
// After StreamingQuery was started,
// the physical plan is complete (with batch-specific values)
>>> sq.explain()

//input 
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:00:00.002Z,"mine",20

  
//Output 
-------------------------------------------
Batch: 1
-------------------------------------------
+--------+----------------+-----+------------------------------------------+
|deviceId|signals         |count|window                                    |
+--------+----------------+-----+------------------------------------------+
|"mine"  |[70]            |1    |[2017-08-23 06:15:00, 2017-08-23 06:20:00]|
|"mine"  |[60, 60]        |2    |[2017-08-23 06:30:00, 2017-08-23 06:35:00]|
|"mine"  |[30, 40, 30, 40]|4    |[2017-08-23 05:35:00, 2017-08-23 05:40:00]|
|"mine"  |[20, 20]        |2    |[2017-08-23 05:30:00, 2017-08-23 05:35:00]|
|"mine"  |[50, 50]        |2    |[2017-08-23 05:40:00, 2017-08-23 05:45:00]|
+--------+----------------+-----+------------------------------------------+

-------------------------------------------
Batch: 2
-------------------------------------------
+--------+--------+-----+------------------------------------------+
|deviceId|signals |count|window                                    |
+--------+--------+-----+------------------------------------------+
|"mine"  |[70, 70]|2    |[2017-08-23 06:15:00, 2017-08-23 06:20:00]|
+--------+--------+-----+------------------------------------------+

-------------------------------------------
Batch: 3
-------------------------------------------
+--------+-------+-----+------+
|deviceId|signals|count|window|
+--------+-------+-----+------+
+--------+-------+-----+------+




///Example of Kafka sink with  CSV

//Schema 
val mySchema = StructType(Array(
 StructField("id", IntegerType),
 StructField("name", StringType),
 StructField("year", IntegerType),
 StructField("rating", DoubleType),
 StructField("duration", IntegerType)
))
//Put csv file (eg check data/kakfa-csv.csv) in ./kafka-csv dir
val streamingDataFrame = spark.readStream.schema(mySchema).csv("kafka-csv")

//Publish the Stream to Kafka
streamingDataFrame.selectExpr("CAST(id AS STRING) AS key", "to_json(struct(*)) AS value").
  writeStream
  .format("kafka")
  .option("topic", "topicName")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .option("checkpointLocation", "./kafka-checkpoint") // <-- mandatory
  .start()
  
//Subscribe the Stream From Kafka
import spark.implicits._
val df = spark
  .readStream
  .format("kafka")
  .option("kafka.bootstrap.servers", "localhost:9092")
  .option("subscribe", "topicName")
  .load()
  
//convert the data that is coming in the Stream from Kafka to JSON, 
//and from JSON, create the DataFrame as per mySchema

val df1 = df.selectExpr("CAST(value AS STRING)", "CAST(timestamp AS TIMESTAMP)").as[(String, Timestamp)]
  .select(from_json($"value", mySchema).as("data"), $"timestamp")
  .select("data.*", "timestamp")
  
//put in console 
val sq = df1.writeStream
    .format("console")
    .option("truncate","false")
    .start()
    
//sq.awaitTermination()  //blocks 
//sq.stop() 
sq.processAllAvailable()  //testng purpose only , only once triggered   



///MemorySink is a streaming Sink that stores records in memory. 
//It is particularly useful for testing.

//MemorySink is used for memory format and requires a query name 
//(by queryName method or queryName option).

val spark: SparkSession = 
val logs = spark.readStream.textFile("logs/*.out")

scala> val outStream = logs.writeStream
  .format("memory")
  .queryName("logs")
  .start()
outStream: org.apache.spark.sql.streaming.StreamingQuery = org.apache.spark.sql.execution.streaming.StreamingQueryWrapper@690337df

scala> sql("select * from logs").show(truncate = false)

                         
///Example rate data source 
//The following example code shows how to apply groupByKey operator to a structured stream of timestamped values of different devices.

// input stream
val signals = spark.
  readStream.
  format("rate").
  option("rowsPerSecond", 1).
  load.
  withColumn("value", $"value" % 10)  // <-- randomize the values (just for fun)
  withColumn("deviceId", lit(util.Random.nextInt(10))). // <-- 10 devices randomly assigned to values
  as[(Timestamp, Long, Int)] // <-- convert to a "better" type (from "unpleasant" Row)
 
>>> signals.printSchema()
root
 |-- timestamp: timestamp (nullable = true)
 |-- value: long (nullable = true)
 |-- deviceId: integer (nullable = false)
 
 
// stream processing using groupByKey operator
// groupByKey(func: ((Timestamp, Long, Int)) => K): KeyValueGroupedDataset[K, (Timestamp, Long, Int)]
// K becomes Int which is a device id
val deviceId: ((Timestamp, Long, Int)) => Int = { case (_, _, deviceId) => deviceId }
>>> val signalsByDevice = signals.groupByKey(deviceId)
signalsByDevice: org.apache.spark.sql.KeyValueGroupedDataset[Int,(java.sql.Timestamp, Long, Int)] = org.apache.spark.sql.KeyValueGroupedDataset@19d40bc6




///Example - Streaming Query for Running Counts (over Words from Socket with Output to Console)
//You need to run nc -lk 9999 first before running the example.
//note socket is not production grade 

val lines = spark.readStream
  .format("socket")
  .option("host", "localhost")
  .option("port", 9999)
  .option("includeTimestamp", true)
  .load
  .as[(String,java.sql.Timestamp)]

val words = lines.flatMap( t => (t._1.split("\\W+"), t._2))

scala> words.printSchema
root
 |-- value: string (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 
val counter = words.groupBy("value").count //org.apache.spark.sql.DataFrame = [value: string, count: bigint]

// nc -lk 9999 is supposed to be up at this point
//groupBy only supports Complete 

import org.apache.spark.sql.streaming.OutputMode.Complete
val query = counter.writeStream
  .outputMode(Complete)
  .format("console")
  .start

query.stop



///Example -Streaming Query over CSV Files with Output to Console Every 5 Seconds
// Explicit schema with nullables false
import org.apache.spark.sql.types._
val schemaExp = StructType(
  StructField("name", StringType, false) ::
  StructField("city", StringType, true) ::
  StructField("country", StringType, true) ::
  StructField("age", IntegerType, true) ::
  StructField("alive", BooleanType, false) :: Nil
)

// Implicit inferred schema, check csv-logs for csv file 
val schemaImp = spark.read
  .format("csv")
  .option("header", true)
  .option("inferSchema", true)
  .load("../data/csv-logs")
  .schema

val in = spark.readStream
  .schema(schemaImp)
  .format("csv")
  .option("header", true)
  .option("maxFilesPerTrigger", 1)
  .load("../data/csv-logs")

scala> in.printSchema
root
 |-- name: string (nullable = true)
 |-- city: string (nullable = true)
 |-- country: string (nullable = true)
 |-- age: integer (nullable = true)
 |-- alive: boolean (nullable = true)

println("Is the query streaming" + in.isStreaming)

println("Are there any streaming queries" + spark.streams.active.isEmpty)

import scala.concurrent.duration._
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
val out = in.
  writeStream.
  format("console").
  option("truncate", false).
  trigger(Trigger.ProcessingTime("5 seconds")).
  queryName("consoleStream").
  outputMode(Output.Append).
  start
//Output 

-------------------------------------------
Batch: 0
-------------------------------------------
+-----+--------+-------+---+-----+
| name|    city|country|age|alive|
+-----+--------+-------+---+-----+
|Jacek|Warszawa| Polska| 42| true|
+-----+--------+-------+---+-----+

spark.streams
  .active
  .foreach(println)
// Streaming Query - consoleStream [state = ACTIVE]

scala> spark.streams.active(0).explain
== Physical Plan ==
*Scan csv [name#130,city#131,country#132,age#133,alive#134] Format: CSV, InputPaths: file:/Users/j


///KeyValueGroupedDataset—Streaming Aggregation
//KeyValueGroupedDataset represents a grouped dataset as a result of groupByKey operator 
//(that aggregates records by a grouping function).
// Dataset[T]
groupByKey(func: T => K): KeyValueGroupedDataset[K, T]

//KeyValueGroupedDataset works for batch and streaming aggregations, 
//but shines the most when used for streaming aggregation (with streaming Datasets).

import java.sql.Timestamp
scala> val numGroups = spark.
  readStream.
  format("rate").
  load.
  as[(Timestamp, Long)].
  groupByKey { case (time, value) => value % 2 }
numGroups: org.apache.spark.sql.KeyValueGroupedDataset[Long,(java.sql.Timestamp, Long)] = org.apache.spark.sql.KeyValueGroupedDataset@616c1605

import org.apache.spark.sql.streaming.Trigger
import scala.concurrent.duration._
numGroups.
  mapGroups { case(group, values) => values.size }.
  writeStream.
  format("console").
  trigger(Trigger.ProcessingTime(10.seconds)).
  start

-------------------------------------------
Batch: 0
-------------------------------------------
+-----+
|value|
+-----+
+-----+

-------------------------------------------
Batch: 1
-------------------------------------------
+-----+
|value|
+-----+
|    3|
|    2|
+-----+

-------------------------------------------
Batch: 2
-------------------------------------------
+-----+
|value|
+-----+
|    5|
|    5|
+-----+

// Eventually...
spark.streams.active.foreach(_.stop)

///KeyValueGroupedDataset’s Operators Operator 	Description
agg
cogroup
count
flatMapGroups
flatMapGroupsWithState
	Creates a Dataset with FlatMapGroupsWithState logical operator
	The difference between flatMapGroupsWithState and mapGroupsWithState is the state function 
    that generates zero or more elements (that are in turn the rows in the result Dataset).
keyAs
keys
mapGroups
mapGroupsWithState
    Creates a Dataset with FlatMapGroupsWithState logical operator
mapValues
queryExecution
reduceGroups
    Creating KeyValueGroupedDataset Instance



///*** mapGroupsWithState Operator—Stateful Streaming Aggregation (with Explicit State Logic)
mapGroupsWithState[S: Encoder, U: Encoder](
  func: (K, Iterator[V], GroupState[S]) => U): Dataset[U] 
      Uses GroupStateTimeout.NoTimeout for timeoutConf
mapGroupsWithState[S: Encoder, U: Encoder](
      timeoutConf: GroupStateTimeout)(
      func: (K, Iterator[V], GroupState[S]) => U): Dataset[U]


//mapGroupsWithState is a special case of flatMapGroupsWithState operator with the following:
    // func being transformed to return a single-element Iterator
    // Update output mode

//mapGroupsWithState also creates a FlatMapGroupsWithState 
//with isMapGroupsWithState internal flag enabled.

import java.sql.Timestamp
scala> val numGroups = spark.
  readStream.
  format("rate").
  load.
  as[(Timestamp, Long)].
  groupByKey { case (time, value) => value % 2 }
numGroups: org.apache.spark.sql.KeyValueGroupedDataset[Long,(java.sql.Timestamp, Long)] = org.apache.spark.sql.KeyValueGroupedDataset@616c1605


import org.apache.spark.sql.streaming.GroupState
def mappingFunc(key: Long, values: Iterator[(java.sql.Timestamp, Long)], state: GroupState[Long]): Long = {
  println(s">>> key: $key => state: $state")
  val newState = state.getOption.map(_ + values.size).getOrElse(0L)
  state.update(newState)
  key
}

import org.apache.spark.sql.streaming.GroupStateTimeout
val longs = numGroups.mapGroupsWithState(
    timeoutConf = GroupStateTimeout.ProcessingTimeTimeout)(
    func = mappingFunc)

import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import scala.concurrent.duration._
val q = longs.
  writeStream.
  format("console").
  trigger(Trigger.ProcessingTime(10.seconds)).
  outputMode(OutputMode.Update). // <-- required for mapGroupsWithState
  start

// Note GroupState

-------------------------------------------
Batch: 1
-------------------------------------------
>>> key: 0 => state: GroupState(<undefined>)
>>> key: 1 => state: GroupState(<undefined>)
+-----+
|value|
+-----+
|    0|
|    1|
+-----+

-------------------------------------------
Batch: 2
-------------------------------------------
>>> key: 0 => state: GroupState(0)
>>> key: 1 => state: GroupState(0)
+-----+
|value|
+-----+
|    0|
|    1|
+-----+

-------------------------------------------
Batch: 3
-------------------------------------------
>>> key: 0 => state: GroupState(4)
>>> key: 1 => state: GroupState(4)
+-----+
|value|
+-----+
|    0|
|    1|
+-----+

// in the end
spark.streams.active.foreach(_.stop)



///*** flatMapGroupsWithState Operator—Arbitrary Stateful Streaming Aggregation (with Explicit State Logic)
flatMapGroupsWithState[S: Encoder, U: Encoder](
  outputMode: OutputMode,
  timeoutConf: GroupStateTimeout)(
  func: (K, Iterator[V], GroupState[S]) => Iterator[U]): Dataset[U]

//	flatMapGroupsWithState requires Append or Update output modes.
//	Every time the state function func is executed for a key, 
//the state (as GroupState[S]) is for this key only.
    // K is the type of the keys in KeyValueGroupedDataset
    // V is the type of the values (per key) in KeyValueGroupedDataset
    // S is the user-defined type of the state as maintained for each group
    // U is the type of rows in the result Dataset

scala> spark.version
res0: String = 2.3.0-SNAPSHOT

import java.sql.Timestamp
type DeviceId = Int
case class Signal(timestamp: java.sql.Timestamp, value: Long, deviceId: DeviceId)

// input stream
import org.apache.spark.sql.functions._
val signals = spark.
  readStream.
  format("rate").
  option("rowsPerSecond", 1).
  load.
  withColumn("value", $"value" % 10).  // <-- randomize the values (just for fun)
  withColumn("deviceId", rint(rand() * 10) cast "int"). // <-- 10 devices randomly assigned to values
  as[Signal] // <-- convert to our type (from "unpleasant" Row)
scala> signals.explain
== Physical Plan ==
*Project [timestamp#0, (value#1L % 10) AS value#5L, cast(ROUND((rand(4440296395341152993) * 10.0)) as int) AS deviceId#9]
+- StreamingRelation rate, [timestamp#0, value#1L]

// stream processing using flatMapGroupsWithState operator
val device: Signal => DeviceId = { case Signal(_, _, deviceId) => deviceId }
val signalsByDevice = signals.groupByKey(device)

import org.apache.spark.sql.streaming.GroupState
type Key = Int
type Count = Long
type State = Map[Key, Count]
case class EventsCounted(deviceId: DeviceId, count: Long)
def countValuesPerKey(deviceId: Int, signalsPerDevice: Iterator[Signal], state: GroupState[State]): Iterator[EventsCounted] = {
  val values = signalsPerDevice.toList
  println(s"Device: $deviceId")
  println(s"Signals (${values.size}):")
  values.zipWithIndex.foreach { case (v, idx) => println(s"$idx. $v") }
  println(s"State: $state")

  // update the state with the count of elements for the key
  val initialState: State = Map(deviceId -> 0)
  val oldState = state.getOption.getOrElse(initialState)
  // the name to highlight that the state is for the key only
  val newValue = oldState(deviceId) + values.size
  val newState = Map(deviceId -> newValue)
  state.update(newState)

  // you must not return as it's already consumed
  // that leads to a very subtle error where no elements are in an iterator
  // iterators are one-pass data structures
  Iterator(EventsCounted(deviceId, newValue))
}
import org.apache.spark.sql.streaming.{GroupStateTimeout, OutputMode}
val signalCounter = signalsByDevice.flatMapGroupsWithState(
  outputMode = OutputMode.Append,
  timeoutConf = GroupStateTimeout.NoTimeout)(func = countValuesPerKey)

import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import scala.concurrent.duration._
val sq = signalCounter.
  writeStream.
  format("console").
  option("truncate", false).
  trigger(Trigger.ProcessingTime(10.seconds)).
  outputMode(OutputMode.Append).
  start
...
-------------------------------------------
Batch: 0
-------------------------------------------
+--------+-----+
|deviceId|count|
+--------+-----+
+--------+-----+
...
17/08/21 08:57:29 INFO StreamExecution: Streaming query made progress: {
  "id" : "a43822a6-500b-4f02-9133-53e9d39eedbf",
  "runId" : "79cb037e-0f28-4faf-a03e-2572b4301afe",
  "name" : null,
  "timestamp" : "2017-08-21T06:57:26.719Z",
  "batchId" : 0,
  "numInputRows" : 0,
  "processedRowsPerSecond" : 0.0,
  "durationMs" : {
    "addBatch" : 2404,
    "getBatch" : 22,
    "getOffset" : 0,
    "queryPlanning" : 141,
    "triggerExecution" : 2626,
    "walCommit" : 41
  },
  "stateOperators" : [ {
    "numRowsTotal" : 0,
    "numRowsUpdated" : 0,
    "memoryUsedBytes" : 12599
  } ],
  "sources" : [ {
    "description" : "RateSource[rowsPerSecond=1, rampUpTimeSeconds=0, numPartitions=8]",
    "startOffset" : null,
    "endOffset" : 0,
    "numInputRows" : 0,
    "processedRowsPerSecond" : 0.0
  } ],
  "sink" : {
    "description" : "ConsoleSink[numRows=20, truncate=false]"
  }
}
17/08/21 08:57:29 DEBUG StreamExecution: batch 0 committed
...
-------------------------------------------
Batch: 1
-------------------------------------------
Device: 3
Signals (1):
0. Signal(2017-08-21 08:57:27.682,1,3)
State: GroupState(<undefined>)
Device: 8
Signals (1):
0. Signal(2017-08-21 08:57:26.682,0,8)
State: GroupState(<undefined>)
Device: 7
Signals (1):
0. Signal(2017-08-21 08:57:28.682,2,7)
State: GroupState(<undefined>)
+--------+-----+
|deviceId|count|
+--------+-----+
|3       |1    |
|8       |1    |
|7       |1    |
+--------+-----+
...
17/08/21 08:57:31 INFO StreamExecution: Streaming query made progress: {
  "id" : "a43822a6-500b-4f02-9133-53e9d39eedbf",
  "runId" : "79cb037e-0f28-4faf-a03e-2572b4301afe",
  "name" : null,
  "timestamp" : "2017-08-21T06:57:30.004Z",
  "batchId" : 1,
  "numInputRows" : 3,
  "inputRowsPerSecond" : 0.91324200913242,
  "processedRowsPerSecond" : 2.2388059701492535,
  "durationMs" : {
    "addBatch" : 1245,
    "getBatch" : 22,
    "getOffset" : 0,
    "queryPlanning" : 23,
    "triggerExecution" : 1340,
    "walCommit" : 44
  },
  "stateOperators" : [ {
    "numRowsTotal" : 3,
    "numRowsUpdated" : 3,
    "memoryUsedBytes" : 18095
  } ],
  "sources" : [ {
    "description" : "RateSource[rowsPerSecond=1, rampUpTimeSeconds=0, numPartitions=8]",
    "startOffset" : 0,
    "endOffset" : 3,
    "numInputRows" : 3,
    "inputRowsPerSecond" : 0.91324200913242,
    "processedRowsPerSecond" : 2.2388059701492535
  } ],
  "sink" : {
    "description" : "ConsoleSink[numRows=20, truncate=false]"
  }
}
17/08/21 08:57:31 DEBUG StreamExecution: batch 1 committed
...
-------------------------------------------
Batch: 2
-------------------------------------------
Device: 1
Signals (1):
0. Signal(2017-08-21 08:57:36.682,0,1)
State: GroupState(<undefined>)
Device: 3
Signals (2):
0. Signal(2017-08-21 08:57:32.682,6,3)
1. Signal(2017-08-21 08:57:35.682,9,3)
State: GroupState(Map(3 -> 1))
Device: 5
Signals (1):
0. Signal(2017-08-21 08:57:34.682,8,5)
State: GroupState(<undefined>)
Device: 4
Signals (1):
0. Signal(2017-08-21 08:57:29.682,3,4)
State: GroupState(<undefined>)
Device: 8
Signals (2):
0. Signal(2017-08-21 08:57:31.682,5,8)
1. Signal(2017-08-21 08:57:33.682,7,8)
State: GroupState(Map(8 -> 1))
Device: 7
Signals (2):
0. Signal(2017-08-21 08:57:30.682,4,7)
1. Signal(2017-08-21 08:57:37.682,1,7)
State: GroupState(Map(7 -> 1))
Device: 0
Signals (1):
0. Signal(2017-08-21 08:57:38.682,2,0)
State: GroupState(<undefined>)
+--------+-----+
|deviceId|count|
+--------+-----+
|1       |1    |
|3       |3    |
|5       |1    |
|4       |1    |
|8       |3    |
|7       |3    |
|0       |1    |
+--------+-----+
...
17/08/21 08:57:41 INFO StreamExecution: Streaming query made progress: {
  "id" : "a43822a6-500b-4f02-9133-53e9d39eedbf",
  "runId" : "79cb037e-0f28-4faf-a03e-2572b4301afe",
  "name" : null,
  "timestamp" : "2017-08-21T06:57:40.005Z",
  "batchId" : 2,
  "numInputRows" : 10,
  "inputRowsPerSecond" : 0.9999000099990002,
  "processedRowsPerSecond" : 9.242144177449168,
  "durationMs" : {
    "addBatch" : 1032,
    "getBatch" : 8,
    "getOffset" : 0,
    "queryPlanning" : 19,
    "triggerExecution" : 1082,
    "walCommit" : 21
  },
  "stateOperators" : [ {
    "numRowsTotal" : 7,
    "numRowsUpdated" : 7,
    "memoryUsedBytes" : 19023
  } ],
  "sources" : [ {
    "description" : "RateSource[rowsPerSecond=1, rampUpTimeSeconds=0, numPartitions=8]",
    "startOffset" : 3,
    "endOffset" : 13,
    "numInputRows" : 10,
    "inputRowsPerSecond" : 0.9999000099990002,
    "processedRowsPerSecond" : 9.242144177449168
  } ],
  "sink" : {
    "description" : "ConsoleSink[numRows=20, truncate=false]"
  }
}
17/08/21 08:57:41 DEBUG StreamExecution: batch 2 committed

// In the end...
sq.stop

// Use stateOperators to access the stats
scala> println(sq.lastProgress.stateOperators(0).prettyJson)
{
  "numRowsTotal" : 7,
  "numRowsUpdated" : 7,
  "memoryUsedBytes" : 19023
}
Trigger—How Frequently to Check Sources For New Data

//Trigger defines how frequently a streaming query should be executed 
//and therefore emit a new data (which StreamExecution uses to resolve a TriggerExecutor).

//Available Triggers  
Trigger
    ProcessingTime
        Trigger.ProcessingTime(long intervalMs)
        Trigger.ProcessingTime(Duration interval)
        Trigger.ProcessingTime(String interval)
    Once
        Trigger.Once

//You specify the trigger for a streaming query using DataStreamWriter's trigger method.
import org.apache.spark.sql.streaming.Trigger
val query = spark.
  readStream.
  format("rate").
  load.
  writeStream.
  format("console").
  option("truncate", false).
  trigger(Trigger.Once). // <-- execute once and stop
  queryName("rate-once").
  start

scala> query.isActive
res0: Boolean = false

scala> println(query.lastProgress)
{
  "id" : "2ae4b0a4-434f-4ca7-a523-4e859c07175b",
  "runId" : "24039ce5-906c-4f90-b6e7-bbb3ec38a1f5",
  "name" : "rate-once",
  "timestamp" : "2017-07-04T18:39:35.998Z",
  "numInputRows" : 0,
  "processedRowsPerSecond" : 0.0,
  "durationMs" : {
    "addBatch" : 1365,
    "getBatch" : 29,
    "getOffset" : 0,
    "queryPlanning" : 285,
    "triggerExecution" : 1742,
    "walCommit" : 40
  },
  "stateOperators" : [ ],
  "sources" : [ {
    "description" : "RateSource[rowsPerSecond=1, rampUpTimeSeconds=0, numPartitions=8]",
    "startOffset" : null,
    "endOffset" : 0,
    "numInputRows" : 0,
    "processedRowsPerSecond" : 0.0
  } ],
  "sink" : {
    "description" : "org.apache.spark.sql.execution.streaming.ConsoleSink@7dbf277"
  }
}

///ForeachSink
foreach(writer: ForeachWriter[T]): DataStreamWriter[T]
//foreach sets the input ForeachWriter to be in control of streaming writes.

//ForeachSink is a typed streaming sink that passes rows (of the type T) to ForeachWriter 
//(one record at a time per partition).
//ForeachSink is assigned a ForeachWriter when DataStreamWriter is started.

//ForeachSink is used exclusively in foreach operator.

//foreach reports an IllegalArgumentException when writer is null.
//foreach writer cannot be null


///ForeachWriter
//ForeachWriter is set using foreach operator.

val foreachWriter = new ForeachWriter[String] { ... }
streamingQuery.
  writeStream.
  foreach(foreachWriter).
  start

//ForeachWriter Contract

package org.apache.spark.sql

abstract class ForeachWriter[T] {
  def open(partitionId: Long, version: Long): Boolean
  def process(value: T): Unit
  def close(errorOrNull: Throwable): Unit
}


//Example 
val records = spark.
  readStream
  format("text").
  load("server-logs/*.out").
  as[String]

import org.apache.spark.sql.ForeachWriter
val writer = new ForeachWriter[String] {
  override def open(partitionId: Long, version: Long) = true
  override def process(value: String) = println(value)
  override def close(errorOrNull: Throwable) = {}
}

records.writeStream
  .queryName("server-logs processor")
  .foreach(writer)
  .start




///*** ML/MLIB - General flow of classification, regression 

1. Feature extractors (generally for Text data)
   Feature selection if input features are of high numbers 
   Feature Transformers to transform input data 
   input data is DF for ML and LabeledPoint for mlib 
   (containing label, features columns - could be dense or sparse Vector ) 
   sparse vector is identified by [#of_features, [indices], [corresponding_values]]
   Note, all feature columns in 2D data are part of only one column 'features' in final DF 
   Use VectorAssembler or sql.functions.array() to merge all seperate feature columns to one 'features' column 
   For ML, use setInputCol/setOutputCol/setLabelCol/setFeaturesCol etc 
   to set columns name for operation 
2. Classification or regression stage of transformed data 
3. if required inverse transformation of step 1
4. Random split input data into training and test 
   Dataset[T].randomSplit(weights: Array[Double]): Array[Dataset[T]] 
   RDD[T].randomSplit(weights: Array[Double], seed: Long = Utils.random.nextLong): Array[RDD[T]] 
5. fit the training data to get 'model' 
6. predictions = model.transform(testData) to get prediction 
   Note in MLIB, call  predict
7. For ML, Use 'evaluate' of MulticlassClassificationEvaluator 
   or BinaryClassificationEvaluator or RegressionEvaluator with above predictions 
   MulticlassClassificationEvaluator supports metricName as "f1" (default), "weightedPrecision", "weightedRecall", "accuracy")
   BinaryClassificationEvaluator (supports "areaUnderROC" (default), "areaUnderPR")
   RegressionEvaluator supports "rmse" (default): root mean squared error,"mse": mean squared error,"r2": R2 metric,"mae": mean absolute error 
7. For MLIB, similarly use many Metrics classes 
   BinaryClassificationMetrics,MulticlassMetrics,MultilabelMetrics,,RegressionMetrics
8. Note for Binary class or regression of test or training data , 
   Use model.summaryto get summary, BinaryLogisticRegressionSummary/LinearRegressionSummary/GeneralizedLinearRegressionSummary from model.summary 
   check 'lazy val' variables which are importants for summary
   BinaryLogisticRegressionSummary have predictions 
   RegressionSummary have pValues, coefficientStandardErrors(form normal solver), residuals, aic (for GLM)

NOTE 
   1. .toDF, .toDS etc are implicits on Seq and RDD 
      primitives, date, timestamp, tuple , case class and  Seq, Array, Map of those only have implicits  Encoders 
      DenseVector and SparseVector donot have Encoders, Wrap them inside Tuple or case class 
   2. For Pipeline, use Pipeline
      For tuning use CrossValidator, TrainValidationSplit along with ParamGridBuilder
      all above and any classification, regression class have .params, .explainParams, .extractParamMap, 
      then use .setParamName to set any params
   3. Pipline,classification, regression class, CrossValidator,TrainValidationSplit trains on 
      'label' and 'fetaures' columns of DF (which is SparseVector or DenseVector of all features- Use VectorAssembler to create such)
      or set those columns by setLabelCol and setFeaturesCol
      Outputs are in generally 'prediction' and 'probability' columns of 'transform' DF 
      or set them by setPredictionCol, setProbabilityCol
    4. Model has .save(path) and ObjectModel.load(path) for saving/loading model 
       Check the model class name, after .fit(dataFrame) 
       

///ML: Default Input Column name in DF  for classifiation, regression 
//Param name  Type(s)     Default     Description
labelCol      Double      "label"     Label to predict 
featuresCol   Vector      "features"  Feature vector 

///ML: Default Output Column name in DF  for classifiation, regression 
//Param name          Type(s)     Default         Description
predictionCol       Double      "prediction"    Predicted label  
rawPredictionCol    Vector      "rawPrediction" Vector of length // classes, with the counts of training instance labels at the tree node which makes the prediction Classification only 
probabilityCol      Vector      "probability"   Vector of length // classes equal to rawPrediction normalized to a multinomial distribution Classification only 
varianceCol         Double                      The biased sample variance of prediction Regression only 
///*** ML : Extracting, transforming and selecting features
// •Extraction: Extracting features from “raw” data
// •Transformation: Scaling, converting, or modifying features
// •Selection: Selecting a subset from a larger set of features

import org.apache.spark.ml.feature._ 
import org.apache.spark.mllib.feature._  //for MLIB 


//Some Transformation works on Column of Vector or convert Vector to Vector or simple element to Vector 

//Before ML regression/classifications, DF has two columns 
//,"label" should be Double and 
//"features" should be vector (dense or Sparse - eg (20,[0,5,9,17],[1.0,1.0,1.0,2.0])  )

//All these have below methods to set in and out columnname
//Applies transformations on input column and result is in output column of DF
def setInputCol(value: String)
def setOutputCol(value: String)
//Additionally , have methods for setting it's paramaters eg 
def setMax(value: Double)
def setMin(value: Double)
//have many methods for manipulating Params 
def explainParams(): String
    Explains all params of this instance.
lazy val params: Array[Param[_]]
    Returns all params sorted by their names.
//Can save and read model 
instance.save(path: String): Unit
Object.load(path: String)
//Might have .fit(inputDF) to get fitted model and model.transform(inputDF) to get output DF 
//if model is not involved , use diretly instance.transform(inputDF) to get output DF 


///Summary - Feature Extractors 
◦TF-IDF     
    Term frequency-inverse document frequency (TF-IDF) is multiplication of TF(HashingTF and CountVectorizer) and IDF 
    Reflects the importance of a term to a document 
    TF - generates the term frequency vectors
    IDF -  it down-weights columns which appear frequently in the corpus 
    ///*Result (in-sentence, tokenizer - words, TF-rawfeatures, out/TF-IDF- features)
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |label|sentence                           |words                                     |rawFeatures                              |features                                                                                                              |
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+
    |0.0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |(20,[0,5,9,17],[1.0,1.0,1.0,2.0])        |(20,[0,5,9,17],[0.6931471805599453,0.6931471805599453,0.28768207245178085,1.3862943611198906])                        |
    |0.0  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|(20,[2,7,9,13,15],[1.0,1.0,3.0,1.0,1.0]) |(20,[2,7,9,13,15],[0.6931471805599453,0.6931471805599453,0.8630462173553426,0.28768207245178085,0.28768207245178085]) |
    |1.0  |Logistic regression models are neat|[logistic, regression, models, are, neat] |(20,[4,6,13,15,18],[1.0,1.0,1.0,1.0,1.0])|(20,[4,6,13,15,18],[0.6931471805599453,0.6931471805599453,0.28768207245178085,0.28768207245178085,0.6931471805599453])|
    +-----+-----------------------------------+------------------------------------------+-----------------------------------------+----------------------------------------------------------------------------------------------------------------------+

◦Word2Vec
    Transforms each column of Vector into a vector using the average of all words in the document
    ///*Result
    +------------------------------------------+----------------------------------------------------------------+
    |text                                      |result                                                          |
    +------------------------------------------+----------------------------------------------------------------+
    |[Hi, I, heard, about, Spark]              |[-0.008142343163490296,0.02051363289356232,0.03255096450448036] |
    |[I, wish, Java, could, use, case, classes]|[0.043090314205203734,0.035048123182994974,0.023512658663094044]|
    |[Logistic, regression, models, are, neat] |[0.038572299480438235,-0.03250147425569594,-0.01552378609776497]|
    +------------------------------------------+----------------------------------------------------------------+

    
◦CountVectorizer
    Converts a collection of text documents to vectors of token counts.
    ///*Result 
    +---+---------------+-------------------------+
    |id |words          |features                 |
    +---+---------------+-------------------------+
    |0  |[a, b, c]      |(3,[0,1,2],[1.0,1.0,1.0])|
    |1  |[a, b, b, c, a]|(3,[0,1,2],[2.0,2.0,1.0])|
    +---+---------------+-------------------------+

///Summary - Feature Transformers 
◦Tokenizer    
    takes text (such as a sentence) and breakes it into individual terms (usually words). 
    ///*Result (RegexTokenizer - .setPattern("\\W"))
    +---+-----------------------------------+------------------------------------------+
    |id |sentence                           |words                                     |
    +---+-----------------------------------+------------------------------------------+
    |0  |Hi I heard about Spark             |[hi, i, heard, about, spark]              |
    |1  |I wish Java could use case classes |[i, wish, java, could, use, case, classes]|
    |2  |Logistic,regression,models,are,neat|[logistic, regression, models, are, neat] |
    +---+-----------------------------------+------------------------------------------+
    
◦StopWordsRemover
    Removes Stop words are words which should be excluded from the input, 
    typically because the words appear frequently and don’t carry as much meaning.
    ///*Result 
    +---+----------------------------+--------------------+
    |id |raw                         |filtered            |
    +---+----------------------------+--------------------+
    |0  |[I, saw, the, red, balloon] |[saw, red, balloon] |
    |1  |[Mary, had, a, little, lamb]|[Mary, little, lamb]|
    +---+----------------------------+--------------------+
    
◦n-gram
     transform input feature/a Column Vector into sequence of n tokens (typically words) for some integer n
     ///*Result - setN(2)
    +---+------------------------------------------+------------------------------------------------------------------+
    |id |words                                     |ngrams                                                            |
    +---+------------------------------------------+------------------------------------------------------------------+
    |0  |[Hi, I, heard, about, Spark]              |[Hi I, I heard, heard about, about Spark]                         |
    |1  |[I, wish, Java, could, use, case, classes]|[I wish, wish Java, Java could, could use, use case, case classes]|
    |2  |[Logistic, regression, models, are, neat] |[Logistic regression, regression models, models are, are neat]    |
    +---+------------------------------------------+------------------------------------------------------------------+

     

◦Binarizer
    Converts numerical features to binary (0/1) features using a threashold
    ///*Result  - setThreshold(0.5)
    +---+-------+-----------------+
    |id |feature|binarized_feature|
    +---+-------+-----------------+
    |0  |0.1    |0.0              |
    |1  |0.8    |1.0              |
    |2  |0.2    |0.0              |
    +---+-------+-----------------+
    
◦PCA
    Converts a set of observations of possibly correlated variables into a set of values 
    of linearly uncorrelated variables called principal components
    ///*Result   - setK(3)  
    +---------------------+-----------------------------------------------------------+
    |features             |pcaFeatures                                                |
    +---------------------+-----------------------------------------------------------+
    |(5,[1,3],[1.0,7.0])  |[1.6485728230883807,-4.013282700516296,-5.524543751369388] |
    |[2.0,0.0,3.0,4.0,5.0]|[-4.645104331781534,-1.1167972663619026,-5.524543751369387]|
    |[4.0,0.0,0.0,6.0,7.0]|[-6.428880535676489,-5.337951427775355,-5.524543751369389] |
    +---------------------+-----------------------------------------------------------+
    
◦PolynomialExpansion
    expands your features into a polynomial space, To include higher degree terms of features 
    which is formulated by an n-degree combination of original dimensions.
    ///*Result - setDegree(3)
    +----------+------------------------------------------+
    |features  |polyFeatures                              |
    +----------+------------------------------------------+
    |[2.0,1.0] |[2.0,4.0,8.0,1.0,2.0,4.0,1.0,2.0,1.0]     |
    |[0.0,0.0] |[0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]     |
    |[3.0,-1.0]|[3.0,9.0,27.0,-1.0,-3.0,-9.0,1.0,3.0,-1.0]|
    +----------+------------------------------------------+
    
◦Discrete Cosine Transform (DCT)
    transforms a length N real-valued Vector Column in the time domain 
    into another length N real-valued Vector Column  in the frequency domain
    /// Result
   +--------------------+----------------------------------------------------------------+
   |features            |featuresDCT                                                     |
   +--------------------+----------------------------------------------------------------+
   |[0.0,1.0,-2.0,3.0]  |[1.0,-1.1480502970952693,2.0000000000000004,-2.7716385975338604]|
   |[-1.0,2.0,4.0,-7.0] |[-1.0,3.378492794482933,-7.000000000000001,2.9301512653149677]  |
   |[14.0,-2.0,-5.0,1.0]|[4.0,9.304453421915744,11.000000000000002,1.5579302036357163]   |
   +--------------------+----------------------------------------------------------------+
 
    
◦StringIndexer
     Encodes a string column of labels to a column of label indices. 
     The indices are in [0, numLabels), ordered by label frequencies, so the most frequent label gets index 0
    ///* Result 
    +---+--------+-------------+
    |id |category|categoryIndex|
    +---+--------+-------------+
    |0  |a       |0.0          |
    |1  |b       |2.0          |
    |2  |c       |1.0          |
    |3  |a       |0.0          |
    |4  |a       |0.0          |
    |5  |c       |1.0          |
    +---+--------+-------------+
   
◦IndexToString
     Converts column of label indices back to a column containing the original labels as strings
    ///* Result 
    +---+--------+-------------+----------------+
    |id |category|categoryIndex|originalCategory|
    +---+--------+-------------+----------------+
    |0  |a       |0.0          |a               |
    |1  |b       |2.0          |b               |
    |2  |c       |1.0          |c               |
    |3  |a       |0.0          |a               |
    |4  |a       |0.0          |a               |
    |5  |c       |1.0          |c               |
    +---+--------+-------------+----------------+
 
 
◦OneHotEncoder
    maps a column of label indices to a column of binary vectors, with at most a single one-value
    This encoding allows algorithms which expect continuous features, such as Logistic Regression, to use categorical features
    eg Use StringIndexer and the OneHotEncoder to convert string category to column to be used for Logit 
    ///* Result - in:category, StringIndexer:categoryIndex, out:categoryVec
    +---+--------+-------------+-------------+
    |id |category|categoryIndex|categoryVec  |
    +---+--------+-------------+-------------+
    |0  |a       |0.0          |(2,[0],[1.0])|
    |1  |b       |2.0          |(2,[],[])    |
    |2  |c       |1.0          |(2,[1],[1.0])|
    |3  |a       |0.0          |(2,[0],[1.0])|
    |4  |a       |0.0          |(2,[0],[1.0])|
    |5  |c       |1.0          |(2,[1],[1.0])|
    +---+--------+-------------+-------------+
    
◦VectorIndexer
    Takes an input columns of type Vector and a parameter maxCategories 
    Decide which features should be categorical based on the number of distinct values, where features with at most maxCategories are declared categorical.
    Compute 0-based category indices for each categorical feature
    and transform original feature values to indices
    ///* Result - setMaxCategories(2)
    +---+--------------+--------------+
    |id |features      |indexed       |
    +---+--------------+--------------+
    |0  |[1.0,0.5,-1.0]|[0.0,0.0,-1.0]|
    |1  |[1.0,1.0,1.0] |[0.0,1.0,1.0] |
    |2  |[4.0,0.5,2.0] |[1.0,0.0,2.0] |
    +---+--------------+--------------+
    
    
◦Interaction
    takes Vector OR double-valued columns, and generates a single vector column 
    that contains the product of all combinations of one value from each input column
    ///*Result, vec1<- VectorAssembler("id2", "id3", "id4"), vec2 <-VectorAssembler("id5", "id6", "id7")
    // output = interactedCol of vec1 and vec2
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |id1|id2|id3|id4|id5|id6|id7|vec1          |vec2          |interactedCol                                         |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+
    |1  |1  |2  |3  |8  |4  |5  |[1.0,2.0,3.0] |[8.0,4.0,5.0] |[8.0,4.0,5.0,16.0,8.0,10.0,24.0,12.0,15.0]            |
    |2  |4  |3  |8  |7  |9  |8  |[4.0,3.0,8.0] |[7.0,9.0,8.0] |[56.0,72.0,64.0,42.0,54.0,48.0,112.0,144.0,128.0]     |
    |3  |6  |1  |9  |2  |3  |6  |[6.0,1.0,9.0] |[2.0,3.0,6.0] |[36.0,54.0,108.0,6.0,9.0,18.0,54.0,81.0,162.0]        |
    |4  |10 |8  |6  |9  |4  |5  |[10.0,8.0,6.0]|[9.0,4.0,5.0] |[360.0,160.0,200.0,288.0,128.0,160.0,216.0,96.0,120.0]|
    |5  |9  |2  |7  |10 |7  |3  |[9.0,2.0,7.0] |[10.0,7.0,3.0]|[450.0,315.0,135.0,100.0,70.0,30.0,350.0,245.0,105.0] |
    |6  |1  |1  |4  |2  |8  |4  |[1.0,1.0,4.0] |[2.0,8.0,4.0] |[12.0,48.0,24.0,12.0,48.0,24.0,48.0,192.0,96.0]       |
    +---+---+---+---+---+---+---+--------------+--------------+------------------------------------------------------+

◦Normalizer
    transforms a dataset of Vector rows, normalizing each Vector to have p-norm(each Vector = all features)
    ///* Result - setP(1.0)
    +---+--------------+------------------+
    |id |features      |normFeatures      |
    +---+--------------+------------------+
    |0  |[1.0,0.5,-1.0]|[0.4,0.2,-0.4]    |
    |1  |[2.0,1.0,1.0] |[0.5,0.25,0.25]   |
    |2  |[4.0,10.0,2.0]|[0.25,0.625,0.125]|
    +---+--------------+------------------+
 
◦StandardScaler
    transforms a dataset of rows, normalizing each feature(ie Column) 
    to have unit standard deviation and/or zero mean. 
    ///*Result - setWithStd(true),setWithMean(false)
    +---+--------------+------------------------------------------------------------+
    |id |features      |scaledFeatures                                              |
    +---+--------------+------------------------------------------------------------+
    |0  |[1.0,0.5,-1.0]|[0.6546536707079771,0.09352195295828246,-0.6546536707079771]|
    |1  |[2.0,1.0,1.0] |[1.3093073414159542,0.18704390591656492,0.6546536707079771] |
    |2  |[4.0,10.0,2.0]|[2.6186146828319083,1.8704390591656492,1.3093073414159542]  |
    +---+--------------+------------------------------------------------------------+

    
◦MinMaxScaler
    MinMaxScaler transforms a dataset of rows, 
    rescaling each feature(ie Column) to a specific range (often [0, 1]). 
    ///* Result
    +---+--------------+--------------+
    |id |features      |scaledFeatures|
    +---+--------------+--------------+
    |0  |[1.0,0.1,-1.0]|[0.0,0.0,0.0] |
    |1  |[2.0,1.1,1.0] |[0.5,0.1,0.5] |
    |2  |[3.0,10.1,3.0]|[1.0,1.0,1.0] |
    +---+--------------+--------------+

 
◦MaxAbsScaler
    transforms a dataset of rows, rescaling each feature(ie Column) to range [-1, 1]
    ///* Result
    +---+--------------+----------------+
    |id |features      |scaledFeatures  |
    +---+--------------+----------------+
    |0  |[1.0,0.1,-8.0]|[0.25,0.01,-1.0]|
    |1  |[2.0,1.0,-4.0]|[0.5,0.1,-0.5]  |
    |2  |[4.0,10.0,8.0]|[1.0,1.0,1.0]   |
    +---+--------------+----------------+
   
◦Bucketizer
    transforms a column of continuous feature to a column of feature bucket index(after n splits)
    ///*Result - .setSplits(Array(Double.NegativeInfinity, -0.5, 0.0, 0.5, Double.PositiveInfinity))
    +--------+----------------+
    |features|bucketedFeatures|
    +--------+----------------+
    |-999.9  |0.0             |
    |-0.5    |1.0             |
    |-0.3    |1.0             |
    |0.0     |2.0             |
    |0.2     |2.0             |
    |999.9   |3.0             |
    +--------+----------------+



 
◦ElementwiseProduct
    scales each column of the dataset by a scalar multiplier.
    ///*Result with Vectors.dense(0.0, 1.0, 2.0)
    +---+-------------+-----------------+
    |id |vector       |transformedVector|
    +---+-------------+-----------------+
    |a  |[1.0,2.0,3.0]|[0.0,2.0,6.0]    |
    |b  |[4.0,5.0,6.0]|[0.0,5.0,12.0]   |
    +---+-------------+-----------------+
    
◦SQLTransformer
    transforms column via SQL statement 
    ///*Result "SELECT *, (v1 + v2) AS v3, (v1 * v2) AS v4 from __THIS__ "
    +---+---+---+---+----+
    |id |v1 |v2 |v3 |v4  |
    +---+---+---+---+----+
    |0  |1.0|3.0|4.0|3.0 |
    |2  |2.0|5.0|7.0|10.0|
    +---+---+---+---+----+
    
◦VectorAssembler
    combines a given list of columns into a single vector column
    ///*Result - features <- Array("hour", "mobile", "userFeatures")    
    +---+----+------+--------------+-------+-----------------------+
    |id |hour|mobile|userFeatures  |clicked|features               |
    +---+----+------+--------------+-------+-----------------------+
    |0  |18  |1.0   |[0.0,10.0,0.5]|1.0    |[18.0,1.0,0.0,10.0,0.5]|
    +---+----+------+--------------+-------+-----------------------+
    
◦QuantileDiscretizer
    takes a column with continuous feature and outputs a column with binned categorical feature( eg n bin)
    ///*Result - setNumBuckets(3), in= hour, out=result     
    +---+----+------+
    |id |hour|result|
    +---+----+------+
    |0  |18.0|2.0   |
    |1  |19.0|2.0   |
    |2  |8.0 |1.0   |
    |3  |5.0 |1.0   |
    |4  |2.2 |0.0   |
    +---+----+------+

///Summary - Feature Selectors 
◦VectorSlicer
    extracts subfeatures from a vector column.
    ///*Result   - setIndices(Array(1)) or setIndices(Array(1, 2)), in=userFeatures
    +--------------------+-------------+
    |userFeatures        |features     |
    +--------------------+-------------+
    |(3,[0,1],[-2.0,2.3])|(2,[0],[2.3])|
    |[-2.0,2.3,0.0]      |[2.3,0.0]    |
    +--------------------+-------------+
    
◦RFormula
    selects columns specified by an R model formula    
    ~ separate target and terms
    + concat terms, “+ 0” means removing intercept
    - remove a term, “- 1” means removing intercept
    : interaction (multiplication for numeric values, or binarized categorical values)
    . all columns except target
    string input columns will be one-hot encoded, and numeric columns will be cast to doubles
    If the label column is of type string, it will be first transformed to double with StringIndexer. 
    If the label column does not exist in the DataFrame, the output label column will be created from the specified response variable in the formula.
    ///*Result - .setFormula("clicked ~ country + hour").setFeaturesCol("features").setLabelCol("label")
    // hence label = clicked , features = country + hour
    +---+-------+----+-------+--------------+-----+
    |id |country|hour|clicked|features      |label|
    +---+-------+----+-------+--------------+-----+
    |7  |US     |18  |1.0    |[0.0,0.0,18.0]|1.0  |
    |8  |CA     |12  |0.0    |[1.0,0.0,12.0]|0.0  |
    |9  |NZ     |15  |0.0    |[0.0,1.0,15.0]|0.0  |
    +---+-------+----+-------+--------------+-----+

    
◦ChiSqSelector
    uses the Chi-Squared test of independence to decide which features to choose(by numTopFeatures, percentile , fpr)
    ///*Result - .setNumTopFeatures(1)
    // top 1 features selected, out=    selectedFeatures, in=features
    +---+------------------+-------+----------------+
    |id |features          |clicked|selectedFeatures|
    +---+------------------+-------+----------------+
    |7  |[0.0,0.0,18.0,1.0]|1.0    |[18.0]          |
    |8  |[0.0,1.0,12.0,0.0]|0.0    |[12.0]          |
    |9  |[1.0,0.0,15.0,0.1]|0.0    |[15.0]          |
    +---+------------------+-------+----------------+
    
◦Userdefined Transformer 
    eg Add a constant term to input via extending UnaryTransformer
    ///*Result - setShift(0.5)
    +-----+------+
    |input|output|
    +-----+------+
    |0.0  |0.5   |
    |1.0  |1.5   |
    |2.0  |2.5   |
    |3.0  |3.5   |
    |4.0  |4.5   |
    +-----+------+
    
◦Locality Sensitive Hashing
    a class of hashing techniques
    Two algorithms 
        Bucketed Random Projection for Euclidean Distance(hash bucket based on Euclidian distance)
        MinHash for Jaccard Distance 
    Various operations possibles
    Example - Bucketed Random Projection for Euclidean Distance
    ///* Result - .setBucketLength(2.0).setNumHashTables(3), in=keys, out=values 
    +---+-----------+-----------------------+
    |id |keys       |values                 |
    +---+-----------+-----------------------+
    |0  |[1.0,1.0]  |[[0.0], [0.0], [-1.0]] |
    |1  |[1.0,-1.0] |[[-1.0], [-1.0], [0.0]]|
    |2  |[-1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    |3  |[-1.0,1.0] |[[0.0], [0.0], [-1.0]] |
    +---+-----------+-----------------------+

    +---+----------+-----------------------+
    |id |keys      |values                 |
    +---+----------+-----------------------+
    |4  |[1.0,0.0] |[[0.0], [-1.0], [-1.0]]|
    |5  |[-1.0,0.0]|[[-1.0], [0.0], [0.0]] |
    |6  |[0.0,1.0] |[[0.0], [0.0], [-1.0]] |
    |7  |[0.0,-1.0]|[[-1.0], [-1.0], [0.0]]|
    +---+----------+-----------------------+
    ///*Result - Approximate similarity join with threashold= 1.5 
    // in= datasetA,datasetB (from above), out= below full DF 
    //check each row, eg id 1 is joined with id 4 with distCol = 1.0 (min)
    +---------------------------------------------------+--------------------------------------------------+-------+
    |datasetA                                           |datasetB                                          |distCol|
    +---------------------------------------------------+--------------------------------------------------+-------+
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[1,[1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])] |[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    |[0,[1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]   |[4,[1.0,0.0],WrappedArray([0.0], [-1.0], [-1.0])] |1.0    |
    |[3,[-1.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |[6,[0.0,1.0],WrappedArray([0.0], [0.0], [-1.0])]  |1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[7,[0.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|1.0    |
    |[2,[-1.0,-1.0],WrappedArray([-1.0], [-1.0], [0.0])]|[5,[-1.0,0.0],WrappedArray([-1.0], [0.0], [0.0])] |1.0    |
    +---------------------------------------------------+--------------------------------------------------+-------+
    ///*Result - Approximate nearest neighbor search, for Vectors.dense(1.0, 0.0)
    ///in= datsetA(from above), out= below DF showing which ids are nearer via distCol=1.0 min 
    +---+----------+-----------------------+-------+
    |id |keys      |values                 |distCol|
    +---+----------+-----------------------+-------+
    |1  |[1.0,-1.0]|[[-1.0], [-1.0], [0.0]]|1.0    |
    |0  |[1.0,1.0] |[[0.0], [0.0], [-1.0]] |1.0    |
    +---+----------+-----------------------+-------+
    



///+++ Intro Spark MLlib
///Extra Methods in Mlib 
org.apache.spark.mllib.linalg 
    object Vectors //factory methods 
        def fromJson(json: String): Vector
            Parses the JSON representation of a vector into a Vector.
        def fromML(v: ml.linalg.Vector): Vector
            Convert new linalg type to spark.mllib type.
    DenseVector 
        def asML: ml.linalg.DenseVector
            Convert this vector to the new mllib-local representation.
        def toJson: String
            Converts the vector to a JSON string.
        object DenseVector
            def fromML(v: ml.linalg.DenseVector): DenseVector
                Convert new linalg type to spark.mllib type.
    SparseVector 
        def asML: ml.linalg.SparseVector
            Convert this vector to the new mllib-local representation.
        def toJson: String
            Converts the vector to a JSON string.
        object SparseVector 
            def fromML(v: ml.linalg.SparseVector): SparseVector
                Convert new linalg type to spark.mllib type.        
    object Matrices //factory method 
        def fromML(m: ml.linalg.Matrix): Matrix
            Convert new linalg type to spark.mllib type.
    DenseMatrix
        def asML: ml.linalg.DenseMatrix
            Convert this matrix to the new mllib-local representation.
        object DenseMatrix
            def fromML(m: ml.linalg.DenseMatrix): DenseMatrix
                Convert new linalg type to spark.mllib type.
    SparseMatrix
        def asML: ml.linalg.SparseMatrix
            Convert this matrix to the new mllib-local representation.
        object SParseMatrix 
            def fromML(m: ml.linalg.SparseMatrix): SparseMatrix
                Convert new linalg type to spark.mllib type.       
// ML types 
org.apache.spark.ml.linalg 
    object Vectors //Factory methods
        def dense(values: Array[Double]): Vector
        def dense(firstValue: Double, otherValues: Double*): Vector
            Vectors.dense(Array(1.0, 2.0))
        def norm(vector: Vector, p: Double): Double
        def sparse(size: Int, elements: Iterable[(Integer, Double)]): Vector
        def sparse(size: Int, elements: Seq[(Int, Double)]): Vector
        def sparse(size: Int, indices: Array[Int], values: Array[Double]): Vector
            >>> Vectors.sparse(4, List((1, 1.0), (3, 5.5)))
            SparseVector(4, {1: 1.0, 3: 5.5})
            >>> Vectors.sparse(4, Array(1, 3), Array(1.0, 5.5))
            SparseVector(4, {1: 1.0, 3: 5.5})
        def sqdist(v1: Vector, v2: Vector): Double
        def zeros(size: Int): Vector
    DenseVector(ar)
        Column-major dense matrix.
        == for equality and (Int) for indexing
        new DenseVector(values: Array[Double])
        def apply(i: Int): Double
            Gets the value of the ith element.
        def argmax: Int
            Find the index of a maximal element.
        def compressed: Vector
            Returns a vector in either dense or sparse format, whichever uses less storage.
        def copy: DenseVector
            Makes a deep copy of this vector.
        def equals(other: Any): Boolean
        def foreachActive(f: (Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse vector.
        def hashCode(): Int
            Returns a hash code value for the vector.
        def numActives: Int
            Number of active entries.
        def numNonzeros: Int
            Number of nonzero elements.
        def size: Int
            Size of the vector.
        def toArray: Array[Double]
            Converts the instance to a double array.
        def toDense: DenseVector
            Converts this vector to a dense vector.
        def toSparse: SparseVector
            Converts this vector to a sparse vector with all explicit zeros removed.
        def toString(): String
        val values: Array[Double] 
        object DenseVector.unapply(dv: DenseVector): Option[Array[Double]] 
            extractor 
    SparseVector(size, *args)
        Sparse Vector, == and (Int) for indexing 
            new SparseVector(size: Int, indices: Array[Int], values: Array[Double])
        def apply(i: Int): Double
            Gets the value of the ith element.
        def argmax: Int
            Find the index of a maximal element.
        def compressed: Vector
            Returns a vector in either dense or sparse format, whichever uses less storage.
        def copy: SparseVector
            Makes a deep copy of this vector.
        def equals(other: Any): Boolean
        def foreachActive(f: (Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse vector.
        def hashCode(): Int
            Returns a hash code value for the vector.
        val indices: Array[Int]
            index array, assume to be strictly increasing.
        def numActives: Int
            Number of active entries.
        def numNonzeros: Int
            Number of nonzero elements.
        val size: Int
            size of the vector.
        def toArray: Array[Double]
            Converts the instance to a double array.
        def toDense: DenseVector
            Converts this vector to a dense vector.
        def toSparse: SparseVector
            Converts this vector to a sparse vector with all explicit zeros removed.
        def toString(): String
        val values: Array[Double]
            value array, must have the same length as the index array.
        object SparseVector.unapply(sv: SparseVector): Option[(Int, Array[Int], Array[Double])] 
            Extractor
    object Matrices #factory 
        def dense(numRows: Int, numCols: Int, values: Array[Double]): Matrix
            Creates a column-major dense matrix.
            Example:
                1.0 2.0
                3.0 4.0
                5.0 6.0
            is stored as [1.0, 3.0, 5.0, 2.0, 4.0, 6.0]. 
        def sparse(numRows: Int, numCols: Int, colPtrs: Array[Int], rowIndices: Array[Int], values: Array[Double]): Matrix
            Creates a column-major sparse matrix in Compressed Sparse Column (CSC) format.
            Example- following matrix
                1.0 0.0 4.0
                0.0 3.0 5.0
                2.0 0.0 6.0
            is stored as values: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0], 
            numRows = 3 , numCols = 3
            rowIndices=[0, 2, 1, 0, 1, 2], row index of each from values
            colPointers=[0, 2, 3, 6] , index of values where col number changes     
        def diag(vector: Vector): Matrix
            Generate a diagonal matrix in Matrix format from the supplied values.
        def eye(n: Int): Matrix
            Generate a dense Identity Matrix in Matrix format.
        def horzcat(matrices: Array[Matrix]): Matrix
            Horizontally concatenate a sequence of matrices.
        def vertcat(matrices: Array[Matrix]): Matrix
            Vertically concatenate a sequence of matrices.
        def ones(numRows: Int, numCols: Int): Matrix
            Generate a DenseMatrix consisting of ones.
        def rand(numRows: Int, numCols: Int, rng: Random): Matrix
            Generate a DenseMatrix consisting of i.i.d. uniform random numbers.
        def randn(numRows: Int, numCols: Int, rng: Random): Matrix
            Generate a DenseMatrix consisting of i.i.d. gaussian random numbers.
        def speye(n: Int): Matrix
            Generate a sparse Identity Matrix in Matrix format.
        def sprand(numRows: Int, numCols: Int, density: Double, rng: Random): Matrix
            Generate a SparseMatrix consisting of i.i.d. gaussian random numbers.
        def sprandn(numRows: Int, numCols: Int, density: Double, rng: Random): Matrix
            Generate a SparseMatrix consisting of i.i.d. gaussian random numbers.
        def zeros(numRows: Int, numCols: Int): Matrix
            Generate a Matrix consisting of zeros.
    DenseMatrix
        Dense matrix of column major order, 
        has == and (Int,Int) for indexing 
        new DenseMatrix(numRows: Int, numCols: Int, values: Array[Double])
        new DenseMatrix(numRows: Int, numCols: Int, values: Array[Double], isTransposed: Boolean)
        def apply(i: Int, j: Int): Double
            Gets the (i, j)-th element.
        def colIter: Iterator[Vector]
            Returns an iterator of column vectors.
        def compressed: Matrix
            Returns a matrix in dense column major, dense row major, sparse row major, or sparse column major format, whichever uses less storage.
        def compressedColMajor: Matrix
            Returns a matrix in dense or sparse column major format, whichever uses less storage.
        def compressedRowMajor: Matrix
            Returns a matrix in dense or sparse row major format, whichever uses less storage.
        def copy: DenseMatrix
            Get a deep copy of the matrix.
        def equals(o: Any): Boolean
        def foreachActive(f: (Int, Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse matrix.
        def hashCode(): Int
        val isTransposed: Boolean
            whether the matrix is transposed.
        def multiply(y: Vector): DenseVector
            Convenience method for Matrix-Vector multiplication.
        def multiply(y: DenseVector): DenseVector
            Convenience method for Matrix-DenseVector multiplication.
        def multiply(y: DenseMatrix): DenseMatrix
            Convenience method for Matrix-DenseMatrix multiplication.
        def numActives: Int
            Find the number of values stored explicitly.
        val numCols: Int
            number of columns
        def numNonzeros: Int
            Find the number of non-zero active values.
        val numRows: Int
            number of rows
        def rowIter: Iterator[Vector]
            Returns an iterator of row vectors.
        def toArray: Array[Double]
            Converts to a dense array in column major.
        def toDense: DenseMatrix
            Converts this matrix to a dense matrix while maintaining the layout of the current matrix.
        def toDenseColMajor: DenseMatrix
            Converts this matrix to a dense matrix in column major order.
        def toDenseRowMajor: DenseMatrix
            Converts this matrix to a dense matrix in row major order.
        def toSparse: SparseMatrix
            Converts this matrix to a sparse matrix while maintaining the layout of the current matrix.
        def toSparseColMajor: SparseMatrix
            Converts this matrix to a sparse matrix in column major order.
        def toSparseRowMajor: SparseMatrix
            Converts this matrix to a sparse matrix in row major order.
        def toString(maxLines: Int, maxLineWidth: Int): String
            A human readable representation of the matrix with maximum lines and width
        def toString(): String
            A human readable representation of the matrix
        def transpose: DenseMatrix
            Transpose the Matrix.
        val values: Array[Double]
            matrix entries in column major if not transposed or in row major otherwise
        object DenseMatrix
            def diag(vector: Vector): DenseMatrix
                Generate a diagonal matrix in DenseMatrix format from the supplied values.
            def eye(n: Int): DenseMatrix
                Generate an Identity Matrix in DenseMatrix format.
            def ones(numRows: Int, numCols: Int): DenseMatrix
                Generate a DenseMatrix consisting of ones.
            def rand(numRows: Int, numCols: Int, rng: Random): DenseMatrix
                Generate a DenseMatrix consisting of i.i.d. uniform random numbers.
            def randn(numRows: Int, numCols: Int, rng: Random): DenseMatrix
                Generate a DenseMatrix consisting of i.i.d. gaussian random numbers.
            def zeros(numRows: Int, numCols: Int): DenseMatrix
                Generate a DenseMatrix consisting of zeros.        
    SparseMatrix
        Sparse matrix in CSC format, has == and (Int,Int) for indexing 
        new SparseMatrix(numRows: Int, numCols: Int, colPtrs: Array[Int], rowIndices: Array[Int], values: Array[Double])
        new SparseMatrix(numRows: Int, numCols: Int, colPtrs: Array[Int], rowIndices: Array[Int], values: Array[Double], isTransposed: Boolean)
        def apply(i: Int, j: Int): Double
            Gets the (i, j)-th element.
        def colIter: Iterator[Vector]
            Returns an iterator of column vectors.
        val colPtrs: Array[Int]
            the index corresponding to the start of a new column (if not transposed)
        def compressed: Matrix
            Returns a matrix in dense column major, dense row major, sparse row major, or sparse column major format, whichever uses less storage.
        def compressedColMajor: Matrix
            Returns a matrix in dense or sparse column major format, whichever uses less storage.
        def compressedRowMajor: Matrix
            Returns a matrix in dense or sparse row major format, whichever uses less storage.
        def copy: SparseMatrix
            Get a deep copy of the matrix.
        def equals(o: Any): Boolean
        def foreachActive(f: (Int, Int, Double) => Unit): Unit
            Applies a function f to all the active elements of dense and sparse matrix.
        def hashCode(): Int
        val isTransposed: Boolean
            whether the matrix is transposed.
        def multiply(y: Vector): DenseVector
            Convenience method for Matrix-Vector multiplication.
        def multiply(y: DenseVector): DenseVector
            Convenience method for Matrix-DenseVector multiplication.
        def multiply(y: DenseMatrix): DenseMatrix
            Convenience method for Matrix-DenseMatrix multiplication.
        def numActives: Int
            Find the number of values stored explicitly.
        val numCols: Int
            number of columns
        def numNonzeros: Int
            Find the number of non-zero active values.
        val numRows: Int
            number of rows
        val rowIndices: Array[Int]
            the row index of the entry (if not transposed).
        def rowIter: Iterator[Vector]
            Returns an iterator of row vectors.
        def toArray: Array[Double]
            Converts to a dense array in column major.
        def toDense: DenseMatrix
            Converts this matrix to a dense matrix while maintaining the layout of the current matrix.
        def toDenseColMajor: DenseMatrix
            Converts this matrix to a dense matrix in column major order.
        def toDenseRowMajor: DenseMatrix
            Converts this matrix to a dense matrix in row major order.
        def toSparse: SparseMatrix
            Converts this matrix to a sparse matrix while maintaining the layout of the current matrix.
        def toSparseColMajor: SparseMatrix
            Converts this matrix to a sparse matrix in column major order.
        def toSparseRowMajor: SparseMatrix
            Converts this matrix to a sparse matrix in row major order.
        def toString(maxLines: Int, maxLineWidth: Int): String
            A human readable representation of the matrix with maximum lines and width
        def toString(): String
            A human readable representation of the matrix
        def transpose: SparseMatrix
            Transpose the Matrix.
        val values: Array[Double]
            nonzero matrix entries in column major (if not transposed)
        object SparseMatrix
            def fromCOO(numRows: Int, numCols: Int, entries: Iterable[(Int, Int, Double)]): SparseMatrix
                Generate a SparseMatrix from Coordinate List (COO) format.
            def spdiag(vector: Vector): SparseMatrix
                Generate a diagonal matrix in SparseMatrix format from the supplied values.
            def speye(n: Int): SparseMatrix
                Generate an Identity Matrix in SparseMatrix format.
            def sprand(numRows: Int, numCols: Int, density: Double, rng: Random): SparseMatrix
                Generate a SparseMatrix consisting of i.i.d.
            def sprandn(numRows: Int, numCols: Int, density: Double, rng: Random): SparseMatrix
                Generate a SparseMatrix consisting of i.i.d.

                
                

//Example - Boston Housing Price Prediction - GradientBoostingRegressor
//Note in GradientBoostedTrees - In Python, predict cannot currently be used within an RDD transformation or action. Call predict directly on the RDD instead.
 
 


// Load data
//"crim","zn","indus","chas","nox","rm","age","dis","rad","tax","ptratio","b","lstat","medv"
val data =  spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\boston.csv")
headers 

val assembler = new VectorAssembler().setInputCols(data.columns.init).setOutputCol("features")
val df = assembler.transform(data).select($"features", $"medv")
val dataRdd = df.rdd.map( row => LabeledPoint(row.getDouble(1), Vectors.dense(row.getAs[ML.DenseVector](0).toArray)))
val Array(trainingData, testData) = dataRdd.randomSplit(Array(3.0,1.0), 24)



// Train a GradientBoostedTrees model.
//  Notes: (a) Empty categoricalFeaturesInfo indicates all features are continuous.
//           OR dict(0=2, 4=10) specifies that feature 0 is binary (taking values 0 or 1) and that feature 4 has 10 categories (values {0, 1, ..., 9})
//         (b) Use more iterations in practice.

// The defaultParams for Regression use SquaredError by default.
import org.apache.spark.mllib.tree.configuration.BoostingStrategy
val boostingStrategy = BoostingStrategy.defaultParams("Regression")
boostingStrategy.numIterations = 3 // Note: Use more iterations in practice.
boostingStrategy.treeStrategy.maxDepth = 5
// Empty categoricalFeaturesInfo indicates all features are continuous.
boostingStrategy.treeStrategy.categoricalFeaturesInfo = Map[Int, Int]()

val model = GradientBoostedTrees.train(trainingData, boostingStrategy)


val predTrain =model.predict(trainingData.map(point => point.features))
val vAPTrain = predTrain.zip(trainingData.map(point => point.label))
val metrics =  new org.apache.spark.mllib.evaluation.RegressionMetrics(vAPTrain) //predictionAndObservations: RDD[(Double, Double)]
metrics.r2 


// Evaluate model on test instances and compute test error
val predictions =model.predict(testData.map(point => point.features))
val valuesAndPreds =predictions.zip(testData.map(point => point.label))
val metrics = new org.apache.spark.mllib.evaluation.RegressionMetrics(valuesAndPreds)
metrics.r2
    
// Squared Error
print("MSE = %s" % metrics.meanSquaredError)
print("RMSE = %s" % metrics.rootMeanSquaredError)
// R-squared
print("R-squared = %s" % metrics.r2)
// Mean absolute error
print("MAE = %s" % metrics.meanAbsoluteError)
// Explained variance
print("Explained variance = %s" % metrics.explainedVariance)




//Example - Iris Classifications  - GradientBoostedTrees
//Binary and Multiclass(set numClasses)
    LogisticRegressionWithLBFGS
    DecisionTree
    RandomForest
//Only Binary 
    LogisticRegressionWithSGDD
    SVMWithSGD
    NaiveBayes
    GradientBoostedTrees


//Example 
from sklearn import datasets

// Load data
val data =  spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\iris.csv")


val assembler = new VectorAssembler().setInputCols(data.columns.init).setOutputCol("features")
val df_temp = assembler.transform(data).select($"features", $"Name")

//Convert Name string to indexes 
val indexer = new StringIndexer().setInputCol("Name").setOutputCol("target")
val df = indexer.fit(df_temp).transform(df_temp).select('features, 'target)

val dataRdd = df.rdd.map( row => LabeledPoint(row.getDouble(1), Vectors.dense(row.getAs[ML.DenseVector](0).toArray)))

val Array(trainingData, testData) = dataRdd.randomSplit(Array(3.0,1.0), 24)



// Train a GradientBoostedTrees model.
//  Notes: (a) Empty categoricalFeaturesInfo indicates all features are continuous.
//           OR dict(0=2, 4=10) specifies that feature 0 is binary (taking values 0 or 1) and that feature 4 has 10 categories (values {0, 1, ..., 9})
//         (b) Use more iterations in practice.
// Train a RandomForest model.
// Empty categoricalFeaturesInfo indicates all features are continuous.
val numClasses = 3
val categoricalFeaturesInfo = Map[Int, Int]()
val numTrees = 3 // Use more in practice.
val featureSubsetStrategy = "auto" // Let the algorithm choose.
val impurity = "gini"
val maxDepth = 4
val maxBins = 32

val model = RandomForest.trainClassifier(trainingData, numClasses, categoricalFeaturesInfo,
  numTrees, featureSubsetStrategy, impurity, maxDepth, maxBins)


// Train error 
val predictions =model.predict(trainingData.map(point => point.features))
val predictionAndLabels =predictions.zip(trainingData.map(point => point.label))
val metrics = new MulticlassMetrics(predictionAndLabels)
>>> metrics.labels
res14: Array[Double] = Array(0.0, 1.0, 2.0)
//fMeasure(label=None, beta=None) , generally beta=2 or 0.5 for F2 or F0.5 
metrics.labels.map( e => metrics.fMeasure(e))


// Evaluate model on test instances and compute test error
val predictions =model.predict(testData.map(point => point.features))
val predictionAndLabels =predictions.zip(testData.map(point => point.label))
val metrics = new MulticlassMetrics(predictionAndLabels)
//fMeasure(label=None, beta=None) , generally beta=2 or 0.5 for F2 or F0.5 
metrics.labels.map( e => metrics.fMeasure(e))
    
// Squared Error, below all takes Label 
metrics.confusionMatrix
res23: org.apache.spark.mllib.linalg.Matrix =
17.0  0.0   0.0
0.0   11.0  0.0
0.0   4.0   9.0


// Statistics by class
"""
Value 1 is te Best 
confusion matrix 
    for binary: two rows and two columns
    that reports the number of true positives(TP), false negatives(FN), 
    and 2nd row as false positives(FP), and true negatives(TN)
precision 
    the ratio tp / (tp + fp) 
    where tp is the number of true positives and fp the number of false positives. 
    The precision is intuitively the ability of the classifier not to label as positive a sample that is negative.
recall 
    ratio tp / (tp + fn) 
    where tp is the number of true positives and fn the number of false negatives. 
    The recall is intuitively the ability of the classifier to find all the positive samples.
F-beta score
    weighted harmonic mean of the precision and recall, 
    where an F-beta score reaches its best value at 1 and worst score at 0.
    The F-beta score weights recall more than precision by a factor of beta. 
    beta == 1.0 means recall and precision are equally important.
"""

val labels = dataRdd.map(point => point.label).distinct.collect
for(label <- labels.sorted){
    println(s"Class $label precision = ${metrics.precision(label)}")
    println(s"Class $label recall = ${metrics.recall(label)}" )
    println(s"Class $label F1 Measure = ${metrics.fMeasure(label, beta=1.0)}" )
}




///+++ Intro Spark ML


//Example - Boston Housing Price Prediction - GradientBoostingRegressor
//Note in GradientBoostedTrees - In Python, predict cannot currently be used within an RDD transformation or action. Call predict directly on the RDD instead.
 
 
// Load data
//"crim","zn","indus","chas","nox","rm","age","dis","rad","tax","ptratio","b","lstat","medv"
val data =  spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\boston.csv")

//last column is target 
val assembler = new VectorAssembler().setInputCols(data.columns.init).setOutputCol("features")
val df = assembler.transform(data).select($"features", $"medv")
val Array(trainingData, testData) = df.randomSplit(Array(3.0,1.0), 24)




// If data has categorical features 
//Automatically identify categorical features, and index them.
// Set maxCategories so features with > 4 distinct values are treated as continuous.
//In our case all are continuous, hence not needed 
//note this is a transformer, hence call fit
//featureIndexer = new VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)
//gbt = GBTRegressor(featuresCol="indexedFeatures",labelCol="MEDV", predictionCol="prediction", maxIter=10)
//pipeline = Pipeline(stages=[featureIndexer, gbt))
val gbt = new GBTRegressor().
  setLabelCol("medv").
  setFeaturesCol("features").
  setMaxIter(10)

//Pipeline(stages=[Transformer1, Transformer2,...,Estimator1,Estimator2,...]
//Transformer means whihc has .transform method, Estimator is one having .fit and .transform 
val pipeline = new Pipeline().setStages(Array(gbt))

val model =pipeline.fit(trainingData)


//Training error 
val predictions =model.transform(trainingData)
predictions.select("prediction", "medv", "features").show(5)
// rmse - root mean squared error (default) mse - mean squared error r2 - r^2 metric mae - mean absolute error
val evaluator = new RegressionEvaluator().
  setLabelCol("medv").
  setPredictionCol("prediction").
  setMetricName("r2")

val r2 =evaluator.evaluate(predictions) //not so good 


// Test Error 
val predictions =model.transform(testData)
val r2 =evaluator.evaluate(predictions) 


//Tune parameter - Advantage of ML 
//GBTRegressor(featuresCol="features", labelCol="label", predictionCol="prediction", maxDepth=5, maxBins=32, minInstancesPerNode=1, minInfoGain=0.0, maxMemoryInMB=256, cacheNodeIds=False, subsamplingRate=1.0, checkpointInterval=10, lossType="squared", maxIter=20, stepSize=0.1, seed=None, impurity="variance")
gbt.explainParams() //check all parameters 
val paramGrid = new ParamGridBuilder().
    addGrid(gbt.maxDepth, Array(5,3,7)).
    addGrid(gbt.maxIter, Array(10,20,25)).build()

// In this case the estimator is simply the linear regression.
//CrossValidator - expensive, but reliable for small data set, 
// requires an Estimator, a set of Estimator ParamMaps, and an Evaluator.
val tvs = new TrainValidationSplit().
  setEstimator(pipeline).
  setEvaluator(new RegressionEvaluator().setLabelCol("medv").setPredictionCol("prediction").setMetricName("rmse")).
  setEstimatorParamMaps(paramGrid).
  // 80% of the data will be used for training and the remaining 20% for validation.
  setTrainRatio(0.8).
  // Evaluate up to 2 parameter settings in parallel
  setParallelism(2)


// Run TrainValidationSplit, and choose the best set of parameters.
val model = tvs.fit(trainingData)

//Check now 
val predictions =model.transform(testData)
predictions.select("prediction", "medv", "features").show(5)
val evaluator = new RegressionEvaluator().setLabelCol("medv").setPredictionCol("prediction").setMetricName("r2")
val r2 = evaluator.evaluate(predictions)

model.getEstimatorParamMaps() //params for all combination 
model.validationMetrics //metric for each combination 





//Example - Iris Classifications  - GradientBoostedTrees
//Binary and Multiclass(set numClasses)
    LogisticRegression with family="multinomial")
    DecisionTreeClassifier
    RandomForestClassifier
    NaiveBayes with modelType="multinomial"
//Only Binary 
    LinearSVC
    GBTClassifier


//Example 

// Load data
val data =  spark.read.format("csv").option("header", "true").option("inferSchema","true").load(raw"D:\Desktop\PPT\spark\data\iris.csv")

val assembler = new VectorAssembler().setInputCols(data.columns.init).setOutputCol("features")
val df = assembler.transform(data).select($"features", $"Name")





// If label contains string category or number category, this transforms to [0,numlabels)
//In our case target is already processed 
//Note this is Transformer, hence call .fit
val labelIndexer = new StringIndexer().setInputCol("Name").setOutputCol("target").fit(df)

// Automatically identify categorical features, and index them.
// Set maxCategories so features with > 4 distinct values are treated as continuous.
//In our case features are continuous
//Note this is Transformer, hence call .fit 
//featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=4).fit(df)

// Train a RandomForest model. Note labelCol, featuresCol 
//this is Estimators 
//rf = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures", numTrees=10)

// Convert indexed labels back to original labels.
//Note later stages has to be Estimators 
val labelConverter = new IndexToString().setInputCol("prediction").setOutputCol("predictedLabel").setLabels(labelIndexer.labels)

// Chain indexers and forest in a Pipeline
//Pipeline(stages=[Transformer1, Transformer2,...,Estimator1,Estimator2,...]
//Transformer means whihc has .transform method, Estimator is one having .fit and .transform 
//pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf, labelConverter))




val Array(trainingData, testData) = df.randomSplit(Array(3.0,1.0), 24)

val rf = new RandomForestClassifier().
  setLabelCol("target").
  setFeaturesCol("features").
  setNumTrees(10)

  
val pipeline = new Pipeline().setStages(Array(labelIndexer, rf, labelConverter))

// Train model.  This also runs the indexers.
val model =pipeline.fit(trainingData)

// Training error 
val predictions =model.transform(trainingData)
predictions.select("prediction", "target", "features").show(5)
//f1|weightedPrecision|weightedRecall|accuracy)
//f1 means weightedFMeasure ie  averages of all labels, ie fMeasure(category, beta) * count.toDouble / labelCount

val evaluator = new MulticlassClassificationEvaluator().
  setLabelCol("target").
  setPredictionCol("prediction").
  setMetricName("f1")
val f1 =evaluator.evaluate(predictions)


//Test Error 
val predictions = model.transform(testData)
val f1 = evaluator.evaluate(predictions)












    
///+++ Spark UI 
Mastering_spark.docx
    Spark UI and Spark History Server
        If pyspark is running, then check http://driver_host:4040/
        OR start pyspark/spark-submit with --conf spark.eventLog.enabled 
        If history server(http://ipwhereHSstarted:18080) is running, note spark.history.fs.logDirectory and spark.eventLog.dir
        are to be same(by default - same and at file:///tmp/spark-events)
        For clustered environment, use HDFS 
        
///+++ Cluster deployment 
Mastering_spark.docx
    Spark Standalone Mode
        check https://spark.apache.org/docs/latest/submitting-applications.html
        Main Configuration:
            Cluster: driver runs in worker(stdout in SPARK_WORKER_DIR), client: driver runs in laptop(stdout in laptop)
              --master spark://207.184.161.138:7077 \
              --deploy-mode cluster \ //client 
              --supervise \ //only for cluster 
              --executor-memory 20G \
              --total-executor-cores 100 \ //total cores in whole cluster 
        Resource Scheduling
            FIFO 
            spark.cores.max configures max cores to be used by an application 
            spark.deploy.defaultCores is default number of core if application does not specify spark.cores.max
        Recovery mode 
    Running Spark on YARN
        Make HADOOP_CONF_DIR is in classpath, eg in, conf/spark-env.sh
        Note core_site.xml, default FS would be effective 
        Cluster: driver runs in Application master(stdout in SPARK_WORKER_DIR), client: driver runs in laptop(stdout in laptop)
        Main configuration(calculation in seperate thread)
            --master yarn \
            --deploy-mode cluster or client 
            --driver-memory 3g      //heapsize for driver , use only in cluster mode, for client mode = keep the default of spark.yarn.am.memory 
            --executor-memory 20G   //heapsize for each executor
            --num-executors 50      //how many total executors in cluster 
            --executor-cores 6      //no of core per executor ie how many tasks  per executors 
            --conf "spark.eventLog.enabled=true" 
            --conf "spark.driver.maxResultSize=2g"  //max size for handling result in driver eg for collect 
            --driver-cores 2        //only for cluster mode , client mode=keep the default spark.yarn.am.cores 
            --jars "jar1.jat,jar2.jar,..." //jars transfered to cluster and are included on the driver and executor classpaths.    

    

///++++++ Spark Scheduling
Mastering_spark.docx
    Across Applications and Within application job Scheduling
    
    
        
        
        
///+++ Performance Characteristics and Tuning
Apache Spark 2 Tuning .pdf
    Factors to consider for Spark performance tuning - onwards 
Mastering_spark.docx
    Spark Performance Tuning: A Checklist


///+++ Managing and Estimating cluster resource requirements
Mastering_spark.docx
        Spark Memory Management
        Estimating cluster resource requirements
