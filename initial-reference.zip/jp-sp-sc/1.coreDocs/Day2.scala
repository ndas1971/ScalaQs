"""
DAY-2 
    Functional programming 
    FP with Scala Collection  
    Stream, parallel, lazy collection
    Traits, Mixin class Composition
    Functional error handling - Option, Try
"""

///*** Functional programming - anonymous functions

//Various ways to write anonymous functions
val x = List.range(1, 10)

//foreach takes a function , for multiline use { } instead of ()
x.foreach((i:Int) => println(i))
x.foreach((i) => println(i))
x.foreach{i => println(i)} //or for single arg, for many arg, use (...) tuple format 
x.foreach(println(_))   //partial application
x.foreach(println _ )   //conversion to FunctionN
x.foreach(println)
x foreach println

//It is also possible to define functions with multiple parameters:
(x: Int, y: Int) => "(" + x + ", " + y + ")"  //type is  Function2, (Int, Int) => String

//or with no parameter:
() => { System.getProperty("user.dir") }   // type is () => String


//Note to convert def to FunctionN for use _ 
scala> def f(x:Int) = x*x
f: (x: Int)Int

scala> f _
res0: Int => Int = <function1>



///*** object  Function  
//A module defining utility methods for higher-order functional programming. 

def chain[a](fs: Seq[(a) => a]): (a) => a 
    Given a sequence of functions f1, ..., fn, 
    return the function f1 andThen ... andThen fn.
def  const[T, U](x: T)(y: U): T 
    The constant function, returns x
def tupled[a1, a2, b](f: (a1, a2) => b): ((a1, a2)) => b 
    Tupling for functions of arity 2. 
    (available till arity 5)
def uncurried[a1, a2, b](f: (a1) => (a2) => b): (a1, a2) => b 
    Uncurrying for functions of arity 2.
    (available till arity 5)
def unlift[T, R](f: (T) => Option[R]): PartialFunction[T, R] 
    Turns a function T => Option[R] into a PartialFunction[T, R].
def untupled[a1, a2, b](f: ((a1, a2)) => b): (a1, a2) => b 
    Un-tupling for functions of arity 2.
    (available till arity 5)



///*** class Function1 
trait Function1[-T1, +R] extends AnyRef 
    abstract def apply(v1: T1): R
        Apply the body of this function to the argument.
    //Concrete Value Members
    def andThen[A](g: (R) => A): (T1) => A
        Composes two instances of Function1 in a new Function1, 
        with this function applied first.
    def compose[A](g: (A) => T1): (A) => R
        Composes two instances of Function1 in a new Function1, 
        with this function applied last.
    def toString(): String
        Creates a String representation of this object.
        
trait Function2[-T1, -T2, +R] extends AnyRef 
    abstract def apply(v1: T1, v2: T2): R
        Apply the body of this function to the arguments.
    //Concrete Value Members
    def curried: (T1) => (T2) => R
        Creates a curried version of this function.
    def toString(): String
        Creates a String representation of this object.
    def tupled: ((T1, T2)) => R
        Creates a tupled version of this function: 
        instead of 2 arguments, it accepts a single scala.Tuple2 argument. 

        
//Function1- one parameter Function, available till 22 parameters ie Function22
val succ = (x: Int) => x + 1
//OR
val anonfun1 = new Function1[Int, Int] {   //type is Int => Int
     def apply(x: Int): Int = x + 1
}
assert(succ(0) == anonfun1(0))






///*** Funcion as object/value 

//Defining a Method That Accepts a Simple Function

def executeFunction(callback: () => Unit) {
      callback()
    }


val sayHello = () => { println("Hello") }
executeFunction(sayHello)



//Using Closures
def exec(f:(String) => Unit, name: String)= {
            f(name)
}


var hello = "Hello"
def sayHello(name: String) { println(s"$hello, $name") }

exec(sayHello, "Al")

// change the local variable 'hello', then execute sayHello from
// the exec method of foo, and see what happens
hello = "Hola"
exec(sayHello, "Lorenzo")  //Hola, Lorenzo


//Creating a Function That Returns a Function - Curry form 
def f(x:Int) = {
   def g(y:Int)= {
     x * y
   }
   g _
}

//OR
def f(x:Int) = (y:Int) => x * y 

//Or - direct curry form 
def f(x:Int)(y:Int) = x * y

//Usage 
f(2)   //res18: Int => Int = <function1>
f(2)(3)  //res19: Int = 6

val a = f(2)  //a: Int => Int = <function1>
a(3)  //res20: Int = 6
val b = f(100)  //b: Int => Int = <function1>
b(3)   //res21: Int = 300

//Example of Curry form usage - in Higher order function that takes single argument
def modN(n: Int)(x: Int) = ((x % n) == 0)
val nums = List(1, 2, 3, 4, 5, 6, 7, 8)
nums.filter(modN(2))
nums.filter(modN(3))


//Note Curry form and uncurried form have the same signature 
//Below is error as both are of same type
class A {
 def f(x:Int)(y:Int) = 2
 def f(x:Int, y:Int) = 5    //error: double definition:
}

 
//tupled and curried are part of Function2...FunctionN (not under 'def' syntax)
//tupled gives tupled form ie taking an arg of Tuple, curried gives curried form
def fun(x:Int, y:Int):Int = x * y

val curFun = fun _ curried   //curried is defined only on Function2..22 object

curFun(1)  //res2: Int => Int = <function1>

curFun(1)(2)  //res3: Int = 2

//To create Tuple version of a Function2..N

def fun(x:Int, y:Int):Int = x * y
val tupFun = fun _ tupled

tupFun( 1 -> 2)  //res4: Int = 2
tupFun( (1,2) )  //res5: Int = 2

tupFun( Pair(1,2) )





///*** Partially applied function
val c = scala.math.cos _  // (eta expansion to get FunctionN)     c: Double => Double = <function1>

//partially applied 
val c = scala.math.cos(_)//      c: Double => Double = <function1>
c(0) //      res0: Double = 1.0


val p = scala.math.pow(_ , _) //      pow: (Double, Double) => Double = <function2>
p(scala.math.E, 2)   //      res0: Double = 7.3890560989306495


val sum = (a: Int, b: Int, c: Int) => a + b + c
val f = sum(1, 2, _: Int)
f(3) 							//    res0: Int = 6


 
 
///*** Function composition
//with compose and andThen - note these are only part of Function1
trait Function1[-T1, +R] extends AnyRef 
    def andThen[A](g: (R) => A): (T1) => A
        Composes two instances of Function1 in a new Function1, 
        with this function applied first.
        ie g(this(x)), note the g signature 
        any_type g(type_from_return_of_this)
    def compose[A](g: (A) => T1): (A) => R
        Composes two instances of Function1 in a new Function1, 
        with this function applied last ie this(g(x))
        Note g signature 
        type_require_in_arg_this g(any_type)

//Example 
val add = (x: Int, y: Int) => x + y
val double = (x:Int) => 2 * x

val addThenDouble = (x:Int ,y:Int ) => double(add(x,y))
 
//OR with andThen 

val addThenDouble = (x:Int) => (add(x,_:Int)) andThen double  // addl brackets must
val addComposeDouble = (x:Int) => (add(x,_:Int)) compose double  //

addThenDouble(2)(3)  //res31: Int = 10
addComposeDouble(2)(3)  //res32: Int = 8



//If def then use _ to convert to Function
def triple(x:Int) = x + x + x
val tripleAndDouble = triple _ andThen double 

 
//Can be used with List of functions and it's composition
val foo = 1 to 5 toList
val add1 = (x: Int) => x + 1
val add100 = (x: Int) => x + 100
val sq = (x: Int) => x * x

val fncs = List(add1, sq, add100)

foo map ( fncs.reverse reduce (_ compose _) ) // res8: List[Int] = List(104, 109, 116, 125, 136)
//OR
foo map (add1 andThen sq andThen add100)      //res9: List[Int] = List(104, 109, 116, 125, 136)
//OR
foo map ( fncs reduce (_ andThen _) )  //res10: List[Int] = List(104, 109, 116, 125, 136)
 
 





///*** Creating Partial Functions 
//function that is not defined every where in Domain
trait PartialFunction[-A, +B] extends (A) => B 
    abstract def apply(v1: A): B
        Apply the body of this function to the argument.
    abstract def isDefinedAt(x: A): Boolean
        Checks if a value is contained in the functions domain.
    //Concrete Value Members
    def andThen[C](k: (B) => C): PartialFunction[A, C]
        Composes this partial function with a transformation function 
        that gets applied to results of this partial function.
    def applyOrElse[A1 <: A, B1 >: B](x: A1, default: (A1) => B1): B1
        Applies this partial function to the given argument 
        when it is contained in the function domain.
    def compose[A](g: (A) => A): (A) => B
        Composes two instances of Function1 in a new Function1, 
        with this function applied last.
    def lift: (A) => Option[B]
        Turns this partial function into a plain function 
        returning an Option result.
    def orElse[A1 <: A, B1 >: B](that: PartialFunction[A1, B1]): PartialFunction[A1, B1]
        Composes this partial function with a fallback partial function 
        which gets applied where this partial function is not defined.
    def runWith[U](action: (B) => U): (A) => Boolean
        Composes this partial function with an action function 
        which gets applied to results of this partial function.
    def toString(): String
        Creates a String representation of this object.

//Examples 
val divide = new PartialFunction[Int, Int] {
      def apply(x: Int) = 42 / x
      def isDefinedAt(x: Int) = x != 0
    }

//OR
val divide2: PartialFunction[Int, Int] =  {  //val type is must, '{' is must
      case d: Int if d != 0 => 42 / d        //only One case statement
	 } 
	 


//Usage 
divide.isDefinedAt(1)  //    res0: Boolean = true
if (divide.isDefinedAt(1)) divide(1)  //    res1: AnyVal = 42
divide.isDefinedAt(0)  //    res2: Boolean = false

List(1, 0, 2, 0). collect(divide)
List(1, 0, 2, 0). collect{case d: Int if d != 0 => 42 / d }

//can not be used with map
List(0,1,2) map { divide }  			//Divide by zero 
//below OK 
List(0,1,2) map{ case d:Int if d != 0 => 42/d ; case d:Int if d == 0 => 0 }



///Partial Function composition
//pf1 orElse pf2 
// pf2 function is called if pf1  is not defined at a point
//Note pf1 and pf2 must have same Domain

def forInt: PartialFunction[Any,String] = { case x:Int => s"$x" }  // Arg is Any
def forStr:PartialFunction[Any,Int] = { case x:String => x.length }
 
List(42, "cat") collect { forInt orElse forStr } //it is List[Any] hence PF has domain Any

// converts 1 to "one", etc., up to 5
//String = PF(Int)

val convert1to5 = new PartialFunction[Int, String] {
        val nums = Array("one", "two", "three", "four", "five")
        def apply(i: Int) = nums(i-1)
        def isDefinedAt(i: Int) = i > 0 && i < 6
      }

// converts 6 to "six", etc., up to 10
val convert6to10 = new PartialFunction[Int, String] {
        val nums = Array("six", "seven", "eight", "nine", "ten")
        def apply(i: Int) = nums(i-6)
        def isDefinedAt(i: Int) = i > 5 && i < 11
      }


val handle1to10 = convert1to5 orElse convert6to10  // Else function is called if first one is false as isDefinedAt
handle1to10(3)  			//    res0: String = three

handle1to10(8)  //    res1: String = eight
 
 
 
 










   
   
   
   
   
   
   
   
   
   


///*** Architect Collection Hierarchy
//Seq, Set, Map are Iterable 
//Note Array is altogether different, but has all opertaions via ArrayOps and implicitely converted to Seq 
"""
final  class  Array[T] extends java.io.Serializable with java.lang.Cloneable  // and ArrayOps
case class  Tuple2[+T1, +T2](_1: T1, _2: T2) extends Product2[T1, T2] with Product with Serializable  //...Tuple22


TraversableOnce
	Iterator				//def  hasNext: Boolean , def  next(): A  , Must not call any Method (except, hasnext or next) after using once

TraversableLike  			//def foreach[U](f: Elem => U): Unit and newBuilder
	Iterable				//def iterator: Iterator[A] and newBuilder, implements Traversal's methods via Iterator's
		Seq					//
			LinerSeq			// linear access is efficient, (index) works
				List        	//Immutable
				Queue			//Immutable, Mutable
				LinkedList		//Immutable, Mutable
				Stack			//Immutable, Mutable
				MutableList
				Stream			//Immutable, lazy	
			Buffer				//Base trait for mutable operation
				ArrayBuffer	//Mutable
				ListBuffer	//Mutable
			IndexedSeq		// Random Access is efficient		(index) works		
				StringBuilder
				String		//Immutable
				Range		//Immutable
				Vector		//Immutable
				ArrayBuffer
		Set
			BitSet
			HashSet     //Immutable, Mutable, No Insertion ordered
			ListSet     //Immutable, insertion ordered 
			SortedSet   //Immutable, whose keys are sorted. 
				TreeSet
		Map
			HashMap     //Immutable, Mutable, No Insertion ordered
			WeakHashMap
			SortedMap   //Immutable, whose keys are sorted. 
				TreeMap // immutable maps using a tree. 
			ListMap     //immutable maps using a list-based data structure, insertion ordered 
			LinkedHashMap //Mutable, using a hashtab, insertion ordered 

"""

///Iterator 
//implements all methods (map, filter etc) via only two abstract methods
def hasNext: Boolean
def next(): A
 
//for example, Concrete Value Members- map
trait  Iterator[+A] extends TraversableOnce[A]
    def map[B](f: A => B): Iterator[B] = new AbstractIterator[B] { 
         def hasNext = self.hasNext 
         def next() = f(self.next()) 
    } 


//Builder trait knows how to build a Collection   
//Elem : element type and To : result of the builder(ie one collection)
//- means , arg type, + means return type -immutable 
trait Builder[-Elem, +To] {
  //implement below three
  def +=(elem: Elem): this.type    //adding a element, by b +=x or b ++= (x,y)
  def result(): To				   //returns a collection from this builder
  def clear(): Unit					//clear the builder
 }
 
 
///TraversableLike 
//Is the base trait which provides all methods (like map, filter) 
//based on only two abstract methods
trait  TraversableLike[+A, +Repr] extends HasNewBuilder[A, Repr] with FilterMonadic[A, Repr] with TraversableOnce[A] with GenTraversableLike[A, Repr] with Parallelizable[A, ParIterable[A]] 
        abstract def newBuilder: Builder[Elem, Repr] // Get Builder, Implement this
        abstract def foreach[U](f: Elem => U): Unit  // How to iterate, implement this

//Example how other methods  are implemented 
package scala.collection
//- means , arg type, + means return type -immutable 
//Note if used with private[this] and protected[this], then variances do not matter 
//if +T used in a fn which take T and used as arg of any method 
trait TraversableLike[+Elem, +Repr] {     //Elem is element type and Repr is current collection type
  protected[this] def newBuilder: Builder[Elem, Repr] // Get Builder, Implement this
  def foreach[U](f: Elem => U): Unit  // How to iterate, implement this
   
  //default implementation from here
  def filter(p: Elem => Boolean): Repr = {
    val b = newBuilder
    foreach { elem => if (p(elem)) b += elem }
    b.result
  } 
  //map takes one implicit value of CanBuildFrom, this enables to convert to element type 'B' with Collection type 'That'
  def map[B, That](f: Elem => B)(implicit bf: CanBuildFrom[Repr, B, That]): That = {
	  val b = bf(this)           //calls CanBuildFrom's apply to get Builder
	  this.foreach(x => b += f(x))    //calls Builder's += 
	  b.result                        //calls Builder's result
	}
  //Similarly most of the methods take CanBuildFrom implicit value
}

///The CanBuildFrom trait - used to create other Collection 
//'generic' module has many default implementation for various collections 
package scala.collection.generic
//- means , arg type, + means return type -immutable 
trait CanBuildFrom[-From, -Elem, +To] {   // create a required Builder   from 'From' type to To[Elem]
  def apply(from: From): Builder[Elem, To] 
}

//Scala collection  have breakOut implemented as below
def breakOut[From, T, To](implicit b : CanBuildFrom[Nothing, T, To]) =
    new CanBuildFrom[From, T, To] {
        def apply(from: From) = b.apply() 
		def apply() = b.apply()
 }

//Above can help to convert to default result to other required collection type
val map : Map[Int,String] = List("London", "Paris").map(x => (x.length, x))(collection.breakOut)
//map: Map[Int,String] = Map(6 -> London, 5 -> Paris)

val l = List(1, 2, 3)
val imp = l.map(_ + 1)(collection.breakOut)


val xs = Set(1, 2, 3)
import scala.language.postfixOps  //2* is a postfix operator
val result:List[Int] = xs.map(2*)(collection.breakOut) //else the result type would be Set 
//result: List[Int] = List(2, 4, 6)




///Traversable
trait Traversable[+A] extends TraversableLike[A, Traversable[A]] with GenTraversable[A] with TraversableOnce[A] with GenericTraversableTemplate[A, Traversable] 
//hosts collection of specifications which a Collection must provide
//derives from TraversableLike, hence collection must implement abstract methods of TraversableLike


///Iterable
//This is a base trait for all Scala collections that define an iterator method
trait Iterable[+A] extends Traversable[A] with GenIterable[A] with GenericTraversableTemplate[A, Iterable] with IterableLike[A, Iterable[A]]
    abstract def iterator: Iterator[A]
	 
     
///Seq 
trait Seq[+A] extends PartialFunction[Int, A] with Iterable[A] with GenSeq[A] with GenericTraversableTemplate[A, Seq] with SeqLike[A, Seq[A]] 
//is data structures where indexing operation works
//It has below three abstract methods, all other methods are derived from Iterable 
def  apply(idx: Int): A 
def  iterator: Iterator[A] 
def  length: Int 


//Sequences have two principal subtraits, IndexedSeq and LinearSeq.
//An IndexedSeq provides fast random-access of elements and a fast length operation. 

//A LinearSeq provides fast access only to the first element via head, 
//but also has a fast tail operation.

//Sequences can be accessed in reverse order of their elements, 
//using methods reverse and reverseIterator.



///Set 
trait Set[A] extends (A) => Boolean with Iterable[A] with GenSet[A] with GenericSetTemplate[A, Set] with SetLike[A, Set[A]] 
//provides all set like functionality based on below abstract methods 
abstract def +(elem: A): Set[A]
    Creates a new set with an additional element, unless the element is already present.
abstract def -(elem: A): Set[A]
    Creates a new set with a given element removed from this set.
abstract def contains(elem: A): Boolean
    Tests if some element is contained in this set.
abstract def iterator: Iterator[A] 
abstract def empty: This
// If your additions and mutations return the same kind of set as the set you are defining, 
//you should inherit from SetLike as well.



///Map 
//A map from keys of type A to values of type B.
trait Map[A, +B] extends Iterable[(A, B)] with GenMap[A, B] with MapLike[A, B, Map[A, B]]
//implements all Map methods from below abstract methods 
def get(key: A): Option[B]
def iterator: Iterator[(A, B)]
def + [B1 >: B](kv: (A, B1)): this.type
    Adds a key/value pair to this map, returning a new map.
def -(key: A): this.type
    Removes a key from this map, returning a new map.
def empty: this.type
    The empty map of the same type as this map
    
//Note: If you do not have specific implementations for add and - in mind, 
//you might consider inheriting from DefaultMap instead.

//Note: If your additions and mutations return the same kind of map 
//as the map you are defining, you should inherit from MapLike as well. 

 
///*** mutable.WeakHashMap
//A hash map with references to entries which are weakly reachable. 
//Entries are removed from this map when the key is no longer  referenced by other code 
//All Map functions are available




///*** Collection Methods conventions

"""
 Single Operator  - works with element
 Double operator - works with another Collection
 front : or without front :  - associativity left 
 end : - associativity right 
 end with =  , in place change, only for mutable, But mutable also has  'return new copy' version of immutable
 Immutable - returns new collection
 
 Examples:
 + 		for Map- add an element (k,v),
        Set - Add an element,  List-NA, Array-NA,  Stream -NA
 
 +:  	associativity Right, prepend an Element, List, Array, Stream, Buffer
 :+		append an element , List, Array, Stream, Buffer
 +=  	For buffer, append an element
 +=:   	For Buffer, prepend an element, associativity right
 
 ++		For Map - add another Map, 
        List, Stream,Array, Set - Add another collection , side by side
 :++    not existing- for any ( Map , List, Stream,Array, Set)
 ++:	For Map, same as ++,  List, Stream,Array, Set, Buffer - same as ++
 ++=	In place for Buffer
 ++=: 	In place for buffer, prepend
 
 -		For Map, remove a Key, for Set,Buffer, remove a element , List, Array, Stream -NA
 --		For Map, remove collection of Keys, for Set, Buffer, remove a collection of elements, List, Array, Stream -NA
 --=  	In place for Buffer, remove another list
 
 ::		Only for List,  Add an element  or Nil as last element (always prepend), first element, then list as :: is right associative
 :::	Only for List, add another List (calls on 2nd list and prepend)  ie list's element into list (not a nested list)
 #::	Only for Stream , add an element or Stream.empty as last element (always prepend)
 #:::	Only for Stream, add another Stream 
 
 :\		foldRight    Map  :/ (init: B)(op: (B, (A, B)) => B): B  
        or List/Array/Set/Stream :/ (init: B)(op: (B, A) => B): B 
 /:		foldLeft	((init: B) /:  Map  )(op: (B, (A, B)) => B): B 
        ((init: B) /:  List/Array/Set/Stream  )(op: (B, A) => B): B 
        
 &, &~, | Only for Set
 
"""

//Indexing and Updates 
//for Seq, Array and Buffer and it's derived via below methods
//For Set - checking membership, for Map , getting and updating Key
def apply(index:Int) :A    //for obj(index)
def update(index:Int, value:A):Unit  //for obj(index) = A


///*** Collection - Interacting with Java


//Going to and from Java Collections, import scala.collection.JavaConversions._

def nums = {
              var list = new java.util.ArrayList[Int]()
              list.add(1)
              list.add(2)
              list
            }



val list = nums
list.foreach(println)  //NOK 

//Use below 
import scala.collection.JavaConversions._
list.foreach(println)   // OK now


//Conversion tables-The two-way conversions provided by the JavaConversions object - 
//Mainly for Mutable scala collection
Scala collection                             Java collection
collection.Iterable                          java.lang.Iterable
collection.Iterable                          java.util.Collection
collection.Iterator                          java.util.{Iterator, Enumeration}
collection.mutable.Buffer                    java.util.List
collection.mutable.Set                       java.util.Set
collection.mutable.Map                       java.util.{Map, Dictionary}

//The Scala to Java one-way conversions provided by the JavaConversions 
//- For Immutable 

Scala collection                              Java collection
collection.Seq                                java.util.List
collection.mutable.Seq                        java.util.List
collection.Set                                java.util.Set
collection.Map                                java.util.Map
collection.mutable.Map[String,String]         java.util.Properties


//Note Scala compatibility with JDK8 lambda is poor, (scala2.11.x, 2.12.x is OK)
//Use following conversions and use java.util.function class ,not java lambda
import java.util.function.{ Function => JFunction, Predicate => JPredicate, BiPredicate }

//usage example: `i: Int => 42`
implicit def toJavaFunction[A, B](f: Function1[A, B]) = new JFunction[A, B] {
  override def apply(a: A): B = f(a)
}

//usage example: `i: Int => true`
implicit def toJavaPredicate[A](f: Function1[A, Boolean]) = new JPredicate[A] {
  override def test(a: A): Boolean = f(a)
}

//usage example: `(i: Int, s: String) => true`
implicit def toJavaBiPredicate[A, B](predicate: (A, B) => Boolean) =
  new BiPredicate[A, B] {
    def test(a: A, b: B) = predicate(a, b)
  }

  
///JavaConverters uses the pimp-my-library pattern to “add” the asScala method to the Java collections 
//and the asJava method to the Scala collections, 

import collection.JavaConverters._



//Pimped Type                          | Conversion Method   | Returned Type
=================================================================================================
scala.collection.Iterator              | asJava              | java.util.Iterator
scala.collection.Iterator              | asJavaEnumeration   | java.util.Enumeration
scala.collection.Iterable              | asJava              | java.lang.Iterable
scala.collection.Iterable              | asJavaCollection    | java.util.Collection
scala.collection.mutable.Buffer        | asJava              | java.util.List
scala.collection.mutable.Seq           | asJava              | java.util.List
scala.collection.Seq                   | asJava              | java.util.List
scala.collection.mutable.Set           | asJava              | java.util.Set
scala.collection.Set                   | asJava              | java.util.Set
scala.collection.mutable.Map           | asJava              | java.util.Map
scala.collection.Map                   | asJava              | java.util.Map
scala.collection.mutable.Map           | asJavaDictionary    | java.util.Dictionary
scala.collection.mutable.ConcurrentMap | asJavaConcurrentMap | java.util.concurrent.ConcurrentMap
—————————————————————————————————————————————————————————————————————————————————————————————————
java.util.Iterator                     | asScala             | scala.collection.Iterator
java.util.Enumeration                  | asScala             | scala.collection.Iterator
java.lang.Iterable                     | asScala             | scala.collection.Iterable
java.util.Collection                   | asScala             | scala.collection.Iterable
java.util.List                         | asScala             | scala.collection.mutable.Buffer
java.util.Set                          | asScala             | scala.collection.mutable.Set
java.util.Map                          | asScala             | scala.collection.mutable.Map
java.util.concurrent.ConcurrentMap     | asScala             | scala.collection.mutable.ConcurrentMap
java.util.Dictionary                   | asScala             | scala.collection.mutable.Map
java.util.Properties                   | asScala             | scala.collection.mutable.Map[String, String]


import collection.JavaConverters._
import collection.mutable._

val jul: java.util.List[Int] = ArrayBuffer(1, 2, 3).asJava

val buf: Seq[Int] = jul.asScala
//buf: scala.collection.mutable.Seq[Int] = ArrayBuffer(1, 2, 3)

val m: java.util.Map[String, Int] = HashMap("abc" -> 1, "hello" -> 2).asJava
//m: java.util.Map[String,Int] = {abc=1, hello=2}

  
  
  
  
  

///*** Collection - General methods and Transformation Methods 
//Same for Map but with (k,v) tuple inplace of element for List/Set/Stream/Array/Buffer
//for Map - can use { case (k,v) => ..} 

Map("a" -> 1, "b" -> 2) map { case (x, y) => (y, x) }  // = Map(1 -> a, 2 -> b)
  
Map("a" -> 1, "b" -> 2) map { case (x, y) => y }  //= List(1, 2)

"""
size,length     - gets length
mkString        - Joining
contains(ele),containsSlice(collection) - checking contains
distinct        -  removes duplicates


zip             - zipping with another collection
zipWithIndex    - Zipping wih Index of element

toArray, toList etc     	- Conversion to other collection, for mutable, it makes immutable 
to[CollectionType] 			- conversion to CollectionType

take(left_n),takeRight(right_n),takeWhile(pred)  - Take elements
drop(left_n),dropRight(right_n),dropWhile(pred)  - Drop elements

head,tail, first, last - for List, Array ie for  indexed sequence

startsWith(collection), endsWith(collection) - checks starts with  or ends with  another collection

sorted, sortWith(comparator_function), sortBy(key_function) - for Sorts
max,maxBy(pred), min, minBy(pred)                           - max/min 

map(map_function), flatMap(map_function)- map with flatten
collect(partial_function)       - same as map, but collects where partial function is defined, hence can be applied selectively

filter(pred), withFilter(pred), filterNot(pred) - filter
find(pred), count(pred), indexOf(ele),indexOfWhere(pred), 
lastIndexOf(ele), lastIndexOfWhere(pred)        - to find/cont element
forall(pred), exists(pred)                      - check for all elements or for some elements

fold(init)(op), foldRight, foldLeft, reduce(op), reduceLeft, 
reduceRight, scan(init)(op),scanLeft, scanRight     - scan produces intermediate values

splitAt(n), groupBy(pred), partition(pred), sliding(size,step),
slice(start,until)      - Ways of making many COllections

parmutations, combinations(r) - Iterates permutations/combinations
"""

//Comparison with Mutable and immutable 
//List 
val is = scala.reflect.runtime.universe.typeOf[List[_]].members.map(_.name.toString).toSet
val ms = scala.reflect.runtime.universe.typeOf[collection.mutable.ListBuffer[_]].members.map(_.name.toString).toSet
//Methods extra in Mutable , ms &~ is
Set(prependToList, prepend, readOnly, insert, prependAll, --, 
start_=, clear, +=, result, --=, readObject, 
trimEnd, exported, last0, len_=, insertAll, -=, 
sizeHint,writeObject, +=:, mapResult, remove, 
trimStart, appendAll, -, ++=:, 
sizeHintBounded, last0_=, copy, underlying, update, 
start, transform, ++=, reduceLengthBy,
exported_=, <<, len, append)

//Set 
val is = scala.reflect.runtime.universe.typeOf[Set[_]].members.map(_.name.toString).toSet
val ms = scala.reflect.runtime.universe.typeOf[collection.mutable.Set[_]].members.map(_.name.toString).toSet
//Methods extra in Mutable , ms &~ is
Set(clear, +=, result, --=, retain, -=, 
sizeHint, mapResult, remove, sizeHintBounded, update, add, 
++=, <<)

//Map 
val is = scala.reflect.runtime.universe.typeOf[Map[_,_]].members.map(_.name.toString).toSet
val ms = scala.reflect.runtime.universe.typeOf[collection.mutable.Map[_,_]].members.map(_.name.toString).toSet
//Methods extra in Mutable , ms &~ is
Set(clear, +=, result, --=, retain, getOrElseUpdate, 
-=, sizeHint, mapResult, remove, sizeHintBounded, put,update, 
++=)

//Methods extra in Set compared to List , ms &~ is
Set(empty, subsetOf, --, &~, $bar, 
&, +, -, subsets)

//Methods extra in Map compared to List , ms &~ is
Set(DefaultKeySet, empty, --, FilteredKeys, filterKeys, 
withDefault, valuesIterator, keysIterator, keySet, withDefaultValue, 
getOrElse, +, ImmutableDefaultKeySet, default, -, 
DefaultValuesIterable, values, MappedValues, get, mapValues, 
transform, keys)

///* Reference 
ArrayOps[T] extends ArrayLike[T, Array[T]] with CustomParallelizable[T, ParArray[T]] 
    abstract def length: Int
    abstract def update(idx: Int, elem: T): Unit
    def ++[B](that: GenTraversableOnce[B]): Array[B]
    def ++:[B >: T, That](that: collection.Traversable[B])(implicit bf: CanBuildFrom[Array[T], B, That]): That
    def ++:[B](that: TraversableOnce[B]): Array[B]
    def +:[B >: T](elem: B)(implicit arg0: ClassTag[B]): Array[B]
    def +:(elem: A): Array[A]
    def /:[B](z: B)(op: (B, T) => B): B
    def :+[B >: T](elem: B)(implicit arg0: ClassTag[B]): Array[B]
    def :+(elem: A): Array[A]
    def :\[B](z: B)(op: (T, B) => B): B
    def addString(b: scala.StringBuilder): scala.StringBuilder
    def addString(b: scala.StringBuilder, sep: String): scala.StringBuilder
    def addString(b: scala.StringBuilder, start: String, sep: String, end: String): scala.StringBuilder
    def aggregate[B](z: => B)(seqop: (B, T) => B, combop: (B, B) => B): B
    def canEqual(that: Any): Boolean
    def collect[B](pf: PartialFunction[A, B]): Array[B]
    def collectFirst[B](pf: PartialFunction[T, B]): Option[B]
    def combinations(n: Int): Iterator[Array[T]]
    def contains[A1 >: T](elem: A1): Boolean
    def containsSlice[B](that: GenSeq[B]): Boolean
    def copyToArray(xs: Array[A], start: Int, len: Int): Unit
    def copyToArray(xs: Array[A]): Unit
    def copyToArray(xs: Array[A], start: Int): Unit
    def copyToBuffer[B >: T](dest: Buffer[B]): Unit
    def corresponds[B](that: GenSeq[B])(p: (T, B) => Boolean): Boolean
    def count(p: (T) => Boolean): Int
    def deep: collection.IndexedSeq[Any]
    def diff(that: collection.Seq[T]): Array[T]
    def distinct: Array[T]
    def drop(n: Int): Array[T]
    def dropRight(n: Int): Array[T]
    def dropWhile(p: (T) => Boolean): Array[T]
    def endsWith[B](that: GenSeq[B]): Boolean
    def equals(that: Any): Boolean
    def exists(p: (T) => Boolean): Boolean
    def filter(p: (T) => Boolean): Array[T]
    def filterNot(p: (T) => Boolean): Array[T]
    def find(p: (T) => Boolean): Option[T]
    def flatMap[B](f: (A) => GenTraversableOnce[B]): Array[B]
    def flatten[U](implicit asTrav: (T) => collection.Traversable[U], m: ClassTag[U]): Array[U]
    def fold[A1 >: T](z: A1)(op: (A1, A1) => A1): A1
    def foldLeft[B](z: B)(op: (B, T) => B): B
    def foldRight[B](z: B)(op: (T, B) => B): B
    def forall(p: (T) => Boolean): Boolean
    def foreach(f: (A) => Unit): Unit
    def groupBy[K](f: (T) => K): immutable.Map[K, Array[T]]
    def grouped(size: Int): Iterator[Array[T]]
    def hasDefiniteSize: Boolean
    def hashCode(): Int
    def head: T
    def headOption: Option[T]
    def indexOf(elem: T, from: Int): Int
    def indexOf(elem: T): Int
    def indexOfSlice[B >: T](that: GenSeq[B], from: Int): Int
    def indexOfSlice[B >: T](that: GenSeq[B]): Int
    def indexWhere(p: (T) => Boolean, from: Int): Int
    def indexWhere(p: (T) => Boolean): Int
    def indices: immutable.Range
    def init: Array[T]
    def inits: Iterator[Array[T]]
    def intersect(that: collection.Seq[T]): Array[T]
    def isDefinedAt(idx: Int): Boolean
    def isEmpty: Boolean
    def iterator: Iterator[T]
    def last: T
    def lastIndexOf(elem: T, end: Int): Int
    def lastIndexOf(elem: T): Int
    def lastIndexOfSlice[B >: T](that: GenSeq[B], end: Int): Int
    def lastIndexOfSlice[B >: T](that: GenSeq[B]): Int
    def lastIndexWhere(p: (T) => Boolean, end: Int): Int
    def lastIndexWhere(p: (T) => Boolean): Int
    def lastOption: Option[T]
    def lengthCompare(len: Int): Int
    def map[B](f: (A) => B): Array[B]
    def max: A
    def maxBy[B](f: (A) => B): A
    def min: A
    def minBy[B](f: (A) => B): A
    def mkString: String
    def mkString(sep: String): String
    def mkString(start: String, sep: String, end: String): String
    def nonEmpty: Boolean
    def padTo(len: Int, elem: A): Array[A]
    def par: ParArray[T]
    def partition(p: (T) => Boolean): (Array[T], Array[T])
    def patch(from: Int, that: GenSeq[A], replaced: Int): Array[A]
    def permutations: Iterator[Array[T]]
    def prefixLength(p: (T) => Boolean): Int
    def product: A
    def reduce[A1 >: T](op: (A1, A1) => A1): A1
    def reduceLeft[B >: T](op: (B, T) => B): B
    def reduceLeftOption[B >: T](op: (B, T) => B): Option[B]
    def reduceOption[A1 >: T](op: (A1, A1) => A1): Option[A1]
    def reduceRight[B >: T](op: (T, B) => B): B
    def reduceRightOption[B >: T](op: (T, B) => B): Option[B]
    def repr: Array[T]
    def reverse: Array[T]
    def reverseIterator: Iterator[T]
    def reverseMap[B](f: (A) => B): Array[B]
    def sameElements(that: GenIterable[A]): Boolean
    def scan[B >: T, That](z: B)(op: (B, B) => B)(implicit cbf: CanBuildFrom[Array[T], B, That]): That
    def scanLeft[B, That](z: B)(op: (B, T) => B)(implicit bf: CanBuildFrom[Array[T], B, That]): That
    def scanRight[B, That](z: B)(op: (T, B) => B)(implicit bf: CanBuildFrom[Array[T], B, That]): That
    def segmentLength(p: (T) => Boolean, from: Int): Int
    def seq: IndexedSeq[T]
    def size: Int
    def slice(from: Int, until: Int): Array[T]
    def sliding(size: Int, step: Int): Iterator[Array[T]]
    def sliding(size: Int): Iterator[Array[T]]
    def sortBy[B](f: (T) => B)(implicit ord: math.Ordering[B]): Array[T]
    def sortWith(lt: (T, T) => Boolean): Array[T]
    def sorted[B >: T](implicit ord: math.Ordering[B]): Array[T]
    def span(p: (T) => Boolean): (Array[T], Array[T])
    def splitAt(n: Int): (Array[T], Array[T])
    def startsWith[B](that: GenSeq[B], offset: Int): Boolean
    def startsWith[B](that: GenSeq[B]): Boolean
    def stringPrefix: String
    def sum: A
    def tail: Array[T]
    def tails: Iterator[Array[T]]
    def take(n: Int): Array[T]
    def takeRight(n: Int): Array[T]
    def takeWhile(p: (T) => Boolean): Array[T]
    def to[Col[_]]: Col[A]
    def toArray: Array[A]
    def toBuffer[A1 >: T]: Buffer[A1]
    def toIndexedSeq: immutable.IndexedSeq[T]
    def toIterable: collection.Iterable[T]
    def toIterator: Iterator[T]
    def toList: List[T]
    def toMap[T, U]: collection.Map[T, U]
    def toParArray: ParArray[T]
    def toSeq: collection.Seq[T]
    def toSet[B >: T]: immutable.Set[B]
    def toStream: immutable.Stream[T]
    def toString(): String
    def toTraversable: collection.Traversable[T]
    def toVector: Vector[T]
    def transpose[U](implicit asArray: (T) => Array[U]): Array[Array[U]]
    def union(that: collection.Seq[T]): Array[T]
    def unzip[T1, T2](implicit asPair: (T) => (T1, T2), ct1: ClassTag[T1], ct2: ClassTag[T2]): (Array[T1], Array[T2])
    def unzip3[T1, T2, T3](implicit asTriple: (T) => (T1, T2, T3), ct1: ClassTag[T1], ct2: ClassTag[T2], ct3: ClassTag[T3]): (Array[T1], Array[T2], Array[T3])
    def updated(index: Int, elem: A): Array[A]
    def view(from: Int, until: Int): IndexedSeqView[T, Array[T]]
    def view: IndexedSeqView[T, Array[T]]
    def withFilter(p: (T) => Boolean): FilterMonadic[T, Array[T]]
    def zip[B](that: GenIterable[B]): Array[(A, B)]
    def zipAll[B](that: collection.Iterable[B], thisElem: A, thatElem: B): Array[(A, B)]
    def zipWithIndex: Array[(A, Int)]
sealed abstract class List[+A] extends AbstractSeq[A] with LinearSeq[A] with Product with GenericTraversableTemplate[A, List] with LinearSeqOptimized[A, List[A]] with java.io.Serializable 
    def ++[B](that: GenTraversableOnce[B]): List[B]
    def ++:[B >: A, That](that: collection.Traversable[B])(implicit bf: CanBuildFrom[List[A], B, That]): That
    def ++:[B](that: TraversableOnce[B]): List[B]
    def +:(elem: A): List[A]
    def /:[B](z: B)(op: (B, A) => B): B
    def :+(elem: A): List[A]
    def ::(x: A): List[A]
    def :::(prefix: List[A]): List[A]
    def :\[B](z: B)(op: (A, B) => B): B
    def addString(b: StringBuilder): StringBuilder
    def addString(b: StringBuilder, sep: String): StringBuilder
    def addString(b: StringBuilder, start: String, sep: String, end: String): StringBuilder
    def aggregate[B](z: => B)(seqop: (B, A) => B, combop: (B, B) => B): B
    def andThen[C](k: (A) => C): PartialFunction[Int, C]
    def apply(n: Int): A
    def applyOrElse[A1 <: Int, B1 >: A](x: A1, default: (A1) => B1): B1
    def canEqual(that: Any): Boolean
    def collectFirst[B](pf: PartialFunction[A, B]): Option[B]
    def combinations(n: Int): Iterator[List[A]]
    def companion: GenericCompanion[List]
    def compose[A](g: (A) => Int): (A) => A
    def contains[A1 >: A](elem: A1): Boolean
    def containsSlice[B](that: GenSeq[B]): Boolean
    def copyToArray(xs: Array[A], start: Int, len: Int): Unit
    def copyToArray(xs: Array[A]): Unit
    def copyToArray(xs: Array[A], start: Int): Unit
    def copyToBuffer[B >: A](dest: Buffer[B]): Unit
    def count(p: (A) => Boolean): Int
    def diff(that: collection.Seq[A]): List[A]
    def distinct: List[A]
    def drop(n: Int): List[A]
    def dropRight(n: Int): List[A]
    def endsWith[B](that: GenSeq[B]): Boolean
    def equals(that: Any): Boolean
    def exists(p: (A) => Boolean): Boolean
    def filter(p: (A) => Boolean): List[A]
    def filterNot(p: (A) => Boolean): List[A]
    def find(p: (A) => Boolean): Option[A]
    def flatten[B]: List[B]
    def fold[A1 >: A](z: A1)(op: (A1, A1) => A1): A1
    def foldLeft[B](z: B)(op: (B, A) => B): B
    def foldRight[B](z: B)(op: (A, B) => B): B
    def forall(p: (A) => Boolean): Boolean
    def genericBuilder[B]: Builder[B, List[B]]
    def groupBy[K](f: (A) => K): Map[K, List[A]]
    def grouped(size: Int): Iterator[List[A]]
    def hasDefiniteSize: Boolean
    def hashCode(): Int
    def head: A
    def headOption: Option[A]
    def indexOf(elem: A, from: Int): Int
    def indexOf(elem: A): Int
    def indexOfSlice[B >: A](that: GenSeq[B], from: Int): Int
    def indexOfSlice[B >: A](that: GenSeq[B]): Int
    def indexWhere(p: (A) => Boolean, from: Int): Int
    def indexWhere(p: (A) => Boolean): Int
    def indices: Range
    def init: List[A]
    def inits: Iterator[List[A]]
    def intersect(that: collection.Seq[A]): List[A]
    def isDefinedAt(x: Int): Boolean
    def isEmpty: Boolean
    def iterator: Iterator[A]
    def last: A
    def lastIndexOf(elem: A, end: Int): Int
    def lastIndexOf(elem: A): Int
    def lastIndexOfSlice[B >: A](that: GenSeq[B], end: Int): Int
    def lastIndexOfSlice[B >: A](that: GenSeq[B]): Int
    def lastIndexWhere(p: (A) => Boolean, end: Int): Int
    def lastIndexWhere(p: (A) => Boolean): Int
    def lastOption: Option[A]
    def length: Int
    def lengthCompare(len: Int): Int
    def lift: (Int) => Option[A]
    def max: A
    def maxBy[B](f: (A) => B): A
    def min: A
    def minBy[B](f: (A) => B): A
    def mkString: String
    def mkString(sep: String): String
    def mkString(start: String, sep: String, end: String): String
    def nonEmpty: Boolean
    def orElse[A1 <: Int, B1 >: A](that: PartialFunction[A1, B1]): PartialFunction[A1, B1]
    def padTo(len: Int, elem: A): List[A]
    def par: ParSeq[A]
    def partition(p: (A) => Boolean): (List[A], List[A])
    def patch(from: Int, that: GenSeq[A], replaced: Int): List[A]
    def permutations: Iterator[List[A]]
    def prefixLength(p: (A) => Boolean): Int
    def product: A
    def productIterator: scala.Iterator[Any]
    def productPrefix: String
    def reduce[A1 >: A](op: (A1, A1) => A1): A1
    def reduceLeft[B >: A](f: (B, A) => B): B
    def reduceLeftOption[B >: A](op: (B, A) => B): Option[B]
    def reduceOption[A1 >: A](op: (A1, A1) => A1): Option[A1]
    def reduceRight[B >: A](op: (A, B) => B): B
    def reduceRightOption[B >: A](op: (A, B) => B): Option[B]
    def repr: List[A]
    def reverse: List[A]
    def reverseIterator: Iterator[A]
    def reverseMap[B](f: (A) => B): List[B]
    def reverse_:::(prefix: List[A]): List[A]
    def runWith[U](action: (A) => U): (Int) => Boolean
    def sameElements(that: GenIterable[A]): Boolean
    def scan[B >: A, That](z: B)(op: (B, B) => B)(implicit cbf: CanBuildFrom[List[A], B, That]): That
    def scanLeft[B, That](z: B)(op: (B, A) => B)(implicit bf: CanBuildFrom[List[A], B, That]): That
    def scanRight[B, That](z: B)(op: (A, B) => B)(implicit bf: CanBuildFrom[List[A], B, That]): That
    def segmentLength(p: (A) => Boolean, from: Int): Int
    def seq: LinearSeq[A]
    def size: Int
    def slice(from: Int, until: Int): List[A]
    def sliding(size: Int, step: Int): Iterator[List[A]]
    def sliding(size: Int): Iterator[List[A]]
    def sortBy[B](f: (A) => B)(implicit ord: math.Ordering[B]): List[A]
    def sortWith(lt: (A, A) => Boolean): List[A]
    def sorted[B >: A](implicit ord: math.Ordering[B]): List[A]
    def splitAt(n: Int): (List[A], List[A])
    def startsWith[B](that: GenSeq[B], offset: Int): Boolean
    def startsWith[B](that: GenSeq[B]): Boolean
    def stringPrefix: String
    def sum: A
    def tail: List[A]
    def tails: Iterator[List[A]]
    def take(n: Int): List[A]
    def takeRight(n: Int): List[A]
    def to[Col[_]]: Col[A]
    def toArray: Array[A]
    def toBuffer[B >: A]: Buffer[B]
    def toIndexedSeq: IndexedSeq[A]
    def toIterable: collection.Iterable[A]
    def toIterator: Iterator[A]
    def toList: List[A]
    def toMap[T, U]: collection.Map[T, U]
    def toParArray: ParArray[T]
    def toSeq: Seq[A]
    def toSet[B >: A]: Set[B]
    def toStream: Stream[A]
    def toString(): String
    def toTraversable: collection.Traversable[A]
    def toVector: scala.Vector[A]
    def transpose[B](implicit asTraversable: (A) => GenTraversableOnce[B]): List[List[B]]
    def union(that: collection.Seq[A]): List[A]
    def unzip[A1, A2](implicit asPair: (A) => (A1, A2)): (List[A1], List[A2])
    def unzip3[A1, A2, A3](implicit asTriple: (A) => (A1, A2, A3)): (List[A1], List[A2], List[A3])
    def updated(index: Int, elem: A): List[A]
    def view(from: Int, until: Int): SeqView[A, List[A]]
    def view: SeqView[A, List[A]]
    def withFilter(p: (A) => Boolean): FilterMonadic[A, List[A]]
    def zip[B](that: GenIterable[B]): List[(A, B)]
    def zipAll[B](that: collection.Iterable[B], thisElem: A, thatElem: B): List[(A, B)]
    def zipWithIndex: List[(A, Int)]
object List  extends SeqFactory[List] with Serializable 
    def ReusableCBF: GenericCanBuildFrom[Nothing]
    def apply[A](xs: A*): List[A]
    def concat[A](xss: collection.Traversable[A]*): List[A]
    def empty[A]: List[A]
    def fill[A](n1: Int, n2: Int, n3: Int, n4: Int, n5: Int)(elem: => A): List[List[List[List[List[A]]]]]
    def fill[A](n1: Int, n2: Int, n3: Int, n4: Int)(elem: => A): List[List[List[List[A]]]]
    def fill[A](n1: Int, n2: Int, n3: Int)(elem: => A): List[List[List[A]]]
    def fill[A](n1: Int, n2: Int)(elem: => A): List[List[A]]
    def fill[A](n: Int)(elem: => A): List[A]
    def iterate[A](start: A, len: Int)(f: (A) => A): List[A]
    def newBuilder[A]: Builder[A, List[A]]
    def range[T](start: T, end: T, step: T)(implicit arg0: Integral[T]): List[T]
    def range[T](start: T, end: T)(implicit arg0: Integral[T]): List[T]
    def tabulate[A](n1: Int, n2: Int, n3: Int, n4: Int, n5: Int)(f: (Int, Int, Int, Int, Int) => A): List[List[List[List[List[A]]]]]
    def tabulate[A](n1: Int, n2: Int, n3: Int, n4: Int)(f: (Int, Int, Int, Int) => A): List[List[List[List[A]]]]
    def tabulate[A](n1: Int, n2: Int, n3: Int)(f: (Int, Int, Int) => A): List[List[List[A]]]
    def tabulate[A](n1: Int, n2: Int)(f: (Int, Int) => A): List[List[A]]
    def tabulate[A](n: Int)(f: (Int) => A): List[A]
    def unapplySeq[A](x: List[A]): Some[List[A]]
trait Set[A] extends (A) => Boolean with Iterable[A] with GenSet[A] with GenericSetTemplate[A, Set] with SetLike[A, Set[A]] 
    abstract def +(elem: A): Set[A]
    abstract def -(elem: A): Set[A]
    abstract def contains(elem: A): Boolean
    abstract def iterator: Iterator[A]
    def &(that: GenSet[A]): Set[A]
    def &~(that: GenSet[A]): Set[A]
    def +(elem1: A, elem2: A, elems: A*): Set[A]
    def ++(elems: GenTraversableOnce[A]): Set[A]
    def ++[B](that: GenTraversableOnce[B]): Set[B]
    def ++:[B >: A, That](that: Traversable[B])(implicit bf: CanBuildFrom[Set[A], B, That]): That
    def ++:[B](that: TraversableOnce[B]): Set[B]
    def -(elem1: A, elem2: A, elems: A*): Set[A]
    def --(xs: GenTraversableOnce[A]): Set[A]
    def /:[B](z: B)(op: (B, A) => B): B
    def :\[B](z: B)(op: (A, B) => B): B
    def addString(b: StringBuilder): StringBuilder
    def addString(b: StringBuilder, sep: String): StringBuilder
    def addString(b: StringBuilder, start: String, sep: String, end: String): StringBuilder
    def aggregate[B](z: => B)(seqop: (B, A) => B, combop: (B, B) => B): B
    def andThen[A](g: (Boolean) => A): (A) => A
    def apply(elem: A): Boolean
    def canEqual(that: Any): Boolean
    def collect[B](pf: PartialFunction[A, B]): Set[B]
    def collectFirst[B](pf: PartialFunction[A, B]): Option[B]
    def companion: GenericCompanion[Set]
    def compose[A](g: (A) => A): (A) => Boolean
    def copyToArray(xs: Array[A], start: Int, len: Int): Unit
    def copyToArray(xs: Array[A]): Unit
    def copyToArray(xs: Array[A], start: Int): Unit
    def copyToBuffer[B >: A](dest: Buffer[B]): Unit
    def count(p: (A) => Boolean): Int
    def diff(that: GenSet[A]): Set[A]
    def drop(n: Int): Set[A]
    def dropRight(n: Int): Set[A]
    def dropWhile(p: (A) => Boolean): Set[A]
    def empty: Set[A]
    def equals(that: Any): Boolean
    def exists(p: (A) => Boolean): Boolean
    def filter(p: (A) => Boolean): Set[A]
    def filterNot(p: (A) => Boolean): Set[A]
    def find(p: (A) => Boolean): Option[A]
    def flatMap[B](f: (A) => GenTraversableOnce[B]): Set[B]
    def flatten[B]: Set[B]
    def fold[A1 >: A](z: A1)(op: (A1, A1) => A1): A1
    def foldLeft[B](z: B)(op: (B, A) => B): B
    def foldRight[B](z: B)(op: (A, B) => B): B
    def forall(p: (A) => Boolean): Boolean
    def foreach(f: (A) => Unit): Unit
    def genericBuilder[B]: Builder[B, Set[B]]
    def groupBy[K](f: (A) => K): immutable.Map[K, Set[A]]
    def grouped(size: Int): Iterator[Set[A]]
    def hasDefiniteSize: Boolean
    def hashCode(): Int
    def head: A
    def headOption: Option[A]
    def init: Set[A]
    def inits: Iterator[Set[A]]
    def intersect(that: GenSet[A]): Set[A]
    def isEmpty: Boolean
    def last: A
    def lastOption: Option[A]
    def map[B](f: (A) => B): Set[B]
    def max: A
    def maxBy[B](f: (A) => B): A
    def min: A
    def minBy[B](f: (A) => B): A
    def mkString: String
    def mkString(sep: String): String
    def mkString(start: String, sep: String, end: String): String
    def nonEmpty: Boolean
    def par: ParSet[A]
    def partition(p: (A) => Boolean): (Set[A], Set[A])
    def product: A
    def reduce[A1 >: A](op: (A1, A1) => A1): A1
    def reduceLeft[B >: A](op: (B, A) => B): B
    def reduceLeftOption[B >: A](op: (B, A) => B): Option[B]
    def reduceOption[A1 >: A](op: (A1, A1) => A1): Option[A1]
    def reduceRight[B >: A](op: (A, B) => B): B
    def reduceRightOption[B >: A](op: (A, B) => B): Option[B]
    def repr: Set[A]
    def sameElements(that: GenIterable[A]): Boolean
    def scan[B >: A, That](z: B)(op: (B, B) => B)(implicit cbf: CanBuildFrom[Set[A], B, That]): That
    def scanLeft[B, That](z: B)(op: (B, A) => B)(implicit bf: CanBuildFrom[Set[A], B, That]): That
    def scanRight[B, That](z: B)(op: (A, B) => B)(implicit bf: CanBuildFrom[Set[A], B, That]): That
    def seq: Set[A]
    def size: Int
    def slice(from: Int, until: Int): Set[A]
    def sliding(size: Int, step: Int): Iterator[Set[A]]
    def sliding(size: Int): Iterator[Set[A]]
    def span(p: (A) => Boolean): (Set[A], Set[A])
    def splitAt(n: Int): (Set[A], Set[A])
    def stringPrefix: String
    def subsetOf(that: GenSet[A]): Boolean
    def subsets(): Iterator[Set[A]]
    def subsets(len: Int): Iterator[Set[A]]
    def sum: A
    def tail: Set[A]
    def tails: Iterator[Set[A]]
    def take(n: Int): Set[A]
    def takeRight(n: Int): Set[A]
    def takeWhile(p: (A) => Boolean): Set[A]
    def to[Col[_]]: Col[A]
    def toArray: Array[A]
    def toBuffer[A1 >: A]: Buffer[A1]
    def toIndexedSeq: immutable.IndexedSeq[A]
    def toIterable: Iterable[A]
    def toIterator: Iterator[A]
    def toList: List[A]
    def toMap[T, U]: Map[T, U]
    def toParArray: ParArray[T]
    def toSeq: Seq[A]
    def toSet[B >: A]: immutable.Set[B]
    def toStream: immutable.Stream[A]
    def toString(): String
    def toTraversable: Traversable[A]
    def toVector: Vector[A]
    def transpose[B](implicit asTraversable: (A) => GenTraversableOnce[B]): Set[Set[B]]
    def union(that: GenSet[A]): Set[A]
    def unzip[A1, A2](implicit asPair: (A) => (A1, A2)): (Set[A1], Set[A2])
    def unzip3[A1, A2, A3](implicit asTriple: (A) => (A1, A2, A3)): (Set[A1], Set[A2], Set[A3])
    def view(from: Int, until: Int): IterableView[A, Set[A]]
    def view: IterableView[A, Set[A]]
    def withFilter(p: (A) => Boolean): FilterMonadic[A, Set[A]]
    def zip[B](that: GenIterable[B]): Set[(A, B)]
    def zipAll[B](that: Iterable[B], thisElem: A, thatElem: B): Set[(A, B)]
    def zipWithIndex: Set[(A, Int)]
    def |(that: GenSet[A]): Set[A]
object Set extends SetFactory[Set] 
    def apply[A](elems: A*): Set[A]
    def empty[A]: Set[A]
    def newBuilder[A]: Builder[A, immutable.Set[A]]
    def setCanBuildFrom[A]: CanBuildFrom[Set[_], A, Set[A]]
trait Map[A, +B] extends Iterable[(A, B)] with GenMap[A, B] with MapLike[A, B, Map[A, B]] 
    abstract def get(key: A): Option[B]
    abstract def iterator: Iterator[(A, B)]
    def +(kvs: (A, B)*): Map[A, B]
    abstract def +(kv: (A, B)): Map[A, B]
    def ++(xs: Traversable[(A, B)]): Map[A, B]
    def ++[B](that: GenTraversableOnce[B]): Map[B]
    def ++:[B >: (A, B), That](that: Traversable[B])(implicit bf: CanBuildFrom[Map[A, B], B, That]): That
    def ++:[B](that: TraversableOnce[B]): Map[B]
    def -(elem1: A, elem2: A, elems: A*): Map[A, B]
    abstract def -(key: A): Map[A, B]
    def --(xs: GenTraversableOnce[A]): Map[A, B]
    def /:[B](z: B)(op: (B, (A, B)) => B): B
    def :\[B](z: B)(op: ((A, B), B) => B): B
    def addString(b: StringBuilder, start: String, sep: String, end: String): StringBuilder
    def addString(b: StringBuilder): StringBuilder
    def addString(b: StringBuilder, sep: String): StringBuilder
    def aggregate[B](z: => B)(seqop: (B, (A, B)) => B, combop: (B, B) => B): B
    def andThen[C](k: (B) => C): PartialFunction[A, C]
    def apply(key: A): B
    def applyOrElse[A1 <: A, B1 >: B](x: A1, default: (A1) => B1): B1
    def canEqual(that: Any): Boolean
    def collect[B](pf: PartialFunction[A, B]): Map[B]
    def collectFirst[B](pf: PartialFunction[(A, B), B]): Option[B]
    def companion: GenericCompanion[Iterable]
    def compose[A](g: (A) => A): (A) => B
    def contains(key: A): Boolean
    def copyToArray(xs: Array[A], start: Int, len: Int): Unit
    def copyToArray(xs: Array[A]): Unit
    def copyToArray(xs: Array[A], start: Int): Unit
    def copyToBuffer[B >: (A, B)](dest: Buffer[B]): Unit
    def count(p: ((A, B)) => Boolean): Int
    def default(key: A): B
    Defines the default value computation for the map, returned when a key is not found The method implemented here throws an exception, but it might be overridden in subclasses.
    def drop(n: Int): Map[A, B]
    def dropRight(n: Int): Map[A, B]
    def dropWhile(p: ((A, B)) => Boolean): Map[A, B]
    def empty: Map[A, B]
    def equals(that: Any): Boolean
    def exists(p: ((A, B)) => Boolean): Boolean
    def filter(p: ((A, B)) => Boolean): Map[A, B]
    def filterKeys(p: (A) => Boolean): Map[A, B]
    def filterNot(p: ((A, B)) => Boolean): Map[A, B]
    def find(p: ((A, B)) => Boolean): Option[(A, B)]
    def flatMap[B](f: (A) => GenTraversableOnce[B]): Map[B]
    def flatten[B]: Map[B]
    def fold[A1 >: (A, B)](z: A1)(op: (A1, A1) => A1): A1
    def foldLeft[B](z: B)(op: (B, (A, B)) => B): B
    def foldRight[B](z: B)(op: ((A, B), B) => B): B
    def forall(p: ((A, B)) => Boolean): Boolean
    def foreach(f: ((A, B)) => Unit): Unit
    def genericBuilder[B]: Builder[B, Iterable[B]]
    def getOrElse(key: A, default: => B): B
    def groupBy[K](f: ((A, B)) => K): immutable.Map[K, Map[A, B]]
    def grouped(size: Int): Iterator[Map[A, B]]
    def hasDefiniteSize: Boolean
    def hashCode(): Int
    def head: (A, B)
    def headOption: Option[(A, B)]
    def init: Map[A, B]
    def inits: Iterator[Map[A, B]]
    def isDefinedAt(key: A): Boolean
    def isEmpty: Boolean
    def keySet: Set[A]
    def keys: Iterable[A]
    def keysIterator: Iterator[A]
    def last: (A, B)
    def lastOption: Option[(A, B)]
    def lift: (A) => Option[B]
    def map[B](f: (A) => B): Map[B]
    def mapValues[C](f: (B) => C): Map[A, C]
    def max: A
    def maxBy[B](f: (A) => B): A
    def min: A
    def minBy[B](f: (A) => B): A
    def mkString: String
    def mkString(sep: String): String
    def mkString(start: String, sep: String, end: String): String
    def nonEmpty: Boolean
    def orElse[A1 <: A, B1 >: B](that: PartialFunction[A1, B1]): PartialFunction[A1, B1]
    def par: ParMap[A, B]
    def partition(p: ((A, B)) => Boolean): (Map[A, B], Map[A, B])
    def product: A
    def reduce[A1 >: (A, B)](op: (A1, A1) => A1): A1
    def reduceLeft[B >: (A, B)](op: (B, (A, B)) => B): B
    def reduceLeftOption[B >: (A, B)](op: (B, (A, B)) => B): Option[B]
    def reduceOption[A1 >: (A, B)](op: (A1, A1) => A1): Option[A1]
    def reduceRight[B >: (A, B)](op: ((A, B), B) => B): B
    def reduceRightOption[B >: (A, B)](op: ((A, B), B) => B): Option[B]
    def repr: Map[A, B]
    def runWith[U](action: (B) => U): (A) => Boolean
    def sameElements(that: GenIterable[A]): Boolean
    def scan[B >: (A, B), That](z: B)(op: (B, B) => B)(implicit cbf: CanBuildFrom[Map[A, B], B, That]): That
    def scanLeft[B, That](z: B)(op: (B, (A, B)) => B)(implicit bf: CanBuildFrom[Map[A, B], B, That]): That
    def scanRight[B, That](z: B)(op: ((A, B), B) => B)(implicit bf: CanBuildFrom[Map[A, B], B, That]): That
    def seq: Map[A, B]
    def size: Int
    def slice(from: Int, until: Int): Map[A, B]
    def sliding(size: Int, step: Int): Iterator[Map[A, B]]
    def sliding(size: Int): Iterator[Map[A, B]]
    def span(p: ((A, B)) => Boolean): (Map[A, B], Map[A, B])
    def splitAt(n: Int): (Map[A, B], Map[A, B])
    def stringPrefix: String
    def sum: A
    def tail: Map[A, B]
    def tails: Iterator[Map[A, B]]
    def take(n: Int): Map[A, B]
    def takeRight(n: Int): Map[A, B]
    def takeWhile(p: ((A, B)) => Boolean): Map[A, B]
    def to[Col[_]]: Col[A]
    def toArray: Array[A]
    def toBuffer[C >: (A, B)]: Buffer[C]
    def toIndexedSeq: immutable.IndexedSeq[(A, B)]
    def toIterable: Iterable[(A, B)]
    def toIterator: Iterator[(A, B)]
    def toList: List[(A, B)]
    def toMap[T, U]: Map[T, U]
    def toParArray: ParArray[T]
    def toSeq: Seq[(A, B)]
    def toSet[B >: (A, B)]: immutable.Set[B]
    def toStream: immutable.Stream[(A, B)]
    def toString(): String
    def toTraversable: Traversable[(A, B)]
    def toVector: Vector[(A, B)]
    def transpose[B](implicit asTraversable: ((A, B)) => GenTraversableOnce[B]): Iterable[Iterable[B]]
    def unzip[A1, A2](implicit asPair: ((A, B)) => (A1, A2)): (Iterable[A1], Iterable[A2])
    def unzip3[A1, A2, A3](implicit asTriple: ((A, B)) => (A1, A2, A3)): (Iterable[A1], Iterable[A2], Iterable[A3])
    def updated(key: A, value: B): Map[A, B]
    def values: Iterable[B]
    def valuesIterator: Iterator[B]
    def view(from: Int, until: Int): IterableView[(A, B), Map[A, B]]
    def view: IterableView[(A, B), Map[A, B]]
    def withFilter(p: ((A, B)) => Boolean): FilterMonadic[(A, B), Map[A, B]]
    def zip[B](that: GenIterable[B]): Map[(A, B)]
    def zipAll[B](that: Iterable[B], thisElem: A, thatElem: B): Map[(A, B)]
    def zipWithIndex: Map[(A, Int)]
object Map extends MapFactory[Map] 
    def apply[A, B](elems: (A, B)*): Map[A, B]
    def empty[A, B]: immutable.Map[A, B]
    def newBuilder[A, B]: Builder[(A, B), Map[A, B]]

    
    
////*** foldLeft, reduceLeft, scanLeft 
//- takes a Function with 1st arg = return/initializer type, 2nd arg - element type

def foldLeft [B] (z: B)(f: (B, A) => B): B    //takes initializer , can produce any output
def reduceLeft [B >: A] (f: (B, A) => B): B   // does not take initializer , reduces to one value

//scanLeft is like foldLeft, but gives intermediate results
def scanLeft [B] (z: B)(f: (B, A) => B): B

//Note reduceLeft ===== list.tail.foldLeft(list.head)(_)
//Hence reduceLeft reduces  only to list.head type and foldLeft is generic

List(1,3,5).foldLeft(List[String]()) { (a, b) => b.toString :: a }
List("Ok" , 1, 2).foldLeft( new String() ) ( (r, i) => r + i.toString)

//Note Mixed type handling is challenging in reduceLeft 
List("Ok" , 1, 2).reduceLeft( (r:String, i) => r + i.toString) //Error

//One option is to use pattern matching, only below works 
List("Ok" , 1, 2, 3.0, 4L).reduceLeft{ (r, i) => (r:Any, i:Any) match 
                                    {  case (r:String , i:String) => r + i
                                        case (r:String, i:Number) => r + i.toString  //to handle all types
                                        }
                                    }

    
scala> List.range(1,10).scanLeft(0)( (r,i) => r + i)
res79: List[Int] = List(0, 1, 3, 6, 10, 15, 21, 28, 36, 45)

scala> List.range(1,10).scanLeft(new String("") )( (r,i) => r + i)
res80: List[String] = List("", 1, 12, 123, 1234, 12345, 123456, 1234567, 12345678, 123456789)

//For Map
//foldLeft - can produce any result depending on initializer
//reduceLeft - produce one tuple of type map.head 

scala> Map(1->2, 2->3).foldLeft(Map[Int,Int]())( (r, kv ) => r + (kv._2 -> kv._1) )
res72: scala.collection.immutable.Map[Int,Int] = Map(2 -> 1, 3 -> 2)

scala> Map[Int,Int](1->2, 2->3).reduce(  (r, kv ) => (r._1 + kv._1, r._2 + kv._2) )
res76: (Int, Int) = (3,5)
	
scala> Map[Int,Int](1->2, 2->3).scanLeft(new String("") ) (  (r, kv ) => r + kv )
res82: scala.collection.immutable.Iterable[String] = List("", (1,2), (1,2)(2,3))


//Example - read file with deliminator of any number of \n 
//Example file:
qbcd
abcd
abcd

cdfe
cdef



abcd
abcs


abcd
//read file with deliminator of any number of \n 
scala> val lns = scala.io.Source.fromFile("xy.txt").getLines.toList
lns: List[String] = List(qbcd, abcd, abcd, "", cdfe, cdef, "", "", "", abcd, abs, "", "", abcd)

def pr( r:collection.mutable.ListBuffer[collection.mutable.ListBuffer[String]], e:String)=
    {if (! e.isEmpty ) r.last.append(e) else if(e.isEmpty && r.last.isEmpty) r  else r.append(collection.mutable.ListBuffer());r}

scala> lns.foldLeft(ListBuffer[ListBuffer[String]](ListBuffer[String]()))(pr _)
res46: scala.collection.mutable.ListBuffer[scala.collection.mutable.ListBuffer[String]] = ListBuffer(ListBuffer(qbcd, abcd, abcd), 
ListBuffer(cdfe, cdef), ListBuffer(abcd, abcs), ListBuffer(abcd))


//More example 

scala> L.sum
res42: Int = 6

scala> L.reduceLeft{ (ret : Int, e:Int) => ret+e }
res43: Int = 6

scala> L.foldLeft(100){ (ret : Int, e:Int) => ret+e }
res44: Int = 106

scala> m.toList.foldLeft(0) { (ret:Int ,x) => ret + x._2 }
res59: Int = 5

					 
///*** map , flatMap and collect

//map is used to transform C[A] to C[B] Given a function f: A=>B

//flatMap is a map with flatten , used only when function, f,  produces C[B] , hence flatten is required 
//function for flatMap must return a Container class 
//Only Outermost two container class is flattened to one container class.

//map takes a Function 
//Collect takes PartialFunction and collects only where PartialFunction is defined
//Note PartialFunction and Function are written inside {}
//Where PartialFunction must have pattern match , case ... => which is defined only in some domain of input 
//Function can be fullt specified as (x) =>   or one or multiple case ... => , but is defined in whole domain 

//collect is a convenient way to simultaneously map and filter
scala> (1 to 10) collect { case x:Int if x % 2 == 0 => -x; case 1 => 11 }
res0: scala.collection.immutable.IndexedSeq[Int] = Vector(11, -2, -4, -6, -8, -10)

scala> val pf: PartialFunction[Int, Int] = { case x if x % 2 == 0 =>
 -x; case 1 => 11 }
pf: PartialFunction[Int,Int] = 

scala> (1 to 10) collect pf
res1: scala.collection.immutable.IndexedSeq[Int] = Vector(11, -2, -4, -6, -8, -10)

//example 
val l = List(1, 2.0, "OK")  //l: List[Any] = List(1, 2.0, OK)

val l2 = List(1,2,3)    //l2: List[Int] = List(1, 2, 3)
l2 flatMap (x => List(x, x*x, x*x*x))   //res4: List[Int] = List(1, 1, 1, 2, 4, 8, 3, 9, 27)
l2 map (x => List(x, x*x, x*x*x))  //res5: List[List[Int]] = List(List(1, 1, 1), List(2, 4, 8),


//Partially defined and returns only those 
l.collect { case x:String => x.size}  //res8: List[Int] = List(2)
//fully defined 
l.map {
      case x:Int => x*x
      case x:Double => x*x
      case x:String => x.size
      case _ => 0
      }
//res12: List[Double] = List(1.0, 4.0, 2.0)
//OR as l has only Int, DOuble, String 
l.map {
    case x:Int => x*x
    case x:Double => x*x
    case x:String => x.size
}

//More examples 

scala> L.map { x => x*x }
res46: scala.collection.mutable.ListBuffer[Int] = ListBuffer(9, 9)

scala> m.toList map { x => x._1*2 -> x._2 }
res47: List[(String, Int)] = List((NOKNOK,3), (OKOK,2))

scala> (m.toList map { x => x._1*2 -> x._2 }).toMap
res51: scala.collection.immutable.Map[String,Int] = Map(NOKNOK -> 3, OKOK -> 2)

//With Map
//Convert to List of Tuple , toList and then use map, filter, sorted, sortBy

val names = Map("fname" -> "Robert",   "lname" -> "Goren")
names.toList sortBy ( _._2 ) foreach { println }
(names.toList map { x => x._1*2 -> x._2 }).toMap
(names.toList.filter{ x => x._1.startsWith("N")}).toMap
names.toList.foldLeft(0) { (ret:Int ,x) => ret + x._2 }

//OR directly with Map
Map("a" -> 1, "b" -> 2) map { case (x, y) => (y, x) }  // = Map(1 -> a, 2 -> b)
Map("a" -> 1, "b" -> 2) map { case (x, y) => y }  //= List(1, 2)
Map("a" -> 1, "b" -> 2) filter { case (x, y) => x == "a" }

//or with Tuple

Map("a" -> 1, "b" -> 2) filter { (kv) => kv._1 == "a" }
Map("a" -> 1, "b" -> 2) map { (kv) => (kv._2, kv._1) }

//Converting to another type using collection.breakOut

val map : Map[Int,String] = List("London", "Paris").map(x => (x.length, x))(collection.breakOut)
//map: Map[Int,String] = Map(6 -> London, 5 -> Paris)


//Filter

scala> L.filter{ _.toString.endsWith("3")}
res61: scala.collection.mutable.ListBuffer[Int] = ListBuffer(3, 3)

scala> L.filter{ _.toString.endsWith("1")}
res62: scala.collection.mutable.ListBuffer[Int] = ListBuffer()

scala> (m.toList.filter{ x => x._1.startsWith("N")}).toMap
res64: scala.collection.immutable.Map[String,Int] = Map(NOK -> 3)






///*** Other methods 

//every alternate elements
scala> List(10,20,30,40).zipWithIndex.filter{ case (e,i) => i % 2 == 0 } map { case (e,i) => e }
res15: List[Int] = List(10, 30)

scala> List(10,20,30,40).zipWithIndex.collect {case (e,i) if i % 2 == 0 =>  e}
res16: List[Int] = List(10, 30)

scala> List(10,20,30,40).drop(1).grouped(2).map(_.head).toList
res19: List[Int] = List(20, 40)

scala> List(10,20,30,40).grouped(2).map(_.head).toList
res20: List[Int] = List(10, 30)

scala> val l = List(10,20,30,40)
l: List[Int] = List(10, 20, 30, 40)

scala> for (step <- Range(start = 0, end = l.length, step = 2))  yield l(step)
res21: scala.collection.immutable.IndexedSeq[Int] = Vector(10, 30)

//zip
scala> List(1,2,3).zip(List(2,3,4))
res23: List[(Int, Int)] = List((1,2), (2,3), (3,4))

//count
scala> List(1,2,3).count{ i => i == 2 }
res24: Int = 1

//take(num), takeWhile(pred), drop(num), dropWhile(pred) , groupBy
scala> List(1,2,3,2,3,4).groupBy{ i => List(1,2,3,2,3,4).count(c => i==c) }
res26: scala.collection.immutable.Map[Int,List[Int]] = Map(2 -> List(2, 3, 2, 3), 1 -> List(1, 4))

//Partition, sliding
scala> List(1,2,3).partition{ i => i % 2 == 0 }
res28: (List[Int], List[Int]) = (List(2),List(1, 3))

scala> List(1,2,3).sliding(2,1).toList
res30: List[List[Int]] = List(List(1, 2), List(2, 3))

//permutations, combinations, Shuffle 
"abbbc".combinations(2).toList
"abb".permutations.toList
scala.util.Random.shuffle(List(1,2,3))

//All combinations without repetitions

scala> List(1,2,3).toSet[Int].subsets.map(_.toList).toList
res22: List[List[Int]] = List(List(), List(1), List(2), List(3), List(1, 2), List(1, 3), ...
 
//OR
def combine(in: List[Char]): Seq[String] =  for {
        len <- 1 to in.length
        combinations <- in combinations len
    } yield combinations.mkString 
	
//OR
def powerset[A](s: Set[A]) = s.foldLeft(Set(Set.empty[A])) { case (ss, el) => ss ++ ss.map(_ + el) }


//combinations with repetitions
val input = List('A','C','G')

scala > (input ++ input ++ input) combinations(3) toList

scala > input.flatMap(_ => input).combinations(3).toList
res27: List[List[Char]] = List(List(A, A, A), List(A, A, C), List(A, A, G),...

// considering that we want a combination size
//List.fill(size)(input).flatten.combinations(size).toList

val a = List.fill(2)(List("A","B","C")).flatten.combinations(2).toList

//OR

scala> def comb(s:String)=(s * s.length).combinations(s.length)

scala> comb("ACG").toList
res16: List[String] = List(AAA, AAC, AAG, ACC, ACG, AGG, CCC, CCG, CGG, GGG)

//permutations with repetitions
scala> comb("ACG").flatMap(_.toSeq.permutations.toList).toList
res28: List[Seq[Char]] = List(AAA, AAC, ACA, CAA, AAG, AGA, GAA, ACC, CAC ...

//Map - memoization - withDefault

val m:collection.mutable.Map[BigInt,BigInt] = new collection.mutable.HashMap[BigInt,BigInt]().withDefault { n => { m(n) = if (n<2) n else (m(n-1) + m(n-2)); m(n)} }
println(m(100))



///* Iterating a Collection and for comprehension
//foreach for COllection, for Map - convert to List of tuples or use {case (x,y) => }

L.foreach { println }

m.toList.foreach { println _ }    //or 
m.foreach { println(_._1 + " " + _._2) }
m.foreach { case(k,v) => println(k) }

//Can call keys(), values() to get keys and values
//toList gives tupleSet
// For list , for ( i <- list ) or for Map for ( (k,v) <- map ) 
val names = Map("fname" -> "Robert", "lname" -> "Goren")
for ((k,v) <- names) println(s"key: $k, value: $v")

"""
Rules for 'for' translation of for 

 1. A simple for loop that iterates over a collection is translated to a foreach method call on the collection.
 2. A for loop with a guard is translated to a sequence of a withFilter  method call on the collection followed by a foreach call.
 3. A for loop with a yield expression is translated to a map method call on the collection.
 4. A for loop with a yield expression and a guard is translated to a withFilter method call on the collection, followed by a map method call.
 5. A for loop containing multiple <- is translated to flatMap ... for other than last <- and then last <- as map

$ scalac -Xprint:parse Main.scala   // or -Xprint:all
"""
//In Scala, for comprehension is syntactic sugar for Monadic form ie flatMap and map
// Any container class can be used inside 'for' if class contains flatMap and map methods and foreach and withFilter

val first = List(1, 2)
val next = List(8, 9)
val last = List("ab", "cde", "fghi")

for {
  i <- first    // Here <- means 'Unbox container type to underlying type.  container type must have flatMap
  j <- next
  k <- last
}yield(i * j * k.length)

//Equivalent to Monadic form
first flatMap {
  i => next flatMap {
    j => last map {
      k => i * j * k.length
    }
  }
}

//Pythogoran triplets
def pytho(n:Int) = for { x <- List.range(1,n)
                       y <- List.range(x,n)
	                   z <- List.range(x, n) if x*x + y*y == z*z 
	                   } yield (x,y,z)
	  
//yield always creates a container class from the first <- inside 'for'
//to convert to other type for assignment, use collection.breakOut

for {i <- 1 to 10  if i % 2 == 0
   x = i * i                     //no val, is deprecated
   j <- 1 to x    if j % 2 == 1
 }
yield {
  val y = i*i
  y -> j 
 }

//to convert to any Seq , use (collection.breakOut)
val x:List[(Int,Int)] = (for {i <- 1 to 10  if i % 2 == 0
   x = i * i
   j <- 1 to x    if j % 2 == 1
 }
yield ( i -> j ) )(collection.breakOut)

	  

///*Sort
val L = List(1,2,3)
val m = collection.mutable.Map[String,Int]()
m("OK") = 2

scala> L.sorted
res25: scala.collection.mutable.ListBuffer[Int] = ListBuffer(3, 3)

scala> L.sortBy{ x:Int => -x }
res28: scala.collection.mutable.ListBuffer[Int] = ListBuffer(3, 3)


scala> m.toList sortBy ( _._2 ) foreach { println }
(OK,2)
(NOK,3)

//OR sortBy does not exists in Map
Map("a" -> 1, "b" -> 2).toList.sortBy{ case (x,y) => y }

val words = "The quick brown fox jumped over the lazy dog".split(' ')
// this works because scala.Ordering will implicitly provide an Ordering[Tuple2[Int, Char]]
words.sortBy(x => (x.length, x.head))
res0: Array[String] = Array(The, dog, fox, the, lazy, over, brown, quick, jumped)



///*** Value alias of object
//object has a dummy type
object A
type nn = A.type  //defined type alias nn

"""
In Package.scala, type alias 
type List[+A] = scala.collection.immutable.List[A]

The val List is a value alias for the List object (companion object). 
val List = scala.collection.immutable.List
"""

//Example : Higher dimension - List of List ie each element is List

type Row = List[Int]
type Matrix = List[Row]
val m = Matrix( Row(1,2,3),  //Error
                Row(1,2,3),
                Row(1,2,3)
              )
//Solution

type Row = List[Int]
val Row = List   //val alias of companion object List
type Matrix = List[Row]
val Matrix = List

val m = Matrix( Row(1,2,3),
                  Row(1,2,3),
                  Row(1,2,3))

m(0)(0) //res22: Int = 1
m map { case List(x,y,z) => x } //1st column, res25: List[Int] = List(1, 1, 1)
m map { case List(x, y @ _*) => x } //for variable List size 
m map { case List(x,y,z) => List(x*x, y*y, z*z) } //res26: List[List[Int]] = List(List(1, 4, 9), List(1, 4, 9), List(1, 4, 9))
m map { e => e.map( x => x*x) } //res27: List[List[Int]] = List(List(1, 4, 9), List(1, 4, 9), List(1, 4, 9))




///*** Application of Map - Read CSV and convert to case class 

val lines = scala.io.Source.fromFile(raw"..\data\iris.csv").getLines.map(_.split(",")).map{r =>r.map( _.trim)}
lines.next //header row or use lines.drop(1)
val rowts = lines.map{r => (r.slice(0,4).map(_.toDouble),r.last)}.map { case ( Array(x,y,z,a),b) => (x,y,z,a,b) }

//Convert to case class 
case class Row(sl:Double,sw:Double,pl:Double,pw:Double,Name:String)
val rowcs = rowts.map{r => Function.tupled(Row.apply _)(r)}
//OR ,val rowcs = rows.map{r => (Row.apply _).tupled(r)}


//some processing 
val rows =rowts.toList
rows.sortBy(_._5)
rows.groupBy{r => r._5}.keys //unique keys as keys are set 
//rows.groupBy{r => r._5} returns Map[String,List[(Double, Double, Double, Double, String)]]
//Finding max of first Columnof  each Name 
rows.groupBy{r => r._5}.map{case (n,l) => n->l.map(_._1).max}
//Map(Iris-virginica -> 7.9, Iris-setosa -> 5.8, Iris-versicolor -> 7.0)

//max of every  
def tupleMax(tl:List[(Double, Double, Double, Double, String)], which:Int*) = {
    which.map{w => tl.map{t => t.productElement(w).asInstanceOf[Double]}.max }
} 
rows.groupBy{r => r._5}.map{ case (k,vl) => k -> tupleMax(vl,0,1,2,3) }
//answer
Map(Iris-virginica -> ArrayBuffer(7.9, 3.8, 6.9, 2.5), 
    Iris-setosa -> ArrayBuffer(5.8, 4.4, 1.9, 0.6), 
    Iris-versicolor -> ArrayBuffer(7.0, 3.4, 5.1, 1.8))
    
///* Quick Graph 
//Good csv reader 
import com.github.tototoshi.csv._
val reader = CSVReader.open(raw"..\data\iris.csv")
val lines = reader.iterator
val rowts = lines.drop(1).map{r => (r.slice(0,4).map(_.toDouble),r.last)}.map { case ( Seq(x,y,z,a),b) => (x,y,z,a,b) }
//Quick Graphing 
val rows =rowts.toList

//scatter and line 
import co.theasi.plotly._

val xs = (0 to rows.size).toList 
def getColumn(lst:List[(Double, Double, Double, Double, String)], n:Int)(query: ((Double, Double, Double, Double, String)) => Boolean):List[Double]={
    lst.filter(query).map{t =>t.productElement(n).asInstanceOf[Double]}
}

val p = Plot()
  .withScatter(xs, getColumn(rows,0){t => t._5 == "Iris-virginica"}, 
        ScatterOptions().mode(ScatterMode.Marker).name("SepalLength"))
  .withScatter(xs, getColumn(rows,2){t => t._5 == "Iris-virginica"},
    ScatterOptions()
      .mode(ScatterMode.Marker, ScatterMode.Line)
      .name("SepalWidth"))

draw(p, "iris", writer.FileOptions(overwrite=true))

//Draw Ratios 
def ratio(lst:List[(Double, Double, Double, Double, String)])(query: ((Double, Double, Double, Double, String)) => Boolean)( n:Int, d:Int):List[Double]={
    lst.filter(query).map{t =>t.productElement(n).asInstanceOf[Double]/t.productElement(d).asInstanceOf[Double]}
}
val virginica = ratio(rows){(t:(Double, Double, Double, Double, String)) => t._5 == "Iris-virginica"}(_:Int, _:Int)

val p = Plot()
  .withScatter(virginica(0,1), virginica(2,3), 
        ScatterOptions().mode(ScatterMode.Marker).name("SepalLength"))
 
draw(p, "iris-Ratio", writer.FileOptions(overwrite=true))

  


///*** Application of Map in Excel reading 
//Apache POI library consists of two different implementations for all the above interfaces.
//    HSSF (Horrible SpreadSheet Format): HSSF implementations of POI’s high-level interfaces like HSSFWorkbook, HSSFSheet, HSSFRow and HSSFCell are used to work with excel files of the older binary file format - .xls
 //   XSSF (XML SpreadSheet Format): XSSF implementations are used to work with the newer XML based file format - .xlsx.

//sbt
libraryDependencies += "org.apache.poi" % "poi" % "3.17"
libraryDependencies += "org.apache.poi" % "poi-ooxml" % "3.17"

//Usages 
import org.apache.poi.ss.usermodel._
import java.io.File
import collection.JavaConversions._ // lets you iterate over a java iterable

val f = new File("../data/Nifty-17_Years_Data-V1.xlsx")

val workbook = WorkbookFactory.create(f)
val sheet = workbook.getSheetAt(0) // first sheet
//sheet is a Iterator of Row 

//Use below on Row 
Cell getCell(int cellnum) 
    Get the cell representing a given column (logical cell) 0-based. 
//Use below on Cell 
java.util.Date getDateCellValue() 
    Get the value of the cell as a date.
double getNumericCellValue() 
    Get the value of the cell as a number. 
java.lang.String getStringCellValue() 
    Get the value of the cell as a string 
//Date functionality 
Date(int year, int month, int date) 
Date(int year, int month, int date, int hrs, int min)  
boolean after(Date when) 
    Tests if this date is after the specified date.
boolean before(Date when) 
    Tests if this date is before the specified date.
int compareTo(Date anotherDate) 
int getDay() 
int getHours() 
int getMinutes() 
int getMonth() 
int getSeconds() 
long getTime() 
int getTimezoneOffset() 
int getYear() 
  
//Problem-1: year vs min and max of Open as map 
//Problem 2: Find the year where max diff between min and max 
//Problem -3 : Bin 10 between above diff 
//problem -4 : Then map Problem 2 values into the bin 
//Problem -5: Then invert above to get bin vs list of years and then bin to count of years 
    
    
    

//processing 
case class Data(Date:java.util.Date,Open:Double,High:Double,Low:Double,Close:Double, variation:Double,`Day Wise Variation    Open to Close`:Double) {
    def Year = Date.getYear
    def Month = Date.getMonth 
    def Day = Date.getDay 
    def Hour = Date.getHours 
    def Min = Date.getMinutes
    def Sec = Date.getSeconds
    def Time = Date.getTime 
    def TZ = Date.getTimezoneOffset
    def after(when:java.util.Date) = Date.after(when)
    def before(when:java.util.Date) = Date.before(when)
}


//Drop header row    
val t1 = sheet.drop(1).map{ row => (row.getCell(0).getDateCellValue, (1 to 6).toList.map{i=> row.getCell(i).getNumericCellValue})}
val t2 = t1.map{case (d,List(x,y,z,a,b,c)) => (d,x,y,z,a,b,c)}
val t3 = t2.map {r => (Data.apply _).tupled(r)}.toList 

//Group By Year 
val t4 = t3.groupBy(_.Year).map{case(k,v) => (k+1900)->Map("min"->v.map(_.Open).min,"max"->v.map(_.Open).max)} //year->List of Data

//Find the year where max diff between min and max 
t4.map{ case(k,v) => k->(v("max")-v("min"))}.toList.sortBy{case(k,v) => v}.last

//Or for particular year value 
val t5 = t4.map{ case(k,v) => k->(v("max")-v("min"))}.toList.sortBy{case(k,v) => v}
val t6 = collection.immutable.SortedMap(t5 : _*)
t6(2008)

//Bin 10 between above diff 
def roundAt(p: Int)(n: Double): Double = { val s = math.pow (10, p); math.round(n * s) / s }
//get diff as list and map to 10 bins 
val t7 = t6.map{case(k,v) => roundAt(2)(v) }.toList 
val t8 = t7.sorted.last - t7.sorted.head
//create a map of index vs it's value 
val t9 = (t7.sorted.head to t7.sorted.last by (t8/10)).toList.map(roundAt(2))
val t91 = t9.tail 
//to get bin  Zip it 
val t10 = t9.zip(t91).zipWithIndex.toMap
//Map((3022.05,3391.7) -> 8, (3391.7,3761.35) -> 9,(434.5,804.15) -> 1, (64.85,434.5) -> 0, (1173.8,1543.45) -> 3, (1543.45,1913.1) -> 4, (1913.1,2282.75) -> 5,

import Ordering.Implicits._ 
//Get only keys , index would be referring this list 
val t11 = t10.keys.toList.sorted //***
def findIndex(lst:List[(Double, Double)], v:Double) = lst.find{case (m,n) => if(v >= m && v < n) true else false}
//Find returns Option 
findIndex(t11, 804.15).map{ x => t10(x) }.getOrElse(0)

val t12 = t5.map{case (y,d) => y->(roundAt(2)(d), findIndex(t11, d).map{ x => t10(x) }.getOrElse(10))}.toMap
//scala.collection.immutable.Map[Int,(Double, Int)] = Map(2014 -> (2657.5,7), 2010 -> (1622.5,4), 2007 -> (

//map GroupBy would return values as Map , m is map 
val t13 = t12.groupBy{case (k, (d,i)) => i}.map{case (i, m) => i->m.keys.toList}
//scala.collection.immutable.Map[Int,List[Int]] = Map(0 -> List(2002, 2000, 2018),
val t14 = t13.map{case(k,v) => k-> v.size}
//scala.collection.immutable.Map[Int,Int] = Map(0 -> 3, 5 -> 1, 10 -> 1, 1 -> 2, 6 -> 3
//Put back the index with bin 
t14.map{case(k,v) => (if (k >=t11.size)(t11.last._2,Double.PositiveInfinity) else t11(k))->v  }






///*** Scala Stream, Iterator, parallel, lazy collection

//Use stream, Iterator , or collection.view , all operations lazily. 
//use 'force' for 'view' or toList/toArray etc for others to compute them

reflect.runtime.universe.typeOf[Stream[Int]].members.toSet

//Stream - Main methods - Use List methods, #::, #:::  for concatenation, instead of :: and ::: of List 
//Use collection.toStream  to convert to Stream

//Stream uses Memoization, when it is used as val . Can cause OutOfMemory
//To avoid, use  def or lazy val 

lazy val fibs: Stream[BigInt] =  BigInt(0) #::  BigInt(1) #:: fibs.zip(fibs.tail).map{ case (a,b) => a+b }
//fibs: Stream[scala.math.BigInt] = <lazy>

//OR
def fibFrom(a: Int, b: Int): Stream[Int] = a #:: fibFrom(b,a + b) //not tail recursive

fibs.take(10000).toList.length   
fibFrom(1,2).take(10000).toList.length

//Or
val fibs = Stream.iterate((1,1)){case (a,b) => (b,a+b)}.map(_._1)

//calculate the fixpoint of the cosine function, 
//i.e. the value where  cos(x) == x .

import scala.math._
val cosines = Stream.iterate(1.0)(cos)
def pairsOf(xs:Stream[Double]) = xs zip xs.tail   //Iterator does not have tail
val result = for { (x,y) <- pairsOf cosines if x == y } yield x 
result.head


//Stream object has following methods(hence use prefix Stream)
//the stream returning the infinite sequence of values `start, f(start), f(f(start)), ...`
def iterate[A](start: A)(f: A => A): Stream[A] 
def iterate[A](start: A, len: Int)(f: A => A)
//calling function f(n) n times 
def tabulate[A](n: Int)(f: Int => A): Stream[A] 
//Create an infinite stream starting at `start` and incrementing by step `step`.
def from(start: Int, step: Int): Stream[Int] 
def from(start: Int): Stream[Int] 
//Create an infinite stream containing the given element expression (which is computed for each occurrence).
def continually[A](elem: => A): Stream[A] 
//filling 
def fill[A](n: Int)(elem: => A): Stream[A] 
//From range
def range[T: Integral](start: T, end: T, step: T): Stream[T]

//Reference 
abstract class Stream[+A] extends AbstractSeq[A] with LinearSeq[A] with GenericTraversableTemplate[A, Stream] with LinearSeqOptimized[A, Stream[A]] with Serializable 
    def #::(hd: A): Stream[A]
    def #:::(prefix: Stream[A]): Stream[A]
    def ++[B >: A, That](that: GenTraversableOnce[B])(implicit bf: CanBuildFrom[Stream[A], B, That]): That
    def ++:[B >: A, That](that: collection.Traversable[B])(implicit bf: CanBuildFrom[Stream[A], B, That]): That
    def ++:[B](that: TraversableOnce[B]): Stream[B]
    def +:(elem: A): Stream[A]
    def /:[B](z: B)(op: (B, A) => B): B
    def :+(elem: A): Stream[A]
    def :\[B](z: B)(op: (A, B) => B): B
    def addString(b: mutable.StringBuilder, start: String, sep: String, end: String): mutable.StringBuilder
    def addString(b: StringBuilder): StringBuilder
    def addString(b: StringBuilder, sep: String): StringBuilder
    def aggregate[B](z: => B)(seqop: (B, A) => B, combop: (B, B) => B): B
    def andThen[C](k: (A) => C): PartialFunction[Int, C]
    def append[B >: A](rest: => TraversableOnce[B]): Stream[B]
    def apply(n: Int): A
    def applyOrElse[A1 <: Int, B1 >: A](x: A1, default: (A1) => B1): B1
    def canEqual(that: Any): Boolean
    def collectFirst[B](pf: PartialFunction[A, B]): Option[B]
    def combinations(n: Int): Iterator[Stream[A]]
    def companion: GenericCompanion[Stream]
    def compose[A](g: (A) => Int): (A) => A
    def contains[A1 >: A](elem: A1): Boolean
    def containsSlice[B](that: GenSeq[B]): Boolean
    def copyToArray(xs: Array[A], start: Int, len: Int): Unit
    def copyToArray(xs: Array[A]): Unit
    def copyToArray(xs: Array[A], start: Int): Unit
    def copyToBuffer[B >: A](dest: Buffer[B]): Unit
    def count(p: (A) => Boolean): Int
    def diff(that: collection.Seq[A]): Stream[A]
    def distinct: Stream[A]
    def dropRight(n: Int): Stream[A]
    def dropWhile(p: (A) => Boolean): Stream[A]
    def endsWith[B](that: GenSeq[B]): Boolean
    def equals(that: Any): Boolean
    def exists(p: (A) => Boolean): Boolean
    def filter(p: (A) => Boolean): Stream[A]
    def filterNot(p: (A) => Boolean): Stream[A]
    def find(p: (A) => Boolean): Option[A]
    def flatten[B](implicit asTraversable: (A) => GenTraversableOnce[B]): Stream[B]
    def fold[A1 >: A](z: A1)(op: (A1, A1) => A1): A1
    def foldRight[B](z: B)(op: (A, B) => B): B
    def forall(p: (A) => Boolean): Boolean
    def force: Stream[A]
    def genericBuilder[B]: Builder[B, Stream[B]]
    def groupBy[K](f: (A) => K): Map[K, Stream[A]]
    def grouped(size: Int): Iterator[Stream[A]]
    def hasDefiniteSize: Boolean
    def hashCode(): Int
    def head: A
    def headOption: Option[A]
    def indexOf(elem: A, from: Int): Int
    def indexOf(elem: A): Int
    def indexOfSlice[B >: A](that: GenSeq[B], from: Int): Int
    def indexOfSlice[B >: A](that: GenSeq[B]): Int
    def indexWhere(p: (A) => Boolean, from: Int): Int
    def indexWhere(p: (A) => Boolean): Int
    def indices: Range
    def init: Stream[A]
    def inits: Iterator[Stream[A]]
    def intersect(that: collection.Seq[A]): Stream[A]
    def isDefinedAt(x: Int): Boolean
    def isEmpty: Boolean
    def iterator: Iterator[A]
    def last: A
    def lastIndexOf(elem: A, end: Int): Int
    def lastIndexOf(elem: A): Int
    def lastIndexOfSlice[B >: A](that: GenSeq[B], end: Int): Int
    def lastIndexOfSlice[B >: A](that: GenSeq[B]): Int
    def lastIndexWhere(p: (A) => Boolean, end: Int): Int
    def lastIndexWhere(p: (A) => Boolean): Int
    def lastOption: Option[A]
    def length: Int
    def lengthCompare(len: Int): Int
    def lift: (Int) => Option[A]
    def max: A
    def maxBy[B](f: (A) => B): A
    def min: A
    def minBy[B](f: (A) => B): A
    def mkString(start: String, sep: String, end: String): String
    def mkString: String
    def mkString(sep: String): String
    def nonEmpty: Boolean
    def orElse[A1 <: Int, B1 >: A](that: PartialFunction[A1, B1]): PartialFunction[A1, B1]
    def padTo[B >: A, That](len: Int, elem: B)(implicit bf: CanBuildFrom[Stream[A], B, That]): That
    def par: ParSeq[A]
    def partition(p: (A) => Boolean): (Stream[A], Stream[A])
    def patch(from: Int, that: GenSeq[A], replaced: Int): Stream[A]
    def permutations: Iterator[Stream[A]]
    def prefixLength(p: (A) => Boolean): Int
    def print(sep: String): Unit
    def print(): Unit
    def product: A
    def reduce[A1 >: A](op: (A1, A1) => A1): A1
    def reduceLeftOption[B >: A](op: (B, A) => B): Option[B]
    def reduceOption[A1 >: A](op: (A1, A1) => A1): Option[A1]
    def reduceRight[B >: A](op: (A, B) => B): B
    def reduceRightOption[B >: A](op: (A, B) => B): Option[B]
    def repr: Stream[A]
    def reverse: Stream[A]
    def reverseIterator: Iterator[A]
    def reverseMap[B](f: (A) => B): Stream[B]
    def runWith[U](action: (A) => U): (Int) => Boolean
    def sameElements(that: GenIterable[A]): Boolean
    def scan[B >: A, That](z: B)(op: (B, B) => B)(implicit cbf: CanBuildFrom[Stream[A], B, That]): That
    def scanRight[B, That](z: B)(op: (A, B) => B)(implicit bf: CanBuildFrom[Stream[A], B, That]): That
    def segmentLength(p: (A) => Boolean, from: Int): Int
    def seq: LinearSeq[A]
    def size: Int
    def slice(from: Int, until: Int): Stream[A]
    def sliding(size: Int, step: Int): Iterator[Stream[A]]
    def sliding(size: Int): Iterator[Stream[A]]
    def sortBy[B](f: (A) => B)(implicit ord: math.Ordering[B]): Stream[A]
    def sortWith(lt: (A, A) => Boolean): Stream[A]
    def sorted[B >: A](implicit ord: math.Ordering[B]): Stream[A]
    def span(p: (A) => Boolean): (Stream[A], Stream[A])
    def splitAt(n: Int): (Stream[A], Stream[A])
    def startsWith[B](that: GenSeq[B], offset: Int): Boolean
    def startsWith[B](that: GenSeq[B]): Boolean
    def stringPrefix: String
    def sum: A
    def tail: Stream[A]
    def tails: Iterator[Stream[A]]
    def take(n: Int): Stream[A]
    def takeRight(n: Int): Stream[A]
    def takeWhile(p: (A) => Boolean): Stream[A]
    def to[Col[_]]: Col[A]
    def toArray: Array[A]
    def toBuffer[B >: A]: Buffer[B]
    def toIndexedSeq: IndexedSeq[A]
    def toIterable: collection.Iterable[A]
    def toIterator: Iterator[A]
    def toList: scala.List[A]
    def toMap[T, U]: collection.Map[T, U]
    def toParArray: ParArray[T]
    def toSeq: Seq[A]
    def toSet[B >: A]: Set[B]
    def toStream: Stream[A]
    def toString(): String
    def toTraversable: collection.Traversable[A]
    def toVector: scala.Vector[A]
    def transpose[B](implicit asTraversable: (A) => GenTraversableOnce[B]): Stream[Stream[B]]
    def union(that: collection.Seq[A]): Stream[A]
    def unzip[A1, A2](implicit asPair: (A) => (A1, A2)): (Stream[A1], Stream[A2])
    def unzip3[A1, A2, A3](implicit asTriple: (A) => (A1, A2, A3)): (Stream[A1], Stream[A2], Stream[A3])
    def updated(index: Int, elem: A): Stream[A]
    def view: StreamView[A, Stream[A]]
    def view(from: Int, until: Int): SeqView[A, Stream[A]]
    def zipAll[B](that: collection.Iterable[B], thisElem: A, thatElem: B): Stream[(A, B)]
    def zipWithIndex[A1 >: A, That](implicit bf: CanBuildFrom[Stream[A], (A1, Int), That]): That

 
///*Iterators (no .tail compared to Stream, but efficient)
//are data structures that allow to iterate over a sequence of elements
//They have a hasNext method for checking if there is a next element available, 
//and a next method which returns the next element and discards it from the iterator.
//hence it is lazy 

//one should never use an iterator after calling a method on it(except next,hasNext). as it is a TraversableOnce[A] 
//All List methods can be used 

scala> Iterator(1,2,3,4)
res32: Iterator[Int] = non-empty iterator

//Example:
class FibI extends Iterator[BigInt]{
    private var (a:BigInt, b:BigInt) = (0 :BigInt, 1 :BigInt)  
    def hasNext  = true 
    def next = {  
                val tmp = a; a = b; b = tmp + b;   //no Pattern matching on assignments
                a
            }
    }
    
val a = new FibI()
a.take(10).toList  

//OR
val fibs = Iterator.iterate((1,1)){case (a,b) => (b,a+b)}.map(_._1)




//Note Iterator object also has following methods (hence prefix with Iterator)
//empty Iterator
val empty: Iterator[Nothing] 
//Creates an iterator which produces a single element.
//  '''Note:''' Equivalent, but more efficient than Iterator(elem)
def single[A](elem: A): Iterator[A] 
//Creates iterator that produces the results of some element computation a number of times.
 def fill[A](len: Int)(elem: => A): Iterator[A] 
 //Creates an iterator producing the values of a given function over a range of integer values starting from 0.
//An iterator that produces the values `f(0), ..., f(n -1)`.
def tabulate[A](end: Int)(f: Int => A): Iterator[A] 
//the iterator producing values `start, start + 1, ..., end - 1`
def range(start: Int, end: Int): Iterator[Int] = range(start, end, 1)
//the iterator producing values `start, start + step, ...` up to, but excluding `end`
def range(start: Int, end: Int, step: Int): Iterator[Int] 
//the iterator producing the infinite sequence of values `start, f(start), f(f(start)), ...`
def iterate[T](start: T)(f: T => T): Iterator[T] 
//the iterator producing the infinite sequence of values `start, start + 1, start + 2, ...`
def from(start: Int): Iterator[Int] = from(start, 1)
//the iterator producing the infinite sequence of values `start, start + 1 * step, start + 2 * step, ...`
 def from(start: Int, step: Int): Iterator[Int] 
//Creates an infinite-length iterator returning the results of evaluating an expression.
//The expression is recomputed for every element.
def continually[A](elem: => A): Iterator[A] 
  
//Reference 
trait Iterator[+A] extends TraversableOnce[A] 
    abstract def hasNext: Boolean
    abstract def next(): A
    def ++(that: => Iterator[A]): Iterator[A]
    def /:[B](z: B)(op: (B, A) => B): B
    def :\[B](z: B)(op: (A, B) => B): B
    def addString(b: StringBuilder): StringBuilder
    def addString(b: StringBuilder, sep: String): StringBuilder
    def addString(b: StringBuilder, start: String, sep: String, end: String): StringBuilder
    def aggregate[B](z: => B)(seqop: (B, A) => B, combop: (B, B) => B): B
    def buffered: BufferedIterator[A]
    def collect[B](pf: PartialFunction[A, B]): Iterator[B]
    def collectFirst[B](pf: PartialFunction[A, B]): Option[B]
    def contains(elem: Any): Boolean
    def copyToArray(xs: Array[A], start: Int, len: Int): Unit
    def copyToArray(xs: Array[A]): Unit
    def copyToArray(xs: Array[A], start: Int): Unit
    def copyToBuffer[B >: A](dest: Buffer[B]): Unit
    def corresponds[B](that: GenTraversableOnce[B])(p: (A, B) => Boolean): Boolean
    def count(p: (A) => Boolean): Int
    def drop(n: Int): Iterator[A]
    def dropWhile(p: (A) => Boolean): Iterator[A]
    def duplicate: (Iterator[A], Iterator[A])
    def exists(p: (A) => Boolean): Boolean
    def filter(p: (A) => Boolean): Iterator[A]
    def filterNot(p: (A) => Boolean): Iterator[A]
    def find(p: (A) => Boolean): Option[A]
    def flatMap[B](f: (A) => GenTraversableOnce[B]): Iterator[B]
    def fold[A1 >: A](z: A1)(op: (A1, A1) => A1): A1
    def foldLeft[B](z: B)(op: (B, A) => B): B
    def foldRight[B](z: B)(op: (A, B) => B): B
    def forall(p: (A) => Boolean): Boolean
    def foreach(f: (A) => Unit): Unit
    def grouped[B >: A](size: Int): GroupedIterator[B]
    def hasDefiniteSize: Boolean
    def indexOf[B >: A](elem: B): Int
    def indexWhere(p: (A) => Boolean): Int
    def isEmpty: Boolean
    def isTraversableAgain: Boolean
    def length: Int
    def map[B](f: (A) => B): Iterator[B]
    def max: A
    def maxBy[B](f: (A) => B): A
    def min: A
    def minBy[B](f: (A) => B): A
    def mkString: String
    def mkString(sep: String): String
    def mkString(start: String, sep: String, end: String): String
    def nonEmpty: Boolean
    def padTo(len: Int, elem: A): Iterator[A]
    def partition(p: (A) => Boolean): (Iterator[A], Iterator[A])
    def patch[B >: A](from: Int, patchElems: Iterator[B], replaced: Int): Iterator[B]
    def product: A
    def reduce[A1 >: A](op: (A1, A1) => A1): A1
    def reduceLeft[B >: A](op: (B, A) => B): B
    def reduceLeftOption[B >: A](op: (B, A) => B): Option[B]
    def reduceOption[A1 >: A](op: (A1, A1) => A1): Option[A1]
    def reduceRight[B >: A](op: (A, B) => B): B
    def reduceRightOption[B >: A](op: (A, B) => B): Option[B]
    def sameElements(that: Iterator[_]): Boolean
    def scanLeft[B](z: B)(op: (B, A) => B): Iterator[B]
    def scanRight[B](z: B)(op: (A, B) => B): Iterator[B]
    def seq: Iterator[A]
    def size: Int
    def slice(from: Int, until: Int): Iterator[A]
    def sliding[B >: A](size: Int, step: Int = 1): GroupedIterator[B]
    def span(p: (A) => Boolean): (Iterator[A], Iterator[A])
    def sum: A
    def take(n: Int): Iterator[A]
    def takeWhile(p: (A) => Boolean): Iterator[A]
    def to[Col[_]]: Col[A]
    def toArray: Array[A]
    def toBuffer[B >: A]: Buffer[B]
    def toIndexedSeq: immutable.IndexedSeq[A]
    def toIterable: Iterable[A]
    def toIterator: Iterator[A]
    def toList: List[A]
    def toMap[T, U]: Map[T, U]
    def toSeq: Seq[A]
    def toSet[B >: A]: immutable.Set[B]
    def toStream: immutable.Stream[A]
    def toString(): String
    def toTraversable: Traversable[A]
    def toVector: Vector[A]
    def withFilter(p: (A) => Boolean): Iterator[A]
    def zip[B](that: Iterator[B]): Iterator[(A, B)]
    def zipAll[B](that: Iterator[B], thisElem: A, thatElem: B): Iterator[(A, B)]
    def zipWithIndex: Iterator[(A, Int)]



///* view-Lazy , has  map, filter etc work lazily, do force to force it

1 to 100						// Non lazy view Range(1, 2, 3, 4, ... 98, 99, 100)

val view = (1 to 100).view		//         SeqView(...)

val x = view.force   			//       Vector(1, 2, 3, ... 98, 99, 100)


val a = Range(1,100).toList.view.filter( _ % 2 == 0)
a.take(10)
a.take(10).force


val b = 1 #:: 2 #:: Stream.empty
val b = Range(1,1000).toStream
b.filter( _ % 2 == 0)
b.filter( _ % 2 == 0).take(10)
b.filter( _ % 2 == 0).take(10).force


//Using Parallel Collections, all collections have .par member
//to convert parallel to sequential , use .seq 
//scala.collection.parallel.immutable - Immutable, parallel data-structures 
//such as ParVector, ParRange, ParHashMap or ParHashSet
//scala.collection.parallel.mutable - Mutable, parallel data-structures 
//such as ParArray, ParHashMap, ParTrieMap or ParHashSet

val v = Vector.range(0, 10)
v.foreach(print)  		//    0123456789
v.par.foreach(print)  	//    5678901234
v.par.foreach{ e => print(e); Thread.sleep(50) }  //    0516273894

//Or Use 
import scala.collection.parallel.immutable.ParVector
 
val r = new scala.util.Random
val v = ParVector.range(0, 10)
v.foreach{ e => Thread.sleep(r.nextInt(100)); print(e) }//     0516273849

val s = List.range(1,10).toSet.par  //s: scala.collection.parallel.immutable.ParSet[Int] = ParSet(5, 1, 6, 9, 2, 7, 3, 8, 4)
//above and below can not be together, so issue?
s.map(_*2) //res30: scala.collection.parallel.immutable.ParSet[Int] = ParSet(10, 14, 6, 2, 12, 18, 16,8, 4)

scala> val s = List.range(1,10).map( _ -> 1 ).toMap.par.map { case(k,v) => (v,k)}
s: scala.collection.parallel.immutable.ParMap[Int,Int] = ParMap(1 -> 5)




///*Note on Stream 
//Note that some operations, including drop, dropWhile, flatMap or collect
// may process a large number of intermediate elements before returning. 
//These necessarily hold onto the head, since they are methods on Stream, 
//and a stream holds its own head.
//For computations of this sort where memoization is not desired, 
//use Iterator when possible.

//Iterator has below two 
//abstract def hasNext: Boolean
//abstract def next(): A


//Example 
def loop(s: String, i: Int, iter: Iterator[Int]): Unit = {
  // Stop after 200,000
  if (i < 200001) {
    if (i % 50000 == 0) println(s + i)
    loop(s, iter.next, iter)
  }
}

// Our first Stream definition will be a val definition
val stream1: Stream[Int] = {
  def loop(v: Int): Stream[Int] = v #:: loop(v + 1)
  loop(0)
}

// Because stream1 is a val, everything that the iterator produces is held
// by virtue of the fact that the head of the Stream is held in stream1
val it1 = stream1.iterator
loop("Iterator1: ", it1.next, it1)

// We can redefine this Stream such that all we have is the Iterator left
// and allow the Stream to be garbage collected as required.  Using a def
// to provide the Stream ensures that no val is holding onto the head as
// is the case with stream1
def stream2: Stream[Int] = {
  def loop(v: Int): Stream[Int] = v #:: loop(v + 1)
  loop(0)
}
val it2 = stream2.iterator
loop("Iterator2: ", it2.next, it2)

//OR Use Iterator 
val it3 = new Iterator[Int] {
  var i = -1
  def hasNext = true
  def next(): Int = { i += 1; i }
}
loop("Iterator3: ", it3.next, it3)

//Another example 
val sov: Stream[Vector[Int]] = Vector(0) #:: sov.zip(sov.tail).map { n => n._1 ++ n._2 }
//The definition of fibs above creates a larger number of objects than necessary 
//Solution is below 
lazy val fib: Stream[Int] = {
  def loop(h: Int, n: Int): Stream[Int] = h #:: loop(n, h + n)
  loop(1, 1)
}

//Note that mkString forces evaluation of a Stream, but addString does not.
// In both cases, a Stream that is or ends in a cycle 
//(e.g. lazy val s: Stream[Int] = 0 #:: s) will convert additional trips 
//through the cycle to .... 
//Additionally, addString will display an un-memoized tail as ?. 









 ///*** Recursion

//Working with a List - break list with head::tail

val x = List(1, 2, 3)
val y = 1 :: 2 :: 3 :: Nil

def listToString(list: List[String]): String = list match {
       case s :: rest => s + " " + listToString(rest)
       case Nil => ""
     }
	 
//Fails with large List - 
//Solution - use accumulator pattern , then TCO
@scala.annotation.tailrec
def listToString(list: List[String], str:String): String = list match {
       case s :: rest => listToString(rest, str + " " + s)
       case Nil => str
}
	 

//Summing - Fails with large List - 
//Solution - use accumulator pattern , then TCO
def sum(list: List[Int]): Int = list match {
       case Nil => 1
       case n :: rest => n + sum(rest)
     }

//with tail rec
import scala.annotation.tailrec

@tailrec
def sum(list: List[Int], acc:BigInt = 0 ): BigInt = list match {
       case Nil => acc
       case n :: rest => sum(rest, acc+n)
     }
sum(List.range(1,100))



//max
def max(ints: List[Int]): Int = { 
    @tailrec
    def maxAccum(ints: List[Int], theMax: Int): Int = {
      ints match {
        case Nil => theMax
        case x :: tail => maxAccum(tail, if (x > theMax) x else theMax)
      }
    }
    maxAccum(ints, ints.head)
  }
  
//size
import scala.annotation.tailrec
@scala.annotation.tailrec
def size(list: List[Int], acc:BigInt = 0): BigInt = list match {
       case Nil => acc
       case n :: rest => size(rest, acc+1)
     }
size(List.range(1,100))


//Various ways to implement factorials and it's operations
// TCO way
def factorial2(n: Long): Long = {
        @annotation.tailrec
        def factorialAccumulator(acc: Long, n: Long): Long = {
            if (n == 0) acc
            else factorialAccumulator(n*acc, n-1)
        }
        factorialAccumulator(1, n)
    }
	
//Using foldLeft
def factorial(n:Int) = (BigInt(1) /: (1 to n)) (_*_)   // /: foldLeft, :\ foldRight

def factorial(n:Int) =   ((1 to n) :\ BigInt(1)) (_*_)
//OR
def factorial(n:Int) = (1 to n).foldRight(BigInt(1))(_*_)
def factorial(n:Int) = (1 to n).foldLeft(BigInt(1))(_*_)

//OR for list of factorial
//iterate - the infinite sequence of values `start, f(start), f(f(start)), ...`
//iterate with state gives next state
lazy val factorialVal = Iterator.iterate( (1,BigInt(1)) ){case (i,f) => (i+1,f*(i+1))}  
factorialVal.map(_._2).take(100).toList


//To find the biggest value of n for which factorial(n) fits in a Long.

(1 to 100) takeWhile (factorial(_) <= Long.MaxValue) last
//OR 
val s = Stream.continually(1).zipWithIndex.map(p => p._1 + p._2)  //continually gives const 1 till infinite
																  //zipWithIndex gives tuple(ele,index)
s takeWhile (factorial(_) <= Long.MaxValue) last

//OR

Stream.from(1) takeWhile (factorial(_) <= Long.MaxValue) last  //from gives start, start+1, ..

//Note the stream keeps references of all computed values. so, if that is not required, use Iterator
Iterator.from(1).takeWhile (factorial(_) <= Long.MaxValue).toList.last
//OR
Iterator.from(1).dropWhile( factorial(_) <= Long.MaxValue).next - 1

//OR sliding - Groups elements in fixed size blocks by passing a "sliding window" over them 
//ie sliding creates a List of List
Iterator.from(1).sliding(2).dropWhile(_.tail.head < 10).take(2).toList  //res59: List[Seq[Int]] = List(List(9, 10), List(10, 11))

Iterator.from(1).sliding(2).dropWhile(x => factorial(x.tail.head) <= Long.MaxValue).next.head

//OR
//iterate - the infinite sequence of values `start, f(start), f(f(start)), ...`
//iterate with state gives next state
val it = Iterator.iterate( (1,BigInt(1)) ){case (i,f) => (i+1,f*(i+1))}  
it.find(_._2 >= Long.MaxValue).map(_._1).get - 1  //find returns Some, hence use get



	



///* Various ways to implement Fibbonici Number

val it = Iterator.iterate((1,1)){case (a,b) => (b,a+b)}.map(_._1)
//OR
val fibs: Stream[Int] = 0 #:: fibs.scanLeft(1)(_ + _)  //scanLeft is like foldLeft, but gives intermediate values
fibs take 10 toList


//Stream uses Memoization, when it is used as val .. Can cause OutOfMemory
//To avoid, use  def
val fibs:Stream[Int] = 0 #:: 1 #:: fibs.zip(fibs.tail).map{ case (a,b) => a + b }
val fibs: Stream[BigInt] =  BigInt(0) #::  BigInt(1) #:: fibs.zip(fibs.tail).map( zipTup =>  zipTup._1 + zipTup._2 )
//fibs: Stream[scala.math.BigInt] = <lazy>
def fibFrom(a: Int, b: Int): Stream[Int] = a #:: fibFrom(b,a + b)  //not tail rec
fibFrom(1,2).take(100).toList.length

//Or non TCO ways - very slow as func calls are 2**n
def fib(n:Int):BigInt = {
  if (n == 0 ) BigInt(0) else if (n == 1) BigInt(1) else  fib(n-1) + fib(n-2)
}

//Use  Memoization or TCO to make this fast
//must be val, such that initial code is executed
val fib:(Int =>BigInt) = {
  val m = scala.collection.mutable.Map[Int,BigInt]()
  //calculate Fib
  def fibInternal(n:Int):BigInt = {
      if (n == 0 ) BigInt(0) else if (n == 1) BigInt(1) else  fib(n-1) + fib(n-2)
  }
  //return a function
  ( (n:Int) => {
          val res = m.getOrElseUpdate(n, fibInternal(n))
          res
      }
    )
  }	 
  
//Simpler form
val m = new collection.mutable.HashMap[BigInt,BigInt]().withDefault { n => { m(n) = if (n<2) n else m(n-1) + m(n-2); m(n)} }
//OR
val m = new collection.mutable.HashMap[BigInt,BigInt]().withDefault { n => m.getOrElseUpdate(n, if (n<2) n else m(n-1) + m(n-2)) }
m(100)

//OR TCO way, 
@scala.annotation.tailrec
def fib(n:Int, a:BigInt=0, b:BigInt=1):BigInt = n match {
   case 0 => a
   case 1 => b
   case _ => fib(n-1, b, a+b)
}
 
 
//with memoization and TCO - not possible as it's challenging to handle two args method

	
//to get List of fibs 
@scala.annotation.tailrec
def fib(n: Int, s: List[BigInt] = List(1, 0)): List[BigInt] = 
  if (n <= 2) s.reverse else fib(n - 1, s(0) + s(1) :: s)

//OR
@scala.annotation.tailrec
def fib(n:Int, s:List[BigInt]=List(0,1) ):List[BigInt] =
 if (n<2) s else fib(n-1, s :+ (s.last + s.init.last) )   // s.last = s(s.size-1) .. s(s.size-2)

//Or infinte one, works lazily
class FibI extends Iterator[BigInt]{
    private var (a:BigInt, b:BigInt) = (0 :BigInt, 1 :BigInt)  
    def hasNext  = true 
    def next = {  
                val tmp = a; a = b; b = tmp + b;   //no Pattern matching on assignments
                a
            }
    }
    
val a = new FibI()
a.take(10).toList  


	
///** trampolining – Converting TC recursion into tail recursion
//1. to convert a call to TR, wrap tailcall around your function
//2. to stop, recursion, call done with result
//3. result type should be  TailRec[U] and result is seen from 'result' property


//overflow

def even [A]( ns: List [A]): Boolean =
	ns match {
		case Nil => true
		case x :: xs => odd (xs)
	}
def odd [A]( ns: List [A ]): Boolean =
	ns match {
		case Nil => false
		case x :: xs => even (xs)
	}

//TC
import scala.util.control.TailCalls._

def isEven(xs: List[Int]): TailRec[Boolean] =
  if (xs.isEmpty) done(true) else tailcall(isOdd(xs.tail))

def isOdd(xs: List[Int]): TailRec[Boolean] =
 if (xs.isEmpty) done(false) else tailcall(isEven(xs.tail))

isEven((1 to 100000).toList).result

 



///*** Application of Recursion - Directory listing 
import java.io._ 

def getListOfFiles(dir: String):List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
        d.listFiles.filter(_.isFile).toList
    } else {
        List[File]()
    }
}

//With subdirectory 
def getListOfFilesRecur(dir: File):Array[File] = {
    if (dir.exists && dir.isDirectory) {
        //println(s"At $dir files $files")
        val  files = dir.listFiles
        val subs = files.filter(_.isDirectory).flatMap(getListOfFilesRecur(_))
        files.filter(_.isFile) ++ subs
    } else {
        Array.empty[File]
    }
}

//With TCO subdirectory 
def getListOfFilesRecur(dirs: Array[File], o:Array[File]=Array.empty[File]):Array[File] = {
    val  files = dirs.flatMap{dir => dir.listFiles.filter(_.isFile)}
    val subdirs = dirs.flatMap{dir => dir.listFiles.filter(_.isDirectory)}
    if (subdirs.isEmpty) return o++files else getListOfFilesRecur(subdirs, o++files)
    
}





    
///***Traits, Mixin class Composition

//Trait and Class
//Class or Trait can extend only one Base/Abstract class, but can extend multiple Traits
//First base class/trait/abstract class = use extends
//then use 'with' keywords for multiple traits

//No need to mention abstract, simply leave out the defination
//can have concrete methods as well 

//Use abstract class if this is to be used from Java and/or takes ctor args 

trait A { def foo = "from A" }    //can have concrete implementation

class B extends A { override def foo = "from B" }   //hence use override

class C extends B with A {
  val b = super.foo          // "from B"
  val a = super[A].foo       // "from A"
}
// Class C A B A     - Class C + then start from Right, put obj hierarchy, 
//then start from right, remove duplicates after first
// C B A Object Any

//Note MRO checks all these classes to find all applicable methods at first
//it does not call the first method found, but collates all applicable methods( for overloading resolution purpose)
//note when methods are overridden, overidden methods are taken once

scala.reflect.runtime.universe.typeOf[C].baseClasses  //List(class C, class B, trait A, class Object, class Any)

//Conflicting methods
//when applicable methods contain two same signature methods(non overridden)
 
trait A1 { def foo= "form A1" }   

class C extends B with A with A1 
//NOK - conflicting methods, foo  from  A1 and B(overridden) -- Which foo when user asks for foo ??
// C A1 A B A   =>  C A1  B A Object Any

//To fix , use override foo in C which 
class C extends B with A with A1 {  override def foo = super.foo  }  //OK now as foo means A1's foo 


scala.reflect.runtime.universe.typeOf[C].baseClasses   // List(class C, trait A1, class B, trait A, class Object, class Any)

(new C).foo  //= form A1 as A1 is the first in MRO



//Note Overload across  Traits, class possible 
//when applicable methods differ in signature

trait A2 { def foo(x:Int) = 0 }


class C extends B with A with A2 {   val b = super.foo ;   val a = super[A].foo  } //Now OK as  A2's foo takes Int
(new C).b  //res0: String = from B




///*** Preinitialised  fields - Anon Class
// only one Preinitialised fields after new for anon or after extends in class signature

trait ATrait {
   val n: Int
   val d: Int
}

//Option-1 , no expression allowed in assignment

val x = new ATrait {          //Anon class
   val n = 1
   val d = 2
}

//Option-2, expression allowed
val x = 2
val y = new {
   val n = x * 2
   val d = 1
} with ATrait   // must be 'with' as On fly trait initialization has always 'with'

// Or default option
class A extends ATrait { val n = 1; val d = 2 }

//Or use it in Class definition itself

class A(nu: Int, de: Int) extends {
  val n = nu
  val d = de
} with ATrait {
  def + (o: A) = new A( n + o.n , d + o.d  )
}


///*** On The fly Trait initialization


trait T { def m}
trait T1 { def m1 }
trait T2 { def m2 }
class A {}

val a = new A with  T with T1 with T2 { def m= {}; def m1={}; def m2={} }

import scala.reflect.runtime.universe._
def getType[T:TypeTag](obj: T) = typeTag[T].tpe

getType(a)   // A with T with T1 with T2   // new type







////*** Trait- Restricting trait mixing 
// either self type or trait extending from a class


abstract class A {}
trait TA extends A {}   // TA can be used only where class 'extends' from A or TA
                        //hence can call all methods of A

class B extends TA      //OK

class B 
class C extends B 
class D extends C with TA {}   //Not OK as D extends C not A or TA
class D extends A with TA {}  //OK as D extends from A

//note here , use self.ATTRIBUTE inside trait to access A attributes 
trait TB { self:A => }    //TB can be only used when class extends  from A only (not even from TB)
                          //hence can call all methods of A

class B extends A with TB {}  //OK
class C extends TB {}         //NOK



                       ^
///*** Trait - trait 'this' is actually from class


trait TC {  def m = this }  // note 'this' can be used to return, but type is this.type

val a = new TC {}
a.m   //res28: TC = $anon$1@2fc1f8de


//Type - this.type  - returns concrete class type polymorphic
trait TA { def f:this } // NOK               

trait TA { def f:this.type  }  //OK

class A extends TA { def f = this}

class B extends TA { def f = this}

(new A()).f   // Return A object
(new B()).f    // returns B object



// Method Chaining by using this.type

class A {def method1: A = this }
class B extends A {def method2: B = this }

val b = new B()

b.method2.method1

b.method1.method2   //NOK as method2 belongs to B

//Use with this.type
class A {def method1: this.type = this }
class B extends A {def method2: this.type = this }

val b = new B()

b.method2.method1   //b.type = B@4a3a0004

b.method1.method2  //res45: b.type = B@4a3a0004



///*** Trait - structural subtyping

trait A { def m = println(0)}

class B[T <: {def ok } ](x:T ){   
  self:A =>   //Extending class must derive from A    
    self.m    // call any A functions 
    x.ok      // can call ok as T has method OK
}

class CO { def ok = println(1) }

class C extends B(new CO) with A 

val c = new C()


//Duck typying can be inside 
//The general form is: A with B with C ... { refinement }
//eg T1 with T2 {def ok:Unit }
trait T1 { self : { def ok:Unit } =>  }

abstract class A {}
trait T2 {}
trait T3 { self : A with T2 => }    //with Multiple, hence can call any A and T2 methods via self.a etc

//Type - Compound Type , 
//note 'A with B ..' can be used anywhere where type is required

trait Copyable {
  def copy:Unit
}

trait Resetable {
  def reset: Unit
}

//The general form is: A with B with C ... { refinement }

def cloneAndReset(obj: Copyable with Resetable) = {    
   obj.copy
   obj.reset
}

cloneAndReset( new Copyable with Resetable { def reset = println("Reset") ; def copy = {println("copy")} } )







///*** Stackable Trait - super binding, based om MRO ie from Right

abstract class A { def m(x:Int)  }
class B extends A { def m(x:Int) = println(x)}


val b = new B
b.m(2)    //2

trait TS1 extends A { abstract override def m(x:Int) = super.m(x*x) } //calls next one in chain
val b = new B with TS1
b.m(2) //4 , in MRO, TS1 comes first, hence TS1's is used, and then Class's B




///*** Option 
class Request {
    import scala.util.Random
    private val rand = new Random 
    def getParameter(str:String) = Option{this.output}
    def output = if (rand.nextInt(10) < 5) " Hello " else null
}

val request = new Request 

val name: Option[String] = request getParameter "name"  //request.getParameter("name") returns Option
//all get executed only if name= Some("somestring")
val upper = name map { _.trim } filter { _.length != 0 } map { _.toUpperCase }
println(upper getOrElse "")

//OR 
val upper = for {
  name <- request getParameter "name"  //<- unwraps Option , hence use with Some,None 
  trimmed <- Some(name.trim)
  upper <- Some(trimmed.toUpperCase) if trimmed.length != 0
} yield upper  //Option[String]
println(upper getOrElse "")

//OR 
val nameMaybe = request getParameter "name"
nameMaybe match {
  case Some(name) =>
    println(name.trim.toUppercase)
  case None =>
    println("No name value")
}
 


//Option is used to handle null.
//Wrap a execution as 
val o = Option { ... }
//if execution creates null, it would be None
//if execution creates Something, it would be Some 


//Option is Monad and implicitly convertable to Iterator 
// hence flatMap, map, filter, 'for'  etc can be used

//java
Integer i = toInt(someString);
if (i == null) {
    System.out.println("That didn't work.");
} else {
    System.out.println(i);
}

//in scala
//no import
def toInt(in: String): Option[Int] = {
    try {
        Some(Integer.parseInt(in.trim))
    } catch {
        case e: NumberFormatException => None
    }
}

toInt("1") match {
    case Some(i) => println(i)
    case None => println("That didn't work.")
}

toInt("1") getOrElse ""


//using flatmap, None is removed 
val bag = List("1", "2", "foo", "3", "bar")
bag.flatMap(toInt) //res0: List[Int] = List(1, 2, 3)
bag.map(toInt)     //res1: List[Option[Int]] = List(Some(1), Some(2), None, Some(3), None)

val sum = bag.flatMap(toInt).sum   //flatMap ignore None and flattens rest

//OR with Partial Function
bag map(toInt) collect { case Some(x) => x } sum

//Note List's map, filter etc does not filter None, 
//but Option's map, filter etc ignore none

val name: Option[String] = Some(" ok ");
val upper = name map { _.trim } filter { _.length != 0 } map { _.toUpperCase }
println(upper getOrElse "")

//yield always returns container class of first <- inside 'for'
//Note that this is equivalent to 
val upper = for {
  name <- Some(" ok ")         //unwraps container class
  trimmed <- Some(name.trim)
  upper <- Some(trimmed.toUpperCase) if trimmed.length != 0
} yield upper
println(upper getOrElse "")

//Convertig to Option by Option
def f(x:Int) = if(x==1) null:String else "OK"
Option(f(1))   //res6: Option[String] = None
Option(f(2))  //res7: Option[String] = Some(OK)
Option(f(2)) == None //res8: Boolean = false
Option(f(2)) map { _ + "OK" }  //res9: Option[String] = Some(OKOK)
Option(f(1)) map { _ + "OK" }  //res10: Option[String] = None

//Option has following imp methods
final  def  getOrElse[B >: A](default: => B): B 
    Returns the option value if the option is nonempty, otherwise return the result of evaluating default.
final  def  nonEmpty: Boolean 
    Returns false if the option is None, true otherwise.
final  def orElse[B >: A](alternative: => Option[B]): Option[B] 
    Returns this scala.Option if it is nonempty, otherwise return the result of evaluating alternative.
final  def orNull[A1 >: A](implicit ev: <:<[Null, A1]): A1 
    Returns the option value if it is nonempty, or null if it is empty.

//companion class 
def  apply[A](x: A): Option[A] 
    An Option factory which creates Some(x) if the argument is not null, and None if it is null.
def  empty[A]: Option[A] 
    An Option factory which returns None in a manner consistent with the collections hierarchy.
implicit  def  option2Iterable[A](xo: Option[A]): Iterable[A] 
    An implicit conversion that converts an option to an iterable value 



///*** Either 
import scala.util.{Either, Right, Left}

val in = Console.readLine("Type Either a string or an Int: ")
val result: Either[String,Int] = try {
    Right(in.toInt)
  } catch {
    case e: Exception =>  Left(in)
}

println( result match {
  case Right(x) => "You passed me the Int: " + x + ", which I will increment. " + x + " + 1 = " + (x+1)
  case Left(x) => "You passed me the String: " + x
})

    
///Either - two type, Right is like Some(ie some value), Left is like None(ie error)
//But It contains one type at a time (like union)

def divideXByY(x: Int, y: Int): Either[String, Int] = {
    if (y == 0) Left("no divide by 0")
    else Right(x / y)
  }
   
// a few different ways to use Either, Left, and Right
println(divideXByY(1, 0))
println(divideXByY(1, 1))
divideXByY(1, 0) match {
    case Left(s) => println("Answer: " + s)
    case Right(i) => println("Answer: " + i)
}

//idiomatic way. Note Eirther is not monad, but 
//'left' and 'right' projections are Monad, hence use map etc 
val l: Either[String, Int] = Left("flower") // only Left, right projection would not give anything
val r: Either[String, Int] = Right(12)      //only right, left projection would not give any
l.left.map(_.size).asInstanceOf[Either[Int,Int]] // Left(6)
r.left.map(_.size): Either[Int, Int] // Right(12)  //no transformation on left as only right defined
l.right.map(_.toDouble): Either[String, Double] // Left("flower") //no transformation on right as only left defined
r.right.map(_.toDouble): Either[String, Double] // Right(12.0)

for (s <- l.left) yield s.size // Left(6)

//Using cond to store either Left or Right
Either.cond(true, "OK", 1) //res12: scala.util.Either[Int,String] = Right(OK)

Either.cond(false, "OK", 1)  //res13: scala.util.Either[Int,String] = Left(1)

//Imp methods
def  isLeft: Boolean 
    Returns true if this is a Left, false otherwise.
def  isRight: Boolean 
    Returns true if this is a Right, false otherwise.
def  fold[X](fa: (A) => X, fb: (B) => X): X 
    Applies fa if this is a Left or fb if this is a Right. 
    //example 
    val result: Either[Exception, Int] = possiblyFailingOperation()
    log(result.fold(
      ex => "Operation failed with " + ex,
      v => "Operation produced value: " + v
    ))
def joinLeft[A1 >: A, B1 >: B, C](implicit ev: <:<[A1, Either[C, B1]]): Either[C, B1] 
def joinRight[A1 >: A, B1 >: B, C](implicit ev: <:<[B1, Either[A1, C]]): Either[A1, C] 
    are analogous to Option#flatten 
    Joins an Either through Left/Right
    This method requires that the left/right side of this Either is itself an Either type.
    Either[Either[C, B], B] or Either[B, Either[C, B]]
    If this instance is a Left[Either[C, B]] then the contained Either[C, B] will be returned, otherwise this value will be returned unmodified.
    Left[Either[Int, String], String](Right("flower")).joinLeft // Result: Right("flower")
    Left[Either[Int, String], String](Left(12)).joinLeft // Result: Left(12)
    Right[Either[Int, String], String]("daisy").joinLeft // Result: Right("daisy")
def  swap: Product with Serializable with Either[B, A] 
    If this is a Left, then return the left value in Right or vice versa. 
    Example: 
    val l: Either[String, Int] = Left("left")
    val r: Either[Int, String] = l.swap // Result: Right("left")

//companion object 
def  cond[A, B](test: Boolean, right: => B, left: => A): Either[A, B] 
    If the condition is satisfied, return the given B in Right, 
    otherwise, return the given A in Left.



  
///*** scala.util.Try[T] 
//Try is used to handle execution that results into exception (like try/catch }
//Wrap a execution as 
val t = Try { ... }
//if execution creates Exception, it would be Failure(exception)
//if execution creates Something, it would be Success(value)

class Request {
    import scala.util.Random
    private val rand = new Random 
    def getParameter(str:String) = Option{this.output}
    def output = if (rand.nextInt(10) < 5) " Hello " else null
}

val request = new Request 
//Try is monad, hence flatMap, map, 'for' etc can be used
def name = Try{ request.output.trim + " World   " }
def upper(name:Try[String]) = name map { _.trim } filter { _.length != 0 } map { _.toUpperCase }
val upperOpt = upper(name).toOption 
//Use flatMap if nested Container result
def upperO(name:Option[String]) = name map { _.trim } filter { _.length != 0 } map { _.toUpperCase }
//Flattened , List of result as Option is implicitely converted to Iterable 
val uppers = (1 to 10).toList.map { _ => name.toOption }.flatMap{ x=> upperO(x)}
//Not in case of Try,
val uppers = (1 to 10).toList map { _ => name } flatMap{x=>upper(x)} //ERROR 


//Another exaple 
import scala.io.Source
import scala.util.{Try,Success,Failure}
 
 def readTextFile(filename: String): Try[List[String]] = {
        Try(Source.fromFile(filename).getLines.toList)
    }
 
val filename = "count.pl"
readTextFile(filename) match {
    case Success(lines) => lines.foreach(println)
    case Failure(f) => println(f)
}
 
//Using Try[T].flatmap
val dividend = Try(readLine("Enter an Int that you'd like to divide:\n").toInt)
val divisor = Try(readLine("Enter an Int that you'd like to divide by:\n").toInt)
val problem = dividend.flatMap(x => divisor.map(y => x/y))  // result is in Try
problem match {
    case Success(v) =>   //...
      
    case Failure(e) =>
      
  }

//Important Methods
class Try[+T] extends AnyRef 
    def failed: Try[Throwable]
        Inverts this Try.
    def filter(p: (T) => Boolean): Try[T]
        Converts this to a Failure if the predicate is not satisfied.
    def flatMap[U](f: (T) => Try[U]): Try[U]
        Returns the given function applied to the value from this Success or returns this if this is a Failure.
    def flatten[U](implicit ev: <:<[T, Try[U]]): Try[U]
        Transforms a nested Try, ie, a Try of type Try[Try[T]], into an un-nested Try, ie, a Try of type Try[T].
    def foreach[U](f: (T) => U): Unit
        Applies the given function f if this is a Success, otherwise returns Unit if this is a Failure.
    def get: T
        Returns the value from this Success or throws the exception if this is a Failure.
    def isFailure: Boolean
        Returns true if the Try is a Failure, false otherwise.
    def isSuccess: Boolean
        Returns true if the Try is a Success, false otherwise.
    def map[U](f: (T) => U): Try[U]
        Maps the given function to the value from this Success or returns this if this is a Failure.
    def recover[U >: T](f: PartialFunction[Throwable, U]): Try[U]
        Applies the given function f if this is a Failure, otherwise returns this if this is a Success.
    def recoverWith[U >: T](f: PartialFunction[Throwable, Try[U]]): Try[U]
        Applies the given function f if this is a Failure, otherwise returns this if this is a Success.
        
    def  getOrElse[U >: T](default: => U): U 
        Returns the value from this Success or the given default argument if this is a Failure.
    def  orElse[U >: T](default: => Try[U]): Try[U] 
        Returns this Try if it is a Success or the given default argument if this is a Failure.
    def toOption: Option[T] 
        Returns None if this is a Failure or a Some containing the value if this is a Success.
    def  transform[U](s: (T) => Try[U], f: (Throwable) => Try[U]): Try[U] 
        Completes this Try by applying the function f to this if this is of type Failure, or conversely, by applying s if this is a Success.

//companion objects 
def  apply[T](r: => T): Try[T] 
    Constructs a Try using the by-name parameter.

    
    


   
   

