Day-2 
    Spark basic building block-RDD 
        � RDD transformation and actions 
        � RDD performance improvement - Caching and shared variables 
        � Complex operations and pipelines 
    Spark DataFrame 
        � DF Operations       
        � Joins 
        � UDF 
    SQL to Spark - Spark-SQL 
        Quick Syntax reference 
        Important sql configurations 
        Critical sql operations 
    Spark DataSource 
        � HDFS, csv, json 
        � Hive, Parquet, Avro 
-----------------------------------------
###*** Quick HDFS commands
 
#all are in admin console 
#1.Format the filesystem:
  $ hdfs namenode -format

#2.Start NameNode daemon and DataNode daemon:
  $ start-dfs & start-yarn
  #start history server if required to check logs 
  $ mapred --config c:/hadoop/etc/hadoop historyserver
  #linux
  $ sbin/mr-jobhistory-daemon.sh --config $HADOOP_CONFIG_DIR start historyserver

#check all process started 
  $ jps 
  
#The hadoop daemon log output is written to the $HADOOP_LOG_DIR directory 
#(defaults to $HADOOP_HOME/logs).


#3.Browse the web interface for the NameNode; by default it is available at:
#?NameNode - http://localhost:50070/

##Example of running mapReduce Job 
#4.Make the HDFS directories required to execute MapReduce jobs:
  $ hdfs dfs -mkdir /user
  $ hdfs dfs -mkdir /user/<username>

#5.Copy the input files into the distributed filesystem:
  $ cd  c:\hadoop
  $ hdfs dfs -put etc/hadoop input   #input means /user/das/input 
  $ hdfs dfs -ls input 
  $ hdfs dfs -ls hdfs://localhost:19000/user/das/input  #as per core-site.xml


#7.Examine the output files: Copy the output files from the distributed filesystem to the local filesystem and examine them:
  $ hdfs dfs -get output output
  $ cat output/*
#or   
  $ hdfs dfs -cat output/*

#8.When you're done, stop the daemons with: 
  $ sop-yarn & stop-dfs
  
##For Error 
IOException: Incompatible clusterIDs in C:\tmp\hadoop-das\dfs\data: 
namenode clusterID = CID-3f4c81-1e4f-4a7a-b0d8-4b9faeaaba48; datanode clusterID = CID-fa647c5c-d7d6-4e38-bc18-d4799b0a72e9

$ hdfs namenode -format
$ hdfs namenode -format -clusterId CID-fa647c5c-d7d6-4e38-bc18-d4799b0a72e9
 
#Run an example YARN job 
cd  c:\hadoop
hadoop fs -mkdir  example
hadoop fs -put license.txt  example/
hadoop fs -ls example/
 
#Run an example YARN job 
yarn jar share\hadoop\mapreduce\hadoop-mapreduce-examples-*.jar wordcount example/license.txt out
 
#9. Check delete 
hadoop fs -ls out
hadoop fs -rm -r -f  out


###*Checking: Check the following pages in your browser: 
Resource Manager:  http://localhost:8088
Web UI of the NameNode daemon:  http://localhost:50070
HDFS NameNode web interface:  http://localhost:8042

###* Debugging
#To review per-container launch environment, 
#increase yarn.nodemanager.delete.debug-delay-sec to a large value (e.g. 36000), 
#yarn-site.xml
<property> 
      <name>yarn.nodemanager.delete.debug-delay-sec</name> 
      <value>3600</value> 
</property>
#then access the application cache through 
#yarn.nodemanager.local-dirs on the nodes on which containers are launched

#By default - yarn.nodemanager.local-dirs is ${hadoop.tmp.dir}/nm-local-dir ie c:/tmp/nm-local-dir

#An applications localized file directory will be found in: 
#${yarn.nodemanager.local-dirs}/usercache/${user}/appcache/application_${appid}. 
#Individual containers work directories, called container_${contid}, will be subdirectories of this. 

###* To leave safe mode (maintenance mode)
hdfs dfsadmin -safemode get
hdfs dfsadmin -safemode leave

###* check yarn logs 
#find application id from yarn-resourcemanager cmd shell windows 
$ yarn logs -applicationId application_1487592307594_0001 > log.txt

#check logs from yarn.nodemanager.log-dirs of yarn-site.xml
#as per above it is c:/deps/logs/userlogs/...






###*** Spark Setup 
from __future__ import print_function, division

from pyspark import *                   #SparkContext,RDD,Broadcast,Accumulator,SparkConf,SparkFiles,StorageLevel,TaskContext

from pyspark.sql import *               #SparkSession, DataFrame, Column, Row, GroupedData, DataFrameNaFunctions, DataFrameStatFunctions, Window
import pyspark.sql.functions as F
from pyspark.sql.types import * 

from pyspark.streaming  import *        #StreamingContext, DStream
from pyspark.streaming.kafka import * 
from pyspark.streaming.kinesis import * 
from pyspark.streaming.flume import * 

from pyspark.ml  import *               #Transformer, UnaryTransformer,Estimator,Model,Pipeline,PipelineModel
from pyspark.ml.feature import *        #Binarizer, BucketedRandomProjectionLSHE, BucketedRandomProjectionLSHModelE, Bucketizer, ChiSqSelectorE, ChiSqSelectorModelE, CountVectorizer, CountVectorizerModel, DCT, ElementwiseProduct, FeatureHasherE, HashingTF, IDF, IDFModel, ImputerE, ImputerModelE, IndexToString, MaxAbsScaler, MaxAbsScalerModel, MinHashLSHE, MinHashLSHModelE, MinMaxScaler, MinMaxScalerModel, NGram, Normalizer, OneHotEncoderD, OneHotEncoderEstimator, OneHotEncoderModel, PCA, PCAModel, PolynomialExpansion, QuantileDiscretizerE, RegexTokenizer, RFormulaE, RFormulaModelE, SQLTransformer, StandardScaler, StandardScalerModel, StopWordsRemover, StringIndexer, StringIndexerModel, Tokenizer, VectorAssembler, VectorIndexer, VectorIndexerModel, VectorSizeHintE, VectorSlicer, Word2Vec, Word2VecModel, , 
from pyspark.ml.classification import * #LinearSVCE, LinearSVCModelE, LogisticRegression, LogisticRegressionModel, LogisticRegressionSummaryE, LogisticRegressionTrainingSummaryE, BinaryLogisticRegressionSummaryE, BinaryLogisticRegressionTrainingSummaryE, DecisionTreeClassifier, DecisionTreeClassificationModel, GBTClassifier, GBTClassificationModel, RandomForestClassifier, RandomForestClassificationModel, NaiveBayes, NaiveBayesModel, MultilayerPerceptronClassifier, MultilayerPerceptronClassificationModel, OneVsRestE, OneVsRestModelE, , 
from pyspark.ml.clustering import *     #BisectingKMeans, BisectingKMeansModel, BisectingKMeansSummaryE, KMeans, KMeansModel, GaussianMixture, GaussianMixtureModel, GaussianMixtureSummaryE, LDA, LDAModel, LocalLDAModel, DistributedLDAModel, , 
import pyspark.ml.linalg as ml        #Vector, DenseVector, SparseVector, Vectors, Matrix, DenseMatrix, SparseMatrix, Matrices, , 
from pyspark.ml.recommendation import * #ALS, ALSModel, , 
from pyspark.ml.regression import *     #AFTSurvivalRegressionE, AFTSurvivalRegressionModelE, DecisionTreeRegressor, DecisionTreeRegressionModel, GBTRegressor, GBTRegressionModel, GeneralizedLinearRegressionE, GeneralizedLinearRegressionModelE, GeneralizedLinearRegressionSummaryE, GeneralizedLinearRegressionTrainingSummaryE, IsotonicRegression, IsotonicRegressionModel, LinearRegression, LinearRegressionModel, LinearRegressionSummaryE, LinearRegressionTrainingSummaryE, RandomForestRegressor, RandomForestRegressionModel, , 
from pyspark.ml.stat import *           #moduleChiSquareTestE, CorrelationE, , 
from pyspark.ml.tuning import *         #ParamGridBuilder, CrossValidator, CrossValidatorModel, TrainValidationSplitE, TrainValidationSplitModelE, , 
from pyspark.ml.evaluation import *     #Evaluator, BinaryClassificationEvaluatorE, RegressionEvaluatorE, MulticlassClassificationEvaluatorE, ClusteringEvaluatorE, , 
from pyspark.ml.fpm import *            #FPGrowthE, FPGrowthModelE, , 
from pyspark.ml.util import *           #BaseReadWrite, DefaultParamsReadable, DefaultParamsReader, DefaultParamsWritable, DefaultParamsWriter, Identifiable, JavaMLReadable, JavaMLReader, JavaMLWritable, JavaMLWriter, JavaPredictionModel, MLReadable, MLReader, MLWritable, MLWriter, , , 

#MLIB parts 
from  pyspark.mllib.classification  import *      # LogisticRegressionModel, LogisticRegressionWithSGDD, LogisticRegressionWithLBFGS, SVMModel, SVMWithSGD, NaiveBayesModel, NaiveBayes, StreamingLogisticRegressionWithSGD, , 
from  pyspark.mllib.clustering  import *          # BisectingKMeansModel, BisectingKMeans, KMeansModel, KMeans, GaussianMixtureModel, GaussianMixture, PowerIterationClusteringModel, PowerIterationClustering, StreamingKMeans, StreamingKMeansModel, LDA, LDAModel, , 
from  pyspark.mllib.evaluation  import *          # BinaryClassificationMetrics, RegressionMetrics, MulticlassMetrics, RankingMetrics, , 
from  pyspark.mllib.feature  import *             # Normalizer, StandardScalerModel, StandardScaler, HashingTF, IDFModel, IDF, Word2Vec, Word2VecModel, ChiSqSelector, ChiSqSelectorModel, ElementwiseProduct, , 
from  pyspark.mllib.fpm  import *                 # FPGrowth, FPGrowthModel, PrefixSpan, PrefixSpanModel, , 
import pyspark.mllib.linalg as mlib               # Vector, DenseVector, SparseVector, Vectors, Matrix, DenseMatrix, SparseMatrix, Matrices, QRDecomposition, , 
from  pyspark.mllib.linalg.distributed  import *  # BlockMatrix, CoordinateMatrix, DistributedMatrix, IndexedRow, IndexedRowMatrix, MatrixEntry, RowMatrix, SingularValueDecomposition, , 
from  pyspark.mllib.random  import *              # RandomRDDs, , 
from  pyspark.mllib.recommendation  import *      # MatrixFactorizationModel, ALS, Rating, , 
from  pyspark.mllib.regression  import *          # LabeledPoint, LinearModel, LinearRegressionModel, LinearRegressionWithSGDD, RidgeRegressionModel, RidgeRegressionWithSGDD, LassoModel, LassoWithSGDD, IsotonicRegressionModel, IsotonicRegression, StreamingLinearAlgorithm, StreamingLinearRegressionWithSGD, , 
from  pyspark.mllib.stat  import *                # Statistics, MultivariateStatisticalSummary, ChiSqTestResult, MultivariateGaussian, KernelDensity, , 
from  pyspark.mllib.tree  import *                # DecisionTreeModel, DecisionTree, RandomForestModel, RandomForest, GradientBoostedTreesModel, GradientBoostedTrees, , 
from  pyspark.mllib.util  import *                # JavaLoader, JavaSaveable, LinearDataGenerator, Loader, MLUtils, Saveable, , 

#Other imports 
from __future__ import print_function, division
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt 

#Example 
$ pyspark --master local[4] --driver-memory 2G
#sc(spark context) and spark(spark session) are autocreated 

#or submit 
$ spark-submit --master local[4] --driver-memory 2G --py-files lib.zip script.py args 
#script.py 
#Create SparkConf and from SparkContext to SparkSession
conf = SparkConf().setAppName("wordCount").setMaster("local[*]") 
sc = SparkContext(conf=conf)
spark= SparkSession(sc)

#OR from SparkSession  to SparkContext
warehouse_location = 'spark-warehouse'  
#for embedded hive, uses currentDirectory, if core_site.xml in path, uses fs.default.name eg hdfs://localhost:19000/
#if hive_site.xml is in PATH, then uses metastore RDBMS connection, 
#note existing hive warehouse if to be used, do  spark.sql.warehouse.dir == hive.metastore.warehouse.dir in core_site.xml of external Hive conf 

spark = SparkSession \
    .builder \
    .appName("Example") \
    .master("local[*]") \
    .config("spark.sql.warehouse.dir", warehouse_location) \
    .enableHiveSupport() \
    .getOrCreate()
    
sc = spark.sparkContext

#Check application web UI at http://192.168.1.4:4040(http://<driver>:4040 )
#check Spark properties in the 'Environment' tab
#spark properties are at conf/spark-defaults.conf, SparkConf(), or the command line will appear.



##Configuration 
There are the following places where a Spark application looks for Spark properties (in the order of importance from the least important to the most important):
    conf/spark-defaults.conf - the configuration file with the default Spark properties. Read spark-defaults.conf.
    --conf or -c - the command-line option used by spark-submit (and other shell scripts that use spark-submit or spark-class under the covers, e.g. spark-shell)
    SparkConf where user programatically set options 
RuntimeConfig
    Runtime configuration interface for Spark. To access this, use SparkSession.conf.
    Options set here are automatically propagated to the Hadoop configuration during I/O. 
SparkConf
    Configuration for a Spark application. Used to set various Spark parameters as key-value pairs. 
HadoopConfiguration 
    get as below 
    hadoopConf = sc._jsc.hadoopConfiguration() 
    And then 
    hadoopConf.set(string, value) or hadoopConf.get(string)
    Note for using hadoopFile/newHadoopFile, file opening conf is set via 'conf' arg of those methods 
    
    

$ pyspark --master local[4] --driver-memory 2G
#sc(spark context) and spark(spark session) are autocreated 

>>> dir(sc)

>>> spark.conf.get("spark.app.name")
'PySparkShell'
>>> sc._conf.get("spark.app.name")
'PySparkShell'
>>> sc._conf.getAll() #spark.sparkContext.getConf()/_conf.getAll()
[('spark.app.id', 'local-1532678326302'), ('spark.sql.catalogImplementation', 'hive'), 
('spark.driver.host', '192.168.1.2'), ('spark.rdd.compress', 'True'), 
('spark.serializer.objectStreamReset', '100'), ('spark.master', 'local[*]'), 
('spark.executor.id', 'driver'), ('spark.submit.deployMode', 'client'), 
('spark.driver.port', '60209'), ('spark.app.name', 'PySparkShell'), 
('spark.ui.showConsoleProgress', 'true')]
>>> type(sc._conf)
<class 'pyspark.conf.SparkConf'>
>>> type(spark.conf)
<class 'pyspark.sql.conf.RuntimeConfig'>


##Properties that specify some time duration should be configured with a unit of time. 
#The following format is accepted:
    25ms (milliseconds)
    5s (seconds)
    10m or 10min (minutes)
    3h (hours)
    5d (days)
    1y (years)


##Properties that specify a byte size should be configured with a unit of size. 
#The following format is accepted:
    1b (bytes)
    1k or 1kb (kibibytes = 1024 bytes)
    1m or 1mb (mebibytes = 1024 kibibytes)
    1g or 1gb (gibibytes = 1024 mebibytes)
    1t or 1tb (tebibytes = 1024 gibibytes)
    1p or 1pb (pebibytes = 1024 tebibytes)
    
#The application web UI at http://<driver>:4040 lists Spark properties in the �Environment� tab.
#OR By command line 
#spark-submit will also read configuration options from conf/spark-defaults.conf
$ spark-submit --name "My app" --master local[4] --conf spark.eventLog.enabled=false
  --conf "spark.executor.extraJavaOptions=-verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps" myscript.py 
        
#Few important command line options  
  --master MASTER_URL         spark://host:port, mesos://host:port, yarn,
                              k8s://https://host:port, or local (Default: local[*]).
  --deploy-mode DEPLOY_MODE   Whether to launch the driver program locally ("client") or
                              on one of the worker machines inside the cluster ("cluster")
                              (Default: client).
  --class CLASS_NAME          Your application's main class (for Java / Scala apps).
  --name NAME                 A name of your application.
  
  --jars JARS                 Comma-separated list of jars to include on the driver
                              and executor classpaths.
                              spark doesn't hit maven but it will search specified jar 
                              in the local file system 
                              it also supports following URL scheme hdfs/http/https/ftp.
  
  
  --packages                  Comma-separated list of maven coordinates of jars to include
                              on the driver and executor classpaths. Will search the local
                              maven repo, then maven central and any additional remote
                              repositories given by --repositories. The format for the
                              coordinates should be groupId:artifactId:version.
                              spark will search specific package in local maven repo 
                              then central maven repo or any repo provided by --repositories 
                              and then download it.
  
  --exclude-packages          Comma-separated list of groupId:artifactId, to exclude while
                              resolving the dependencies provided in --packages to avoid
                              dependency conflicts.
  --repositories              Comma-separated list of additional remote repositories to
                              search for the maven coordinates given with --packages.
  --py-files PY_FILES         Comma-separated list of .zip, .egg, or .py files to place
                              on the PYTHONPATH for Python apps.
  --files FILES               Comma-separated list of files to be placed in the working
                              directory of each executor. File paths of these files
                              in executors can be accessed via SparkFiles.get(fileName).

  --conf PROP=VALUE           Arbitrary Spark configuration property.
  --properties-file FILE      Path to a file from which to load extra properties. If not
                              specified, this will look for conf/spark-defaults.conf.

  --driver-memory MEM         Memory for driver (e.g. 1000M, 2G) (Default: 1024M).
  --driver-java-options       Extra Java options to pass to the driver.
  --driver-library-path       Extra library path entries to pass to the driver.
  --driver-class-path         Extra class path entries to pass to the driver. Note that
                              jars added with --jars are automatically included in the
                              classpath.

  --executor-memory MEM       Memory per executor (e.g. 1000M, 2G) (Default: 1G).

  --proxy-user NAME           User to impersonate when submitting the application.
                              This argument does not work with --principal / --keytab.

  --help, -h                  Show this help message and exit.
  --verbose, -v               Print additional debug output.
  --version,                  Print the version of current Spark.

 Cluster deploy mode only:
  --driver-cores NUM          Number of cores used by the driver, only in cluster mode
                              (Default: 1).

 Spark standalone or Mesos with cluster deploy mode only:
  --supervise                 If given, restarts the driver on failure.
  --kill SUBMISSION_ID        If given, kills the driver specified.
  --status SUBMISSION_ID      If given, requests the status of the driver specified.

 Spark standalone and Mesos only:
  --total-executor-cores NUM  Total cores for all executors.

 Spark standalone and YARN only:
  --executor-cores NUM        Number of cores per executor. (Default: 1 in YARN mode,
                              or all available cores on the worker in standalone mode)

 YARN-only:
  --queue QUEUE_NAME          The YARN queue to submit to (Default: "default").
  --num-executors NUM         Number of executors to launch (Default: 2).
                              If dynamic allocation is enabled, the initial number of
                              executors will be at least NUM.
  --archives ARCHIVES         Comma separated list of archives to be extracted into the
                              working directory of each executor.
  --principal PRINCIPAL       Principal to be used to login to KDC, while running on
                              secure HDFS.
  --keytab KEYTAB             The full path to the file that contains the keytab for the
                              principal specified above. This keytab will be copied to
                              the node running the Application Master via the Secure
                              Distributed Cache, for renewing the login tickets and the
                              delegation tokens periodically.

#Values                               
To increase parallelism
    spark.default.parallelism for join/cogroup for RD. or spark.sql.shuffle.partitions for join/cogroup for DataFrame
local mode(master and executors are multi threaded) 
    --driver-memory  2g   #heapsize for driver 
Standalone cluster mode (master and executors are multihosted),with spark.eventLog.enabled to true  
    UI is http://<driver-node>:4040, for master http://masterhost:8080 or for worker, http://workerhost:8081, history server: http://<server-url-where-historyserver-started>:18080 
    In client mode(default), the driver is launched in the same process as the client that submits the application. 
    Use this if you are colocated with master/worker 
    In cluster mode, however, the driver is launched from one of the Worker processes inside the cluster, 
    and the client process exits as soon as it fulfills its responsibility of submitting the application without waiting for the application to finish
    Currently, the standalone mode does not support cluster mode for Python applications, use YARN for that
    --master spark://207.184.161.138:7077 
    --deploy-mode cluster or client 
    --driver-memory 2g      #heapsize for driver 
    --executor-memory 20G   #heapsize for each executor  
    --total-executor-cores 100 #total cores for executors 
    --conf "spark.eventLog.enabled=true"
    --packages groupId:artifactId:version
    --jars "jar1.jar,jar2.jar,...
Yarn with spark.eventLog.enabled to true 
    UI is http://<driver-node>:4040  , history server: http://<server-url-where-historyserver-started>:18080
    In cluster mode, the Spark driver runs inside an application master process which is managed by YARN on the cluster, and the client can go away after initiating the application. 
    Use this when you are farway from cluster 
    In client mode, the driver runs in the client process, and the application master is only used for requesting resources from YARN.
    Use this if you are co-located inside cluster 
    --master yarn \
    --deploy-mode cluster or client 
    --driver-memory 3g      #heapsize for driver , use only in cluster mode, for client mode = keep the default of spark.yarn.am.memory 
    --executor-memory 20G   #heapsize for each executor
    --num-executors 50      #how many total executors 
    --executor-cores 6      #no of core per executor ie how many tasks  
    --conf "spark.eventLog.enabled=true" 
    --conf "spark.driver.maxResultSize=2g"  #max size for handling result in driver eg for collect 
    --driver-cores 2        #only for cluster mode , client mode=keep the default spark.yarn.am.cores 
    --jars "jar1.jar,jar2.jar,..." #jars transfered to cluster and are included on the driver and executor classpaths.    
    For example 
        10 Nodes
        16 cores per Node
        64GB RAM per Node
    Calculation 
        To have or good HDFS throughput, 5 core per executors => --executor-cores = 5 
        Leave 1 core per node for Hadoop/Yarn daemons => Num cores available per node = 16-1 = 15
        So, Total available of cores in cluster = 15 x 10 = 150
        Number of available executors = (total cores/num-cores-per-executor) = 150/5 = 30
        Leaving 1 executor for ApplicationManager => --num-executors = 29
        Number of executors per node = 30/10 = 3
        Memory for os and other stuff 3G = 64GB-4G = 60GB
        Memory per executor = 60GB/3 = 20GB
        Counting off heap overhead = 7%(memoryOverhead )of 20GB = 2GB. So, --executor-memory = 20 - 2 = 18GB
    Note keep below yarn-conf 
        yarn.nodemanager.resource.memory-mb(must be atleast60GB)  controls the maximum sum of memory used by the containers on each node.
        yarn.nodemanager.resource.cpu-vcores(must be atleast 15) controls the maximum sum of cores used by the containers on each node
       
        
        
#Properties set directly on the SparkConf take highest precedence, 
#then flags passed to spark-submit or spark-shell, then options in the spark-defaults.conf file

##List of Properties 
#https://spark.apache.org/docs/latest/configuration.html


#Spark - Master URL
local               Run Spark locally with one worker thread (i.e. no parallelism at all).  
local[K]            Run Spark locally with K worker threads (ideally, set this to the number of cores on your machine).  
local[*]            Run Spark locally with as many worker threads as logical cores on your machine. 
spark://HOST:PORT   Connect to the given Spark standalone cluster master. The port must be whichever one your master is configured to use, which is 7077 by default.  
mesos://HOST:PORT   Connect to the given Mesos cluster. The port must be whichever one your is configured to use, which is 5050 by default. Or, for a Mesos cluster using ZooKeeper, use mesos:#zk:#.... To submit with --deploy-mode cluster, the HOST:PORT should be configured to connect to the MesosClusterDispatcher.  
yarn                Connect to a  YARN  cluster in client or cluster mode depending on the value of --deploy-mode. 
                    The cluster location will be found based on the HADOOP_CONF_DIR or YARN_CONF_DIR variable 

#when deploy-mode is client, 
#You could run spark-submit on laptop, and the Driver Program would run on that laptop. 

#when deploy-mode is cluster, 
#then cluster manager (standalone (not for python) YARN, MESOS) is used to find a slave of yarn/mesos-cluster
#having enough available resources to execute the Driver Program. 

#As a result, the Driver Program would run on one of the slave nodes of that yarn/mesos-cluster
#As its execution is delegated, you can not get the result from Driver Program, 
#it must store its results in a file, database, etc



#Example code:wordcount.py
from __future__ import print_function

from pyspark import SparkConf, SparkContext

if __name__ == "__main__":  #Driver program 
    inputFile =  "hdfs://localhost:19000/user/das/README"  # if HDFS is running,OR "file://D:/PPT/README" 
      
    conf = SparkConf().setAppName("wordCount") #.setMaster(master_url) #when running without spark-submit
    #Create a Scala Spark Context.
    sc = SparkContext(conf=conf)
    #Load our input data.
    input =  sc.textFile(inputFile)  #default partitions, or use textFile(inputFile,100)
    #Split up into words.
    words = input.flatMap(lambda line : line.split(" "))  #on executors 
    #Transform into word and count. 
    counts = words.map(lambda word : (word, 1)) \  #on executors,Shuffle boundary , creates map files for reduce phase 
            .reduceByKey(lambda v1, v2 : v1 + v2) #same key, func for values 
      
    #Some logging 
    print(counts.toDebugString())  #each indents is one stage 
    
    #print, returns list
    output = counts.collect()  #on driver , action, hence now getting executed 
    for word, count in output:
        print("%s, %i" % (word, count)) 



#Check application web UI at http://localhost:4040(http://<driver>:4040 )
#check Spark properties in the 'Environment' tab
#spark properties are at conf/spark-defaults.conf, SparkConf(), or the command line will appear.



#usage 
$ hdfs dfs -put README  /user/das/README
#set python2 as we have numpy installed there 
$ set PATH=c:\anaconda2;%PATH%

##Spark - Usage - local mode 
# add Python .zip, .egg or .py files to the search path with '--py-files'
#these files would be distributed to all 
$ spark-submit --master local[4] wordcount.py

##Spark -  In Master/workers mode (admin console)
$ spark-class2 org.apache.spark.deploy.master.Master 
$ spark-class2 org.apache.spark.deploy.worker.Worker spark://192.168.1.2:7077 

#usage - master/workr mode (localhost/127.0.0.1 etc does not work)
$ spark-submit  --master spark://192.168.1.2:7077 wordcount.py

##Spark -  Yarn mode (yarn should be running)
$ set HADOOP_CONF_DIR=c:\hadoop\etc\hadoop\conf
$ spark-submit --master yarn --deploy-mode client wordcount.py

#check logs - from resource manager node 
http://home-e402:8088/cluster/app/application_1491884936563_0005/ 
#get Application_id from spark-submit log


##Spark -   cluster mode, no stdout
$ spark-submit --master yarn --deploy-mode cluster wordcount.py

#so check output from, from resource manager node 
http://home-e402:8088/cluster/app/application_1491884936563_0007/ 
#get Application_id from spark-submit log












##Detals of execution 
#Application -> Job -> many stages, stage boundary at map and reduce(ShuffleBoundary)
#stage -> many task , each task -> one partition of RDD - uses one core of Executors , 
#one core -> one thread 
#RDD -> many partitions 
#node -> many executors 

#Transformations like repartition and reduceByKey induce stage boundaries(shuffling is required)
#Transformations with (usually) Narrow dependencies:Each partition of the parent RDD is used by at most one partition of the child RDD. 
�	map
�	mapValues
�	flatMap
�	filter
�	mapPartitions
�	mapPartitionsWithIndex
#Transformations with (usually) Wide dependencies: (might cause a shuffle):Each partition of the parent RDD may be used by multiple child partitions 
�	cogroup
�	groupWith
�	join
�	leftOuterJoin
�	rightOuterJoin
�	groupByKey
�	reduceByKey
�	combineByKey
�	distinct
�	intersection
�	repartition
�	coalesce


##To increase parallelism - increase partitions - use spark.conf/sc._conf.set(key,value)
1.Explicitely mention more partitions eg in sc.textfile(), rdd1.reduceByKey(_ + _, numPartitions = X), where X=parent partitions*1.5(heuristic) 
2.Use rdd.coalesce(no) to decrease partition with min shuffle, or rdd/df.repartition(no) to increase with full shuffle    
3.Set spark.sql.shuffle.partitions configures the number of partitions that are used when shuffling data frame for joins or aggregations.
4.Set spark.default.parallelism is the default number of partitions in raw RDDs returned by transformations like join, reduceByKey, and parallelize 


##Stages 
#A stage is consisting of many parallel tasks where one task is on one  partition 

#When a job is submitted, a new stage is created with the parent ShuffleMapStage, they can be created from scratch or linked to, i.e. shared, if other jobs use them already.
#DAGScheduler splits up a job into a collection of stages. 
#Each stage contains a sequence of narrow transformations that can be completed without shuffling the entire data set, separated at shuffle boundaries, i.e. where shuffle occurs.


#stage is uniquely identified by  id . 
#When a stage is created, DAGScheduler increments internal counter  nextStageId  to track the number of stage submissions.

#stage can only work on the partitions of a single RDD (identified by  rdd ), 
#but can be associated with many other dependent parent stages (via internal field  parents ), 
#with the boundary of a stage marked by shuffle dependencies.        
        
#There are two types of stages:
�ShuffleMapStage is an intermediate stage (in the execution DAG) that produces data for other stage(s). 
 It writes map output files for a shuffle 
�ResultStage is the final stage that executes a Spark action in a user program by running a function on an RDD.

#Submitting a stage can therefore trigger execution of a series of dependent parent stages   

#Display means 
[Stage7:===========>                              (14174 + 5) / 62500]        
        
#Stage 7: shows the stage you are in now, 
#(14174 + 5) / 62500] is (numCompletedTasks + numActiveTasks) / totalNumOfTasksInThisStage 

#The progress bar shows numCompletedTasks / totalNumOfTasksInThisStage.

#shown when both spark.ui.showConsoleProgress is true (by default) 
#and log level in conf/log4j.properties is ERROR or WARN (!log.isInfoEnabled is true).
       
       
        
##partition (aka split) 
#a logical chunk of a large distributed data set, called RDD (can be imagined as rows of elements, ie 1D, 2D etc )  
#Spark manages data using partitions that helps parallelize distributed data processing 
#with minimal network traffic for sending data between executors.


#By default, Spark tries to read data into an RDD from the nodes that are close to it.
#By default, a partition is created for each HDFS partition, which by default is 64MB 

     
#For example 
#Note all Higher order functions are lazy, to force, use some Action at the end 
>>> rdd = sc.parallelize(range(100)) #default no of partitions = no of cores 
>>> rdd.count()
100 
>>> rdd.getNumPartitions()
4
        
#Manually modifying 
>>> ints = sc.parallelize(range(100), 2) #two partitions 
>>> ints.getNumPartitions()
2
#check patition with values 
>>> ints.mapPartitionsWithIndex(lambda index,values : (index, list(values))).collect()
0, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 2
1, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 4
1, 42, 43, 44, 45, 46, 47, 48, 49], 1, [50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]]


#smaller/more numerous partitions allow work to be distributed among more workers, 
#but larger/fewer partitions allow work to be done in larger chunks,
#which may result in the work getting done more quickly as long 
#as all workers are kept busy, due to reduced overhead.
        

#Spark can only run 1 task for every partition(because one partition=onecore) of an RDD, 
#up to the number of cores in your cluster concurrently 

#you generally want at least as many as the number of executors for parallelism. 
#You can get this computed value by calling  
>>> sc.defaultParallelism  #no of cores 
4
 


#For compressed file, number of partion is always 1 as .gz etc can not work in parallel
#After reading change the partition via repartition or coalesce
def repartition(numPartitions: Int): RDD[T]
#repartition  is coalesce with  numPartitions  and  shuffle  enabled.      
def coalesce(numPartitions: Int, shuffle: Boolean = false): RDD[T]

rdd = sc.parallelize(range(10), 8)
>>> rdd.getNumPartitions()
8

res1 = rdd.coalesce(numPartitions=8, shuffle=False)  
>>> res1.toDebugString()
(8) CoalescedRDD[1] at coalesce at <console>:27 []
 |  ParallelCollectionRDD[0] at parallelize at <console>:24 []

res3 = rdd.coalesce(numPartitions=8, shuffle=True)
>>> res3.toDebugString()  #indents are stages , stage boundary is shuffleBoundary 
res4: String =
(8) MapPartitionsRDD[5] at coalesce at <console>:27 []
 |  CoalescedRDD[4] at coalesce at <console>:27 []
 |  ShuffledRDD[3] at coalesce at <console>:27 []
 +-(8) MapPartitionsRDD[2] at coalesce at <console>:27 []
    |  ParallelCollectionRDD[0] at parallelize at <console>:24 []

    
    
    
    
###*** Spark - RDD - Creation and Basic operations 
#every Spark application consists of a driver program that runs the user's main function (driver)
#and executes various parallel operations on a cluster(called executors on workers)


###Resilient distributed dataset (RDD) (think of vector of elements/objects (eg String, Vector, Matrix) 
#partitioned across the nodes of the cluster that can be operated on in parallel. 


#Only one SparkContext may be active per JVM. 
#You must stop() the active SparkContext before creating a new one.

from pyspark import SparkContext, SparkConf
conf = SparkConf().setAppName(appName).setMaster(master)
sc = SparkContext(conf=conf)
#use and then stop 
sc.stop()


##master is a Spark, Mesos or YARN cluster URL, or a special 'local' string to run in local mode. 
#Note, standalone code must call setMaster(master), but via spark-submit , one passes via command line 
#Note spark-shell, pyspark, sparkR, spark-submit all share same command line args 

$ pyspark --master local[4]



  
##Spark - RDD - sparkContext 
# http://spark.apache.org/docs/2.1.0/api/python/pyspark.html#pyspark.SparkContext

class pyspark.SparkConf(loadDefaults=True, _jvm=None, _jconf=None)
    Used to set various Spark parameters as key-value pairs.
    Check Reference : https://spark.apache.org/docs/latest/configuration.html
    The application web UI at http://<driver>:4040 lists Spark properties in the �Environment� tab
    All setter methods in this class support chaining. 
    eg conf.setMaster('local').setAppName('My app').
        contains(key)
        get(key, defaultValue=None)
        getAll()
        set(key, value)
        setAll(pairs)
        setAppName(value)
        setExecutorEnv(key=None, value=None, pairs=None)
            Set an environment variable to be passed to executors.
        setIfMissing(key, value)
            Set a configuration property, if not already set.
        setMaster(value)
        setSparkHome(value)
        toDebugString()

class pyspark.SparkContext(master=None, appName=None, sparkHome=None, 
            pyFiles=None, environment=None, batchSize=0, 
            serializer=PickleSerializer(), conf=None, 
            gateway=None, jsc=None, profiler_cls=<class 'pyspark.profiler.BasicProfiler'>)
    Main entry point for Spark functionality. 
        conf = SparkConf().setAppName(appName).setMaster(master)
        sc = SparkContext(conf=conf)
    Note path=local(available on all nodes), hdfs,or an HTTP, HTTPS or FTP URI
    PACKAGE_EXTENSIONS = ('.zip', '.egg', '.jar')
        accumulator(value, accum_param=None)
        broadcast(value)
        parallelize(c, numSlices=None)
            Distribute a local Python collection to form an RDD. 
            Using xrange(py2.7)/range(py3) is recommended 
            >>> sc.parallelize([0, 2, 3, 4, 6], 5).glom().collect() #glom() returns each partition's value seperately
            [[0], [2], [3], [4], [6]]
            >>> sc.parallelize(xrange(0, 6, 2), 5).glom().collect()
            [[], [0], [], [2], [4]]
        range(start, end=None, step=1, numSlices=None)
            Create a new RDD of int containing elements from start to end (exclusive), 
            >>> sc.range(5).collect()
            [0, 1, 2, 3, 4]
            >>> sc.range(2, 4).collect()
            [2, 3]
            >>> sc.range(1, 7, 2).collect()
            [1, 3, 5]
        emptyRDD()
            Create an RDD that has no partitions or elements.
        addFile(path, recursive=False)
            Add a file(path=local, hdfs,or an HTTP, HTTPS or FTP URI) 
            to be downloaded with this Spark job on every node. 
                >>> from pyspark import SparkFiles
                >>> path = os.path.join(tempdir, "test.txt")
                >>> with open(path, "w") as testFile:
                        _ = testFile.write("100")
                >>> sc.addFile(path)
                >>> def func(iterator):
                        with open(SparkFiles.get("test.txt")) as testFile:
                            fileVal = int(testFile.readline())
                        return [x * fileVal for x in iterator]
                >>> sc.parallelize([1, 2, 3, 4]).mapPartitions(func).collect()
                [100, 200, 300, 400]
        addPyFile(path), path=local, hdfs,or an HTTP, HTTPS or FTP URI
            Add a .py or .zip dependency for all tasks         
        binaryRecords(path, recordLength)
        binaryFiles(path, minPartitions=None)
            Read a directory of binary files from HDFS, local (available on all nodes), 
            or any Hadoop-supported file system URI    as a byte array. 
            Each file is read as a single record and returned in a (file,content) key-value pair
        hadoopFile(path, inputFormatClass, keyClass, valueClass, keyConverter=None, valueConverter=None, conf=None, batchSize=0)
        newAPIHadoopFile(path, inputFormatClass, keyClass, valueClass, keyConverter=None, valueConverter=None, conf=None, batchSize=0)
        sequenceFile(path, keyClass=None, valueClass=None, keyConverter=None, valueConverter=None, minSplits=None, batchSize=0)
            Read a Hadoop SequenceFile(=(K,V) pair) with arbitrary key and value Writable class from HDFS, a local file system (available on all nodes), 
            or any Hadoop-supported file system URI
            A Hadoop configuration can be passed in as a Python dict. 
            �path � path to Hadoop file
            �inputFormatClass � fully qualified classname of Hadoop InputFormat (e.g. 'org.apache.hadoop.mapreduce.lib.input.TextInputFormat')
            �keyClass � fully qualified classname of key Writable class (e.g. 'org.apache.hadoop.io.Text')
            �valueClass � fully qualified classname of value Writable class (e.g. 'org.apache.hadoop.io.LongWritable')
            �keyConverter � (None by default)
            �valueConverter � (None by default)
            �conf � Hadoop configuration, passed in as a dict (None by default)
            �batchSize � The number of Python objects represented as a single Java object. 
                         (default 0, choose batchSize automatically)
            #Create a RDD of K,V and save as sequence file 
            >>> sc.parallelize([("foo", '{"foo": 1}'), ("bar", '{"bar": 2}')]).saveAsSequenceFile("example")
            #Read K,V 
            rdd_k_v = sc.sequenceFile("example", "org.apache.hadoop.io.Text", "org.apache.hadoop.io.Text")
            >>> rdd_k_v.collect()
            [('foo', '{"foo": 1}'), ('bar', '{"bar": 2}')]
            rdd_v = rdd_k_v.values()  
            >>> rdd_v.first()
            '{"foo": 1}'       
        newAPIHadoopRDD(inputFormatClass, keyClass, valueClass, keyConverter=None, valueConverter=None, conf=None, batchSize=0)
        hadoopRDD(inputFormatClass, keyClass, valueClass, keyConverter=None, valueConverter=None, conf=None, batchSize=0)
            Read a �new API�/old API Hadoop InputFormat with arbitrary key and value class, 
            from an arbitrary Hadoop configuration, which is passed in as a Python dict
            Difference between new and old API http://hadoopbeforestarting.blogspot.com/2012/12/difference-between-hadoop-old-api-and.html
            This is generally used to read from HBase, BigQuery etc 
            conf contains all connection detail, like table name, host name etc 
            Relevant jar files must be loaded via --jars command line options eg hbase-client.jar hbase-server.jar
            Check one example https://cloud.google.com/dataproc/docs/tutorials/bigquery-connector-spark-example
            #Example 
            $ pyspark --jars "hbase-client.jar,hbase-server.jar"
            conf = {"hbase.zookeeper.quorum": "localhost","hbase.mapreduce.inputtable": "data"} 
            rdd = sc.newAPIHadoopRDD("org.apache.hadoop.hbase.mapreduce.TableInputFormat", "org.apache.hadoop.hbase.io.ImmutableBytesWritable", "org.apache.hadoop.hbase.client.Result", conf=conf) 
            rdd.collect()
            #Example 
            $ pyspark --jars /path/to/elasticsearch-hadoop.jar
            conf = {"es.resource" : "index/type"}  # assume Elasticsearch is running on localhost defaults
            rdd = sc.newAPIHadoopRDD("org.elasticsearch.hadoop.mr.EsInputFormat",
                                         "org.apache.hadoop.io.NullWritable",
                                         "org.elasticsearch.hadoop.mr.LinkedMapWritable",
                                         conf=conf)
            rdd.first() 
        pickleFile(name, minPartitions=None)
            Load an RDD previously saved using RDD.saveAsPickleFile method.
            >>> tmpFile = tempfile.NamedTemporaryFile(delete=True)
            >>> tmpFile.close()
            >>> sc.parallelize(range(10)).saveAsPickleFile(tmpFile.name, 5)
            >>> sorted(sc.pickleFile(tmpFile.name, 3).collect())
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        textFile(name, minPartitions=None, use_unicode=True)
            Read a text file linewise 
            If use_unicode is False, the strings will be kept as str (encoding as utf-8)
            >>> path = os.path.join(tempdir, "sample-text.txt")
            >>> with open(path, "w") as testFile:
                    _ = testFile.write("Hello world!")
            >>> textFile = sc.textFile(path)
            >>> textFile.collect()
            [u'Hello world!']
        wholeTextFiles(path, minPartitions=None, use_unicode=True)
            Read a directory of text files as (file,content) pair
            #Example 
            hdfs://a-hdfs-path/part-00000
            hdfs://a-hdfs-path/part-00001
            ...
            hdfs://a-hdfs-path/part-nnnnn

            rdd = sparkContext.wholeTextFiles('hdfs://a-hdfs-path')
            #then rdd contains:
            (a-hdfs-path/part-00000, its content)
            (a-hdfs-path/part-00001, its content)
            ...
            (a-hdfs-path/part-nnnnn, its content)
        union(rdds)
            Build the union of a list of RDDs.
            >>> path = os.path.join(tempdir, "union-text.txt")
            >>> with open(path, "w") as testFile:
                    _ = testFile.write("Hello")
            >>> textFile = sc.textFile(path)
            >>> textFile.collect()
            [u'Hello']
            >>> parallelized = sc.parallelize(["World!"])
            >>> sorted(sc.union([textFile, parallelized]).collect())
            [u'Hello', 'World!']
        runJob(rdd, partitionFunc, partitions=None, allowLocal=False)
            Executes the given partitionFunc on the specified set of partitions, 
            returning the result as an array of elements.
            >>> myRDD = sc.parallelize(range(6), 3)
            >>> sc.runJob(myRDD, lambda part: [x * x for x in part])
            [0, 1, 4, 9, 16, 25]
            >>> myRDD = sc.parallelize(range(6), 3)
            >>> sc.runJob(myRDD, lambda part: [x * x for x in part], [0, 2], True)
            [0, 1, 16, 25]          
        setJobGroup(groupId, description, interruptOnCancel=False)
            Assigns a group ID to all the jobs started by this thread 
            use SparkContext.cancelJobGroup to cancel all running jobs in this group.
            >>> import threading
            >>> from time import sleep
            >>> result = "Not Set"
            >>> lock = threading.Lock()
            >>> def map_func(x):
                    sleep(100)
                    raise Exception("Task should have been cancelled")
            >>> def start_job(x):
                    global result
                    try:
                        sc.setJobGroup("job_to_cancel", "some description")
                        result = sc.parallelize(range(x)).map(map_func).collect()
                    except Exception as e:
                        result = "Cancelled"
                    lock.release()
            >>> def stop_job():
                    sleep(5)
                    sc.cancelJobGroup("job_to_cancel")
            >>> supress = lock.acquire()
            >>> supress = threading.Thread(target=start_job, args=(10,)).start()
            >>> supress = threading.Thread(target=stop_job).start()
            >>> supress = lock.acquire()
            >>> print(result)
            Cancelled
        cancelAllJobs()
        cancelJobGroup(groupId)
        defaultMinPartitions
        defaultParallelism
        stop()
            Shut down the SparkContext.
        applicationId
            A unique identifier for the Spark application
            >>> sc.applicationId  
            u'local-...'
        setCheckpointDir(dirName)
            The directory must be a HDFS path if running on a cluster.  
        version
            The version of Spark on which this application is running.
        uiWebUrl
            Return the URL of the SparkUI instance started by this SparkContext
        setLocalProperty(key, value)
        setLogLevel(logLevel)
        getConf()
        getLocalProperty(key)
        classmethod getOrCreate(conf=None)
            Get or instantiate a SparkContext and register it as a singleton object.
        classmethod setSystemProperty(key, value)
            Set a Java system property, such as spark.executor.memory. 
            This must must be invoked before instantiating SparkContext.
        show_profiles()
        dump_profiles(path)  
        sparkUser()
        startTime
        statusTracker()           
            
            
class pyspark.SparkFiles
    Resolves paths to files added through SparkContext.addFile()
        classmethod get(filename)
            Get the absolute path of a file 
        classmethod getRootDirectory()
            Get the root directory that contains files added 




##Some notes on reading files with Spark:
�If using a path on the local filesystem, 
 the file must also be accessible at the same path on worker nodes. 
 Either copy the file to all workers or use a network-mounted shared file system 

�All of Spark's file-based input methods, including textFile, 
 support running on directories, compressed files, and wildcards 
 textFile("/my/directory"), 
 textFile("/my/directory/*.txt")
 textFile("/my/directory/*.gz")
 Note to change deliminator, newAPIHadoopFile returns K, V 
 rdd = sc.newAPIHadoopFile(YOUR_FILE, "org.apache.hadoop.mapreduce.lib.input.TextInputFormat",
            "org.apache.hadoop.io.LongWritable", "org.apache.hadoop.io.Text",
            conf={"textinputformat.record.delimiter": YOUR_DELIMITER}).map(lambda l:l[1])

�SparkContext.wholeTextFiles lets you read a directory 
 containing multiple text files, 
 and returns each of them as (filename, content) pairs.
 This is in contrast with textFile, 
 which would return linewise in each file of the directory
 
�RDD.saveAsPickleFile(file) and SparkContext.pickleFile(file)
 support saving an RDD in pickle file 

�For SequenceFiles, use SparkContext's sequenceFile[K, V] method 
 where K and V are the types of key and values in the file. 
 These should be subclasses of Hadoop's Writable interface, 
 like IntWritable and Text. 
 
�For other Hadoop InputFormats, use the SparkContext.hadoopRDD method, 
 which takes an arbitrary JobConf 
 and input format class, key class and value class.
 Set these the same way you would for a Hadoop job with your input source. 
 Use SparkContext.newAPIHadoopRDD for InputFormats based on the 'new' MapReduce API (org.apache.hadoop.mapreduce).

 
�PySpark SequenceFile support loads an RDD of key-value pairs within Java, 
 converts Writables to base Java types, and pickles the resulting Java objects using Pyrolite. 
 When saving an RDD of key-value pairs to SequenceFile, PySpark does the reverse. 
 It unpickles Python objects into Java objects and then converts them to Writables. 
 The following Writables are automatically converted:
 #Writable Type     Python Type
  Text              unicode str 
  IntWritable       int 
  FloatWritable     float 
  DoubleWritable    float 
  BooleanWritable   bool 
  BytesWritable     bytearray 
  NullWritable      None 
  MapWritable       dict 
 Arrays are not handled out-of-the-box. 
 Users need to specify custom ArrayWritable subtypes when reading or writing. 
 When writing, users also need to specify custom converters that convert arrays to custom ArrayWritable subtypes. 
 When reading, the default converter will convert custom ArrayWritable subtypes to Java Object[], 
 which then get pickled to Python tuples. 
 To get Python array.array for arrays of primitive types, users need to specify custom converters.

 Note that, if the InputFormat simply depends on a Hadoop configuration and/or input path, 
 and the key and value classes can easily be converted according to the above table, 
 then this approach should work well for such cases.

 If you have custom serialized binary data (such as loading data from Cassandra / HBase), 
 then you will first need to transform that data on the Scala/Java side to something 
 which can be handled by Pyrolite�s pickler. A 'Converter' trait is provided for this. 
 Simply extend this trait and implement your transformation code in the convert method. 
 Remember to ensure that this class, along with any dependencies required to access your InputFormat, 
 are packaged into your Spark job jar and included on the PySpark classpath.
 Check exmaples 
 https://github.com/apache/spark/blob/master/examples/src/main/python/parquet_inputformat.py
 https://github.com/apache/spark/blob/master/examples/src/main/python/avro_inputformat.py
 https://github.com/apache/spark/tree/master/examples/src/main/scala/org/apache/spark/examples/pythonconverters
 
 
##Various keyClass or valueClass from standard Hadoop 
#derived from org.apache.hadoop.io.Writable
org.apache.hadoop.io.IntWritable
org.apache.hadoop.io.ByteWritable
org.apache.hadoop.io.DoubleWritable
org.apache.hadoop.io.FloatWritable
org.apache.hadoop.io.IntWritable
org.apache.hadoop.io.LongWritable
org.apache.hadoop.io.Text
#InputFormat hierarchy
org.apache.hadoop.mapreduce.InputFormat<K,V>
    org.apache.hadoop.mapreduce.lib.input.FileInputFormat<K,V>
        org.apache.hadoop.mapreduce.lib.input.CombineFileInputFormat<K,V>
            org.apache.hadoop.mapreduce.lib.input.CombineSequenceFileInputFormat<K,V>
            org.apache.hadoop.mapreduce.lib.input.CombineTextInputFormat
        org.apache.hadoop.mapreduce.lib.input.FixedLengthInputFormat extends FileInputFormat<LongWritable,BytesWritable>
            FixedLengthInputFormat is an input format used to read input files 
            which contain fixed length records. 
            The content of a record need not be text. 
            It can be arbitrary binary data.
        org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat extends FileInputFormat<Text,Text>
            An InputFormat for plain text files. 
            Files are broken into lines. 
            Either linefeed or carriage-return are used to signal end of line. 
            Each line is divided into key and value parts by a separator byte(default \t) 
            If no such a byte exists, the key will be the entire line 
            and value will be empty.
        org.apache.hadoop.mapreduce.lib.input.NLineInputFormat extends FileInputFormat<LongWritable,Text>
            NLineInputFormat which splits N lines of input as one split
            by default, one line is fed as a value to one map task, and key is the offset. 
        org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat<K,V>
            org.apache.hadoop.mapreduce.lib.input.SequenceFileAsBinaryInputFormat
            org.apache.hadoop.mapreduce.lib.input.SequenceFileAsTextInputFormat
            org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFilter<K,V>
        org.apache.hadoop.mapreduce.lib.input.TextInputFormat extends FileInputFormat<LongWritable, Text>
            An InputFormat for plain text files. Files are broken into lines. 
            Either linefeed or carriage-return are used to signal end of line. 
            Keys are the position in the file, and values are the line of text

#Quick OutPutFormat 
#keyClass and valueClass comes from earlier 
org.apache.hadoop.mapreduce.OutputFormat<K,V>
    org.apache.hadoop.mapreduce.lib.output.FileOutputFormat<K,V>
        org.apache.hadoop.mapreduce.lib.output.MapFileOutputFormat
        org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat<K,V>
            org.apache.hadoop.mapreduce.lib.output.SequenceFileAsBinaryOutputFormat
        org.apache.hadoop.mapreduce.lib.output.TextOutputFormat<K,V>
                writes plain text files,change seperator by SEPERATOR 
    org.apache.hadoop.mapreduce.lib.output.FilterOutputFormat<K,V>
        org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat<K,V>
    org.apache.hadoop.mapreduce.lib.output.NullOutputFormat<K,V>
        Consume all outputs and put them in /dev/null.
        
                
#Constant values used , Set it via org.apache.hadoop.conf.Configuration.set*
#And use it with sc.newAPIHadoopFile
org.apache.hadoop.mapreduce.lib.input.CombineFileInputFormat<K,V> 
    String 	"mapreduce.input.fileinputformat.split.minsize.per.node"
    String   "mapreduce.input.fileinputformat.split.minsize.per.rack"
org.apache.hadoop.mapreduce.lib.input.FileInputFormat<K,V> 
    String 	"mapreduce.input.fileinputformat.inputdir"
    String 	"mapreduce.input.fileinputformat.input.dir.recursive"
    String 	"mapreduce.input.fileinputformat.list-status.num-threads"
    String 	"mapreduce.input.fileinputformat.numinputfiles"
    String 	"mapreduce.input.pathFilter.class"
    String 	"mapreduce.input.fileinputformat.split.maxsize"
    String 	"mapreduce.input.fileinputformat.split.minsize"
org.apache.hadoop.mapreduce.lib.input.FixedLengthInputFormat 
    String  "fixedlengthinputformat.record.length"
org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat 
    String 	"mapreduce.input.keyvaluelinerecordreader.key.value.separator"
org.apache.hadoop.mapreduce.lib.input.MultipleInputs 
    String "mapreduce.input.multipleinputs.dir.formats"
    String 	"mapreduce.input.multipleinputs.dir.mappers"
org.apache.hadoop.mapreduce.lib.input.NLineInputFormat 
    String 	"mapreduce.input.lineinputformat.linespermap"
org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFilter<K,V> 
    String 	"mapreduce.input.sequencefileinputfilter.class"
    String 	"mapreduce.input.sequencefileinputfilter.frequency"
    String 	"mapreduce.input.sequencefileinputfilter.regex"
org.apache.hadoop.mapreduce.lib.input.TextInputFormat
    String  "textinputformat.record.delimiter"
org.apache.hadoop.mapreduce.lib.output.FileOutputFormat<K,V> 
    String 	 	"mapreduce.output.basename"
    String 	 	"mapreduce.output.fileoutputformat.compress"
    String 	 	"mapreduce.output.fileoutputformat.compress.codec"
    String 	 	"mapreduce.output.fileoutputformat.compress.type"
    String 	 	"mapreduce.output.fileoutputformat.outputdir"
org.apache.hadoop.mapreduce.lib.output.TextOutputFormat
    String "mapred.textoutputformat.separator"


    
    
###Spark - RDD - Resilient Distributed Datasets (RDDs) 

##Spark - RDD - creation by SparkContext 
#Typically you want 2-4 partitions for each CPU core in your cluster. 
sc.defaultParallelism
sc._conf.set("spark.default.parallelism", 16)
rdd.getNumPartitions()
#create via parallelize or methods of reading textfile, json string etc 
#or indirectly via ML's DF read operations 

#Default partitioner function for K,V is portable_hash(K) ie hash function for all ie immutable object must be as key 
#but sortByKey uses rangePartitioner
#repartition by partitionBy(numPartitions, partitionFunc) or use Partitioner
#which calls partitionFunc(k) % numPartitions
#partitionFunc takes K and return the partition number 
# Keys in a range partitioner are partitioned based on the set of sorted range of keys and ordering of keys.
class Partitioner(object):
    def __init__(self, numPartitions, partitionFunc):
        self.numPartitions = numPartitions
        self.partitionFunc = partitionFunc

    def __eq__(self, other):
        return (isinstance(other, Partitioner) and self.numPartitions == other.numPartitions
                and self.partitionFunc == other.partitionFunc)

    def __call__(self, k):
        return self.partitionFunc(k) % self.numPartitions





##Spark - RDD - RDD Operations
#transformations, which create a new dataset from an existing one(gets executed in executor)
#actions, which return a value to the driver program after running a computation on the dataset. 

#Transformations are not executed without action. 

lines = sc.textFile("d:/desktop/ppt/spark/data/README")
lineLengths = lines.map(lambda s: len(s))  #transformations
totalLength = lineLengths.reduce(lambda a, b: a + b) #action 

###RDD - Transformations(lazy, does not get executed without Action closure in executor )
map(func)  
filter(func)  
flatMap(func)  

mapPartitions(func)   
mapPartitionsWithIndex(func)  

sample(withReplacement, fraction, seed)
distinct([numPartitions]))  
pipe(command, [envVars]) 

union(otherDataset)  
intersection(otherDataset) 
cartesian(otherDataset)
join(otherDataset, [numPartitions])   
cogroup(otherDataset, [numPartitions]) 

groupByKey([numPartitions])   
reduceByKey(func, [numPartitions])   
aggregateByKey(zeroValue)(seqOp, combOp, [numPartitions])   
sortByKey([ascending], [numPartitions])   
 
coalesce(numPartitions)   
repartition(numPartitions)  
repartitionAndSortWithinPartitions(partitioner)  


###RDD - Actions(eager - executes whole pipeline before it , closure in executor , final value processing in driver) 
reduce(func) 
count()  
countByKey()
foreach(func)  

collect()  
first()    
take(n)  
takeSample(withReplacement, num, [seed])  
takeOrdered(n, [ordering])  

saveAsTextFile(path)  
saveAsSequenceFile(path, compressionCodecClass=None) 
saveAsPickleFile(path, compressionCodecClass=None) 


###RDD- Understanding Execution 
#what would be value of counter ?
counter = 0
rdd = sc.parallelize(data)


def increment_counter(x):
    global counter
    counter += x

rdd.foreach(increment_counter)

print("Counter value: ", counter)


#Function gets executed in executor only 
#Any closure along with captured variables are serialized by driver and sent to executors
#Executors execuate that function for it's own partitions .
#If it requires other partition data, then spark does a shuffle 

#The variables within the closure sent to each executor are now copies 
#and thus, when counter is referenced within the foreach function(ie in executor), it�s no longer the counter on the driver node

#hence final counter is zero(but would be ok for single thread JVM eg local[1])
#SOLUTION: Use Accumulator in this case 



###Spark - RDD - Printing elements of an RDD

#in local mode, OK 
#in cluster mode - stdout is executer/another machines stdout, hence check SPARK_WORKER_DIR or sparkUI/ResourceManagerUI
rdd.foreach(lambda x: print(x)) 
rdd.map(lambda x: print(x)) #Wrong as map is transformation, hence lazy 

#This can cause the driver to run out of memory- hence safer is to use take 
rdd.take(100) #==> returns list 







###Spark - RDD - Passing Functions in the driver program to run on the cluster. 
#IMP*** functions along with captured variables must be serialized/pickled - else ERROR 
#Note if captured variables are not serializable(eg contains complicated state eg socket/DB/file connection). IT WOULD FAIL 


#Followings are performant
    �Lambda expressions, for simple functions that can be written as an expression. 
    �Simple Local defs inside a function calling Spark methods
    �Top-level functions in a module.
#For class methods, check captured variable  

#Performant Example 
if __name__ == "__main__":
    def myFunc(s):
        words = s.split(" ")
        return len(words)

    sc = SparkContext(...)
    sc.textFile("file.txt").map(myFunc)
    
##Note: For below type of cases, 
#whole object/class needs to be sent to cluster which might  not be performant 
class MyClass(object):
    def func(self, s):
        return s
    def doStuff(self, rdd):
        return rdd.map(self.func)
#OR 
class MyClass(object):
    def __init__(self):
        self.field = "Hello"
    def doStuff(self, rdd):
        return rdd.map(lambda s: self.field + s)

#One Solution - copy field into a local variable 
def doStuff(self, rdd):
    field = self.field
    return rdd.map(lambda s: field + s)
    
    
#Example - Bad code 
connection = createNewConnection()  # executed at the driver
rdd.foreach(lambda record: connection.send(record)) #connection is getting serialized and sent to executor 
connection.close()

#One solution is to open connection in executor 
#But for each element, connection would be opened - not performant
def sendRecord(record):
    connection = createNewConnection()
    connection.send(record)
    connection.close()

rdd.foreach(sendRecord)

#Better solution can be Partitionwise 
def sendPartition(iter):
    connection = createNewConnection()
    for record in iter:
        connection.send(record)
    connection.close()
rdd.foreachPartition(sendPartition)
    
    

###Spark - RDD - Shuffle operations
#The shuffle is Spark's mechanism for re-distributing data so that it's grouped differently across partitions. 


#Operations which can cause a shuffle include repartition operations 
#repartition and coalesce, 'ByKey operations (except for counting) 
#groupByKey and reduceByKey, and join operations like cogroup and join.

#Certain shuffle operations can consume significant amounts of heap memory 
#since they employ in-memory data structures to organize records before or after transferring them
#Shuffle also generates a large number of intermediate files on disk for sharing with next stage 


#Although the set of elements in each partition of newly shuffled data will be deterministic, 
#and so is the ordering of partitions themselves, 
#the ordering of these elements is not. 
#If one desires predictably ordered data following shuffle , use below 
1.mapPartitions(func) to sort each partition using, for example, 'sorted'
2.repartitionAndSortWithinPartitions(numPartitions=None, partitionFunc=<function portable_hash>, ascending=True, keyfunc=<function RDD.<lambda>>)
 to efficiently sort partitions while simultaneously repartitioning
3.sortBy(keyfunc, ascending=True, numPartitions=None)
  to make a globally ordered RDD

#Shuffles files are created at he temporary storage directory ,spark.local.dir 
#Check configuration: http://spark.apache.org/docs/latest/configuration.html#shuffle-behavior
#check http://bigdatatn.blogspot.com/2017/05/spark-performance-optimization-shuffle.html



###Spark - RDD - treeAggregate/treeReduce

#In a regular reduce or aggregate functions in Spark 
#all partitions have to send their reduced value to the driver machine, 
#and that machine spends linear time on the number of partitions , causing performance issue 

#in treeReduce and in treeAggregate, the partitions talk to each other in a logarithmic number of rounds.
#data are combined partially on a small set of executors before they are sent to the driver, reducing time dramatically  

#Note , reduceByKey is only available on key-value pair RDDs and it's a transformation 
#while treeReduce is a generalization of reduce operation on any RDD and its a action reduceByKey is used for implementing treeReduce but they are not related in any other sense. reduceByKey performs reduction for each key, resulting in an RDD; it is not an action but a transformation that returns a Shuffled RDD.

#treeAggregate  is a specialized implementation of aggregate 
#that iteratively applies the combine function to a subset of partitions. 

>>> add = lambda x, y: x + y
>>> rdd = sc.parallelize([-5, -4, -3, -2, -1, 1, 2, 3, 4], 10)
>>> rdd.treeAggregate(0, add, add)
-5
>>> rdd.treeAggregate(0, add, add, depth=2)
-5
>>> rdd.treeReduce(add, depth=2)
-5



##Reference 
#Note Same RDD class contains RDD of T and RDD of (K,V) pair functionality, K is called Key
#Note T can be any type including (K,V), but (K,V) does not have any special meaning 
#If a method understands K of (K,V), it is mentioned explicitly(or method suffix is ByKey), 
#else it is applicable for T 
class pyspark.RDD(jrdd, ctx, jrdd_deserializer=AutoBatchedSerializer(PickleSerializer()))
    A Resilient Distributed Dataset (RDD), 
    the basic abstraction in Spark, can be operated on in parallel
    Many methods of RDD of (K,V) have partitionFunc=<function portable_hash>
    which is used for repartitioning by  partitionBy(numPartitions, partitionFunc)
    and partitionFunc takes only key and return a hash value eg portable_hash(x) in rdd code 
    Partitioner(numPartitions, partitionFunc) also can be used in place of partitionFunc
    which have __call__(k) returns self.partitionFunc(k) % self.numPartitions 
    context
        The SparkContext that this RDD was created on.
    id()
        A unique ID for this RDD (within its SparkContext).
    collect()
        Return a list that contains all of the elements in this RDD.
        Must be called to get all data into driver program
    collectAsMap()
        For RDD of (K,V)
        Return the key-value pairs in this RDD to the driver as a dictionary.
        >>> m = sc.parallelize([(1, 2), (3, 4)]).collectAsMap()
        >>> m[1]
        2
        >>> m[3]
        4
    glom()
        Return an RDD by coalescing all elements within each partition into a list.
        >>> rdd = sc.parallelize([1, 2, 3, 4], 2)
        >>> sorted(rdd.glom().collect())
        [[1, 2], [3, 4]]
    aggregate(zeroValue, seqOp, combOp)
        seqOp(r,e): Aggregate the elements(e) of each partition, ie partitionwise 
        Note for each partition and 1st loop, seqOp is called with r=zeroValue,e=each element of that partition, 
        for 2nd loop, r=return value of earlier seqOp and so on        
        combOp(r1,r2): Combine the results for all the partitions 
        and is called with r1=ZeroValue for first loop , r2=value from 1st partition after seqOp 
        for 2nd loop, r1 = return of above , e= 2nd partition seqOp value 
        r and e type can be different
        seq/combOp(r,x) can modify r and return , but not x 
            >>> seqOp = (lambda x, y: (x[0] + y, x[1] + 1)) #x,y is diff type . x is type of ZeroValue and also return type of function, y each element
            >>> combOp = (lambda x, y: (x[0] + y[0], x[1] + y[1]))#x,y is of same type which is returns of seqOp
            >>> sc.parallelize([1, 2, 3, 4]).aggregate((0, 0), seqOp, combOp)
            (10, 4)
            >>> sc.parallelize([]).aggregate((0, 0), seqOp, combOp)
            (0, 0)
    aggregateByKey(zeroValue, seqFunc, combFunc, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
        Same as above, but for RDD of (K,V) pair 
        zeroValue: U, For Same key, K, seqFunc(U,V):U on each partition 
        combFunc(U1,U2) for merging values(of same Key) on all partitions 
        Returns RDD of (K,U) 
            >>> seqOp = lambda v1, v2: v1+v2  #ZeroValue is coming here 
            >>> combOp = lambda r1,r2: r1+r2 
            #sum by Key 
            >>> sc.parallelize([(0,1), (0,2), (1,3), (1,4)]).aggregateByKey(0, seqOp, combOp).collect()
            [(0, 3), (1, 7)]
            #Average by key 
            >>> seqOp = lambda t, v: (t[0]+v,t[1]+1)  #ZeroValue=(0,0), first index =sum, 2ndindex=count 
            >>> combOp = lambda t1,t2: (t1[0]+t2[0], t1[1]+t2[1]) #simply add both     
            >>> sc.parallelize([(0,1), (0,2), (1,3), (1,4)]).aggregateByKey( (0,0) , seqOp, combOp).mapValues( lambda t : t[0]/t[1]).collect()
            [(0, 1.5), (1, 3.5)]            
    treeAggregate(zeroValue, seqOp, combOp, depth=2)
        Aggregates the elements of this RDD[T] in a multi-level tree pattern.
        #(zeroValue: U)(seqOp: (U, T) => U, combOp: (U, U) => U
        depth � suggested depth of the tree (default: 2) 
        >>> add = lambda x, y: x + y
        >>> rdd = sc.parallelize([-5, -4, -3, -2, -1, 1, 2, 3, 4], 10)
        >>> rdd.treeAggregate(0, add, add, 2)
        -5
    combineByKey(createCombiner, mergeValue, mergeCombiners, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
        For RDD of (K,V), 
        Type: createCombiner: (V) => C, mergeValue: (C, V) => C, mergeCombiners: (C, C) => C
        Turns an RDD[(K, V)] into a result of type RDD[(K, C)], for a 'combined type' C.
        For same Key, K, 
            �createCombiner, which converts first V into a C 
            �mergeValue, to merge a V(from remaining Vs) into a C 
            �mergeCombiners, to combine two C's into a single one.
        >>> x = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
        >>> def add(a, b): return a + str(b)  #a type = return from createCombiner
        >>> sorted(x.combineByKey(str, add, add).collect())
        [('a', '11'), ('b', '1')]
    cogroup(other, numPartitions=None)
        For RDD of (K,V)
        Type: other: RDD[(K, W)] returns  RDD[(K, (Iterable[V], Iterable[W]))]
        For each and same key k in self or other, return a RDD of (k, ((v1,v11,...), (v2,v21..))  )
        v1n are from self, v2n are from other 
        >>> x = sc.parallelize([("a", 1), ("b", 4)])
        >>> y = sc.parallelize([("a", 2)])
        >>> [(x, tuple(map(list, y))) for x, y in sorted(list(x.cogroup(y).collect()))]
        [('a', ([1], [2])), ('b', ([4], []))]
    groupWith(other, *others)
        Alias for cogroup but with support for multiple RDDs.
        For RDD of (K,V)
        Type: other1: RDD[(K, W1)], other2: RDD[(K, W2)], other3: RDD[(K, W3)])
        Returns RDD[(K, (Iterable[V], Iterable[W1], Iterable[W2], Iterable[W3]))]
        >>> w = sc.parallelize([("a", 5), ("b", 6)])
        >>> x = sc.parallelize([("a", 1), ("b", 4)])
        >>> y = sc.parallelize([("a", 2)])
        >>> z = sc.parallelize([("b", 42)])
        >>> [(x, tuple(map(list, y))) for x, y in sorted(list(w.groupWith(x, y, z).collect()))]
        [('a', ([5], [1], [2], [])), ('b', ([6], [4], [], [42]))]
    groupBy(f, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
        Given RDD[T], Return an RDD of grouped items 
        ie RDD of (K,V), where K=f(e) and V=[original_T1,original_T2,...]
        >>> rdd = sc.parallelize([1, 1, 2, 3, 5, 8])
        >>> result = rdd.groupBy(lambda x: x % 2).collect()
        >>> sorted([(x, sorted(y)) for (x, y) in result])
        [(0, [2, 8]), (1, [1, 1, 3, 5])]
    groupByKey(numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
        For RDD of (K,V)
        returns RDD of (K, (v1,v2..)) for same key 
        >>> rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
        >>> sorted(rdd.groupByKey().mapValues(len).collect())
        [('a', 2), ('b', 1)]
        >>> sorted(rdd.groupByKey().mapValues(list).collect())
        [('a', [1, 1]), ('b', [1])] 
    keyBy(f)
        Creates RDD of tuples (f(e), e) of the elements in this RDD by applying f(e).
        >>> x = sc.parallelize(range(0,3)).keyBy(lambda x: x*x)
        >>> x.collect()
        [(0, 0), (1, 1), (4, 2)]
    fullOuterJoin(other, numPartitions=None)
        For self:RDD of (K,V) and other:RDD[(K, W)]
        Perform a right outer join of self and other.
        For each element (k, v) in self , 
        the resulting RDD will either contain (k, (v, w)) for w in other for same key k,
        or the pair (k, (v, None)) if no elements in other have key k.
        Similarly for other, creates (k, (None,w)) for keys not existing in self 
        >>> x = sc.parallelize([("a", 1), ("b", 4)])
        >>> y = sc.parallelize([("a", 2), ("c", 8)])
        >>> sorted(x.fullOuterJoin(y).collect())
        [('a', (1, 2)), ('b', (4, None)), ('c', (None, 8))]
    join(other, numPartitions=None)
        For self:RDD of (K,V) and other: RDD[(K, W)]
        For each (k,v) of self, If there is same Key in other, returns  RDD of (k, (v, w)) tuple, 
        >>> x = sc.parallelize([("a", 1), ("b", 4)])
        >>> y = sc.parallelize([("a", 2), ("a", 3)])
        >>> sorted(x.join(y).collect())
        [('a', (1, 2)), ('a', (1, 3))]   
    leftOuterJoin(other, numPartitions=None)
        For self:RDD of (K,V) and other: RDD[(K, W)]
        For each element (k, v) in self, 
        returns RDD of pairs (k, (v, w)) for w in other for same key k, 
        or the pair (k, (v, None)) if no elements in other have key k.
        >>> x = sc.parallelize([("a", 1), ("b", 4)])
        >>> y = sc.parallelize([("a", 2)])
        >>> sorted(x.leftOuterJoin(y).collect())
        [('a', (1, 2)), ('b', (4, None))]
    rightOuterJoin(other, numPartitions=None)
        For self:RDD of (K,V) and other: RDD[(K, W)]
        For each element (k, w) in other, 
        returns RDD of  pairs (k, (v, w)) for v in self for same key k, 
        or the pair (k, (None, w)) if no elements in self have key k.
        >>> x = sc.parallelize([("a", 1), ("b", 4)])
        >>> y = sc.parallelize([("a", 2)])
        >>> sorted(y.rightOuterJoin(x).collect())
        [('a', (2, 1)), ('b', (None, 4))]
    cache()
        Persist this RDD with the default storage level (MEMORY_ONLY).
    unpersist()
        Mark the RDD as non-persistent, 
        and remove all blocks for it from memory and disk.
    getStorageLevel()
        Get the RDD's current storage level.
        >>> rdd1 = sc.parallelize([1,2])
        >>> rdd1.getStorageLevel()
        StorageLevel(False, False, False, False, 1)
        >>> print(rdd1.getStorageLevel())
        Serialized 1x Replicated
    persist(storageLevel=StorageLevel(False, True, False, False, 1))
        This can only be used to assign a new storage level 
        if the RDD does not have a storage level set yet. 
        If no storage level is specified defaults to (MEMORY_ONLY).
        >>> rdd = sc.parallelize(["b", "a", "c"])
        >>> rdd.persist().is_cached
        True
    cartesian(other)
        Return RDD of all pairs of elements (a, b) where a is in self and b is in other.
        >>> rdd = sc.parallelize([1, 2])
        >>> sorted(rdd.cartesian(rdd).collect())
        [(1, 1), (1, 2), (2, 1), (2, 2)]
    coalesce(numPartitions, shuffle=False)
        Return a new RDD that is reduced into numPartitions partitions.
        >>> sc.parallelize([1, 2, 3, 4, 5], 3).glom().collect()
        [[1], [2, 3], [4, 5]]
        >>> sc.parallelize([1, 2, 3, 4, 5], 3).coalesce(1).glom().collect()
        [[1, 2, 3, 4, 5]]
    partitionBy(numPartitions, partitionFunc=portable_hash)
        For RDD of (K,V), partitionFunc takes K and returns partition number where to put 
        Final partition number is calculated as partitionFunc(k) % numPartitions
        Return a copy of the RDD[(K, V)] partitioned using the specified partitioner.
        >>> pairs = sc.parallelize([1, 2, 3, 4, 2, 4, 1]).map(lambda x: (x, x))
        >>> pairs.partitionBy(2).glom().collect()
        [[(2, 2), (4, 4), (2, 2), (4, 4)], [(1, 1), (3, 3), (1, 1)]]
    repartition(numPartitions)
        Return a new RDD that has exactly numPartitions partitions.
        >>> rdd = sc.parallelize([1,2,3,4,5,6,7], 4)
        >>> sorted(rdd.glom().collect())
        [[1], [2, 3], [4, 5], [6, 7]]
        >>> len(rdd.repartition(2).glom().collect())
        2
        >>> len(rdd.repartition(10).glom().collect())
        10
    repartitionAndSortWithinPartitions(numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>, ascending=True, keyfunc=lambda x: x)
        For RDD of (K,V), repartition by partitionBy(numPartitions, partitionFunc)
        Within each resulting partition, sort records by  keyfunc(K) 
        >>> rdd = sc.parallelize([(0, 5), (3, 8), (2, 6), (0, 8), (3, 8), (1, 3)])
        #repartition with whether key is even or odd , note partitionFunc takes K 
        >>> rdd2 = rdd.repartitionAndSortWithinPartitions(2, lambda x: x % 2, True)
        >>> rdd2.glom().collect()
        [[(0, 5), (0, 8), (2, 6)], [(1, 3), (3, 8), (3, 8)]]
    first()
        Return the first element in this RDD.
        >>> sc.parallelize([2, 3, 4]).first()
        2
        >>> sc.parallelize([]).first()    
        ValueError: RDD is empty
    take(num)
        Take the first num elements of the RDD.(Action)
        >>> sc.parallelize([2, 3, 4, 5, 6]).cache().take(2)
        [2, 3]
        >>> sc.parallelize([2, 3, 4, 5, 6]).take(10)
        [2, 3, 4, 5, 6]
        >>> sc.parallelize(range(100), 100).filter(lambda x: x > 90).take(3)
        [91, 92, 93]
    takeOrdered(num, key=None)
        Get the N elements from an RDD ordered in ascending order 
        or after sorting by  key(element) function(Action)
        >>> sc.parallelize([10, 1, 2, 9, 3, 4, 5, 6, 7]).takeOrdered(6)
        [1, 2, 3, 4, 5, 6]
        >>> sc.parallelize([10, 1, 2, 9, 3, 4, 5, 6, 7], 2).takeOrdered(6, key=lambda x: -x)
        [10, 9, 7, 6, 5, 4]
    top(num, key=None)
        Get the top N elements from an RDD.(Action)
        >>> sc.parallelize([10, 4, 2, 12, 3]).top(1)
        [12]
        >>> sc.parallelize([2, 3, 4, 5, 6], 2).top(2)
        [6, 5]
        >>> sc.parallelize([10, 4, 2, 12, 3]).top(3, key=str)
        [4, 3, 2]
    count()
        Return the number of elements in this RDD.(Action)
        >>> sc.parallelize([2, 3, 4]).count()
        3
    countApprox(timeout, confidence=0.95)
        Approximate version of count() and returns result to master/driver(Action)
        >>> rdd = sc.parallelize(range(1000), 10)
        >>> rdd.countApprox(1000, 1.0)
        1000
    countApproxDistinct(relativeSD=0.05)
        Return approximate number of distinct elements in the RDD.
        >>> n = sc.parallelize(range(1000)).map(str).countApproxDistinct()
        >>> 900 < n < 1100
        True
        >>> n = sc.parallelize([i % 20 for i in range(1000)]).countApproxDistinct()
        >>> 16 < n < 24
        True
    countByKey()
        For RDD (K,V) and returns result (K,count) to master/driver(Action)
        >>> rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
        >>> sorted(rdd.countByKey().items())
        [('a', 2), ('b', 1)]
    countByValue()
        For only RDD of V, not for (K,V)
        Return the count of each unique value in this RDD 
        as a dictionary of (value, count) pairs.(Action)
        >>> sorted(sc.parallelize([1, 2, 1, 2, 2], 2).countByValue().items())
        [(1, 2), (2, 3)]
    distinct(numPartitions=None)
        Return a new RDD containing the distinct elements in this RDD.
        >>> sorted(sc.parallelize([1, 1, 2, 3]).distinct().collect())
        [1, 2, 3]
    min(key=None)
        Find the minimum item in this RDD.
        or after sorting by  key(element) function
    max(key=None)
        Find the maximum item in this RDD.
        or after sorting by  key(element) function
        >>> rdd = sc.parallelize([1.0, 5.0, 43.0, 10.0])
        >>> rdd.max()
        43.0
        >>> rdd.max(key=str)
        5.0
    mean()
        Compute the mean of this RDD's elements.
        >>> sc.parallelize([1, 2, 3]).mean()
        2.0
    meanApprox(timeout, confidence=0.95)
        Approximate operation to return the mean within a timeout or meet the confidence.
        >>> rdd = sc.parallelize(range(1000), 10)
        >>> r = sum(range(1000)) / 1000.0
        >>> abs(rdd.meanApprox(1000) - r) / r < 0.05
        True
    sampleStdev()
        Compute the sample standard deviation of this RDD's elements 
        >>> sc.parallelize([1, 2, 3]).sampleStdev()
        1.0
    sampleVariance()
        Compute the sample variance of this RDD's elements 
        >>> sc.parallelize([1, 2, 3]).sampleVariance()
        1.0
    stats()
        Return a StatCounter object containing below methods
        merge(value),mergeStats(other),copy()
        count(),mean(),sum(),min(),max(),variance(),sampleVariance(),stdev(),sampleStdev() 
    stdev()
        Compute the standard deviation of this RDD's elements.
        >>> sc.parallelize([1, 2, 3]).stdev()
        0.816...
    variance()
        Compute the variance of this RDD's elements.
        >>> sc.parallelize([1, 2, 3]).variance()
        0.666...
    sum()
        Add up the elements in this RDD.
        >>> sc.parallelize([1.0, 2.0, 3.0]).sum()
        6.0
    sumApprox(timeout, confidence=0.95)
        >>> rdd = sc.parallelize(range(1000), 10)
        >>> r = sum(range(1000))
        >>> abs(rdd.sumApprox(1000) - r) / r < 0.05
        True
    filter(f)
        Return a new RDD containing only the elements that satisfy a predicate.
        >>> rdd = sc.parallelize([1, 2, 3, 4, 5])
        >>> rdd.filter(lambda x: x % 2 == 0).collect()
        [2, 4]
    map(f, preservesPartitioning=False)
        Return a new RDD of f(e)
        >>> rdd = sc.parallelize(["b", "a", "c"])
        >>> sorted(rdd.map(lambda x: (x, 1)).collect())
        [('a', 1), ('b', 1), ('c', 1)]
    mapPartitions(f, preservesPartitioning=False)
        Return a new RDD by applying a function f(iterator)
        where iterator consists of all elements in that partition
        >>> rdd = sc.parallelize([1, 2, 3, 4], 2)
        >>> def f(iterator): yield sum(iterator)
        >>> rdd.mapPartitions(f).collect()
        [3, 7]
    mapPartitionsWithIndex(f, preservesPartitioning=False)
        Return a new RDD by applying a function f(index, Iterator)
        where iterator consists of all elements in that partition
        >>> rdd = sc.parallelize([1, 2, 3, 4], 4)
        >>> def f(splitIndex, iterator): yield splitIndex
        >>> rdd.mapPartitionsWithIndex(f).sum()
        6
    mapPartitionsWithSplit(f, preservesPartitioning=False)
        Deprecated: use mapPartitionsWithIndex instead.
    mapValues(f)
        For RDD of (K,V)
        Same as map, but for each key, transform values by f(v)
        >>> x = sc.parallelize([("a", ["apple", "banana", "lemon"]), ("b", ["grapes"])])
        >>> def f(x): return len(x)
        >>> x.mapValues(f).collect()
        [('a', 3), ('b', 1)]
    flatMap(f, preservesPartitioning=False)
        Return a new RDD with f(e):Iterable and after flattening 
        >>> rdd = sc.parallelize([2, 3, 4])
        >>> sorted(rdd.flatMap(lambda x: range(1, x)).collect())
        [1, 1, 1, 2, 2, 3]
        >>> sorted(rdd.flatMap(lambda x: [(x, x), (x, x)]).collect())
        [(2, 2), (2, 2), (3, 3), (3, 3), (4, 4), (4, 4)]
    flatMapValues(f)
        For RDD of (K,V), mapping of Values 
        for each key, transform values by f(v):Iterable and flatening as (K,each_from_Iterable)
        >>> x = sc.parallelize([("a", ["x", "y", "z"]), ("b", ["p", "r"])])
        >>> def f(x): return x
        >>> x.flatMapValues(f).collect()
        [('a', 'x'), ('a', 'y'), ('a', 'z'), ('b', 'p'), ('b', 'r')]
    fold(zeroValue, op)
        op(U,e):U is applied with zeroValue:U , 
        note op(r,e) must be commutative, else result is not predictable
        Note op is called for each partition as well as for combining partitions 
        >>> from operator import add
        >>> sc.parallelize([1, 2, 3, 4, 5]).fold(0, add)
        15
    foldByKey(zeroValue, func, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
        For RDD of (K,V), same as above, but for same key , func(U,v):U, zeroValue:U
        returns RDD of (K,U)
        >>> rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
        >>> from operator import add
        >>> sorted(rdd.foldByKey(0, add).collect())
        [('a', 2), ('b', 1)]
    reduce(f)
        Reduces the elements of this RDD using f(r,e):r, where initial r=first value of RDD
        must be commutative and associative
        >>> from operator import add
        >>> sc.parallelize([1, 2, 3, 4, 5]).reduce(add)
        15
        >>> sc.parallelize((2 for _ in range(10))).map(lambda x: 1).cache().reduce(add)
        10
    reduceByKey(func, numPartitions=None, partitionFunc=<function portable_hash at 0x7fc35dbc8e60>)
        For RDD of (K,V), same as above, but for same key, func(r,v):r, where initial r=first value of V for a key 
        >>> from operator import add
        >>> rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
        >>> sorted(rdd.reduceByKey(add).collect())
        [('a', 2), ('b', 1)]
    reduceByKeyLocally(func)
        For RDD of (K,V), same as above, but for same key, func(r,v)
        but return the results immediately to the master as a dictionary.
        >>> from operator import add
        >>> rdd = sc.parallelize([("a", 1), ("b", 1), ("a", 1)])
        >>> sorted(rdd.reduceByKeyLocally(add).items())
        [('a', 2), ('b', 1)]
    treeReduce(f, depth=2)
        Reduces the elements of this RDD in a multi-level tree pattern.
        depth � suggested depth of the tree (default: 2) 
        >>> add = lambda x, y: x + y
        >>> rdd = sc.parallelize([-5, -4, -3, -2, -1, 1, 2, 3, 4], 10)
        >>> rdd.treeReduce(add, 2)
        -5
    sortBy(keyfunc, ascending=True, numPartitions=None)
        Sorts this RDD by the given keyfunc(e)
        >>> tmp = [('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5)]
        >>> sc.parallelize(tmp).sortBy(lambda x: x[0]).collect()
        [('1', 3), ('2', 5), ('a', 1), ('b', 2), ('d', 4)]
        >>> sc.parallelize(tmp).sortBy(lambda x: x[1]).collect()
        [('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5)]
    sortByKey(ascending=True, numPartitions=None, keyfunc=lambda x: x)
        For RDD of (K,V), sorts by keyfunc taking K and returning key for sorting 
        >>> tmp = [('a', 1), ('b', 2), ('1', 3), ('d', 4), ('2', 5)]
        >>> sc.parallelize(tmp).sortByKey().first()
        ('1', 3)
        >>> sc.parallelize(tmp).sortByKey(True, 1).collect()
        [('1', 3), ('2', 5), ('a', 1), ('b', 2), ('d', 4)]
        >>> sc.parallelize(tmp).sortByKey(True, 2).collect()
        [('1', 3), ('2', 5), ('a', 1), ('b', 2), ('d', 4)]
        >>> tmp2 = [('Mary', 1), ('had', 2), ('a', 3), ('little', 4), ('lamb', 5)]
        >>> tmp2.extend([('whose', 6), ('fleece', 7), ('was', 8), ('white', 9)])
        >>> sc.parallelize(tmp2).sortByKey(True, 3, keyfunc=lambda k: k.lower()).collect()
        [('a', 3), ('fleece', 7), ('had', 2), ('lamb', 5),...('white', 9), ('whose', 6)]
    foreach(f)
        Applies a function to all elements of this RDD.
        >>> def f(x): print(x)
        >>> sc.parallelize([1, 2, 3, 4, 5]).foreach(f)
    foreachPartition(f)
        Applies a function, f(iterator) to each partition of this RDD.
        where iterator consists of all elements in that partition
        >>> def f(iterator):
                for x in iterator:
                    print(x)
        >>> sc.parallelize([1, 2, 3, 4, 5]).foreachPartition(f)    
    getNumPartitions()
        Returns the number of partitions in RDD
        >>> rdd = sc.parallelize([1, 2, 3, 4], 2)
        >>> rdd.getNumPartitions()
        2
    histogram(buckets)
        Compute a histogram using the provided buckets. 
        buckets [1,10,20,50] means the buckets are [1,10) [10,20) [20,50], 
        buckets can also be number of buckets
        The return value is a tuple of buckets and histogram(count of elements in that bucket).
        >>> rdd = sc.parallelize(range(51))
        >>> rdd.histogram(2)
        ([0, 25, 50], [25, 26])
        >>> rdd.histogram([0, 5, 25, 50])
        ([0, 5, 25, 50], [5, 20, 26])
        >>> rdd.histogram([0, 15, 30, 45, 60])  # evenly spaced buckets
        ([0, 15, 30, 45, 60], [15, 15, 15, 6])
        >>> rdd = sc.parallelize(["ab", "ac", "b", "bd", "ef"])
        >>> rdd.histogram(("a", "b", "c"))
        (('a', 'b', 'c'), [2, 2])
    isEmpty()
        Returns true if and only if the RDD contains no elements at all.
        >>> sc.parallelize([]).isEmpty()
        True
        >>> sc.parallelize([1]).isEmpty()
        False
    name()
        Return the name of this RDD.
    setName(name)
        Assign a name to this RDD.
        >>> rdd1 = sc.parallelize([1, 2])
        >>> rdd1.setName('RDD1').name()
        u'RDD1'
    pipe(command, env=None, checkCode=False)
        Return an RDD created by piping elements to a forked external process.
        >>> sc.parallelize(['1', '2', '', '3']).pipe('cat').collect()
        [u'1', u'2', u'', u'3']
    randomSplit(weights, seed=None)
        Randomly splits this RDD with the provided weights.
        >>> rdd = sc.parallelize(range(500), 1)
        >>> rdd1, rdd2 = rdd.randomSplit([2, 3], 17)
        >>> len(rdd1.collect() + rdd2.collect())
        500
        >>> 150 < rdd1.count() < 250
        True
        >>> 250 < rdd2.count() < 350
        True
    sample(withReplacement, fraction, seed=None)
        Return a sampled subset of this RDD.
        >>> rdd = sc.parallelize(range(100), 4)
        >>> 6 <= rdd.sample(False, 0.1, 81).count() <= 14
        True
    sampleByKey(withReplacement, fractions, seed=None)
        For RDD of (K,V)
        Return a subset of this RDD sampled by key
        Create a sample of this RDD using variable sampling rates for different keys 
        as specified by fractions, a key to sampling rate map.        
        >>> fractions = {"a": 0.2, "b": 0.1} #for key a, 20%, for key b, 10% 
        >>> rdd = sc.parallelize(fractions.keys()).cartesian(sc.parallelize(range(0, 1000)))
        >>> sample = dict(rdd.sampleByKey(False, fractions, 2).groupByKey().collect())
        >>> 100 < len(sample["a"]) < 300 and 50 < len(sample["b"]) < 150
        True
        >>> max(sample["a"]) <= 999 and min(sample["a"]) >= 0
        True
        >>> max(sample["b"]) <= 999 and min(sample["b"]) >= 0
        True
    takeSample(withReplacement, num, seed=None)
        Return a fixed-size sampled subset of this RDD.
        >>> rdd = sc.parallelize(range(0, 10))
        >>> len(rdd.takeSample(True, 20, 1))
        20
        >>> len(rdd.takeSample(False, 5, 2))
        5
        >>> len(rdd.takeSample(False, 15, 3))
        10
    saveAsHadoopDataset(conf, keyConverter=None, valueConverter=None)
        Output a Python RDD of(K, V) to any Hadoop file system, 
        using the old Hadoop OutputFormat API (mapred package). 
        �conf � Hadoop job configuration, passed in as a dict
        Keys/values are converted for output using either user specified converters 
        or, by default, org.apache.spark.api.python.JavaToWritableConverter
    saveAsNewAPIHadoopDataset(conf, keyConverter=None, valueConverter=None)
        Output a Python RDD of (K, V) to any Hadoop file system, 
        using the new Hadoop OutputFormat API (mapreduce package). 
        Keys/values are converted for output using either user specified converters 
        or, by default, org.apache.spark.api.python.JavaToWritableConverter
    saveAsHadoopFile(path, outputFormatClass, keyClass=None, valueClass=None, keyConverter=None, valueConverter=None, conf=None, compressionCodecClass=None)
        Output a Python RDD of (K, V) to any Hadoop file system, 
        using the old Hadoop OutputFormat API (mapred package)
        �path � path to Hadoop file
        �outputFormatClass � fully qualified classname of Hadoop OutputFormat (e.g. 'org.apache.hadoop.mapred.SequenceFileOutputFormat')
        �keyClass � fully qualified classname of key Writable class (e.g. 'org.apache.hadoop.io.IntWritable', None by default)
        �valueClass � fully qualified classname of value Writable class (e.g. 'org.apache.hadoop.io.Text', None by default)
        �keyConverter � (None by default)
        �valueConverter � (None by default)
        �conf � (None by default)
        �compressionCodecClass � (None by default)
    saveAsNewAPIHadoopFile(path, outputFormatClass, keyClass=None, valueClass=None, keyConverter=None, valueConverter=None, conf=None)
        Output a Python RDD of (K, V) to any Hadoop file system, 
        using the new Hadoop OutputFormat API (mapreduce package)
    saveAsPickleFile(path, batchSize=10)
        Save this RDD as a SequenceFile of serialized objects. 
        >>> tmpFile = tempfile.NamedTemporaryFile(delete=True)
        >>> tmpFile.close()
        >>> sc.parallelize([1, 2, 'spark', 'rdd']).saveAsPickleFile(tmpFile.name, 3)
        >>> sorted(sc.pickleFile(tmpFile.name, 5).map(str).collect())
        ['1', '2', 'rdd', 'spark']
    saveAsSequenceFile(path, compressionCodecClass=None)
        Output a Python RDD of (K, V)
        to any Hadoop file system including local filesystem,  
        using the org.apache.hadoop.io.Writable types that we convert from the RDD's key and value types
    saveAsTextFile(path, compressionCodecClass=None)
        Save this RDD as a text file, using string representations of elements.
        �path � path to text file
        �compressionCodecClass � (None by default) string i.e. 'org.apache.hadoop.io.compress.GzipCodec'
        >>> tempFile = tempfile.NamedTemporaryFile(delete=True)
        >>> tempFile.close()
        >>> sc.parallelize(range(10)).saveAsTextFile(tempFile.name)
        >>> from fileinput import input
        >>> from glob import glob
        >>> ''.join(sorted(input(glob(tempFile.name + "/part-0000*"))))
        '0\n1\n2\n3\n4\n5\n6\n7\n8\n9\n'
    intersection(other)
        Return the intersection of this RDD and another one. 
        The output will not contain any duplicate elements, even if the input RDDs did.
        >>> rdd1 = sc.parallelize([1, 10, 2, 3, 4, 5])
        >>> rdd2 = sc.parallelize([1, 6, 2, 3, 7, 8])
        >>> rdd1.intersection(rdd2).collect()
        [1, 2, 3]
    subtract(other, numPartitions=None)
        Return each value in self that is not contained in other.
        >>> x = sc.parallelize([("a", 1), ("b", 4), ("b", 5), ("a", 3)])
        >>> y = sc.parallelize([("a", 3), ("c", None)])
        >>> sorted(x.subtract(y).collect())
        [('a', 1), ('b', 4), ('b', 5)]
    subtractByKey(other, numPartitions=None)
        For RDD of (K,V)
        Return each (key, value) pair in self that has no pair with matching key in other.
        >>> x = sc.parallelize([("a", 1), ("b", 4), ("b", 5), ("a", 2)])
        >>> y = sc.parallelize([("a", 3), ("c", None)])
        >>> sorted(x.subtractByKey(y).collect())
        [('b', 4), ('b', 5)]
    union(other)
        Return the union of this RDD and another one.
        >>> rdd = sc.parallelize([1, 1, 2, 3])
        >>> rdd.union(rdd).collect()
        [1, 1, 2, 3, 1, 1, 2, 3]
    toDebugString()
        A description of this RDD and its recursive dependencies for debugging.
    toLocalIterator()
        Return an iterator that contains all of the elements in this RDD.
        >>> rdd = sc.parallelize(range(10))
        >>> [x for x in rdd.toLocalIterator()]
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    values()
        For RDD of (K,V)
        Return an RDD with the values 
        >>> m = sc.parallelize([(1, 2), (3, 4)]).values()
        >>> m.collect()
        [2, 4]
    keys()
        For RDD of (K,V)
        Return an RDD with the keys of each tuple.
        >>> m = sc.parallelize([(1, 2), (3, 4)]).keys()
        >>> m.collect()
        [1, 3]
    lookup(key)
        For RDD of (K,V)
        Return the list of values in the RDD for key key.
        >>> l = range(1000)
        >>> rdd = sc.parallelize(zip(l, l), 10)
        >>> rdd.lookup(42)  # slow
        [42]
        >>> sorted = rdd.sortByKey()
        >>> sorted.lookup(42)  # fast
        [42]
        >>> sorted.lookup(1024)
        []
        >>> rdd2 = sc.parallelize([(('a', 'b'), 'c')]).groupByKey()
        >>> list(rdd2.lookup(('a', 'b'))[0])
        ['c']
    zip(other)
        Zips this RDD with another one, Returns RDD of (E1,E2)
        >>> x = sc.parallelize(range(0,5))
        >>> y = sc.parallelize(range(1000, 1005))
        >>> x.zip(y).collect()
        [(0, 1000), (1, 1001), (2, 1002), (3, 1003), (4, 1004)]
    zipWithIndex()
        Zips this RDD with its element indices ie (e,index)
        first item in the first partition gets index 0, 
        and the last item in the last partition receives the largest index.
        >>> sc.parallelize(["a", "b", "c", "d"], 3).zipWithIndex().collect()
        [('a', 0), ('b', 1), ('c', 2), ('d', 3)]
    zipWithUniqueId()
        Zips this RDD with generated unique Long ids ie (e, id)
        Items in the kth partition will get ids k, n+k, 2*n+k, ..., 
        where n is the number of partitions. 
        >>> sc.parallelize(["a", "b", "c", "d", "e"], 3).zipWithUniqueId().collect()
        [('a', 0), ('b', 1), ('c', 4), ('d', 2), ('e', 5)]
    isCheckpointed()
        Return whether this RDD is checkpointed
    localCheckpoint()
        Mark this RDD for local checkpointing using Spark's existing caching layer.
    getCheckpointFile()
        Gets the name of the file to which this RDD was checkpointed
        Not defined if RDD is checkpointed locally.
    checkpoint()
        Mark this RDD for checkpointing via SparkContext.setCheckpointDir() 

        
        


    
###RDD -  Shared variables(broadcast and accumulators) 
#By default, when Spark runs a function in parallel as a set of tasks on different nodes, 
#it ships a copy of each variable used in the function to each task
#Hence direct sharing of global variables not possible 
broadcast variables 
    Immutable global like varaible , to cache a value in memory on all nodes, 
    Use it to share large data only once between driver and executors imporving performance 
accumulators        
    Mutable shared variables that are only 'added' to, such as counters and sums.
    Executors can only operate on them, Driver can only view the result 


##Spark - RDD - Mutating variables 
#RDD operations that MODIFY variables outside of their scope - WRONG, 
#Use accumulators


#WRONG Usage - this might work in local mode, but fails in other 
counter = 0
rdd = sc.parallelize(data)

# Wrong: Donot do this!!
def increment_counter(x):
    global counter
    counter += x
rdd.foreach(increment_counter)

print("Counter value: ", counter)


##Spark - RDD - Shared Variables - Accumulators
class pyspark.Accumulator(aid, value, accum_param)
    A shared variable that can be accumulated, 
    i.e., has a commutative and associative 'add' operation. 
    Worker tasks on a Spark cluster can add values to an Accumulator with the += operator, 
    but only the driver program is allowed to access its value, using value. 
        add(term)
            Adds a term to this accumulator's value
        value
            Get the accumulator's value; only usable in driver program

 
#Spark natively supports accumulators of numeric types, 
#and programmers can add support for new types.
accum = sc.accumulator(0) #Driver
sc.parallelize([1, 2, 3, 4]).foreach(lambda x: accum.add(x)) #Executor
accum.value  #10  #Driver 



##User defined accumulator 
#The AccumulatorParam interface has two methods: zero for providing a 'zero value' for your data type, 
#and addInPlace for adding two values together

#Example - handling vectors as accumulator 
from pyspark.util import AccumulatorParam
from pyspark.mllib.linalg import Vectors 
class VectorAccumulatorParam(AccumulatorParam):
    def zero(self, initialValue):
        return Vectors.zeros(initialValue.size)
    def addInPlace(self, v1, v2):
        v1 += v2
        return v1

# Then, create an Accumulator of this type:
vecAccum = sc.accumulator(Vectors.dense([1.0, 2.0]), VectorAccumulatorParam())#Driver
sc.parallelize([1, 2, 3, 4]).foreach(lambda x: vecAccum.add([x,x])) #Executor
vecAccum.value    #Driver 




##Spark - RDD - Shared Variables - Broadcast Variables

class pyspark.Broadcast(sc=None, value=None, pickle_registry=None, path=None)
    Broadcast variables allow the programmer to keep a read-only variable cached 
    on each machine rather than shipping a copy of it with tasks. 
    Once created by Driver, 
    it can  be used(.value) in any functions that run on the cluster 
    destroy()
        Destroy all data and metadata related to this broadcast variable. 
    dump(value, f)
    load(path)
    unpersist(blocking=False)
    value
        Return the broadcasted value
    
    

            
#Example 
>>> from pyspark.context import SparkContext
>>> sc = SparkContext('local', 'test')
>>> b = sc.broadcast([1, 2, 3, 4, 5])
>>> b.value
[1, 2, 3, 4, 5]
>>> sc.parallelize([0, 0]).flatMap(lambda x: b.value).collect()
[1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
>>> b.unpersist()
>>> large_broadcast = sc.broadcast(range(10000))






###Spark - RDD - Persistence

#You can mark an RDD to be persisted using the persist() or cache() 
#The first time it is computed in an action, it will be kept in memory on the nodes imporving performance for next operations 

#The cache() method is a shorthand for using the default storage level, which is StorageLevel.MEMORY_ONLY 

#Spark automatically monitors cache usage on each node 
#and drops out old data partitions in a least-recently-used (LRU) fashion. 
#OR use the RDD.unpersist() method.

#StorageLevel describes how an RDD is persisted (and addresses the following concerns):
    1.Does RDD use disk?
    2.How much of RDD is in memory?
    3.Does RDD use off-heap memory?
    4.Should an RDD be serialized (while persisting)?
    5.How many replicas (default: 1) to use (can only be less than 40)?

#Example 
lines = sc.textFile("README.md")
>>> lines.getStorageLevel()
res0: org.apache.spark.storage.StorageLevel = StorageLevel(disk=false, memory=false, offheap=..)

#To have replica more than 2 use directly 
StorageLevel(useDisk, useMemory, useOffHeap, deserialized, replication=1):
eg 
MEMORY_AND_DISK_20 = StorageLevel(True, True, False, False, 20)


#There are the following StorageLevel (number _2 in the name denotes 2 replicas):
MEMORY_ONLY         
    Store RDD as deserialized Java objects in the JVM. If the RDD does not fit in memory, 
    some partitions will not be cached and will be recomputed on the fly each time they are needed. 
    This is the default level.  
MEMORY_AND_DISK     
    Store RDD as deserialized Java objects in the JVM. 
    If the RDD does not fit in memory, store the partitions that dont fit on disk, 
    and read them from there when theyre needed.  
MEMORY_ONLY_SER     
    (Java and Scala)  Store RDD as serialized Java objects (one byte array per partition). 
    This is generally more space-efficient than deserialized objects, especially 
    when using a fast serializer, but more CPU-intensive to read.  
MEMORY_AND_DISK_SER 
    (Java and Scala)  Similar to MEMORY_ONLY_SER, but spill partitions that dont fit in memory 
    to disk instead of recomputing them on the fly each time they re needed.  
DISK_ONLY           
    Store the RDD partitions only on disk.  
MEMORY_ONLY_2, MEMORY_AND_DISK_2, etc.  
    Same as the levels above, but replicate each partition on two cluster nodes.  
OFF_HEAP (experimental)     
    Similar to MEMORY_ONLY_SER, but store the data in off-heap memory. 
    This requires off-heap memory to be enabled.  
    
#Note in python :: since the records will always be serialized in Python.
StorageLevel.MEMORY_ONLY_SER = StorageLevel.MEMORY_ONLY
StorageLevel.MEMORY_ONLY_SER_2 = StorageLevel.MEMORY_ONLY_2
StorageLevel.MEMORY_AND_DISK_SER = StorageLevel.MEMORY_AND_DISK
StorageLevel.MEMORY_AND_DISK_SER_2 = StorageLevel.MEMORY_AND_DISK_2


##Which Storage Level to Choose
�If your RDDs fit comfortably with the default storage level (MEMORY_ONLY), leave them that way. 
 This is the most CPU-efficient option, allowing operations on the RDDs to run as fast as possible.

�If not, try using MEMORY_ONLY_SER and selecting a fast serialization library to make the objects much more space-efficient, 
 but still reasonably fast to access. (Java and Scala)

�Don�t spill to disk unless the functions that computed your datasets are expensive, 
 or they filter a large amount of the data. 
 Otherwise, recomputing a partition may be as fast as reading it from disk.

�Use the replicated storage levels if you want fast fault recovery 
 (e.g. if using Spark to serve requests from a web application). 
 All the storage levels provide full fault tolerance by recomputing lost data, 
 but the replicated ones let you continue running tasks on the RDD without waiting to recompute a lost partition.

#Reference, Note  replication<40
class pyspark.StorageLevel(useDisk, useMemory, useOffHeap, deserialized, replication=1)
    DISK_ONLY = StorageLevel(True, False, False, False, 1)
    DISK_ONLY_2 = StorageLevel(True, False, False, False, 2)
    MEMORY_AND_DISK = StorageLevel(True, True, False, False, 1)
    MEMORY_AND_DISK_2 = StorageLevel(True, True, False, False, 2)
    MEMORY_AND_DISK_SER = StorageLevel(True, True, False, False, 1)
    MEMORY_AND_DISK_SER_2 = StorageLevel(True, True, False, False, 2)
    MEMORY_ONLY = StorageLevel(False, True, False, False, 1)
    MEMORY_ONLY_2 = StorageLevel(False, True, False, False, 2)
    MEMORY_ONLY_SER = StorageLevel(False, True, False, False, 1)
    MEMORY_ONLY_SER_2 = StorageLevel(False, True, False, False, 2)
    OFF_HEAP = StorageLevel(True, True, True, False, 1)


    
    
    

###*** Iris Examples 
lines = sc.textFile("./data/iris.csv", 8)

lines.getNumPartitions()
sc.defaultParallelism
lines.coalesce(4) #returns new 

lines.glom().collect()

##take 
lines.take(5) 

##count 
lines.count() 

##remove header 

iris = sc.textFile(r'.\data\spark\iris.csv', 8)
iris1 = iris.zipWithIndex().filter(lambda t : t[1] != 0).map(lambda t : t[0].split(','))

iris2 = iris1.map(lambda t : (t[-1],list(map(float, t[:-1]))))

##parition based on Name 
uniqueName = iris2.groupByKey().keys().collect()
def part(k, lst):
    return lst.index(k)

iris3 = iris2.groupByKey(3, lambda k : part(k,uniqueName)) 

>>> iris3.glom().take(3)
[[('Iris-setosa', <pyspark.resultiterable.ResultIterable object at 0x0000003FFF5A0F60>)], 
[('Iris-virginica', <pyspark.resultiterable.ResultIterable object at 0x0000003FFF596EF0>)], 
[('Iris-versicolor', <pyspark.resultiterable.ResultIterable object at 0x0000003FFF596DA0>)]]

>>> iris3.first()
('Iris-setosa', <pyspark.resultiterable.ResultIterable object at 0x0000003FFF596748>)
[[5.1, 3.5, 1.4, 0.2], [4.9, 3.0, 1.4, 0.2],...]

#preserve key and partitioning 
#iterator contains only one element (as partition contains one element)
def func(it, which=0):
    lst = list(it)[0]
    #print(lst)
    #must return a iterator  for that partition
    return [(lst[0], [e[which] for e in lst[1]]), ]


iris4 = iris3.mapPartitions(lambda it : func(it,0), True)
iris5 = iris4.map(lambda t : (t[0], {'max': np.amax(t[1])}))   


sc.stop() 


###*** HandsOn RDD - 
#Open device.txt 
#eventTime,deviceId,signal 

Q1. Count of unique deviceId and count by each deviceId 

Q2. Parition based on DeviceId and get all signals and size 

Q3.Find deviceId and it's signal between 2017-08-23T00:00:00.002Z - 2017-08-23T00:10:00.002Z 


Q4. Find all Device IDs between 10 min windows    
    

    
##Ans: 
lines = sc.textFile("./data/spark/device.txt")

#Q1. Count of deviceId 
from dateutil.parser import parse 
rows = lines.map(lambda l:l.split(',')).map(lambda r: (parse(r[0]),r[1],int(r[2])))
kv_rows = rows.keyBy(lambda r: r[1])  #('mine', (datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), 'mine', 20))

unq = kv_rows.map(lambda t:t[0]).distinct().collect()
#['yours', 'his', 'mine']
kv_rows.map(lambda t:t[0]).distinct().count()


kv_rows.countByKey().items()
#dict_items([('yours', 6), ('his', 6), ('mine', 6)])




Q2. Parition based on DeviceId and get all signals and size 
def part(k, lst):
    return lst.index(k) % len(lst)
    
kv = rows.groupBy(lambda r: r[1], 3, lambda k: part(k,unq)) #('yours', Iterable)
kv.getNumPartitions()
kv.keys().collect()

def partFunc1(itr):
    lst = list(itr)[0] #single value , [(key, itr)]
    value = [ r[-1] for r in lst[1]]
    return [ (lst[0], value, len(value))  ] #keep the key , must return iter 

kv.mapPartitions(partFunc1).collect() 



Q3.Find deviceId and it's signal between 2017-08-23T00:00:00.002Z - 2017-08-23T00:10:00.002Z 
start = parse('2017-08-23T00:00:00.002Z')
end = parse('2017-08-23T00:10:00.002Z')

def partFunc2(itr, start=start,end=end):
    lst = list(itr)[0] #single value , [(key, itr)]
    value = [ r[-1] for r in lst[1] if start < r[0] < end]
    return [ (lst[0], value, len(value))  ] #keep the key , must return iter 

kv.mapPartitions(partFunc2).collect() 





Q4. Find all Device IDs between 10 min windows    
#get max and min in each partitions
def partFunc3(itr):
    lst = list(itr)[0] #single value , [(key, itr)]
    value = [ r[0] for r in lst[1]]
    return [ (lst[0], max(value), min(value))  ] #keep the key , must return iter 

#get all max and min 
#Note fold does not work as there is no combine op 
>>> kv.mapPartitions(partFunc3).fold([], lambda r,t: (print(t),r+[t[1],t[-1]])[-1])
('yours',datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8,23, 0, 0, 0, 2000, tzinfo=tzutc()))
('mine', datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()))
('his', datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()))
#then again call SeqOp for all outputs 
[datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]
[datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]
[datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]
#Then result , last values are repeated 
[datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]

>>> kv.mapPartitions(partFunc3).aggregate([], lambda r,t:(print(r,t),r+[*t[1:]])[-1], lambda r,l: (print(r,l),r+l)[-1])
[] ('his', datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()))
[] ('mine', datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()))
[] ('yours', datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()))
[] [datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]
[datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())] [datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]
[datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())] [datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]
[datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 1, 0, 0, 2000, tzinfo=tzutc()), datetime.datetime(2017, 8, 23, 0, 0, 0, 2000, tzinfo=tzutc())]


ds = kv.mapPartitions(partFunc3).aggregate([], lambda r,t:r+[*t[1:]], lambda r,l: r+l)

min_d = min(ds)
max_d = max(ds)
delta = datetime.timedelta(minutes=10)
n = (max_d - min_d)//delta
bins = []
for i in range(n):
    bins.append([min_d+i*delta, min_d+(1+i)*delta])

#lst bin 
bins.append([min_d+n*delta, max_d+delta]) #for anything beyond 
#put exact bin number 
def by(r, bins=bins):
    for i, (st,en) in enumerate(bins):
        if st <= r[0] < en:
            return i


date_kv = rows.groupBy(lambda r:by(r), len(bins)+1, lambda k: k) #('yours', Iterable)

>>> date_kv.glom().collect()
[[(0, <pyspark.resultiterable.ResultIterable object at 0x000000B0B98F8EF0>)], [(1, <pyspar
k.resultiterable.ResultIterable object at 0x000000B0B98F8BA8>)], [], [], [(4, <pyspark.res
ultiterable.ResultIterable object at 0x000000B0B98F8D30>)], [], [(6, <pyspark.resultiterab
le.ResultIterable object at 0x000000B0B98F4470>)], []]


#flatten it now , but some partition might be empty as no deviceId in that group 
def partFunc4(it, bins):
    itr = list(it)  #single pass
    if len(itr) < 1 :
        return []
    lst = itr[0] #single value , [(key, itr)]
    n = lst[0] 
    v = [ (r[0],r[1],r[2]) for r in lst[1]]
    res = [ (n, (v, bins[n]) )  ] #keep the key , must return iter 
    return res 

res = date_kv.mapPartitions(lambda itr: partFunc4(itr,bins))#[(0, ([ tuples_of_row], [st,end]) )]

#Find all Device IDs now 
def partFunc5(it):
    itr = list(it)  #single pass
    if len(itr) < 1 :
        return []
    lst = itr[0] #single value , (n, (v, bins[n]) ) 
    v = [ r[1] for r in lst[1][0]]
    res = [ (lst[1][-1],v) ] # must return iter 
    return res 
    

res.mapPartitions(partFunc5).collect()



@@@
###+++ Spark SQL: Structured Data Processing with Relational Queries on Massive Scale

#The primary difference between the computation models of Spark SQL and Spark Core is the relational framework 
#for ingesting, querying and persisting (semi)structured data using structured queries 
#that can be expressed using SQL (with many features of HiveQL) 
#and the high-level SQL-like functional declarative type-safe Structured Query DSL.


#Whichever query interface you use to describe a structured query, i.e. SQL or Query DSL, 
#the query becomes a DataFrame


#Internally, a structured query is a Catalyst tree of (logical and physical) relational operators and expressions.

#When an action is executed on a Dataset 
#(directly, e.g. show or count, or indirectly, e.g. save or saveAsTable) 
#the structured query (behind Dataset) goes through the execution stages:
    Logical Analysis
    Caching Replacement
    Logical Query Optimization (using rule-based and cost-based optimizations)
            check 
                https://jaceklaskowski.gitbooks.io/mastering-spark-sql/spark-sql-SparkOptimizer.html
                https://jaceklaskowski.gitbooks.io/mastering-spark-sql/spark-sql-Optimizer.html
    Physical Planning
    Physical Optimization (e.g. Whole-Stage Java Code Generation or Adaptive Query Execution)
    Constructing the RDD of Internal Binary Rows (that represents the structured query in terms of Spark Core�s RDD API)
    
#Under the covers, structured queries are automatically compiled into corresponding RDD operations.

#Spark SQL supports structured queries in batch and streaming mode


#Spark SQL configuration is available through the user-facing interface RuntimeConfig 
#that you can access using SparkSession.
>>> spark.version
#2.3.0

>>>type(spark.conf)
<class 'pyspark.sql.conf.RuntimeConfig'>

#RuntimeConfig 
get(self, key, default=None)
    Returns the value of Spark runtime configuration property for the given key,assuming it is set.
set(self, key, value)
    Sets the given Spark runtime configuration property.
unset(self, key)
    Resets the configuration property for the given key.


##Catalog is used to access all SQL tables, functions etc 
>>> spark.catalog.listTables()
[Table(name='boxes', database='default', description=None, tableType='EXTERNAL', isTemporary=False),
 Table(name='rectangles', database='default', description=None, tableType='EXTERNAL', isTemporary=False), 
 Table(name='v1', database=None, description=None, tableType='TEMPORARY', isTemporary=True)]

>>> spark.catalog.listFunctions() #267 functions which can be used in SQL or in DSL 
[Function(name='!', description=None, className='org.apache.spark.sql.catalyst.expressions.Not', isTemporary=True), 
...]
>>> spark.catalog.listFunctions()[0].name
'!'

##scala - reference , same as in PY, but no datatype 
class Catalog extends AnyRef
    	    Catalog interface for Spark. To access this, use SparkSession.catalog.
    def cacheTable(tableName: String): Unit
    	    Caches the specified table in-memory.
    def clearCache(): Unit
    	    Removes all cached tables from the in-memory cache.
    def createTable(tableName: String, source: String, schema: StructType, options: Map[String, String]): DataFrame
    	    Create a table based on the dataset in a data source, a schema and a set of options.
    def createTable(tableName: String, source: String, options: Map[String, String]): DataFrame
    	    Creates a table based on the dataset in a data source and a set of options.
    def createTable(tableName: String, path: String, source: String): DataFrame
    	    Creates a table from the given path based on a data source and returns the corresponding DataFrame.
    def createTable(tableName: String, path: String): DataFrame
    	    Creates a table from the given path and returns the corresponding DataFrame.
    def currentDatabase: String
    	    Returns the current default database in this session.
    def databaseExists(dbName: String): Boolean
    	    Check if the database with the specified name exists.
    def dropGlobalTempView(viewName: String): Boolean
    	    Drops the global temporary view with the given view name in the catalog.
    def dropTempView(viewName: String): Boolean
    	    Drops the local temporary view with the given view name in the catalog.
    def functionExists(dbName: String, functionName: String): Boolean
    	    Check if the function with the specified name exists in the specified database.
    def functionExists(functionName: String): Boolean
    	    Check if the function with the specified name exists.
    def getDatabase(dbName: String): Database
    	    Get the database with the specified name.
    def getFunction(dbName: String, functionName: String): Function
    	    Get the function with the specified name.
    def getFunction(functionName: String): Function
    	    Get the function with the specified name.
    def getTable(dbName: String, tableName: String): Table
    	    Get the table or view with the specified name in the specified database.
    def getTable(tableName: String): Table
    	    Get the table or view with the specified name.
    def isCached(tableName: String): Boolean
    	    Returns true if the table is currently cached in-memory.
    def listColumns(dbName: String, tableName: String): Dataset[Column]
    	    Returns a list of columns for the given table/view in the specified database.
    def listColumns(tableName: String): Dataset[Column]
    	    Returns a list of columns for the given table/view or temporary view.
    def listDatabases(): Dataset[Database]
    	    Returns a list of databases available across all sessions.
    def listFunctions(dbName: String): Dataset[Function]
    	    Returns a list of functions registered in the specified database.
    def listFunctions(): Dataset[Function]
    	    Returns a list of functions registered in the current database.
    def listTables(dbName: String): Dataset[Table]
    	    Returns a list of tables/views in the specified database.
    def listTables(): Dataset[Table]
    	    Returns a list of tables/views in the current database.
    def recoverPartitions(tableName: String): Unit
    	    Recovers all the partitions in the directory of a table and update the catalog.
    def refreshByPath(path: String): Unit
    	    Invalidates and refreshes all the cached data (and the associated metadata) for any Dataset that contains the given data source path.
    def refreshTable(tableName: String): Unit
    	    Invalidates and refreshes all the cached data and metadata of the given table.
    def setCurrentDatabase(dbName: String): Unit
    	    Sets the current default database in this session.
    def tableExists(dbName: String, tableName: String): Boolean
    	    Check if the table or view with the specified name exists in the specified database.
    def tableExists(tableName: String): Boolean
    	    Check if the table or view with the specified name exists.
    def uncacheTable(tableName: String): Unit
    	    Removes the specified table from the in-memory cache.

            
            

###Logging
#Spark uses log4j for logging.
#The valid logging levels are log4j�s Levels (from most specific to least):
    OFF (most specific, no logging)
    FATAL (most specific, little data)
    ERROR
    WARN
    INFO
    DEBUG
    TRACE (least specific, a lot of data)
    ALL (least specific, all data)



#You can set up the default logging for Spark shell in conf/log4j.properties. 
#Use conf/log4j.properties.template as a starting point.


###Setting Log Levels in Spark Applications
#In standalone Spark applications or while in Spark Shell session, use the following:

import org.apache.log4j.{Level, Logger}

Logger.getLogger(classOf[RackResolver]).getLevel
Logger.getLogger("org").setLevel(Level.OFF)
Logger.getLogger("akka").setLevel(Level.OFF)


###Disabling Logging
#Use the following conf/log4j.properties to disable logging completely:
log4j.logger.org=OFF




###+++ Spark - DataFrames

#A DataFrame is a dataset organized into named columns(like pandas.DataFrame)
#ie a 2D struture of ROW x Column, Columns are called features and rows are observations

###Spark - DataFrames - pyspark.sql module 
�pyspark.sql.SparkSession   Main entry point for DataFrame and SQL functionality.
�pyspark.sql.DataFrame      A distributed collection of data grouped into named columns.
�pyspark.sql.Column         A column expression in a DataFrame.
�pyspark.sql.Row            A row of data in a DataFrame.
�pyspark.sql.GroupedData    Aggregation methods, returned by DataFrame.groupBy().

�pyspark.sql.DataFrameNaFunctions       Methods for handling missing data (null values).
�pyspark.sql.DataFrameStatFunctions     Methods for statistics functionality.
�pyspark.sql.functions                  List of built-in functions available for DataFrame.
�pyspark.sql.types                      List of data types available.
�pyspark.sql.Window                     For working with window functions.


###Spark - DataFrames - SparkSession 

#As of Spark 2.0, SQLContext is replaced by SparkSession
from pyspark.sql import SparkSession

spark = SparkSession \
    .builder \
    .appName("Python Spark SQL basic example") \
    .config("spark.some.config.option", "some-value") \
    .getOrCreate()
#Example 
warehouseLocation = "file:${system:user.dir}/spark-warehouse" 
spark = SparkSession 
 .builder
 .appName("SparkSessionZipsExample") 
 .config("spark.sql.warehouse.dir", warehouseLocation) 
 .enableHiveSupport() 
 .getOrCreate() 

    
    
##Spark - DataFrames - NaN Semantics
#There is specially handling for not-a-number (NaN) when dealing with float or double types 
#that does not exactly match standard floating point semantics. 
�NaN = NaN returns true.
�In aggregations all NaN values are grouped together.
�NaN is treated as a normal value in join keys.
�NaN values go last when in ascending order, larger than any other numeric value.


##Spark - DataFrames - Using Row 
#A row in DataFrame 
#The fields in it can be accessed:
#like attributes (row.key),like dictionary values (row[key]) or by row[Index]
#For missing named argument,  explicitly set to None 

from pyspark.sql import * 
>>> Row.__mro__
(<class 'pyspark.sql.types.Row'>, <class 'tuple'>, <class 'object'>)
#for creation , **kargs style is must 
>>> row = Row(name="Alice", age=11)
>>> row
Row(age=11, name='Alice')
>>> row['name'], row['age']
('Alice', 11)
>>> row.name, row.age
('Alice', 11)
>>> 'name' in row
True
>>> 'wrong_key' in row
False

#Row also can be used to create another Row like class, 
#then it could be used to create Row objects
>>> Person = Row("name", "age")
>>> Person
<Row(name, age)>
>>> 'name' in Person
True
>>> 'wrong_key' in Person
False
>>> Person("Alice", 11)
Row(name='Alice', age=11)


#Methods 
asDict(recursive=False)
    Return as an dict
    Parameters:
        recursive � turns the nested Row as dict (default: False). 


>>> Row(name="Alice", age=11).asDict() == {'name': 'Alice', 'age': 11}
True
>>> row = Row(key=1, value=Row(name='a', age=2))
>>> row.asDict() == {'key': 1, 'value': Row(age=2, name='a')}
True
>>> row.asDict(True) == {'key': 1, 'value': {'name': 'a', 'age': 2}}
True


###Spark - DataFrame - DF to rdd 
df.rdd 
#Note DF does not have map, reduce functions,
#DF has filter function which takes string of SQL expression or col expression 
#has foreach(f), foreachPartition(f) functions which takes Row and Iterator of Row 

#To use map on DF, either use  builtin sql.functions or use custom UDF (which takes each element of an column )
#or use (not possible on streaming DF)
df.rdd.map(lambda row : ...) 
#or use pandas_udf, SCALAR = takes Column as pandas.Series and outputs pandas.Series
#GROUPED_MAP, takes  Dataframe as pandas.DataFrame and outputs pandas.DataFrame

# any RDD methods eg aggregate(zeroValue, seqOp, combOp), fold(zeroValue, op), flatMap(f) can be used 
df.rdd.filter(lambda row : ...) 
df.rdd.reduce(lambda r,row : ...) 
#Note Row can only be accessed by 
# attributes (row.key), dictionary values (row[key]), or by row[Index]
#and has 'in' operator for checking key in Row
#For missing named argument,  explicitly set to None 



###Spark - DataFrame - Conversion from RDDs
#Spark SQL supports two different methods for converting existing RDDs into DataFrame
RDD.toDF(schema=None, sampleRatio=None)   
SparkSession.createDataFrame(data, schema=None, samplingRatio=None, verifySchema=True)
    schema: 
        a pyspark.sql.types.StructType 
        eg StructType([StructField("name", StringType(), True),StructField("age", IntegerType(), True)])
        or list of names of Columns eg ['name', 'age']
        or string of datatype eg "name: string, age: int"
DataFrame.toDF([cols])
    Returns a new class:DataFrame that with new specified list of column names

#METHOD-1 : Infer the schema
from pyspark.sql import Row
#row = Michael, 29
parts = spark.sparkContext.textFile(r"D:\Desktop\PPT\spark\data\people.txt").map(lambda l: l.split(","))
#[['Michael', ' 29'], ['Andy', ' 30'], ['Justin', ' 19']]
people = parts.map(lambda p: Row(name=p[0], age=int(p[1]))).toDF()
>>> people  #column name comes from Row 
DataFrame[age: bigint, name: string]
#Another example 
rdd = sc.parallelize(
        [Row(field1=1, field2="row1"),
         Row(field1=2, field2="row2"),
         Row(field1=3, field2="row3")])
df = rdd.toDF()

#METHOD-2: Programmatically Specifying the Schema
#another way , load the file 
sc = spark.sparkContext
lines = sc.textFile(r"D:\Desktop\PPT\spark\data\people.txt")
parts = lines.map(lambda l: l.split(","))
people = parts.map(lambda p: (p[0], p[1].strip())) #RDD[tuples)]

# The schema is encoded in a string.
schemaString = "name age"
fields = [StructField(field_name, StringType(), True) for field_name in schemaString.split()]
schema = StructType(fields)

# Apply the schema to the RDD.
peopleDF = spark.createDataFrame(people, schema)
#or 
peopleDF =  people.toDF(schema)  
#or 
peopleDF =  people.toDF(["name", "age"])  



###Spark - DataFrame - Creation of DF - With a SparkSession, 
#applications can create DataFrames from an existing RDD(of Row), or list of Row/namedtuple/dict  
#from a Hive table, or from Spark data sources, pandas.Dataframe, dict etc 

SparkSession.createDataFrame(data, schema=None, samplingRatio=None, verifySchema=True)
    When schema is a list of column names,the type of each column will be inferred from data.
    
    When schema is None, infer the schema (column names and types) from data, 
    which must be an RDD or list of Row/namedtuple/dict
    (each row is one Row or named tuple or one Dict,  dict key is columnName, dict value is value )
 
    When schema is pyspark.sql.types.DataType or a datatype string, it must match the real data, 
    If the given schema is not pyspark.sql.types.StructType(eg other DataType), 
    it will be wrapped into a pyspark.sql.types.StructType as its only field(named as 'value') 
    and each record will also be wrapped into a tuple, which can be converted to row later.
    
    �data � an RDD of any kind of SQL data representation(e.g. row, tuple, int, boolean, etc.), 
        or list of tuples(each row as one tuple), or list of dict(each row as one dict )
        or pandas.DataFrame
    �schema � a pyspark.sql.types.DataType  or a datatype string or a list of column names
         default is None. 
         The data type string format equals to pyspark.sql.types.DataType.simpleString, 
         except that top level struct type can omit the struct<> 
         and atomic types use typeName() as their format, 
         e.g. use byte instead of tinyint for pyspark.sql.types.ByteType. 
         We can also use int as a short name for IntegerType.
    �samplingRatio � the sample ratio of rows used for inferring
    �verifySchema � verify data types of every row against schema.

#Creation from pandas ,  
#Pandas DF take dict - Key is column name and value is list of all values of that column 
#or 2D numpy.ndarray or list of list(each list is one row), then provide names via columns 
>>> import pandas as pd
>>> df2 = pd.DataFrame(np.random.randint(low=0, high=10, size=(5, 5)),columns=['a', 'b', 'c', 'd', 'e'])
>>> pd_df = pd.DataFrame({'a':[1,2,3,4], "b":[5,6,7,8]})        
>>> pd_df
   a  b
0  1  5
1  2  6
2  3  7
3  4  8
>>> spark.createDataFrame(pd_df)
DataFrame[a: bigint, b: bigint]
>>> spark.createDataFrame(pd_df).show()
+---+---+
|  a|  b|
+---+---+
|  1|  5|
|  2|  6|
|  3|  7|
|  4|  8|
+---+---+
#to pandas 
spark.createDataFrame(pd_df.toPandas()).collect()   

# Creation from List of tuples , each tuple is one row
langPercentDF = spark.createDataFrame([("Scala", 35), ("Python", 30), ("R", 15), ("Java", 20)])
>>> langPercentDF
DataFrame[_1: string, _2: bigint]
#rename the columns
lpDF = langPercentDF.withColumnRenamed("_1", "language").withColumnRenamed("_2", "percent")
#or 
langPercentDF = spark.createDataFrame([("Scala", 35), ("Python", 30), ("R", 15), ("Java", 20)], schema=['language','percent'])
#order the DataFrame in descending order of percentage
lpDF.orderBy(desc("percent")).show(false)
 
#Creation from list of tuples( each tuple is for one row ), Schema = list of column names 
l = [('Alice', 1)]
spark.createDataFrame(l).collect()  #[Row(_1=u'Alice', _2=1)]
spark.createDataFrame(l, ['name', 'age']).collect()   ##[Row(name=u'Alice', age=1)]

#from list of dicts( each dict is for one row ), column names come from dict key 
d = [{'name': 'Alice', 'age': 1}]
spark.createDataFrame(d).collect()  #[Row(age=1, name=u'Alice')]

#from RDD of  tuples, Schema = list of column names 
rdd = sc.parallelize([('Alice', 1)])
spark.createDataFrame(rdd).collect() #[Row(_1=u'Alice', _2=1)]
df = spark.createDataFrame(rdd, ['name', 'age']) 
df.collect() #[Row(name=u'Alice', age=1)]
df.printSchema()
df.show()

#from RDD of  tuples, Schema =  explicit schema 
#Note Column type/value could be Simple type or another complex type 
#ie cell value could be a Array, a Dict/map or structtype or combination 
#sql.functions have many methods which work on cellvalue as array, map or another struct type 
#note metadata is additional info that can be attached to a column 
ArrayType(elementType, containsNull=True)
MapType(keyType, valueType, valueContainsNull=True)
StructField(name, dataType, nullable=True, metadata=None)
StructType(fields=None) with add(field, data_type=None, nullable=True, metadata=None)
#Example 
from pyspark.sql.types import *
schema = StructType([
    StructField("name", StringType(), True),
    StructField("age", IntegerType(), True)])
#or Use 
schema = StructType().add("name", StringType(), True).add("age", IntegerType(), True, None)
rdd = sc.parallelize([('Alice', 1)])
df3 = spark.createDataFrame(rdd, schema)
df3.collect()  #[Row(name=u'Alice', age=1)]


#from RDD of  tuples, Schema =  With schema as string 
StructType      "struct<field_name:field_type,...>"  or "field_name:field_type, .."
MapType         "map<k_type_string, v_type_string>"
ArrayType       "array<element_type>"
#Note StructType(fields) represent a Row.
rdd = sc.parallelize([('Alice', 1)])
spark.createDataFrame(rdd, "a: string, b: int").collect()  #[Row(a=u'Alice', b=1)]

#from RDD of  Row, Schema =  None,so infer 
from pyspark.sql import Row
Person = Row('name', 'age')
rdd = sc.parallelize([('Alice', 1)])
person = rdd.map(lambda r: Person(*r))
df2 = spark.createDataFrame(person)
df2.collect()  #[Row(name=u'Alice', age=1)]

#schema is not pyspark.sql.types.StructType
rdd = sc.parallelize([('Alice', "1")])
>>> df = spark.createDataFrame(rdd, ArrayType(StringType()) ) #DataFrame[value: array<string>]
DataFrame[value: string]
>>> df.show()
+----------+
|     value|
+----------+
|[Alice, 1]|
+----------+
>>> df.value.getItem(1).astype("int")
Column<b'CAST(value[1] AS INT)'>
>>> df.select(df.value.getItem(1).astype("int"))
DataFrame[CAST(value[1] AS INT): int]
>>> df.select(df.value.getItem(1).astype("int")).show()
+---------------------+
|CAST(value[1] AS INT)|
+---------------------+
|                    1|
+---------------------+


#column is ArrayType and MapType and StructType
data = [ ("name", [10,20], {'age':30}, Row(a=1,b-2)) ]
df = spark.createDataFrame(data) #DataFrame[_1: string, _2: array<bigint>, _3: map<string,bigint>, _4: struct<a:bigint,b:bigint>]
>>> df.select("_1", col("_2").getItem(0).alias("first"), col("_3").getItem("age"),col("_4").getField("a"))
#DataFrame[_1: string, first: bigint, _3[age]: bigint, _4.a: bigint]
+----+-----+-------+----+
|  _1|_2[0]|_3[age]|_4.a|
+----+-----+-------+----+
|name|   10|     30|   1|
+----+-----+-------+----+
#alternate syntax 
>>> df.select("_1", col("_2")[0].alias("first"), col("_3")["age"],df._4.getField("a"))



# accepatble Python types for  Spark SQL DataType
_acceptable_types = {
    BooleanType: (bool,),
    ByteType: (int, long),
    ShortType: (int, long),
    IntegerType: (int, long),
    LongType: (int, long),
    FloatType: (float,),
    DoubleType: (float,),
    DecimalType: (decimal.Decimal,),
    StringType: (str, unicode),
    BinaryType: (bytearray,),
    DateType: (datetime.date, datetime.datetime),
    TimestampType: (datetime.datetime,),
    ArrayType: (list, tuple, array.array),
    MapType: (dict,),
    StructType: (tuple, list, dict),
}
# Default mapping from Python to DataType 
_type_mappings = {
    type(None): NullType,
    bool: BooleanType,
    int: LongType,
    float: DoubleType,
    str: StringType,
    bytearray: BinaryType,
    decimal.Decimal: DecimalType,
    datetime.date: DateType,
    datetime.datetime: TimestampType,
    datetime.time: TimestampType,
}

#Decimal Type 
DecimalType(precision=10, scale=0)
    Decimal (decimal.Decimal) data type.
    String name is "decimal(precisiond,scale)" 
    
    The DecimalType must have fixed precision (the maximum total number of digits)
    and scale (the number of digits on the right of dot). For example, (5, 2) can
    support the value from [-999.99 to 999.99].

    The precision can be up to 38, the scale must less or equal to precision.

    When create a DecimalType, the default precision and scale is (10, 0). When infer
    schema from decimal.Decimal objects, it will be DecimalType(38, 18).

    precision: the maximum total number of digits (default: 10)
    scale: the number of digits on right side of dot. (default: 0)

#String of Datatype 
#The data type string format equals DataType.simpleString
#Atomic types can use DataType.typeName()(=lower case of class_name[:-4] ie byte for ByteType)
DataType.simpleString 
    by default = DataType.typeName(), (=lower case of class_name[:-4] ie byte for ByteType)
    eg 
    FloatType       'float'  #representing single precision floats
    DoubleType      'fouble' #representing double precision floats
    except below for atomic type 
    IntegerType     "integer" or 'int'          #a signed 32-bit integer
    DecimalType     'decimal' or 'decimal(precision, scale)'
    ByteType        'byte' or 'tinyint'         #a signed integer in a single byte
    LongType        'long' or 'bigint'          # a signed 64-bit integer.
    ShortType       'smallint'                  #a signed 16-bit integer.
    
#Complex type can have following 
    StructType  "struct<field_name:field_type,...>"  or "field_name:field_type, .."
    MapType     "map<k_type_string, v_type_string>"
    ArrayType   "array<element_type>"

>>> pyspark.sql.types._all_atomic_types
{'float': <class 'pyspark.sql.types.FloatType'>, 
'timestamp': <class 'pyspark.sql.types.TimestampType'>, 
'double': <class 'pyspark.sql.types.DoubleType'>, 
'null': <class 'pyspark.sql.types.NullType'>, 
'short': <class 'pyspark.sql.types.ShortType'>, 
'binary': <class 'pyspark.sql.types.BinaryType'>, 
'byte': <class 'pyspark.sql.types.ByteType'>, 
'integer': <class 'pyspark.sql.types.IntegerType'>, 
'decimal': <class 'pyspark.sql.types.DecimalType'>, 
'boolean': <class 'pyspark.sql.types.BooleanType'>, 
'long': <class 'pyspark.sql.types.LongType'>, 
'string': <class 'pyspark.sql.types.StringType'>, 
'date': <class 'pyspark.sql.types.DateType'>}
>>> pyspark.sql.types._all_complex_types
{'struct': <class 'pyspark.sql.types.StructType'>, 
'map': <class 'pyspark.sql.types.MapType'>, 
'array': <class 'pyspark.sql.types.ArrayType'>}

>>> pyspark.sql.types._parse_datatype_string("int ")
IntegerType
>>> pyspark.sql.types._parse_datatype_string("a: byte, b: decimal(  16 , 8   ) ")
StructType([StructField(a,ByteType,true),StructField(b,DecimalType(16,8),true)])
>>> pyspark.sql.types._parse_datatype_string("a: array< short>")
StructType([StructField(a,ArrayType(ShortType,true),true)])
>>> pyspark.sql.types._parse_datatype_string(" map<string , string > ")
MapType(StringType,StringType,true)



###Reference - DataFrames - SparkSession -  
  
class Builder
    Builder for SparkSession. Get it from SparkSession.builder
    appName(name)
        Sets a name for the application
    config(key=None, value=None, conf=None)
        Sets a config option.
        >>> from pyspark.conf import SparkConf
        >>> SparkSession.builder.config(conf=SparkConf())        
        >>> SparkSession.builder.config("spark.some.config.option", "some-value")
        <pyspark.sql.session...
    enableHiveSupport()
        Enables Hive support, including connectivity to a persistent Hive metastore, 
        support for Hive serdes, and Hive user-defined functions.
    getOrCreate()
        Gets an existing SparkSession or, if there is no existing one, 
        creates a new one based on the options set in this builder.
        >>> s1 = SparkSession.builder.config("k1", "v1").getOrCreate()
        >>> s1.conf.get("k1") == s1.sparkContext.getConf().get("k1") == "v1"
        True
    master(master)
        Sets the Spark master URL to connect to, such as 'local' to run locally, 
        'local[4]' to run locally with 4 cores, or 'spark://master:7077' to run on a Spark standalone cluster.



class pyspark.sql.SparkSession(sparkContext, jsparkSession=None)
    The entry point to programming Spark with  DataFrame API.
    A SparkSession can be used create DataFrame, 
    register DataFrame as tables, execute SQL over tables, 
    cache tables, and read many datasource (eg parquet) files. 
    SparkSession provides builtin support for Hive features
    Can be used with 'with' syntax 
        with SparkSession.builder.(...).getOrCreate() as spark:
            ....            
    #Attributes 
    classAttribute builder = <pyspark.sql.session.Builder object at 0x7fc358d6e250>
    catalog
        Interface through which the user may create, drop, alter 
        or query underlying databases, tables, functions etc.
        #fetch metadata data from the catalog, methods return as List 
        spark.catalog.listDatabases.show(false)
        spark.catalog.listTables.show(false)
        >>> dir(spark.catalog)
        ['cacheTable', 'clearCache', 'createExternalTable', 'createTable', 'currentDatabase', 
        'dropGlobalTempView', 'dropTempView', 'isCached', 'listColumns', 'listDatabases', 
        'listFunctions', 'listTables', 'recoverPartitions', 'refreshByPath', 'refreshTable', 
        'registerFunction', 'setCurrentDatabase', 'uncacheTable']
    conf
        Instance of RuntimeConfig, Runtime configuration interface for Spark
        #set new runtime options
        spark.conf.set("spark.sql.shuffle.partitions", 6)
        spark.conf.set("spark.executor.memory", "2g")
        #get all settings
        configMap = spark.conf.getAll() #Not possible in Python 
        >>> spark.conf.get("spark.app.name")
        'PySparkShell'
        >>> spark.sparkContext._conf.getAll()
    newSession()
        Returns a new SparkSession as new session, 
        that has separate SQLConf, registered temporary views and UDFs, 
        but shared SparkContext and table cache.
        
    createDataFrame(data, schema=None, samplingRatio=None, verifySchema=True)
        Create Data Frame 
    range(start, end=None, step=1, numPartitions=None)
        Create a DataFrame with single pyspark.sql.types.LongType column named 'id',
        containing elements in a range from start to end (exclusive) with step value step.
        >>> spark.range(1, 7, 2).collect()
        [Row(id=1), Row(id=3), Row(id=5)]
        >>> spark.range(3).collect()
        [Row(id=0), Row(id=1), Row(id=2)]
        #create a Dataset using spark.range starting from 5 to 100, with increments of 5
        numDS = spark.range(5, 100, 5)
        # reverse the order and display first 5 items
        from pyspark.sql.functions  import * 
        numDS.orderBy(desc("id")).show(5)
        #compute descriptive stats and display them
        numDs.describe().show()  
        
    table(tableName)
        Returns the specified table as a DataFrame.
        >>> df.createOrReplaceTempView("table1")
        >>> df2 = spark.table("table1")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
    read
        Returns a DataFrameReader that can be used to read data in as a DataFrame.
        #example 
        zipsDF = spark.read.json("zips.json")
        #filter all cities whose population > 40K
        zipsDF.filter(zipsDF.pop > 40000).show(10)
        zipsDF.createOrReplaceTempView("zips_table")
        zipsDF.cache()
        resultsDF = spark.sql("SELECT city, pop, state, zip FROM zips_table")
        resultsDF.show(10)
        #drop the table if exists to get around existing table error
        spark.sql("DROP TABLE IF EXISTS zips_hive_table")
        #Read one table and save as a different hive table, hive should be enabled 
        spark.table("zips_table").write.saveAsTable("zips_hive_table")
        #make a similar query against the hive table 
        val resultsHiveDF = spark.sql("SELECT city, pop, state, zip FROM zips_hive_table WHERE pop > 40000")
        resultsHiveDF.show(10)
    readStream
        Returns a DataStreamReader that can be used to read data streams as a streaming DataFrame.
    sparkContext
        Returns the underlying SparkContext.
    sql(sqlQuery)
        Returns a DataFrame representing the result of the given query.
        >>> df.createOrReplaceTempView("table1")
        >>> df2 = spark.sql("SELECT field1 AS f1, field2 as f2 from table1")
        >>> df2.collect()
        [Row(f1=1, f2=u'row1'), Row(f1=2, f2=u'row2'), Row(f1=3, f2=u'row3')]
    stop()
        Stop the underlying SparkContext.
    streams
        Returns a StreamingQueryManager that allows managing all the StreamingQuery StreamingQueries active on this context.
    udf
        Returns a instance UDFRegistration for UDF registration.
        Use pyspark.sql.functions.udf for simplicity to use in DF DSL 
        Note must use UDFRegistration if function t be used in SQL query
    version
        The version of Spark on which this application is running.
        
        

sql.types.DataType
    Base class for all data types
        fromJson(json)
        jsonValue()
        json()
            Gets json string 
        needConversion()
        simpleString()
        toInternal(obj)
            Converts a Python object into an internal SQL object
        fromInternal(obj)
            Converts an internal SQL object into a native Python object.
        classmethod typeName()
        ==, !=
    NullType
    StringType
    BinaryType
    BooleanType
    DateType
    TimestampType
    DecimalType(precision=10, scale=0)
    DoubleType
    FloatType
    ByteType
    IntegerType
    LongType
    ShortType    
    ArrayType(elementType, containsNull=True)
        Array data type.
        fromInternal(obj)
        classmethod fromJson(json)
            from json string 
        jsonValue()
            to json object 
        josn()
            to json string 
        needConversion()
        simpleString()
        toInternal(obj)
    MapType(keyType, valueType, valueContainsNull=True)
        Map data type.
        fromInternal(obj)
        classmethod fromJson(json)
            from json string 
        jsonValue()
            to json object 
        josn()
            to json string 
        needConversion()
        simpleString()
        toInternal(obj)
    StructField(name, dataType, nullable=True, metadata=None)
        fromInternal(obj)
        classmethod fromJson(json)
            from json string 
        jsonValue()
            to json object 
        josn()
            to json string 
        needConversion()
        simpleString()
        toInternal(obj)
    StructType(fields=None) 
        List of StructField
        >>> struct1 = StructType([StructField("f1", StringType(), True)])
        >>> struct1["f1"]
        StructField(f1,StringType,true)
        >>> struct1[0]
        StructField(f1,StringType,true)
        #Methods 
        fromInternal(obj)
        classmethod fromJson(json)
            from json string 
        jsonValue()
            to json object 
        josn()
            to json string 
        needConversion()
        simpleString()
        toInternal(obj)        
        add(field, data_type=None, nullable=True, metadata=None)
            Construct a StructType by adding new elements to it to define the schema. 
            The method accepts either:
                a.A single parameter which is a StructField object.
                b.Between 2 and 4 parameters as (name, data_type, nullable (optional), metadata(optional). 
            The data_type parameter may be either a String or a DataType object.
            >>> struct1 = StructType().add("f1", StringType(), True).add("f2", StringType(), True, None)
            >>> struct2 = StructType([StructField("f1", StringType(), True), StructField("f2", StringType(), True, None)])
            >>> struct1 == struct2
            True
            >>> struct1 = StructType().add(StructField("f1", StringType(), True))
            >>> struct2 = StructType([StructField("f1", StringType(), True)])
            >>> struct1 == struct2
            True
            >>> struct1 = StructType().add("f1", "string", True)
            >>> struct2 = StructType([StructField("f1", StringType(), True)])
            >>> struct1 == struct2
            True

            
            
            


###Spark - DataFrame - Userdefined function to operate on each element of a DF column
#Note f takes each element of a Column, not full Column together

#Note to use in sql query, must register via UDFRegistration
class pyspark.sql.UDFRegistration(sparkSession)
    Wrapper for user-defined function registration.
    Get instance from sparkSession.udf 
    Use pyspark.sql.functions.udf for simplicity to use in DF DSL 
    Note to use in sql query, must register via UDFRegistration
    #Attributes 
        register(name, f, returnType=StringType)
            Registers a python function (including lambda function) as a UDF
        registerJavaFunction(name, javaClassName, returnType=None)
            Register a Java user-defined function as a SQL function
           
#Example  
from pyspark.sql.types import IntegerType
spark.udf.register("stringLengthInt", lambda x: len(x), IntegerType())
>>> spark.sql("SELECT stringLengthInt('test')").collect()
[Row(stringLengthInt(test)=4)]

#Using sqlContext. (deprecated)
>>> sqlContext.registerFunction("stringLengthString", lambda x: len(x))
>>> sqlContext.sql("SELECT stringLengthString('test')").collect()
[Row(stringLengthString(test)=u'4')]

#Use pyspark.sql.functions.udf(f=None, returnType=StringType)
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import udf
slen = udf(lambda s: len(s), IntegerType())
_ = spark.udf.register("slen", slen)     #To use it in sql query must register
spark.sql("SELECT slen('test')").collect()
#or default return type StringType 
@udf
def to_upper(s):
    if s is not None:
        return s.upper()

#for later version below decorator is possible 
@udf(returnType=IntegerType())
def add_one(x):
    if x is not None:
        return x + 1
#Alternate syntax if udf decorator is not use 
add_one = udf(add_one, IntegerType()) 



df = spark.createDataFrame([(1, "John Doe", 21)], ("id", "name", "age"))
>>> df.select(slen("name").alias("slen(name)"), to_upper("name"), add_one("age")).show()
+----------+--------------+------------+
|slen(name)|to_upper(name)|add_one(age)|
+----------+--------------+------------+
|         8|      JOHN DOE|          22|
+----------+--------------+------------+
df.createOrReplaceTempView("table1")
_ = spark.udf.register("add_one", add_one)
_ = spark.udf.register("to_upper", to_upper)

>>> spark.sql("SELECT slen(name) AS LENGTH, to_upper(name), add_one(age) from table1").show()
+------+--------------+------------+
|LENGTH|to_upper(name)|add_one(age)|
+------+--------------+------------+
|     8|      JOHN DOE|          22|
+------+--------------+------------+


#Using spark.udf.registerJavaFunction(name, javaClassName, returnType=None)
#make sure jar is given as --jars command line 
>>> from pyspark.sql.types import IntegerType
>>> spark.udf.registerJavaFunction("javaStringLength", "test.org.apache.spark.sql.JavaStringLength", IntegerType())
>>> spark.sql("SELECT javaStringLength('test')").collect()
[Row(UDF:javaStringLength(test)=4)]





###Spark DF vs Pandas DF and spark UDF vs pandas_udf 
#Apache Arrow is an in-memory columnar data format that is used in Spark to efficiently transfer data between JVM and Python processes
#ensure that PyArrow is installed and available on all cluster nodes. The current supported version is 0.8.0
$ pip install pyarrow==0.8.0

#Example 
import numpy as np
import pandas as pd

# Enable Arrow-based columnar data transfers
spark.conf.set("spark.sql.execution.arrow.enabled", "true")

# Generate a Pandas DataFrame
pdf = pd.DataFrame(np.random.rand(100, 3))

# Create a Spark DataFrame from a Pandas DataFrame using Arrow
df = spark.createDataFrame(pdf)

# Convert the Spark DataFrame back to a Pandas DataFrame using Arrow
result_pdf = df.select("*").toPandas()

##Note 'object' type can not be converted to spark.DataFrame, hence use .astype() 
dataset = pd.read_csv("data/AS/test_v2.csv")
dataset.info()
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 5062 entries, 0 to 5061
Data columns (total 51 columns):
SomeCol                    5062 non-null object
Col2                       5062 non-null object

dataset[['SomeCol', 'Col2']] = dataset[['SomeCol', 'Col2']].astype(str) #or np.float64 etc 
sdf = spark.createDataFrame(dataset)






##Reference of pandas_udf 
pyspark.sql.functions.pandas_udf(f=None, returnType=None, functionType=SCALAR)
    Creates a vectorized user defined function (UDF).
    Parameters:
    �f � user-defined function. A python function if used as a standalone function
    �returnType � the return type of the user-defined function. 
     The value can be either a pyspark.sql.types.DataType object or a DDL-formatted type string.
    �functionType � an enum value in pyspark.sql.functions.PandasUDFType. Default: SCALAR.
 
##SCALAR(default) (also called vectorised)function type of the UDF 
#A scalar UDF defines a transformation: 
#One or more pandas.Series -> A pandas.Series.
#So, all pandas.Series operation can be done on the in args 
#The returnType should be a primitive data type, e.g., DoubleType(). 
#The length of the returned pandas.Series must be of the same as the input pandas.Series.

#Scalar UDFs are used with pyspark.sql.DataFrame.withColumn() and pyspark.sql.DataFrame.select().

#The length of pandas.Series within a scalar UDF is not that of the whole input column, 
#but is the length of an internal batch used for each call to the function. 
#Therefore, this can be used, for example, to ensure the length of each returned pandas.Series, 
#and can not be used as the column length.
 
from pyspark.sql.functions import pandas_udf, PandasUDFType
from pyspark.sql.types import IntegerType, StringType
slen = pandas_udf(lambda s: s.str.len(), IntegerType())  

@pandas_udf(StringType())  #default SCALAR 
def to_upper(s): #s is pandas Series 
    return s.str.upper()

@pandas_udf("integer", PandasUDFType.SCALAR)  
def add_one(x):
    return x + 1

df = spark.createDataFrame([(1, "John Doe", 21)],("id", "name", "age"))  
>>> df.select(slen("name").alias("slen(name)"), to_upper("name"), add_one("age")) .show()  
+----------+--------------+------------+
|slen(name)|to_upper(name)|add_one(age)|
+----------+--------------+------------+
|         8|      JOHN DOE|          22|
+----------+--------------+------------+

#Another Exmaple 
#Pandas UDFs are user defined functions that are executed by Spark using Arrow to transfer data 
#and Pandas to work with the data.
import pandas as pd

from pyspark.sql.functions import col, pandas_udf
from pyspark.sql.types import LongType

# Declare the function and create the UDF
#Takes two COlumns/Series 
def multiply_func(a, b):
    return a * b

multiply = pandas_udf(multiply_func, returnType=LongType())

# The function for a pandas_udf should be able to execute with local Pandas data
x = pd.Series([1, 2, 3])
print(multiply_func(x, x))
# 0    1
# 1    4
# 2    9
# dtype: int64

# Create a Spark DataFrame, 'spark' is an existing SparkSession
df = spark.createDataFrame(pd.DataFrame(x, columns=["x"]))

# Execute function as a Spark vectorized UDF
df.select(multiply(col("x"), col("x"))).show()
# +-------------------+
# |multiply_func(x, x)|
# +-------------------+
# |                  1|
# |                  4|
# |                  9|
# +-------------------+


##GROUPED_MAP function type of the UDF 
#A grouped map UDF defines transformation: 
#A pandas.DataFrame -> A pandas.DataFrame 
#So all pandas.DataFrame operations can be done on in args 
#The returnType should be a StructType describing the schema of the returned pandas.DataFrame. 
#The length of the returned pandas.DataFrame can be arbitrary.

#Grouped map UDFs are used with pyspark.sql.GroupedData.apply().

from pyspark.sql.functions import pandas_udf, PandasUDFType
df = spark.createDataFrame(
    [(1, 1.0), (1, 2.0), (2, 3.0), (2, 5.0), (2, 10.0)],
    ("id", "v"))  
@pandas_udf("id long, v double", PandasUDFType.GROUPED_MAP)  
def normalize(pdf):  #pandas.DataFrame 
    v = pdf.v      #take pandas Column 
    return pdf.assign(v=(v - v.mean()) / v.std())
>>> df.groupby("id").apply(normalize).show()  
+---+-------------------+
| id|                  v|
+---+-------------------+
|  1|-0.7071067811865475|
|  1| 0.7071067811865475|
|  2|-0.8320502943378437|
|  2|-0.2773500981126146|
|  2| 1.1094003924504583|
+---+-------------------+

##Grouped Map Pandas UDFs
#are used with spark.sql.DataFrame.groupBy().apply() 
#which implements the �split-apply-combine� pattern. 
#Split-apply-combine consists of three steps:
�Split the data into groups by using DataFrame.groupBy.
�Apply a function on each group. 
 The input and output of the function are both pandas.DataFrame. 
 The input data contains all the rows and columns for each group.
�Combine the results into a new DataFrame.

#Note that all data for a group will be loaded into memory before the function is applied. 
#This can lead to out of memory exceptons, 

#example shows how to use groupby().apply() to subtract the mean from each value in the group.

from pyspark.sql.functions import pandas_udf, PandasUDFType

df = spark.createDataFrame(
    [(1, 1.0), (1, 2.0), (2, 3.0), (2, 5.0), (2, 10.0)],
    ("id", "v"))

@pandas_udf("id long, v double", PandasUDFType.GROUPED_MAP)
def substract_mean(pdf):
    # pdf is a pandas.DataFrame
    v = pdf.v
    return pdf.assign(v=v - v.mean())

df.groupby("id").apply(substract_mean).show()
# +---+----+
# | id|   v|
# +---+----+
# |  1|-0.5|
# |  1| 0.5|
# |  2|-3.0|
# |  2|-1.0|
# |  2| 4.0|
# +---+----+

#The user-defined functions are considered deterministic by default. 
#Due to optimization, duplicate invocations may be eliminated 
#or the function may even be invoked more times than it is present in the query. 
#If your function is not deterministic, call asNondeterministic on the user defined function
@pandas_udf('double', PandasUDFType.SCALAR)  
def random(v):
    import numpy as np
    import pandas as pd
    return pd.Series(np.random.randn(len(v))
>>> random = random.asNondeterministic()  




###Spark - DataFrame -  Columns 
class Column 
    A column in a DataFrame.

#check functions at http://spark.apache.org/docs/latest/api/python/pyspark.sql.html#module-pyspark.sql.functions
#check column operations http://spark.apache.org/docs/latest/api/python/pyspark.sql.html#pyspark.sql.Column


#Creation of Column Instance 
#Note below operation  gives Column instance
#not  DataFrame with single column
#to convert to DataFrame, use as  df.select(Column_instance)
1. Select a Column instance out of a DataFrame
    df.colName
    df["colName"] 
    from pyspark.sql import functions as F
    F.col("colName")   
    F.column("colName")
   Many column expression also accepts "colName" string 
   
2. Using pyspark.sql.functions , convert one column to another column instance 
    F.func(col)  # where col is DF col eg df.colName or df["colName"]

3. Create from an expression
    df.colName + 1
    1 / df.colName
    F.col("colName") * 2
    


###Spark - DataFrame - Getting a row or column of DF 
df.select(*cols)
    Projects a set of expressions and returns a new DataFrame.
    cols � var args  of column names (string) 
           or expressions involving Column instances 
           If one of the column names is '*', 
           that column is expanded to include all columns in the current DataFrame. 
df.show(n=20, truncate=True)
    Prints the first n rows to the console.
df.columns
    Returns all column names as a list.
    >>> df.columns
    ['age', 'name']
df.collect()
    Returns all the records as a list of Row.
    >>> df.collect()
    [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]
 
    
#Getting a named column is 
df.select("colname")  #return DataFrame , to display, do .show()
df.select(df["colname"])
df.select(F.col("colname"))
df.select(df.colName)

#To get Single column based on   column index 
from pyspark.sql.functions import col
df.select(col(df.columns[index])) #return DataFrame, to display, do .show()


#To get a row 
##Not straight forward as DF are distributed 
df = spark.createDataFrame([("a", 1), ("b", 2), ("c", 3)], ["letter", "name"])
myIndex = 1
values = (df.rdd.zipWithIndex()     #(k,v),index 
            .filter(lambda t,i : i == myIndex)
            .map(lambda t,i: t)
            .collect())
print(values[0])
# (u'b', 2)


###Spark - DataFrame - Associating metadata with a column 
#Example - Associating max value with a Column via metadata (extra data associated with Column)

#to associate metadata with a column 
StructField(name, dataType, nullable=True, metadata=None) 
#or 
Column.as(alias, metadata) 
#Use below to access it 
schema["colName"].metadata['name'] 

#Example
df = spark.createDataFrame([(1, "John Doe", 21)], ("id", "name", "age"))

>>> df.select(df.age.alias("age2")).collect()
[Row(age2=2), Row(age2=5)]
>>> df.select(df.age.alias("age3", metadata={'max': 99})).schema['age3'].metadata['max']
99



###Example -  Basic creation and Operations on DF 
#HDFS must be up as configured in spark\conf\spark-env.cmd
$ spark-submit  --master local[4] basic.py

#basic.py 
from __future__ import print_function

from pyspark.sql import *
from pyspark.sql.types import *


df = spark.read.json(r"D:\Desktop\PPT\spark\data\people.json")
# Displays the content of the DataFrame to stdout
df.show()
# +----+-------+
# | age|   name|
# +----+-------+
# |null|Michael|
# |  30|   Andy|
# |  19| Justin|
# +----+-------+

# spark, df are from the previous example
# Print the schema in a tree format
df.printSchema()
# root
# |-- age: long (nullable = true)
# |-- name: string (nullable = true)

# Select only the "name" column
df.select("name").show()
# +-------+
# |   name|
# +-------+
# |Michael|
# |   Andy|
# | Justin|
# +-------+

# Select everybody, but increment the age by 1
df.select(df['name'], df['age'] + 1).show()
# +-------+---------+
# |   name|(age + 1)|
# +-------+---------+
# |Michael|     null|
# |   Andy|       31|
# | Justin|       20|
# +-------+---------+

# Select people older than 21
df.filter(df['age'] > 21).show()
# +---+----+
# |age|name|
# +---+----+
# | 30|Andy|
# +---+----+

# Count people by age
df.groupBy("age").count().show()
# +----+-----+
# | age|count|
# +----+-----+
# |  19|    1|
# |null|    1|
# |  30|    1|
# +----+-----+

# Register the DataFrame as a SQL temporary view
df.createOrReplaceTempView("people")

sqlDF = spark.sql("SELECT * FROM people")
sqlDF.show()
# +----+-------+
# | age|   name|
# +----+-------+
# |null|Michael|
# |  30|   Andy|
# |  19| Justin|
# +----+-------+

# Register the DataFrame as a global temporary view
df.createGlobalTempView("people")

# Global temporary view is tied to a system preserved database `global_temp`
spark.sql("SELECT * FROM global_temp.people").show()
# +----+-------+
# | age|   name|
# +----+-------+
# |null|Michael|
# |  30|   Andy|
# |  19| Justin|
# +----+-------+

# Global temporary view is cross-session
spark.newSession().sql("SELECT * FROM global_temp.people").show()
# +----+-------+
# | age|   name|
# +----+-------+
# |null|Michael|
# |  30|   Andy|
# |  19| Justin|
# +----+-------+




###ArrayType and MapType columns - String interpretation with the array() method
df = sc.parallelize([Row(word1="i like blue and red"),Row(word1="you pink and blue")]).toDF()

actualDF = df.withColumn(
  "colors",
  array(
    when(col("word1").contains("blue"), "blue"),
    when(col("word1").contains("red"), "red"),
    when(col("word1").contains("pink"), "pink"),
    when(col("word1").contains("cyan"), "cyan")
  )
)
#The array() function unfortunately includes null values in the colors column. 
actualDF.show(truncate = false)
+-------------------+--------------+
|              word1|        colors|
+-------------------+--------------+
|i like blue and red| [blue, red,,]|
|  you pink and blue|[blue,, pink,]|
+-------------------+--------------+

#OR 
colors = ("blue", "red", "pink", "cyan")

actualDF = df.withColumn(
  "colors",
  array( *[when(col("word1").contains(c), c)  for c in colors] )
)
actualDF.show(truncate=false)
+-------------------+--------------+
|              word1|        colors|
+-------------------+--------------+
|i like blue and red| [blue, red,,]|
|  you pink and blue|[blue,, pink,]|
+-------------------+--------------+

##Eliminating null from the arrays

actualDF = df.withColumn(
  "colors",
  split(
    concat_ws(
      ",",
      when(col("word1").contains("blue"), "blue"),
      when(col("word1").contains("red"), "red"),
      when(col("word1").contains("pink"), "pink"),
      when(col("word1").contains("cyan"), "cyan")
    ),
    ","
  )
)

actualDF.show(truncate=false)
+-------------------+------------+
|              word1|      colors|
+-------------------+------------+
|i like blue and red| [blue, red]|
|  you pink and blue|[blue, pink]|
+-------------------+------------+




##Splitting a string into an ArrayType column

singersDF = sc.parallelize([  ("beatles", "help|hey jude"),  ("romeo", "eres mia")]).toDF(["name", "hit_songs"])

#def withColumn(colName: String, col: Column): DataFrame
#Returns a new Dataset by adding a column or replacing the existing column that has the same name. 
actualDF = singersDF.withColumn( "hit_songs", split(col("hit_songs"), "\\|") )

actualDF.show()
#output 
+-------+----------------+
|   name|       hit_songs|
+-------+----------------+
|beatles|[help, hey jude]|
|  romeo|      [eres mia]|
+-------+----------------+

actualDF.printSchema()
#output 
root
 |-- name: string (nullable = true)
 |-- hit_songs: array (nullable = true)
 |    |-- element: string (containsNull = true)

  
#Directly creating an ArrayType column
rdd = sc.parallelize( [ Row("bieber", ("baby", "sorry")), Row("ozuna", ("criminal",))])
schema = StructType([StructField("name", StringType(), True), StructField("hit_songs", ArrayType(StringType(), True), True) ])
singersDFA = spark.createDataFrame(rdd, schema)
 
singersDFA.show()
#output 
+------+-------------+
|  name|    hit_songs|
+------+-------------+
|bieber|[baby, sorry]|
| ozuna|   [criminal]|
+------+-------------+
singersDFA.printSchema()
#output 
root
 |-- name: string (nullable = true)
 |-- hit_songs: array (nullable = true)
 |    |-- element: string (containsNull = true)

#Example - selecting 1st index 
singersDFA.select(col("name"),col("hit_songs").getItem(0).alias("First")  ).show()
  
 
##Directly creating a MapType column

val singersDF = spark.createDataFrame(
  sc.parallelize([
    Row("sublime", {
      "good_song" : "santeria",
      "bad_song" : "doesn't exist"}
    ),
    Row("prince_royce", {
      "good_song" : "darte un beso",
      "bad_song" : "back it up"}
    )
  ]), StructType([
    StructField("name", StringType(), True),
    StructField("songs", MapType(StringType(), StringType(), True), True)
  ])
)

singersDF.show()
#output 
+------------+--------------------+
|        name|               songs|
+------------+--------------------+
|     sublime|Map(good_song -> ...|
|prince_royce|Map(good_song -> ...|
+------------+--------------------+

singersDF.printSchema()
#output 
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: string (valueContainsNull = true)

#Example - we can display the singer name and their bad song:
singersDF.select(
    col("name"),
    col("songs").getField("bad_song").alias("bad song!")
  ).show()
#output 
+------------+-------------+
|        name|    bad song!|
+------------+-------------+
|     sublime|doesnt exist|
|prince_royce|   back it up|
+------------+-------------+

##Creating a schema with a column that uses MapType and ArrayType
val singersDFMA = spark.createDataFrame(
  sc.parallelize([
    Row("miley", {
      "good_songs" : ("party in the usa", "wrecking ball"),
      "bad_songs" : ("younger now",)}
    ),
    Row("kesha", {
      "good_songs" : ("tik tok", "timber"),
      "bad_songs" : ("rainbow",)}
    )
  ]), StructType([
    StructField("name", StringType(), True),
    StructField("songs", MapType(StringType(), ArrayType(StringType(), True), True), True)
  ])
)

singersDFMA.show()
#output
+-----+--------------------+
| name|               songs|
+-----+--------------------+
|miley|Map(good_songs ->...|
|kesha|Map(good_songs ->...|
+-----+--------------------+

singersDFMA.printSchema()
#output 
root
 |-- name: string (nullable = true)
 |-- songs: map (nullable = true)
 |    |-- key: string
 |    |-- value: array (valueContainsNull = true)
 |    |    |-- element: string (containsNull = true)

#display the good songs for each singer.
singersDF
  .select(
    col("name"),
    col("songs").getField("good_songs").getItem(0).alias("fun")
  ).show()
#output 
+-----+--------------------+
| name|                 fun|
+-----+--------------------+
|miley|[party in the usa...|
|kesha|   [tik tok, timber]|
+-----+--------------------+

##array_contains() and explode() methods for ArrayType columns
#The array_contains method returns true if the column contains a specified element.
val peopleDF = spark.createDataFrame(
  sc.parallelize([
    Row("bob", ("red", "blue")),
    Row("maria", ("green", "red")),
    Row("sue", ("black",))
  ]), StructType([
    StructField("name", StringType(), True),
    StructField("favorite_colors", ArrayType(StringType(), True), True)
  ])
)

val actualDF = peopleDF.withColumn(
  "likes_red",
  array_contains(col("favorite_colors"), "red")
)

actualDF.show()
#output
+-----+---------------+---------+
| name|favorite_colors|likes_red|
+-----+---------------+---------+
|  bob|    [red, blue]|     true|
|maria|   [green, red]|     true|
|  sue|        [black]|    false|
+-----+---------------+---------+

#The explode() method creates a new row for every element in an array.
peopleDF.select(
  col("name"),
  explode(col("favorite_colors")).alias("color")
).show()
#output
+-----+-----+
| name|color|
+-----+-----+
|  bob|  red|
|  bob| blue|
|maria|green|
|maria|  red|
|  sue|black|
+-----+-----+



###Example of complex schema 
#Each row is Person 

Person = Row('userId', 'tech')  #tech is instance of below Tech 
Tech = Row('browsers', 'oss')   #browsers is list of instance of below Browser 
Browser = Row('family','major', 'minor','language','timesSeen')

#userId: string, tech: struct<browsers: array<struct<family:string,major:int,minor:int,language:string,timesSeen:bigint>>, oss: string>

df = sc.parallelize([Person("abc",Tech([
    Browser("IE", 7, 0, "en", 3),
    Browser(None, None, None, "en-us", 1),
    Browser("Firefox",54, None,None, 1)], "win")),
  Person("abc", Tech([
    Browser("IE", 7, 0, "en", 3),
    Browser(None, None, None, "en-us", 1),
    Browser("Firefox",54, None,None, 1)], "linux"))]).toDF()
>>> df.schema
StructType(List(StructField(userId,StringType,true),StructField(tech,StructType(List(StructField(browsers,ArrayType(StructType(List(StructField(family,StringType,true),StructField(major,LongType,true),StructField(minor,LongType,true),StructField(language,StringType,true),StructField(timesSeen,LongType,true))),true),true),StructField(oss,StringType,true))),true)))
>>> df.schema.json()
'{"fields":[{"metadata":{},"name":"userId","nullable":true,"type":"string"},{"metadata":{},"name":"tech","nullable":true,"type":{"fields":[{"metadata":{},"name":"browsers","nullable":true,"type":{"containsNull":true,"elementType":{"fields":[{"metadata":{},"name":"family","nullable":true,"type":"string"},{"metadata":{},"name":"major","nullable":true,"type":"long"},{"metadata":{},"name":"minor","nullable":true,"type":"long"},{"metadata":{},"name":"language","nullable":true,"type":"string"},{"metadata":{},"name":"timesSeen","nullable":true,"type":"long"}],"type":"struct"},"type":"array"}},{"metadata":{},"name":"oss","nullable":true,"type":"string"}],"type":"struct"}}],"type":"struct"}'

#Select two columns
df.select("userId", "tech.browsers").show(truncate=False)
#output 
+------+-------------------------------------------------------+
|userId|browsers                                               |
+------+-------------------------------------------------------+
|abc   |[[IE, 7, 0, en, 3], [,,, en-us, 1], [Firefox, 54,,, 1]]|
|abc   |[[IE, 7, 0, en, 3], [,,, en-us, 1], [Firefox, 54,,, 1]]|
+------+-------------------------------------------------------+



#Extract the family (nested value)
#This way you can iterate over the persons, and get their browsers
#Family values are nested
df.select("tech.browsers.family").show()
#output 
+--------------+
|        family|
+--------------+
|[IE,, Firefox]|
|[IE,, Firefox]|
+--------------+

#Normalize the family: One row for each family
#Then you can iterate over all families
#Family values are un-nested, empty values/null/None are handled by explode()
df.select(explode(col("tech.browsers.family")).alias("family")).show()
+-------+
| family|
+-------+
|     IE|
|   null|
|Firefox|
|     IE|
|   null|
|Firefox|
+-------+
>> df.select(explode(col("tech.browsers.family")).alias("family")).dropna().show()
+-------+
| family|
+-------+
|     IE|
|Firefox|
|     IE|
|Firefox|
+-------+


families = df.select(explode(col("tech.browsers.family")).alias("family")).rdd.map(lambda row : row['family']).distinct().collect()
print(families) #[None, 'IE', 'Firefox']

 
         


  
###Spark - DataFrame - DF Reference 

df = sc.parallelize([(2, 'Alice'), (5, 'Bob')])\
        .toDF(StructType([StructField('age', IntegerType()),
                          StructField('name', StringType())]))
df2 = sc.parallelize([Row(name='Tom', height=80), Row(name='Bob', height=85)]).toDF()
df3 = sc.parallelize([Row(name='Alice', age=2),
                           Row(name='Bob', age=5)]).toDF()
df4 = sc.parallelize([Row(name='Alice', age=10, height=80),
                           Row(name='Bob', age=5, height=None),
                           Row(name='Tom', age=None, height=None),
                           Row(name=None, age=None, height=None)]).toDF()
                           
sdf = sc.parallelize([Row(name='Tom', time=1479441846),
                           Row(name='Bob', time=1479442946)]).toDF()


class pyspark.sql.DataFrame(jdf, sql_ctx)
    A distributed collection of data grouped into named columns.
    A DataFrame is equivalent to a relational table in Spark SQL, 
    Create a DF from datasource or from spakSession.createDataFrame
    arg 'col' is given as 
        df.colName, df["colName"], "colName", df[functions.col("colName")]
    arg 'colName' is  string 
    #Attributes 
    dtypes
        Returns all column names and their data types as a list.
        >>> df.dtypes
        [('age', 'int'), ('name', 'string')]
    explain(extended=False)
        Prints the (logical and physical) plans to the console for debugging purpose.
    schema
        Returns the schema of this DataFrame as a pyspark.sql.types.StructType.
        Note schema['colName'] gives StructField() of that 'colName'
        >>> df.schema
        StructType(List(StructField(age,IntegerType,true),StructField(name,StringType,true)))
    printSchema()
        Prints out the schema in the tree format.
        >>> df.printSchema()
        root
         |-- age: integer (nullable = true)
         |-- name: string (nullable = true)

    rdd
        Returns the content as an pyspark.RDD of Row.
    columns
        Returns all column names as a list.
        >>> df.columns
        ['age', 'name']
        
    collect()
        Returns all the records as a list of Row.
        >>> df.collect()
        [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]
    count()
        Returns the number of rows in this DataFrame.
        >>> df.count()
        2
    distinct()
        Returns a new DataFrame containing the distinct rows in this DataFrame.
        >>> df.distinct().count()
        2
    first()
        Returns the first row as a Row.
        >>> df.first()
        Row(age=2, name=u'Alice')
    head(n=None)
        Returns the first n rows.
        >>> df.head()
        Row(age=2, name=u'Alice')
        >>> df.head(1)
        [Row(age=2, name=u'Alice')]
    limit(num)
        Limits the result count to the number specified.
        >>> df.limit(1).collect()
        [Row(age=2, name=u'Alice')]
        >>> df.limit(0).collect()
        []
    take(num)
        Returns the first num rows as a list of Row.
        >>> df.take(2)
        [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]
        
    colRegex(colName)
        Selects column based on the column name specified as a regex and returns it as Column.
        colName � string, column name specified as a regex, note must be enclosed in ``
        >>> df = spark.createDataFrame([("a", 1), ("b", 2), ("c",  3)], ["Col1", "Col2"])
        >>> df.select(df.colRegex("`(Col1)?+.+`")).show()
        +----+
        |Col2|
        +----+
        |   1|
        |   2|
        |   3|
        +----+
    select(*cols)
        Projects a set of expressions and returns a new DataFrame.
        cols �  
            variable args of column names (string) 
            or expressions involving column instances ie df.colName etc 
            If one of the column names is '*', that column is expanded to include all columns in the current DataFrame. 
        >>> df.select('*').collect()
        [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]
        >>> df.select('name', 'age').collect()
        [Row(name=u'Alice', age=2), Row(name=u'Bob', age=5)]
        >>> df.select(df.name, (df.age + 10).alias('age')).collect()
        [Row(name=u'Alice', age=12), Row(name=u'Bob', age=15)]
    selectExpr(*expr)
        Projects variable args of expr, string of SQL expressions and returns a new DataFrame.
        This is a variant of select() that accepts SQL expressions.
        (numeric can have +,-,*,/ , string can have || for concatenation)
        (comparison operators =, !=, > < >= <= )
        (has many functions , check  https://docs.oracle.com/cd/B28359_01/server.111/b28286/functions001.htm#SQLRF51174 )
        >>> df.selectExpr("age * 2", "abs(age)").collect()
        [Row((age * 2)=4, abs(age)=2), Row((age * 2)=10, abs(age)=5)]
        
    show(n=20, truncate=True)
        Prints the first n rows to the console.
        >>> df
        DataFrame[age: int, name: string]
        >>> df.show()
        +---+-----+
        |age| name|
        +---+-----+
        |  2|Alice|
        |  5|  Bob|
        +---+-----+
        >>> df.show(truncate=3)
        +---+----+
        |age|name|
        +---+----+
        |  2| Ali|
        |  5| Bob|
        +---+----+
    where(condition) 
    filter(condition)
        Filters rows using the given condition.
        condition � a Column of types.BooleanType or column with comparison operation
        or a string of SQL expression involving  comparison. 
        Note &, | and ~ is used for combining boolean conditions 
        >>> df.filter(df.age > 3).collect()
        [Row(age=5, name=u'Bob')]
        >>> df.where(df.age == 2).collect()
        [Row(age=2, name=u'Alice')]
        >>> df.filter("age > 3").collect()
        [Row(age=5, name=u'Bob')]
        >>> df.where("age = 2").collect()
        [Row(age=2, name=u'Alice')]
    foreach(f)
        Applies the f(row) function to all Row of this DataFrame.
        Row can be accessed like attributes (row.key),like dictionary values (row[key]) or row[index]
        or checking : key in row 
        This is a shorthand for df.rdd.foreach().
        >>> def f(person): #row 
                print(person.name)
        >>> df.foreach(f)
    foreachPartition(f)
        Applies the f(row_iterator) function to each partition of this DataFrame.
        This a shorthand for df.rdd.foreachPartition().
        Row can be accessed like attributes (row.key),like dictionary values (row[key]) or row[index]
        or checking as key in row 
        >>> def f(people):
                for person in people:
                    print(person.name)
        >>> df.foreachPartition(f)
        
    approxQuantile(col, probabilities, relativeError)
        Calculates the approximate quantiles of a numerical column of a DataFrame.
    corr(col1, col2, method=None)
        Calculates the correlation of two columns of a DataFrame as a double value. 
    cov(col1, col2)
        Calculate the sample covariance for the given columns, 
        specified by their names, as a double value. 
        DataFrame.cov() and DataFrameStatFunctions.cov() are aliases.
    crosstab(col1, col2)
        Computes a pair-wise frequency table of the given columns. 
    stat
        Returns a DataFrameStatFunctions for statistic functions.
    describe(*cols)
        Computes statistics for numeric and string columns.
        cols can be variable args or list of 'colName' 
        Return DataFrame 
        >>> df.describe(['age']).show() 
        +-------+------------------+
        |summary|               age|
        +-------+------------------+
        |  count|                 2|
        |   mean|               3.5|
        | stddev|2.1213203435596424|
        |    min|                 2|
        |    max|                 5|
        +-------+------------------+
        >>> df.describe().show()  #'age','name' or ['age','name']
        +-------+------------------+-----+
        |summary|               age| name|
        +-------+------------------+-----+
        |  count|                 2|    2|
        |   mean|               3.5| null|
        | stddev|2.1213203435596424| null|
        |    min|                 2|Alice|
        |    max|                 5|  Bob|
        +-------+------------------+-----+
    toDF(*cols)
        Returns a new DataFrame that with new specified column names(var args)
        >>> df.toDF('f1', 'f2').collect()
        [Row(f1=2, f2=u'Alice'), Row(f1=5, f2=u'Bob')]
        
    alias(alias)
        Returns a new DataFrame with an alias set.
        >>> from pyspark.sql.functions import *
        >>> df_as1 = df.alias("df_as1")
        >>> df_as2 = df.alias("df_as2")
        >>> joined_df = df_as1.join(df_as2, col("df_as1.name") == col("df_as2.name"), 'inner')
        >>> joined_df.select("df_as1.name", "df_as2.name", "df_as2.age").collect()
        [Row(name=u'Bob', name=u'Bob', age=5), Row(name=u'Alice', name=u'Alice', age=2)]
    withColumn(colName, col)
        Returns a new DataFrame by adding a column 
        or replacing the existing column that has the same name.
        >>> df.withColumn('age2', df.age + 2).collect()
        [Row(age=2, name=u'Alice', age2=4), Row(age=5, name=u'Bob', age2=7)]
    withColumnRenamed(existing, new)
        Returns a new DataFrame by renaming an existing column. 
        This is a no-op if schema doesn't contain the given column name.
        >>> df.withColumnRenamed('age', 'age2').collect()
        [Row(age2=2, name=u'Alice'), Row(age2=5, name=u'Bob')]
    drop(*cols)
        Returns a new DataFrame that drops the specified column. 
        This is a no-op if schema doesn't contain the given column name(s).
        >>> df.drop('age').collect()
        [Row(name=u'Alice'), Row(name=u'Bob')]
        >>> df.drop(df.age).collect()
        [Row(name=u'Alice'), Row(name=u'Bob')]
        >>> df.join(df2, df.name == df2.name, 'inner').drop(df.name).collect()
        [Row(age=5, height=85, name=u'Bob')]
        >>> df.join(df2, df.name == df2.name, 'inner').drop(df2.name).collect()
        [Row(age=5, name=u'Bob', height=85)]
        >>> df.join(df2, 'name', 'inner').drop('age', 'height').collect()
        [Row(name=u'Bob')]
    dropDuplicates(subset=None) 
    drop_duplicates(subset=None)
        Return a new DataFrame with duplicate rows removed, 
        optionally only considering certain columns in subset as list of 'colName'
        For a static batch DataFrame, it just drops duplicate rows. 
        For a streaming DataFrame, it uses trigger processing time as intermediate state to drop duplicates rows. 
        You can use withWatermark() further to limit how late the duplicate data can be  and system will accordingly limit the state. 
        In addition, too late data older than watermark will be dropped to avoid any possibility of duplicates.
        >>> from pyspark.sql import Row
        >>> df = sc.parallelize([ \
                Row(name='Alice', age=5, height=80), \
                Row(name='Alice', age=5, height=80), \
                Row(name='Alice', age=10, height=80)]).toDF()
        >>> df.dropDuplicates().show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        |  5|    80|Alice|
        | 10|    80|Alice|
        +---+------+-----+
        >>> df.dropDuplicates(['name', 'height']).show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        |  5|    80|Alice|
        +---+------+-----+
    na
        Returns a DataFrameNaFunctions for handling missing values.
    dropna(how='any', thresh=None, subset=None)
        Returns a new DataFrame omitting rows with null values. 
        DataFrame.dropna() and DataFrameNaFunctions.drop() are aliases 
        �how � 'any' or 'all'. 
         If 'any', drop a row if it contains any nulls. 
         If 'all', drop a row only if all its values are null.
        �thresh � int, default None If specified, drop rows that have less than thresh non-null values. This overwrites the how parameter.
        �subset � optional list of column names to consider.
        >>> df4.na.drop().show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        | 10|    80|Alice|
        +---+------+-----+
    fillna(value, subset=None)
        Replace null values, 
        alias for na.fill(). DataFrame.fillna() and DataFrameNaFunctions.fill() 
        �value � int, long, float, string, or dict. 
         Value to replace null values with. 
         If the value is a dict, then subset is ignored 
         and value must be a mapping from column name (string) to replacement value. 
         The replacement value must be an int, long, float, or string.
        �subset � optional list of column names to consider. 
         Columns specified in subset that do not have matching data type are ignored. 
        >>> df4.na.fill(50).show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        | 10|    80|Alice|
        |  5|    50|  Bob|
        | 50|    50|  Tom|
        | 50|    50| null|
        +---+------+-----+
        >>> df4.na.fill({'age': 50, 'name': 'unknown'}).show()
        +---+------+-------+
        |age|height|   name|
        +---+------+-------+
        | 10|    80|  Alice|
        |  5|  null|    Bob|
        | 50|  null|    Tom|
        | 50|  null|unknown|
        +---+------+-------+
    replace(to_replace, value, subset=None)
        Returns a new DataFrame replacing a value with another value. 
        DataFrame.replace() and DataFrameNaFunctions.replace() are aliases 
        �to_replace � int, long, float, string, or list. 
           Value to be replaced. 
           If this is list, then list of values to be replaced 
           If it is a dict, then 'value' arg is ignored 
           and to_replace must be a mapping from column name (string) 
           to replacement value. The value to be replaced must be an int, long, float, or string.
        �value � int, long, float, string, or list. 
            Value to use to replace holes. 
            The replacement value must be an int, long, float, or string. 
            If value is a list or tuple, value should be of the same length with to_replace.
            If value is a scalar and to_replace is a sequence, then value is used as a replacement for each item in to_replace.
        �subset � optional list of column names to consider. 
            Columns specified in subset that do not have matching data type are ignored. 
        >>> df4.na.replace(10, 20).show()
        +----+------+-----+
        | age|height| name|
        +----+------+-----+
        |  20|    80|Alice|
        |   5|  null|  Bob|
        |null|  null|  Tom|
        |null|  null| null|
        +----+------+-----+
        >>> df4.na.replace(['Alice', 'Bob'], ['A', 'B'], 'name').show()
        +----+------+----+
        | age|height|name|
        +----+------+----+
        |  10|    80|   A|
        |   5|  null|   B|
        |null|  null| Tom|
        |null|  null|null|
        +----+------+----+
    freqItems(cols, support=None)
        Finding frequent items for columns, possibly with false positives. 
        �cols � Names of the columns to calculate frequent items 
                for as a list or tuple of strings.
        �support � The frequency with which to consider an item 'frequent'. 
                   Default is 1%. The support must be greater than 1e-4.
    agg(*exprs)
        Aggregate on the entire DataFrame without groups 
        (shorthand for df.groupBy.agg()).
        The available aggregate functions are avg, max, min, sum, count.
        If exprs is a single dict mapping from string to string, 
        then the key is the column to perform aggregation on, and the value is the aggregate function.
        Alternatively, exprs can also be a var args of aggregate Column expressions
        >>> df.agg({"age": "max"}).collect()
        [Row(max(age)=5)]
        >>> from pyspark.sql import functions as F
        >>> df.agg(F.min(df.age)).collect()
        [Row(min(age)=2)]
        >>> df.agg(F.min(df.age), F.min(df.age)).collect()
    cube(*cols)
        Returns GroupedData
        Create a multi-dimensional cube for the current DataFrame 
        using the specified columns, so we can run aggregation on them.
        #create cartesian product of (null, all values from name) x (null, all values from age)
        #null means  any value of that column possible 
        >>> df.cube("name", df.age).count().orderBy("name", "age").show()
        +-----+----+-----+
        | name| age|count|
        +-----+----+-----+
        | null|null|    2|
        | null|   2|    1|
        | null|   5|    1|
        |Alice|null|    1|
        |Alice|   2|    1|
        |  Bob|null|    1|
        |  Bob|   5|    1|
        +-----+----+-----+
    rollup(*cols)
        Returns GroupedData
        Create a multi-dimensional rollup for the current DataFrame using the specified columns, 
        so we can run aggregation on them.
        #create cartesian product of (null, all values from name) x (null, all values from age)
        #null means  any value of that column possible 
        #and them remove rows with "null" of first column and only keeping null,null row
        >>> df.rollup("name", df.age).count().orderBy("name", "age").show()
        +-----+----+-----+
        | name| age|count|
        +-----+----+-----+
        | null|null|    2|
        |Alice|null|    1|
        |Alice|   2|    1|
        |  Bob|null|    1|
        |  Bob|   5|    1|
        +-----+----+-----+
    groupBy(*cols) 
    groupby(*cols)
        Groups the DataFrame using the specified columns, returns GroupedData
        GroupedData has many functions eg avg, min, max, sum, agg etc 
        cols � var args of columns to group by. 
              Each element should be a column name (string) or an expression (Column). 
        #create cartesian product of (null, all values from name) x (null, all values from age)
        #null means  any value of that column possible 
        #and them remove rows with any null 
        >>> df.groupby("name", df.age).count().orderBy("name", "age").show()
        +-----+---+-----+
        | name|age|count|
        +-----+---+-----+
        |Alice|  2|    1|
        |  Bob|  5|    1|
        +-----+---+-----+
        >>> df.groupBy().avg().collect()
        [Row(avg(age)=3.5)]
        >>> sorted(df.groupBy('name').agg({'age': 'mean'}).collect())
        [Row(name=u'Alice', avg(age)=2.0), Row(name=u'Bob', avg(age)=5.0)]
        >>> sorted(df.groupBy(df.name).avg().collect())
        [Row(name=u'Alice', avg(age)=2.0), Row(name=u'Bob', avg(age)=5.0)]
        >>> sorted(df.groupBy(['name', df.age]).count().collect())
        [Row(name=u'Alice', age=2, count=1), Row(name=u'Bob', age=5, count=1)]
    orderBy(*cols, **kwargs)
        Returns a new DataFrame sorted by the specified column(s).
        �cols � var args of Column or column names to sort by.
        �ascending = boolean or list of boolean (default True). 
                    Sort ascending vs. descending. 
                    Specify list for multiple sort orders. 
                    If a list is specified, length of the list must equal length of the cols. 
        >>> df.orderBy(df.age.desc()).collect()
        [Row(age=5, name=u'Bob'), Row(age=2, name=u'Alice')]
        >>> df.orderBy(desc("age"), "name").collect()
        [Row(age=5, name=u'Bob'), Row(age=2, name=u'Alice')]
        >>> df.orderBy(["age", "name"], ascending=[0, 1]).collect()
        [Row(age=5, name=u'Bob'), Row(age=2, name=u'Alice')]
    sort(*cols, **kwargs)
        Returns a new DataFrame sorted by the specified column(s).
        >>> df.sort(df.age.desc()).collect()
        [Row(age=5, name=u'Bob'), Row(age=2, name=u'Alice')]
        >>> df.sort("age", ascending=False).collect()
        [Row(age=5, name=u'Bob'), Row(age=2, name=u'Alice')]
        >>> from pyspark.sql.functions import *
        >>> df.sort(asc("age")).collect()
        [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]        
    sortWithinPartitions(*cols, **kwargs)
        Returns a new DataFrame with each partition sorted by the specified column(s).
        >>> df.sortWithinPartitions("age", ascending=False).show()
        +---+-----+
        |age| name|
        +---+-----+
        |  2|Alice|
        |  5|  Bob|
        +---+-----+
        
    crossJoin(other)
        Returns the cartesian product with another DataFrame.
            other: Right side of the cartesian product
        >>> df.select("age", "name").collect()
        [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]
        >>> df2.select("name", "height").collect()
        [Row(name=u'Tom', height=80), Row(name=u'Bob', height=85)]
        >>> df.crossJoin(df2.select("height")).select("age", "name", "height").collect()
        [Row(age=2, name=u'Alice', height=80), Row(age=2, name=u'Alice', height=85),
         Row(age=5, name=u'Bob', height=80), Row(age=5, name=u'Bob', height=85)]
    join(other, on=None, how=None)
        Joins with another DataFrame, using the given join expression.
        �other � Right side of the join
        �on � a string for join column name, a list of string column names(both df must have these columns)
              or a join expression involving Column ( eg leftDf.colName1 == rightDF.colName2)
              or a list of join expression involving Column
              If on is a string or a list of strings indicating the name of the join column(s), 
              the column(s) must exist on both sides, and this performs an equi-join.
        �how � str, default 'inner'. 
               One of inner, outer, left_outer, right_outer, leftsemi.
        #a full outer join between df1 and df2.
        >>> df.join(df2, df.name == df2.name, 'outer').select(df.name, df2.height).collect()
        [Row(name=None, height=80), Row(name=u'Bob', height=85), Row(name=u'Alice', height=None)]
        >>> df.join(df2, 'name', 'outer').select('name', 'height').collect()
        [Row(name=u'Tom', height=80), Row(name=u'Bob', height=85), Row(name=u'Alice', height=None)]
        >>> cond = [df.name == df3.name, df.age == df3.age]
        >>> df.join(df3, cond, 'outer').select(df.name, df3.age).collect()
        [Row(name=u'Alice', age=2), Row(name=u'Bob', age=5)]
        >>> df.join(df2, 'name').select(df.name, df2.height).collect()
        [Row(name=u'Bob', height=85)]
        >>> df.join(df4, ['name', 'age']).select(df.name, df.age).collect()
        [Row(name=u'Bob', age=5)]
        
    randomSplit(weights, seed=None)
        Randomly splits this DataFrame with the provided list of weights.
        Returns that many DataFrame 
        >>> splits = df4.randomSplit([1.0, 2.0], 24)
        >>> splits[0].count()
        1
        >>> splits[1].count()
        3
    sample(withReplacement, fraction, seed=None)
        Returns a sampled subset of this DataFrame.
        >>> df.sample(False, 0.5, 42).count()
        2
    sampleBy(col, fractions, seed=None)
        Returns a stratified sample without replacement based on the fraction  given on each stratum.
        fractions is a dict where key is value of that 'colName' 
        and dict's value is fraction for that value of 'colName'
        >>> from pyspark.sql.functions import col
        >>> dataset = spark.range(0, 100).select((col("id") % 3).alias("key"))
        >>> sampled = dataset.sampleBy("key", fractions={0: 0.1, 1: 0.2}, seed=0)
        >>> sampled.groupBy("key").count().orderBy("key").show()
        +---+-----+
        |key|count|
        +---+-----+
        |  0|    5|
        |  1|    9|
        +---+-----+
    intersect(other)
        Return a new DataFrame containing rows 
        in both this frame and another frame.
    subtract(other)
        Return a new DataFrame containing rows in this frame but not in another frame.
        This is equivalent to EXCEPT in SQL.
    unionAll(other) 
    union(other)
        Return a new DataFrame containing union of rows in this frame and another frame.
        This is equivalent to UNION ALL in SQL. 
        To do a SQL-style set union (that does de-duplication of elements), 
        use this function followed by a distinct.
        
    createGlobalTempView(name)
        Creates a global temporary view with this DataFrame.
        Local Temporary views in Spark SQL are session-scoped 
        and will disappear if the session that creates it terminates. 
        To share among all sessions and keep alive 
        until the Spark application terminates, create a global temporary view. 
        Global temporary view is tied to a system preserved database global_temp, 
        and use the qualified name to refer it, e.g. SELECT * FROM global_temp.view    
        >>> df.createGlobalTempView("people")
        >>> df2 = spark.sql("select * from global_temp.people")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
        >>> df.createGlobalTempView("people")  
        Traceback (most recent call last):
        ...
        AnalysisException: u"Temporary table 'people' already exists;"
         >>> spark.catalog.listTables()
        []
        >>> spark.catalog.listDatabases()
        [Database(name='default', description='Default Hive database', locationUri='file:/D:/Desktop/PPT/spark-warehouse')]
        >>> spark.catalog.dropGlobalTempView("people")
        >>> df.createGlobalTempView("people")
    createOrReplaceTempView(name)
        Creates or replaces a local temporary view with this DataFrame.
        >>> df.createOrReplaceTempView("people")
        >>> df2 = df.filter(df.age > 3)
        >>> df2.createOrReplaceTempView("people")
        >>> df3 = spark.sql("select * from people")
        >>> sorted(df3.collect()) == sorted(df2.collect())
        True
        >>> spark.catalog.dropTempView("people")
    createTempView(name)
        Creates a local temporary view with this DataFrame.
        >>> df.createTempView("people")
        >>> df2 = spark.sql("select * from people")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
        >>> df.createTempView("people")  
        Traceback (most recent call last):
        ...
        AnalysisException: u"Temporary table 'people' already exists;"
        >>> spark.catalog.dropTempView("people")
    registerTempTable(name)
        Registers this RDD as a temporary table(hive) using the given name.
        >>> df.registerTempTable("people")
        >>> df2 = spark.sql("select * from people")
        >>> sorted(df.collect()) == sorted(df2.collect())
        True
        >>> spark.catalog.dropTempView("people")   #to delete temp table 
        #diif between temp and permanent table 
        >>> spark.catalog.listTables()
        []
        >>> df.write.saveAsTable("people")
        >>> spark.catalog.listTables()
        [Table(name='people', database='default', description=None, tableType='MANAGED', isTemporary=False)]
        >>> df = spark.table("people")
        >>> df.show()
        +---+-----+
        |age| name|
        +---+-----+
        |  2|Alice|
        |  5|  Bob|
        +---+-----+
        >>> df.registerTempTable("people")
        >>> spark.catalog.listTables()
        [Table(name='people', database='default', description=None, tableType='MANAGED', isTemporary=False), 
         Table(name='people', database=None, description=None, tableType='TEMPORARY', isTemporary=True)]
        >>> df.registerTempTable("db.people")
        pyspark.sql.utils.AnalysisException: 'It is not allowed to add database prefix `db` for the TEMPORARY view name.;'

        >>> spark.sql("create database db")
        18/07/29 09:48:31 WARN ObjectStore: Failed to get database db, returning NoSuchObjectException
        >>> spark.sql("CREATE DATABASE IF NOT EXISTS new_db ")
        18/07/29 09:49:26 WARN ObjectStore: Failed to get database new_db, returning NoSuchObjectException

        >>> spark.catalog.listDatabases()
        [Database(name='db', description='', locationUri='file:/D:/Desktop/PPT/spark-warehouse/db.db'), 
        Database(name='default', description='Default Hive database', locationUri='file:/D:/Desktop/PPT/spark-warehouse'), 
        Database(name='new_db', description='', locationUri='file:/D:/Desktop/PPT/spark-warehouse/new_db.db')]
 
        >>> df.write.saveAsTable("db.people")
        >>> spark.catalog.listTables()
        [Table(name='people', database='default', description=None, tableType='MANAGED', isTemporary=False), 
        Table(name='people', database=None, description=None, tableType='TEMPORARY', isTemporary=True)]
        >>> spark.catalog.listTables("db")
        [Table(name='people', database='db', description=None, tableType='MANAGED', isTemporary=False), 
        Table(name='people', database=None, description=None, tableType='TEMPORARY', isTemporary=True)]
        >>> spark.catalog.dropTempView("people")
        >>> spark.catalog.listTables()
        [Table(name='people', database='default', description=None, tableType='MANAGED', isTemporary=False)]
        
        >>> spark.catalog.listTables("db")
        [Table(name='people', database='db', description=None, tableType='MANAGED', isTemporary=False)]
        >>> sql("DROP table IF EXISTS db.people ")
        DataFrame[]
        >>> spark.catalog.listTables("db")
        []
    toJSON(use_unicode=True)
        Converts a DataFrame into a RDD of string.
        Each row is turned into a JSON document as one element in the returned RDD.
        >>> df.toJSON().first()
        u'{"age":2,"name":"Alice"}'
    toLocalIterator()
        Returns an iterator that contains all of the rows in this DataFrame. 
        >>> list(df.toLocalIterator())
        [Row(age=2, name=u'Alice'), Row(age=5, name=u'Bob')]
    toPandas()
        Returns the contents of this DataFrame as Pandas pandas.DataFrame.
        >>> df.toPandas()  
           age   name
        0    2  Alice
        1    5    Bob
    cache()
        Persists the DataFrame with the default storage level (MEMORY_AND_DISK).
    unpersist(blocking=False)
        Marks the DataFrame as non-persistent, 
        and remove all blocks for it from memory and disk.
    persist(storageLevel=StorageLevel(True, True, False, False, 1))
        Sets the storage level to persist the contents of the DataFrame across operations after the first time it is computed. This can only be used to assign a new storage level if the DataFrame does not have a storage level set yet. If no storage level is specified defaults to (MEMORY_AND_DISK).
    storageLevel
        Get the DataFrame's current storage level.
        >>> df.storageLevel
        StorageLevel(False, False, False, False, 1)
        >>> df.cache().storageLevel
        StorageLevel(True, True, False, True, 1)
        >>> df2.persist(StorageLevel.DISK_ONLY_2).storageLevel
        StorageLevel(True, False, False, False, 2)
        
    withWatermark(eventTime, delayThreshold)
        Defines an event time watermark for this DataFrame. 
        A watermark tracks a point in time before which we assume no more late data is going to arrive.

        The current watermark is computed by looking at the MAX(eventTime) seen across all of the partitions in the query 
        minus a user specified delayThreshold. 
        Due to the cost of coordinating this value across partitions, the actual watermark used is only guaranteed to be at least delayThreshold behind the actual event time. 

        Spark will use this watermark for several purposes:
                �To know when a given time window aggregation can be finalized 
                 and thus can be emitted when using output modes that do not allow updates.
                �To minimize the amount of state that we need to keep for on-going aggregations.
        eventTime � the name of the column that contains the event time of the row.
        delayThreshold � the minimum delay to wait to data to arrive late, 
            relative to the latest record that has been processed in the form of an interval 
            (e.g. '1 minute' or '5 hours')
        >>> sdf.select('name', sdf.time.cast('timestamp')).withWatermark('time', '10 minutes')
        DataFrame[name: string, time: timestamp]
    write
        Interface for saving the content of the non-streaming DataFrame out into external storage.
        Note to read use sparkSession.read
    writeStream
        Interface for saving the content of the streaming DataFrame out into external storage.
        Note to read use sparkSession.readStream
    checkpoint(eager=True)
        Returns a checkpointed version of this Dataset. 
        Checkpointing can be used to truncate the logical plan of this DataFrame, 
        which is especially useful in iterative algorithms 
        where the plan may grow exponentially. 
        It will be saved to files inside the checkpoint directory set 
        with SparkContext.setCheckpointDir().
    isLocal()
        Returns True if the collect() and take() methods can be run locally 
    isStreaming
        Returns true if this Dataset contains one or more sources 
        that continuously return data as it arrives.


###Spark - DataFrame - Column Reference 
df =  sc.parallelize([(2, 'Alice'), (5, 'Bob')]) \
        .toDF(StructType([StructField('age', IntegerType()),StructField('name', StringType())]))

class pyspark.sql.Column(jc)
    Get column instance by 
        df.colName or df["colName"] or functions.col("colName")
    Operators Possible 
        #Bitwise operation, elementwise 
        bitwiseAND(col2) 
        bitwiseOR(col2) 
        bitwiseXOR(col2) 
        #boolean operator , elementwise 
            col1 & col2 , col1 & literal, for boolean and 
            col1 | col2, col1 | literal, for boolean or 
             ~col for boolean not 
        # arithmetic operators, elementwise 
            -col
            col1 + col2 , col1 + literal or literal + col1 
            col1 - col2 , col1 - literal or literal - col1 
            col1 * col2 , col1 * literal or literal * col1 
            col1 / col2 , col1 / literal or literal / col1 
            col1 // col2 , col1 // literal or literal // col1 
            col1 % col2 , col1 % literal or literal % col1 
            col1 ** col2 , col1 ** literal or literal ** col1 
        # logical operators, elementwise 
            col1 == col2 , col1 == literal or literal == col1 
            col1 != col2 , col1 != literal or literal != col1 
            col1 >= col2 , col1 >= literal or literal >= col1 
            col1 > col2 , col1 > literal or literal > col1 
            col1 <= col2 , col1 <= literal or literal <= col1 
            col1 < col2 , col1 < literal or literal < col1         
    rlike(regex)
        Return a Boolean Column based on a regex match.
        >>> df.filter(df.name.rlike('ice$')).collect()
        [Row(age=2, name=u'Alice')]  
    like(SQL_LIKE_pattern)
        Return a Boolean Column based on a SQL LIKE match.
        >>> df.filter(df.name.like('Al%')).collect()
        [Row(age=2, name=u'Alice')]
        
    startswith(string)
        Return a Boolean Column based on a string match.
        >>> df.filter(df.name.startswith('Al')).collect()
        [Row(age=2, name=u'Alice')]
        >>> df.filter(df.name.startswith('^Al')).collect()
        []
    endswith(string)
        Return a Boolean Column based on matching end of string.
        >>> df.filter(df.name.endswith('ice')).collect()
        [Row(age=2, name=u'Alice')]
        >>> df.filter(df.name.endswith('ice$')).collect()
        []    
    isNull()
        True if the current expression is null. 
        Often combined with DataFrame.filter to select rows with null values.
        >>> from pyspark.sql import Row
        >>> df2 = sc.parallelize([Row(name=u'Tom', height=80), Row(name=u'Alice', height=None)]).toDF()
        >>> df2.filter(df2.height.isNull()).collect()
        [Row(height=None, name=u'Alice')]
    isNotNull()
        True if the current expression is null. 
        Often combined with  DataFrame.filter to select rows with non-null values.
        >>> from pyspark.sql import Row
        >>> df2 = sc.parallelize([Row(name=u'Tom', height=80), Row(name=u'Alice', height=None)]).toDF()
        >>> df2.filter(df2.height.isNotNull()).collect()
        [Row(height=80, name=u'Tom')]
        
    alias(*alias),name(*alias)
        Returns this column aliased with a new name 
        or names (in the case of expressions that return more than one column, such as explode).
        >>> df.select(df.age.alias("age2")).collect()
        [Row(age2=2), Row(age2=5)]
    asc()
    desc()
        Returns a sort expression based on the ascending/descending order of the given column name.
    between(lowerBound, upperBound)
        A boolean expression that is evaluated to true 
        if the value of this expression is between the given columns.
        >>> df.select(df.name, df.age.between(2, 4)).show()
        +-----+---------------------------+
        | name|((age >= 2) AND (age <= 4))|
        +-----+---------------------------+
        |Alice|                       true|
        |  Bob|                      false|
        +-----+---------------------------+
    cast(dataType)
    astype(dataType)
        Convert the column into type dataType (dataType can be simpleString of Datatype)
        >>> df.select(df.age.cast("string").alias('ages')).collect()
        [Row(ages=u'2'), Row(ages=u'5')]
        >>> df.select(df.age.cast(StringType()).alias('ages')).collect()
        [Row(ages=u'2'), Row(ages=u'5')]
        
    getField(name)
        An expression that gets a field by name in a StructField.
        >>> from pyspark.sql import Row
        >>> df = sc.parallelize([Row(r=Row(a=1, b="b"))]).toDF()
        >>> df.select(df.r.getField("b")).show()
        +---+
        |r.b|
        +---+
        |  b|
        +---+
        >>> df.select(df.r.a).show()
        +---+
        |r.a|
        +---+
        |  1|
        +---+
    getItem(key)
        An expression that gets an item at index position out of a list, 
        or gets an item by key out of a dict.
        >>> df = sc.parallelize([ ([1, 2], {"key": "value"}) ]).toDF(["l", "d"])
        >>> df.select(df.l.getItem(0), df.d.getItem("key")).show()
        +----+------+
        |l[0]|d[key]|
        +----+------+
        |   1| value|
        +----+------+
        >>> df.select(df.l[0], df.d["key"]).show()
        +----+------+
        |l[0]|d[key]|
        +----+------+
        |   1| value|
        +----+------+

    isin(*cols)
        A boolean expression that is evaluated to true 
        if the value of this expression is contained by the evaluated values of the arguments.
        >>> df[df.name.isin("Bob", "Mike")].collect()
        [Row(age=5, name=u'Bob')]
        >>> df[df.age.isin([1, 2, 3])].collect()
        [Row(age=2, name=u'Alice')]
    over(window)
        Define a windowing column.
        >>> from pyspark.sql import Window
        >>> window = Window.partitionBy("name").orderBy("age").rowsBetween(-1, 1)
        >>> from pyspark.sql.functions import rank, min
        >>> df.select(rank().over(window), min('age').over(window))
    substr(startPos, length)
        Return a Column which is a substring of the column.
        >>> df.select(df.name.substr(1, 3).alias("col")).collect()
        [Row(col=u'Ali'), Row(col=u'Bob')]
        
    when(condition, value)
    otherwise(value)
        Evaluates a list of conditions 
        and returns one of multiple possible result expressions. 
        >>> from pyspark.sql import functions as F
        >>> df.select(df.name, F.when(df.age > 4, 1).when(df.age < 3, -1).otherwise(0)).show()
        +-----+------------------------------------------------------------+
        | name|CASE WHEN (age > 4) THEN 1 WHEN (age < 3) THEN -1 ELSE 0 END|
        +-----+------------------------------------------------------------+
        |Alice|                                                          -1|
        |  Bob|                                                           1|
        +-----+------------------------------------------------------------+
    
 


###Spark - DataFrame - pyspark.sql.functions Reference 
df = sc.parallelize([Row(name='Alice', age=2), Row(name='Bob', age=5)]).toDF()

    
pyspark.sql.functions module
    A collections of builtin functions operates on Column
        Use as 
            from pyspark.sql import functions as F
            df.select(F.func(col),...)
        where col is DF col eg df.colName or df["colName"] or string of colName 
        or any column expression via Column.method()
        or any functions of pyspark.sql.functions as many functions return Column
        Note *cols means list of column names (string) or list of Column expressions
        or variable number of column names or Columns 
    Note these functions work on each cell value of a Column 
    or if functions take other Columns, then elementwise 
    Means, result would be another Column with each cell value resulting from functions operation 
    
    #Aggregate function
    Use inside of agg of df.groupBy(...).agg(F.func(col),..) or df.agg(F.func(col),...)
    avg(col)
        returns the average of the values in a group.
        >>> df.agg(F.avg("age"), F.min("age")).show()
        +--------+--------+
        |avg(age)|min(age)|
        +--------+--------+
        |     3.5|       2|
        +--------+--------+
        >>> df.groupBy("name").agg(F.avg("age"), F.min("age")).show()
        +-----+--------+--------+
        | name|avg(age)|min(age)|
        +-----+--------+--------+
        |  Bob|     5.0|       5|
        |Alice|     2.0|       2|
        +-----+--------+--------+ 
    count(col)
        returns the number of items in a group.
    countDistinct(col, *cols)
        Returns a new Column for distinct count of col or cols.
        >>> df.agg(countDistinct(df.age, df.name).alias('c')).collect()
        [Row(c=2)]
        >>> df.agg(countDistinct("age", "name").alias('c')).collect()
        [Row(c=2)]            
    first(col, ignorenulls=False)
        returns the first value in a group.
    grouping(col)
        indicates whether a specified column in a GROUP BY list is aggregated or not, 
        returns 1 for aggregated or 0 for not aggregated in the result set.
        >>> df.cube("name").agg(grouping("name"), sum("age")).orderBy("name").show()
        +-----+--------------+--------+
        | name|grouping(name)|sum(age)|
        +-----+--------------+--------+
        | null|             1|       7|
        |Alice|             0|       2|
        |  Bob|             0|       5|
        +-----+--------------+--------+
    grouping_id(*cols)
        returns the level of grouping, equals to
            (grouping(c1) << (n-1)) + (grouping(c2) << (n-2)) + ... + grouping(cn)
        The list of columns should match with grouping columns exactly, 
        or empty (means all the grouping columns). 
        >>> df.cube("name").agg(grouping_id(), sum("age")).orderBy("name").show()
        +-----+-------------+--------+
        | name|grouping_id()|sum(age)|
        +-----+-------------+--------+
        | null|            1|       7|
        |Alice|            0|       2|
        |  Bob|            0|       5|
        +-----+-------------+--------+
    kurtosis(col)
        returns the kurtosis of the values in a group.
    last(col, ignorenulls=False)
        returns the last value in a group.
    max(col)
        returns the maximum value of the expression in a group.
    mean(col)
        returns the average of the values in a group.
    min(col)
        returns the minimum value of the expression in a group.
    skewness(col)
        returns the skewness of the values in a group.
    stddev(col)
        returns the unbiased sample standard deviation of the expression in a group.
    stddev_pop(col)
        returns population standard deviation of the expression in a group.
    stddev_samp(col)
        returns the unbiased sample standard deviation of the expression in a group.
    sum(col)
        returns the sum of all values in the expression.
    sumDistinct(col)
        returns the sum of distinct values in the expression.
    var_pop(col)
        returns the population variance of the values in a group.
    var_samp(col)
        returns the unbiased variance of the values in a group.
    variance(col)
        returns the population variance of the values in a group.    
            

    #Window function 
    To be used as F.func(col).over(window)
    Note other functions also can be used as 'func' eg 'min', 'max'
        from pyspark.sql import Window
        # PARTITION BY country ORDER BY date RANGE BETWEEN 3 PRECEDING AND 3 FOLLOWING
        window = Window.orderBy("date").partitionBy("country").rangeBetween(-3, 3) 
        #rangeBetween means  +/- of row's value, rowsBetween means +/- few rows around current row 
        from pyspark.sql.functions import rank, min
        df.select(rank().over(window), min('age').over(window))
    cume_dist()
        returns the cumulative distribution of values within a window partition, 
        i.e. the fraction of rows that are below the current row.
    dense_rank()
        returns the rank of rows within a window partition, without any gaps.
    rank()
        returns the rank of rows within a window partition.
        The difference between rank and denseRank is that 
        denseRank leaves no gaps in ranking sequence when there are ties. 
        For example, if you were ranking a competition using denseRank 
        and had three people tie for second place, you would say that all three were in second place 
        and that the next person came in third.
        Rank would give  sequential numbers, making the person that came in third place 
        (after the ties) would register as coming in fifth.
    lag(col, count=1, default=None)
        returns the value that is offset rows before the current row, 
        and defaultValue if there is less than offset rows before the current row. 
        For example, an offset of one will return the previous row at any given point 
        in the window partition.
    lead(col, count=1, default=None)
        returns the value that is offset rows after the current row
    ntile(n)
        returns the ntile group id (from 1 to n inclusive) 
        in an ordered window partition. 
        For example, if n is 4, the first quarter of the rows will get value 1, 
        the second quarter will get 2, the third quarter will get 3, 
        and the last quarter will get 4.
    percent_rank()
        returns the relative rank (i.e. percentile) of rows within a window partition.
    row_number()
        returns a sequential number starting at 1 within a window partition.

    #Collection functions
    array(*cols)
        Creates a new array column.
        Each cell would contain array of original columns cell value 
        Note array, map , struct column can be accessed based on index, key or field 
        from Column.getItem(key) or Column.getField(name)
        >>> df.select(array('age', 'age').alias("arr")).collect()
        [Row(arr=[2, 2]), Row(arr=[5, 5])]
        >>> df.select(array([df.age, df.age]).alias("arr")).collect()
        [Row(arr=[2, 2]), Row(arr=[5, 5])]
    create_map(*cols)
        Creates a new map column.
        >>> df.select(create_map('name', 'age').alias("map")).collect()
        [Row(map={u'Alice': 2}), Row(map={u'Bob': 5})]
        >>> df.select(create_map([df.name, df.age]).alias("map")).collect()
        [Row(map={u'Alice': 2}), Row(map={u'Bob': 5})]
    struct(*cols)
        Creates a new struct column.
        >>> df.select(struct('age', 'name').alias("struct")).collect()
        [Row(struct=Row(age=2, name=u'Alice')), Row(struct=Row(age=5, name=u'Bob'))]
        >>> df.select(struct([df.age, df.name]).alias("struct")).collect()
        [Row(struct=Row(age=2, name=u'Alice')), Row(struct=Row(age=5, name=u'Bob'))]
    collect_list(col)
        returns a list of all col values with duplicates.
        >>> df2 = spark.createDataFrame([(2,), (5,), (5,)], ('age',))
        >>> df2.agg(collect_list('age')).collect()
        [Row(collect_list(age)=[2, 5, 5])]
    collect_set(col)
        returns a set of objects with duplicate elements eliminated.
        >>> df2 = spark.createDataFrame([(2,), (5,), (5,)], ('age',))
        >>> df2.agg(collect_set('age')).collect()
        [Row(collect_set(age)=[5, 2])]
    array_contains(col, value)
        >>> df = spark.createDataFrame([(["a", "b", "c"],), ([],)], ['data'])
        >>> df.select(array_contains(df.data, "a")).collect()
        [Row(array_contains(data, a)=True), Row(array_contains(data, a)=False)]
    size(col)
        returns the length of the array or map stored in the column.
        >>> df = spark.createDataFrame([([1, 2, 3],),([1],),([],)], ['data'])
        >>> df.select(size(df.data)).collect()
        [Row(size(data)=3), Row(size(data)=1), Row(size(data)=0)]
    sort_array(col, asc=True)
        sorts the input array in ascending or descending order 
        according to the natural ordering of the array elements.
        >>> df = spark.createDataFrame([([2, 1, 3],),([1],),([],)], ['data'])
        >>> df.select(sort_array(df.data).alias('r')).collect()
        [Row(r=[1, 2, 3]), Row(r=[1]), Row(r=[])]
        >>> df.select(sort_array(df.data, asc=False).alias('r')).collect()
        [Row(r=[3, 2, 1]), Row(r=[1]), Row(r=[])]          

    #Mathematical functions 
    To be used with Numeric columns 
    abs(col)
        Computes the absolute value.
    acos(col)
    cbrt(col)
        Computes the cube-root of the given value.
    ceil(col)
        Computes the ceiling of the given value.
    floor(col)
        Computes the floor of the given value.
    asin(col)
    atan(col)
    atan2(col1, col2)
    cos(col)
    cosh(col)
    bitwiseNOT(col)
    exp(col)
        Computes the exponential of the given value.
    expm1(col)
        Computes the exponential of the given value minus one.
    bround(col, scale=0)
        Round the given value to scale decimal places using HALF_EVEN rounding mode if scale >= 0 or at integral part when scale < 0.
        >>> spark.createDataFrame([(2.5,)], ['a']).select(bround('a', 0).alias('r')).collect()
        [Row(r=2.0)]   
    log(arg1, arg2=None)
        Returns the first argument-based logarithm of the second argument.
    log10(col)
        Computes the logarithm of the given value in Base 10.
    log1p(col)
        Computes the natural logarithm of the given value plus one.
    log2(col)
        Returns the base-2 logarithm of the argument.
    pow(col1, col2)
        Returns the value of the first argument raised to the power of the second argument.
    rint(col)
        Returns the double value that is closest in value to the argument 
        and is equal to a mathematical integer.
    round(col, scale=0)
        Round the given value to scale decimal places using HALF_UP rounding mode 
    signum(col)
        Computes the signum of the given value.
    sin(col)
        Computes the sine of the given value.
    sinh(col)
        Computes the hyperbolic sine of the given value.        
    sqrt(col)
        Computes the square root of the specified float value. 
    tan(col)
        Computes the tangent of the given value.
    tanh(col)
        Computes the hyperbolic tangent of the given value.
    hypot(col1, col2)
        Computes sqrt(a^2 + b^2) without intermediate overflow or underflow.
    factorial(col)
        Computes the factorial of the given value.
        >>> df = spark.createDataFrame([(5,)], ['n'])
        >>> df.select(factorial(df.n).alias('f')).collect()
        [Row(f=120)]    
    isnan(col)
        An expression that returns true iff the column is NaN.
        >>> df = spark.createDataFrame([(1.0, float('nan')), (float('nan'), 2.0)], ("a", "b"))
        >>> df.select(isnan("a").alias("r1"), isnan(df.a).alias("r2")).collect()
        [Row(r1=False, r2=False), Row(r1=True, r2=True)]
    isnull(col)
        An expression that returns true iff the column is null.
        >>> df = spark.createDataFrame([(1, None), (None, 2)], ("a", "b"))
        >>> df.select(isnull("a").alias("r1"), isnull(df.a).alias("r2")).collect()
        [Row(r1=False, r2=False), Row(r1=True, r2=True)]
    shiftLeft(col, numBits)
        Shift the given value numBits left.
    shiftRight(col, numBits)
        (Signed) shift the given value numBits right.
    shiftRightUnsigned(col, numBits)
        Unsigned shift the given value numBits right.        
    nanvl(col1, col2)
        Returns col1 if it is not NaN, or col2 if col1 is NaN.
        >>> df = spark.createDataFrame([(1.0, float('nan')), (float('nan'), 2.0)], ("a", "b"))
        >>> df.select(nanvl("a", "b").alias("r1"), nanvl(df.a, df.b).alias("r2")).collect()
        [Row(r1=1.0, r2=1.0), Row(r1=2.0, r2=2.0)]        
   
    #Misc functions 
    expr(str)
        Parses the expression string into the column that it represents
        >>> df.select(expr("length(name)")).collect()
        [Row(length(name)=5), Row(length(name)=3)]
    asc(col)
    desc(col)
        Returns a sort expression based on the as/decending order of the given column name.
    col(col)
    column(col)
        Returns a Column based on the given column name.
    lit(literal)
        Creates a Column of literal value.
    greatest(*cols)
        Returns the greatest value of the list of column names, 
        skipping null values. 
        This function takes at least 2 parameters. 
        It will return null iff all parameters are null.
        >>> df = spark.createDataFrame([(1, 4, 3)], ['a', 'b', 'c'])
        >>> df.select(greatest(df.a, df.b, df.c).alias("greatest")).collect()
        [Row(greatest=4)]
    least(*cols)
        Returns the least value of the list of column names, skipping null values. 
        This function takes at least 2 parameters. It will return null iff all parameters are null.
        >>> df = spark.createDataFrame([(1, 4, 3)], ['a', 'b', 'c'])
        >>> df.select(least(df.a, df.b, df.c).alias("least")).collect()
        [Row(least=1)]
    coalesce(*cols)
        Returns the first non null column value across *cols 
        >>> cDf = spark.createDataFrame([(None, None), (1, None), (None, 2)], ("a", "b"))
        >>> cDf.show()
        +----+----+
        |   a|   b|
        +----+----+
        |null|null|
        |   1|null|
        |null|   2|
        +----+----+
        >>> cDf.select(coalesce(cDf["a"], cDf["b"])).show()
        +--------------+
        |coalesce(a, b)|
        +--------------+
        |          null|
        |             1|
        |             2|
        +--------------+
        >>> cDf.select('*', coalesce(cDf["a"], lit(0.0))).show()
        +----+----+----------------+
        |   a|   b|coalesce(a, 0.0)|
        +----+----+----------------+
        |null|null|             0.0|
        |   1|null|             1.0|
        |null|   2|             0.0|
        +----+----+----------------+
    input_file_name()
        Creates a string column for the file name of the current Spark task.
    broadcast(df)
        Marks a DataFrame as small enough for use in broadcast joins.  
    spark_partition_id()
        A column for partition ID.
        >>> df.repartition(1).select(spark_partition_id().alias("pid")).collect()
        [Row(pid=0), Row(pid=0)]   
        
    #String functions 
    concat(*cols)
        Concatenates multiple input string columns together into a single string column.
        >>> df = spark.createDataFrame([('abcd','123')], ['s', 'd'])
        >>> df.select(concat(df.s, df.d).alias('s')).collect()
        [Row(s=u'abcd123')]
    concat_ws(sep, *cols)
        Concatenates multiple input string columns together into a single string column,
        using the given separator.       
    decode(col, charset)
        Computes the first argument into a string from a binary 
        using the provided character set (one of 'US-ASCII', 'ISO-8859-1', 'UTF-8', 'UTF-16BE', 'UTF-16LE', 'UTF-16').
    encode(col, charset)
        Computes the first argument into a binary from a string 
        using the provided character set (one of 'US-ASCII', 'ISO-8859-1', 'UTF-8', 'UTF-16BE', 'UTF-16LE', 'UTF-16').
    format_number(col, d)
        Formats the number X to a format like '#,�#,�#.�', rounded to d decimal places, 
        and returns the result as a string.
        >>> spark.createDataFrame([(5,)], ['a']).select(format_number('a', 4).alias('v')).collect()
        [Row(v=u'5.0000')]
    format_string(format, *cols)
        Formats the arguments in printf-style and returns the result as a string column.
        >>> df = spark.createDataFrame([(5, "hello")], ['a', 'b'])
        >>> df.select(format_string('%d %s', df.a, df.b).alias('v')).collect()
        [Row(v=u'5 hello')]        
    conv(col, fromBase, toBase)
        Convert a number in a string column from one base to another.
        >>> df = spark.createDataFrame([("010101",)], ['n'])
        >>> df.select(conv(df.n, 2, 16).alias('hex')).collect()
        [Row(hex=u'15')]      
    ascii(col)
        Computes the numeric value of the first character of the string column.
    initcap(col)
        Translate the first letter of each word to upper case in the sentence.
    instr(str, substr)
        Locate the position of the first occurrence of substr column in the given string. Returns null if either of the arguments are null.
        >>> df = spark.createDataFrame([('abcd',)], ['s',])
        >>> df.select(instr(df.s, 'b').alias('s')).collect()
        [Row(s=2)]
    length(col)
        Calculates the length of a string or binary expression.
        >>> spark.createDataFrame([('ABC',)], ['a']).select(length('a').alias('length')).collect()
        [Row(length=3)]
    levenshtein(left, right)
        Computes the Levenshtein distance of the two given strings.
        >>> df0 = spark.createDataFrame([('kitten', 'sitting',)], ['l', 'r'])
        >>> df0.select(levenshtein('l', 'r').alias('d')).collect()
        [Row(d=3)]
    locate(substr, str, pos=1)
        Locate the position of the first occurrence of substr in a string column, after position pos.
        >>> df = spark.createDataFrame([('abcd',)], ['s',])
        >>> df.select(locate('b', df.s, 1).alias('s')).collect()
        [Row(s=2)]
    lower(col)
        Converts a string column to lower case.
    lpad(col, len, pad)
        Left-pad the string column to width len with pad.
    ltrim(col)
        Trim the spaces from left end for the specified string value.
    repeat(col, n)
        Repeats a string column n times, and returns it as a new string column.
        >>> df = spark.createDataFrame([('ab',)], ['s',])
        >>> df.select(repeat(df.s, 3).alias('s')).collect()
        [Row(s=u'ababab')]
    reverse(col)
        Reverses the string column and returns it as a new string column.
    rpad(col, len, pad)
        Right-pad the string column to width len with pad.
    rtrim(col)
        Trim the spaces from right end for the specified string value.
    substring(str, pos, len)
        Substring starts at pos and is of length len when str is String type or returns the slice of byte array that starts at pos in byte and is of length len when str is Binary type
        >>> df = spark.createDataFrame([('abcd',)], ['s',])
        >>> df.select(substring(df.s, 1, 2).alias('s')).collect()
        [Row(s=u'ab')]
    substring_index(str, delim, count)
        Returns the substring from string str before count occurrences of the delimiter delim. If count is positive, everything the left of the final delimiter (counting from left) is returned. If count is negative, every to the right of the final delimiter (counting from the right) is returned. substring_index performs a case-sensitive match when searching for delim.
        >>> df = spark.createDataFrame([('a.b.c.d',)], ['s'])
        >>> df.select(substring_index(df.s, '.', 2).alias('s')).collect()
        [Row(s=u'a.b')]
        >>> df.select(substring_index(df.s, '.', -3).alias('s')).collect()
        [Row(s=u'b.c.d')]
    translate(srcCol, matching, replace)
        A function translate any character in the srcCol by a character in matching. The characters in replace is corresponding to the characters in matching. The translate will happen when any character in the string matching with the character in the matching.
        >>> spark.createDataFrame([('translate',)], ['a']).select(translate('a', "rnlt", "123") \
        ...     .alias('r')).collect()
        [Row(r=u'1a2s3ae')]
    trim(col)
        Trim the spaces from both ends for the specified string column.
    upper(col)
        Converts a string column to upper case.
        
    #Regex functions 
    regexp_extract(col, pattern, idx)
            idx = particular group id to return 
        Extract a specific group matched by a Java regex, from the specified string column. 
        If the regex did not match, or the specified group did not match, an empty string is returned.
        >>> df = spark.createDataFrame([('100-200',)], ['str'])
        >>> df.select(regexp_extract('str', '(\d+)-(\d+)', 1).alias('d')).collect()
        [Row(d=u'100')]
        >>> df = spark.createDataFrame([('foo',)], ['str'])
        >>> df.select(regexp_extract('str', '(\d+)', 1).alias('d')).collect()
        [Row(d=u'')]
        >>> df = spark.createDataFrame([('aaaac',)], ['str'])
        >>> df.select(regexp_extract('str', '(a+)(b)?(c)', 2).alias('d')).collect()
        [Row(d=u'')]
    regexp_replace(col, pattern, replacement)
        Replace all substrings of the specified string value that match regexp with rep.
        >>> df = spark.createDataFrame([('100-200',)], ['str'])
        >>> df.select(regexp_replace('str', '(\d+)', '--').alias('d')).collect()
        [Row(d=u'-----')]
    split(col, pattern)
        Splits str around pattern (pattern is a regular expression).
        >>> df = spark.createDataFrame([('ab12cd',)], ['s',])
        >>> df.select(split(df.s, '[0-9]+').alias('s')).collect()
        [Row(s=[u'ab', u'cd'])]       

    #Date and time functions    
    Used with col is datetime.date or datetime.datetime Column or string of colName     
    current_date()
        Returns the current date as a 'date' column.
    current_timestamp()
        Returns the current timestamp as a 'timestamp' column.        
    add_months(col, months)
        Returns the date that is months months after start
        >>> df = spark.createDataFrame([('2015-04-08',)], ['d'])
        >>> df.select(add_months(df.d, 1).alias('d')).collect()
        [Row(d=datetime.date(2015, 5, 8))]    
    date_add(col, days)
        Returns the date that is days days after start
        >>> df = spark.createDataFrame([('2015-04-08',)], ['d'])
        >>> df.select(date_add(df.d, 1).alias('d')).collect()
        [Row(d=datetime.date(2015, 4, 9))]
    date_format(col, format)
        Converts a date/timestamp/string to a value of string in the format specified 
        eg pattern- dd.MM.yyyy from java.text.SimpleDateFormat
        >>> df = spark.createDataFrame([('2015-04-08',)], ['a'])
        >>> df.select(date_format('a', 'MM/dd/yyy').alias('date')).collect()
        [Row(date=u'04/08/2015')]
    date_sub(col, days)
        Returns the date that is days days before start
        >>> df = spark.createDataFrame([('2015-04-08',)], ['d'])
        >>> df.select(date_sub(df.d, 1).alias('d')).collect()
        [Row(d=datetime.date(2015, 4, 7))]
    datediff(col_end, col_start)
        Returns the number of days from start to end.
        >>> df = spark.createDataFrame([('2015-04-08','2015-05-10')], ['d1', 'd2'])
        >>> df.select(datediff(df.d2, df.d1).alias('diff')).collect()
        [Row(diff=32)]
    dayofmonth(col)
        Extract the day of the month of a given date as integer.
        >>> df = spark.createDataFrame([('2015-04-08',)], ['a'])
        >>> df.select(dayofmonth('a').alias('day')).collect()
        [Row(day=8)]
    dayofyear(col)
        Extract the day of the year of a given date as integer.        
    hour(col)
        Extract the hours of a given date as integer.
    last_day(col)
        Returns the last day of the month which the given date belongs to.
        >>> df = spark.createDataFrame([('1997-02-10',)], ['d'])
        >>> df.select(last_day(df.d).alias('date')).collect()
        [Row(date=datetime.date(1997, 2, 28))]        
    minute(col)
        Extract the minutes of a given date as integer.
        >>> df = spark.createDataFrame([('2015-04-08 13:08:15',)], ['a'])
        >>> df.select(minute('a').alias('minute')).collect()
        [Row(minute=8)]
    month(col)
        Extract the month of a given date as integer.
        >>> df = spark.createDataFrame([('2015-04-08',)], ['a'])
        >>> df.select(month('a').alias('month')).collect()
        [Row(month=4)]
    months_between(col_date1, col_date2)
        Returns the number of months between date1 and date2.
        >>> df = spark.createDataFrame([('1997-02-28 10:30:00', '1996-10-30')], ['t', 'd'])
        >>> df.select(months_between(df.t, df.d).alias('months')).collect()
        [Row(months=3.9495967...)]
    next_day(col, dayOfWeek)
        Returns the first date which is later than the value of the date column.
        Day of the week parameter is case insensitive, and accepts:'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'.
        >>> df = spark.createDataFrame([('2015-07-27',)], ['d'])
        >>> df.select(next_day(df.d, 'Sun').alias('date')).collect()
        [Row(date=datetime.date(2015, 8, 2))]
    quarter(col)
        Extract the quarter of a given date as integer.
        >>> df = spark.createDataFrame([('2015-04-08',)], ['a'])
        >>> df.select(quarter('a').alias('quarter')).collect()
        [Row(quarter=2)]   
    second(col)
            Extract the seconds of a given date as integer.
    weekofyear(col)
        Extract the week number of a given date as integer.
        >>> df = spark.createDataFrame([('2015-04-08',)], ['a'])
        >>> df.select(weekofyear(df.a).alias('week')).collect()
        [Row(week=15)]
    year(col)
        Extract the year of a given date as integer.
        >>> df = spark.createDataFrame([('2015-04-08',)], ['a'])
        >>> df.select(year('a').alias('year')).collect()
        [Row(year=2015)]
    trunc(col, format)
        Returns date truncated to the unit specified by the format.
        format � 'year', 'YYYY', 'yy' or 'month', 'mon', 'mm' 
        >>> df = spark.createDataFrame([('1997-02-28',)], ['d'])
        >>> df.select(trunc(df.d, 'year').alias('year')).collect()
        [Row(year=datetime.date(1997, 1, 1))]
        >>> df.select(trunc(df.d, 'mon').alias('month')).collect()
        [Row(month=datetime.date(1997, 2, 1))] 
        
    #Conversion functions 
    to_date(col)
        Converts the column of pyspark.sql.types.StringType 
        or pyspark.sql.types.TimestampType into pyspark.sql.types.DateType.
        >>> df = spark.createDataFrame([('1997-02-28 10:30:00',)], ['t'])
        >>> df.select(to_date(df.t).alias('date')).collect()
        [Row(date=datetime.date(1997, 2, 28))]
    to_json(col, options={})
        Converts a column containing a StructType into a JSON string. 
        Throws an exception, in the case of an unsupported type.
        >>> from pyspark.sql import Row
        >>> from pyspark.sql.types import *
        >>> data = [(1, Row(name='Alice', age=2))]
        >>> df = spark.createDataFrame(data, ("key", "value"))
        >>> df.select(to_json(df.value).alias("json")).collect()
        [Row(json=u'{"age":2,"name":"Alice"}')]
    to_utc_timestamp(col, tz)
        Given a timestamp, which corresponds to a certain time of day 
        in the given timezone, returns another timestamp that corresponds 
        to the same time of day in UTC.
        >>> df = spark.createDataFrame([('1997-02-28 10:30:00',)], ['t'])
        >>> df.select(to_utc_timestamp(df.t, "PST").alias('t')).collect()
        [Row(t=datetime.datetime(1997, 2, 28, 18, 30))]    
    from_json(col, schema, options={})
        Parses a column containing a JSON string into a StructType with the specified schema. 
        Returns null, in the case of an unparseable string.
        >>> from pyspark.sql.types import *
        >>> data = [(1, '''{"a": 1}''')]
        >>> schema = StructType([StructField("a", IntegerType())])
        >>> df = spark.createDataFrame(data, ("key", "value"))
        >>> df.select(from_json(df.value, schema).alias("json")).collect()
        [Row(json=Row(a=1))]
    from_unixtime(col_unixTimestamp, format='yyyy-MM-dd HH:mm:ss')
        Converts the number of seconds from unix epoch (1970-01-01 00:00:00 UTC) 
        to a string representing the timestamp of that moment in the current system time zone 
        in the given format.
    from_utc_timestamp(col_timestamp, tz)
        Given a timestamp, which corresponds to a certain time of day in UTC, 
        returns another timestamp that corresponds to the same time of day in the given timezone.
    get_json_object(col, path)
        Extracts json object from a json string based on json path specified, 
        and returns json string of the extracted json object. 
        It will return null if the input json string is invalid.
        >>> data = [("1", '''{"f1": "value1", "f2": "value2"}'''), ("2", '''{"f1": "value12"}''')]
        >>> df = spark.createDataFrame(data, ("key", "jstring"))
        >>> df.select(df.key, get_json_object(df.jstring, '$.f1').alias("c0"), \
                    get_json_object(df.jstring, '$.f2').alias("c1") ).collect()
        [Row(key=u'1', c0=u'value1', c1=u'value2'), Row(key=u'2', c0=u'value12', c1=None)]
    json_tuple(col, *fields)
        Creates a new row for a json column according to the given field names.
        >>> data = [("1", '''{"f1": "value1", "f2": "value2"}'''), ("2", '''{"f1": "value12"}''')]
        >>> df = spark.createDataFrame(data, ("key", "jstring"))
        >>> df.select(df.key, json_tuple(df.jstring, 'f1', 'f2')).collect()
        [Row(key=u'1', c0=u'value1', c1=u'value2'), Row(key=u'2', c0=u'value12', c1=None)]
    monotonically_increasing_id()
        A column that generates monotonically increasing 64-bit integers.
    degrees(col)
        Converts an angle measured in radians to an approximately equivalent angle measured in degrees.
    radians(col)
        Converts an angle measured in degrees to an approximately equivalent angle measured in radians.
    unbase64(col)
        Decodes a BASE64 encoded string column and returns it as a binary column.
    unhex(col)
        Inverse of hex. Interprets each pair of characters as a hexadecimal number and converts to the byte representation of number.
        >>> spark.createDataFrame([('414243',)], ['a']).select(unhex('a')).collect()
        [Row(unhex(a)=bytearray(b'ABC'))]
    unix_timestamp(col_timestamp, format='yyyy-MM-dd HH:mm:ss')
        Convert time string with given pattern ('yyyy-MM-dd HH:mm:ss', by default) 
        to Unix time stamp (in seconds), using the default timezone 
        and the default locale, return null if fail.

    #Advanced functions 
    udf(f, returnType=StringType)
        Creates a Column expression representing a user defined function (UDF) of f(col):returnType
        To use with sql query, must register with spark.udf.register 
        >>> from pyspark.sql.types import IntegerType
        >>> slen = udf(lambda s: len(s), IntegerType())
        >>> df.select(slen(df.name).alias('slen')).collect()
        [Row(slen=5), Row(slen=3)]
    when(condition, value)
            condition : Column with comparison operator 
            value : literal or Column expression
        Evaluates a list of conditions 
        and returns one of multiple possible result expressions. 
        If Column.otherwise() is not invoked, None is returned for unmatched conditions.
        >>> df.select(when(df['age'] == 2, 3).otherwise(4).alias("age")).collect()
        [Row(age=3), Row(age=4)]
        >>> df.select(when(df.age == 2, df.age + 1).alias("age")).collect()
        [Row(age=3), Row(age=None)]
        
    window(col_timestamp , windowDuration, slideDuration=None, startTime=None)
        Note this is time based window to be used witnin groupby(window(..)), 
        To have window based on current row +/- few rows or current row value +/- some range, 
        use Window class along with F.func(col).over(WindowClassInstance)        
        
        Bucketize rows into one or more time windows given a column with timestamp 
        Window starts are inclusive but the window ends are exclusive, 
        e.g. 12:05 will be in the window [12:05,12:10) but not in [12:00,12:05). 
        Windows can support microsecond precision. 
        Windows in the order of months are not supported.

        The time column must be of pyspark.sql.types.TimestampType.
        Durations(windowDuration, slideDuration)  are provided as strings, 
        e.g. '1 second', '1 day 12 hours', '2 minutes'.
        Valid interval strings are 'week', 'day', 'hour', 'minute', 'second', 'millisecond', 'microsecond'. 
        If the slideDuration is not provided, the windows will be tumbling windows.

        The startTime is the offset with respect to 1970-01-01 00:00:00 UTC 
        with which to start window intervals. 

        The output column will be a struct called 'window' by default 
        with the nested columns 'start' and 'end', 
        where 'start' and 'end' will be of pyspark.sql.types.TimestampType.
        
        >>> df = spark.createDataFrame([("2016-03-11 09:00:07", 1)]).toDF("date", "val")
        >>> w = df.groupBy(window("date", "5 seconds")).agg(sum("val").alias("sum"))
        >>> w.select(w.window.start.cast("string").alias("start"),
                w.window.end.cast("string").alias("end"), "sum").collect()
        [Row(start=u'2016-03-11 09:00:05', end=u'2016-03-11 09:00:10', sum=1)]
    explode(col)
        Returns a new row for each element in the given col containing array or map.
        >>> from pyspark.sql import Row
        >>> eDF = spark.createDataFrame([Row(a=1, intlist=[1,2,3], mapfield={"a": "b"})])
        >>> eDF.select(explode(eDF.intlist).alias("anInt")).collect()
        [Row(anInt=1), Row(anInt=2), Row(anInt=3)]
        >>> eDF.select(explode(eDF.mapfield).alias("key", "value")).show()
        +---+-----+
        |key|value|
        +---+-----+
        |  a|    b|
        +---+-----+
    posexplode(col)
        Returns a new row for each element with position in the given col containing array or map.
        >>> from pyspark.sql import Row
        >>> eDF = spark.createDataFrame([Row(a=1, intlist=[1,2,3], mapfield={"a": "b"})])
        >>> eDF.select(posexplode(eDF.intlist)).collect()
        [Row(pos=0, col=1), Row(pos=1, col=2), Row(pos=2, col=3)]
        >>> eDF.select(posexplode(eDF.mapfield)).show()
        +---+---+-----+
        |pos|key|value|
        +---+---+-----+
        |  0|  a|    b|
        +---+---+-----+
        
    #Code creation functions
    crc32(col)
        Calculates the cyclic redundancy check value (CRC32) of a binary column and returns the value as a bigint.
    base64(col)
    bin(col)
        Returns the string representation of the binary value of the given column.
        >>> df.select(bin(df.age).alias('c')).collect()
        [Row(c=u'10'), Row(c=u'101')]     
    hash(*cols)
        Calculates the hash code of given columns, 
        and returns the result as an int column.
        >>> spark.createDataFrame([('ABC',)], ['a']).select(hash('a').alias('hash')).collect()
        [Row(hash=-757602832)]
    hex(col)
        Computes hex value of the given column, 
        >>> spark.createDataFrame([('ABC', 3)], ['a', 'b']).select(hex('a'), hex('b')).collect()
        [Row(hex(a)=u'414243', hex(b)=u'3')]
    md5(col)
        Calculates the MD5 digest 
    sha1(col)
        Returns the hex string result of SHA-1.
    sha2(col, numBits)
        Returns the hex string result of SHA-2 family of hash functions (SHA-224, SHA-256, SHA-384, and SHA-512)
    soundex(col)
        Returns the SoundEx encoding for a string
        
    #Statistical functions
    approxCountDistinct(col, rsd=None)
    approx_count_distinct(col, rsd=None)
    corr(col1, col2)
        Returns a new Column for the Pearson Correlation Coefficient for col1 and col2.
        >>> a = range(20)
        >>> b = [2 * x for x in range(20)]
        >>> df = spark.createDataFrame(zip(a, b), ["a", "b"])
        >>> df.agg(corr("a", "b").alias('c')).collect()
        [Row(c=1.0)]
    covar_pop(col1, col2)
        Returns a new Column for the population covariance of col1 and col2.
        >>> a = [1] * 10
        >>> b = [1] * 10
        >>> df = spark.createDataFrame(zip(a, b), ["a", "b"])
        >>> df.agg(covar_pop("a", "b").alias('c')).collect()
        [Row(c=0.0)]
    covar_samp(col1, col2)
        Returns new Column for sample covariance     
    rand(seed=None)
        Generates a random column with independent and identically distributed (i.i.d.) samples from U[0.0, 1.0].
    randn(seed=None)
        Generates a column with independent and identically distributed (i.i.d.) samples from the standard normal distribution.


        
        
###Spark - DataFrames - Special clasess - GroupedData, DataFrameNaFunctions, DataFrameStatFunctions, Window, WindowSpec
df = sc.parallelize([(2, 'Alice'), (5, 'Bob')]) \
    .toDF(StructType([StructField('age', IntegerType()),
                      StructField('name', StringType())]))
df3 = sc.parallelize([Row(name='Alice', age=2, height=80),
                           Row(name='Bob', age=5, height=85)]).toDF()
df4 = sc.parallelize([Row(course="dotNET", year=2012, earnings=10000),
                           Row(course="Java",   year=2012, earnings=20000),
                           Row(course="dotNET", year=2012, earnings=5000),
                           Row(course="dotNET", year=2013, earnings=48000),
                           Row(course="Java",   year=2013, earnings=30000)]).toDF()


                                   
class pyspark.sql.GroupedData(jgd, sql_ctx)
        Returned by df.groupBy(*cols)
        below functions return DataFrame, hence DataFrame methods can be used 
    agg(*exprs)
        Supported are avg, max, min, sum, count.
        exprs � a dict mapping from column name (string) to aggregate functions (string),  
                or a list of Column involving aggregation functions of pyspark.sql.function 
        >>> gdf = df.groupBy(df.name)
        >>> sorted(gdf.agg({"*": "count"}).collect())
        [Row(name=u'Alice', count(1)=1), Row(name=u'Bob', count(1)=1)]
        >>> from pyspark.sql import functions as F
        >>> sorted(gdf.agg(F.min(df.age)).collect())
        [Row(name=u'Alice', min(age)=2), Row(name=u'Bob', min(age)=5)]
    avg(*cols)
    mean(*cols)
        Computes average values for each numeric columns for each group.
        mean() is an alias for avg().
        >>> df.groupBy().avg('age').collect()
        [Row(avg(age)=3.5)]
        >>> df3.groupBy().avg('age', 'height').collect()
        [Row(avg(age)=3.5, avg(height)=82.5)]
    count()
        Counts the number of records for each group.
        >>> sorted(df.groupBy(df.age).count().collect())
        [Row(age=2, count=1), Row(age=5, count=1)]
    max(*cols)
    min(*cols)
        Computes the max/min value for each numeric columns for each group.
        >>> df.groupBy().max('age').collect()
        [Row(max(age)=5)]
        >>> df3.groupBy().max('age', 'height').collect()
        [Row(max(age)=5, max(height)=85)]
    sum(*cols)
        Compute the sum for each numeric columns for each group.
        >>> df.groupBy().sum('age').collect()
        [Row(sum(age)=7)]
        >>> df3.groupBy().sum('age', 'height').collect()
        [Row(sum(age)=7, sum(height)=165)]
    pivot(pivot_col, values=None)
        Returns GroupedData, hence you can call GroupedData aggregation method on returns 
        
        It Performs specified aggregation on each of 'values' of 'pivot_col'
        There are two versions of pivot function: 
         one that requires the caller to specify the list of distinct values to pivot on, 
         one that does not. 
        The latter is more concise but less efficient
        �pivot_col � Name of the column to pivot.
        �values � List of values of pivot_col on which aggregation is computed
        # Compute the sum of earnings for each year when course=dotNet and course=Java 
        #result data frame contains year, dotnet=sum(earnings) and java=sum(earnings)
        >>> df4.groupBy("year").pivot("course", ["dotNET", "Java"]).sum("earnings").collect()
        [Row(year=2012, dotNET=15000, Java=20000), Row(year=2013, dotNET=48000, Java=30000)]
        # Or without specifying column values (less efficient)
        >>> df4.groupBy("year").pivot("course").sum("earnings").collect()
        [Row(year=2012, Java=20000, dotNET=15000), Row(year=2013, Java=30000, dotNET=48000)]



##DataFrameNaFunctions
df = sc.parallelize([(2, 'Alice'), (5, 'Bob')])\
    .toDF(StructType([StructField('age', IntegerType()),
                      StructField('name', StringType())]))
df2 = sc.parallelize([Row(name='Tom', height=80), Row(name='Bob', height=85)]).toDF()
df3 = sc.parallelize([Row(name='Alice', age=2),
                               Row(name='Bob', age=5)]).toDF()
df4 = sc.parallelize([Row(name='Alice', age=10, height=80),
                               Row(name='Bob', age=5, height=None),
                               Row(name='Tom', age=None, height=None),
                               Row(name=None, age=None, height=None)]).toDF()
sdf = sc.parallelize([Row(name='Tom', time=1479441846),
                               Row(name='Bob', time=1479442946)]).toDF()


class pyspark.sql.DataFrameNaFunctions(df)
        Returned by df.na and used for manipulating NA values 
    drop(how='any', thresh=None, subset=None)
        Returns a new DataFrame omitting rows with null values. 
        DataFrame.dropna() and DataFrameNaFunctions.drop() are aliases of each other.
        >>> df4.na.drop().show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        | 10|    80|Alice|
        +---+------+-----+
    fill(value, subset=None)
        Replace null values, alias for na.fill(). 
        DataFrame.fillna() and DataFrameNaFunctions.fill() are aliases 
        >>> df4.na.fill(50).show()
        +---+------+-----+
        |age|height| name|
        +---+------+-----+
        | 10|    80|Alice|
        |  5|    50|  Bob|
        | 50|    50|  Tom|
        | 50|    50| null|
        +---+------+-----+
        >>> df4.na.fill({'age': 50, 'name': 'unknown'}).show()
        +---+------+-------+
        |age|height|   name|
        +---+------+-------+
        | 10|    80|  Alice|
        |  5|  null|    Bob|
        | 50|  null|    Tom|
        | 50|  null|unknown|
        +---+------+-------+
    replace(to_replace, value, subset=None)
        Returns a new DataFrame replacing a value with another value. 
        DataFrame.replace() and DataFrameNaFunctions.replace() are aliases 
        >>> df4.na.replace(10, 20).show()
        +----+------+-----+
        | age|height| name|
        +----+------+-----+
        |  20|    80|Alice|
        |   5|  null|  Bob|
        |null|  null|  Tom|
        |null|  null| null|
        +----+------+-----+
        >>> df4.na.replace(['Alice', 'Bob'], ['A', 'B'], 'name').show()
        +----+------+----+
        | age|height|name|
        +----+------+----+
        |  10|    80|   A|
        |   5|  null|   B|
        |null|  null| Tom|
        |null|  null|null|
        +----+------+----+

##DataFrameStatFunctions
df = sc.parallelize([(2, 'Alice'), (5, 'Bob')])\
        .toDF(StructType([StructField('age', IntegerType()),
                          StructField('name', StringType())]))
df2 = sc.parallelize([Row(name='Tom', height=80), Row(name='Bob', height=85)]).toDF()
df3 = sc.parallelize([Row(name='Alice', age=2),
                               Row(name='Bob', age=5)]).toDF()
df4 = sc.parallelize([Row(name='Alice', age=10, height=80),
                               Row(name='Bob', age=5, height=None),
                               Row(name='Tom', age=None, height=None),
                               Row(name=None, age=None, height=None)]).toDF()
sdf = sc.parallelize([Row(name='Tom', time=1479441846),
                               Row(name='Bob', time=1479442946)]).toDF()


class pyspark.sql.DataFrameStatFunctions(df)
        Returned by df.stat
    approxQuantile(col, probabilities, relativeError)
    corr(col1, col2, method=None)
    cov(col1, col2)
    crosstab(col1, col2)
    freqItems(cols, support=None)
    sampleBy(col, fractions, seed=None)
        >>> from pyspark.sql.functions import col
        >>> dataset = sqlContext.range(0, 100).select((col("id") % 3).alias("key"))
        >>> sampled = dataset.sampleBy("key", fractions={0: 0.1, 1: 0.2}, seed=0)
        >>> sampled.groupBy("key").count().orderBy("key").show()
        +---+-----+
        |key|count|
        +---+-----+
        |  0|    5|
        |  1|    9|
        +---+-----+


##Window
class pyspark.sql.WindowSpec(jspec)
    Use the classmethod methods in Window to create a WindowSpec.
    
class pyspark.sql.Window
    Creation of WindowSpec to be used with Column.over(WindowSpec)
    For time based window use functions.window(..) inside df.groupby
    All these classmethod returns Window, hence can be chained  
    Rows between means current row +/- few rows (could be unboundedPreceding, unboundedFollowing) 
    Range between means current row value +/- value range(could be -Inf, +Inf as np.iinfo(np.int64).max/min) 
    PartitionBy on cols are must 
        from pyspark.sql import Window
        # ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        window = Window.orderBy("date").rowsBetween(Window.unboundedPreceding, Window.currentRow)
        # PARTITION BY country ORDER BY date RANGE BETWEEN 3 PRECEDING AND 3 FOLLOWING
        window = Window.orderBy("date").partitionBy("country").rangeBetween(-3, 3)
        from pyspark.sql.functions import rank, min
        df.select(rank().over(window), min('age').over(window))
    classmethod  orderBy(*cols)
        Creates a WindowSpec with the ordering defined.        
    classmethod partitionBy(*cols)
        Creates a WindowSpec with the partitioning defined.
    classmethod rangeBetween(start, end)
    classmethod rowsBetween(start, end)
        Creates a WindowSpec with the frame boundaries defined
        from start (inclusive) to end (inclusive).
        Both start and end are relative from the current row. 
        For example, '0' means 'current row', 
        while '-1' means one off before the current row, 
        and '5' means the five off after the current row.
    unboundedFollowing = 9223372036854775807
    unboundedPreceding = -9223372036854775808L
    currentRow = 0
    #difference between rangeBetween and rowsBetween
    ROWS BETWEEN doesn't care about the exact values. 
        It cares only about the order of rows when computing frame.
    RANGE BETWEEN considers values when computing frame.
    #example using two window definitions:
    ORDER BY x ROWS BETWEEN 2  PRECEDING AND CURRENT ROW
    ORDER BY x RANGE BETWEEN 2  PRECEDING AND CURRENT ROW
    #and data as
    +---+
    |  x|
    +---+
    | 10|
    | 20|
    | 30|
    | 31|
    +---+
    Assuming the current row is the one with value 31 for the first window following rows will be included 
    (current one, and two preceding):
    +---+----------------------------------------------------+
    |  x|ORDER BY x ROWS BETWEEN 2  PRECEDING AND CURRENT ROW|
    +---+----------------------------------------------------+
    | 10|                                               false|
    | 20|                                                true|
    | 30|                                                true|
    | 31|                                                true|
    +---+----------------------------------------------------+
    and for the second one following (current one, and all preceding where x >= 31 - 2):
    +---+-----------------------------------------------------+
    |  x|ORDER BY x RANGE BETWEEN 2  PRECEDING AND CURRENT ROW|
    +---+-----------------------------------------------------+
    | 10|                                                false|
    | 20|                                                false|
    | 30|                                                 true|
    | 31|                                                 true|
    +---+-----------------------------------------------------+


@@@
###Winner curse CSV 
lines = sc.textFile(r".\data\Cartier+for+WinnersCurse.csv")
headers = lines.first()

fs = [StructField(f, StringType()) for f in  headers.split(",")]
schema = StructType(fs)

noheaders = lines.filter(lambda _ : _ != headers)
rows = noheaders.map(lambda _ : _.split(",")).map( lambda a : Row(*a))

auctions = spark.createDataFrame(rows, schema)
>>> auctions.printSchema()
root
 |-- auctionid: string (nullable = true)
 |-- bid: string (nullable = true)
 |-- bidtime: string (nullable = true)
 |-- bidder: string (nullable = true)
 |-- bidderrate: string (nullable = true)
 |-- openbid: string (nullable = true)
 |-- price: string (nullable = true)

>>> auctions.dtypes
[('auctionid', 'string'), ('bid', 'string'), ('bidtime', 'string'), ('bidder', 'string'), ('bidderrate', 'string'), ('openbid', 'string'), ('price', 'string')]

>>> auctions.show(5)
+----------+----+-----------+-----------+----------+-------+-----+
| auctionid| bid|    bidtime|     bidder|bidderrate|openbid|price|
+----------+----+-----------+-----------+----------+-------+-----+
|1638843936| 500|0.478368056|  kona-java|       181|    500| 1625|
|1638843936| 800|0.826388889|     doc213|        60|    500| 1625|
|1638843936| 600|3.761122685|       zmxu|         7|    500| 1625|
|1638843936|1500|5.226377315|carloss8055|         5|    500| 1625|
|1638843936|1600|   6.570625|    jdrinaz|         6|    500| 1625|
+----------+----+-----------+-----------+----------+-------+-----+
only showing top 5 rows

#OR Convert to Row  
Auction = Row('auctionid', 'bid', 'bidtime', 'bidder', 'bidderrate', 'openbid', 'price')

rdd = noheaders.map(lambda _ : _.split(",")).map(lambda r : Auction(*r))
auctions = rdd.toDF() #[auctionid: string, bid: float, bidtime: float, bidder: string, bidderrate: int, openbid: float, price: float]

#OR 
auctions = spark.read.format("csv").option("header", "true").option("inferSchema","true").load(r"D:\Desktop\PPT\spark\data\Cartier+for+WinnersCurse.csv")

#Querying DataFrame
auctions.groupBy("bidder").count().show(5)
auctions.groupBy("bidder").count().sort(F.col("count").desc()).show(5)
auctions.groupBy("bidder").count().sort(F.desc("count")).show(5)
auctions.select("auctionid").distinct().count()

#Using SQL
auctions.registerTempTable("auctions") 
sql = spark.sql("SELECT count(*) AS count FROM auctions") #[count: bigint]
sql.explain()
sql.show()
count = sql.collect()[0]["count"]           #collect returns Row 
spark.catalog.listTables()

#Filtering
auctions.filter(F.col("bidder").like("c%")).show()
auctions.filter('bidder like "c%"').show()


df.printSchema()
df.columns()
df.dtypes()
df.schema()
df.show()
##map here 
auctions.rdd.map{row => row.getString(0)}


  

##write 
auctions.repartition(1).write.format("csv").option("header", "true").
 mode("append").save(raw"..\data\spark\output.csv")

auctions.repartition(1).write.format("json").
 mode("append").save(raw"..\data\spark\output.json")
 
auctions.repartition(1).write.format("text").
 mode("append").save(raw"..\data\spark\output.txt")
 
#Read 

spark.read.format("json").option("inferSchema",true).
  load(raw"..\data\spark\output.json\*.json")
                 
#$ pyspark --driver-class-path sqlite-jdbc-3.21.0.1.jar --jars sqlite-jdbc-3.21.0.1.jar

auctions.write.format("jdbc").options(Map("url" -> "jdbc:sqlite:wc.db",
                 "driver" -> "org.sqlite.JDBC",
                 "dbtable" -> "new_db")).mode("append").save()  
                 
#Read 
spark.read.format("jdbc").options("url"="jdbc:sqlite:wc.db",
                 "driver"="org.sqlite.JDBC",
                 "dbtable"= "new_db")).load() 








###iris example 
iris = spark.read.format("csv").option("header", "true").option("inferSchema","true").load(r'D:\Desktop\PPT\spark\data\iris.csv')
iris.show(5)
>>> iris.dtypes
[('SepalLength', 'double'), ('SepalWidth', 'double'), ('PetalLength', 'double'),
 ('PetalWidth', 'double'), ('Name', 'string')]
 
#Return new DF 
>>>iris1 = iris.withColumn("sepal_ratio" , F.round(iris['SepalWidth'] / iris.SepalLength, 2) )
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200

#Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:
iris.filter('SepalLength > 5 AND SepalLength < 5.2').show()
iris.filter((F.col('SepalLength') > 5) & (F.col('SepalLength') < 5.2) ).show()
iris.filter(F.col('SepalLength').between(5.01,5.1) ).show()


iris.filter('SepalLength > 5').withColumn('SepalRatio', F.col('SepalWidth') / iris.SepalLength) \
    .withColumn('PetalRatio' , iris.PetalWidth / iris.PetalLength).toPandas()   \
    .plot(kind='scatter', x='SepalRatio', y='PetalRatio')
    
plt.show()

#Clearly two clusters 
iris_m = iris.filter('SepalLength > 5').withColumn('SepalRatio', F.col('SepalWidth') / iris.SepalLength) \
    .withColumn('PetalRatio' , iris.PetalWidth / iris.PetalLength)

##Quick K-Means - Find those two clusters 
from math import sqrt
from pyspark.mllib.clustering import KMeans, KMeansModel

iris_m.select(F.array(F.round('SepalRatio',2),F.round('PetalRatio',2)).alias("features")).show(truncate=False)

parsedData = iris_m.select(F.array(F.round('SepalRatio',2),F.round('PetalRatio',2)).alias("features"))
trainData, testData = parsedData.randomSplit([3.0,1.0], seed=34)

# Build the model (cluster the data), MLIB only takes LabeledPoint(label,Vector_as_features) or Vector for unsupervised learning
clusters = KMeans.train(trainData.rdd.map(lambda row:Vectors.dense(row.features)) , k=2, maxIterations=10, initializationMode="random")

>>> clusters.clusterCenters
[array([0.46052083, 0.34041667]), array([0.70045455, 0.18318182])]
>>> clusters.centers
[array([0.46052083, 0.34041667]), array([0.70045455, 0.18318182])]

predictedRDD = clusters.predict(testData.rdd.map(lambda row:Vectors.dense(row.features)))

# Evaluate clustering by computing Within Set Sum of Squared Errors
def error(point):
    center = clusters.centers[clusters.predict(point)]
    return sqrt(sum([x**2 for x in (point - center)]))

WSSSE = trainData.rdd.map(lambda row:error(Vectors.dense(row.features))).reduce(lambda x, y: x + y)
print("Within Set Sum of Squared Error = " , WSSSE)

# Save and load model
clusters.save(sc, "KMeansModel")
sameModel = KMeansModel.load(sc, "KMeansModel")


#OR Use VectorAssembler to convert to ml.linalg.DenseVector 
parsedData = iris_m.select(F.round('SepalRatio',2).alias('sr'),F.round('PetalRatio',2).alias("pr"))

assembler = VectorAssembler().setInputCols(['pr', 'sr']).setOutputCol("features")
out = assembler.transform(parsedData)

parsedRdd = out.rdd.map(lambda row:Vectors.dense(row.features.toArray()))#we need mllib.linalg.DenseVector 





      
#Unique 
>>> iris.select(F.collect_set("Name")).collect()
[Row(collect_set(Name)=['Iris-virginica', 'Iris-setosa', 'Iris-versicolor'])]

#String proessing 
iris.select(F.lower(F.col("Name"))).show(5)

#Note sql.functions return Column, hence usage of below is wrong, Write a UDF 
#>>> iris.select(F.substring(F.col("Name"), F.instr(F.col("Name"),"-")+1, F.length(F.col("Name")))).show(5)
@F.udf(returnType=StringType()) 
def get(s):
    return s[s.find("-")+1:]

iris.select(get(F.col("Name")).alias("nm")).show(5)

#or use pandas_udf , pandas.Series -> pandas.Series  for SCALAR
@F.pandas_udf("string", F.PandasUDFType.SCALAR) 
def get(se):
    return se.str.slice(len("Iris-"))
    
iris.select(get(F.col("Name")).alias("nm")).show(5)  

#To show in SQL , must use 
spark.udf.register("get", lambda s: s[s.find("-")+1:], StringType())
iris.createOrReplaceTempView("iris")
spark.sql("select get(Name) as nm from iris").show()





#Statistic 
stat = iris.describe().cache() #DataFrame[summary: string, SepalLength: string, SepalWidth: string, PetalLength: string, PetalWidth: string, Name: string]
stat.show(truncate=False)  #DF 
stat.coalesce(1).write.format("csv").option("header","true").save("summary")

#groupBy 
iris.groupby("Name").agg({'*':'count', 'SepalLength':'min'}).collect()
iris.groupby("Name").agg(F.count('*'), F.stddev(iris.SepalLength)).collect()

#Pivoting a particular value 
iris.select(sort_array(collect_set(F.col("SepalLength")))).collect()
[4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9

iris.agg(countDistinct("SepalLength")).collect()  #35 
#find each distinct values count 
irisd = iris.withColumn("cnt", count("SepalLength").over(Window.partitionBy("SepalLength"))).withColumn("maps", array("SepalLength", "cnt"))
irisd.select(col("maps")).distinct().collect()
[[6.9, 4.0], [6.2, 4.0], 

#Compute the avg of SepalWidth for evalue of SepalLength
#note These functions takes only ColumnName 
iris.groupBy("Name").pivot("SepalLength", [6.9, 6.2]).avg("SepalWidth")
[[Iris-virginica,3.1333333333333333,3.0999999999999996], [Iris-setosa,null,null], [Iris-versicolor,3.1,2.55])

#Or without specifying column values (less efficient)
iris.groupBy("Name").pivot("SepalLength").avg("SepalWidth").collect








#full return pdf schema should be mentioned , inour case, input pdf schema is the output one 
@F.pandas_udf(iris.schema, F.PandasUDFType.GROUPED_MAP)  
def normalize(pdf):
    def _norm(se):
        return ((se - se.mean())/se.std()).round(2)
    return pdf.aliassign(SepalLength=_norm(pdf.SepalLength), PetalLength=_norm(pdf.PetalLength))


iris.groupby("Name").apply(normalize).show()  

#With sql 
spark.sql("select Name, count(*) as cnt, min(SepalLength) as min from iris group by Name order by Name").show(truncate=False)


##HandsON 
    :Attribute Information (in order):
        - CRIM     per capita crime rate by town
        - ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
        - INDUS    proportion of non-retail business acres per town
        - CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
        - NOX      nitric oxides concentration (parts per 10 million)
        - RM       average number of rooms per dwelling
        - AGE      proportion of owner-occupied units built prior to 1940
        - DIS      weighted distances to five Boston employment centres
        - RAD      index of accessibility to radial highways
        - TAX      full-value property-tax rate per $10,000
        - PTRATIO  pupil-teacher ratio by town
        - B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
        - LSTAT    % lower status of the population
        - MEDV     Median value of owner-occupied homes in $1000s

"crim", "zn",   "indus", "chas", "nox",  "rm",  "age",  "dis",  "rad", "tax", "ptratio", "b",   "lstat","medv"
0.00632, 18,     2.31,    "0",    0.538,  6.575, 65.2,   4.09,  1,      296,   15.3,      396.9, 4.98,   24

1. read data in boston 
boston = spark.read.format("csv").option("header",true).
  option("inferSchema",true).load("./data/spark/boston.csv")
2. Create a column crimxmedv = crim X medv 
boston.withColumn("crimxmedv", col("crim") * col("medv"))
3. select columns crimxmedv , tax 
df = boston.withColumn("crimxmedv", col("crim") * col("medv")).
   select("crimxmedv","tax")
4. what is the max value of crim 
boston.agg(max("crim")).show
mc = boston.agg(max("crim")).collect.apply(0).getDouble(0)
5. what is max value of medv 
boston.agg(max("medv")).show
mm = boston.agg(max("medv")).collect.apply(0).getDouble(0)
5. select rows of crim where medv is max 
boston.select("medv").where(s"crim == $mc").show

6. select rows of medv where crim is max 
boston.select("crim").where(s"medv == $mm").show

7. how many unique value in chas and rad 
boston.select("chas").distinct.show 

8. what is max and min value of medv for each chas 
boston.groupBy("chas").agg(col("chas"), max(col("medv")).alias("max_medv"),
    min(col("medv")).alias("min_medv")).show 

9. put crimxmedv and tax in csv 
df.repartition(1).write.format("csv").
  option("header",true).save("./data/spark/processed")

  
  
## eventTime,deviceId,signal  (5188 line)
2017-08-23T00:00:00.002Z,"mine",20
2017-08-23T00:05:00.002Z,"mine",30
2017-08-23T00:09:00.002Z,"mine",40
2017-08-23T00:11:00.002Z,"mine",50
2017-08-23T01:00:00.002Z,"mine",60
2017-08-23T00:49:59.002Z,"mine",70

1.Create Text file 
2. read text file in DF 
device = spark.read.format("text").load("./data/spark/device.txt")
##[value: string]

3. extract each column  and then 'cast' to correct type with name eventTime,deviceId,signal
col1 - timestamp, column2 - string, column3-int 
extracted = device.withColumn("splits", split(col("value"), ",")).
  withColumn("eventTime", to_timestamp(col("splits").getItem(0))).
  withColumn("deviceId", col("splits").getItem(1).cast("string")).
  withColumn("signal", col("splits").getItem(2).cast("int")).
  select("eventTime", "deviceId","signal")
  


4. group by deviceId and collect all signals into a list 'signals'
df = extracted.groupBy("deviceId").
    agg(collect_list(col("signal")).alias("signals")).
    select(col("deviceId"), col("signals"), size(col("signals")).alias("size"))
    


5. select deviceId,signals, it's size and dump into csv file '
df.repartition(1).write.format("csv").
  option("header",true).save("./data/spark/deviced-processed ")
 
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
###+++ Spark - Spark-SQL along with Data Frame
#For syntax, check : https://docs.databricks.com/spark/latest/spark-sql/index.html
#Similar to HiveQL , Through Spark-SQL, user can access Spark Dataframe engines 

#Spark SQL supports loading datasets from various data sources('using datasource') including tables in Apache Hive. 
#With Hive support enabled, you can load datasets from existing Apache Hive deployments 
#and save them back to Hive tables if needed.

#Example 
warehouseLocation = "file:///tmp/spark-warehouse" ##should match to location of HDFS hive , hive-site.xml's hive.metastore.warehouse.dir

spark = SparkSession.
  builder().
  appName("Spark Hive Example").master("local[*]").
  config("spark.sql.warehouse.dir", warehouseLocation).
  config("hive.warehouse.subdir.inherit.perms", False). ##chgrp does not match expected pattern for group
  config("hive.exec.dynamic.partition", "true").
  config("hive.exec.dynamic.partition.mode", "nonstrict").
  config("spark.sql.sources.partitionOverwriteMode", "dynamic").  ##for dynamic overwrite 
  enableHiveSupport().
  getOrCreate()


##https://issues.apache.org/jira/browse/SPARK-22918
##https://stackoverflow.com/questions/48008343/sbt-test-does-not-work-for-spark-test/48044007
System.setSecurityManager(null) ##spark and derby incompatibility 
##Note using spark-shell and spark-submit is OK 


#code 
spark.sql("CREATE OR REPLACE TEMPORARY VIEW v1 (name STRING, age INT) USING csv OPTIONS ('path'='file:///D:/Desktop/PPT/spark/data/people.csv', 'header'='true')")

#Queries are expressed in HiveQL
spark.sql("FROM v1").show()

>>> spark.sql("desc EXTENDED v1").show(truncate=False)
+----------+---------+-------+
|col_name  |data_type|comment|
+----------+---------+-------+
|# col_name|data_type|comment|
|key       |int      |null   |
|value     |string   |null   |
+----------+---------+-------+



###Running the Spark SQL CLI in local mode 
##Note that the Spark SQL CLI cannot talk to the Thrift JDBC server for spark 
$ spark-sql  [cli args]
#spark-submit --class org.apache.spark.sql.hive.thriftserver.SparkSQLCLIDriver [cli_args]  //--help
spark-sql> describe function `<>`;
spark-sql> show functions;
spark-sql> explain extended show tables;

#Equivalent 
spark.sql("describe function `<>`").show(truncate=False)
spark.sql("show functions").show()
spark.sql("explain extended show tables").show(truncate=False)


###Distributed SQL Engine - Thrift JDBC/ODBC Server 
#Thrift is an interface definition language and binary communication protocol used 
#for defining and creating services for cross platform services 

#The Spark Thrift server works in YARN client mode only.

#Spark also has JDBC/ODBC server, for Connecting to Spark engines , called Thrift JDBC/ODBC server
#It can run spark SQL 
#The Thrift JDBC/ODBC server implemented here corresponds to the HiveServer2 in Hive 1.2.1 
#User can Use beeline client as in Hive or in Spark to connect to this server 

$ ./sbin/start-thriftserver.sh
# spark-submit --class org.apache.spark.sql.hive.thriftserver.HiveThriftServer2
$ ./sbin/stop-thriftserver.sh

#This script accepts all bin/spark-submit command line options, plus a --hiveconf option to specify Hive properties. 
#You may run ./sbin/start-thriftserver.sh --help for a complete list of all available options. 

#By default, the server listens on localhost:10000. 
$ export HIVE_SERVER2_THRIFT_PORT=<listening-port>
$ export HIVE_SERVER2_THRIFT_BIND_HOST=<listening-host>
$ ./sbin/start-thriftserver.sh \
  --master <master-uri> \
  ...

#or system properties:
./sbin/start-thriftserver.sh \
  --hiveconf hive.server2.thrift.port=<listening-port> \
  --hiveconf hive.server2.thrift.bind.host=<listening-host> \
  --master <master-uri>
  ...
  
##Running external JDBC client of Thrift JDBC/ODBC server
#include all jars in spark/jars or include  'org.spark-project.hive:hive-jdbc:1.2.1.spark2'  
JDBC URL 
    #https://docs.hortonworks.com/HDPDocuments/HDP2/HDP-2.6.4/bk_spark-component-guide/content/access-jdbc.html
    jdbc:hive2://<host>:<port>/<dbName>;<sessionConfs>?<hiveConfs>#<hiveVars>
JDBC Class Name
    org.apache.hive.jdbc.HiveDriver 

 
##Using beeline to connect to  the Thrift JDBC/ODBC server:
./bin/beeline
#Beeline will ask you for a username and password. 
#In non-secure mode, simply enter the username on your machine and a blank password.
beeline> !connect jdbc:hive2://localhost:10000
Connecting to jdbc:hive2://localhost:10000
Enter username for jdbc:hive2://localhost:10000: jacek
Enter password for jdbc:hive2://localhost:10000: [press ENTER]
Connected to: Spark SQL (version 2.3.0)
Driver: Hive JDBC (version 1.2.1.spark2)
Transaction isolation: TRANSACTION_REPEATABLE_READ
0: jdbc:hive2://localhost:10000> show databases;
+---------------+--+
| databaseName  |
+---------------+--+
| default       |
+---------------+--+
1 row selected (0.074 seconds)
0: jdbc:hive2://localhost:10000> show tables;


##Using spark-shell or spark-submit to connect to  the Thrift JDBC/ODBC server:
val df = spark
  .read
  .option("url", "jdbc:hive2://localhost:10000") 
  .option("dbtable", "people") 
  .format("jdbc")
  .load

###Spark SQL Options - 78 options 
#https://spark.apache.org/docs/latest/configuration.html

spark.sparkContext 
sc.setLogLevel("WARN")
spark.conf.get("spark.app.name")



##SQL parameters 
spark.sql("set -v").show(200, truncate=False)
spark.sql("set -v").select(col("key"),col("value")).show(200, truncate=False) ##'
spark.sql("set -v").select(col("key"),col("value")).count()  ##'
##SQL functions 
spark.sql("show all functions").show(200,truncate=False)
spark.sql("show all functions").count()

spark.sql("desc function explode").show(truncate=False)
spark.sql("desc database default").show(truncate=False)
spark.sql("show  functions like 'r.+'").show(200,truncate=False) ##regex 


###Spark SQL Syntax 
##For syntax, check : https://docs.databricks.com/spark/latest/spark-sql/index.html
Alter Database
Alter Table or View
Alter Table Partitions
Analyze Table
Cache
Cache Table
Clear Cache
Create Database
Create Function
Create Table
Create View
Describe Database
Describe Function
Describe Table
Drop Database
Drop Function
Drop Table
Explain
Insert
Load Data
Refresh Table
Reset
Select
Set
Show Columns
Show Create Table
Show Functions
Show Partitions
Show Table Properties
Truncate Table
Uncache Table
Use Database
Vacuum






##Examples 
spark.sql("CREATE TABLE IF NOT EXISTS src (key INT, value STRING)")
##load data is only for Hive table 
spark.sql("LOAD DATA LOCAL INPATH './data/spark/kv1.txt' INTO TABLE src")

## Queries are expressed in HiveQL
spark.sql("SELECT * FROM src").show()

## Aggregation queries are also supported.
spark.sql("SELECT COUNT(*) FROM src").show()

## The results of SQL queries are themselves DataFrames and support all normal functions.
sqlDF = spark.sql("SELECT key, value FROM src WHERE key < 10 ORDER BY key")


## You can also use DataFrames to create temporary views within a SparkSession.
Record = Row('key', 'value')
recordsDF = spark.createDataFrame([Record(i, "val_"+str(i)) for i in range(1,100)])
recordsDF.createOrReplaceTempView("records")

## Queries can then join DataFrame data with data stored in Hive.
spark.sql("SELECT * FROM records r JOIN src s ON r.key = s.key").show()



##CSV 
spark.sql("CREATE DATABASE IF NOT EXISTS new_db ")
spark.sql("USE new_db")

##For reading only as insert into requires hdfs like file structure 
spark.sql("""CREATE TABLE IF NOT EXISTS v1 (name STRING, age INT) 
           USING csv 
           OPTIONS ('path'='file:///D:/Desktop/PPT/spark/data/people.csv', 'inferSchema'='true', 'header'='true')""")
           
##Queries are expressed in HiveQL
spark.sql("FROM new_db.v1").show(truncate=False)

>>> spark.sql("desc EXTENDED v1").show(truncate=False)

##Insert into 
spark.sql("""CREATE TABLE IF NOT EXISTS v3 (name STRING, age INT) 
           USING csv""")
 
spark.sql("""INSERT INTO v3  SELECT * FROM v1""")
spark.sql("INSERT INTO v3 VALUES ('NEW1',20), ('NEW1',30)")
spark.sql("select * from v3").show()

##json 
spark.sql("""CREATE OR REPLACE TEMPORARY VIEW v2 (name STRING, age INT) 
           USING json 
           OPTIONS ('path'='file:///D:/Desktop/PPT/spark/data/people.json', 'inferSchema'='true')""")
spark.sql("select * from v2").show()
spark.sql("desc EXTENDED v2").show(truncate=False)          
spark.sql("""INSERT INTO v3  SELECT * FROM v2""")
spark.sql("select * from v3").show()

##With partition - Partioned By should include any columns defined in table 
spark.sql("DROP TABLE IF EXISTS v4")
spark.sql("""CREATE TABLE IF NOT EXISTS v4 (name STRING, age INT) 
           USING csv PARTITIONED BY (name)""")
           
##Note v4 has two columns including partitioned by 
spark.sql("INSERT INTO v4 PARTITION(name='NEW1') VALUES (20), (30)")   
spark.sql("select * from v4").show()   
##conf:dynamic should be on , 
spark.sql("INSERT INTO v4  PARTITION(name) SELECT age, name FROM v1")      
##age,name must be explicit , not * as partitioned column should be last    
spark.sql("INSERT INTO v4  PARTITION(name) SELECT age,name FROM v2")   
##check 
df = spark.sql("SELECT age, name FROM v1")
##only one record for any number of update of same record 
df.write.mode("overwrite").insertInto("v4") ##not to be used with Partitionby 
##or append 
df.write.mode("append").insertInto("v4")


##catalogs 
spark.catalog.currentDatabase
spark.catalog.databaseExists("new_db")
spark.catalog.listColumns("new_db", "v1")
spark.catalog.listDatabases().show()
spark.catalog.listFunctions("new_db").show(200,truncate=False)
spark.catalog.listFunctions()
spark.catalog.listTables("new_db").show()
spark.catalog.listTables().show()  
           
           
##More examples 
##USING <datasource>    TEXT, CSV, JSON, JDBC, PARQUET, ORC, HIVE and LIBSVM

CREATE TABLE boxes (width INT, length INT, height INT) USING CSV  PARTITIONED BY (width, length)
CREATE TEMPORARY TABLE boxes  (width INT, length INT, height INT)  USING PARQUET   OPTIONS ('compression'='snappy')
    
##insert 
INSERT INTO boxes PARTITION (width = 3, length = 4) SELECT id FROM RANGE(1, 3)
INSERT INTO boxes PARTITION (width = 4, length = 3) VALUES (7), (8)
  
##Create another table 
CREATE TABLE rectangles
    USING PARQUET
    PARTITIONED BY (width)
    CLUSTERED BY (length) INTO 8 buckets
    AS SELECT * FROM boxes   
    
    

    
##Basic select 
SELECT * FROM boxes
SELECT width, length FROM boxes WHERE height=3
SELECT DISTINCT width, length FROM boxes WHERE height=3 LIMIT 2
SELECT * FROM VALUES (1, 2, 3) AS (width, length, height)
SELECT * FROM VALUES (1, 2, 3), (2, 3, 4) AS (width, length, height)
SELECT * FROM boxes ORDER BY width
SELECT * FROM boxes DISTRIBUTE BY width SORT BY width
SELECT * FROM boxes CLUSTER BY length

##Samplings 
SELECT * FROM boxes TABLESAMPLE (3 ROWS)
SELECT * FROM boxes TABLESAMPLE (25 PERCENT)

##Joins
SELECT * FROM boxes INNER JOIN rectangles ON boxes.width = rectangles.width
SELECT * FROM boxes FULL OUTER JOIN rectangles USING (width, length)
SELECT * FROM boxes NATURAL JOIN rectangles

##Lateral View
##Generate zero or more output rows for each input row using a table-generating function. 
##The most common built-in function used with LATERAL VIEW is explode.
SELECT * FROM boxes LATERAL VIEW explode(Array(1, 2, 3)) my_view
SELECT name, my_view.grade FROM students LATERAL VIEW OUTER explode(grades) my_view AS grade

##Aggregation
##GROUP BY a, b, c WITH ROLLUP is equivalent to GROUP BY a, b, c GROUPING SETS ((a, b, c), (a, b), (a), ()).
##GROUP BY a, b, c WITH CUBE is equivalent to GROUP BY a, b, c GROUPING SETS ((a, b, c), (a, b), (b, c), (a, c), (a), (b), (c), ()). 
##GROUP BY x, y GROUPING SETS (x, y) is equivalent to the result of  GROUP BY x unioned with that of GROUP BY y.
SELECT height, COUNT(*) AS num_rows FROM boxes GROUP BY height
SELECT width, AVG(length) AS average_length FROM boxes GROUP BY width
SELECT width, length, height FROM boxes GROUP BY width, length, height WITH ROLLUP
SELECT width, length, height FROM boxes GROUP BY width, length, height WITH CUBE
SELECT width, length, avg(height) FROM boxes GROUP BY width, length GROUPING SETS (width, length)

##Window Functions
##A windowed expression is specified using the OVER keyword, which is followed by either an identifier to the window (defined using the WINDOW keyword) or the specification of a window
SELECT AVG(length) AS average_length OVER PARTITION BY length ORDER BY length ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    FROM boxes GROUP BY width


##Syntax 
CREATE [TEMPORARY] TABLE [IF NOT EXISTS] [db_name.]table_name
    [(col_name1 col_type1 [COMMENT col_comment1], ...)]
    USING datasource
    [OPTIONS (key1=val1, key2=val2, ...)]
    [PARTITIONED BY (col_name1, col_name2, ...)]
    [CLUSTERED BY (col_name3, col_name4, ...) INTO num_buckets BUCKETS]
    [LOCATION path]
    [COMMENT table_comment]
    [TBLPROPERTIES (key1=val1, key2=val2, ...)]
    [AS select_statement]
    
USING <data source>
    Specify the file format to use for this table. 
    The data source may be one of TEXT, CSV, JSON, JDBC, PARQUET, ORC, HIVE and LIBSVM,
    or a fully qualified class name of a custom implementation of org.apache.spark.sql.sources.DataSourceRegister.
    Use file:/// , hdfs://, ftp:// protocol, by default , for /path/to takes HDFS system 

#Example  
CREATE TABLE jdbcTable
USING org.apache.spark.sql.jdbc
OPTIONS (
  url "jdbc:<databaseServerType>://<jdbcHostname>:<jdbcPort>",
  table "<jdbcDatabase>.atable",
  user "<jdbcUsername>",
  password "<jdbcPassword>"
)

# Insert 
INSERT INTO [TABLE] [db_name.]table_name [PARTITION part_spec] select_statement
INSERT INTO [TABLE] [db_name.]table_name [PARTITION part_spec] VALUES values_row [, values_row ...]

#Many forms of select statements are available, check reference 
SELECT [hints, ...] [ALL|DISTINCT] named_expression[, named_expression, ...]
    FROM relation[, relation, ...]
    [lateral_view[, lateral_view, ...]]
    [WHERE boolean_expression]
    [aggregation [HAVING boolean_expression]]
    [ORDER BY sort_expressions]
    [CLUSTER BY expressions]
    [DISTRIBUTE BY expressions]
    [SORT BY sort_expressions]
    [WINDOW named_window[, WINDOW named_window, ...]]
    [LIMIT num_rows]

named_expression:
    : expression [AS alias]

relation:
    | join_relation
    | (table_name|query|relation) [sample] [AS alias]
    : VALUES (expressions)[, (expressions), ...]
          [AS (column_name[, column_name, ...])]

expressions:
    : expression[, expression, ...]

sort_expressions:
    : expression [ASC|DESC][, expression [ASC|DESC], ...]
    
    
#Example 
CREATE TEMPORARY TABLE boxes
    (width INT, length INT, height INT)
    USING PARQUET
    OPTIONS ('compression'='snappy')
    
#Example , start hdfs by  ' start-dfs ' and stop by 'stop-dfs'
#creates files under /data   
spark.sql("""CREATE TABLE boxes (width INT, length INT, height INT) USING CSV
    OPTIONS ('path'='/data/sql/boxes.csv', 'header'='true') PARTITIONED BY (width, length)""")


#insert 
spark.sql("""INSERT INTO boxes PARTITION (width = 3, length = 4)
  SELECT id FROM RANGE(1, 3)""")
  
spark.sql("""INSERT INTO boxes PARTITION (width = 4, length = 3)
  VALUES (7), (8)""")
  
#Create another table 
spark.sql("""CREATE TABLE rectangles
    USING PARQUET
    OPTIONS ('path'='/data/sql/rectangles.PARQUET')
    PARTITIONED BY (width)
    CLUSTERED BY (length) INTO 8 buckets
    AS SELECT * FROM boxes  """)
    
$ hdfs dfs -cat "/data/sql/boxes.csv/width=3/length=4/*"
#or 
$ hdfs dfs -cat "hdfs://localhost:19000/data/sql/boxes.csv/width=3/length=4/*"
height
1
height
2
    

#Example - Basic select 
>>> spark.sql("SELECT * FROM boxes").show(truncate=False)
+------+-----+------+
|height|width|length|
+------+-----+------+
|7     |4    |3     |
|8     |4    |3     |
|1     |3    |4     |
|2     |3    |4     |
+------+-----+------+

#More examples 
#in code, below select return DF, hence do .show(truncate=False)
SELECT width, length FROM boxes WHERE height=3
SELECT DISTINCT width, length FROM boxes WHERE height=3 LIMIT 2
SELECT * FROM VALUES (1, 2, 3) AS (width, length, height)
SELECT * FROM VALUES (1, 2, 3), (2, 3, 4) AS (width, length, height)
SELECT * FROM boxes ORDER BY width
SELECT * FROM boxes DISTRIBUTE BY width SORT BY width
SELECT * FROM boxes CLUSTER BY length

#Samplings 
SELECT * FROM boxes TABLESAMPLE (3 ROWS)
SELECT * FROM boxes TABLESAMPLE (25 PERCENT)

#Joins
SELECT * FROM boxes INNER JOIN rectangles ON boxes.width = rectangles.width
SELECT * FROM boxes FULL OUTER JOIN rectangles USING (width, length)
SELECT * FROM boxes NATURAL JOIN rectangles

#Lateral View
#Generate zero or more output rows for each input row using a table-generating function. 
#The most common built-in function used with LATERAL VIEW is explode.
SELECT * FROM boxes LATERAL VIEW explode(Array(1, 2, 3)) my_view
SELECT name, my_view.grade FROM students LATERAL VIEW OUTER explode(grades) my_view AS grade

##Aggregation
ROLLUP
    Create a grouping set at each hierarchical level of the specified expressions. 
    For instance, For instance, GROUP BY a, b, c WITH ROLLUP is equivalent to GROUP BY a, b, c GROUPING SETS ((a, b, c), (a, b), (a), ()).
    The total number of grouping sets will be N + 1, where N is the number of group expressions.
CUBE
    Create a grouping set for each possible combination of set of the specified expressions. 
    For instance, GROUP BY a, b, c WITH CUBE is equivalent to GROUP BY a, b, c GROUPING SETS ((a, b, c), (a, b), (b, c), (a, c), (a), (b), (c), ()). 
    The total number of grouping sets will be 2^N, where N is the number of group expressions.
GROUPING SETS
    Perform a group by for each subset of the group expressions specified in the grouping sets. 
    For instance, GROUP BY x, y GROUPING SETS (x, y) is equivalent to the result of GROUP BY x unioned with that of GROUP BY y.

SELECT height, COUNT(*) AS num_rows FROM boxes GROUP BY height
SELECT width, AVG(length) AS average_length FROM boxes GROUP BY width
SELECT width, length, height FROM boxes GROUP BY width, length, height WITH ROLLUP
SELECT width, length, avg(height) FROM boxes GROUP BY width, length GROUPING SETS (width, length)

#Window Functions
#A windowed expression is specified using the OVER keyword, which is followed by either an identifier to the window (defined using the WINDOW keyword) or the specification of a window
window_expression:
    : expression OVER window_spec

window_spec:
    : ((PARTITION|DISTRIBUTE) BY expressions
          [(ORDER|SORT) BY sort_expressions] [window_frame])

window_frame:
    | (RANGE|ROWS) frame_bound
    : (RANGE|ROWS) BETWEEN frame_bound AND frame_bound

frame_bound:
    | CURRENT ROW
    | UNBOUNDED (PRECEDING|FOLLOWING)
    : expression (PRECEDING|FOLLOWING)

PARTITION BY
    Specify which rows will be in the same partition, aliased by DISTRIBUTE BY.
ORDER BY
    Specify how rows within a window partition are ordered, aliased by SORT BY.
RANGE bound
    Express the size of the window in terms of a value range for the expression.
ROWS bound
    Express the size of the window in terms of the number of rows before and/or after the current row.
CURRENT ROW
    Use the current row as a bound.
UNBOUNDED
    Use negative infinity as the lower bound or infinity as the upper bound.
PRECEDING
    If used with a RANGE bound, this defines the lower bound of the value range. 
    If used with a ROWS bound, this determines the number of rows before the current row to keep in the window.
FOLLOWING
    If used with a RANGE bound, this defines the upper bound of the value range. 
    If used with a ROWS bound, this determines the number of rows after the current row to keep in the window
    
#Example  
SELECT AVG(length) AS average_length OVER PARTITION BY length ORDER BY length ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    FROM boxes GROUP BY width


##Hints 
#Hints can be used to help Spark execute a query better
SELECT /*+ BROADCAST(customers) */ * FROM customers, orders WHERE o_custId = c_custId
SELECT /*+ SKEW('orders') */ * FROM customers, orders WHERE o_custId = c_custId
SELECT /*+ SKEW('orders'), BROADCAST(demographic) */ * FROM orders, customers, demographic WHERE o_custId = c_custId AND c_demoId = d_demoId












###Broadcast Joins (aka Map-Side Joins)

#Spark SQL uses broadcast join (aka broadcast hash join) instead of hash join 
#to optimize join queries when the size of one side data is below spark.sql.autoBroadcastJoinThreshold.

#Broadcast join can be very efficient for joins between a large table (fact) 
#with relatively small tables (dimensions) that could then be used to perform a star-schema join. 
#It can avoid sending all data of the large table over the network.

#You can use broadcast function or SQL�s broadcast hints to mark a dataset to be broadcast 
#when used in a join query.

#broadcast join is also called a replicated join (in the distributed system community) 
#or a map-side join (in the Hadoop community).


#JoinSelection execution planning strategy uses spark.sql.autoBroadcastJoinThreshold property (default: 10M) 
#to control the size of a dataset before broadcasting it to all worker nodes when performing a join.


threshold =  spark.conf.get("spark.sql.autoBroadcastJoinThreshold").toInt
int(threshold) / 1024 / 1024 #10

q = spark.range(100).alias("a").join(spark.range(100).alias("b")).where("a.id == b.id")
>>> q.explain()
== Physical Plan ==
*(2) BroadcastHashJoin [id#8L], [id#11L], Inner, BuildRight
:- *(2) Range (0, 100, step=1, splits=4)
+- BroadcastExchange HashedRelationBroadcastMode(List(input[0, bigint, false]))
   +- *(1) Range (0, 100, step=1, splits=4)

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
q = spark.range(100).alias("a").join(spark.range(100).alias("b")).where("a.id == b.id")
>>> q.explain()
== Physical Plan ==
*(5) SortMergeJoin [id#17L], [id#20L], Inner
:- *(2) Sort [id#17L ASC NULLS FIRST], false, 0
:  +- Exchange hashpartitioning(id#17L, 200)
:     +- *(1) Range (0, 100, step=1, splits=4)
+- *(4) Sort [id#20L ASC NULLS FIRST], false, 0
   +- ReusedExchange [id#20L], Exchange hashpartitioning(id#17L, 200)

#Force BroadcastHashJoin with broadcast hint (as function)
qBroadcast = spark.range(100).alias("a").join(broadcast(spark.range(100)).alias("b")).where("a.id == b.id")
qBroadcast.explain()
== Physical Plan ==
*(2) BroadcastHashJoin [id#29L], [id#32L], Inner, BuildRight
:- *(2) Range (0, 100, step=1, splits=4)
+- BroadcastExchange HashedRelationBroadcastMode(List(input[0, bigint, false]))
   +- *(1) Range (0, 100, step=1, splits=4)

   
###Hint Framework (Spark SQL 2.2)

#As of Spark SQL 2.2, structured queries can be optimized using Hint Framework 
#that allows for specifying query hints.

#Query hints allow for annotating a query and give a hint to the query optimizer 
#how to optimize logical plans. 

#Specifying Query Hints
#You can specify query hints using Dataset.hint operator or SELECT SQL statements with hints.
#def hint(name: String, parameters: String ): Dataset[T] 

q = spark.range(1).hint("myHint", "100", "true")
>>> q.explain(True)
== Parsed Logical Plan ==
'UnresolvedHint myHint, [100, true]
+- Range (0, 1, step=1, splits=Some(4))


q = sql("SELECT /*+ myHint (100, true) */ 1")  
>>> q.explain(True)
== Parsed Logical Plan ==
'UnresolvedHint myHint, [100, true]
+- 'Project [unresolvedalias(1, None)]
   +- OneRowRelation
   
   
#Force BroadcastHashJoin using SQL's BROADCAST hint
#Supported hints: BROADCAST, BROADCASTJOIN or MAPJOIN
qBroadcastLeft = """
  SELECT /*+ BROADCAST (lf) */ *
  FROM range(100) lf, range(1000) rt
  WHERE lf.id = rt.id
"""
>>> sql(qBroadcastLeft).explain()
== Physical Plan ==
*(2) BroadcastHashJoin [id#39L], [id#40L], Inner, BuildLeft
:- BroadcastExchange HashedRelationBroadcastMode(List(input[0, bigint, false]))
:  +- *(1) Range (0, 100, step=1, splits=4)
+- *(2) Range (0, 1000, step=1, splits=4)

qBroadcastRight = """
 SELECT /*+ MAPJOIN (rt) */ *
 FROM range(100) lf, range(1000) rt
 WHERE lf.id = rt.id
"""
>>> sql(qBroadcastRight).explain
== Physical Plan ==
*(2) BroadcastHashJoin [id#43L], [id#44L], Inner, BuildLeft
:- BroadcastExchange HashedRelationBroadcastMode(List(input[0, bigint, false]))
:  +- *(1) Range (0, 100, step=1, splits=4)
+- *(2) Range (0, 1000, step=1, splits=4)

   
###Spark with DISTRIBUTE BY & CLUSTER BY 
DISTRIBUTE BY
    Repartitions a DataFrame by the given expressions ie all the rows for which this expression is equal are on the same partition
    The number of partitions is equal to spark.sql.shuffle.partitions. 
    #Example - All same key goes to one partition 
    #SQL 
    SET spark.sql.shuffle.partitions = 2
    SELECT * FROM df DISTRIBUTE BY key
    #DF 
    df.repartition(col("key"), 2)
SORT BY 
    Sorts data within partitions by the given expressions.
    Note that this operation does not cause any shuffle.
    #In SQL:
    SELECT * FROM df SORT BY key
    #Equivalent in DataFrame API:
    df.sortWithinPartitions()
CLUSTER BY 
    a shortcut for using distribute by and sort by together on the same set of expressions.
    #In SQL:
    SET spark.sql.shuffle.partitions = 2
    SELECT * FROM df CLUSTER BY key
    #Equivalent in DataFrame API:
    df.repartition(col("key"), 2).sortWithinPartitions()

##UseCase 
1.Skewed Data
    Your DataFrame is skewed if most of its rows are located on a small number of partitions, 
    while the majority of the partitions remain empty. 
    #Example 
    SET spark.sql.shuffle.partitions = 5
    SELECT * FROM df DISTRIBUTE BY key, value

2.Multiple Joins
    When you join two DataFrames, Spark will repartition them both by the join expressions. 
    This means that if you are joining to the same DataFrame many times (by the same expressions each time), 
    Spark will be doing the repartitioning of this DataFrame each time.
    #Example 
    data =[(key, 1) for key in range(100)]
    sc.parallelize(data).toDF("key", "value").registerTempTable("df")
    import random 
    data1 =  data[:] ; random.shuffle(data1)
    data2 =  data[:] ; random.shuffle(data2)
    sc.parallelize(data1).toDF("key", "value").registerTempTable("df1")
    sc.parallelize(data2).toDF("key", "value").registerTempTable("df2")
    #disable Broadcast join for experiment 
    spark.sql("SET spark.sql.autoBroadcastJoinThreshold = -1")

    sql("CACHE TABLE df")
    sql("SELECT * FROM df JOIN df1 ON df.a = df1.a").show
    sql("SELECT * FROM df JOIN df2 ON df.a = df2.a").show
    #Check the result in SparkUI :Three jobs were executed. df is repartitioned two times 

    #Solution - repartition the DataFrame manually, only once, at the very beginning.
    dfDist = sql("SELECT * FROM df DISTRIBUTE BY a")
    dfDist.registerTempTable("df_dist")
    sql("CACHE TABLE df_dist")
    sql("SELECT * FROM df_dist JOIN df1 ON df_dist.a = df1.a").show
    sql("SELECT * FROM df_dist JOIN df2 ON df_dist.a = df2.a").show
    #Check the result in SparkUI :Three jobs were executed. both of the following jobs, one stage is skipped and the repartitioned DataFrame is taken from the cache

3.Sorting in Join
    Starting from version 1.2, Spark uses sort-based shuffle by default (as opposed to hash-based shuffle).
    when you join two DataFrames, Spark will repartition them both by the join expressions 
    and sort them within the partitions! 
    That means the code above can be further optimised by adding sort by to it:
    SELECT * FROM df DISTRIBUTE BY a SORT BY a
    #OR 
    SELECT * FROM df CLUSTER BY a

4.Multiple Join on Already Partitioned DataFrame
    if the DataFrame that you will be joining to is already partitioned correctly, use only sort by 
    Don't use distribute by
    #Example 
    dfDist = sql("SELECT a, count(*) FROM some_other_df GROUP BY a SORT BY a")
    dfDist.registerTempTable("df_dist")
    sql("CACHE TABLE df_dist")
    sql("SELECT * FROM df_dist JOIN df1 ON df_dist.a = df1.a").show
    sql("SELECT * FROM df_dist JOIN df2 ON df_dist.a = df2.a").show  
   


### DataFrame and SQL Join Operators
#Queries can access multiple tables at once, or access the same table in such a way that multiple rows of the table are being processed at the same time. 
#A query that accesses multiple rows of the same or different tables at one time is called a join query.

spark.sql("select * from t1, t2 where t1.id = t2.id")

#OR specify a join condition (aka join expression) as part of join operators 
#or using where or filter operators.
df1.join(df2, "df1Key == df2Key")
df1.join(df2).where("df1Key == df2Key")
df1.join(df2).filter("df1Key == df2Key")

#using joinType optional parameter).
df1.join(df2, "df1Key == df2Key", "inner")



# Inner join with a single column that exists on both sides
left = sc.parallelize([(0, "zero"), (1, "one")]).toDF(["id", "left"])
right = sc.parallelize([(0, "zero"), (2, "two"), (3, "three")]).toDF(["id", "right"])

# Inner join
>>> left.join(right, "id").show
+---+----+-----+
| id|left|right|
+---+----+-----+
|  0|zero| zero|
+---+----+-----+

# Full outer
>>> left.join(right, ["id"], "fullouter").show()
+---+----+-----+
| id|left|right|
+---+----+-----+
|  1| one| null|
|  3|null|three|
|  2|null|  two|
|  0|zero| zero|
+---+----+-----+

# Left anti
>>> left.join(right, "id", "leftanti").show()
+---+----+
| id|left|
+---+----+
|  1| one|
+---+----+


#inner equi-join
#joinWith creates a Dataset with two columns _1 and _2 
#that each contain records for which condition holds.

Person = Row("id", "name", "cityId")
City = Row("id", "name")

family = sc.parallelize([
  Person(0, "Agata", 0),
  Person(1, "Iweta", 0),
  Person(2, "Patryk", 2),
  Person(3, "Maksym", 0)]).toDF()
cities = sc.parallelize([
  City(0, "Warsaw"),
  City(1, "Washington"),
  City(2, "Sopot")]).toDF()

joined = family.join(cities, family.cityId == cities.id)
>>> joined.printSchema()
root
 |-- id: long (nullable = true)
 |-- name: string (nullable = true)
 |-- cityId: long (nullable = true)
 |-- id: long (nullable = true)
 |-- name: string (nullable = true)
 
>>> joined.show()
+---+------+------+---+------+
| id|  name|cityId| id|  name|
+---+------+------+---+------+
|  0| Agata|     0|  0|Warsaw|
|  1| Iweta|     0|  0|Warsaw|
|  3|Maksym|     0|  0|Warsaw|
|  2|Patryk|     2|  2| Sopot|
+---+------+------+---+------+




### DataFrame and SQL Multi-Dimensional Aggregation
groupBy(cols: Column*): GroupedData
groupBy(col1: String, cols: String*): GroupedData
    groupBy operator groups the rows in a Dataset by columns (as Column expressions or names).
    groupBy gives a GroupedData to execute aggregate functions or operators.
cube(cols: Column*): GroupedData
cube(col1: String, cols: String*): GroupedData
	Returns GroupedData
    Calculates subtotals and a grand total for every permutation of the columns specified.
    cube multi-dimensional aggregate operator is an extension of groupBy operator 
    that allows calculating subtotals and a grand total across all combinations of 
    specified group of n + 1 dimensions (with n being the number of columns as cols and col1 and 1 
    for where values become null, i.e. undefined).
    cube is more than rollup operator, i.e. cube does rollup with aggregation 
    over all the missing combinations given the columns. 
rollup(cols: Column*): GroupedData
rollup(col1: String, cols: String*): GroupedData
	Returns GroupedData
    Calculates subtotals and a grand total over (ordered) combination of groups.
    rollup multi-dimensional aggregate operator is an extension of groupBy operator 
    that calculates subtotals and a grand total across specified group of n + 1 dimensions 
    (with n being the number of columns as cols and col1 and 1 for where values become null, i.e. undefined).
    rollup operator is commonly used for analysis over hierarchical data; 
    e.g. total salary by department, division, and company-wide total.
    rollup operator is equivalent to GROUP BY ... WITH ROLLUP in SQL 
    (which in turn is equivalent to GROUP BY ... GROUPING SETS ((a,b,c),(a,b),(a),()) 
    when used with 3 columns: a, b, and c).     
GROUPING SETS SQL Clause
    GROUP BY ... GROUPING SETS (...)
    GROUPING SETS clause generates a dataset that is equivalent to union operator 
    of multiple groupBy operators.    
    It is most general of all 
    
    

#Multi-dimensional aggregate operators are enhanced variants of groupBy operator 
#that allow you to create queries for subtotals, grand totals and superset of subtotals in one go.

sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])

# very labor-intense
# groupBy's unioned
groupByCityAndYear = sales \
  .groupBy("city", "year")              \ # <-- subtotals (city, year)
  .agg(sum("amount").alias("amount")) 
groupByCityOnly = sales \
  .groupBy("city")                                  \ # <-- subtotals (city) 
  .agg(sum("amount").alias("amount"))               \
  .select("city", lit(None).alias("year"), "amount")  # <-- year is null
withUnion = groupByCityAndYear  \
  .union(groupByCityOnly)   \
  .sort(col("city").desc(), col("year").asc())    
>>> withUnion.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|null|   300|
| Warsaw|2016|   100|
| Warsaw|2017|   200|
|Toronto|null|    50|
|Toronto|2017|    50|
| Boston|null|   200|
| Boston|2015|    50|
| Boston|2016|   150|
+-------+----+------+


#grouping(*cols)  is an aggregate function that indicates whether a specified column is aggregated or not and:
#    returns  1  if the column is in a subtotal and is  NULL 
#    returns  0  if the underlying value is  NULL  or any other value
#grouping_id(*cols)  is an aggregate function that computes the level of grouping:
#    Returns 
#        0  for combinations of each column
#        1  for subtotals of column 1
#        2  for subtotals of column 2
#        And so on�

##Multi-dimensional aggregate operators are semantically equivalent to union operator 
#(or SQL�s UNION ALL) to combine single grouping queries.
withRollup = sales      \
  .rollup("city", "year")   \
  .agg(sum("amount").alias("amount"), grouping_id().alias("gid"))   \
  .sort(col("city").desc(), col("year").asc())    \
  .filter("gid != 3")   \
  .select("city", "year", "amount")
>>> withRollup.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|null|   300|
| Warsaw|2016|   100|
| Warsaw|2017|   200|
|Toronto|null|    50|
|Toronto|2017|    50|
| Boston|null|   200|
| Boston|2015|    50|
| Boston|2016|   150|
+-------+----+------+

# SQL only, 
sales.createOrReplaceTempView("sales")
withGroupingSets = sql("""
  SELECT city, year, SUM(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city))
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> withGroupingSets.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
+-------+----+------+

##Details of  rollup 
#Note the subtotal 
sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])

q = sales   \
  .rollup("city", "year")   \
  .agg(sum("amount").alias("amount"))    \
  .sort(col("city").desc(), col("year").asc())
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100| <-- subtotal for Warsaw in 2016
| Warsaw|2017|   200|
| Warsaw|null|   300| <-- subtotal for Warsaw (across years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550| <-- grand total
+-------+----+------+

# The above query is semantically equivalent to the following
q1 = sales
  .groupBy("city", "year")  # <-- subtotals (city, year)
  .agg(sum("amount").alias("amount"))
q2 = sales
  .groupBy("city")          # <-- subtotals (city)
  .agg(sum("amount").alias("amount"))
  .select("city", lit(None).alias("year"), "amount")  # <-- year is null
q3 = sales
  .groupBy()                # <-- grand total
  .agg(sum("amount").alias("amount"))
  .select(lit(None).alias("city"), lit(None).alias("year"), "amount")  # <-- city and year are null
qq = q1
  .union(q2)
  .union(q3)
  .sort(col("city".desc, "year".asc())
>>> qq.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|
+-------+----+------+

##The ROLLUP operator is useful in generating reports that contain subtotals and totals. (�) 
#ROLLUP generates a result set that shows aggregates for a hierarchy of values in the selected columns.

# Borrowed from Microsoft's "Summarizing Data Using ROLLUP" article
inventory = sc.parallelize([
  ("table", "blue", 124),
  ("table", "red", 223),
  ("chair", "blue", 101),
  ("chair", "red", 210)]).toDF(["item", "color", "quantity"])

>>> inventory.show()
+-----+-----+--------+
| item|color|quantity|
+-----+-----+--------+
|chair| blue|     101|
|chair|  red|     210|
|table| blue|     124|
|table|  red|     223|
+-----+-----+--------+

# ordering and empty rows done manually for demo purposes
>>> inventory.rollup("item", "color").sum().show()
+-----+-----+-------------+
| item|color|sum(quantity)|
+-----+-----+-------------+
|chair| blue|          101|
|chair|  red|          210|
|chair| null|          311|
|     |     |             |
|table| blue|          124|
|table|  red|          223|
|table| null|          347|
|     |     |             |
| null| null|          658|
+-----+-----+-------------+


# using struct function
>>> inventory.rollup(struct("item", "color").alias("(item,color)").sum().show()
+------------+-------------+
|(item,color)|sum(quantity)|
+------------+-------------+
| [table,red]|          223|
|[chair,blue]|          101|
|        null|          658|
| [chair,red]|          210|
|[table,blue]|          124|
+------------+-------------+

# using expr function
>>> inventory.rollup(expr("(item, color)").alias("(item, color)").sum().show()
+-------------+-------------+
|(item, color)|sum(quantity)|
+-------------+-------------+
|  [table,red]|          223|
| [chair,blue]|          101|
|         null|          658|
|  [chair,red]|          210|
| [table,blue]|          124|
+-------------+-------------+

##From Hive�s Cubes and Rollups:
    WITH ROLLUP is used with the GROUP BY only. 
    ROLLUP clause is used with GROUP BY to compute the aggregate at the hierarchy levels of a dimension.
    GROUP BY a, b, c with ROLLUP assumes that the hierarchy is "a" drilling down to "b" drilling down to "c".
    GROUP BY a, b, c, WITH ROLLUP is equivalent to GROUP BY a, b, c GROUPING SETS ( (a, b, c), (a, b), (a), ( )).

# Borrowed from http:#//tackoverflow.com/a/27222655/1305344
quarterlyScores = sc.parallelize([
  ("winter2014", "Agata", 99),
  ("winter2014", "Jacek", 97),
  ("summer2015", "Agata", 100),
  ("summer2015", "Jacek", 63),
  ("winter2015", "Agata", 97),
  ("winter2015", "Jacek", 55),
  ("summer2016", "Agata", 98),
  ("summer2016", "Jacek", 97)]).toDF(["period", "student", "score"])

>>> quarterlyScores.show()
+----------+-------+-----+
|    period|student|score|
+----------+-------+-----+
|winter2014|  Agata|   99|
|winter2014|  Jacek|   97|
|summer2015|  Agata|  100|
|summer2015|  Jacek|   63|
|winter2015|  Agata|   97|
|winter2015|  Jacek|   55|
|summer2016|  Agata|   98|
|summer2016|  Jacek|   97|
+----------+-------+-----+

# ordering and empty rows done manually for demo purposes
>>> quarterlyScores.rollup("period", "student").sum("score").show()
+----------+-------+----------+
|    period|student|sum(score)|
+----------+-------+----------+
|winter2014|  Agata|        99|
|winter2014|  Jacek|        97|
|winter2014|   null|       196|
|          |       |          |
|summer2015|  Agata|       100|
|summer2015|  Jacek|        63|
|summer2015|   null|       163|
|          |       |          |
|winter2015|  Agata|        97|
|winter2015|  Jacek|        55|
|winter2015|   null|       152|
|          |       |          |
|summer2016|  Agata|        98|
|summer2016|  Jacek|        97|
|summer2016|   null|       195|
|          |       |          |
|      null|   null|       706|
+----------+-------+----------+



##Another example of rollup 
import datetime
expenses = sc.parallelize([
  (datetime.date(2012, 12, 12), 5),
  (datetime.date(2016, 8, 13), 10),
  (datetime.date(2017, 5, 27), 15)]).toDF(["date", "amount"])
>>> expenses.show()
+----------+------+
|      date|amount|
+----------+------+
|2012-12-12|     5|
|2016-08-13|    10|
|2017-05-27|    15|
+----------+------+

# rollup 
q = expenses    \
  .rollup(year("date").alias("year"), month("date").alias("month")) \
  .agg(sum("amount").alias("amount"))   \
  .sort(col("year").asc(), col("month").asc())
>>> q.show()
+----+-----+------+
|year|month|amount|
+----+-----+------+
|2012|   12|     5|
|2012| null|     5|
|2016|    8|    10|
|2016| null|    10|
|2017|    5|    15|
|2017| null|    15|
|null| null|    30|
+----+-----+------+


##Details of cube - cube is more than rollup operator, 
#i.e. cube does rollup with aggregation over all the missing combinations given the columns.
sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])

q = sales.cube("city", "year")
  .agg(sum("amount").alias("amount"))
  .sort(col("city").desc, col("year").asc())
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|  <-- total in Warsaw in 2016
| Warsaw|2017|   200|  <-- total in Warsaw in 2017
| Warsaw|null|   300|  <-- total in Warsaw (across all years)
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total in 2015 (across all cities)
|   null|2016|   250|
|   null|2017|   250|
|   null|null|   550|  <-- grand total (across cities and years)
+-------+----+------+


##Details of GROUPING SETS SQL Clause
#GROUPING SETS clause generates a dataset that is equivalent to union operator 
#of multiple groupBy operators.

sales = sc.parallelize([
  ("Warsaw", 2016, 100),
  ("Warsaw", 2017, 200),
  ("Boston", 2015, 50),
  ("Boston", 2016, 150),
  ("Toronto", 2017, 50)]).toDF(["city", "year", "amount"])
sales.createOrReplaceTempView("sales")

# equivalent to rollup("city", "year")
q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|null|   550|  <-- grand total across all cities and years
+-------+----+------+

# equivalent to cube("city", "year")
# note the additional (year) grouping set
q = sql("""
  SELECT city, year, sum(amount) as amount
  FROM sales
  GROUP BY city, year
  GROUPING SETS ((city, year), (city), (year), ())
  ORDER BY city DESC NULLS LAST, year ASC NULLS LAST
  """)
>>> q.show()
+-------+----+------+
|   city|year|amount|
+-------+----+------+
| Warsaw|2016|   100|
| Warsaw|2017|   200|
| Warsaw|null|   300|
|Toronto|2017|    50|
|Toronto|null|    50|
| Boston|2015|    50|
| Boston|2016|   150|
| Boston|null|   200|
|   null|2015|    50|  <-- total across all cities in 2015
|   null|2016|   250|  <-- total across all cities in 2016
|   null|2017|   250|  <-- total across all cities in 2017
|   null|null|   550|
+-------+----+------+



##Performance Tunng - Number of Partitions for groupBy Aggregation
#The goal of the case study is to fine tune the number of partitions used for groupBy aggregation.

#Given the following 2-partition dataset the task is to write a structured query 
#so there are no empty partitions (or as little as possible).

# 2-partition dataset
ids = spark.range(start = 0, end = 4, step = 1, numPartitions = 2)
>>> ids.show()
+---+
| id|
+---+
|  0|
|  1|
|  2|
|  3|
+---+
#(2) means number of partitions 
#indentation means Shuffle stage/stage boundary 
>>> ids.rdd.toDebugString()
res1: String =
(2) MapPartitionsRDD[8] at rdd at <console>:26 []
 |  MapPartitionsRDD[7] at rdd at <console>:26 []
 |  MapPartitionsRDD[6] at rdd at <console>:26 []
 |  MapPartitionsRDD[5] at rdd at <console>:26 []
 |  ParallelCollectionRDD[4] at rdd at <console>:26 []

##By default Spark SQL uses spark.sql.shuffle.partitions number of partitions for aggregations and joins, i.e. 200 by default.
#That often leads to explosion of partitions for nothing 
#that does impact the performance of a query since these 200 tasks (per partition) have all to start and finish before you get the result.


##Case 1: Default Number of Partitions�spark.sql.shuffle.partitions Property

#how many partitions the following query really requires
groupingExpr = (col("id") % 2).alias("group")
q = ids.groupBy(groupingExpr).agg(count("id").alias("count"))

#You may have expected to have at most 2 partitions given the number of groups.
#Wrong!

>>> q.explain()
== Physical Plan ==
*HashAggregate(keys=[(id#0L % 2)#17L], functions=[count(1)])
+- Exchange hashpartitioning((id#0L % 2)#17L, 200)
   +- *HashAggregate(keys=[(id#0L % 2) AS (id#0L % 2)#17L], functions=[partial_count(1)])
      +- *Range (0, 4, step=1, splits=2)

>>> q.rdd.toDebugString()
res5: String =
(200) MapPartitionsRDD[16] at rdd at <console>:30 []
  |   MapPartitionsRDD[15] at rdd at <console>:30 []
  |   MapPartitionsRDD[14] at rdd at <console>:30 []
  |   ShuffledRowRDD[13] at rdd at <console>:30 []
  +-(2) MapPartitionsRDD[12] at rdd at <console>:30 []
     |  MapPartitionsRDD[11] at rdd at <console>:30 []
     |  MapPartitionsRDD[10] at rdd at <console>:30 []
     |  ParallelCollectionRDD[9] at rdd at <console>:30 []

#When you execute the query you should see 200 or so partitions in use in web UI.
>>> q.show()
+-----+-----+
|group|count|
+-----+-----+
|    0|    2|
|    1|    2|
+-----+-----+


##Case 2: Using repartition Operator
#repartition operator is indeed a step in a right direction 
#when used with caution as it may lead to an unnecessary shuffle (aka exchange in Spark SQL�s parlance).

groupingExpr = (col("id") % 2).alias("group")
q = ids.repartition(groupingExpr)  \ # <-- repartition per groupBy expression
  .groupBy(groupingExpr)        \
  .agg(count("id").alias("count"))

#You may have expected 2 partitions again!
#Wrong! This is worse than case-1 
>>> q.explain()
== Physical Plan ==
*HashAggregate(keys=[(id#6L % 2)#105L], functions=[count(1)])
+- Exchange hashpartitioning((id#6L % 2)#105L, 200)
   +- *HashAggregate(keys=[(id#6L % 2) AS (id#6L % 2)#105L], functions=[partial_count(1)])
      +- Exchange hashpartitioning((id#6L % 2), 200)
         +- *Range (0, 4, step=1, splits=2)

>>> q.rdd.toDebugString()
res1: String =
(200) MapPartitionsRDD[57] at rdd at <console>:30 []
  |   MapPartitionsRDD[56] at rdd at <console>:30 []
  |   MapPartitionsRDD[55] at rdd at <console>:30 []
  |   ShuffledRowRDD[54] at rdd at <console>:30 []
  +-(200) MapPartitionsRDD[53] at rdd at <console>:30 []
      |   MapPartitionsRDD[52] at rdd at <console>:30 []
      |   ShuffledRowRDD[51] at rdd at <console>:30 []
      +-(2) MapPartitionsRDD[50] at rdd at <console>:30 []
         |  MapPartitionsRDD[49] at rdd at <console>:30 []
         |  MapPartitionsRDD[48] at rdd at <console>:30 []
         |  ParallelCollectionRDD[47] at rdd at <console>:30 []


##Case 3: Using repartition Operator With Explicit Number of Partitions
#repartition operator accepts an additional parameter for the number of partitions 


groupingExpr = (col("id") % 2).alias("group")
q = ids.repartition(numPartitions = 2, groupingExpr)   \# <-- repartition per groupBy expression
  .groupBy(groupingExpr)    \
  .agg(count("id").alias("count"))

#You may have expected 2 partitions again!
#Correct!

>>> q.explain()
== Physical Plan ==
*HashAggregate(keys=[(id#6L % 2)#129L], functions=[count(1)])
+- Exchange hashpartitioning((id#6L % 2)#129L, 200)
   +- *HashAggregate(keys=[(id#6L % 2) AS (id#6L % 2)#129L], functions=[partial_count(1)])
      +- Exchange hashpartitioning((id#6L % 2), 2)
         +- *Range (0, 4, step=1, splits=2)

>>> q.rdd.toDebugString()
res14: String =
(200) MapPartitionsRDD[78] at rdd at <console>:30 []
  |   MapPartitionsRDD[77] at rdd at <console>:30 []
  |   MapPartitionsRDD[76] at rdd at <console>:30 []
  |   ShuffledRowRDD[75] at rdd at <console>:30 []
  +-(2) MapPartitionsRDD[74] at rdd at <console>:30 []
     |  MapPartitionsRDD[73] at rdd at <console>:30 []
     |  ShuffledRowRDD[72] at rdd at <console>:30 []
     +-(2) MapPartitionsRDD[71] at rdd at <console>:30 []
        |  MapPartitionsRDD[70] at rdd at <console>:30 []
        |  MapPartitionsRDD[69] at rdd at <console>:30 []
        |  ParallelCollectionRDD[68] at rdd at <console>:30 []


##Case 4: set spark.sql.shuffle.partitions Property Properly
spark.conf.set("spark.sql.shuffle.partitions", 2)
q = ids.groupBy(groupingExpr).agg(count("id").alias("count"))

>>> q.explain
== Physical Plan ==
*HashAggregate(keys=[(id#0L % 2)#40L], functions=[count(1)])
+- Exchange hashpartitioning((id#0L % 2)#40L, 2)
   +- *HashAggregate(keys=[(id#0L % 2) AS (id#0L % 2)#40L], functions=[partial_count(1)])
      +- *Range (0, 4, step=1, splits=2)

>>> q.rdd.toDebugString()
res10: String =
(2) MapPartitionsRDD[31] at rdd at <console>:31 []
 |  MapPartitionsRDD[30] at rdd at <console>:31 []
 |  MapPartitionsRDD[29] at rdd at <console>:31 []
 |  ShuffledRowRDD[28] at rdd at <console>:31 []
 +-(2) MapPartitionsRDD[27] at rdd at <console>:31 []
    |  MapPartitionsRDD[26] at rdd at <console>:31 []
    |  MapPartitionsRDD[25] at rdd at <console>:31 []
    |  ParallelCollectionRDD[24] at rdd at <console>:31 []  #'



    
    
###Dataset Caching and Persistence
cache(): DF
    cache merely executes the no-argument persist method.
persist(): DF
persist(newLevel: StorageLevel): DF
    persist caches the Dataset using the default storage level MEMORY_AND_DISK or newLevel and returns it.
unpersist(blocking: Boolean): DF
    unpersist uncache the Dataset possibly by blocking the call.

# Cache Dataset -- it is lazy
>>> df = spark.range(1).cache()
df: org.apache.spark.sql.Dataset[Long] = [id: bigint]

# Trigger caching
>>> df.show()
+---+
| id|
+---+
|  0|
+---+

# Visit http://localhost:4040/storage to see the Dataset cached. It should.

# You may also use queryExecution or explain to see InMemoryRelation
# InMemoryRelation is used for cached queries
>>> df.explain(True)
InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
   +- *Range (0, 1, step=1, splits=Some(8))

# Use the cached Dataset in another query
# Notice InMemoryRelation in use for cached queries
>>> df.withColumn("newId", col("id")).explain(extended = True)
== Parsed Logical Plan ==
'Project [*, 'id AS newId#16]
+- Range (0, 1, step=1, splits=Some(8))

== Analyzed Logical Plan ==
id: bigint, newId: bigint
Project [id#0L, id#0L AS newId#16L]
+- Range (0, 1, step=1, splits=Some(8))

== Optimized Logical Plan ==
Project [id#0L, id#0L AS newId#16L]
+- InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
      +- *Range (0, 1, step=1, splits=Some(8))

== Physical Plan ==
*Project [id#0L, id#0L AS newId#16L]
+- InMemoryTableScan [id#0L]
      +- InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
            +- *Range (0, 1, step=1, splits=Some(8))

# Clear in-memory cache using SQL
# Equivalent to 
>>> spark.catalog.clearCache()
#OR 
>>> sql("CLEAR CACHE").collect()


# Visit http://localhost:4040/storage to confirm the cleaning

#You can also use SQL�s CACHE TABLE [tableName] to cache tableName table in memory. 
#Unlike cache and persist operators, CACHE TABLE is an eager operation 
sql("CACHE TABLE tableName")

#use LAZY keyword to make caching lazy.
sql("CACHE LAZY TABLE tableName")

#to refresh a cached table.
sql("REFRESH TABLE tableName") 

#to remove a table from cache.
sql("UNCACHE TABLE IF EXISTS tableName") 

#to remove all tables from cache.
sql("CLEAR CACHE") 


#Be careful what you cache, i.e. what Dataset is cached, as it gives different queries cached.

# cache after range(5)
q1 = spark.range(5).cache.filter("id % 2 == 0").select("id")
>>> q1.explain()
== Physical Plan ==
*Filter ((id#0L % 2) = 0)
+- InMemoryTableScan [id#0L], [((id#0L % 2) = 0)]
      +- InMemoryRelation [id#0L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
            +- *Range (0, 5, step=1, splits=8)

# cache at the end
q2 = spark.range(1).filter("id % 2 == 0").select("id").cache()
>>> q2.explain
== Physical Plan ==
InMemoryTableScan [id#17L]
   +- InMemoryRelation [id#17L], true, 10000, StorageLevel(disk, memory, deserialized, 1 replicas)
         +- *Filter ((id#17L % 2) = 0)
            +- *Range (0, 1, step=1, splits=8)




###Standard Window Functions from sql.functions 

#org.apache.spark.sql.functions object defines built-in standard functions 
#to work with values in Columns.

>>> spark.catalog.listFunctions().count()
res1: Long = 251


##Ranking Records per Window Partition�rank Function
rank(): Column
dense_rank(): Column
percent_rank(): Column
#rank functions assign the sequential rank of each distinct value per window partition. 
#They are equivalent to RANK, DENSE_RANK and PERCENT_RANK functions in SQL.

dataset = spark.range(9).withColumn("bucket", col("id") % 3)  

byBucket = Window.partitionBy("bucket").orderBy("id")

>>> dataset.withColumn("rank", rank().over(byBucket)).show()
+---+------+----+
| id|bucket|rank|
+---+------+----+
|  0|     0|   1|
|  3|     0|   2|
|  6|     0|   3|
|  1|     1|   1|
|  4|     1|   2|
|  7|     1|   3|
|  2|     2|   1|
|  5|     2|   2|
|  8|     2|   3|
+---+------+----+

>>> dataset.withColumn("percent_rank", percent_rank().over(byBucket)).show()
+---+------+------------+
| id|bucket|percent_rank|
+---+------+------------+
|  0|     0|         0.0|
|  3|     0|         0.5|
|  6|     0|         1.0|
|  1|     1|         0.0|
|  4|     1|         0.5|
|  7|     1|         1.0|
|  2|     2|         0.0|
|  5|     2|         0.5|
|  8|     2|         1.0|
+---+------+------------+

#rank function assigns the same rank for duplicate rows 
#with a gap in the sequence (similarly to Olympic medal places). 
#dense_rank is like rank for duplicate rows but compacts the ranks and removes the gaps.

# rank function with duplicates
# Note the missing/sparse ranks, i.e. 2 and 4
>>> dataset.union(dataset).withColumn("rank", rank().over(byBucket)).show()
+---+------+----+
| id|bucket|rank|
+---+------+----+
|  0|     0|   1|
|  0|     0|   1|
|  3|     0|   3|
|  3|     0|   3|
|  6|     0|   5|
|  6|     0|   5|
|  1|     1|   1|
|  1|     1|   1|
|  4|     1|   3|
|  4|     1|   3|
|  7|     1|   5|
|  7|     1|   5|
|  2|     2|   1|
|  2|     2|   1|
|  5|     2|   3|
|  5|     2|   3|
|  8|     2|   5|
|  8|     2|   5|
+---+------+----+

# dense_rank function with duplicates
# Note that the missing ranks are now filled in
>>> dataset.union(dataset).withColumn("dense_rank", dense_rank().over(byBucket)).show()
+---+------+----------+
| id|bucket|dense_rank|
+---+------+----------+
|  0|     0|         1|
|  0|     0|         1|
|  3|     0|         2|
|  3|     0|         2|
|  6|     0|         3|
|  6|     0|         3|
|  1|     1|         1|
|  1|     1|         1|
|  4|     1|         2|
|  4|     1|         2|
|  7|     1|         3|
|  7|     1|         3|
|  2|     2|         1|
|  2|     2|         1|
|  5|     2|         2|
|  5|     2|         2|
|  8|     2|         3|
|  8|     2|         3|
+---+------+----------+

# percent_rank function with duplicates
>>> dataset.union(dataset).withColumn("percent_rank", percent_rank().over(byBucket)).show()
+---+------+------------+
| id|bucket|percent_rank|
+---+------+------------+
|  0|     0|         0.0|
|  0|     0|         0.0|
|  3|     0|         0.4|
|  3|     0|         0.4|
|  6|     0|         0.8|
|  6|     0|         0.8|
|  1|     1|         0.0|
|  1|     1|         0.0|
|  4|     1|         0.4|
|  4|     1|         0.4|
|  7|     1|         0.8|
|  7|     1|         0.8|
|  2|     2|         0.0|
|  2|     2|         0.0|
|  5|     2|         0.4|
|  5|     2|         0.4|
|  8|     2|         0.8|
|  8|     2|         0.8|
+---+------+------------+

##Cumulative Distribution of Records Across Window Partitions�cume_dist Function
cume_dist(): Column
#cume_dist computes the cumulative distribution of the records in window partitions. 
#This is equivalent to SQL�s CUME_DIST function.

buckets = spark.range(9).withColumn("bucket", col("id") % 3)
# Make duplicates
dataset = buckets.union(buckets)


windowSpec = Window.partitionBy("bucket").orderBy(col("id"))
>>> dataset.withColumn("cume_dist", cume_dist().over(windowSpec)).show()   #'
+---+------+------------------+
| id|bucket|         cume_dist|
+---+------+------------------+
|  0|     0|0.3333333333333333|
|  3|     0|0.6666666666666666|
|  6|     0|               1.0|
|  1|     1|0.3333333333333333|
|  4|     1|0.6666666666666666|
|  7|     1|               1.0|
|  2|     2|0.3333333333333333|
|  5|     2|0.6666666666666666|
|  8|     2|               1.0|
+---+------+------------------+

##lag Function
lag(e: Column, offset: Int): Column
lag(columnName: String, offset: Int): Column
lag(columnName: String, offset: Int, defaultValue: Any): Column
lag(e: Column, offset: Int, defaultValue: Any): Column

#lag returns the value in e/columnName column that is offset records 
#before the current record. 
#lag returns null value if the number of records in a window partition is less than offset or defaultValue.
#For example, an offset of one will return the previous row at any given point in the window partition
buckets = spark.range(9).withColumn("bucket", col("id") % 3) #'
# Make duplicates
dataset = buckets.union(buckets)
+---+------+
| id|bucket|
+---+------+
|  0|     0|
|  1|     1|
|  2|     2|
|  3|     0|
|  4|     1|
|  5|     2|
|  6|     0|
|  7|     1|
|  8|     2|
|  0|     0|
|  1|     1|
|  2|     2|
|  3|     0|
|  4|     1|
|  5|     2|
|  6|     0|
|  7|     1|
|  8|     2|
+---+------+
import org.apache.spark.sql.expressions.Window
windowSpec = Window.partitionBy("bucket").orderBy(col("id"))
>>> dataset.withColumn("lag", lag(col("id"), 1).over(windowSpec)).show()
+---+------+----+
| id|bucket| lag|
+---+------+----+
|  0|     0|null|
|  0|     0|   0|
|  3|     0|   0|
|  3|     0|   3|
|  6|     0|   3|
|  6|     0|   6|
|  1|     1|null|
|  1|     1|   1|
|  4|     1|   1|
|  4|     1|   4|
|  7|     1|   4|
|  7|     1|   7|
|  2|     2|null|
|  2|     2|   2|
|  5|     2|   2|
|  5|     2|   5|
|  8|     2|   5|
|  8|     2|   8|
+---+------+----+

>>> dataset.withColumn("lag", lag(col("id"), 2, 99).over(windowSpec)).show()
+---+------+---+
| id|bucket|lag|
+---+------+---+
|  0|     0| 99|
|  0|     0| 99|
|  3|     0|  0|
|  3|     0|  0|
|  6|     0|  3|
|  6|     0|  3|
|  1|     1| 99|
|  1|     1| 99|
|  4|     1|  1|
|  4|     1|  1|
|  7|     1|  4|
|  7|     1|  4|
|  2|     2| 99|
|  2|     2| 99|
|  5|     2|  2|
|  5|     2|  2|
|  8|     2|  5|
|  8|     2|  5|
+---+------+---+

##lead Function
lead(columnName: String, offset: Int): Column
lead(e: Column, offset: Int): Column
lead(columnName: String, offset: Int, defaultValue: Any): Column
lead(e: Column, offset: Int, defaultValue: Any): Column

#lead returns the value that is offset records after the current records, 
#and defaultValue if there is less than offset records after the current record. 
#lag returns null value if the number of records in a window partition is less than offset or defaultValue.

buckets = spark.range(9).withColumn("bucket", col("id") % 3)
# Make duplicates
dataset = buckets.union(buckets)

import org.apache.spark.sql.expressions.Window
windowSpec = Window.partitionBy("bucket").orderBy(col("id"))
>>> dataset.withColumn("lead", lead(col("id"), 1).over(windowSpec)).show()
+---+------+----+
| id|bucket|lead|
+---+------+----+
|  0|     0|   0|
|  0|     0|   3|
|  3|     0|   3|
|  3|     0|   6|
|  6|     0|   6|
|  6|     0|null|
|  1|     1|   1|
|  1|     1|   4|
|  4|     1|   4|
|  4|     1|   7|
|  7|     1|   7|
|  7|     1|null|
|  2|     2|   2|
|  2|     2|   5|
|  5|     2|   5|
|  5|     2|   8|
|  8|     2|   8|
|  8|     2|null|
+---+------+----+

>>> dataset.withColumn("lead", lead(col("id"), 2, "<default_value>").over(windowSpec)).show()  #'
+---+------+----+
| id|bucket|lead|
+---+------+----+
|  0|     0|   3|
|  0|     0|   3|
|  3|     0|   6|
|  3|     0|   6|
|  6|     0|null|
|  6|     0|null|
|  1|     1|   4|
|  1|     1|   4|
|  4|     1|   7|
|  4|     1|   7|
|  7|     1|null|
|  7|     1|null|
|  2|     2|   5|
|  2|     2|   5|
|  5|     2|   8|
|  5|     2|   8|
|  8|     2|null|
|  8|     2|null|
+---+------+----+

##Sequential numbering per window partition�row_number Function
row_number(): Column
#row_number returns a sequential number starting at 1 within a window partition.

buckets = spark.range(9).withColumn("bucket", col("id") % 3)
# Make duplicates
dataset = buckets.union(buckets)

import org.apache.spark.sql.expressions.Window
windowSpec = Window.partitionBy("bucket").orderBy(col("id"))
>>> dataset.withColumn("row_number", row_number().over(windowSpec)).show()  #'
+---+------+----------+
| id|bucket|row_number|
+---+------+----------+
|  0|     0|         1|
|  0|     0|         2|
|  3|     0|         3|
|  3|     0|         4|
|  6|     0|         5|
|  6|     0|         6|
|  1|     1|         1|
|  1|     1|         2|
|  4|     1|         3|
|  4|     1|         4|
|  7|     1|         5|
|  7|     1|         6|
|  2|     2|         1|
|  2|     2|         2|
|  5|     2|         3|
|  5|     2|         4|
|  8|     2|         5|
|  8|     2|         6|
+---+------+----------+

##ntile Function
ntile(n: Int): Column
#ntile computes the ntile group id (from 1 to n inclusive) in an ordered window partition.

dataset = spark.range(7).select('*', (col("id") % 3). alias("bucket"))

byBuckets = Window.partitionBy("bucket").orderBy(col("id"))
>>> dataset.select('*', ntile(3).over(byBuckets).alias("ntile")).show()  #'
+---+------+-----+
| id|bucket|ntile|
+---+------+-----+
|  0|     0|    1|
|  3|     0|    2|
|  6|     0|    3|
|  1|     1|    1|
|  4|     1|    2|
|  2|     2|    1|
|  5|     2|    2|
+---+------+-----+
##expr Function
expr(expr: String): Column
#expr function parses the input expr SQL statement to a Column it represents.

ds = sc.parallelize([(0, "hello"), (1, "world")]).toDF(["id", "token"])
>>> ds.show()
+---+-----+
| id|token|
+---+-----+
|  0|hello|
|  1|world|
+---+-----+

filterExpr = expr("token = 'hello'")
>>> ds.filter(filterExpr).show()
+---+-----+
| id|token|
+---+-----+
|  0|hello|
+---+-----+

##grouping Aggregate Function
grouping(e: Column): Column
grouping(columnName: String): Column 
#grouping is an aggregate function that indicates whether a specified column is aggregated or not and:
    # returns 1 if the column is in a subtotal and is NULL
    # returns 0 if the underlying value is NULL or any other value

#grouping can only be used with cube, rollup or GROUPING SETS multi-dimensional aggregate operators 
#(and is verified when Analyzer does check analysis).


tmpWorkshops = sc.parallelize([
  ("Warsaw", 2016, 2),
  ("Toronto", 2016, 4),
  ("Toronto", 2017, 1)]).toDF(["city", "year", "count"])

# there seems to be a bug with nulls
# and so the need for the following union
cityNull = sc.parallelize([(None, 2016, 2)]).toDF(["city", "year", "count"])

workshops = tmpWorkshops.union(cityNull)

>>> workshops.show()
+-------+----+-----+
|   city|year|count|
+-------+----+-----+
| Warsaw|2016|    2|
|Toronto|2016|    4|
|Toronto|2017|    1|
|   null|2016|    2|
+-------+----+-----+

q = workshops   \
  .cube("city", "year") \
  .agg(grouping("city"), grouping("year"))  \ # <-- grouping here
  .sort(col("city").desc(), col("year").desc())

>>> q.show()
+-------+----+--------------+--------------+
|   city|year|grouping(city)|grouping(year)|
+-------+----+--------------+--------------+
| Warsaw|2016|             0|             0|
| Warsaw|null|             0|             1|
|Toronto|2017|             0|             0|
|Toronto|2016|             0|             0|
|Toronto|null|             0|             1|
|   null|2017|             1|             0|
|   null|2016|             1|             0|
|   null|2016|             0|             0|  <-- null is city
|   null|null|             0|             1|  <-- null is city
|   null|null|             1|             1|
+-------+----+--------------+--------------+


##grouping_id Aggregate Function
grouping_id(cols: Column*): Column
grouping_id(colName: String, colNames: String*): Column (1)
#grouping_id is an aggregate function that computes the level of grouping:
    # 0 for combinations of each column
    # 1 for subtotals of column 1
    # 2 for subtotals of column 2
    # And so on�
#The list of columns of grouping_id should match grouping columns (in cube or rollup) exactly, 
#or empty which means all the grouping columns (which is exactly what the function expects).
#grouping_id can only be used with cube, rollup or GROUPING SETS multi-dimensional aggregate operators (and is verified when Analyzer does check analysis).

tmpWorkshops = sc.parallelize([
  ("Warsaw", 2016, 2),
  ("Toronto", 2016, 4),
  ("Toronto", 2017, 1)]).toDF(["city", "year", "count"])

# there seems to be a bug with nulls
# and so the need for the following union
cityNull = sc.parallelize([(None, 2016, 2)]).toDF(["city", "year", "count"])

workshops = tmpWorkshops.union(cityNull)

>>> workshops.show()
+-------+----+-----+
|   city|year|count|
+-------+----+-----+
| Warsaw|2016|    2|
|Toronto|2016|    4|
|Toronto|2017|    1|
|   null|2016|    2|
+-------+----+-----+

query = workshops   \
  .cube("city", "year") \
  .agg(grouping_id())                   \  # <-- all grouping columns used
  .sort(col("city").desc(), col("year").desc())
>>> query.show()
+-------+----+-------------+
|   city|year|grouping_id()|
+-------+----+-------------+
| Warsaw|2016|            0|
| Warsaw|null|            1|
|Toronto|2017|            0|
|Toronto|2016|            0|
|Toronto|null|            1|
|   null|2017|            2|
|   null|2016|            2|
|   null|2016|            0|
|   null|null|            1|
|   null|null|            3|
+-------+----+-------------+


# bin function gives the string representation of the binary value of the given long column
>>> query.withColumn("bitmask", bin("grouping_id()")).show()
+-------+----+-------------+-------+
|   city|year|grouping_id()|bitmask|
+-------+----+-------------+-------+
| Warsaw|2016|            0|      0|
| Warsaw|null|            1|      1|
|Toronto|2017|            0|      0|
|Toronto|2016|            0|      0|
|Toronto|null|            1|      1|
|   null|2017|            2|     10|
|   null|2016|            2|     10|
|   null|2016|            0|      0|  <-- null is city
|   null|null|            3|     11|
|   null|null|            1|      1|
+-------+----+-------------+-------+


##Extracting Data from Arbitrary JSON-Encoded Values�from_json Functions
from_json(e: Column, schema: StructType, options: Map[String, String]): Column (1)
from_json(e: Column, schema: DataType, options: Map[String, String]): Column (2)
from_json(e: Column, schema: StructType): Column (3)
from_json(e: Column, schema: DataType): Column  (4)
from_json(e: Column, schema: String, options: Map[String, String]): Column (5)
#from_json parses a column with a JSON-encoded value into a StructType 
#or ArrayType of StructType elements with the specified schema.

jsons = sc.parallelize(["""{ "id": 0 }"""]).toDF(["json"])

schema = StructType().add("id", IntegerType(), True)

>>> jsons.select(from_json("json", schema).alias("ids")).show()
+---+
|ids|
+---+
|[0]|
+---+

#A schema can be one of the following:
    # DataType as a object or in the JSON format
    # StructType in the DDL format

# Define the schema for JSON-encoded messages
# Note that the schema is nested (on the addresses field)

addressesSchema = StructType()  \
  .add("city", StringType(), True)  \
  .add("state", StringType(), True) \
  .add("zip", StringType(), True)   
schema =  StructType()   \
  .add("firstName", StringType(), True) \
  .add("lastName", StringType(), True)  \
  .add("email", StringType(), True) \
  .add("addresses", ArrayType(addressesSchema ))
  

# Generate the JSON-encoded schema
# That's the variant of the schema that from_json accepts
schemaAsJson = schema.json()

# Use prettyJson to print out the JSON-encoded schema
# Only for demo purposes
import json 
print(json.dumps(json.loads(schemaAsJson), indent=4, sort_keys=True))

{
  "type" : "struct",
  "fields" : [ {
    "name" : "firstName",
    "type" : "string",
    "nullable" : true,
    "metadata" : { }
  }, {
    "name" : "lastName",
    "type" : "string",
    "nullable" : true,
    "metadata" : { }
  }, {
    "name" : "email",
    "type" : "string",
    "nullable" : true,
    "metadata" : { }
  }, {
    "name" : "addresses",
    "type" : {
      "type" : "array",
      "elementType" : {
        "type" : "struct",
        "fields" : [ {
          "name" : "city",
          "type" : "string",
          "nullable" : true,
          "metadata" : { }
        }, {
          "name" : "state",
          "type" : "string",
          "nullable" : true,
          "metadata" : { }
        }, {
          "name" : "zip",
          "type" : "string",
          "nullable" : true,
          "metadata" : { }
        } ]
      },
      "containsNull" : true
    },
    "nullable" : true,
    "metadata" : { }
  } ]
}

# Let's "validate" the JSON-encoded schema

dt = StructType.fromJson(json.loads(schemaAsJson))
>>> print(dt.simpleString())
struct<firstName:string,lastName:string,email:string,addresses:array<struct<city:string,state:string,zip:string>>>

# No exception means that the JSON-encoded schema should be fine
# Use it with from_json
rawJsons = sc.parallelize([("""
  {
    "firstName" : "Jacek",
    "lastName" : "Laskowski",
    "email" : "jacek@japila.pl",
    "addresses" : [
      {
        "city" : "Warsaw",
        "state" : "N/A",
        "zip" : "02-791"
      }
    ]
  }""",)]).toDF(["rawjson"])
###Check , how it is used to flatten
people = rawJsons   \
  .select(from_json("rawjson", dt).alias("json"))   \
  .select("json.*")                                     \ # <-- flatten the struct field
  .withColumn("address", explode("addresses"))          \ # <-- explode the array field
  .drop("addresses")                                    \ # <-- no longer needed
  .select("firstName", "lastName", "email", "address.*") # <-- flatten the struct field
>>> people.show()
+---------+---------+---------------+------+-----+------+
|firstName| lastName|          email|  city|state|   zip|
+---------+---------+---------------+------+-----+------+
|    Jacek|Laskowski|jacek@japila.pl|Warsaw|  N/A|02-791|
+---------+---------+---------------+------+-----+------+

#options controls how a JSON is parsed and contains the same options as the json format.

jsons = sc.parallelize([("""{ id: 0 }""",)]).toDF(["json"])

schema = StructType().add("id",IntegerType(),True).add("corrupted_records", StringType(), True)
opts = {"columnNameOfCorruptRecord": "corrupted_records"}
>>> jsons.select(from_json("json", schema, opts).alias("ids")).show()
+----+
| ids|
+----+
|null|
+----+



###Date and Time Functions
##Current Date As Date Column�current_date Function
current_date(): Column
#current_date function gives the current date as a date column.

df = spark.range(1).select(current_date())
>>> df.show()
+--------------+
|current_date()|
+--------------+
|    2017-09-16|
+--------------+

>>> df.printSchema()
root
 |-- current_date(): date (nullable = false)

##date_format Function
date_format(dateExpr: Column, format: String): Column
#date_format creates a Column with DateFormatClass binary expression. 
#DateFormatClass takes the expression from dateExpr column and format.

c = date_format("date", "dd/MM/yyyy")


##current_timestamp Function
current_timestamp(): Column
#current_timestamp is also now function in SQL.
df = spark.range(1).select(current_timestamp())
>>> df.show()

##to_date Function
to_date(e: Column, fmt: String): Column
to_timestamp(s: Column): Column
to_timestamp(s: Column, fmt: String): Column

df = spark.range(1).select(date_format(current_date(),"dd/MM/yyyy").alias("date"))
df.withColumn("dateF", to_date(col("date"),"dd/MM/yyyy")) #DataFrame[date: string, dateF: date]


##Converting Current or Specified Time to Unix Timestamp�unix_timestamp Function
unix_timestamp(): Column  (1)
unix_timestamp(time: Column): Column (2)
unix_timestamp(time: Column, format: String): Column
#Gives current timestamp (in seconds)
#Converts time string in format yyyy-MM-dd HH:mm:ss to Unix timestamp (in seconds)
#unix_timestamp converts the current or specified time in the specified format 
#to a Unix timestamp (in seconds).

#unix_timestamp supports a column of type Date, Timestamp or String.

# no time and format => current time
>>> spark.range(1).select(unix_timestamp().alias( "current_timestamp")).show()
+-----------------+
|current_timestamp|
+-----------------+
|       1493362850|
+-----------------+

# no format so yyyy-MM-dd HH:mm:ss assumed
>>> sc.parallelize([("2017-01-01 00:00:00",)]).toDF(["time"]).withColumn("unix_timestamp", unix_timestamp("time")).show()
+-------------------+--------------+
|               time|unix_timestamp|
+-------------------+--------------+
|2017-01-01 00:00:00|    1483225200|
+-------------------+--------------+

>>> sc.parallelize([("2017-01-01 00:00:00",)]).toDF(["time"]).withColumn("unix_timestamp", unix_timestamp("time", "yyyy/MM/dd")).show()
+-------------------+--------------+
|               time|unix_timestamp|
+-------------------+--------------+
|2017/01/01 00:00:00|    1483225200|
+-------------------+--------------+

#unix_timestamp returns null if conversion fails.

#unix_timestamp is also supported in SQL mode.

>>> spark.sql("SELECT unix_timestamp() as unix_timestamp").show()
+--------------+
|unix_timestamp|
+--------------+
|    1493369225|
+--------------+

##Generating Time based window Function
window(
  timeColumn: Column,
  windowDuration: String,
  slideDuration: String,
  startTime: String): Column     

#window generates tumbling, sliding or delayed time windows of windowDuration duration 
#given a timeColumn timestamp specifying column.
#Tumbling windows are a series of fixed-sized, non-overlapping and contiguous time intervals.

#windowDuration and slideDuration are strings specifying the width of the window 
#for duration and sliding identifiers, respectively.

>>> timeColumn = window("time", "5 seconds")    #'
Column<b'timewindow(time, 5000000, 5000000, 0) AS `window`'>

#timeColumn should be of TimestampType, i.e. with datetime.datetime values.
import datetime 
levels = sc.parallelize([
  # (year, month, dayOfMonth, hour, minute, second)
  ((2012, 12, 12, 12, 12, 12), 5),
  ((2012, 12, 12, 12, 12, 14), 9),
  ((2012, 12, 12, 13, 13, 14), 4),
  ((2016, 8,  13, 0, 0, 0), 10),
  ((2017, 5,  27, 0, 0, 0), 15)]).map(lambda t : (datetime.datetime(*t[0]), t[1])).toDF(["time", "level"])
>>> levels.show()
+-------------------+-----+
|               time|level|
+-------------------+-----+
|2012-12-12 12:12:12|    5|
|2012-12-12 12:12:14|    9|
|2012-12-12 13:13:14|    4|
|2016-08-13 00:00:00|   10|
|2017-05-27 00:00:00|   15|
+-------------------+-----+

q = levels.select(window("time", "5 seconds"), "level")
>>> q.show(truncate = False)
+---------------------------------------------+-----+
|window                                       |level|
+---------------------------------------------+-----+
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|5    |
|[2012-12-12 12:12:10.0,2012-12-12 12:12:15.0]|9    |
|[2012-12-12 13:13:10.0,2012-12-12 13:13:15.0]|4    |
|[2016-08-13 00:00:00.0,2016-08-13 00:00:05.0]|10   |
|[2017-05-27 00:00:00.0,2017-05-27 00:00:05.0]|15   |
+---------------------------------------------+-----+

>>> q.printSchema()
root
 |-- window: struct (nullable = true)
 |    |-- start: timestamp (nullable = true)
 |    |-- end: timestamp (nullable = true)
 |-- level: integer (nullable = false)

# calculating the sum of levels every 5 seconds
sums = levels.  \
  groupBy(window("time", "5 seconds")). \
  agg(sum("level").alias("level_sum")).  \
  select("window.start", "window.end", "level_sum")
>>> sums.show()
+-------------------+-------------------+---------+
|              start|                end|level_sum|
+-------------------+-------------------+---------+
|2012-12-12 13:13:10|2012-12-12 13:13:15|        4|
|2012-12-12 12:12:10|2012-12-12 12:12:15|       14|
|2016-08-13 00:00:00|2016-08-13 00:00:05|       10|
|2017-05-27 00:00:00|2017-05-27 00:00:05|       15|
+-------------------+-------------------+---------+





##Generating Records  based window Function
#Window aggregate functions (aka window functions or windowed aggregates) are functions 
#that perform a calculation over a group of records called window 
#that are in some relation to the current record (i.e. can be in the same partition or frame as the current row).

#In other words, when executed, a window function computes a value for each and every row 
#in a window (per window specification).

#Window functions are also called.over(functions due to how they are applied using.over(operator.

#Spark SQL supports three kinds of window functions:
    # ranking functions  - rank,dense_rank,percent_rank,ntile,row_number
    # analytic functions - cum_dist,lag,lead
    # aggregate functions

##For aggregate functions, you can use the existing aggregate functions as window functions, 
#e.g. sum, avg, min, max and count.

# Borrowed from 3.5. Window Functions in PostgreSQL documentation
# Example of window functions using Scala API
#
Salary = Row('depName', 'empNo', 'salary')
empsalary = sc.parallelize([
  Salary("sales", 1, 5000),
  Salary("personnel", 2, 3900),
  Salary("sales", 3, 4800),
  Salary("sales", 4, 4800),
  Salary("personnel", 5, 3500),
  Salary("develop", 7, 4200),
  Salary("develop", 8, 6000),
  Salary("develop", 9, 4500),
  Salary("develop", 10, 5200),
  Salary("develop", 11, 5200)]).toDF()

import org.apache.spark.sql.expressions.Window
# Windows are partitions of deptName
byDepName = Window.partitionBy('depName')
>>> empsalary.withColumn("avg", avg('salary').over(byDepName)).show()
+---------+-----+------+-----------------+
|  depName|empNo|salary|              avg|
+---------+-----+------+-----------------+
|  develop|    7|  4200|           5020.0|
|  develop|    8|  6000|           5020.0|
|  develop|    9|  4500|           5020.0|
|  develop|   10|  5200|           5020.0|
|  develop|   11|  5200|           5020.0|
|    sales|    1|  5000|4866.666666666667|
|    sales|    3|  4800|4866.666666666667|
|    sales|    4|  4800|4866.666666666667|
|personnel|    2|  3900|           3700.0|
|personnel|    5|  3500|           3700.0|
+---------+-----+------+-----------------+

#The main difference between window aggregate functions and aggregate functions with grouping operators 
#is that the former calculate values for every row in a window 
#while the latter gives you at most the number of input rows, one value per group.

#You can mark a function window by.over(clause after a function in SQL, 
#e.g. avg(revenue).over((�) or.over(method on a function in the Dataset API, e.g. rank().over(�).


##WindowSpec�Window Specification

#A window specification defines which rows are included in a window (aka a frame), 
#i.e. set of rows, that is associated with a given input row. 
#It does so by partitioning an entire data set and specifying frame boundary with ordering.




#A window specification includes three parts:
    Partitioning Specification defines which records are in the same partition. 
        With no partition defined, all records belong to a single partition.
    Ordering Specification defines how records in a partition are ordered 
        that in turn defines the position of a record in a partition. 
        The ordering could be ascending (ASC in SQL or asc in Scala) or descending (DESC or desc).
    Frame Specification (unsupported in Hive;)defines the records to be included in the frame 
        for the current input row, based on their relative position to the current row. 
        For example, �the three rows preceding the current row to the current row� 
        describes a frame including the current input row and three rows appearing 
        before the current row.

#Once WindowSpec instance has been created using Window object, 
#you can further expand on window specification using the following methods to define frames:
    rowsBetween(start: Long, end: Long): WindowSpec
    rangeBetween(start: Long, end: Long): WindowSpec

##Partitioning Records�partitionBy Methods
partitionBy(colName: String, colNames: String*): WindowSpec
partitionBy(cols: Column*): WindowSpec

#partitionBy creates an instance of WindowSpec with partition expression(s) 
#defined for one or more columns.

# partition records into two groups
# * tokens starting with "h"
# * others


tokens = sc.parallelize([(0,'hello'),(1,'henry'),(2,'and'),(3,'harry')]).toDF(["id","token"])

byHTokens = Window.partitionBy(col('token').startswith("h"))  #'

# count the sum of ids in each group
result = tokens.select('*', sum(col("id")).over(byHTokens).alias("sum.over h tokens")).orderBy(col("id")) #'

>>> result.show()
+---+-----+-----------------+
| id|token|sum.over h tokens|
+---+-----+-----------------+
|  0|hello|                4|
|  1|henry|                4|
|  2|  and|                2|
|  3|harry|                4|
+---+-----+-----------------+

##Ordering in Windows�orderBy Methods
orderBy(colName: String, colNames: String*): WindowSpec
orderBy(cols: Column*): WindowSpec
#orderBy allows you to control the order of records in a window.

byDepnameSalaryDesc = Window.partitionBy('depname').orderBy(col('salary').desc())

# a numerical rank within the current row's partition for each distinct ORDER BY value
>>> rankByDepname = rank().over(byDepnameSalaryDesc)

>>> empsalary.select('*', rankByDepname.alias('rank')).show()
+---------+-----+------+----+
|  depName|empNo|salary|rank|
+---------+-----+------+----+
|  develop|    8|  6000|   1|
|  develop|   10|  5200|   2|
|  develop|   11|  5200|   2|
|  develop|    9|  4500|   4|
|  develop|    7|  4200|   5|
|    sales|    1|  5000|   1|
|    sales|    3|  4800|   2|
|    sales|    4|  4800|   2|
|personnel|    2|  3900|   1|
|personnel|    5|  3500|   2|
+---------+-----+------+----+

##rangeBetween Method
rangeBetween(start: Long, end: Long): WindowSpec
#rangeBetween creates a WindowSpec with the frame boundaries from start (inclusive) to end (inclusive).
#It is recommended to use Window.unboundedPreceding, Window.unboundedFollowing 
#and Window.currentRow to describe the frame boundaries when a frame is unbounded preceding, unbounded following and at current row, respectively.


WindowSpec = Window.rangeBetween(Window.unboundedPreceding, Window.currentRow)

# PARTITION BY country ORDER BY date ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
Window.partitionBy('country').orderBy('date').rowsBetween(np.iinfo(np.int64).min, 0)
# PARTITION BY country ORDER BY date ROWS BETWEEN 3 PRECEDING AND 3 FOLLOWING
Window.partitionBy('country').orderBy('date').rowsBetween(-3, 3)

##Frame
#At its core, a window function calculates a return value for every input row of a table 
#based on a group of rows, called the frame. 
#Every input row can have a unique frame associated with it.

#When you define a frame you have to specify three components of a frame specification -
#the start and end boundaries, and the type.

#Types of boundaries (two positions and three offsets):
    UNBOUNDED PRECEDING - the first row of the partition
    UNBOUNDED FOLLOWING - the last row of the partition
    CURRENT ROW
    <value> PRECEDING
    <value> FOLLOWING

#Offsets specify the offset from the current input row.
#Types of frames:
    ROW - based on physical offsets from the position of the current input row
    RANGE - based on logical offsets from the position of the current input row

#you can use two methods to define a frame:
    rowsBetween
    rangeBetween

#Window frame definition is simply not supported by Hive GenericUDAFRank, GenericUDAFLag and GenericUDAFLead 
#so errors are an expected behavior.

#Another issue 
wSpec = Window.orderBy(df.a)
df.select(df.a, func.rank().over(wSpec).alias("rank"))

#you can make it work by changing window definition to this:
wSpec = Window.partitionBy().orderBy(df.a)
    
    
##Window Operators in SQL Queries
#The grammar of windows operators in SQL accepts the following:
    CLUSTER BY or PARTITION BY or DISTRIBUTE BY for partitions,
    ORDER BY or SORT BY for sorting order,
    RANGE, ROWS, RANGE BETWEEN, and ROWS BETWEEN for window frame types,
    UNBOUNDED PRECEDING, UNBOUNDED FOLLOWING, CURRENT ROW for frame bounds.

##Examples -Top N per Group
#Top N per Group is useful when you need to compute the first and second best-sellers in category.
#Question: What are the best-selling and the second best-selling products in every category

dataset = sc.parallelize([
  ("Thin",       "cell phone", 6000),
  ("Normal",     "tablet",     1500),
  ("Mini",       "tablet",     5500),
  ("Ultra thin", "cell phone", 5000),
  ("Very thin",  "cell phone", 6000),
  ("Big",        "tablet",     2500),
  ("Bendable",   "cell phone", 3000),
  ("Foldable",   "cell phone", 3000),
  ("Pro",        "tablet",     4500),
  ("Pro2",       "tablet",     6500)]).toDF(["product", "category", "revenue"])

>>> dataset.show()
+----------+----------+-------+
|   product|  category|revenue|
+----------+----------+-------+
|      Thin|cell phone|   6000|
|    Normal|    tablet|   1500|
|      Mini|    tablet|   5500|
|Ultra thin|cell phone|   5000|
| Very thin|cell phone|   6000|
|       Big|    tablet|   2500|
|  Bendable|cell phone|   3000|
|  Foldable|cell phone|   3000|
|       Pro|    tablet|   4500|
|      Pro2|    tablet|   6500|
+----------+----------+-------+

>>> data.where('category == "tablet"').show()  #'
+-------+--------+-------+
|product|category|revenue|
+-------+--------+-------+
| Normal|  tablet|   1500|
|   Mini|  tablet|   5500|
|    Big|  tablet|   2500|
|    Pro|  tablet|   4500|
|   Pro2|  tablet|   6500|
+-------+--------+-------+

#The question boils down to ranking products in a category 
#based on their revenue, and to pick the best selling and the second best-selling products 
#based the ranking.

overCategory = Window.partitionBy('category').orderBy(col('revenue').desc())

ranked = data.withColumn("rank", dense_rank().over(overCategory))

>>> ranked.show()
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|       Pro|    tablet|   4500|   3|
|       Big|    tablet|   2500|   4|
|    Normal|    tablet|   1500|   5|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
|  Bendable|cell phone|   3000|   3|
|  Foldable|cell phone|   3000|   3|
+----------+----------+-------+----+

>>> ranked.where('rank <= 2').show()  #'
+----------+----------+-------+----+
|   product|  category|revenue|rank|
+----------+----------+-------+----+
|      Pro2|    tablet|   6500|   1|
|      Mini|    tablet|   5500|   2|
|      Thin|cell phone|   6000|   1|
| Very thin|cell phone|   6000|   1|
|Ultra thin|cell phone|   5000|   2|
+----------+----------+-------+----+

##Revenue Difference per Category

reveDesc = Window.partitionBy('category).orderBy(col('revenue').desc())
reveDiff = max('revenue').over(reveDesc) - col('revenue')

>>> data.select('*', reveDiff.alias('revenue_diff)).show()
+----------+----------+-------+------------+
|   product|  category|revenue|revenue_diff|
+----------+----------+-------+------------+
|      Pro2|    tablet|   6500|           0|
|      Mini|    tablet|   5500|        1000|
|       Pro|    tablet|   4500|        2000|
|       Big|    tablet|   2500|        4000|
|    Normal|    tablet|   1500|        5000|
|      Thin|cell phone|   6000|           0|
| Very thin|cell phone|   6000|           0|
|Ultra thin|cell phone|   5000|        1000|
|  Bendable|cell phone|   3000|        3000|
|  Foldable|cell phone|   3000|        3000|
+----------+----------+-------+------------+

##Difference on Column
#Compute a difference between values in rows in a column.
pairs = [(x, 10 * x * y) for x in range(1,6) for y in range(1,3)]
ds = sc.parallelize(pairs).toDF(["ns", "tens"])

>>> ds.show()
+---+----+
| ns|tens|
+---+----+
|  1|  10|
|  1|  20|
|  2|  20|
|  2|  40|
|  3|  30|
|  3|  60|
|  4|  40|
|  4|  80|
|  5|  50|
|  5| 100|
+---+----+

overNs = Window.partitionBy('ns').orderBy('tens')
diff = lead('tens', 1).over(overNs)

>>> ds.withColumn("diff", diff - col('tens')).show()
+---+----+----+
| ns|tens|diff|
+---+----+----+
|  1|  10|  10|
|  1|  20|null|
|  3|  30|  30|
|  3|  60|null|
|  5|  50|  50|
|  5| 100|null|
|  4|  40|  40|
|  4|  80|null|
|  2|  20|  20|
|  2|  40|null|
+---+----+----+

##Running Total
#The running total is the sum of all previous lines including the current one.

sales = sc.parallelize([
  (0, 0, 0, 5),
  (1, 0, 1, 3),
  (2, 0, 2, 1),
  (3, 1, 0, 2),
  (4, 2, 0, 8),
  (5, 2, 2, 8)]).toDF(["id", "orderID", "prodID", "orderQty"])

>>> sales.show()
+---+-------+------+--------+
| id|orderID|prodID|orderQty|
+---+-------+------+--------+
|  0|      0|     0|       5|
|  1|      0|     1|       3|
|  2|      0|     2|       1|
|  3|      1|     0|       2|
|  4|      2|     0|       8|
|  5|      2|     2|       8|
+---+-------+------+--------+

orderedByID = Window.orderBy(col("id"))

totalQty = sum('orderQty').over(orderedByID).alias('running_total')
salesTotalQty = sales.select('*', totalQty).orderBy(col("id"))

>>> salesTotalQty.show()
16/04/10 23:01:52 WARN Window: No Partition Defined for Window operation! Moving all data to a single partition, this can cause serious performance degradation.
+---+-------+------+--------+-------------+
| id|orderID|prodID|orderQty|running_total|
+---+-------+------+--------+-------------+
|  0|      0|     0|       5|            5|
|  1|      0|     1|       3|            8|
|  2|      0|     2|       1|            9|
|  3|      1|     0|       2|           11|
|  4|      2|     0|       8|           19|
|  5|      2|     2|       8|           27|
+---+-------+------+--------+-------------+

byOrderId = orderedByID.partitionBy('orderID')
totalQtyPerOrder = sum('orderQty').over(byOrderId).alias('running_total_per_order')
salesTotalQtyPerOrder = sales.select('*', totalQtyPerOrder).orderBy(col("id"))

>>> salesTotalQtyPerOrder.show()
+---+-------+------+--------+-----------------------+
| id|orderID|prodID|orderQty|running_total_per_order|
+---+-------+------+--------+-----------------------+
|  0|      0|     0|       5|                      5|
|  1|      0|     1|       3|                      8|
|  2|      0|     2|       1|                      9|
|  3|      1|     0|       2|                      2|
|  4|      2|     0|       8|                      8|
|  5|      2|     2|       8|                     16|
+---+-------+------+--------+-----------------------+

#With the window function support, you could use user-defined aggregate functions as window functions.









































