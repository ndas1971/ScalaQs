#Set anaconda before py3.5 in path
# args= <trainingDir> <testDir> <batchDuration> <numClusters> <numDimensions>
#spark-submit  --master local[4] streaming_k_means_example2.py train test 10 2 3
#Create train and test directory 
#copy train and test data (increment 1, 2, 3..)
#to converge , keep on copying same train data as 2.txt, 3.txt 
#you would see predictions converges 
# rm -rf test train 
# mkdir test train 
#cp d:\desktop\ppt\spark\data\streaming_kmeans_train.txt train\1.txt
#cp d:\desktop\ppt\spark\data\streaming_kmeans_test.txt test\1.txt



from __future__ import print_function

from pyspark import SparkContext
from pyspark.streaming import StreamingContext

from pyspark.mllib.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.clustering import StreamingKMeans
import sys 
import re

if __name__ == "__main__":
    sc = SparkContext(appName="StreamingKMeansExample")  # SparkContext
    ssc = StreamingContext(sc, int(sys.argv[3]))
    
    def LabeledPoint_parse(lp):        
        ar = filter(lambda x: x , re.split(r"\(|\)|,|\[|\]", lp))
        label = float(ar[0])
        vec = Vectors.dense([float(x) for x in ar[1:]])
        return LabeledPoint(label, vec)

    trainingData = ssc.textFileStream(sys.argv[1]).map(Vectors.parse)
    testData = ssc.textFileStream(sys.argv[2]).map(LabeledPoint_parse)

    model = StreamingKMeans() \
      .setK(int(sys.argv[4])) \
      .setDecayFactor(1.0) \
      .setRandomCenters(int(sys.argv[5]), 0.0, None)

    model.trainOn(trainingData)

    #returns DStream containing the input keys ie lp.label and the predictions(which cluster) as values   
    model.predictOnValues(testData.map(lambda lp : (lp.label, lp.features))).pprint()

    ssc.start()
    ssc.awaitTermination()
