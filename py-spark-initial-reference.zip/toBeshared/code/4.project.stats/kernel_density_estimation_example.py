#Set anaconda in path 
#spark-submit --master local[4] kernel_density_estimation_example.py

#to estimate the probability density function of a random variable.
#X vs it's Pr plot 

from __future__ import print_function

from pyspark import SparkContext

from pyspark.mllib.stat import KernelDensity


if __name__ == "__main__":
    sc = SparkContext(appName="KernelDensityEstimationExample")  # SparkContext

    # an RDD of sample data
    data = sc.parallelize([1.0, 1.0, 1.0, 2.0, 3.0, 4.0, 5.0, 5.0, 6.0, 7.0, 8.0, 9.0, 9.0])

    # Construct the density estimator with the sample data and a standard deviation for the Gaussian
    # kernels
    kd = KernelDensity()
    kd.setSample(data)
    kd.setBandwidth(3.0) #ets the bandwidth (standard deviation) of the Gaussian kernel (default: 1.0). 

    # Find density estimates for the given values
    densities = kd.estimate([-1.0, 2.0, 5.0])


    print(densities)

    sc.stop()
