#Set anaconda in path 
#spark-submit --master local[4] stratified_sampling_example.py

from __future__ import print_function

from pyspark import SparkContext

if __name__ == "__main__":
    sc = SparkContext(appName="StratifiedSamplingExample")  # SparkContext


    # an RDD of any key value pairs
    data = sc.parallelize([(1, 'a'), (1, 'b'), (2, 'c'), (2, 'd'), (2, 'e'), (3, 'f')])

    # specify the exact fraction desired from each key as a dictionary
    fractions = {1: 0.1, 2: 0.6, 3: 0.3}

    approxSample = data.sampleByKey(False, fractions)


    for each in approxSample.collect():
        print(each)

    sc.stop()
