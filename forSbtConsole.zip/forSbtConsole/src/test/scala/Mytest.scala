package examples 

import org.scalatest._ 

class Mytest extends FunSuite with BeforeAndAfter with Matchers{
  var myValue: MyInt = _ 
  
  before{
    myValue = MyInt(2)
  }

  test("Add functionality"){ assert(myValue+myValue == MyInt(4)) }
  test("Add functionality2"){(myValue+myValue) should equal (MyInt(4))}

}