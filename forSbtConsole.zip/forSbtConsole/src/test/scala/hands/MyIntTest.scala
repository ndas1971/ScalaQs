package hands 

import org.scalatest._

class MyTest extends FunSuite with BeforeAndAfter with Matchers{
    var myValue:MyInt  = _
    before {
        myValue = MyInt(2)
    }

    test("testing add functionality"){
        assert( (myValue+2) == MyInt(4) )
    }
    
    test("testing add another way") {
        (myValue+myValue) should equal (MyInt(4))
    }
}

