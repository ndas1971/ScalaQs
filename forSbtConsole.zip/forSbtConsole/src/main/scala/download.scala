package download  //download.Main.main(Array[String]())

import akka.actor._
import akka.event.Logging
import scala.util._
import scala.concurrent._
import akka.util._ 
import scala.concurrent.duration._
import akka.pattern._

case class xURL(url:String, sender:ActorRef)
case class rMap(url:String, urls:Seq[String], sender:ActorRef)
case object STOP

class Download extends Actor {
  import org.xml.sax._ 
  import java.io._ 
  import java.net._   
  
  def get(url: String) = scala.io.Source.fromURL(url, "ISO-8859-1").getLines.toList.mkString

  def downloadURLAndGetAllHref(base:String):Seq[String] = {
        val parserFactory = new org.ccil.cowan.tagsoup.jaxp.SAXFactoryImpl
        val parser = parserFactory.newSAXParser()
        val source = new InputSource( new StringReader( get(base) ) )
        val adapter = new scala.xml.parsing.NoBindingFactoryAdapter
        val xml = adapter.loadXML(source, parser)
        (xml \\ "a" ).map { n => n \@ "href"}.map{ url => if(url.startsWith("http")) url else (new URL(new URL(base),url)).toString}
    }
    def receive = {
        case  xURL(url,ori_sender) =>                            
                            val t = Try{downloadURLAndGetAllHref(url)}
                            t match {
                                case Failure(exe) => sender() ! rMap(url, Seq.empty[String],ori_sender)
                                case Success(urls) => sender() ! rMap(url, urls.asInstanceOf[Seq[String]],ori_sender)
                            }                          
        case STOP => context stop self
     }
}

class Service extends Actor with ActorLogging {
  import org.xml.sax._ 
  import java.io._ 
  import java.net._   
  val rnd = scala.util.Random
  
  def receive = {
        case  url:String => 
                log.info(""+ Thread.currentThread.getName+":"+url) //not multiargs 
                //start new actor                 
                val a = context.actorOf(Props[Download], "download-" + rnd.nextInt.abs)
                val currentSender = sender()
                a ! xURL(url,currentSender)  //Do it like this, to remove latest bug 
        case rMap(url:String, urls:Seq[String], ori_sender:ActorRef) =>  
                ori_sender ! Map( url -> urls.toList) 
                //kill child 
                sender ! STOP 
        case _      => log.info("received unknown message")
      } 
}

object Main extends App {

    val urls = List(  "http://www.google.com",
                      "http://www.scala-lang.org/",
                      "http://jskdlsycds.com", //invalid url-1
                      "http://rediff.com",
                      "http://wowslskdleodd.com") //invalid url-2

                      
                      
                      
                      
    //actual code 
    implicit val system = ActorSystem("testSystem")
    val service = system.actorOf(Props[Service], "service") //or .actorOf(Props(classOf[MyActor], arg1, arg2), "name")

    import system.dispatcher // The ExecutionContext(for futures) that will be used
    implicit val timeout = Timeout(5 seconds) // needed for `?` below


    val gMap = scala.collection.concurrent.TrieMap[String,List[String]]()

                      
    val htmls = urls.map {
      url => 
        val fut = (service ? url).mapTo[Map[String,List[String]]] 
        fut.onSuccess { case map:Map[_,_]  =>                         
                            val old = gMap.getOrElse(url, List.empty[String])
                            //Update only diff 
                            val newS = map.values.toList(0).asInstanceOf[List[String]].toSet &~ old.toSet 
                            gMap.getOrElseUpdate(map.keys.toList(0).asInstanceOf[String],newS.toList)
                    }
        fut
    }
    val t1 = htmls.map{ fut => {val res = Try{Await.result(fut, Duration.Inf)};res} }.collect{case Success(map) => map.values.flatten.size}.reduce(_ + _)
    
    println(s"Total nested links found $t1")
    val tfut = system.terminate 
    Await.result(tfut, Duration.Inf)
}