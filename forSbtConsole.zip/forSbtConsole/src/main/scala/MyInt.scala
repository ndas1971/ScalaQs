package examples 
class MyInt(val x:Int) extends Ordered[MyInt]{    
    def this() { this(0)}
    override def hashCode = this.x.hashCode 
    override def toString = s"MyInt(${this.x})"
    override def equals(o:Any) = o match {
        case y:MyInt => this.hashCode == y.hashCode
        case _  => false 
    }    
    def +(o:MyInt) = MyInt(this.x + o.x)
    def compare(o:MyInt) = this.x compare o.x 
    //Main ctor body 
}
object MyInt{
    def apply(x:Int) = new MyInt(x)
    def unapply(x:MyInt):Option[Int] = Some(x.x)
    implicit def toInt(x:Int)  = new MyInt(x)
}
/*
val a = examples.Fraction(1,2)
val b = examples.Fraction(2,3)
val c = a + b 
print(c)  # Fraction( 7,6)

//val examples.Fraction(x,y) = a 
//x =1, y=2 
*/
package examplesCase {
    case class MyInt2(x:Int) extends Ordered[MyInt2]{    
        def this() { this(0)}    
        def +(o:MyInt2) = MyInt2(this.x + o.x)
        def compare(o:MyInt2) = this.x compare o.x 
        //Main ctor body 
    }
    object MyInt2 extends (Int => MyInt2) {
        def apply() = new MyInt2()
        implicit def toInt(x:Int)  = new MyInt2(x)
    }
}