package main 
import examples.MyInt

object Main extends App{

    val a = MyInt(2)
    println( a + 2 )

    
    
    
    
}