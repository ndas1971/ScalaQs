package hands

object Main extends App {
    /*
    Take each char(ch) from s 
        initialize counter 
        Take again each char(ch1) from s 
            if ch and ch1 are same 
                increment counter 
        print ch and counter 
    
    
    */
    val s = "Hello World"
    for ( ch <- s){
        var counter = 0 
        for (ch1 <- s) {
            if (ch == ch1)
                counter += 1 
        }
        println(s"$ch - $counter")
    }
    
    
    
    def freq[T](x:List[T]):Map[T,Int] = {
        val m = collection.mutable.Map[T,Int]()
        for (i <- x){
            if( m contains i){
                m(i) = m(i) + 1 
            } else {
                m(i) = 1
            }        
        }
        m.toMap
    }
    
         
    
    //def add(a:Int, b:Int=20) = a+b
    
    val ls = List(1,2,3,4)
    //import scala.collection.mutable._
    
    val out = collection.mutable.ListBuffer[Int]()
    for (i <- ls){
        out.append(i*i)
    }
    println(out)
    
    val ls2 = "List(1,2,3,4)"
    //val out = List(1,2,3,4)
    
    /*
    slice 5, ls2.size - 2 , => 1,2,3,4
    split with ","
    Take each element, convert to int and append to empty list 
    
    */
    
    
}
