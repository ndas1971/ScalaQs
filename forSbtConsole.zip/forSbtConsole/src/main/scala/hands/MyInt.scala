package hands 

class MyInt( private val x:Int) extends Ordered[MyInt]{
    def this() { this(0) }
    override def toString = s"MyInt(${this.x})"
    override def hashCode = this.x.hashCode 
    override def equals(o:Any) = o match {
        case x:MyInt => this.hashCode == x.hashCode
        case _ => false 
    }
    def compare(o:MyInt) = this.x compare o.x //OK
    //new 
    def +(o:MyInt) = new MyInt(this.x+o.x)    
 
}
object MyInt{
    def apply(x:Int) = new MyInt(x)
    def apply() = new MyInt()
    def unapply(x:MyInt):Option[Int] = Some(x.x)
    implicit def int2MyInt(x:Int) = new MyInt(x)
}


/*
val a = examples.Fraction(1,2)
val b = examples.Fraction(2,3)
val c = a + b 
print(c)  # Fraction( 7,6)

//val examples.Fraction(x,y) = a 
//x =1, y=2 
*/

package hands1 {
    case class MyInt( private val x:Int) extends Ordered[MyInt]{
        def this() { this(0) }       
        def compare(o:MyInt) = this.x compare o.x //OK
        //new 
        def +(o:MyInt) = new MyInt(this.x+o.x)            
    }
    object MyInt extends ((Int) => MyInt) {       
        implicit def int2MyInt(x:Int) = new MyInt(x)
    }
}



