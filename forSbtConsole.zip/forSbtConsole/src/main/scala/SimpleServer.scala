package tcp

import java.net._
import java.io._
import scala.io._

object Main extends App{
    val server = new ServerSocket(9998)
    println(s"Server online at http://localhost:9998/\nPress CRTL+c to stop...")
    server.setReuseAddress(true);

    while (true) {
        val s = server.accept()
        println(s"Accepted .. ${s.toString}")
        val out = new PrintStream(s.getOutputStream())
        var close = false
        while (!close ){
            val line = StdIn.readLine
            try{
                out.println(line)
                out.flush()
            } catch {
                case ex:Exception => 
                    close = true
            }
        }
        println(s"Closed .. ${s.toString}")
    }
}