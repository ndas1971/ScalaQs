package examples 

case class MyInt3(x:Int) extends Ordered[MyInt3]{ 
    //Another MyInt3 RHS    
    def +(o:MyInt3) = MyInt3(this.x + o.x)  //3
    def compare(o:MyInt3) = this.x compare o.x 
    //RHS T
    def +[T](o:T)(implicit ev : Numeric[T]) ={ //2
        import ev._ 
        MyInt3(x + ev.toInt(o)) //o.toInt)
    }
}
object MyInt3  {
    def apply[T](implicit ev:Numeric[T]) = new MyInt3(ev.toInt(ev.zero) )
    //LHS T
    implicit def toInt[T : Numeric ](x:T)  =  //1
        new MyInt3(implicitly[Numeric[T]].toInt(x) )
}
/*
2 + MyInt3(2)  //1
MyInt3(2) + 3  //2
MyInt3(2) + MyInt3(3) //3
MyInt3(2) + 3.0 //2
2.0 + MyInt3(2) //1
*/



